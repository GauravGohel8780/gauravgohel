package com.iten.tenoku.listeners;

public interface AdsNativeAdListener {

    void onAdShown(Boolean shown);

}
