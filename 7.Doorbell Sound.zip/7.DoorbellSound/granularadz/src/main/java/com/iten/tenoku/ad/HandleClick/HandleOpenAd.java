package com.iten.tenoku.ad.HandleClick;

public interface HandleOpenAd {
    void Show(boolean adShow);
}
