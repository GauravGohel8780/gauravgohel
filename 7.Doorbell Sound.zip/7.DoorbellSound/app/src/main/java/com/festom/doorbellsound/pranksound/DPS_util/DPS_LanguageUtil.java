package com.festom.doorbellsound.pranksound.DPS_util;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;

import com.festom.doorbellsound.pranksound.DPS_preference.DPS_SharePref;

import java.util.Locale;

public class DPS_LanguageUtil {
    public static void setLanguage(Context context) {
        if (context == null) {
            return;
        }
        String prefLanguage = DPS_SharePref.getPrefLanguage(context);
        if (prefLanguage == null) {
            prefLanguage = Locale.getDefault().getLanguage();
        }
        Locale locale = new Locale(prefLanguage.toLowerCase());
        Locale.setDefault(locale);
        Resources resources = context.getResources();
        Configuration configuration = resources.getConfiguration();
        configuration.setLocale(locale);
        resources.updateConfiguration(configuration, resources.getDisplayMetrics());
    }
}
