package com.festom.doorbellsound.pranksound.DPS_util;


import com.festom.doorbellsound.pranksound.DPS_model.DPS_FeedBackResponseModel;
import com.festom.doorbellsound.pranksound.DPS_model.DPS_FeedbackRequestModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface DPS_ApiService {

    @POST("api/v1/feedBack/save")
    Call<DPS_FeedBackResponseModel> feedbackUser(@Body DPS_FeedbackRequestModel request);
}