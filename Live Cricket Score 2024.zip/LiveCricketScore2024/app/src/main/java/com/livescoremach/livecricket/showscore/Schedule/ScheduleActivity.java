package com.livescoremach.livecricket.showscore.Schedule;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.os.Bundle;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.livescoremach.livecricket.showscore.Ads_Common.AdsBaseActivity;
import com.livescoremach.livecricket.showscore.R;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class ScheduleActivity extends AdsBaseActivity {

    TextView tvUpcoming, tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);


        tvUpcoming = findViewById(R.id.tvUpcoming);
        tvResult = findViewById(R.id.tvResult);
        findViewById(R.id.ivBack).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });

        tvUpcoming.setTextColor(getColor(R.color.white));
        tvUpcoming.setBackground(getDrawable(R.drawable.ic_blue_gradiant_bg));
        tvResult.setTextColor(getColor(R.color.black));
        tvResult.setBackgroundColor(getColor(R.color.white));
        loadFragment(new UpcomingFragment());

        tvUpcoming.setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    tvUpcoming.setTextColor(getColor(R.color.white));
                    tvUpcoming.setBackground(getDrawable(R.drawable.ic_blue_gradiant_bg));
                    tvResult.setTextColor(getColor(R.color.black));
                    tvResult.setBackgroundColor(getColor(R.color.white));
                    loadFragment(new UpcomingFragment());
                }
            }, MAIN_CLICK);
        });
        tvResult.setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    tvUpcoming.setTextColor(getColor(R.color.black));
                    tvUpcoming.setBackgroundColor(getColor(R.color.white));
                    tvResult.setTextColor(getColor(R.color.white));
                    tvResult.setBackground(getDrawable(R.drawable.ic_blue_gradiant_bg));
                    loadFragment(new ResultFragment());
                }
            }, MAIN_CLICK);
        });
    }

    private void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.flSchedule, fragment);
        transaction.commit();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
