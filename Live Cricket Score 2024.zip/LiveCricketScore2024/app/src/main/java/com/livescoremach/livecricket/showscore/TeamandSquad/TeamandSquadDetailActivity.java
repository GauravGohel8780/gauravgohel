package com.livescoremach.livecricket.showscore.TeamandSquad;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.livescoremach.livecricket.showscore.Ads_Common.AdsBaseActivity;
import com.livescoremach.livecricket.showscore.R;
import com.livescoremach.livecricket.showscore.utils.ApiService;
import com.livescoremach.livecricket.showscore.utils.RetrofitClient;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TeamandSquadDetailActivity extends AdsBaseActivity {

    RecyclerView rvTeamandSquadditail;
    ArrayList<TeamandSquadDetailModel> arrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teamand_squad_detail);


        findViewById(R.id.ivBack).setOnClickListener(v -> {
            getInstance(TeamandSquadDetailActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });

        String TeamandSquadname = getIntent().getStringExtra("TeamandSquadname");
        ((TextView) findViewById(R.id.tvTeamname)).setText(TeamandSquadname);


        ApiService apiService = RetrofitClient.getApiService();
        Call<TeamAndSquadAipRespons> call = apiService.getTeamAndSquadData("team&sqaud");
        call.enqueue(new Callback<TeamAndSquadAipRespons>() {
            @Override
            public void onResponse(Call<TeamAndSquadAipRespons> call, Response<TeamAndSquadAipRespons> response) {
                if (response.isSuccessful()) {
                    findViewById(R.id.mainProgress).setVisibility(View.GONE);
                    TeamAndSquadAipRespons responseData = response.body();
                    ArrayList<TeamandSquadModel> teamList = responseData.getData();
                    arrayList = teamList.get(0).getArrTeamePlayer();
                    for (TeamandSquadModel item : teamList) {
                        if (item.getvTeameName().equals(TeamandSquadname)) {
                            rvTeamandSquadditail = findViewById(R.id.rvTeamandSquadditail);
                            TeamandSquadDetailAdapter adapter = new TeamandSquadDetailAdapter(arrayList);
                            rvTeamandSquadditail.setLayoutManager(new LinearLayoutManager(TeamandSquadDetailActivity.this));
                            rvTeamandSquadditail.setAdapter(adapter);
                        }
                    }


                    Log.w("--apiResponse--", "" + new GsonBuilder().setPrettyPrinting().create().toJson(arrayList));

                } else {
                    try {
                        Log.e("--apiResponse--", "Error: PlanDetailResponse " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(Call<TeamAndSquadAipRespons> call, Throwable t) {
                Log.e("--apiResponse--", "Error:" + t.getMessage());
            }
        });
    }


    public class TeamandSquadDetailAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private ArrayList<TeamandSquadDetailModel> items;

        public TeamandSquadDetailAdapter(ArrayList<TeamandSquadDetailModel> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.teamandsquaddetaillayout, parent, false);
            return new ViewHolder(view);

        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

            TeamandSquadDetailModel item = (TeamandSquadDetailModel) items.get(position);

            Glide.with(TeamandSquadDetailActivity.this).load(item.getvImage()).into(((ViewHolder) holder).ivCricketerimg);

            ((ViewHolder) holder).tvCricketerName.setText(item.getvName());
            ((ViewHolder) holder).tvCricketerRole.setText(item.getvRole());
            ((ViewHolder) holder).tvCricketerPrice.setText(getResources().getString(R.string.price) + " : " + item.getvPrice());

            ((ViewHolder) holder).itemView.setOnClickListener(v -> {
                getInstance(TeamandSquadDetailActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(TeamandSquadDetailActivity.this, PlayerDetailsActivity.class);
                        intent.putExtra("teamPlayerName",item.getvName());
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            });

        }


        @Override
        public int getItemCount() {
            return items.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            TextView tvCricketerName, tvCricketerRole, tvCricketerPrice;
            ImageView ivCricketerimg;


            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                ivCricketerimg = itemView.findViewById(R.id.ivCricketerimg);
                tvCricketerName = itemView.findViewById(R.id.tvCricketerName);
                tvCricketerRole = itemView.findViewById(R.id.tvCricketerRole);
                tvCricketerPrice = itemView.findViewById(R.id.tvCricketerPrice);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}