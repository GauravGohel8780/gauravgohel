package com.livescoremach.livecricket.showscore.TeamandSquad;

import com.livescoremach.livecricket.showscore.TeamandSquad.BattingPlayer.BattingPlayerModel;
import com.livescoremach.livecricket.showscore.TeamandSquad.BowlingPlayer.BowlingPlayerModel;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class TeamandSquadDetailModel {

    @SerializedName("vName")
    @Expose
    private String vName;
    @SerializedName("vRole")
    @Expose
    private String vRole;
    @SerializedName("vImage")
    @Expose
    private String vImage;
    @SerializedName("vPrice")
    @Expose
    private String vPrice;
    @SerializedName("dtDob")
    @Expose
    private String dtDob;
    @SerializedName("vBattingStyle")
    @Expose
    private String vBattingStyle;
    @SerializedName("vBowlingStyle")
    @Expose
    private String vBowlingStyle;
    @SerializedName("arrBatting")
    @Expose
    private ArrayList<BattingPlayerModel> arrBatting;
    @SerializedName("arrBowling")
    @Expose
    private ArrayList<BowlingPlayerModel> arrBowling;

    public String getvName() {
        return vName;
    }

    public void setvName(String vName) {
        this.vName = vName;
    }

    public String getvRole() {
        return vRole;
    }

    public void setvRole(String vRole) {
        this.vRole = vRole;
    }

    public String getvImage() {
        return vImage;
    }

    public void setvImage(String vImage) {
        this.vImage = vImage;
    }

    public String getvPrice() {
        return vPrice;
    }

    public void setvPrice(String vPrice) {
        this.vPrice = vPrice;
    }

    public String getDtDob() {
        return dtDob;
    }

    public void setDtDob(String dtDob) {
        this.dtDob = dtDob;
    }

    public String getvBattingStyle() {
        return vBattingStyle;
    }

    public void setvBattingStyle(String vBattingStyle) {
        this.vBattingStyle = vBattingStyle;
    }

    public String getvBowlingStyle() {
        return vBowlingStyle;
    }

    public void setvBowlingStyle(String vBowlingStyle) {
        this.vBowlingStyle = vBowlingStyle;
    }

    public ArrayList<BattingPlayerModel> getArrBatting() {
        return arrBatting;
    }

    public void setArrBatting(ArrayList<BattingPlayerModel> arrBatting) {
        this.arrBatting = arrBatting;
    }

    public ArrayList<BowlingPlayerModel> getArrBowling() {
        return arrBowling;
    }

    public void setArrBowling(ArrayList<BowlingPlayerModel> arrBowling) {
        this.arrBowling = arrBowling;
    }

}
