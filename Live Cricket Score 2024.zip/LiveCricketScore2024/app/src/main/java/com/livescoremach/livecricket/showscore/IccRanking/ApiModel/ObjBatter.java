package com.livescoremach.livecricket.showscore.IccRanking.ApiModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class ObjBatter {

@SerializedName("arrOdi")
@Expose
private ArrayList<AllModel> arrOdi;
@SerializedName("arrT20")
@Expose
private ArrayList<AllModel> arrT20;
@SerializedName("arrTest")
@Expose
private ArrayList<AllModel> arrTest;

public ArrayList<AllModel> getArrOdi() {
return arrOdi;
}

public void setArrOdi(ArrayList<AllModel> arrOdi) {
this.arrOdi = arrOdi;
}

public ArrayList<AllModel> getArrT20() {
return arrT20;
}

public void setArrT20(ArrayList<AllModel> arrT20) {
this.arrT20 = arrT20;
}

public ArrayList<AllModel> getArrTest() {
return arrTest;
}

public void setArrTest(ArrayList<AllModel> arrTest) {
this.arrTest = arrTest;
}

}