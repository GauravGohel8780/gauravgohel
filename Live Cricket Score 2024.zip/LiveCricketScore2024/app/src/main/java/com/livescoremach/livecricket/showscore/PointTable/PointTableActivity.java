package com.livescoremach.livecricket.showscore.PointTable;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.livescoremach.livecricket.showscore.Ads_Common.AdsBaseActivity;
import com.livescoremach.livecricket.showscore.R;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.util.ArrayList;

public class PointTableActivity extends AdsBaseActivity {

    RecyclerView rvPointTable;
    ArrayList<PointTableModel> arrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_point_table);

        findViewById(R.id.ivBack).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });

        arrayList.add(new PointTableModel(R.drawable.ic_flag_afghanistan, "AFG", 0,0,0,0,0,5));
        arrayList.add(new PointTableModel(R.drawable.ic_flag_australia, "AUS", 0,0,0,0,0,2));
        arrayList.add(new PointTableModel(R.drawable.ic_flag_bangladesh, "BGD", 0,0,0,0,0,3));
        arrayList.add(new PointTableModel(R.drawable.ic_flag_england, "ELD", 0,0,0,0,0,5));
        arrayList.add(new PointTableModel(R.drawable.ic_flag_india, "IND", 0,0,0,0,0,3));
        arrayList.add(new PointTableModel(R.drawable.ic_flag_nepal, "NPL", 0,0,0,0,0,2));
        arrayList.add(new PointTableModel(R.drawable.ic_flag_netherlands, "NLD", 0,0,0,0,0,1));
        arrayList.add(new PointTableModel(R.drawable.ic_flag_southafrica, "ZAF", 0,0,0,0,0,5));
        arrayList.add(new PointTableModel(R.drawable.ic_flag_srilanka, "LKA", 0,0,0,0,0,4));
        arrayList.add(new PointTableModel(R.drawable.ic_flag_pakistan, "PAK", 0,0,0,0,0,3));

        rvPointTable = findViewById(R.id.rvPointTable);
        PointTableAdapter adapter = new PointTableAdapter(arrayList);
        rvPointTable.setLayoutManager(new LinearLayoutManager(this));
        rvPointTable.setAdapter(adapter);
    }

    public class PointTableAdapter extends RecyclerView.Adapter<PointTableAdapter.ViewHolder> {
        private ArrayList<PointTableModel> items;

        public PointTableAdapter(ArrayList<PointTableModel> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.pointtable_layout, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            PointTableModel item = items.get(position);
            holder.tvTeamname.setText(item.getTeamname());
            holder.tvM.setText(""+item.getM());
            holder.tvW.setText(""+item.getW());
            holder.tvL.setText(""+item.getL());
            holder.tvNRR.setText(""+item.getNrr());
            holder.tvPTS.setText(""+item.getPts());
            holder.ivTeamimg.setImageResource(item.getTeamimg());


            Integer img = R.drawable.ic_last5_dot;
            int NUMBER_OF_IMAGES = item.getLast5dot();
            int marginInPixels = 3;

            for (int i = 0; i < NUMBER_OF_IMAGES; i++) {
                ImageView iView = new ImageView(PointTableActivity.this);
                iView.setImageResource(img);
                ConstraintLayout.LayoutParams layoutParams = new ConstraintLayout.LayoutParams(
                        ConstraintLayout.LayoutParams.WRAP_CONTENT,
                        ConstraintLayout.LayoutParams.WRAP_CONTENT
                );
                layoutParams.setMargins(marginInPixels, marginInPixels, marginInPixels, marginInPixels);
                iView.setLayoutParams(layoutParams);
                holder.lldot.addView(iView);
            }


        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            TextView tvTeamname, tvM, tvW, tvL, tvNRR, tvPTS;
            ImageView ivTeamimg;
            LinearLayout lldot;


            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvTeamname = itemView.findViewById(R.id.tvTeamname);
                tvM = itemView.findViewById(R.id.tvM);
                tvW = itemView.findViewById(R.id.tvW);
                tvL = itemView.findViewById(R.id.tvL);
                tvNRR = itemView.findViewById(R.id.tvNRR);
                tvPTS = itemView.findViewById(R.id.tvPTS);
                ivTeamimg = itemView.findViewById(R.id.ivTeamimg);
                lldot = itemView.findViewById(R.id.lldot);
            }
        };
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}