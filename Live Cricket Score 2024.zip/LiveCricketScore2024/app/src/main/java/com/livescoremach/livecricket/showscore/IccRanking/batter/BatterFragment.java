package com.livescoremach.livecricket.showscore.IccRanking.batter;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.livescoremach.livecricket.showscore.IccRanking.AllAdapter;
import com.livescoremach.livecricket.showscore.IccRanking.ApiModel.AllModel;
import com.livescoremach.livecricket.showscore.IccRanking.ApiModel.IccRankingApiResponse;
import com.livescoremach.livecricket.showscore.IccRanking.ApiModel.ObjMain;
import com.livescoremach.livecricket.showscore.R;
import com.livescoremach.livecricket.showscore.utils.ApiService;
import com.livescoremach.livecricket.showscore.utils.RetrofitClient;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BatterFragment extends Fragment {

    TextView tvOdi, tvT20, tvTest;
    RecyclerView rvBatter;
    ArrayList<AllModel> arrayList = new ArrayList<>();
    AllAdapter adapter;
    String intentIccRenking;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_batter, container, false);

        intentIccRenking = getActivity().getIntent().getStringExtra("IccRanking");

        tvOdi = view.findViewById(R.id.tvOdi);
        tvT20 = view.findViewById(R.id.tvT20);
        tvTest = view.findViewById(R.id.tvTest);
        rvBatter = view.findViewById(R.id.rvBatter);

        if (intentIccRenking.equals("men")) {
            tvTest.setVisibility(View.VISIBLE);
        } else if (intentIccRenking.equals("women")) {
            tvTest.setVisibility(View.GONE);
        }

        ApiService apiService = RetrofitClient.getApiService();
        Call<IccRankingApiResponse> call = apiService.getIccRankingData(intentIccRenking);
        call.enqueue(new Callback<IccRankingApiResponse>() {
            @Override
            public void onResponse(Call<IccRankingApiResponse> call, Response<IccRankingApiResponse> response) {
                if (response.isSuccessful()) {
                    view.findViewById(R.id.mainProgress).setVisibility(View.GONE);
                    IccRankingApiResponse responseData = response.body();
                    ArrayList<ObjMain> teamList = responseData.getData();

                    tvOdi.setTextColor(requireActivity().getColor(R.color.white));
                    tvOdi.setBackground(requireActivity().getDrawable(R.drawable.ic_blue_gradiant_bg));
                    tvT20.setTextColor(requireActivity().getColor(R.color.black));
                    tvT20.setBackgroundColor(requireActivity().getColor(R.color.white));
                    tvTest.setTextColor(requireActivity().getColor(R.color.black));
                    tvTest.setBackgroundColor(requireActivity().getColor(R.color.white));
                    arrayList = teamList.get(0).getObjPlayer().getObjBatter().getArrOdi();
                    onResume();

                    tvOdi.setOnClickListener(v -> {
                        getInstance(getActivity()).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                tvOdi.setTextColor(requireActivity().getColor(R.color.white));
                                tvOdi.setBackground(requireActivity().getDrawable(R.drawable.ic_blue_gradiant_bg));
                                tvT20.setTextColor(requireActivity().getColor(R.color.black));
                                tvT20.setBackgroundColor(requireActivity().getColor(R.color.white));
                                tvTest.setTextColor(requireActivity().getColor(R.color.black));
                                tvTest.setBackgroundColor(requireActivity().getColor(R.color.white));
                                arrayList = teamList.get(0).getObjPlayer().getObjBatter().getArrOdi();
                                onResume();
                            }
                        }, MAIN_CLICK);
                    });
                    tvT20.setOnClickListener(v -> {
                        getInstance(getActivity()).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                tvT20.setTextColor(requireActivity().getColor(R.color.white));
                                tvT20.setBackground(requireActivity().getDrawable(R.drawable.ic_blue_gradiant_bg));
                                tvOdi.setTextColor(requireActivity().getColor(R.color.black));
                                tvOdi.setBackgroundColor(requireActivity().getColor(R.color.white));
                                tvTest.setTextColor(requireActivity().getColor(R.color.black));
                                tvTest.setBackgroundColor(requireActivity().getColor(R.color.white));
                                arrayList = teamList.get(0).getObjPlayer().getObjBatter().getArrT20();
                                onResume();
                            }
                        }, MAIN_CLICK);
                    });
                    tvTest.setOnClickListener(v -> {
                        getInstance(getActivity()).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                tvTest.setTextColor(requireActivity().getColor(R.color.white));
                                tvTest.setBackground(requireActivity().getDrawable(R.drawable.ic_blue_gradiant_bg));
                                tvT20.setTextColor(requireActivity().getColor(R.color.black));
                                tvT20.setBackgroundColor(requireActivity().getColor(R.color.white));
                                tvOdi.setTextColor(requireActivity().getColor(R.color.black));
                                tvOdi.setBackgroundColor(requireActivity().getColor(R.color.white));
                                arrayList = teamList.get(0).getObjPlayer().getObjBatter().getArrTest();
                                onResume();
                            }
                        }, MAIN_CLICK);
                    });


                } else {
                    try {
                        Log.e("--apiResponse--", "Error: PlanDetailResponse " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(Call<IccRankingApiResponse> call, Throwable t) {
                Log.e("--apiResponse--", "Error:" + t.getMessage());
            }
        });




        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        adapter = new AllAdapter(arrayList, getContext());
        rvBatter.setLayoutManager(new LinearLayoutManager(getContext()));
        rvBatter.setAdapter(adapter);
    }

}