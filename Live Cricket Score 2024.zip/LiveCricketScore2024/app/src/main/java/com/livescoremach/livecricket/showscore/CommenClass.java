package com.livescoremach.livecricket.showscore;

public class CommenClass {

    public static final int GRIDITEM_PER_AD = 5;
}
