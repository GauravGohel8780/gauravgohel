package com.livescoremach.livecricket.showscore;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.MyApplication.sharedPreferencesHelper;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import com.livescoremach.livecricket.showscore.Ads_Common.AdsBaseActivity;
import com.google.gson.Gson;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.networking.AdsResponse;
import com.iten.tenoku.utils.AdUtils;

public class PrivacyPolicyActivity extends AdsBaseActivity {
    AdsResponse appSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy_policy);



        String title = getIntent().getStringExtra("title");
        if (title.equals("toi")) {
            ((TextView) findViewById(R.id.tvtexttital)).setText(getResources().getString(R.string.terms_of_use));
            appSettings = new Gson().fromJson(sharedPreferencesHelper.getResponse(), AdsResponse.class);
            WebView webView = findViewById(R.id.webView);
            webView.loadUrl(appSettings.data.getObjAPPSETTINGS().getVPolicylink());
            webView.getSettings().setJavaScriptEnabled(true);
            webView.setWebViewClient(new WebViewClient());
        } else if (title.equals("pp")) {
            ((TextView) findViewById(R.id.tvtexttital)).setText(getResources().getString(R.string.privacy_policy));
            appSettings = new Gson().fromJson(sharedPreferencesHelper.getResponse(), AdsResponse.class);
            WebView webView = findViewById(R.id.webView);
            webView.loadUrl(appSettings.data.getObjAPPSETTINGS().getVPrivacyPolicy());
            webView.getSettings().setJavaScriptEnabled(true);
            webView.setWebViewClient(new WebViewClient());
        }


        findViewById(R.id.ivBack).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}