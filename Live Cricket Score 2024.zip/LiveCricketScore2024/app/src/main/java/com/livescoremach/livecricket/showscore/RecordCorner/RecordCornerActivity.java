package com.livescoremach.livecricket.showscore.RecordCorner;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Intent;
import android.os.Bundle;

import com.livescoremach.livecricket.showscore.Ads_Common.AdsBaseActivity;
import com.livescoremach.livecricket.showscore.R;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class RecordCornerActivity extends AdsBaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_corner);

        findViewById(R.id.ivBack).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });

        findViewById(R.id.llMostRun).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    Intent intent = new Intent(RecordCornerActivity.this, RecordCornerDetailActivity.class);
                    intent.putExtra("RecordCorner", "MostRun");
                    startActivity(intent);
                }
            }, MAIN_CLICK);
        });
        findViewById(R.id.llMostSixes).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    Intent intent = new Intent(RecordCornerActivity.this, RecordCornerDetailActivity.class);
                    intent.putExtra("RecordCorner", "MostSixes");
                    startActivity(intent);
                }
            }, MAIN_CLICK);
        });
        findViewById(R.id.llHightestScores).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    Intent intent = new Intent(RecordCornerActivity.this, RecordCornerDetailActivity.class);
                    intent.putExtra("RecordCorner", "HightestScores");
                    startActivity(intent);
                }
            }, MAIN_CLICK);
        });
        findViewById(R.id.llBestBattingStrikeRate).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    Intent intent = new Intent(RecordCornerActivity.this, RecordCornerDetailActivity.class);
                    intent.putExtra("RecordCorner", "BestBattingStrikeRate");
                    startActivity(intent);
                }
            }, MAIN_CLICK);
        });
        findViewById(R.id.llMostFifties).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    Intent intent = new Intent(RecordCornerActivity.this, RecordCornerDetailActivity.class);
                    intent.putExtra("RecordCorner", "MostFifties");
                    startActivity(intent);
                }
            }, MAIN_CLICK);
        });
        findViewById(R.id.llBWHNOWickets).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    Intent intent = new Intent(RecordCornerActivity.this, RecordCornerDetailActivity.class);
                    intent.putExtra("RecordCorner", "BWHNOWickets");
                    startActivity(intent);
                }
            }, MAIN_CLICK);
        });
        findViewById(R.id.llTWHIScore).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    Intent intent = new Intent(RecordCornerActivity.this, RecordCornerDetailActivity.class);
                    intent.putExtra("RecordCorner", "TWHIScore");
                    startActivity(intent);
                }
            }, MAIN_CLICK);
        });
        findViewById(R.id.llBWMCenturies).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    Intent intent = new Intent(RecordCornerActivity.this, RecordCornerDetailActivity.class);
                    intent.putExtra("RecordCorner", "BWMCenturies");
                    startActivity(intent);
                }
            }, MAIN_CLICK);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}