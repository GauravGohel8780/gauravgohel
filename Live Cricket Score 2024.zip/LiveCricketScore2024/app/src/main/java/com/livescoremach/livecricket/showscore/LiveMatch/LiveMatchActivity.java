package com.livescoremach.livecricket.showscore.LiveMatch;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.livescoremach.livecricket.showscore.Ads_Common.AdsBaseActivity;
import com.livescoremach.livecricket.showscore.R;
import com.livescoremach.livecricket.showscore.utils.ApiService;
import com.livescoremach.livecricket.showscore.utils.RetrofitClient;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LiveMatchActivity extends AdsBaseActivity {

    RecyclerView rvLiveMatch;
    ArrayList<LiveMatchModel> arrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_match);

        findViewById(R.id.ivBack).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);

        });




        rvLiveMatch = findViewById(R.id.rvLiveMatch);


        ApiService apiService = RetrofitClient.getApiService();
        Call<LiveMatchAipRespons> call = apiService.getLiveMatchDetails();
        call.enqueue(new Callback<LiveMatchAipRespons>() {
            @Override
            public void onResponse(Call<LiveMatchAipRespons> call, Response<LiveMatchAipRespons> response) {
                if (response.isSuccessful()) {
                    LiveMatchAipRespons LiveMatchAipRespons = response.body();

                    findViewById(R.id.mainProgress).setVisibility(View.GONE);
                    arrayList = LiveMatchAipRespons.getData();
                    rvLiveMatch.setLayoutManager(new LinearLayoutManager(LiveMatchActivity.this));
                    LiveMatchAdapter adapter = new LiveMatchAdapter(arrayList);
                    rvLiveMatch.setAdapter(adapter);

                    Log.w("--apiResponse--", "" + new GsonBuilder().setPrettyPrinting().create().toJson(LiveMatchAipRespons));

                } else {
                    try {
                        Log.e("www", "Response not successful. Code: " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(Call<LiveMatchAipRespons> call, Throwable t) {
                Log.e("www", "Failed to fetch schedule details: " + t.getMessage());
            }
        });
    }


    public class LiveMatchAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private ArrayList<LiveMatchModel> items;

        public LiveMatchAdapter(ArrayList<LiveMatchModel> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


            View view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.live_match_layout, parent, false);
            return new ViewHolder(view);


        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            LiveMatchModel item = (LiveMatchModel) items.get(position);
            ((ViewHolder) holder).tvTitleMatch.setText("" + item.getTitle());
            ((ViewHolder) holder).tvMatchName1.setText("" + item.getTeamA());
            ((ViewHolder) holder).tvScore1.setText("" + item.getWicketA());
            ((ViewHolder) holder).tvMatchName2.setText("" + item.getTeamB());
            ((ViewHolder) holder).tvScore2.setText("" + item.getWicketB());
            ((ViewHolder) holder).tvMatchDatetime.setText("" + item.getMatchtime());
            ((ViewHolder) holder).tvScore.setText("" + item.getScore());

            Glide.with(LiveMatchActivity.this).load(item.getTeamABannerA()).into(((ViewHolder) holder).ivMatchImg1);
            Glide.with(LiveMatchActivity.this).load(item.getTeamABannerB()).into(((ViewHolder) holder).ivMatchImg2);


            String inputString = item.getMatchtime();
            String modifiedString = inputString.replace(" at ", " ").replace("-Wed", "");

            StringBuilder sb = new StringBuilder(modifiedString);
            sb.insert(sb.indexOf("PM") - 2, ' ');

            String formattedString = sb.toString();

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy hh:mm a", Locale.US);
            Date targetDate = null;

            try {
                targetDate = dateFormat.parse(formattedString);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            // Current time
            Calendar currentCalendar = Calendar.getInstance();
            Date currentDate = currentCalendar.getTime();

            // Compare current time with target time
            String displayText;
            if (currentDate.after(targetDate)) {
                // Current time is after target time
                displayText = "Today";
            } else {
                // Current time is before or equal to target time
                displayText = "Live";
            }

            ((ViewHolder) holder).tvLive.setText(displayText);


            holder.itemView.setOnClickListener(v -> {
                getInstance(LiveMatchActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(LiveMatchActivity.this, LiveMatchDetailActivity.class);
                        intent.putExtra("LiveMatchId", item.getMatchId());
                        intent.putExtra("LiveMatchtitle", item.getTitle());
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            });
        }

        @Override
        public int getItemCount() {
            return items.size();
        }


        public class ViewHolder extends RecyclerView.ViewHolder {

            TextView tvTitleMatch, tvMatchName1, tvScore1, tvMatchName2, tvScore2, tvMatchDatetime, tvScore,tvLive;
            ImageView ivMatchImg1, ivMatchImg2;


            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvTitleMatch = itemView.findViewById(R.id.tvTitleMatch);
                ivMatchImg1 = itemView.findViewById(R.id.ivMatchImg1);
                tvMatchName1 = itemView.findViewById(R.id.tvMatchName1);
                tvScore1 = itemView.findViewById(R.id.tvScore1);
                tvMatchName2 = itemView.findViewById(R.id.tvMatchName2);
                tvScore2 = itemView.findViewById(R.id.tvScore2);
                ivMatchImg2 = itemView.findViewById(R.id.ivMatchImg2);
                tvMatchDatetime = itemView.findViewById(R.id.tvMatchDatetime);
                tvScore = itemView.findViewById(R.id.tvScore);
                tvLive = itemView.findViewById(R.id.tvLive);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}