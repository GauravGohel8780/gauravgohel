package com.livescoremach.livecricket.showscore.Auction;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.livescoremach.livecricket.showscore.Auction.ActionModel.AuctionDitailModel;
import com.livescoremach.livecricket.showscore.R;

import java.util.ArrayList;

public class AuctionDitailAdapter extends RecyclerView.Adapter<AuctionDitailAdapter.ViewHolder> {

    private ArrayList<AuctionDitailModel> items;
    private Context context;

    public AuctionDitailAdapter(ArrayList<AuctionDitailModel> items, Context context) {
        this.items = items;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.auctionlist_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AuctionDitailModel item = items.get(position);

        holder.tvPlayerName.setText("" + item.getvPlayerName());
        holder.tvBasePrice.setText(context.getString(R.string.baseprice) + " : " + item.getvBasePrice());
        if (item.getvSellPrice().isEmpty()) {
            holder.tvSellingPrice.setText(context.getString(R.string.sellingprice) + " : " + "--");
        } else {
            holder.tvSellingPrice.setText(context.getString(R.string.sellingprice) + " : " + item.getvSellPrice());
        }

        if (item.getvTeam().isEmpty()) {
            holder.tvTeam.setText(context.getString(R.string.team) + " : " + "------");
        } else {
            holder.tvTeam.setText(context.getString(R.string.team) + " : " + item.getvTeam());
        }

    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvPlayerName, tvBasePrice, tvSellingPrice, tvTeam;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvPlayerName = itemView.findViewById(R.id.tvPlayerName);
            tvBasePrice = itemView.findViewById(R.id.tvBasePrice);
            tvSellingPrice = itemView.findViewById(R.id.tvSellingPrice);
            tvTeam = itemView.findViewById(R.id.tvTeam);
        }
    }
}
