package com.livescoremach.livecricket.showscore.IccRanking.ApiModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class ObjTeam {

@SerializedName("arrOdi")
@Expose
private ArrayList<TeamModel> arrOdi;
@SerializedName("arrT20")
@Expose
private ArrayList<TeamModel> arrT20;
@SerializedName("arrTest")
@Expose
private ArrayList<TeamModel> arrTest;

public ArrayList<TeamModel> getArrOdi() {
return arrOdi;
}

public void setArrOdi(ArrayList<TeamModel> arrOdi) {
this.arrOdi = arrOdi;
}

public ArrayList<TeamModel> getArrT20() {
return arrT20;
}

public void setArrT20(ArrayList<TeamModel> arrT20) {
this.arrT20 = arrT20;
}

public ArrayList<TeamModel> getArrTest() {
return arrTest;
}

public void setArrTest(ArrayList<TeamModel> arrTest) {
this.arrTest = arrTest;
}

}