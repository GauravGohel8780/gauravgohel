package com.livescoremach.livecricket.showscore.IccRanking.ApiModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ObjMain {

@SerializedName("objTeam")
@Expose
private ObjTeam objTeam;
@SerializedName("objPlayer")
@Expose
private ObjPlayer objPlayer;

public ObjTeam getObjTeam() {
return objTeam;
}

public void setObjTeam(ObjTeam objTeam) {
this.objTeam = objTeam;
}

public ObjPlayer getObjPlayer() {
return objPlayer;
}

public void setObjPlayer(ObjPlayer objPlayer) {
this.objPlayer = objPlayer;
}

}