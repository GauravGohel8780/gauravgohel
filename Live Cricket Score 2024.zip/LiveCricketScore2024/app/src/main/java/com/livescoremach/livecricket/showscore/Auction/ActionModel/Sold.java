package com.livescoremach.livecricket.showscore.Auction.ActionModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class Sold {

@SerializedName("batsmens")
@Expose
private ArrayList<AuctionDitailModel> batsmens;
@SerializedName("bowlers")
@Expose
private ArrayList<AuctionDitailModel> bowlers;
@SerializedName("wicketkeepers")
@Expose
private ArrayList<AuctionDitailModel> wicketkeepers;
@SerializedName("allrounders")
@Expose
private ArrayList<AuctionDitailModel> allrounders;

public ArrayList<AuctionDitailModel> getBatsmens() {
return batsmens;
}

public void setBatsmens(ArrayList<AuctionDitailModel> batsmens) {
this.batsmens = batsmens;
}

public ArrayList<AuctionDitailModel> getBowlers() {
return bowlers;
}

public void setBowlers(ArrayList<AuctionDitailModel> bowlers) {
this.bowlers = bowlers;
}

public ArrayList<AuctionDitailModel> getWicketkeepers() {
return wicketkeepers;
}

public void setWicketkeepers(ArrayList<AuctionDitailModel> wicketkeepers) {
this.wicketkeepers = wicketkeepers;
}

public ArrayList<AuctionDitailModel> getAllrounders() {
return allrounders;
}

public void setAllrounders(ArrayList<AuctionDitailModel> allrounders) {
this.allrounders = allrounders;
}

}