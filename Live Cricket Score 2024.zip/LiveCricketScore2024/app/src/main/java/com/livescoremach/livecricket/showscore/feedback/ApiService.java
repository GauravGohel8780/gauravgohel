package com.livescoremach.livecricket.showscore.feedback;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ApiService {

    @POST("api/v1/feedBack/save")
    Call<FeedBackResponseModel> feedbackUser(@Body FeedbackRequestModel request);
}