package com.livescoremach.livecricket.showscore.RecordCorner;

public class RecordCornerDetailModel {

    private int pos;
    private String PlayerName;
    private float score;

    public RecordCornerDetailModel(int pos, String playerName, float score) {
        this.pos = pos;
        PlayerName = playerName;
        this.score = score;
    }

    public int getPos() {
        return pos;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }

    public String getPlayerName() {
        return PlayerName;
    }

    public void setPlayerName(String playerName) {
        PlayerName = playerName;
    }

    public float getScore() {
        return score;
    }

    public void setScore(float score) {
        this.score = score;
    }
}
