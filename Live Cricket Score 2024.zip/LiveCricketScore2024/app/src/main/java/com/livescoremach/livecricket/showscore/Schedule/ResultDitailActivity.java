package com.livescoremach.livecricket.showscore.Schedule;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.os.Bundle;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.livescoremach.livecricket.showscore.Ads_Common.AdsBaseActivity;
import com.livescoremach.livecricket.showscore.LiveMatch.ScoreCard.ScoreCradFragment;
import com.livescoremach.livecricket.showscore.R;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class ResultDitailActivity extends AdsBaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_ditail);
        String LiveMatchtitle = getIntent().getStringExtra("LiveMatchtitle");
        ((TextView)findViewById(R.id.tvTitle)).setText(LiveMatchtitle);
        ((TextView)findViewById(R.id.tvTitle)).setSelected(true);

        findViewById(R.id.ivBack).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });

        loadFragment(new ScoreCradFragment());
    }
    private void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.flResult, fragment);
        transaction.commit();
    }
    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}