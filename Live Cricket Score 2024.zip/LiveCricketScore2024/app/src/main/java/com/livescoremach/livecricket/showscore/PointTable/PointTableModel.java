package com.livescoremach.livecricket.showscore.PointTable;

public class PointTableModel {

    private int Teamimg;
    private String Teamname;
    private int m;
    private int w;
    private int l;
    private int nrr;
    private int pts;
    private int last5dot;

    public PointTableModel(int teamimg, String teamname, int m, int w, int l, int nrr, int pts, int last5dot) {
        Teamimg = teamimg;
        Teamname = teamname;
        this.m = m;
        this.w = w;
        this.l = l;
        this.nrr = nrr;
        this.pts = pts;
        this.last5dot = last5dot;
    }

    public int getTeamimg() {
        return Teamimg;
    }

    public void setTeamimg(int teamimg) {
        Teamimg = teamimg;
    }

    public String getTeamname() {
        return Teamname;
    }

    public void setTeamname(String teamname) {
        Teamname = teamname;
    }

    public int getM() {
        return m;
    }

    public void setM(int m) {
        this.m = m;
    }

    public int getW() {
        return w;
    }

    public void setW(int w) {
        this.w = w;
    }

    public int getL() {
        return l;
    }

    public void setL(int l) {
        this.l = l;
    }

    public int getNrr() {
        return nrr;
    }

    public void setNrr(int nrr) {
        this.nrr = nrr;
    }

    public int getPts() {
        return pts;
    }

    public void setPts(int pts) {
        this.pts = pts;
    }

    public int getLast5dot() {
        return last5dot;
    }

    public void setLast5dot(int last5dot) {
        this.last5dot = last5dot;
    }
}
