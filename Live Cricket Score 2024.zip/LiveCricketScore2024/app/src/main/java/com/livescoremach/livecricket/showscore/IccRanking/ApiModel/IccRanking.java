package com.livescoremach.livecricket.showscore.IccRanking.ApiModel;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class IccRanking {

@SerializedName("objMain")
@Expose
private ObjMain objMain;

public ObjMain getObjMain() {
return objMain;
}

public void setObjMain(ObjMain objMain) {
this.objMain = objMain;
}

}