package com.livescoremach.livecricket.showscore.Winner;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class WinnerModel {
    @SerializedName("vWinTeamImage")
    @Expose
    private String vWinTeamImage;
    @SerializedName("vYear")
    @Expose
    private String vYear;
    @SerializedName("vWinTeamName")
    @Expose
    private String vWinTeamName;
    @SerializedName("vRunnerupTeam")
    @Expose
    private String vRunnerupTeam;
    @SerializedName("vOrangeCap")
    @Expose
    private String vOrangeCap;
    @SerializedName("vPurpleCap")
    @Expose
    private String vPurpleCap;
    @SerializedName("vManofTheMatch")
    @Expose
    private String vManofTheMatch;
    @SerializedName("vVenue")
    @Expose
    private String vVenue;
    @SerializedName("vMatchDate")
    @Expose
    private String vMatchDate;
    @SerializedName("vPlayerOfTournament")
    @Expose
    private String vPlayerOfTournament;
    @SerializedName("vDetails")
    @Expose
    private String vDetails;

    public String getvWinTeamImage() {
        return vWinTeamImage;
    }

    public void setvWinTeamImage(String vWinTeamImage) {
        this.vWinTeamImage = vWinTeamImage;
    }

    public String getvYear() {
        return vYear;
    }

    public void setvYear(String vYear) {
        this.vYear = vYear;
    }

    public String getvWinTeamName() {
        return vWinTeamName;
    }

    public void setvWinTeamName(String vWinTeamName) {
        this.vWinTeamName = vWinTeamName;
    }

    public String getvRunnerupTeam() {
        return vRunnerupTeam;
    }

    public void setvRunnerupTeam(String vRunnerupTeam) {
        this.vRunnerupTeam = vRunnerupTeam;
    }

    public String getvOrangeCap() {
        return vOrangeCap;
    }

    public void setvOrangeCap(String vOrangeCap) {
        this.vOrangeCap = vOrangeCap;
    }

    public String getvPurpleCap() {
        return vPurpleCap;
    }

    public void setvPurpleCap(String vPurpleCap) {
        this.vPurpleCap = vPurpleCap;
    }

    public String getvManofTheMatch() {
        return vManofTheMatch;
    }

    public void setvManofTheMatch(String vManofTheMatch) {
        this.vManofTheMatch = vManofTheMatch;
    }

    public String getvVenue() {
        return vVenue;
    }

    public void setvVenue(String vVenue) {
        this.vVenue = vVenue;
    }

    public String getvMatchDate() {
        return vMatchDate;
    }

    public void setvMatchDate(String vMatchDate) {
        this.vMatchDate = vMatchDate;
    }

    public String getvPlayerOfTournament() {
        return vPlayerOfTournament;
    }

    public void setvPlayerOfTournament(String vPlayerOfTournament) {
        this.vPlayerOfTournament = vPlayerOfTournament;
    }

    public String getvDetails() {
        return vDetails;
    }

    public void setvDetails(String vDetails) {
        this.vDetails = vDetails;
    }
}

