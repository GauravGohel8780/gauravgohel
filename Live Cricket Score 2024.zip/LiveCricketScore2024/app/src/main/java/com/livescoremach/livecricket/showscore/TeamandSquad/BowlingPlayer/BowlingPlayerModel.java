package com.livescoremach.livecricket.showscore.TeamandSquad.BowlingPlayer;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class BowlingPlayerModel {
    @SerializedName("year")
    @Expose
    private String year;
    @SerializedName("vTotalMatch")
    @Expose
    private String vTotalMatch;
    @SerializedName("vBall")
    @Expose
    private String vBall;
    @SerializedName("vRun")
    @Expose
    private String vRun;
    @SerializedName("vWkts")
    @Expose
    private String vWkts;
    @SerializedName("vBbm")
    @Expose
    private String vBbm;
    @SerializedName("vAve")
    @Expose
    private String vAve;
    @SerializedName("vEcon")
    @Expose
    private String vEcon;
    @SerializedName("vSr")
    @Expose
    private String vSr;
    @SerializedName("v4w")
    @Expose
    private String v4w;
    @SerializedName("v5w")
    @Expose
    private String v5w;

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getvTotalMatch() {
        return vTotalMatch;
    }

    public void setvTotalMatch(String vTotalMatch) {
        this.vTotalMatch = vTotalMatch;
    }

    public String getvBall() {
        return vBall;
    }

    public void setvBall(String vBall) {
        this.vBall = vBall;
    }

    public String getvRun() {
        return vRun;
    }

    public void setvRun(String vRun) {
        this.vRun = vRun;
    }

    public String getvWkts() {
        return vWkts;
    }

    public void setvWkts(String vWkts) {
        this.vWkts = vWkts;
    }

    public String getvBbm() {
        return vBbm;
    }

    public void setvBbm(String vBbm) {
        this.vBbm = vBbm;
    }

    public String getvAve() {
        return vAve;
    }

    public void setvAve(String vAve) {
        this.vAve = vAve;
    }

    public String getvEcon() {
        return vEcon;
    }

    public void setvEcon(String vEcon) {
        this.vEcon = vEcon;
    }

    public String getvSr() {
        return vSr;
    }

    public void setvSr(String vSr) {
        this.vSr = vSr;
    }

    public String getV4w() {
        return v4w;
    }

    public void setV4w(String v4w) {
        this.v4w = v4w;
    }

    public String getV5w() {
        return v5w;
    }

    public void setV5w(String v5w) {
        this.v5w = v5w;
    }
}