package com.livescoremach.livecricket.showscore.TeamandSquad.BattingPlayer;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class BattingPlayerModel {

    @SerializedName("year")
    @Expose
    private String year;
    @SerializedName("vTotalMatch")
    @Expose
    private String vTotalMatch;
    @SerializedName("vNotOut")
    @Expose
    private String vNotOut;
    @SerializedName("vRun")
    @Expose
    private String vRun;
    @SerializedName("vAve")
    @Expose
    private String vAve;
    @SerializedName("vHs")
    @Expose
    private String vHs;
    @SerializedName("vSt")
    @Expose
    private String vSt;
    @SerializedName("vBallFaced")
    @Expose
    private String vBallFaced;
    @SerializedName("vSr")
    @Expose
    private String vSr;
    @SerializedName("v10")
    @Expose
    private String v10;
    @SerializedName("v50")
    @Expose
    private String v50;
    @SerializedName("v4s")
    @Expose
    private String v4s;
    @SerializedName("v6s")
    @Expose
    private String v6s;
    @SerializedName("vCt")
    @Expose
    private String vCt;
    @SerializedName("v100")
    @Expose
    private String v100;

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getvTotalMatch() {
        return vTotalMatch;
    }

    public void setvTotalMatch(String vTotalMatch) {
        this.vTotalMatch = vTotalMatch;
    }

    public String getvNotOut() {
        return vNotOut;
    }

    public void setvNotOut(String vNotOut) {
        this.vNotOut = vNotOut;
    }

    public String getvRun() {
        return vRun;
    }

    public void setvRun(String vRun) {
        this.vRun = vRun;
    }

    public String getvAve() {
        return vAve;
    }

    public void setvAve(String vAve) {
        this.vAve = vAve;
    }

    public String getvHs() {
        return vHs;
    }

    public void setvHs(String vHs) {
        this.vHs = vHs;
    }

    public String getvSt() {
        return vSt;
    }

    public void setvSt(String vSt) {
        this.vSt = vSt;
    }

    public String getvBallFaced() {
        return vBallFaced;
    }

    public void setvBallFaced(String vBallFaced) {
        this.vBallFaced = vBallFaced;
    }

    public String getvSr() {
        return vSr;
    }

    public void setvSr(String vSr) {
        this.vSr = vSr;
    }

    public String getV10() {
        return v10;
    }

    public void setV10(String v10) {
        this.v10 = v10;
    }

    public String getV50() {
        return v50;
    }

    public void setV50(String v50) {
        this.v50 = v50;
    }

    public String getV4s() {
        return v4s;
    }

    public void setV4s(String v4s) {
        this.v4s = v4s;
    }

    public String getV6s() {
        return v6s;
    }

    public void setV6s(String v6s) {
        this.v6s = v6s;
    }

    public String getvCt() {
        return vCt;
    }

    public void setvCt(String vCt) {
        this.vCt = vCt;
    }

    public String getV100() {
        return v100;
    }

    public void setV100(String v100) {
        this.v100 = v100;
    }

}
