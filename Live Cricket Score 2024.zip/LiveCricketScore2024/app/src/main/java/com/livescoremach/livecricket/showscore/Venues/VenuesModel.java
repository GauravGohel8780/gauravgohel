package com.livescoremach.livecricket.showscore.Venues;

public class VenuesModel {

    private String VenuesName;
    private String City;
    private String State;
    private String Opened;
    private String Capacity;

    public VenuesModel(String venuesName, String city, String state, String opened, String capacity) {
        VenuesName = venuesName;
        City = city;
        State = state;
        Opened = opened;
        Capacity = capacity;
    }

    public String getVenuesName() {
        return VenuesName;
    }

    public void setVenuesName(String venuesName) {
        VenuesName = venuesName;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public String getState() {
        return State;
    }

    public void setState(String state) {
        State = state;
    }

    public String getOpened() {
        return Opened;
    }

    public void setOpened(String opened) {
        Opened = opened;
    }

    public String getCapacity() {
        return Capacity;
    }

    public void setCapacity(String capacity) {
        Capacity = capacity;
    }
}
