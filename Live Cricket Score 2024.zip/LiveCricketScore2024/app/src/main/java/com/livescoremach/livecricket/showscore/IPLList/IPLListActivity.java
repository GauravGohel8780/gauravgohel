package com.livescoremach.livecricket.showscore.IPLList;


import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.livescoremach.livecricket.showscore.Ads_Common.AdsBaseActivity;
import com.livescoremach.livecricket.showscore.R;
import com.livescoremach.livecricket.showscore.utils.ApiService;
import com.livescoremach.livecricket.showscore.utils.RetrofitClient;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class IPLListActivity extends AdsBaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ipllist);

        findViewById(R.id.ivBack).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });

        ApiService apiService = RetrofitClient.getApiService();
        Call<IplListAipRespons> call = apiService.getIplListData("ipl");
        call.enqueue(new Callback<IplListAipRespons>() {
            @Override
            public void onResponse(Call<IplListAipRespons> call, Response<IplListAipRespons> response) {
                if (response.isSuccessful()) {
                    findViewById(R.id.mainProgress).setVisibility(View.GONE);
                    IplListAipRespons responseData = response.body();
                    ArrayList<IPLListModel> teamList = responseData.getData();
                    IPLListAdapter adapter = new IPLListAdapter(teamList);
                    ((RecyclerView) findViewById(R.id.rvIplList)).setLayoutManager(new LinearLayoutManager(IPLListActivity.this));
                    ((RecyclerView) findViewById(R.id.rvIplList)).setAdapter(adapter);

                    Log.w("--apiResponse--", "" + new GsonBuilder().setPrettyPrinting().create().toJson(teamList));
                } else {
                    try {
                        Log.e("--apiResponse--", "Error: PlanDetailResponse " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(Call<IplListAipRespons> call, Throwable t) {
                Log.e("--apiResponse--", "Error:" + t.getMessage());
            }
        });

    }


    public class IPLListAdapter extends RecyclerView.Adapter<IPLListAdapter.ViewHolder> {
        private ArrayList<IPLListModel> items;

        public IPLListAdapter(ArrayList<IPLListModel> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.ipllist_layout, parent, false);
            return new ViewHolder(view);
        }


        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            IPLListModel item = items.get(position);

            holder.tvYear.setText("" + item.getvYear());

            holder.itemView.setOnClickListener(v -> {
                getInstance(IPLListActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        startActivity(new Intent(IPLListActivity.this, IPLListDitailActivity.class).putExtra("iplHistoryYear", item.getvYear()));
                    }
                }, MAIN_CLICK);

            });

        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            TextView tvYear;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                tvYear = itemView.findViewById(R.id.tvYear);

            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}