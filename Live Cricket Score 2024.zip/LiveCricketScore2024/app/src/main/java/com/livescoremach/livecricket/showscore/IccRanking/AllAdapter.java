package com.livescoremach.livecricket.showscore.IccRanking;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.livescoremach.livecricket.showscore.IccRanking.ApiModel.AllModel;
import com.livescoremach.livecricket.showscore.R;

import java.util.ArrayList;


public class AllAdapter extends RecyclerView.Adapter<AllAdapter.ViewHolder> {

    private ArrayList<AllModel> items;
    private Context context;

    public AllAdapter(ArrayList<AllModel> items, Context context) {
        this.items = items;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.iccranking_all_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AllModel item = items.get(position);

        holder.tvRank.setText("" + item.getvRank());
        holder.tvPlayerName.setText("" + item.getvPlayer());
//        holder.tvPlayerCity.setText("(" + item.getTvPlayerCity() + ")");
        holder.tvPlayerRaning.setText("" + item.getvRatings());

//        Glide.with(context).load(item.getIvPlayerimg()).into(holder.ivPlayerimg);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvRank, tvPlayerName, tvPlayerCity, tvPlayerRaning;
        ImageView ivPlayerimg;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvRank = itemView.findViewById(R.id.tvRank);
            tvPlayerName = itemView.findViewById(R.id.tvPlayerName);
            tvPlayerCity = itemView.findViewById(R.id.tvPlayerCity);
            tvPlayerRaning = itemView.findViewById(R.id.tvPlayerRaning);
            ivPlayerimg = itemView.findViewById(R.id.ivPlayerimg);
        }
    }
}
