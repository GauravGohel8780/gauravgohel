package com.livescoremach.livecricket.showscore.IPLList;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.livescoremach.livecricket.showscore.Ads_Common.AdsBaseActivity;
import com.livescoremach.livecricket.showscore.R;
import com.livescoremach.livecricket.showscore.utils.ApiService;
import com.livescoremach.livecricket.showscore.utils.RetrofitClient;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class IPLListDitailActivity extends AdsBaseActivity {

    String iplHistoryYear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ipllist_ditail);

        findViewById(R.id.ivBack).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });

        iplHistoryYear = getIntent().getStringExtra("iplHistoryYear");
        ((TextView)findViewById(R.id.tvYear)).setText(""+iplHistoryYear);

        ApiService apiService = RetrofitClient.getApiService();
        Call<IplListAipRespons> call = apiService.getIplListData("ipl");
        call.enqueue(new Callback<IplListAipRespons>() {
            @Override
            public void onResponse(Call<IplListAipRespons> call, Response<IplListAipRespons> response) {
                if (response.isSuccessful()) {
                    findViewById(R.id.mainProgress).setVisibility(View.GONE);
                    IplListAipRespons responseData = response.body();
                    ArrayList<IPLListModel> teamList = responseData.getData();

                    for (IPLListModel item : teamList) {
                        if (item.getvYear().equals(iplHistoryYear)) {

                            ((TextView)findViewById(R.id.tvWinner)).setText(""+item.getvWinner());
                            ((TextView)findViewById(R.id.tvRunnerUp)).setText(""+item.getvRunnerUp());
                            ((TextView)findViewById(R.id.tvVenue)).setText(""+item.getvVenue());
                            ((TextView)findViewById(R.id.tvWinnerCaptain)).setText(""+item.getvWinnerCaptain());
                            ((TextView)findViewById(R.id.tvManOfTheMatch)).setText(""+item.getvManOfTheMatch());
                            ((TextView)findViewById(R.id.tvPlayerOfTheTournament)).setText(""+item.getvPlayerOfTheTournament());
                            ((TextView)findViewById(R.id.tvOCPlayerName)).setText(""+item.getObjOrangeCap().getvPlayerName());
                            ((TextView)findViewById(R.id.tvOCInnings)).setText(""+item.getObjOrangeCap().getiInnings());
                            ((TextView)findViewById(R.id.tvOCRun)).setText(""+item.getObjOrangeCap().getiRuns());
                            ((TextView)findViewById(R.id.tvOCHighestScore)).setText(""+item.getObjOrangeCap().getiHighestScore());
                            ((TextView)findViewById(R.id.tvOCAverage)).setText(""+item.getObjOrangeCap().getiAverage());
                            ((TextView)findViewById(R.id.tvOCStrikeRate)).setText(""+item.getObjOrangeCap().getiStrikeRate());
                            ((TextView)findViewById(R.id.tvOCFifty)).setText(""+item.getObjOrangeCap().getiFifty());
                            ((TextView)findViewById(R.id.tvOCCenturie)).setText(""+item.getObjOrangeCap().getiCenturies());
                            ((TextView)findViewById(R.id.tvOCFour)).setText(""+item.getObjOrangeCap().getFour());
                            ((TextView)findViewById(R.id.tvOCSixe)).setText(""+item.getObjOrangeCap().getSixes());
                            ((TextView)findViewById(R.id.tvPCPlayerName)).setText(""+item.getObjPurpleCap().getvPlayerName());
                            ((TextView)findViewById(R.id.tvPCTeam)).setText(""+item.getObjPurpleCap().getvTeam());
                            ((TextView)findViewById(R.id.tvPCMatches)).setText(""+item.getObjPurpleCap().getiMatches());
                            ((TextView)findViewById(R.id.tvPCWickets)).setText(""+item.getObjPurpleCap().getiWickets());

                            Log.w("--apiResponse--", "" + new GsonBuilder().setPrettyPrinting().create().toJson(item));

                        }
                    }
                } else {
                    try {
                        Log.e("--apiResponse--", "Error: PlanDetailResponse " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(Call<IplListAipRespons> call, Throwable t) {
                Log.e("--apiResponse--", "Error:" + t.getMessage());
            }
        });
    }


    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall1).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}