package com.livescoremach.livecricket.showscore.LiveMatch;

import com.livescoremach.livecricket.showscore.LiveMatch.LiveLine.LiveLineModel;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LiveMatchModel {

    @SerializedName("Title")
    @Expose
    private String title;
    @SerializedName("TeamA")
    @Expose
    private String teamA;
    @SerializedName("TeamB")
    @Expose
    private String teamB;
    @SerializedName("Matchtime")
    @Expose
    private String matchtime;
    @SerializedName("MatchId")
    @Expose
    private Integer matchId;
    @SerializedName("innerData")
    @Expose
    private LiveLineModel innerData;
    @SerializedName("wicketA")
    @Expose
    private String wicketA;
    @SerializedName("wicketB")
    @Expose
    private String wicketB;
    @SerializedName("TeamABannerA")
    @Expose
    private String teamABannerA;
    @SerializedName("TeamABannerB")
    @Expose
    private String teamABannerB;
    @SerializedName("score")
    @Expose
    private String score;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTeamA() {
        return teamA;
    }

    public void setTeamA(String teamA) {
        this.teamA = teamA;
    }

    public String getTeamB() {
        return teamB;
    }

    public void setTeamB(String teamB) {
        this.teamB = teamB;
    }

    public String getMatchtime() {
        return matchtime;
    }

    public void setMatchtime(String matchtime) {
        this.matchtime = matchtime;
    }

    public Integer getMatchId() {
        return matchId;
    }

    public void setMatchId(Integer matchId) {
        this.matchId = matchId;
    }

    public LiveLineModel getInnerData() {
        return innerData;
    }

    public void setInnerData(LiveLineModel innerData) {
        this.innerData = innerData;
    }

    public String getWicketA() {
        return wicketA;
    }

    public void setWicketA(String wicketA) {
        this.wicketA = wicketA;
    }

    public String getWicketB() {
        return wicketB;
    }

    public void setWicketB(String wicketB) {
        this.wicketB = wicketB;
    }

    public String getTeamABannerA() {
        return teamABannerA;
    }

    public void setTeamABannerA(String teamABannerA) {
        this.teamABannerA = teamABannerA;
    }

    public String getTeamABannerB() {
        return teamABannerB;
    }

    public void setTeamABannerB(String teamABannerB) {
        this.teamABannerB = teamABannerB;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

}
