package com.livescoremach.livecricket.showscore.Schedule;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.livescoremach.livecricket.showscore.R;
import com.livescoremach.livecricket.showscore.utils.ApiService;
import com.livescoremach.livecricket.showscore.utils.RetrofitClient;

import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpcomingFragment extends Fragment {

    RecyclerView rvUpcoming;
    ArrayList<UpcomingModel> arrayList = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_upcoming, container, false);


        rvUpcoming = view.findViewById(R.id.rvUpcoming);

        ApiService apiService = RetrofitClient.getApiService();
        Call<UpcomingAipRespons> call = apiService.getScheduleDetails();
        call.enqueue(new Callback<UpcomingAipRespons>() {
            @Override
            public void onResponse(Call<UpcomingAipRespons> call, Response<UpcomingAipRespons> response) {
                if (response.isSuccessful()) {
                    view.findViewById(R.id.mainProgress).setVisibility(View.GONE);
                    UpcomingAipRespons UpcomingAipRespons = response.body();
                    arrayList = UpcomingAipRespons.getData();
                    rvUpcoming.setLayoutManager(new LinearLayoutManager(getContext()));
                    UpcomingAdapter adapter = new UpcomingAdapter(arrayList);
                    rvUpcoming.setAdapter(adapter);
//                    Log.w("--apiResponse--", "Home -activity ------userdata >  " + new GsonBuilder().setPrettyPrinting().create().toJson(UpcomingAipRespons));

                } else {
                    try {
                        Log.e("www", "Response not successful. Code: " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(Call<UpcomingAipRespons> call, Throwable t) {
                Log.e("www", "Failed to fetch schedule details: " + t.getMessage());
            }
        });


        return view;
    }


    public class UpcomingAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private ArrayList<UpcomingModel> items;

        public UpcomingAdapter(ArrayList<UpcomingModel> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(getContext()).inflate(R.layout.schedule_layout, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

            UpcomingModel item = (UpcomingModel) items.get(position);
            ((ViewHolder) holder).tvTitleMatch.setText(item.getTitle());
            ((ViewHolder) holder).tvMatchName1.setText(item.getTeamA());
            ((ViewHolder) holder).tvMatchName2.setText(item.getTeamB());
            ((ViewHolder) holder).tvMatchDatetime.setText(item.getMatchtime());
            ((ViewHolder) holder).tvMatchCityName.setText(item.getVenue());

            ((ViewHolder) holder).tvMatchCityName.setSelected(true);

            Glide.with(getContext()).load(item.getImageUrl() + item.getTeamAImage()).into(((ViewHolder) holder).ivMatchImg1);
            Glide.with(getContext()).load(item.getImageUrl() + item.getTeamBImage()).into(((ViewHolder) holder).ivMatchImg2);


        }

        @Override
        public int getItemCount() {
            return arrayList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvTitleMatch, tvMatchName1, tvMatchName2, tvMatchDatetime, tvMatchCityName, tvMatchWon;
            ImageView ivMatchImg1, ivMatchImg2;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvTitleMatch = itemView.findViewById(R.id.tvTitleMatch);
                tvMatchName1 = itemView.findViewById(R.id.tvMatchName1);
                tvMatchName2 = itemView.findViewById(R.id.tvMatchName2);
                tvMatchDatetime = itemView.findViewById(R.id.tvMatchDatetime);
                tvMatchCityName = itemView.findViewById(R.id.tvMatchCityName);
                ivMatchImg1 = itemView.findViewById(R.id.ivMatchImg1);
                ivMatchImg2 = itemView.findViewById(R.id.ivMatchImg2);
                tvMatchWon = itemView.findViewById(R.id.tvMatchWon);
            }
        }
    }
}