package com.livescoremach.livecricket.showscore.IPLList;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class IPLListModel {
    @SerializedName("vYear")
    @Expose
    private String vYear;
    @SerializedName("vWinner")
    @Expose
    private String vWinner;
    @SerializedName("vRunnerUp")
    @Expose
    private String vRunnerUp;
    @SerializedName("vVenue")
    @Expose
    private String vVenue;
    @SerializedName("vWinnerCaptain")
    @Expose
    private String vWinnerCaptain;
    @SerializedName("vManOfTheMatch")
    @Expose
    private String vManOfTheMatch;
    @SerializedName("vPlayerOfTheTournament")
    @Expose
    private String vPlayerOfTheTournament;
    @SerializedName("objOrangeCap")
    @Expose
    private ObjOrangeCap objOrangeCap;
    @SerializedName("objPurpleCap")
    @Expose
    private ObjPurpleCap objPurpleCap;

    public String getvYear() {
        return vYear;
    }

    public void setvYear(String vYear) {
        this.vYear = vYear;
    }

    public String getvWinner() {
        return vWinner;
    }

    public void setvWinner(String vWinner) {
        this.vWinner = vWinner;
    }

    public String getvRunnerUp() {
        return vRunnerUp;
    }

    public void setvRunnerUp(String vRunnerUp) {
        this.vRunnerUp = vRunnerUp;
    }

    public String getvVenue() {
        return vVenue;
    }

    public void setvVenue(String vVenue) {
        this.vVenue = vVenue;
    }

    public String getvWinnerCaptain() {
        return vWinnerCaptain;
    }

    public void setvWinnerCaptain(String vWinnerCaptain) {
        this.vWinnerCaptain = vWinnerCaptain;
    }

    public String getvManOfTheMatch() {
        return vManOfTheMatch;
    }

    public void setvManOfTheMatch(String vManOfTheMatch) {
        this.vManOfTheMatch = vManOfTheMatch;
    }

    public String getvPlayerOfTheTournament() {
        return vPlayerOfTheTournament;
    }

    public void setvPlayerOfTheTournament(String vPlayerOfTheTournament) {
        this.vPlayerOfTheTournament = vPlayerOfTheTournament;
    }

    public ObjOrangeCap getObjOrangeCap() {
        return objOrangeCap;
    }

    public void setObjOrangeCap(ObjOrangeCap objOrangeCap) {
        this.objOrangeCap = objOrangeCap;
    }

    public ObjPurpleCap getObjPurpleCap() {
        return objPurpleCap;
    }

    public void setObjPurpleCap(ObjPurpleCap objPurpleCap) {
        this.objPurpleCap = objPurpleCap;
    }
}
