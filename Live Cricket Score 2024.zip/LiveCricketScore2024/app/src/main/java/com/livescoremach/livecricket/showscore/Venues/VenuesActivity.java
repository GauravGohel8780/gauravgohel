package com.livescoremach.livecricket.showscore.Venues;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.MyApplication.sharedPreferencesHelper;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.livescoremach.livecricket.showscore.Ads_Common.AdsBaseActivity;
import com.livescoremach.livecricket.showscore.R;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.util.ArrayList;

public class VenuesActivity extends AdsBaseActivity {

    RecyclerView rvWinner;
    ArrayList<Object> arrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_venues);



        findViewById(R.id.ivBack).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });

        arrayList.add(new VenuesModel("Wankhede Stadium", "Mumbai", "Maharashtra", "23 January 1975", "33,108"));
        arrayList.add(new VenuesModel("M. Chinnaswamy Stadium", "Bengaluru", "Karnataka", "2008", "35,000"));
        arrayList.add(new VenuesModel("Feroz Shah Kotla Ground", "New Delhi", "Delhi", "1883", "41,820"));
        arrayList.add(new VenuesModel("Rajiv Gandhi Intl. Cricket Stadium", "Hyderabad", "Telangana", "2012", "39,408   "));
        arrayList.add(new VenuesModel("Holkar Cricket Stadium", "Indore", "Madhya Pradesh", "April 15, 2006", "30,000"));
        arrayList.add(new VenuesModel("Sawai Mansingh Stadium", "Jaipur", "Rajasthan", "2006", "23,185"));
        arrayList.add(new VenuesModel("Eden Gardens", "Calcutta", "West Bengal", "1864", "68,000"));
        arrayList.add(new VenuesModel("IS Bindra Stadium", "Mohali", "Punjab", "1993", "26,000"));
        arrayList.add(new VenuesModel("Maharashtra Cricket Association's International Stadium", "Pune", "Maharashtra", "April 2012", "42,000"));
        arrayList.add(new VenuesModel("M. A. Chidambaram Stadium", "Chennai", "Tamil Nadu", "1916", "33,500"));


        rvWinner = findViewById(R.id.rvWinner);
        getbanneritems();
        VenuesAdapter adapter = new VenuesAdapter(arrayList);
        rvWinner.setLayoutManager(new LinearLayoutManager(this));
        rvWinner.setAdapter(adapter);
    }

    public void getbanneritems() {
        for (int i = 0; i < arrayList.size(); i += sharedPreferencesHelper.getListViewAd()) // i=i+4
        {
            arrayList.add(i, ""); // 0 4 8 12...
        }
    }

    public class VenuesAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private ArrayList<Object> items;
        private static final int VIEW_TYPE_ITEM = 0;
        private static final int VIEW_TYPE_AD = 1;

        public VenuesAdapter(ArrayList<Object> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            switch (viewType) {
                case VIEW_TYPE_ITEM:
                    View view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.venueslayout, parent, false);
                    return new ViewHolder(view);
                case VIEW_TYPE_AD:
                default:
                    View view1 = LayoutInflater.from(getApplicationContext()).inflate(R.layout.ads_rv_native_banner, parent, false);
                    return new NativeViewHolder(view1);
            }
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            int viewType = getItemViewType(position);

            switch (viewType) {
                case VIEW_TYPE_ITEM:
                    VenuesModel item = (VenuesModel) items.get(position);
                    ((ViewHolder) holder).tvVenuesName.setText(item.getVenuesName());
                    ((ViewHolder) holder).tvCity.setText(item.getCity());
                    ((ViewHolder) holder).tvState.setText(item.getState());
                    ((ViewHolder) holder).tvOpened.setText(item.getOpened());
                    ((ViewHolder) holder).tvCapacity.setText(item.getCapacity());
                    break;
                case VIEW_TYPE_AD:
                default:
                    getInstance(VenuesActivity.this).ShowNativeAd(holder.itemView.findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
                    break;
            }

        }

        @Override
        public int getItemViewType(int position) {

            if (position % sharedPreferencesHelper.getListViewAd() == 0)
                return VIEW_TYPE_AD;
            else
                return VIEW_TYPE_ITEM;
        }


        @Override
        public int getItemCount() {
            return arrayList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            TextView tvVenuesName, tvCity, tvState, tvOpened, tvCapacity;


            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvVenuesName = itemView.findViewById(R.id.tvVenuesName);
                tvCity = itemView.findViewById(R.id.tvCity);
                tvState = itemView.findViewById(R.id.tvState);
                tvOpened = itemView.findViewById(R.id.tvOpened);
                tvCapacity = itemView.findViewById(R.id.tvCapacity);
            }
        }
    }

    public static class NativeViewHolder extends RecyclerView.ViewHolder {
        public NativeViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

}