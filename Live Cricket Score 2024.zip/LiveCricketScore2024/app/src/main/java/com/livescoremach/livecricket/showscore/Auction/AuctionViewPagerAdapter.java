package com.livescoremach.livecricket.showscore.Auction;

import android.content.Context;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.livescoremach.livecricket.showscore.Auction.AllRoundersAuction.AllRoundersAuctionFragment;
import com.livescoremach.livecricket.showscore.Auction.BatterAuction.BatterAuctionFragment;
import com.livescoremach.livecricket.showscore.Auction.TeamAuction.TeamAuctionFragment;
import com.livescoremach.livecricket.showscore.Auction.WicketkeeperAuction.WicketkeeperAuctionFragment;

public class AuctionViewPagerAdapter extends FragmentPagerAdapter {

    private Context myContext;
    int totalTabs;

    public AuctionViewPagerAdapter(Context context, FragmentManager fm, int totalTabs) {
        super(fm);  
        myContext = context;  
        this.totalTabs = totalTabs;  
    }  
  
    // this is for fragment tabs  
    @Override  
    public Fragment getItem(int position) {
        switch (position) {  
            case 0:
                TeamAuctionFragment teamAuctionFragment = new TeamAuctionFragment();
                return teamAuctionFragment;
            case 1:
                BatterAuctionFragment batterAuctionFragment = new BatterAuctionFragment();
                return batterAuctionFragment;
            case 2:
                WicketkeeperAuctionFragment wicketkeeperAuctionFragment = new WicketkeeperAuctionFragment();
                return wicketkeeperAuctionFragment;
            case 3:
                AllRoundersAuctionFragment allRoundersAuctionFragment = new AllRoundersAuctionFragment();
                return allRoundersAuctionFragment;
            default:  
                return null;  
        }  
    }
    @Override  
    public int getCount() {  
        return totalTabs;  
    }  
}  