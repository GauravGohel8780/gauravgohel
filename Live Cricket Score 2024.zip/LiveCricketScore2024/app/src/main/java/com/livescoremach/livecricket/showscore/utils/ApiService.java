package com.livescoremach.livecricket.showscore.utils;

import com.livescoremach.livecricket.showscore.Auction.ActionModel.AuctionDitailApiResponse;
import com.livescoremach.livecricket.showscore.IPLList.IplListAipRespons;
import com.livescoremach.livecricket.showscore.IccRanking.ApiModel.IccRankingApiResponse;
import com.livescoremach.livecricket.showscore.LiveMatch.LiveMatchAipRespons;
import com.livescoremach.livecricket.showscore.LiveMatch.ScoreCard.ScoreCardAipRespons;
import com.livescoremach.livecricket.showscore.Schedule.UpcomingAipRespons;
import com.livescoremach.livecricket.showscore.TeamandSquad.TeamAndSquadAipRespons;
import com.livescoremach.livecricket.showscore.Winner.WinnerApiResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiService {
    @FormUrlEncoded
    @POST("api/v1/saveRecord/list/")
    Call<IccRankingApiResponse> getIccRankingData(@Field("vName") String vName);

    @FormUrlEncoded
    @POST("api/v1/saveRecord/list/")
    Call<IplListAipRespons> getIplListData(@Field("vName") String vName);

    @FormUrlEncoded
    @POST("api/v1/saveRecord/list/")
    Call<TeamAndSquadAipRespons> getTeamAndSquadData(@Field("vName") String vName);

    @FormUrlEncoded
    @POST("api/v1/saveRecord/list/")
    Call<AuctionDitailApiResponse> getAuctionData(@Field("vName") String vName);


    @FormUrlEncoded
    @POST("api/v1/saveRecord/list/")
    Call<WinnerApiResponse> getWinnerData(@Field("vName") String vName);

    @FormUrlEncoded
    @POST("api/v1/liveMatch/result")
    Call<UpcomingAipRespons> getTopRatedMovies(@Field("vStart") String vStart, @Field("vEnd") String vEnd);

    @POST("api/v1/schedule/details")
    Call<UpcomingAipRespons> getScheduleDetails();

    @POST("api/v1/liveMatch/details")
    Call<LiveMatchAipRespons> getLiveMatchDetails();

    @FormUrlEncoded
    @POST("api/v1/liveMatch/scoreCard")
    Call<ScoreCardAipRespons> getScoreCardData(@Field("MatchId") String vName);

}


