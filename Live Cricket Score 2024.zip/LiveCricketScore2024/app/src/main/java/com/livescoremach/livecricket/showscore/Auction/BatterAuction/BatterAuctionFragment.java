package com.livescoremach.livecricket.showscore.Auction.BatterAuction;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.livescoremach.livecricket.showscore.Auction.ActionModel.AuctionDitail;
import com.livescoremach.livecricket.showscore.Auction.ActionModel.AuctionDitailApiResponse;
import com.livescoremach.livecricket.showscore.Auction.ActionModel.AuctionDitailModel;
import com.livescoremach.livecricket.showscore.Auction.AuctionDitailAdapter;
import com.livescoremach.livecricket.showscore.R;
import com.livescoremach.livecricket.showscore.utils.ApiService;
import com.livescoremach.livecricket.showscore.utils.RetrofitClient;

import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BatterAuctionFragment extends Fragment {
    String intentAuction;
    RecyclerView rvBatterAuction;
    AuctionDitailAdapter adapter;
    ArrayList<AuctionDitailModel> arrayList = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_batter_auction, container, false);

        intentAuction = getActivity().getIntent().getStringExtra("Auction");

        ApiService apiService = RetrofitClient.getApiService();
        Call<AuctionDitailApiResponse> call = apiService.getAuctionData("sold&unsold");
        call.enqueue(new Callback<AuctionDitailApiResponse>() {
            @Override
            public void onResponse(Call<AuctionDitailApiResponse> call, Response<AuctionDitailApiResponse> response) {
                if (response.isSuccessful()) {
                    view.findViewById(R.id.mainProgress).setVisibility(View.GONE);
                    AuctionDitailApiResponse responseData = response.body();
                    ArrayList<AuctionDitail> teamList = responseData.getData();

                    rvBatterAuction = view.findViewById(R.id.rvBatterAuction);
                    if (intentAuction.equals("SoldPlayer")) {
                        arrayList = teamList.get(0).getSold().getBatsmens();
                    } else if (intentAuction.equals("UnsoldPlayer")) {
                        arrayList = teamList.get(0).getUnsold().getBatsmens();
                    }
                    adapter = new AuctionDitailAdapter(arrayList, getContext());
                    rvBatterAuction.setLayoutManager(new LinearLayoutManager(getContext()));
                    rvBatterAuction.setAdapter(adapter);

                } else {
                    try {
                        Log.e("--apiResponse--", "Error: PlanDetailResponse " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(Call<AuctionDitailApiResponse> call, Throwable t) {
                Log.e("--apiResponse--", "Error:" + t.getMessage());
            }
        });



        return view;
    }

}