package com.livescoremach.livecricket.showscore.IccRanking;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.os.Bundle;
import android.widget.TextView;

import androidx.viewpager.widget.ViewPager;

import com.livescoremach.livecricket.showscore.Ads_Common.AdsBaseActivity;
import com.livescoremach.livecricket.showscore.R;
import com.google.android.material.tabs.TabLayout;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class IccRankingActivity extends AdsBaseActivity {

    TabLayout tabLayout;
    ViewPager viewPager;

    String intentIccRenking;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_icc_ranking);

        intentIccRenking = getIntent().getStringExtra("IccRanking");

        findViewById(R.id.ivBack).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });

        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        viewPager = (ViewPager) findViewById(R.id.viewPager);
        if (intentIccRenking.equals("men")) {
            ((TextView)findViewById(R.id.tvTitle)).setText(getResources().getString(R.string.iccmanraning));
        } else if (intentIccRenking.equals("women")) {
            ((TextView)findViewById(R.id.tvTitle)).setText(getResources().getString(R.string.iccwomanraning));
        }

        tabLayout.addTab(tabLayout.newTab().setText(getResources().getString(R.string.team)));
        tabLayout.addTab(tabLayout.newTab().setText(getResources().getString(R.string.better)));
        tabLayout.addTab(tabLayout.newTab().setText(getResources().getString(R.string.bowler)));
        tabLayout.addTab(tabLayout.newTab().setText(getResources().getString(R.string.allrounders)));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        final IccRankingAdapter adapter = new IccRankingAdapter(this, getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
