package com.livescoremach.livecricket.showscore;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatRatingBar;
import androidx.cardview.widget.CardView;

import com.livescoremach.livecricket.showscore.feedback.FeedbackActivity;
import com.iten.tenoku.ad.HandleClick.HandleClick;

public class RateingDialog extends Dialog {

    private float userrate = 5;
    Activity activity;

    public RateingDialog(@NonNull Activity activity) {
        super(activity);
        this.activity = activity;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rate_us_layout);

        AppCompatRatingBar ratebtn = findViewById(R.id.ratebtn);
        CardView btnsubmit = findViewById(R.id.btnsubmit);


        ratebtn.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                userrate = rating;
            }
        });

        btnsubmit.setOnClickListener(v -> {
            dismiss();
            if (userrate >= 4) {
                Uri uri = Uri.parse("market://details?id=" + getContext().getPackageName());
                Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
                try {
                    getContext().startActivity(myAppLinkToMarket);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), " unable to find market app", Toast.LENGTH_LONG).show();
                }
            } else {
                getInstance(activity).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent1 = new Intent(getContext(), FeedbackActivity.class);
                        getContext().startActivity(intent1);
                    }
                }, MAIN_CLICK);
            }

        });
    }
}
