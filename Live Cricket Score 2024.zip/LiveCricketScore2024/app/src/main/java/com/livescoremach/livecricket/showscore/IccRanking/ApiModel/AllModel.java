package com.livescoremach.livecricket.showscore.IccRanking.ApiModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AllModel {

@SerializedName("vRank")
@Expose
private String vRank;
@SerializedName("vPlayer")
@Expose
private String vPlayer;
@SerializedName("vRatings")
@Expose
private String vRatings;

public String getvRank() {
return vRank;
}

public void setvRank(String vRank) {
this.vRank = vRank;
}

public String getvPlayer() {
return vPlayer;
}

public void setvPlayer(String vPlayer) {
this.vPlayer = vPlayer;
}

public String getvRatings() {
return vRatings;
}

public void setvRatings(String vRatings) {
this.vRatings = vRatings;
}

}