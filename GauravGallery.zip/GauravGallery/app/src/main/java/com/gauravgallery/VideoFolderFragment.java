package com.gauravgallery;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.gauravgallery.databinding.FragmentVideoFolderBinding;

import java.util.ArrayList;

public class VideoFolderFragment extends Fragment {

    FragmentVideoFolderBinding binding;
    ArrayList<MediaModel> arrayList = new ArrayList<>();
    MediaAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentVideoFolderBinding.inflate(getLayoutInflater());

        binding.rvVideoFolder.setHasFixedSize(true);
        binding.rvVideoFolder.setLayoutManager(new GridLayoutManager(getContext(), 2));
        arrayList = getPicturePaths();
        adapter = new MediaAdapter(arrayList, getContext());
        binding.rvVideoFolder.setAdapter(adapter);
        return binding.getRoot();
    }



    private ArrayList<MediaModel> getPicturePaths() {

        ArrayList<String> picPaths = new ArrayList<>();
        Uri allImagesuri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Video.VideoColumns.DATA,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
                MediaStore.Video.Media.BUCKET_ID};

        Cursor cursor = getActivity().getContentResolver().query(allImagesuri, projection, null, null, null);

        try {
            if (cursor != null) {
                cursor.moveToFirst();
            }
            do {
                MediaModel model = new MediaModel();
                String name = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME));
                String folder = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME));
                String datapath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA));


                String folderpaths = datapath.substring(0, datapath.lastIndexOf(folder + "/"));
                folderpaths = folderpaths + folder + "/";
                if (!picPaths.contains(folderpaths)) {
                    picPaths.add(folderpaths);

                    model.setPath(folderpaths);
                    model.setFolderName(folder);
                    model.setFirstMediaPath(datapath);
                    model.addpics();
                    arrayList.add(model);
                } else {
                    for (int i = 0; i < arrayList.size(); i++) {
                        model = (MediaModel) arrayList.get(i);
                        if (model.getPath().equals(folderpaths)) {
                            model.setFirstMediaPath(datapath);
                            model.addpics();
                        }
                    }
                }
            } while (cursor.moveToNext());
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return arrayList;
    }
}