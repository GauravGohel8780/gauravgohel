package com.gauravgallery;

import android.content.Context;
import android.content.SharedPreferences;


public class SharedPrefs {
    public static final String LanguageName = "LanguageName";
    public static final String isPermisstion = "Permisstion";
    public static final String Coine = "Coine";

    private static SharedPreferences mPreferences;

    private static SharedPreferences getInstance(Context context) {
        if (mPreferences == null) {
            mPreferences = context.getApplicationContext().getSharedPreferences("stat_data", 0);
        }
        return mPreferences;
    }


    public static void setPermisstion(Context context, boolean str) {
        getInstance(context).edit().putBoolean(isPermisstion, str).apply();
    }

    public static boolean getPermisstion(Context context) {
        return getInstance(context).getBoolean(isPermisstion, false);
    }

    public static void setLanguageName(Context context, String str) {
        getInstance(context).edit().putString(LanguageName, str).apply();
    }

    public static String getLanguageName(Context context) {
        return getInstance(context).getString(LanguageName, "");
    }

    public static void setSelectFregmnet(Context context, int str) {
        getInstance(context).edit().putInt(Coine, str).apply();
    }

    public static int getSelectFregmnet(Context context) {
        return getInstance(context).getInt(Coine, 10);
    }


}
