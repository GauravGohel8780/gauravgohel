package com.gauravgallery;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.View;

import com.gauravgallery.databinding.ActivityMainBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        FragmnetLoad(new ImageFolderFragment());
        SharedPrefs.setSelectFregmnet(this, 0);


        binding.ivImage.setOnClickListener(v -> {
            FragmnetLoad(new ImageFolderFragment());
            SharedPrefs.setSelectFregmnet(this, 0);
        });
        binding.ivVideo.setOnClickListener(v -> {
            FragmnetLoad(new VideoFolderFragment());
            SharedPrefs.setSelectFregmnet(this, 1);
        });
        binding.ivImageVideo.setOnClickListener(v -> {
            FragmnetLoad(new AllFolderFragment());
            SharedPrefs.setSelectFregmnet(this, 2);
        });
    }

    private void FragmnetLoad(Fragment fragment) {
        final FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.flFragmnet, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }


}