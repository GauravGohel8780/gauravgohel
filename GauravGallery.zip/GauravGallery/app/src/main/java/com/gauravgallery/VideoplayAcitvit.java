package com.gauravgallery;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VideoplayAcitvit extends AppCompatActivity {

    VideoView videoshow;
    ImageView imageshow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videoplay_acitvit);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(getResources().getColor(R.color.darkcolor));
        }


        videoshow = findViewById(R.id.videoshow);
        imageshow = findViewById(R.id.imageshow);


        Intent i = getIntent();
        Uri uri = Uri.parse(i.getExtras().get("Videoshow").toString());

        boolean isVideo = getBack(i.getExtras().get("Videoshow").toString(), "((\\.mp4|\\.webm|\\.ogg|\\.mpK|\\.avi|\\.mkv|\\.flv|\\.mpg|\\.wmv|\\.vob|\\.ogv|\\.mov|\\.qt|\\.rm|\\.rmvb\\.|\\.asf|\\.m4p|\\.m4v|\\.mp2|\\.mpeg|\\.mpe|\\.mpv|\\.m2v|\\.3gp|\\.f4p|\\.f4a|\\.f4b|\\.f4v)$)").isEmpty();

        if (!isVideo) {
            videoshow.setVisibility(View.VISIBLE);
            imageshow.setVisibility(View.GONE);
            videoshow.setVideoURI(uri);


            MediaController mediaController = new MediaController(this);

            mediaController.setAnchorView(videoshow);

            mediaController.setMediaPlayer(videoshow);

            videoshow.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    finish();
                }
            });

            videoshow.setMediaController(mediaController);

            videoshow.start();
        } else {

            videoshow.setVisibility(View.GONE);
            imageshow.setVisibility(View.VISIBLE);
            Bitmap myBitmap = BitmapFactory.decodeFile(i.getExtras().get("Videoshow").toString());

            imageshow.setImageBitmap(myBitmap);
        }

    }

    public static String getBack(String paramString1, String paramString2) {
        Matcher localMatcher = Pattern.compile(paramString2).matcher(paramString1);
        if (localMatcher.find()) {
            return localMatcher.group(1);
        }
        return "";
    }

}