package com.gauravgallery;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.gauravgallery.databinding.FragmentImageFolderBinding;

import java.util.ArrayList;

public class ImageFolderFragment extends Fragment {

    FragmentImageFolderBinding binding;
    ArrayList<MediaModel> arrayList = new ArrayList<>();
    MediaAdapter adapter;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentImageFolderBinding.inflate(getLayoutInflater());


        binding.rvImageFolder.setHasFixedSize(true);
        binding.rvImageFolder.setLayoutManager(new GridLayoutManager(getContext(), 2));
        arrayList = getPicturePaths();
        adapter = new MediaAdapter(arrayList, getContext());
        binding.rvImageFolder.setAdapter(adapter);
        return binding.getRoot();
    }

    private ArrayList<MediaModel> getPicturePaths() {

        ArrayList<String> picPaths = new ArrayList<>();
        Uri allImagesuri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Images.ImageColumns.DATA,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
                MediaStore.Images.Media.BUCKET_ID};

        Cursor cursor = getActivity().getContentResolver().query(allImagesuri, projection, null, null, null);

        try {
            if (cursor != null) {
                cursor.moveToFirst();
            }
            do {
                MediaModel model = new MediaModel();
                String name = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME));
                String folder = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME));
                String datapath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA));


                String folderpaths = datapath.substring(0, datapath.lastIndexOf(folder + "/"));
                folderpaths = folderpaths + folder + "/";
                if (!picPaths.contains(folderpaths)) {
                    picPaths.add(folderpaths);

                    model.setPath(folderpaths);
                    model.setFolderName(folder);
                    model.setFirstMediaPath(datapath);
                    model.addpics();
                    arrayList.add(model);
                } else {
                    for (int i = 0; i < arrayList.size(); i++) {
                        model = (MediaModel) arrayList.get(i);
                        if (model.getPath().equals(folderpaths)) {
                            model.setFirstMediaPath(datapath);
                            model.addpics();
                        }
                    }
                }
            } while (cursor.moveToNext());
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return arrayList;
    }
}