package com.gauravgallery;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class GalleryItemActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList<PhotoListModel> model = new ArrayList<>();
    String foldePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery_item);
        findViewById(R.id.btnback).setOnClickListener(view -> {
            onBackPressed();
        });
        String foldename = getIntent().getStringExtra("foldername");
        ((TextView) findViewById(R.id.txttitle)).setText(foldename);
        foldePath = getIntent().getStringExtra("folderPath");

        recyclerView = findViewById(R.id.rvGalleryList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 3));

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (SharedPrefs.getSelectFregmnet(this) == 0) {
            model = getAllImagesByFolder(foldePath);
        } else if (SharedPrefs.getSelectFregmnet(this) == 1) {
            model = getAllVideoByFolder(foldePath);
        } else if (SharedPrefs.getSelectFregmnet(this) == 2) {
            model = getAllMediaByFolder(foldePath);
        }
        recyclerView.setAdapter(new GallaryListAdapter(model, this));
    }

    public ArrayList<PhotoListModel> getAllMediaByFolder(String path) {
        ArrayList<PhotoListModel> mediaList = new ArrayList<>();

        // Query for images and videos
        Uri allMediaUri = MediaStore.Files.getContentUri("external");
        String[] mediaProjection = {MediaStore.Files.FileColumns.DATA, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_TAKEN, MediaStore.MediaColumns.DATE_MODIFIED, MediaStore.Files.FileColumns.MEDIA_TYPE};

        String selection = MediaStore.Files.FileColumns.MEDIA_TYPE + " IN (?, ?) AND " + MediaStore.Files.FileColumns.DATA + " LIKE ?";
        String[] selectionArgs = {String.valueOf(MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE), String.valueOf(MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO), "%" + path + "%"};

        Cursor mediaCursor = this.getContentResolver().query(allMediaUri, mediaProjection, selection, selectionArgs, MediaStore.Files.FileColumns.DATE_MODIFIED + " DESC");

        try {
            if (mediaCursor != null && mediaCursor.moveToFirst()) {
                do {
                    PhotoListModel media = new PhotoListModel();

                    media.setPicturName(mediaCursor.getString(mediaCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)));
                    media.setPicturePath(mediaCursor.getString(mediaCursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA)));
                    media.setPictureSize(mediaCursor.getString(mediaCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)));
                    media.setDateTaken(mediaCursor.getLong(mediaCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)));
                    media.setLastModified(mediaCursor.getLong(mediaCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)));

                    int mediaType = mediaCursor.getInt(mediaCursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE));
                    media.setMediaType(mediaType);

                    mediaList.add(media);
                } while (mediaCursor.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (mediaCursor != null) {
                mediaCursor.close();
            }
        }

        return mediaList;
    }


    public ArrayList<PhotoListModel> getAllImagesByFolder(String path) {
        ArrayList<PhotoListModel> photos = new ArrayList<>();
        Uri allPhtossuri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Images.ImageColumns.DATA, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.SIZE};
        Cursor cursor = getContentResolver().query(allPhtossuri, projection, MediaStore.Images.Media.DATA + " like ? ", new String[]{"%" + path + "%"}, null);
        try {
            cursor.moveToFirst();
            do {
                PhotoListModel pic = new PhotoListModel();

                pic.setPicturName(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)));

                pic.setPicturePath(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)));

                pic.setPictureSize(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)));

                photos.add(pic);
            } while (cursor.moveToNext());
            cursor.close();
            ArrayList<PhotoListModel> reSelection = new ArrayList<>();
            for (int i = photos.size() - 1; i > -1; i--) {
                reSelection.add(photos.get(i));
            }
            photos = reSelection;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return photos;
    }


    public ArrayList<PhotoListModel> getAllVideoByFolder(String path) {
        ArrayList<PhotoListModel> videos = new ArrayList<>();
        Uri allVideosuri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Video.VideoColumns.DATA, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.SIZE};
        Cursor cursor = getContentResolver().query(allVideosuri, projection, MediaStore.Video.Media.DATA + " like ? ", new String[]{"%" + path + "%"}, null);
        try {
            cursor.moveToFirst();
            do {
                PhotoListModel pic = new PhotoListModel();

                pic.setPicturName(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)));

                pic.setPicturePath(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)));

                pic.setPictureSize(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)));

                videos.add(pic);
            } while (cursor.moveToNext());
            cursor.close();
            ArrayList<PhotoListModel> reSelection = new ArrayList<>();
            for (int i = videos.size() - 1; i > -1; i--) {
                reSelection.add(videos.get(i));
            }
            videos = reSelection;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return videos;
    }
}