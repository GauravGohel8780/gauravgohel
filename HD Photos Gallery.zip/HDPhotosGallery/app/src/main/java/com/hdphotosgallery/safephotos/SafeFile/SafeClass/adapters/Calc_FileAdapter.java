package com.hdphotosgallery.safephotos.SafeFile.SafeClass.adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Calc_FilesActivity;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model.DocModel;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;

public class Calc_FileAdapter extends RecyclerView.Adapter<Calc_FileAdapter.ViewHolder> {
    private static ArrayList<DocModel> docList;
    private Activity activity;

    public Calc_FileAdapter(Activity activity, ArrayList<DocModel> arrayList) {
        this.activity = activity;
        docList = arrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(((LayoutInflater) this.activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.doc_item, (ViewGroup) null));
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int i) {
        if (docList.get(i).isSelected()) {
            viewHolder.imgSelected.setVisibility(View.VISIBLE);
        } else {
            viewHolder.imgSelected.setVisibility(View.GONE);
        }
        if (docList.get(i).getFileName().endsWith(".pdf")) {
            Glide.with(this.activity).load(Integer.valueOf((int) R.drawable.pdf_icon)).into(viewHolder.fileImg);
        } else if (docList.get(i).getFileName().endsWith(".docx") || docList.get(i).getFileName().endsWith(".doc")) {
            Glide.with(this.activity).load(Integer.valueOf((int) R.drawable.wordpress_icon)).into(viewHolder.fileImg);
        } else if (docList.get(i).getFileName().endsWith(".xlsx") || docList.get(i).getFileName().endsWith(".xls")) {
            Glide.with(this.activity).load(Integer.valueOf((int) R.drawable.xml_icon)).into(viewHolder.fileImg);
        } else if (docList.get(i).getFileName().endsWith(".txt")) {
            Glide.with(this.activity).load(Integer.valueOf((int) R.drawable.text_icon_copy)).into(viewHolder.fileImg);
        } else if (docList.get(i).getFileName().endsWith(".ppt") || docList.get(i).getFileName().endsWith(".pptx")) {
            Glide.with(this.activity).load(Integer.valueOf((int) R.drawable.ppt_icon_copy)).into(viewHolder.fileImg);
        }
        viewHolder.fileNameTxt.setText(docList.get(i).getFileName());
        long length = new File(docList.get(i).getFilePath()).length() / 1024;
        long j = length / 1024;
        if (j > 0) {
            TextView textView = viewHolder.fileSizeTxt;
            textView.setText(j + " MB");
        } else {
            TextView textView2 = viewHolder.fileSizeTxt;
            textView2.setText(length + " KB");
        }
        viewHolder.selectFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calc_FilesActivity.selected = true;
                if (((DocModel) Calc_FileAdapter.docList.get(i)).isSelected()) {
                    ((DocModel) Calc_FileAdapter.docList.get(i)).setSelected(false);
                    viewHolder.imgSelected.setVisibility(View.GONE);
                } else {
                    ((DocModel) Calc_FileAdapter.docList.get(i)).setSelected(true);
                    viewHolder.imgSelected.setVisibility(View.VISIBLE);
                }
                Calc_FileAdapter.this.notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return docList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView fileImg;
        TextView fileNameTxt;
        TextView fileSizeTxt;
        RelativeLayout imgSelected;
        RelativeLayout selectFile;

        ViewHolder(View view) {
            super(view);
            this.fileImg = (ImageView) view.findViewById(R.id.file_img);
            this.fileNameTxt = (TextView) view.findViewById(R.id.file_name_tv);
            this.fileSizeTxt = (TextView) view.findViewById(R.id.file_size_tv);
            this.selectFile = (RelativeLayout) view.findViewById(R.id.select_file);
            this.imgSelected = (RelativeLayout) view.findViewById(R.id.img_selected);
        }
    }

    public static void clearSelection() {
        Iterator<DocModel> it = docList.iterator();
        while (it.hasNext()) {
            it.next().isSelected = false;
        }
    }

    public ArrayList<DocModel> getSelectedList() {
        ArrayList<DocModel> arrayList = new ArrayList<>();
        for (int i = 0; i <= docList.size() - 1; i++) {
            if (docList.get(i).isSelected()) {
                arrayList.add(docList.get(i));
            }
        }
        return arrayList;
    }
}
