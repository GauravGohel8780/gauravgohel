package com.hdphotosgallery.safephotos.SafeFile.SafeClass;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.hdphotosgallery.safephotos.PhotosGroping.AllPhotosActivity;
import com.hdphotosgallery.safephotos.R;

import java.util.ArrayList;

public class Calc_GetFileActivity extends AppCompatActivity {
    ArrayList<String> list = new ArrayList<>();
    Uri uri;

    @SuppressLint("Range")
    @Override
    public void onCreate(Bundle bundle) {
        ArrayList parcelableArrayListExtra;
        super.onCreate(bundle);
        setContentView(R.layout.activity_get_file);

        Intent intent = getIntent();
        String[] strArr = {"_data"};
        String type = intent.getType();
        if ("android.intent.action.SEND".equals(intent.getAction())) {
            Uri uri = (Uri) intent.getParcelableExtra("android.intent.extra.STREAM");
            this.uri = uri;
            String scheme = uri.getScheme();
            if (scheme != null && scheme.equals("content")) {
                Cursor query = getContentResolver().query(this.uri, strArr, null, null, null);
                if (query != null) {
                    query.moveToFirst();
                    this.list.add(query.getString(query.getColumnIndex(strArr[0])));
                    query.close();
                }
            } else if (scheme != null && scheme.equals("file")) {
                this.list.add(this.uri.getPath());
            }
        } else if ("android.intent.action.SEND_MULTIPLE".equals(intent.getAction()) && type != null && (parcelableArrayListExtra = intent.getParcelableArrayListExtra("android.intent.extra.STREAM")) != null) {
            for (int i = 0; i < parcelableArrayListExtra.size(); i++) {
                String scheme2 = ((Uri) parcelableArrayListExtra.get(i)).getScheme();
                if (scheme2 != null && scheme2.equals("content")) {
                    Cursor query2 = getContentResolver().query((Uri) parcelableArrayListExtra.get(i), strArr, null, null, null);
                    if (query2 != null) {
                        query2.moveToFirst();
                        this.list.add(query2.getString(query2.getColumnIndex(strArr[0])));
                        query2.close();
                    }
                } else if (scheme2 != null && scheme2.equals("file")) {
                    this.list.add(((Uri) parcelableArrayListExtra.get(i)).getPath());
                }
            }
        }
        if (type != null) {
            if (type.startsWith("text/") || type.startsWith("application/txt") || type.startsWith("application/pdf") || type.startsWith("application/vnd.ms-excel") || type.startsWith("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") || type.startsWith("application/msword") || type.startsWith("text/html") || type.startsWith("application/vnd.openxmlformats-officedocument.wordprocessingml.document") || type.startsWith("application/vnd.openxmlformats-officedocument.presentationml.presentation") || type.startsWith("application/vnd.ms-powerpoint")) {
                Intent intent2 = new Intent(getApplicationContext(), AllPhotosActivity.class);
                intent2.putExtra("getActivity", true);
                intent2.putExtra("docList", this.list);
                startActivity(intent2);
                finish();
            } else if (type.startsWith("image/") || type.startsWith("video/")) {
                Intent intent3 = new Intent(getApplicationContext(), AllPhotosActivity.class);
                intent3.putExtra("getActivity", true);
                intent3.putExtra("selectedList", this.list);
                startActivity(intent3);
                finish();
            }
        }
    }
}
