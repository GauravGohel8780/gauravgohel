package com.hdphotosgallery.safephotos.GalleryGroping;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.hdphotosgallery.safephotos.R;

import java.util.ArrayList;

public class GalleryItemActivity extends AppCompatActivity implements OnItemClickListener {
    RecyclerView recyclerView;
    ArrayList<PhotoListModel> model = new ArrayList<>();
    String foldePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery_item);
        findViewById(R.id.btnback).setOnClickListener(view -> {
            onBackPressed();
        });
        String foldename = getIntent().getStringExtra("foldername");
        ((TextView) findViewById(R.id.txttitle)).setText(foldename);
        foldePath = getIntent().getStringExtra("folderPath");

        recyclerView = findViewById(R.id.rvGalleryList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 3));

    }

    @Override
    protected void onResume() {
        super.onResume();
        model = getAllMediaByFolder(foldePath);
        recyclerView.setAdapter(new GallaryListAdapter(model, this, this));
    }

    public ArrayList<PhotoListModel> getAllMediaByFolder(String path) {
        ArrayList<PhotoListModel> mediaList = new ArrayList<>();

        // Query for images and videos
        Uri allMediaUri = MediaStore.Files.getContentUri("external");
        String[] mediaProjection = {
                MediaStore.Files.FileColumns.DATA,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.Files.FileColumns.MEDIA_TYPE
        };

        String selection = MediaStore.Files.FileColumns.MEDIA_TYPE + " IN (?, ?) AND " +
                MediaStore.Files.FileColumns.DATA + " LIKE ?";
        String[] selectionArgs = {
                String.valueOf(MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE),
                String.valueOf(MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO),
                "%" + path + "%"
        };

        Cursor mediaCursor = this.getContentResolver().query(
                allMediaUri, mediaProjection,
                selection, selectionArgs,
                MediaStore.Files.FileColumns.DATE_MODIFIED + " DESC"
        );

        try {
            if (mediaCursor != null && mediaCursor.moveToFirst()) {
                do {
                    PhotoListModel media = new PhotoListModel();

                    media.setPicturName(mediaCursor.getString(mediaCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)));
                    media.setPicturePath(mediaCursor.getString(mediaCursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA)));
                    media.setPictureSize(mediaCursor.getString(mediaCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)));
                    media.setDateTaken(mediaCursor.getLong(mediaCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)));
                    media.setLastModified(mediaCursor.getLong(mediaCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)));

                    int mediaType = mediaCursor.getInt(mediaCursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE));
                    media.setMediaType(mediaType);

                    mediaList.add(media);
                } while (mediaCursor.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (mediaCursor != null) {
                mediaCursor.close();
            }
        }

        return mediaList;
    }


    @Override
    public void onItemClick(PhotoListModel model, int position, ArrayList<PhotoListModel> arrayList) {
        int po = position;
        Intent intent = new Intent(this, MediaViewpagerActivity.class);
        Bundle args = new Bundle();
        intent.putExtra("po", po);
        intent.putExtra("path", foldePath);
        intent.putExtra("name", model.getPicturName());
        intent.putExtra("selectFolderPath", "/data/user/0/com.hdphotosgallery.safephotos/files/hideFolders/Videos");
        intent.putExtras(args);
        startActivity(intent);
    }
}