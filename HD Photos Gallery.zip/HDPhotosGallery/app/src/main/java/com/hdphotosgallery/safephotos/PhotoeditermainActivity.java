package com.hdphotosgallery.safephotos;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class PhotoeditermainActivity extends AppCompatActivity {

    ImageView iv_pink_image;
    ActivityResultLauncher<String> mGetContent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photoeditermain);

        iv_pink_image = findViewById(R.id.iv_pink_image);

        iv_pink_image.setOnClickListener(view -> {
            mGetContent.launch("image/*");
        });

        mGetContent=registerForActivityResult(new ActivityResultContracts.GetContent(), new ActivityResultCallback<Uri>() {
            @Override
            public void onActivityResult(Uri o) {
                Intent intent = new Intent(PhotoeditermainActivity.this,PhotoEditerActivity.class);
                intent.putExtra("DATA",o.toString());
                startActivityForResult(intent,101);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode==-1 && requestCode==101){
            String result = data.getStringExtra("Result");
            Uri resultUri = null;
            if (result!=null){
                resultUri = Uri.parse(result);
            }
            iv_pink_image.setImageURI(resultUri);
        }
    }
}