package com.hdphotosgallery.safephotos.PhotosGroping;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MediaItemModel {

    private String mediaName;
    private String mediaPath;
    private String mediaSize;
    private long dateTaken;
    private boolean isDateTitle;

    public boolean isSelected;

    // Constructors, getters, and setters

    public MediaItemModel(String mediaName, String mediaPath, String mediaSize, long dateTaken, boolean isDateTitle) {
        this.mediaName = mediaName;
        this.mediaPath = mediaPath;
        this.mediaSize = mediaSize;
        this.dateTaken = dateTaken;
        this.isDateTitle = isDateTitle;
    }

    public MediaItemModel() {
    }

    public MediaItemModel(String mediaName, String mediaPath) {
        this.mediaName = mediaName;
        this.mediaPath = mediaPath;
    }

    public void setMediaName(String mediaName) {
        this.mediaName = mediaName;
    }

    public void setMediaPath(String mediaPath) {
        this.mediaPath = mediaPath;
    }

    public void setMediaSize(String mediaSize) {
        this.mediaSize = mediaSize;
    }

    public void setDateTaken(long dateTaken) {
        this.dateTaken = dateTaken;
    }

    public void setDateTitle(boolean dateTitle) {
        isDateTitle = dateTitle;
    }

    public String getMediaName() {
        return mediaName;
    }

    public String getMediaPath() {
        return mediaPath;
    }

    public String getMediaSize() {
        return mediaSize;
    }

    public long getDateTaken() {
        return dateTaken;
    }

    public boolean isSelected() {
        return this.isSelected;
    }

    public void setSelected(boolean z) {
        this.isSelected = z;
    }

    public boolean isDateTitle() {
        return isDateTitle;
    }

    public String getDateTitle() {
        Calendar calendar = Calendar.getInstance();
        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY, 0);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);
        today.set(Calendar.MILLISECOND, 0);

        calendar.setTimeInMillis(dateTaken);

        if (calendar.after(today)) {
            return "Today";
        } else {
            Calendar yesterday = (Calendar) today.clone();
            yesterday.add(Calendar.DAY_OF_YEAR, -1);

            if (calendar.after(yesterday)) {
                return "Yesterday";
            } else {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                return sdf.format(new Date(dateTaken));
            }
        }
    }
}