package com.hdphotosgallery.safephotos.PhotosGroping;

import static com.hdphotosgallery.safephotos.PhotosGroping.SectionimgeActivity.getBack;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.hdphotosgallery.safephotos.R;

import java.util.ArrayList;
import java.util.List;

public class AllPhotosFragment extends Fragment {
    ArrayList<MediaItemModel> mFiles = new ArrayList<>();
    RecyclerView recyclerView;
    TextView textView;
    PAdapter pAdapter;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_all_photos, container, false);
        recyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);

        recyclerView.setHasFixedSize(true);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 4);
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                if(pAdapter.getItemViewType(position) == 1)
                    return gridLayoutManager.getSpanCount();
                else
                    return 1;
            }
        });
        recyclerView.setLayoutManager(gridLayoutManager);

        return view;
    }
    @Override
    public void onResume() {
        super.onResume();
        mFiles = findMediaFiles(requireActivity());
        pAdapter = new PAdapter(requireActivity(), mFiles);
        recyclerView.setAdapter(pAdapter);
    }


    public static ArrayList<MediaItemModel> findMediaFiles(Context context) {
        ArrayList<MediaItemModel> mediaList = new ArrayList<>();

        final String[] columns = {
                MediaStore.MediaColumns.DATA,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.DATE_TAKEN
        };

        Cursor cursor = context.getContentResolver().query(
                MediaStore.Files.getContentUri("external"), columns,
                null, null, MediaStore.MediaColumns.DATE_TAKEN + " DESC");

        try {
            if (cursor != null && cursor.moveToFirst()) {
                String currentDate = null;

                do {
                    MediaItemModel mediaItem = new MediaItemModel();
                    mediaItem.setMediaName(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)));
                    mediaItem.setMediaPath(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)));
                    mediaItem.setMediaSize(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)));
                    mediaItem.setDateTaken(cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)));

                    // If the date changes, add a new date title
                    if (!TextUtils.equals(currentDate, mediaItem.getDateTitle())) {
                        currentDate = mediaItem.getDateTitle();
                        mediaList.add(new MediaItemModel("", "", "", mediaItem.getDateTaken(),true));  // Add the date title
                    }

                    mediaList.add(mediaItem);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return mediaList;
    }


    public class PAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private static final int VIEW_TYPE_DATE = 1;
        private static final int VIEW_TYPE_PHOTO = 2;

        private List<MediaItemModel> photoList;
        private Context context;

        public PAdapter(Context context, List<MediaItemModel> photoList) {
            this.context = context;
            this.photoList = photoList;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());

            if (viewType == VIEW_TYPE_DATE) {
                View dateView = inflater.inflate(R.layout.item_month_title, parent, false);
                return new DateViewHolder(dateView);
            } else {
                View photoView = inflater.inflate(R.layout.item_child, parent, false);
                return new PhotoViewHolder(photoView);
            }
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            MediaItemModel item = photoList.get(position);

            if (holder instanceof DateViewHolder) {
                ((DateViewHolder) holder).bind(item.getDateTitle());
            } else if (holder instanceof PhotoViewHolder) {
                Glide.with(context).load(photoList.get(position).getMediaPath()).into(((PhotoViewHolder) holder).imageView);

                boolean isVideo = getBack(item.getMediaPath(), "((\\.mp4|\\.webm|\\.ogg|\\.mpK|\\.avi|\\.mkv|\\.flv|\\.mpg|\\.wmv|\\.vob|\\.ogv|\\.mov|\\.qt|\\.rm|\\.rmvb\\.|\\.asf|\\.m4p|\\.m4v|\\.mp2|\\.mpeg|\\.mpe|\\.mpv|\\.m2v|\\.3gp|\\.f4p|\\.f4a|\\.f4b|\\.f4v)$)").isEmpty();

                if (!isVideo) {
                    ((PhotoViewHolder) holder).imagePlayer.setVisibility(View.VISIBLE);
                } else {
                    ((PhotoViewHolder) holder).imagePlayer.setVisibility(View.GONE);
                }

                ((PhotoViewHolder) holder).itemView.setOnClickListener(view -> {
                    Intent intent = new Intent(context, PhotoViewpagerActivity.class);
                    Bundle args = new Bundle();
                    intent.putExtra("po", position);
                    intent.putExtra("path", item.getMediaPath());
                    intent.putExtra("name", item.getMediaName());
                    intent.putExtra("selectFolderPath", "/data/user/0/com.hdphotosgallery.safephotos/files/hideFolders/Videos");
                    intent.putExtras(args);
                    startActivity(intent);
                });
            }
        }

        @Override
        public int getItemCount() {
            return photoList.size();
        }

        @Override
        public int getItemViewType(int position) {
            return photoList.get(position).isDateTitle() ? VIEW_TYPE_DATE : VIEW_TYPE_PHOTO;
        }

        private class DateViewHolder extends RecyclerView.ViewHolder {
            private TextView tvDateTitle;
            DateViewHolder(@NonNull View itemView) {
                super(itemView);
                tvDateTitle = itemView.findViewById(R.id.monthTitleTextView);
            }

            void bind(String dateTitle) {
                tvDateTitle.setText(dateTitle);
            }
        }

        private class PhotoViewHolder extends RecyclerView.ViewHolder {
            private ImageView imageView,imagePlayer;
            PhotoViewHolder(@NonNull View itemView) {
                super(itemView);
                imageView = itemView.findViewById(R.id.imageView);
                imagePlayer = itemView.findViewById(R.id.iconplayer);
            }
        }
    }
}
