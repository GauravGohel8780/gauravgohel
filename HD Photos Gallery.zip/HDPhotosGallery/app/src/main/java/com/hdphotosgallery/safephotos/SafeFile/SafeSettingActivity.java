package com.hdphotosgallery.safephotos.SafeFile;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.SharedPrefs;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.patternlockview.ForgetActivity;

public class SafeSettingActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    TextView password_type;
    PopupWindow mypopupWindow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_safe_setting);
        password_type = findViewById(R.id.password_type);
        setPopUpWindow();
        findViewById(R.id.ChangePassword).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (SharedPrefs.getLockFinalType(SafeSettingActivity.this).equalsIgnoreCase("Pattern")) {
                    SharedPrefs.setLockType(SafeSettingActivity.this, "Pattern");
                    startActivity(new Intent(SafeSettingActivity.this, ForgetActivity.class));
                } else {
                    SharedPrefs.setLockType(SafeSettingActivity.this, "PIN");
                    startActivity(new Intent(SafeSettingActivity.this, ForgetActivity.class));
                }
            }
        });

        findViewById(R.id.lockTypeLL).setOnClickListener(view -> {
            mypopupWindow.showAsDropDown(view, -153, 0);
        });
        findViewById(R.id.SecurityQuestion).setOnClickListener(view -> {
            showdialog();
        });
    }

    private void setPopUpWindow() {
        LayoutInflater inflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.password_type_dialog, null);

        LinearLayout patternLL = view.findViewById(R.id.patternLL);
        LinearLayout pinLL = view.findViewById(R.id.pinLL);
        ImageView patternIV = view.findViewById(R.id.patternIV);
        ImageView pinIV = view.findViewById(R.id.pinIV);

        if (SharedPrefs.getLockFinalType(SafeSettingActivity.this).equalsIgnoreCase("PIN")) {
            patternIV.setImageResource(R.drawable.ic_checkbox_unchecked);
            pinIV.setImageResource(R.drawable.ic_checkbox_checked);
            password_type.setText("Pin");
        } else {
            patternIV.setImageResource(R.drawable.ic_checkbox_checked);
            pinIV.setImageResource(R.drawable.ic_checkbox_unchecked);
            password_type.setText("Pattern");
        }

        pinLL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (SharedPrefs.getLockFinalType(SafeSettingActivity.this).equalsIgnoreCase("Pattern")) {
                    if (SharedPrefs.getIsPinSet(SafeSettingActivity.this)) {
                        SharedPrefs.setLockFinalType(SafeSettingActivity.this, "PIN");
                        patternIV.setImageResource(R.drawable.ic_checkbox_unchecked);
                        pinIV.setImageResource(R.drawable.ic_checkbox_checked);
                        password_type.setText("Pin");
                        mypopupWindow.dismiss();
                    } else {
                        SharedPrefs.setLockType(SafeSettingActivity.this, "PIN");
                        startActivity(new Intent(SafeSettingActivity.this, ForgetActivity.class));
                    }
                }
            }
        });

        patternLL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (SharedPrefs.getLockFinalType(SafeSettingActivity.this).equalsIgnoreCase("PIN")) {
                    if (SharedPrefs.getIsPatternSet(SafeSettingActivity.this)) {
                        SharedPrefs.setLockFinalType(SafeSettingActivity.this, "Pattern");
                        patternIV.setImageResource(R.drawable.ic_checkbox_checked);
                        pinIV.setImageResource(R.drawable.ic_checkbox_unchecked);
                        password_type.setText("Pattern");
                        mypopupWindow.dismiss();
                    } else {
                        SharedPrefs.setLockType(SafeSettingActivity.this, "Pattern");
                        startActivity(new Intent(SafeSettingActivity.this, ForgetActivity.class));
                    }
                }
            }
        });

        mypopupWindow = new PopupWindow(view, RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT, true);
    }

    private void showdialog() {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setContentView(R.layout.security_question_dialog);

        bottomSheetDialog.setCancelable(true);
        Spinner SpinnerTextSize = bottomSheetDialog.findViewById(R.id.SpinnerTextSize);
        AppCompatButton save = bottomSheetDialog.findViewById(R.id.save);
        EditText edit = bottomSheetDialog.findViewById(R.id.edit);


        SpinnerTextSize.setOnItemSelectedListener(SafeSettingActivity.this);

        String[] textsize = getResources().getStringArray(R.array.font_sizes);
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, textsize);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SpinnerTextSize.setAdapter(adapter);


        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (edit.getText().toString().isEmpty()) {
                    Toast.makeText(SafeSettingActivity.this, "Please Enter Answer..", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(SafeSettingActivity.this, "Saved Successfully.", Toast.LENGTH_SHORT).show();
                    bottomSheetDialog.dismiss();
                }

                String Question = edit.getText().toString();

                SharedPrefs.setSecurityQuestionAnswer(SafeSettingActivity.this, Question);
            }
        });


        bottomSheetDialog.show();
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
        if (parent.getId() == R.id.SpinnerTextSize) {
            String valueFromSpinner = parent.getItemAtPosition(i).toString();
            SharedPrefs.setSecurityQuestion(this, valueFromSpinner);

        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}