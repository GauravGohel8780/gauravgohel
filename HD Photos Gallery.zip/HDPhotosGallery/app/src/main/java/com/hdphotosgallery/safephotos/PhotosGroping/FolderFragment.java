package com.hdphotosgallery.safephotos.PhotosGroping;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.hdphotosgallery.safephotos.GalleryGroping.MediaAdapter;
import com.hdphotosgallery.safephotos.GalleryGroping.MediaModel;
import com.hdphotosgallery.safephotos.R;

import java.util.ArrayList;

public class FolderFragment extends Fragment {
    private RecyclerView recyclerView;
    ArrayList<MediaModel> arrayList = new ArrayList<>();
    MediaAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_folder, container, false);
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(),2));

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        arrayList = getMediaPaths();
        adapter = new MediaAdapter(arrayList, getContext());
        recyclerView.setAdapter(adapter);
    }

    private ArrayList<MediaModel> getMediaPaths() {
        ArrayList<MediaModel> mediaList = new ArrayList<>();
        ArrayList<String> mediaPaths = new ArrayList<>();
        Uri allMediaUri = MediaStore.Files.getContentUri("external");

        String[] projection = {
                MediaStore.Files.FileColumns.DATA,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
                MediaStore.Files.FileColumns.MEDIA_TYPE,
                MediaStore.Files.FileColumns.SIZE
        };

        String selection = MediaStore.Files.FileColumns.MEDIA_TYPE + " = ? OR " +
                MediaStore.Files.FileColumns.MEDIA_TYPE + " = ?";
        String[] selectionArgs = {
                String.valueOf(MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE),
                String.valueOf(MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO)
        };

        Cursor cursor = getActivity().getContentResolver().query(
                allMediaUri,
                projection,
                selection,
                selectionArgs,
                null
        );

        try {
            if (cursor != null) {
                cursor.moveToFirst();
            }
            do {
                MediaModel mediaModel = new MediaModel();
                String name = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME));
                String folder = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME));
                String dataPath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA));
                int mediaType = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE));
                long fileSize = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE));

                String folderPath = dataPath.substring(0, dataPath.lastIndexOf(folder + "/"));
                folderPath = folderPath + folder + "/";

                if (!mediaPaths.contains(folderPath)) {
                    mediaPaths.add(folderPath);
                    mediaModel.setPath(folderPath);
                    mediaModel.setFolderName(folder);
                    mediaModel.setFirstMediaPath(dataPath);
                    mediaModel.addMedia();
                    mediaModel.setFolderSize(fileSize); // Set the folder size in the MediaModel
                    mediaList.add(mediaModel);
                } else {
                    for (int i = 0; i < mediaList.size(); i++) {
                        mediaModel = mediaList.get(i);
                        if (mediaModel.getPath().equals(folderPath)) {
                            mediaModel.setFirstMediaPath(dataPath);
                            mediaModel.addMedia();
                            mediaModel.setFolderSize(mediaModel.getFolderSize() + fileSize); // Update the folder size
                        }
                    }
                }
            } while (cursor.moveToNext());
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mediaList;
    }
}