package com.hdphotosgallery.safephotos.GalleryGroping;

public class MediaModel {
    private String path; // Folder path
    private String folderName; // Folder name
    private String firstMediaPath; // The path to the first media file (image or video) in the folder
    private int mediaCount; // Number of media files in the folder
    private String displayName;
    private String date;
    private long FolderSize;
    private long dateTaken; // Date when the first media file was taken
    private long lastModified; // Last modified timestamp of the first media file

    public long getDateTaken() {
        return dateTaken;
    }

    public void setDateTaken(long dateTaken) {
        this.dateTaken = dateTaken;
    }

    public long getLastModified() {
        return lastModified;
    }

    public void setLastModified(long lastModified) {
        this.lastModified = lastModified;
    }

    public long getFolderSize() {
        return FolderSize;
    }

    public void setFolderSize(long folderSize) {
        FolderSize = folderSize;
    }

    public MediaModel() {
        // Default constructor
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getFolderName() {
        return folderName;
    }

    public void setFolderName(String folderName) {
        this.folderName = folderName;
    }

    public String getFirstMediaPath() {
        return firstMediaPath;
    }

    public void setFirstMediaPath(String firstMediaPath) {
        this.firstMediaPath = firstMediaPath;
    }

    public int getMediaCount() {
        return mediaCount;
    }

    public void addMedia() {
        mediaCount++;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public long getSize() {
        return FolderSize;
    }


    private double bytesToMegabytes(long bytes) {
        return (double) bytes / (1024 * 1024);
    }

    private double bytesToGigabytes(long bytes) {
        return (double) bytes / (1024 * 1024 * 1024);
    }

    private String formatFolderSize(long bytes) {
        double megabytes = bytesToMegabytes(bytes);
        double gigabytes = bytesToGigabytes(bytes);

        if (gigabytes >= 1.0) {
            return String.format("%.2f GB", gigabytes);
        } else {
            return String.format("%.2f MB", megabytes);
        }
    }
    public String getFormattedFolderSize() {
        return formatFolderSize(getFolderSize());
    }
}