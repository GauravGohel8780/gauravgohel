package com.hdphotosgallery.safephotos.FavoriteClass;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;


public class FavDB extends SQLiteOpenHelper {

    private static int DB_VERSION = 1;
    private static String DATABASE_NAME = "QuoteDB";
    private static String TABLE_NAME = "favoriteTable";
    private static String ITEM_IMAGE = "image";
    private static String ITEM_Name = "name";
    private static String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + "(" + ITEM_IMAGE + " TEXT," + ITEM_Name + " TEXT)";




    public FavDB(Context context) { super(context,DATABASE_NAME,null,DB_VERSION);}


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void insertIntoTheDatabase(String item_image,String item_name) {
        if(!checkRecordIsExists(item_image))  {
            SQLiteDatabase db = this.getReadableDatabase();
            ContentValues cv = new ContentValues();
            cv.put(ITEM_IMAGE,item_image);
            cv.put(ITEM_Name,item_name);
            db.insert(TABLE_NAME,null,cv);
        }
    }

    public ArrayList<FavModel> Showdata(){
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from "+TABLE_NAME+"";
        Cursor cursor = db.rawQuery(sql, null);

        ArrayList<FavModel>list = new ArrayList<>();
        list.clear();
        if (cursor.moveToFirst()){
            do {
                String path = cursor.getString(0);
                String name = cursor.getString(1);
                list.add( new FavModel(0,path,name));
            }while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    public Boolean checkRecordIsExists(String item_image){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        String sql ="SELECT * FROM "+TABLE_NAME+" WHERE "+ITEM_IMAGE+" = '"+item_image+"'";
        cursor= db.rawQuery(sql,null);
        if(cursor.getCount()>0){
            cursor.close();
            return true;
        }else{
            cursor.close();
            return  false;
        }
    }

    public void remove_fav(String image){
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "DELETE FROM "+TABLE_NAME+" WHERE "+ITEM_IMAGE+" = '"+image+"'";
        db.execSQL(sql);
    }
}



//import android.content.ContentValues;
//import android.content.Context;
//import android.database.Cursor;
//import android.database.sqlite.SQLiteDatabase;
//import android.database.sqlite.SQLiteOpenHelper;
//import android.util.Log;
//
//import androidx.annotation.Nullable;
//
//public class FavDB extends SQLiteOpenHelper {
//
//    private static final String dbname = "gaurav1.db";
//    private static final String tablename = "users";
//    public static String FAVORITE_STATUS = "FAVORITE_STATUS";
//
//
//    public FavDB(@Nullable Context context) {
//        super(context, dbname, null, 1);
//    }
//
//    @Override
//    public void onCreate(SQLiteDatabase sqLiteDatabase) {
//        String db = "Create table " + tablename + "(_id integer primary key autoincrement, FAVORITE_STATUS text, PATH text)";
//        sqLiteDatabase.execSQL(db);
//    }
//
//    @Override
//    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
//        String db = " drop table if exists " + tablename + "";
//        sqLiteDatabase.execSQL(db);
//    }
//
//    public boolean addData(String PATH) {
//        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
//        ContentValues contentValues = new ContentValues();
//        contentValues.put("PATH", PATH);
//        long result = sqLiteDatabase.insert(tablename, null, contentValues);
//        sqLiteDatabase.close();
//        if (result == -1) {
//            Log.d("tag", "addData: Adding false" + PATH + " to " + tablename);
//            return false;
//        } else {
//            Log.d("tag", "addData: Adding true" + PATH + " to " + tablename);
//            return true;
//        }
//
//    }

//    public void remove_fav(int id) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        db.delete("users","_id=?",new String[]{String.valueOf(id)});
//    }
//
//    public void insertIntoTheDatabase(String id, String FAVORITE_STATUS, String PATH) {
//        SQLiteDatabase db;
//        db = this.getWritableDatabase();
//        ContentValues cv = new ContentValues();
//        cv.put("_id", id);
//        cv.put("FAVORITE_STATUS", FAVORITE_STATUS);
//        cv.put("PATH", PATH);
//        db.insert(tablename,null, cv);
//    }
//
//    public Cursor read_all_data(String id) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        String sql = "select * from " + tablename + " where " + " _id" +"="+id+"";
//        return db.rawQuery(sql,null,null);
//}
//}
