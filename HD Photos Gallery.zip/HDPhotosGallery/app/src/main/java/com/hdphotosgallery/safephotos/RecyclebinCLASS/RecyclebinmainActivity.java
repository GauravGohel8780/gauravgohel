package com.hdphotosgallery.safephotos.RecyclebinCLASS;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model.FolderModel;

import java.io.File;
import java.util.ArrayList;

public class RecyclebinmainActivity extends AppCompatActivity implements OnClickListener {

    RecyclerView recycler;
    String selectFolderPath;
    public static ArrayList<FolderModel> folderList = new ArrayList<>();
    DatabaseRecyclerHelper db;
    RecyclebinAdapder adapter;
    File[] list;
    LinearLayout binimg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recyclebinmain);
        this.selectFolderPath = getIntent().getStringExtra("selectedFolderPath");
        this.recycler = (RecyclerView) findViewById(R.id.recycler);
        this.binimg = (LinearLayout) findViewById(R.id.binimg);

        findViewById(R.id.back).setOnClickListener(view -> {
            onBackPressed();
        });

    }

    @Override
    public void onResume() {
        super.onResume();

        this.db = new DatabaseRecyclerHelper(this);
        if (this.selectFolderPath != null) {
            this.list = new File(this.selectFolderPath).listFiles();
        }
        folderList.clear();
        File[] fileArr = this.list;
        if (fileArr != null) {
            for (File file : fileArr) {
                folderList.add(new FolderModel(file.getName(), file.getPath()));
            }
        }
        this.recycler.setLayoutManager(new GridLayoutManager(this, 3));
        RecyclebinAdapder hideItemAdapter = new RecyclebinAdapder(folderList, this, this);
        this.adapter = hideItemAdapter;
        this.recycler.setAdapter(hideItemAdapter);
        if (folderList.size() == 0) {
            binimg.setVisibility(View.VISIBLE);
        } else {
            binimg.setVisibility(View.GONE);
        }
    }

    @Override
    public void OnClick(RecyclebinAdapder.ViewModel holder, int position, ArrayList<FolderModel> arrayList) {
        int postion = position;
        Intent intent = new Intent(this, RecyclebViewpagerActivity.class);
        Bundle args = new Bundle();
        args.putParcelableArrayList("arrayP", (ArrayList<? extends Parcelable>) folderList);
        intent.putExtra("po", postion);
        intent.putExtras(args);
        startActivity(intent);
    }


    public class RecyclebinAdapder extends RecyclerView.Adapter<RecyclebinAdapder.ViewModel> {
        ArrayList<FolderModel> arrayList;
        Context context;
        private OnClickListener onClickListener;

        public RecyclebinAdapder(ArrayList<FolderModel> arrayList, Context context, OnClickListener onClickListener) {
            this.arrayList = arrayList;
            this.context = context;
            this.onClickListener = onClickListener;
        }

        @NonNull
        @Override
        public RecyclebinAdapder.ViewModel onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.hide_item, parent, false);
            return new ViewModel(view);
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclebinAdapder.ViewModel holder, int position) {
            Glide.with(this.context).load(arrayList.get(position).getPath()).into(holder.image);
            holder.itemView.setOnClickListener(view -> {
                onClickListener.OnClick(holder, position, arrayList);
            });
        }

        @Override
        public int getItemCount() {
            return arrayList.size();
        }

        public class ViewModel extends RecyclerView.ViewHolder {
            ImageView image;
            public ViewModel(@NonNull View itemView) {
                super(itemView);

                image = itemView.findViewById(R.id.image);
            }
        }
    }
}