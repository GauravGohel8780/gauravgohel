package com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model;

public class DocModel {
    private String fileName;
    private String filePath;
    public boolean isSelected;

    public DocModel(String str, String str2) {
        this.fileName = "";
        this.filePath = "";
        this.fileName = str;
        this.filePath = str2;
    }

    public boolean isSelected() {
        return this.isSelected;
    }

    public void setSelected(boolean z) {
        this.isSelected = z;
    }

    public String getFileName() {
        return this.fileName;
    }

    public void setFileName(String str) {
        this.fileName = str;
    }

    public String getFilePath() {
        return this.filePath;
    }

    public void setFilePath(String str) {
        this.filePath = str;
    }
}
