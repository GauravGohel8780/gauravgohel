package com.hdphotosgallery.safephotos.SafeFile.LockClass;

import android.os.Bundle;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.hdphotosgallery.safephotos.R;

public class CreatePasswordActivity extends AppCompatActivity implements ItemClickListener {

    FrameLayout frame;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_password);

        frame = findViewById(R.id.frame);

        init(new PatternFregment());
    }

    public void init(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame, fragment).commit();
    }

    @Override
    public void onItemClicked(String item) {
        if (item.equalsIgnoreCase("pattern")) {
            init(new PatternFregment());
        } else {
            init(new RePatternFregment());
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}