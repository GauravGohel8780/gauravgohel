package com.hdphotosgallery.safephotos.SafeFile.SafeClass;

import android.content.Context;
import android.media.MediaPlayer;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model.FolderModel;

import java.util.ArrayList;

/* loaded from: classes2.dex */
public class Calc_ViewImageActivity extends AppCompatActivity {
    MyPagerAdapter adapter;
    ArrayList<FolderModel> list = new ArrayList<>();
    MediaController mediacontroller;
    int selectedImg;
//    Toolbar toolbar;
    VideoView videoView;
    ViewPager viewPager;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_view_image);

        this.viewPager = (ViewPager) findViewById(R.id.viewPager);
//        this.toolbar = (Toolbar) findViewById(R.id.toolbar);
        this.videoView = (VideoView) findViewById(R.id.video_view);
        this.selectedImg = getIntent().getIntExtra("position", 0);
        MediaController mediaController = new MediaController(this);
        this.mediacontroller = mediaController;
        mediaController.setAnchorView(this.videoView);
        //setSupportActionBar(this.toolbar);
        //getSupportActionBar().setDisplayShowTitleEnabled(false);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        ArrayList<FolderModel> arrayList = Calc_HideItemActivity.folderList;
        this.list = arrayList;
//        this.toolbar.setTitle(arrayList.get(this.selectedImg).getName());
        this.viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() { // from class: com.vault.cal.applock.photo.video.calculatorlock.hidephoto.hidevideo.activity.ViewImageActivity.1
            @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
            public void onPageScrollStateChanged(int i) {
            }

            @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
            public void onPageSelected(int i) {
            }

            @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
            public void onPageScrolled(int i, float f, int i2) {
                if (Calc_ViewImageActivity.this.videoView.isPlaying()) {
                    Calc_ViewImageActivity.this.videoView.stopPlayback();
                }
                Calc_ViewImageActivity.this.videoView.setVisibility(View.GONE);
                Calc_ViewImageActivity.this.selectedImg = i;
//                Calc_ViewImageActivity.this.toolbar.setTitle(Calc_ViewImageActivity.this.list.get(Calc_ViewImageActivity.this.selectedImg).getName());
            }
        });
        MyPagerAdapter myPagerAdapter = new MyPagerAdapter();
        this.adapter = myPagerAdapter;
        this.viewPager.setAdapter(myPagerAdapter);
        this.viewPager.setCurrentItem(this.selectedImg);
        this.viewPager.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == 0) {
//                    if (Calc_ViewImageActivity.this.toolbar.getVisibility() == View.VISIBLE) {
//                        Calc_ViewImageActivity.this.toolbar.setVisibility(View.GONE);
//                    } else {
//                        Calc_ViewImageActivity.this.toolbar.setVisibility(View.VISIBLE);
//                    }
                }
                return false;
            }
        });
        this.videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override // android.media.MediaPlayer.OnPreparedListener
            public void onPrepared(MediaPlayer mediaPlayer) {
                mediaPlayer.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() {
                    @Override // android.media.MediaPlayer.OnVideoSizeChangedListener
                    public void onVideoSizeChanged(MediaPlayer mediaPlayer2, int i, int i2) {
                        Calc_ViewImageActivity.this.videoView.setMediaController(Calc_ViewImageActivity.this.mediacontroller);
                        Calc_ViewImageActivity.this.mediacontroller.setAnchorView(Calc_ViewImageActivity.this.videoView);
                    }
                });
            }
        });
        this.videoView.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
                return false;
            }
        });
    }


    private class MyPagerAdapter extends PagerAdapter {
        @Override // androidx.viewpager.widget.PagerAdapter
        public int getItemPosition(Object obj) {
            return -2;
        }

        @Override // androidx.viewpager.widget.PagerAdapter
        public boolean isViewFromObject(View view, Object obj) {
            return view == obj;
        }

        private MyPagerAdapter() {
        }

        @Override // androidx.viewpager.widget.PagerAdapter
        public int getCount() {
            return Calc_ViewImageActivity.this.list.size();
        }

        @Override // androidx.viewpager.widget.PagerAdapter
        public Object instantiateItem(ViewGroup viewGroup, final int i) {
            View inflate = ((LayoutInflater) Calc_ViewImageActivity.this.getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.view_pager_item, (ViewGroup) null);
            ImageView imageView = (ImageView) inflate.findViewById(R.id.image_media);
            ImageView imageView2 = (ImageView) inflate.findViewById(R.id.play_btn);
            if (Calc_ViewImageActivity.this.list.get(i).getName().endsWith(".jpg") || Calc_ViewImageActivity.this.list.get(i).getName().endsWith(".JPG") || Calc_ViewImageActivity.this.list.get(i).getName().endsWith(".png") || Calc_ViewImageActivity.this.list.get(i).getName().endsWith(".PNG") || Calc_ViewImageActivity.this.list.get(i).getName().endsWith(".JPEG") || Calc_ViewImageActivity.this.list.get(i).getName().endsWith(".jpeg")) {
                imageView2.setVisibility(View.GONE);
                Glide.with((FragmentActivity) Calc_ViewImageActivity.this).load(Calc_ViewImageActivity.this.list.get(i).getPath()).into(imageView);
            } else if (Calc_ViewImageActivity.this.list.get(i).getName().endsWith(".gif") || Calc_ViewImageActivity.this.list.get(i).getName().endsWith(".mp4")) {
                imageView2.setVisibility(View.VISIBLE);
                Glide.with(Calc_ViewImageActivity.this.getApplicationContext()).asBitmap().load(ThumbnailUtils.createVideoThumbnail(Calc_ViewImageActivity.this.list.get(i).getPath(), 2)).into(imageView);
                imageView2.setOnClickListener(new View.OnClickListener() { // from class: com.vault.cal.applock.photo.video.calculatorlock.hidephoto.hidevideo.activity.ViewImageActivity.MyPagerAdapter.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        Calc_ViewImageActivity.this.videoView.setVisibility(View.VISIBLE);
                        Calc_ViewImageActivity.this.videoView.setVideoURI(Uri.parse(Calc_ViewImageActivity.this.list.get(i).getPath()));
                        Calc_ViewImageActivity.this.videoView.requestFocus();
                        Calc_ViewImageActivity.this.videoView.start();
                    }
                });
                Calc_ViewImageActivity.this.videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { // from class: com.vault.cal.applock.photo.video.calculatorlock.hidephoto.hidevideo.activity.ViewImageActivity.MyPagerAdapter.2
                    @Override // android.media.MediaPlayer.OnCompletionListener
                    public void onCompletion(MediaPlayer mediaPlayer) {
                        Calc_ViewImageActivity.this.videoView.setVisibility(View.GONE);
                    }
                });
            }
            viewGroup.addView(inflate);
            return inflate;
        }

        @Override // androidx.viewpager.widget.PagerAdapter
        public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
            viewGroup.removeView((View) obj);
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        this.videoView.stopPlayback();
        super.onBackPressed();
        finish();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i == 4) {
            onBackPressed();
            finish();
            return true;
        }
        return true;
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        super.onOptionsItemSelected(menuItem);
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
            return true;
        }
        return true;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

}
