package com.hdphotosgallery.safephotos.PhotosGroping;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.hdphotosgallery.safephotos.FavoriteClass.FavoriteActivity;
import com.hdphotosgallery.safephotos.GalleryGroping.MediaAdapter;
import com.hdphotosgallery.safephotos.GalleryGroping.MediaModel;
import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.RecyclebinCLASS.RecyclebinmainActivity;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.CreatePasswordActivity;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.MainPasswordActivity;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.SharedPrefs;
import com.hdphotosgallery.safephotos.SettingActivity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class FolderActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList<MediaModel> arrayList = new ArrayList<>();
    MediaAdapter adapter;
    PopupWindow mypopupWindow;
    private boolean isCardVisible = true;
    private CardView cardView;


    private List<String> folderContentList;
    private static final int REQUEST_CODE_SELECT_MEDIA = 3;
    private String selectedFolderPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_folder);
        cardView = findViewById(R.id.card);
        findViewById(R.id.btnphoto).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FolderActivity.this, AllPhotosActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.reserntbtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showbottomdialog(FolderActivity.this);
            }
        });

        findViewById(R.id.favoritebtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FolderActivity.this, FavoriteActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.binbtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), RecyclebinmainActivity.class);
                intent.putExtra("selectedFolderPath", "/data/user/0/com.hdphotosgallery.safephotos/files/hideFolders/Videos");
                startActivity(intent);
            }
        });

        findViewById(R.id.safefilebtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (SharedPrefs.getIsPasswordSet(getApplicationContext())) {
                    mypopupWindow.dismiss();
                    Intent intent = new Intent(FolderActivity.this, MainPasswordActivity.class);
                    startActivity(intent);
                } else {
                    mypopupWindow.dismiss();
                    Intent intent = new Intent(FolderActivity.this, CreatePasswordActivity.class);
                    startActivity(intent);
                }
            }
        });
        findViewById(R.id.newfolderntm).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showCustomDialog();
            }
        });
        findViewById(R.id.menudialog).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mypopupWindow.showAsDropDown(view, -100, 0);
            }
        });
        setPopUpWindow(this);

        recyclerView = findViewById(R.id.recyclerView);
        NestedScrollView nestedScrollView = findViewById(R.id.nestedScrollView);
        nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                if (scrollY > oldScrollY) {
                    hideCardViewWithAnimation();
                } else {
                    showCardViewWithAnimation();
                }
            }
        });
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

    }

    @Override
    public void onResume() {
        super.onResume();
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        String downloadsFolderPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath();

        MediaScannerConnection.scanFile(
                this,
                new String[]{downloadsFolderPath},
                null,
                new MediaScannerConnection.OnScanCompletedListener() {
                    @Override
                    public void onScanCompleted(String path, Uri uri) {

                    }
                });
        arrayList = getMediaPaths(SharedPrefs.getsortingtype(this), SharedPrefs.getIsSortingAcs(this));
        adapter = new MediaAdapter(arrayList, this);
        recyclerView.setAdapter(adapter);
    }

    private ArrayList<MediaModel> getMediaPaths(String sortBy, boolean isAscending) {
        ArrayList<MediaModel> mediaList = new ArrayList<>();
        ArrayList<String> mediaPaths = new ArrayList<>();
        Uri allMediaUri = MediaStore.Files.getContentUri("external");

        String[] projection = {MediaStore.Files.FileColumns.DATA, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.BUCKET_DISPLAY_NAME, MediaStore.Files.FileColumns.MEDIA_TYPE, MediaStore.Files.FileColumns.SIZE, MediaStore.Images.Media.DATE_TAKEN, MediaStore.Files.FileColumns.DATE_MODIFIED};

        String selection = MediaStore.Files.FileColumns.MEDIA_TYPE + " = ? OR " + MediaStore.Files.FileColumns.MEDIA_TYPE + " = ?";
        String[] selectionArgs = {String.valueOf(MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE), String.valueOf(MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO)};

        Cursor cursor = getContentResolver().query(allMediaUri, projection, selection, selectionArgs, null);

        try {
            if (cursor != null) {
                cursor.moveToFirst();
            }
            do {
                MediaModel mediaModel = new MediaModel();
                String name = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME));
                String folder = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME));
                String dataPath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA));
                int mediaType = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE));
                long fileSize = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE));
                long dateTaken = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN));
                long dateModified = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED));

                String folderPath = dataPath.substring(0, dataPath.lastIndexOf(folder + "/"));
                folderPath = folderPath + folder + "/";

                if (!mediaPaths.contains(folderPath)) {
                    mediaPaths.add(folderPath);
                    mediaModel.setPath(folderPath);
                    mediaModel.setFolderName(folder);
                    mediaModel.setFirstMediaPath(dataPath);
                    mediaModel.addMedia();
                    mediaModel.setFolderSize(fileSize);
                    mediaModel.setDateTaken(dateTaken);
                    mediaModel.setLastModified(dateModified);
                    mediaList.add(mediaModel);
                } else {
                    for (int i = 0; i < mediaList.size(); i++) {
                        mediaModel = mediaList.get(i);
                        if (mediaModel.getPath().equals(folderPath)) {
                            mediaModel.setFirstMediaPath(dataPath);
                            mediaModel.addMedia();
                            mediaModel.setFolderSize(mediaModel.getFolderSize() + fileSize);
                            mediaModel.setDateTaken(dateTaken);
                            mediaModel.setLastModified(dateModified);
                        }
                    }
                }
            } while (cursor.moveToNext());

            // Sort the mediaList based on the selected criteria
            sortMediaList(mediaList, sortBy, isAscending);

            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mediaList;
    }

    private void sortMediaList(ArrayList<MediaModel> mediaList, String sortBy, boolean isAscending) {
        Comparator<MediaModel> comparator;

        switch (sortBy) {
            case "name":
                comparator = Comparator.comparing(MediaModel::getFolderName);
                break;
            case "size":
                comparator = Comparator.comparing(MediaModel::getSize);
                break;
            case "date_taken":
                comparator = Comparator.comparing(MediaModel::getDateTaken);
                break;
            case "last_modified":
                comparator = Comparator.comparing(MediaModel::getLastModified);
                break;
            default:
                comparator = Comparator.comparing(MediaModel::getDisplayName);
                break;
        }

        if (!isAscending) {
            comparator = comparator.reversed();
        }
        Collections.sort(mediaList, comparator);
    }


    private void showbottomdialog(Activity activity) {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this, R.style.BottomSheetDialogTheme);
        bottomSheetDialog.setContentView(R.layout.sorting_buttom_dialog);

        bottomSheetDialog.setCancelable(false);

        TextView btnname = bottomSheetDialog.findViewById(R.id.btnname);
        TextView btnsize = bottomSheetDialog.findViewById(R.id.btnsize);
        TextView btndateken = bottomSheetDialog.findViewById(R.id.btndateken);
        TextView btnlastmodified = bottomSheetDialog.findViewById(R.id.btnlastmodified);
        TextView btnascending = bottomSheetDialog.findViewById(R.id.btnascending);
        TextView btndescending = bottomSheetDialog.findViewById(R.id.btndescending);
        TextView btncancel = bottomSheetDialog.findViewById(R.id.btncancel);
        TextView btnok = bottomSheetDialog.findViewById(R.id.btnok);

        String sortingType = SharedPrefs.getsortingtype(activity);

        btnname.setTextColor(ContextCompat.getColor(this, sortingType.equals("name") ? R.color.colorPrimary : R.color.black));
        btnsize.setTextColor(ContextCompat.getColor(this, sortingType.equals("size") ? R.color.colorPrimary : R.color.black));
        btndateken.setTextColor(ContextCompat.getColor(this, sortingType.equals("date_taken") ? R.color.colorPrimary : R.color.black));
        btnlastmodified.setTextColor(ContextCompat.getColor(this, sortingType.equals("last_modified") ? R.color.colorPrimary : R.color.black));

        boolean isSortingAscending = SharedPrefs.getIsSortingAcs(activity);

        btnascending.setTextColor(ContextCompat.getColor(this, isSortingAscending ? R.color.colorPrimary : R.color.black));
        btndescending.setTextColor(ContextCompat.getColor(this, isSortingAscending ? R.color.black : R.color.colorPrimary));

        btnname.setOnClickListener(view -> {
            SharedPrefs.setsortingtype(activity, "name");
            btnname.setTextColor(ContextCompat.getColor(this, R.color.colorPrimary));
            btnsize.setTextColor(ContextCompat.getColor(this, R.color.black));
            btndateken.setTextColor(ContextCompat.getColor(this, R.color.black));
            btnlastmodified.setTextColor(ContextCompat.getColor(this, R.color.black));
        });
        btnsize.setOnClickListener(view -> {
            SharedPrefs.setsortingtype(activity, "size");
            btnname.setTextColor(ContextCompat.getColor(this, R.color.black));
            btnsize.setTextColor(ContextCompat.getColor(this, R.color.colorPrimary));
            btndateken.setTextColor(ContextCompat.getColor(this, R.color.black));
            btnlastmodified.setTextColor(ContextCompat.getColor(this, R.color.black));
        });
        btndateken.setOnClickListener(view -> {
            SharedPrefs.setsortingtype(activity, "date_taken");
            btnname.setTextColor(ContextCompat.getColor(this, R.color.black));
            btnsize.setTextColor(ContextCompat.getColor(this, R.color.black));
            btndateken.setTextColor(ContextCompat.getColor(this, R.color.colorPrimary));
            btnlastmodified.setTextColor(ContextCompat.getColor(this, R.color.black));
        });
        btnlastmodified.setOnClickListener(view -> {
            SharedPrefs.setsortingtype(activity, "last_modified");
            btnname.setTextColor(ContextCompat.getColor(this, R.color.black));
            btnsize.setTextColor(ContextCompat.getColor(this, R.color.black));
            btndateken.setTextColor(ContextCompat.getColor(this, R.color.black));
            btnlastmodified.setTextColor(ContextCompat.getColor(this, R.color.colorPrimary));
        });
        btnascending.setOnClickListener(view -> {
            SharedPrefs.setIsSortingAcs(activity, true);
            btnascending.setTextColor(ContextCompat.getColor(this, R.color.colorPrimary));
            btndescending.setTextColor(ContextCompat.getColor(this, R.color.black));
        });
        btndescending.setOnClickListener(view -> {
            SharedPrefs.setIsSortingAcs(activity, false);
            btnascending.setTextColor(ContextCompat.getColor(this, R.color.black));
            btndescending.setTextColor(ContextCompat.getColor(this, R.color.colorPrimary));
        });
        btncancel.setOnClickListener(view -> {
            bottomSheetDialog.dismiss();
        });
        btnok.setOnClickListener(view -> {
            onResume();
            bottomSheetDialog.dismiss();
        });
        bottomSheetDialog.show();
    }

    private void setPopUpWindow(FolderActivity mainActivity) {
        LayoutInflater inflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view1 = inflater.inflate(R.layout.menu_list_item, null);

        TextView selectitem = view1.findViewById(R.id.selectitem);
        TextView newfolder = view1.findViewById(R.id.newfolder);
        TextView setting = view1.findViewById(R.id.setting);
        TextView recyclebin = view1.findViewById(R.id.recyclebin);
        TextView favourites = view1.findViewById(R.id.favourites);
        TextView safefolder = view1.findViewById(R.id.safefolder);

        if (new SharedPrefs().getchackfregment(FolderActivity.this) == 0) {
            selectitem.setVisibility(View.VISIBLE);
            newfolder.setVisibility(View.GONE);
        } else if (new SharedPrefs().getchackfregment(FolderActivity.this) == 1) {
            selectitem.setVisibility(View.GONE);
            newfolder.setVisibility(View.VISIBLE);
        }

        selectitem.setVisibility(View.GONE);
        newfolder.setVisibility(View.VISIBLE);
        selectitem.setOnClickListener(view -> {
            Toast.makeText(mainActivity, "selectitem", Toast.LENGTH_SHORT).show();
            mypopupWindow.dismiss();
        });
        newfolder.setOnClickListener(view -> {
            Toast.makeText(mainActivity, "newfolder", Toast.LENGTH_SHORT).show();
            mypopupWindow.dismiss();
        });
        setting.setOnClickListener(view -> {
            mypopupWindow.dismiss();
            Intent intent = new Intent(FolderActivity.this, SettingActivity.class);
            startActivity(intent);
        });
        recyclebin.setOnClickListener(view -> {
            mypopupWindow.dismiss();
            Intent intent = new Intent(getApplicationContext(), RecyclebinmainActivity.class);
            intent.putExtra("selectedFolderPath", "/data/user/0/com.hdphotosgallery.safephotos/files/hideFolders/Videos");
            startActivity(intent);
        });
        favourites.setOnClickListener(view -> {
            mypopupWindow.dismiss();
            Intent intent = new Intent(FolderActivity.this, FavoriteActivity.class);
            startActivity(intent);
        });
        safefolder.setOnClickListener(view -> {
            if (SharedPrefs.getIsPasswordSet(getApplicationContext())) {
                mypopupWindow.dismiss();
                Intent intent = new Intent(FolderActivity.this, MainPasswordActivity.class);
                startActivity(intent);
            } else {
                mypopupWindow.dismiss();
                Intent intent = new Intent(FolderActivity.this, CreatePasswordActivity.class);
                startActivity(intent);
            }
        });
        mypopupWindow = new PopupWindow(view1, RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT, true);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private void hideCardViewWithAnimation() {
        if (isCardVisible) {
            cardView.animate().translationY(cardView.getHeight()).alpha(0.0f);
            isCardVisible = false;
        }
    }

    private void showCardViewWithAnimation() {
        if (!isCardVisible) {
            cardView.animate().translationY(0).alpha(1.0f);
            isCardVisible = true;
        }
    }

    private void showCustomDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.new_folder_dialoglayout, null);
        builder.setView(dialogView);

        final EditText etFolderName = dialogView.findViewById(R.id.etFolderName);

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                String folderName = etFolderName.getText().toString().trim();
                createFolderAndSelectMedia(folderName);
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });

        builder.show();
    }

    private void createFolderAndSelectMedia(String folderName) {
        // Create the folder on the external storage
        File folder = new File(Environment.getExternalStorageDirectory(), folderName);
        if (!folder.exists()) {
            folder.mkdirs();
            Log.d("dd", "createFolderAndSelectMedia: " + folder);
        }

        // Save the folder path
        selectedFolderPath = folder.getAbsolutePath();

        // Open the system file picker for selecting images and videos
        Intent mediaIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        mediaIntent.addCategory(Intent.CATEGORY_OPENABLE);
        mediaIntent.setType("image/* video/*");
        startActivityForResult(mediaIntent, REQUEST_CODE_SELECT_MEDIA);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_SELECT_MEDIA && resultCode == Activity.RESULT_OK) {
            ClipData clipData = data.getClipData();
            if (clipData != null) {
                int count = clipData.getItemCount();
                for (int i = 0; i < count; i++) {
                    Uri mediaUri = clipData.getItemAt(i).getUri();
                    copyMediaToFolder(mediaUri, selectedFolderPath);
                }
            } else {
                // Single item selection
                Uri mediaUri = data.getData();
                copyMediaToFolder(mediaUri, selectedFolderPath);
            }
        }
    }

    private void copyMediaToFolder(Uri mediaUri, String folderPath) {
        if (folderPath == null) {
            // Handle the case where the folder path is null
            Toast.makeText(this, "Error: Folder path is null", Toast.LENGTH_SHORT).show();
            return;
        }

        File folder = new File(folderPath);
        if (!folder.exists()) {
            if (!folder.mkdirs()) {
                // Handle the case where folder creation failed
                Toast.makeText(this, "Error: Failed to create folder", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        String fileName = getDisplayNameFromUri(mediaUri);
        if (fileName == null) {
            // Handle the case where the file name is null
            Toast.makeText(this, "Error: File name is null", Toast.LENGTH_SHORT).show();
            return;
        }

        File destinationFile = new File(folder, fileName);

        try (FileChannel sourceChannel = new FileInputStream(getRealPathFromUri(mediaUri)).getChannel();
             FileChannel destinationChannel = new FileOutputStream(destinationFile).getChannel()) {

            destinationChannel.transferFrom(sourceChannel, 0, sourceChannel.size());

            // Notify the media scanner about the new file
            MediaScannerConnection.scanFile(
                    this,
                    new String[]{destinationFile.getAbsolutePath()},
                    null,
                    new MediaScannerConnection.OnScanCompletedListener() {
                        @Override
                        public void onScanCompleted(String path, Uri uri) {
                            // The scanning is complete; you can now update the UI or take other actions.
                            loadFolderContent();
                        }
                    });

            Toast.makeText(this, "Media copied to folder", Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error copying media to folder", Toast.LENGTH_SHORT).show();
        }
    }


    private String getRealPathFromUri(Uri uri) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            if (inputStream != null) {
                File file = createTempFileFromInputStream(inputStream);
                return file.getAbsolutePath();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private File createTempFileFromInputStream(InputStream inputStream) throws IOException {
        File tempFile = File.createTempFile("temp_file", null, getCacheDir());
        try (FileOutputStream out = new FileOutputStream(tempFile)) {
            byte[] buffer = new byte[4 * 1024];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        }
        return tempFile;
    }

    private String getDisplayNameFromUri(Uri uri) {
        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
        if (cursor != null) {
            int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            cursor.moveToFirst();
            String name = cursor.getString(nameIndex);
            cursor.close();
            return name;
        }
        return null;
    }

    public void loadFolderContent() {
        folderContentList.clear();

        // Load the content of the folder
        File folder = new File(selectedFolderPath);
        File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
                folderContentList.add(file.getName());
            }
        }

        // Notify the adapter that the data set has changed
        adapter.notifyDataSetChanged();
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        finishAffinity();
    }
}