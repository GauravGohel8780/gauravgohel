package com.hdphotosgallery.safephotos.SafeFile.SafeClass.Database;

import android.content.Context;
import android.content.SharedPreferences;

/* loaded from: classes2.dex */
public class Pref {
    private static SharedPreferences sharedPreferences;

    private static void openPref(Context context) {
        sharedPreferences = context.getSharedPreferences("MY_PREFS", 0);
    }

    public static String getStringValue(Context context, String str, String str2) {
        openPref(context);
        String string = sharedPreferences.getString(str, str2);
        sharedPreferences = null;
        return string;
    }

    public static void setStringValue(Context context, String str, String str2) {
        openPref(context);
        SharedPreferences.Editor edit = sharedPreferences.edit();
        edit.putString(str, str2);
        edit.apply();
        sharedPreferences = null;
    }

    public static void setIntValue(Context context, String str, int i) {
        openPref(context);
        SharedPreferences.Editor edit = sharedPreferences.edit();
        edit.putInt(str, i);
        edit.apply();
        sharedPreferences = null;
    }

    public static int getIntValue(Context context, String str, int i) {
        openPref(context);
        int i2 = sharedPreferences.getInt(str, i);
        sharedPreferences = null;
        return i2;
    }

    public static boolean getBooleanValue(Context context, String str, boolean z) {
        openPref(context);
        boolean z2 = sharedPreferences.getBoolean(str, z);
        sharedPreferences = null;
        return z2;
    }

    public static void setBooleanValue(Context context, String str, boolean z) {
        openPref(context);
        SharedPreferences.Editor edit = sharedPreferences.edit();
        edit.putBoolean(str, z);
        edit.apply();
        sharedPreferences = null;
    }
}
