package com.hdphotosgallery.safephotos.SafeFile.LockClass;

public interface ItemClickListener {

    void onItemClicked(String item);

}
