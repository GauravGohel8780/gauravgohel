package com.hdphotosgallery.safephotos.SafeFile.SafeClass.adapters;

import android.app.Activity;
import android.content.Context;
import android.media.ThumbnailUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Calc_HideItemActivity;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model.FolderModel;

import java.util.ArrayList;
import java.util.Iterator;

public class Calc_HideItemAdapter extends RecyclerView.Adapter<Calc_HideItemAdapter.ViewHolder> {
    private static ArrayList<FolderModel> list;
    private Activity activity;
    private OnClickListener onClickListener;

    public interface OnClickListener {
        void OnClick(int i, int i2);
    }

    public Calc_HideItemAdapter(Activity activity, ArrayList<FolderModel> arrayList, OnClickListener onClickListener) {
        this.activity = activity;
        list = arrayList;
        this.onClickListener = onClickListener;
    }

    public void newList(ArrayList<FolderModel> arrayList) {
        list = arrayList;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(((LayoutInflater) this.activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.hide_item, (ViewGroup) null));
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int i) {
        if (list.get(i).isSelected()) {
            viewHolder.imgSelected.setVisibility(View.VISIBLE);
        } else {
            viewHolder.imgSelected.setVisibility(View.GONE);
        }
        if (list.get(i).getPath().contains(".mp4")) {
            viewHolder.videoPlay.setVisibility(View.VISIBLE);
            Glide.with(this.activity).asBitmap().load(ThumbnailUtils.createVideoThumbnail(list.get(i).getPath(), 3)).into(viewHolder.image);
            viewHolder.fileName.setVisibility(View.GONE);
        } else if (list.get(i).getName().endsWith(".pdf")) {
            Glide.with(this.activity).load(Integer.valueOf((int) R.drawable.pdf_icon)).into(viewHolder.image);
            viewHolder.fileName.setVisibility(View.VISIBLE);
            viewHolder.fileName.setText(list.get(i).getName());
        } else if (list.get(i).getName().endsWith(".docx") || list.get(i).getName().endsWith(".doc")) {
            Glide.with(this.activity).load(Integer.valueOf((int) R.drawable.wordpress_icon)).into(viewHolder.image);
            viewHolder.fileName.setVisibility(View.VISIBLE);
            viewHolder.fileName.setText(list.get(i).getName());
        } else if (list.get(i).getName().endsWith(".xlsx") || list.get(i).getName().endsWith(".xls")) {
            Glide.with(this.activity).load(Integer.valueOf((int) R.drawable.xml_icon)).into(viewHolder.image);
            viewHolder.fileName.setVisibility(View.VISIBLE);
            viewHolder.fileName.setText(list.get(i).getName());
        } else if (list.get(i).getName().endsWith(".txt")) {
            Glide.with(this.activity).load(Integer.valueOf((int) R.drawable.text_icon_copy)).into(viewHolder.image);
            viewHolder.fileName.setVisibility(View.VISIBLE);
            viewHolder.fileName.setText(list.get(i).getName());
        } else if (list.get(i).getName().endsWith(".ppt") || list.get(i).getName().endsWith(".pptx")) {
            Glide.with(this.activity).load(Integer.valueOf((int) R.drawable.ppt_icon_copy)).into(viewHolder.image);
            viewHolder.fileName.setVisibility(View.VISIBLE);
            viewHolder.fileName.setText(list.get(i).getName());
        } else {
            viewHolder.videoPlay.setVisibility(View.GONE);
            Glide.with(this.activity).load(list.get(i).getPath()).into(viewHolder.image);
            viewHolder.fileName.setVisibility(View.GONE);
        }

        viewHolder.image.setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.adapter.HideItemAdapter.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (Calc_HideItemActivity.itemSelected) {
                    if (((FolderModel) Calc_HideItemAdapter.list.get(i)).isSelected()) {
                        Calc_HideItemActivity.count--;
                        ((FolderModel) Calc_HideItemAdapter.list.get(i)).setSelected(false);
                        viewHolder.imgSelected.setVisibility(View.GONE);
                    } else {
                        Calc_HideItemActivity.count++;
                        ((FolderModel) Calc_HideItemAdapter.list.get(i)).setSelected(true);
                        viewHolder.imgSelected.setVisibility(View.VISIBLE);
                    }
                    Calc_HideItemActivity.toolbar.setTitle(Calc_HideItemActivity.count + " selected");
                    Calc_HideItemAdapter.this.notifyDataSetChanged();
                    return;
                }
                Calc_HideItemAdapter.this.onClickListener.OnClick(1, i);
            }
        });

        viewHolder.image.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                Calc_HideItemActivity.no_selectall = false;
                Calc_HideItemActivity.editLayout.setVisibility(View.VISIBLE);
                Calc_HideItemActivity.itemSelected = true;
                if (((FolderModel) Calc_HideItemAdapter.list.get(i)).isSelected()) {
                    Calc_HideItemActivity.count--;
                    ((FolderModel) Calc_HideItemAdapter.list.get(i)).setSelected(false);
                    viewHolder.imgSelected.setVisibility(View.GONE);
                } else {
                    Calc_HideItemActivity.count++;
                    ((FolderModel) Calc_HideItemAdapter.list.get(i)).setSelected(true);
                    viewHolder.imgSelected.setVisibility(View.VISIBLE);
                }
                Calc_HideItemActivity.toolbar.setTitle(Calc_HideItemActivity.count + " selected");
                Calc_HideItemAdapter.this.notifyDataSetChanged();
                return true;
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView fileName;
        ImageView image;
        RelativeLayout imgSelected;
        ImageView videoPlay;
        ViewHolder(View view) {
            super(view);
            this.image = (ImageView) view.findViewById(R.id.image);
            this.imgSelected = (RelativeLayout) view.findViewById(R.id.img_selected);
            this.videoPlay = (ImageView) view.findViewById(R.id.video_play);
            this.fileName = (TextView) view.findViewById(R.id.file_name);
        }
    }

    public static void clearSelection() {
        Iterator<FolderModel> it = list.iterator();
        while (it.hasNext()) {
            it.next().isSelected = false;
        }
    }

    public ArrayList<FolderModel> getSelectedList() {
        ArrayList<FolderModel> arrayList = new ArrayList<>();
        for (int i = 0; i <= list.size() - 1; i++) {
            if (list.get(i).isSelected()) {
                arrayList.add(list.get(i));
            }
        }
        return arrayList;
    }
}
