package com.hdphotosgallery.safephotos.GalleryGroping;


import java.util.ArrayList;

public interface OnItemClickListener {
    void onItemClick(PhotoListModel model, int position, ArrayList<PhotoListModel> arrayList);
}