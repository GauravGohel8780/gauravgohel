package com.hdphotosgallery.safephotos.SafeFile.LockClass;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.hdphotosgallery.safephotos.PhotosGroping.AllPhotosActivity;
import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.patternlockview.ForgetActivity;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.patternlockview.PatternLockView;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.patternlockview.listener.PatternLockViewListener;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.patternlockview.utils.PatternLockUtils;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.SafeFileMainActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainPasswordActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    PatternLockView patternLockView;
    String password;
    TextView forgetPassword, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn0;


    View view1, view2, view3, view4;
    LinearLayout btnclear, patternlock, pinlock;

    String passcode = "";
    String num1, num2, num3, num4;
    int count = 0;
    BottomSheetDialog bottomSheetDialog;
    ArrayList<String> number_list = new ArrayList<>();
    List<Integer> generated = new ArrayList<Integer>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_password);
        bottomSheetDialog = new BottomSheetDialog(this);

        if (SharedPrefs.getSecurityQuestionAnswer(MainPasswordActivity.this).isEmpty()) {
            showdialog();
        }

        patternLockView = findViewById(R.id.pattern);
        patternlock = findViewById(R.id.patternlock);
        pinlock = findViewById(R.id.pinlock);

        findViewById(R.id.backprees).setOnClickListener(view -> {
            Intent intent = new Intent(MainPasswordActivity.this, AllPhotosActivity.class);
            startActivity(intent);
        });

        forgetPassword = findViewById(R.id.forgetPassword);

        view1 = findViewById(R.id.view1);
        view2 = findViewById(R.id.view2);
        view3 = findViewById(R.id.view3);
        view4 = findViewById(R.id.view4);


        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);
        btn6 = findViewById(R.id.btn6);
        btn7 = findViewById(R.id.btn7);
        btn8 = findViewById(R.id.btn8);
        btn9 = findViewById(R.id.btn9);
        btn0 = findViewById(R.id.btn0);
        btnclear = findViewById(R.id.btncancel);

        btnclear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                number_list.clear();
                passnumber(number_list);
            }
        });

        forgetPassword.setPaintFlags(forgetPassword.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);

        forgetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmDialog();
            }
        });


        password = SharedPrefs.getPatternData(getApplicationContext());

        patternLockView.addPatternLockListener(new PatternLockViewListener() {
            @Override
            public void onStarted() {

            }

            @Override
            public void onProgress(List<PatternLockView.Dot> progressPattern) {

            }

            @Override
            public void onComplete(List<PatternLockView.Dot> pattern) {
                count++;
                if (PatternLockUtils.patternToString(patternLockView, pattern).length() >= 4) {
                    if (password.equals(PatternLockUtils.patternToString(patternLockView, pattern))) {
                        Intent intent = new Intent(MainPasswordActivity.this, SafeFileMainActivity.class);
                        startActivity(intent);
                        patternLockView.clearPattern();
                    } else {
                        Toast.makeText(MainPasswordActivity.this, "Wrong password !", Toast.LENGTH_SHORT).show();
                        patternLockView.clearPattern();
                    }
                } else {
                    Toast.makeText(MainPasswordActivity.this, "Plz Connect 4 dot..", Toast.LENGTH_SHORT).show();
                    patternLockView.clearPattern();
                }


                if (count <= 3) {
                    forgetPassword.setVisibility(View.VISIBLE);
                } else {
                    forgetPassword.setVisibility(View.GONE);
                }

            }

            @Override
            public void onCleared() {

            }
        });


        randomnumber();

        addNumber(btn0, "0");
        addNumber(btn1, "1");
        addNumber(btn2, "2");
        addNumber(btn3, "3");
        addNumber(btn4, "4");
        addNumber(btn5, "5");
        addNumber(btn6, "6");
        addNumber(btn7, "7");
        addNumber(btn8, "8");
        addNumber(btn9, "9");


        if (SharedPrefs.getLockFinalType(getApplicationContext()).equalsIgnoreCase("PIN")) {
            pinlock.setVisibility(View.VISIBLE);
            patternlock.setVisibility(View.GONE);
        } else {
            pinlock.setVisibility(View.GONE);
            patternlock.setVisibility(View.VISIBLE);
        }

    }

    public static Bitmap drawableToBitmap(Drawable drawable) {
        Bitmap bitmap = null;

        if (drawable instanceof BitmapDrawable) {
            BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;
            if (bitmapDrawable.getBitmap() != null) {
                return bitmapDrawable.getBitmap();
            }
        }

        if (drawable.getIntrinsicWidth() <= 0 || drawable.getIntrinsicHeight() <= 0) {
            bitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888); // Single color bitmap will be created of 1x1 pixel
        } else {
            bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        }

        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return bitmap;
    }


    private void confirmDialog() {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setContentView(R.layout.security_confirm_dialog);

        RelativeLayout rlv = bottomSheetDialog.findViewById(R.id.rlv);
        ImageView cancel = bottomSheetDialog.findViewById(R.id.cancel);
        TextView ConfirmQuestion = bottomSheetDialog.findViewById(R.id.ConfirmQuestion);
        EditText ConfirmEdit = bottomSheetDialog.findViewById(R.id.ConfirmEdit);
        AppCompatButton confirm = bottomSheetDialog.findViewById(R.id.confirm);


        ConfirmQuestion.setText(SharedPrefs.getSecurityQuestion(getApplicationContext()));

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomSheetDialog.dismiss();
            }
        });

        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ConfirmEdit.getText().toString().equals(SharedPrefs.getSecurityQuestionAnswer(getApplicationContext()))) {
                    Toast.makeText(MainPasswordActivity.this, "SuccessFully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(MainPasswordActivity.this, ForgetActivity.class));
                    if (SharedPrefs.getLockFinalType(MainPasswordActivity.this).equalsIgnoreCase("Pattern")) {
                        SharedPrefs.setLockType(MainPasswordActivity.this, "Pattern");
                        startActivity(new Intent(MainPasswordActivity.this, ForgetActivity.class));
                    } else {
                        SharedPrefs.setLockType(MainPasswordActivity.this, "PIN");
                        startActivity(new Intent(MainPasswordActivity.this, ForgetActivity.class));
                    }
                } else {
                    Toast.makeText(MainPasswordActivity.this, "Enter a Valid answer", Toast.LENGTH_SHORT).show();
                }
            }
        });

        bottomSheetDialog.show();
    }


    private void randomnumber() {
        Random rng = new Random();
        for (int i = 0; i < 10; i++) {
            while (true) {
                Integer next = rng.nextInt(10);
                if (!generated.contains(next)) {
                    generated.add(next);
                    break;
                }
            }
        }

    }

    public void addRandomNumber(TextView button, int randomNumber) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                number_list.add(String.valueOf(randomNumber));
                passnumber(number_list);
            }
        });
    }

    public void addNumber(TextView button, String number) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                number_list.add(number);
                passnumber(number_list);
            }
        });
    }

    private void passnumber(ArrayList<String> number_list) {

        if (number_list.size() == 0) {
            view1.setBackgroundResource(R.drawable.bg_view_2);
            view2.setBackgroundResource(R.drawable.bg_view_2);
            view3.setBackgroundResource(R.drawable.bg_view_2);
            view4.setBackgroundResource(R.drawable.bg_view_2);
        } else {
            switch (number_list.size()) {
                case 1:
                    num1 = number_list.get(0);
                    view1.setBackgroundResource(R.drawable.bg_view_1);
                    break;
                case 2:
                    num2 = number_list.get(1);
                    view2.setBackgroundResource(R.drawable.bg_view_1);
                    break;
                case 3:
                    num3 = number_list.get(2);
                    view3.setBackgroundResource(R.drawable.bg_view_1);
                    break;
                case 4:
                    num4 = number_list.get(3);
                    view4.setBackgroundResource(R.drawable.bg_view_1);
                    passcode = num1 + num2 + num3 + num4;

                    count++;

                    if (passcode.equals(SharedPrefs.getPinData(getApplicationContext()))) {
                        Intent intent = new Intent(MainPasswordActivity.this, SafeFileMainActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(this, "Enter a Valid PIN", Toast.LENGTH_SHORT).show();
                    }

                    if (count == 3) {
                        forgetPassword.setVisibility(View.VISIBLE);
                    } else {
                        forgetPassword.setVisibility(View.GONE);
                    }

                    break;

            }
        }
    }

    private void showdialog() {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setContentView(R.layout.security_question_dialog);

        bottomSheetDialog.setCancelable(false);
        Spinner SpinnerTextSize = bottomSheetDialog.findViewById(R.id.SpinnerTextSize);
        AppCompatButton save = bottomSheetDialog.findViewById(R.id.save);
        EditText edit = bottomSheetDialog.findViewById(R.id.edit);


        SpinnerTextSize.setOnItemSelectedListener(MainPasswordActivity.this);

        String[] textsize = getResources().getStringArray(R.array.font_sizes);
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, textsize);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SpinnerTextSize.setAdapter(adapter);


        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (edit.getText().toString().isEmpty()) {
                    Toast.makeText(MainPasswordActivity.this, "Please Enter Answer..", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainPasswordActivity.this, "Saved Successfully.", Toast.LENGTH_SHORT).show();
                    bottomSheetDialog.dismiss();
                }

                String Question = edit.getText().toString();

                SharedPrefs.setSecurityQuestionAnswer(MainPasswordActivity.this, Question);
            }
        });


        bottomSheetDialog.show();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
        if (parent.getId() == R.id.SpinnerTextSize) {
            String valueFromSpinner = parent.getItemAtPosition(i).toString();
            SharedPrefs.setSecurityQuestion(this, valueFromSpinner);

        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        Intent intent = new Intent(MainPasswordActivity.this, AllPhotosActivity.class);
        startActivity(intent);
    }
}