package com.hdphotosgallery.safephotos.PhotosGroping;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class MediaItem implements Parcelable {
    private String filePath;
    private int mediaType;
    private long dateTaken;
    private long lastModified;

    public MediaItem(String filePath, int mediaType, long dateTaken, long lastModified) {
        this.filePath = filePath;
        this.mediaType = mediaType;
        this.dateTaken = dateTaken;
        this.lastModified = lastModified;
    }

    protected MediaItem(Parcel in) {
        filePath = in.readString();
        mediaType = in.readInt();
        dateTaken = in.readLong();
        lastModified = in.readLong();
    }

    public MediaItem() {
    }

    public static final Creator<MediaItem> CREATOR = new Creator<MediaItem>() {
        @Override
        public MediaItem createFromParcel(Parcel in) {
            return new MediaItem(in);
        }

        @Override
        public MediaItem[] newArray(int size) {
            return new MediaItem[size];
        }
    };

    public String getFilePath() {
        return filePath;
    }

    public int getMediaType() {
        return mediaType;
    }

    public long getDateTaken() {
        return dateTaken;
    }

    public long getLastModified() {
        return lastModified;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(filePath);
        parcel.writeInt(mediaType);
        parcel.writeLong(dateTaken);
        parcel.writeLong(lastModified);
    }
}
