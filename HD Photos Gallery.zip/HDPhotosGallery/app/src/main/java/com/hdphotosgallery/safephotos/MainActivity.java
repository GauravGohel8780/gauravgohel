package com.hdphotosgallery.safephotos;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.tabs.TabLayout;
import com.hdphotosgallery.safephotos.FavoriteClass.FavoriteActivity;
import com.hdphotosgallery.safephotos.PhotosGroping.AllPhotosFragment;
import com.hdphotosgallery.safephotos.PhotosGroping.FolderFragment;
import com.hdphotosgallery.safephotos.RecyclebinCLASS.RecyclebinmainActivity;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.CreatePasswordActivity;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.MainPasswordActivity;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.SharedPrefs;
import com.ismaeldivita.chipnavigation.ChipNavigationBar;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    PopupWindow mypopupWindow;
    ImageView menudialog;
    BottomSheetDialog bottomSheetDialog;
    RelativeLayout rl1;
    ChipNavigationBar chipNavigationBar;
    ViewPager viewPager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bottomSheetDialog = new BottomSheetDialog(this, R.style.BottomSheetDialogTheme);
        setPopUpWindow(this);
        menudialog = findViewById(R.id.menudialog);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                findViewById(R.id.progresh).setVisibility(View.GONE);
            }
        }, 5000);
        menudialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mypopupWindow.showAsDropDown(view, -100, 0);
            }
        });


        viewPager = findViewById(R.id.viewPager);
        chipNavigationBar = findViewById(R.id.chipNavigationBar);
        TabLayout tabLayout = findViewById(R.id.tabLayout);


        MyPagerAdapter pagerAdapter = new MyPagerAdapter(getSupportFragmentManager());
        pagerAdapter.addFragment(new AllPhotosFragment());
        pagerAdapter.addFragment(new FolderFragment());
        viewPager.setAdapter(pagerAdapter);

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if (position == 0) {
                    chipNavigationBar.setItemSelected(R.id.home1, true);
                    new SharedPrefs().setchackfregment(MainActivity.this, 0);
                    setPopUpWindow(MainActivity.this);
                } else if (position == 1) {
                    chipNavigationBar.setItemSelected(R.id.cart1, true);
                    new SharedPrefs().setchackfregment(MainActivity.this, 1);
                    setPopUpWindow(MainActivity.this);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        tabLayout.setupWithViewPager(viewPager);
        chipNavigationBar.setOnItemSelectedListener(new ChipNavigationBar.OnItemSelectedListener() {
            @Override
            public void onItemSelected(int i) {
                if (i == R.id.home1) {
                    viewPager.setCurrentItem(0);
                    new SharedPrefs().setchackfregment(MainActivity.this, 0);
                    setPopUpWindow(MainActivity.this);
                } else if (i == R.id.cart1) {
                    viewPager.setCurrentItem(1);
                    new SharedPrefs().setchackfregment(MainActivity.this, 1);
                    setPopUpWindow(MainActivity.this);
                }
                // Add more conditions as needed
            }
        });
    }

    private void setPopUpWindow(MainActivity mainActivity) {
        LayoutInflater inflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view1 = inflater.inflate(R.layout.menu_list_item, null);

        TextView selectitem = view1.findViewById(R.id.selectitem);
        TextView newfolder = view1.findViewById(R.id.newfolder);
        TextView setting = view1.findViewById(R.id.setting);
        TextView recyclebin = view1.findViewById(R.id.recyclebin);
        TextView favourites = view1.findViewById(R.id.favourites);
        TextView safefolder = view1.findViewById(R.id.safefolder);

        if (new SharedPrefs().getchackfregment(MainActivity.this) == 0) {
            selectitem.setVisibility(View.VISIBLE);
            newfolder.setVisibility(View.GONE);
        }
        else if (new SharedPrefs().getchackfregment(MainActivity.this) == 1) {
            selectitem.setVisibility(View.GONE);
            newfolder.setVisibility(View.VISIBLE);
        }

        selectitem.setOnClickListener(view -> {
            Toast.makeText(mainActivity, "selectitem", Toast.LENGTH_SHORT).show();
            mypopupWindow.dismiss();
        });
        newfolder.setOnClickListener(view -> {
            Toast.makeText(mainActivity, "newfolder", Toast.LENGTH_SHORT).show();
            mypopupWindow.dismiss();
        });
        setting.setOnClickListener(view -> {
            mypopupWindow.dismiss();
        });
        recyclebin.setOnClickListener(view -> {
            mypopupWindow.dismiss();
            Intent intent = new Intent(getApplicationContext(), RecyclebinmainActivity.class);
            intent.putExtra("selectedFolderPath", "/data/user/0/com.hdphotosgallery.safephotos/files/hideFolders/Videos");
            startActivity(intent);
        });
        favourites.setOnClickListener(view -> {
            mypopupWindow.dismiss();
            Intent intent = new Intent(MainActivity.this, FavoriteActivity.class);
            startActivity(intent);
        });
        safefolder.setOnClickListener(view -> {
            if (SharedPrefs.getIsPasswordSet(getApplicationContext())) {
                mypopupWindow.dismiss();
                Intent intent = new Intent(MainActivity.this, MainPasswordActivity.class);
                startActivity(intent);
            } else {
                mypopupWindow.dismiss();
                Intent intent = new Intent(MainActivity.this, CreatePasswordActivity.class);
                startActivity(intent);
            }
        });

        mypopupWindow = new PopupWindow(view1, RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT, true);

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (new SharedPrefs().getchackfregment(MainActivity.this) == 0) {
            viewPager.setCurrentItem(0);
            chipNavigationBar.setItemSelected(R.id.home1, true);
        } else if (new SharedPrefs().getchackfregment(MainActivity.this) == 1) {
            viewPager.setCurrentItem(1);
            chipNavigationBar.setItemSelected(R.id.cart1, true);
        }
    }

    public class MyPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> fragmentList = new ArrayList<>();

        public MyPagerAdapter(@NonNull FragmentManager fm) {
            super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        }

        public void addFragment(Fragment fragment) {
            fragmentList.add(fragment);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            return fragmentList.get(position);
        }

        @Override
        public int getCount() {
            return fragmentList.size();
        }
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        finishAffinity();
    }
}