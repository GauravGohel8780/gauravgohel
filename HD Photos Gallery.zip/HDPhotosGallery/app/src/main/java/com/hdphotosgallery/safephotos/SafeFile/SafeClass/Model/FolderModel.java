package com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class FolderModel implements Parcelable {
    public boolean isSelected;
    private String name;
    private String path;

    public FolderModel(String str, String str2) {
        this.name = "";
        this.path = "";
        this.name = str;
        this.path = str2;
    }

    protected FolderModel(Parcel in) {
        isSelected = in.readByte() != 0;
        name = in.readString();
        path = in.readString();
    }

    public static final Creator<FolderModel> CREATOR = new Creator<FolderModel>() {
        @Override
        public FolderModel createFromParcel(Parcel in) {
            return new FolderModel(in);
        }

        @Override
        public FolderModel[] newArray(int size) {
            return new FolderModel[size];
        }
    };

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public String getPath() {
        return this.path;
    }

    public void setPath(String str) {
        this.path = str;
    }

    public boolean isSelected() {
        return this.isSelected;
    }

    public void setSelected(boolean z) {
        this.isSelected = z;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeByte((byte) (isSelected ? 1 : 0));
        parcel.writeString(name);
        parcel.writeString(path);
    }
}
