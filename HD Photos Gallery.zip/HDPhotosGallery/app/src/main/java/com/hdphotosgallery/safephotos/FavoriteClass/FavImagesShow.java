package com.hdphotosgallery.safephotos.FavoriteClass;
import static com.hdphotosgallery.safephotos.PhotosGroping.SectionimgeActivity.getBack;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.hdphotosgallery.safephotos.PhotosGroping.SectionimgeActivity;
import com.hdphotosgallery.safephotos.R;

import java.util.ArrayList;
import java.util.Objects;

public class FavImagesShow extends AppCompatActivity {
    private ArrayList<FavModel> allImages = new ArrayList<>();
    RelativeLayout tool1;
    ViewPager mViewPager;
    FavimageAdapte favimageAdapte;
    ImageView favorite, imagePlayer, share;

    FavModel model;

    FavDB favDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fav_images_show);

        findViewById(R.id.back).setOnClickListener(view -> {
            onBackPressed();
        });

        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.blackall));
        getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.blackall));

        share = findViewById(R.id.share);
        tool1 = findViewById(R.id.tool1);
        favorite = findViewById(R.id.favorite);
        favDB = new FavDB(this);

        Bundle bundle = getIntent().getExtras();

        String position = bundle.getString("po");
        allImages = getIntent().getExtras().getParcelableArrayList("arrayP");
        Log.i("ffffffff", "onCreate: " + allImages);

        imagePlayer = findViewById(R.id.iconplayer);
        mViewPager = findViewById(R.id.viewPagerMain1);
        favimageAdapte = new FavimageAdapte(this, allImages);
        mViewPager.setAdapter(favimageAdapte);

        mViewPager.setCurrentItem(Integer.parseInt(position));
        model = allImages.get(Integer.parseInt(position));
        ((TextView)findViewById(R.id.title)).setText(model.getFname());
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri imageUri = Uri.parse(model.getFimage());
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("image/*");

                intent.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(intent, "Share"));

            }
        });

        favorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                favDB.remove_fav(model.getFimage());
                removeItem(position);

            }
        });

        boolean isVideo = getBack(model.getFimage(), "((\\.mp4|\\.webm|\\.ogg|\\.mpK|\\.avi|\\.mkv|\\.flv|\\.mpg|\\.wmv|\\.vob|\\.ogv|\\.mov|\\.qt|\\.rm|\\.rmvb\\.|\\.asf|\\.m4p|\\.m4v|\\.mp2|\\.mpeg|\\.mpe|\\.mpv|\\.m2v|\\.3gp|\\.f4p|\\.f4a|\\.f4b|\\.f4v)$)").isEmpty();
        if (!isVideo) {
            imagePlayer.setVisibility(View.VISIBLE);
        } else {
            imagePlayer.setVisibility(View.GONE);
        }
        imagePlayer.setOnClickListener(view -> {
            Intent intent = new Intent(FavImagesShow.this, SectionimgeActivity.class);
            intent.putExtra("path", model.getFimage());
            startActivity(intent);
        });

        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                model = allImages.get(position);
                ((TextView)findViewById(R.id.title)).setText(model.getFname());
                boolean isVideo = getBack(model.getFimage(), "((\\.mp4|\\.webm|\\.ogg|\\.mpK|\\.avi|\\.mkv|\\.flv|\\.mpg|\\.wmv|\\.vob|\\.ogv|\\.mov|\\.qt|\\.rm|\\.rmvb\\.|\\.asf|\\.m4p|\\.m4v|\\.mp2|\\.mpeg|\\.mpe|\\.mpv|\\.m2v|\\.3gp|\\.f4p|\\.f4a|\\.f4b|\\.f4v)$)").isEmpty();
                if (!isVideo) {
                    imagePlayer.setVisibility(View.VISIBLE);
                } else {
                    imagePlayer.setVisibility(View.GONE);
                }
                imagePlayer.setOnClickListener(view -> {
                    Intent intent = new Intent(FavImagesShow.this, SectionimgeActivity.class);
                    intent.putExtra("path", model.getFimage());
                    startActivity(intent);
                });
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

    }

    private void removeItem(String position) {
        allImages.remove(position);
        finish();
        FavImagesShow.super.onBackPressed();
    }

    public void back(View view) {
        super.onBackPressed();
    }

    public class FavimageAdapte extends PagerAdapter {

        Context context;
        private ArrayList<FavModel> images;
        LayoutInflater mLayoutInflater;

        public FavimageAdapte(Context context, ArrayList<FavModel> images) {
            this.context = context;
            this.images = images;
            this.mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }


        @Override
        public int getCount() {
            return images.size();
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
            return view == object;
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            FavModel model = images.get(position);

            View itemView = mLayoutInflater.inflate(R.layout.picture_browser_pager, container, false);

            ImageView imageView = itemView.findViewById(R.id.image);

            LinearLayout ll = itemView.findViewById(R.id.ll);
            ll.setOnClickListener(view -> {
                Animation slideDown = AnimationUtils.loadAnimation(context, R.anim.slide_down);
                Animation slideDown1 = AnimationUtils.loadAnimation(context, R.anim.slide_down_1);
                Animation slideUp = AnimationUtils.loadAnimation(context, R.anim.slide_up);
                Animation slideUp1 = AnimationUtils.loadAnimation(context, R.anim.slide_up_1);
                if (tool1.getVisibility() == View.VISIBLE) {
                    tool1.startAnimation(slideUp1);
                    tool1.setVisibility(View.GONE);
                } else {
                    tool1.startAnimation(slideDown1);
                    tool1.setVisibility(View.VISIBLE);
                }
            });

            Glide.with(context).load(model.getFimage()).into(imageView);

            Objects.requireNonNull(container).addView(itemView);
            return itemView;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((LinearLayout) object);
        }
    }

}
