package com.hdphotosgallery.safephotos.SafeFile.SafeClass.adapters;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.hdphotosgallery.safephotos.R;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/* loaded from: classes2.dex */
public class Calc_HomeFolderAdapter extends RecyclerView.Adapter<Calc_HomeFolderAdapter.ViewHolder> {
    private static final int REQUEST_STORAGE_PERMISSION = 101;
    private Activity activity;
    private ArrayList<String> folderLists;
    private OnItemClickListener onItemClickListener;
    String[] permissionsList = new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};
    public static String[] storage_permissions_33 = {Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_IMAGES};

    /* loaded from: classes2.dex */
    public interface OnItemClickListener {
        void OnItemClick(int i, int i2);
    }

    public Calc_HomeFolderAdapter(Activity activity, ArrayList<String> arrayList, OnItemClickListener onItemClickListener) {
        this.activity = activity;
        this.folderLists = arrayList;
        this.onItemClickListener = onItemClickListener;
    }

    public void newList(ArrayList<String> arrayList) {
        this.folderLists = arrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(((LayoutInflater) this.activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.folder_item, (ViewGroup) null));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        if (this.folderLists.get(i).contains("Videos")) {
            Glide.with(this.activity).load(Integer.valueOf((int) R.drawable.add_folder_icon)).into(viewHolder.icon);
            viewHolder.title.setText("Safe File");
            viewHolder.desc.setText(this.activity.getResources().getString(R.string.video_desc));
        } else if (this.folderLists.get(i).contains("Photos")) {
            Glide.with(this.activity).load(Integer.valueOf((int) R.drawable.settingicon)).into(viewHolder.icon);
            viewHolder.title.setText("Setting");
            viewHolder.desc.setText(this.activity.getResources().getString(R.string.photo_desc));
        }



        viewHolder.folderView.setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.adapter.HomeFolderAdapter.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= 33) {
                    if (ActivityCompat.checkSelfPermission(Calc_HomeFolderAdapter.this.activity, "android.permission.READ_MEDIA_IMAGES") != 0 || ActivityCompat.checkSelfPermission(Calc_HomeFolderAdapter.this.activity, "android.permission.READ_MEDIA_VIDEO") != 0 || ActivityCompat.checkSelfPermission(Calc_HomeFolderAdapter.this.activity, "android.permission.READ_MEDIA_AUDIO") != 0) {
                        Calc_HomeFolderAdapter.this.requestStoragePermission();
                        return;
                    }
                } else {
                    if (ActivityCompat.checkSelfPermission(Calc_HomeFolderAdapter.this.activity, "android.permission.WRITE_EXTERNAL_STORAGE") != 0 || ActivityCompat.checkSelfPermission(Calc_HomeFolderAdapter.this.activity, "android.permission.READ_EXTERNAL_STORAGE") != 0) {
                        Calc_HomeFolderAdapter.this.requestStoragePermission();
                        return;
                    }
                }

                Calc_HomeFolderAdapter.this.onItemClickListener.OnItemClick(i, i);
            }
        });

        viewHolder.folderView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override // android.view.View.OnLongClickListener
            public boolean onLongClick(View view) {
                Calc_HomeFolderAdapter.this.onItemClickListener.OnItemClick(i, i);
                return true;
            }
        });
    }

    public void requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (!checkPermissions(activity, storage_permissions_33)) {
                ActivityCompat.requestPermissions(activity, storage_permissions_33, 21);
            }
        } else {
            if (!checkPermissions(activity, permissionsList)) {
                ActivityCompat.requestPermissions(activity, permissionsList, 21);
            }
        }
//        if (Build.VERSION.SDK_INT >= 16) {
//            ActivityCompat.requestPermissions(this.activity, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"}, 101);
//        }
    }

    public static boolean checkPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public int getItemCount() {
        return 2;
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView desc;
        RelativeLayout folderView;
        ImageView icon;
        TextView title;

        ViewHolder(View view) {
            super(view);
            this.folderView = (RelativeLayout) view.findViewById(R.id.folder_view);
            this.icon = (ImageView) view.findViewById(R.id.icon);
            this.title = (TextView) view.findViewById(R.id.title);
            this.desc = (TextView) view.findViewById(R.id.desc);
        }
    }

}
