package com.hdphotosgallery.safephotos.SafeFile.SafeClass.adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model.AlbumFolderModel;

import java.util.ArrayList;

/* loaded from: classes2.dex */
public class Calc_AlbumAdapter extends RecyclerView.Adapter<Calc_AlbumAdapter.ViewHolder> {
    private Activity activity;
    private ArrayList<AlbumFolderModel> albumFolders;
    private SetOnClickListener setOnClickListener;

    /* loaded from: classes2.dex */
    public interface SetOnClickListener {
        void onClick(int i);
    }

    public Calc_AlbumAdapter(Activity activity, ArrayList<AlbumFolderModel> arrayList, SetOnClickListener setOnClickListener) {
        this.activity = activity;
        this.albumFolders = arrayList;
        this.setOnClickListener = setOnClickListener;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(((LayoutInflater) this.activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.album_item, (ViewGroup) null));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        Glide.with(this.activity).load(this.albumFolders.get(i).getAlbumFiles().get(0).getPath()).into(viewHolder.image);
        viewHolder.countImage.setText(String.valueOf(this.albumFolders.get(i).getAlbumFiles().size()));
        viewHolder.folderName.setText(this.albumFolders.get(i).getName());
        viewHolder.album.setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.adapter.AlbumAdapter.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Calc_AlbumAdapter.this.setOnClickListener.onClick(i);
            }
        });
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.albumFolders.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout album;
        TextView countImage;
        TextView folderName;
        ImageView image;

        ViewHolder(View view) {
            super(view);
            this.album = (RelativeLayout) view.findViewById(R.id.album);
            this.image = (ImageView) view.findViewById(R.id.image);
            this.folderName = (TextView) view.findViewById(R.id.folder_name);
            this.countImage = (TextView) view.findViewById(R.id.count_image);
        }
    }
}
