package com.hdphotosgallery.safephotos.SafeFile.SafeClass.adapters;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Calc_HideItemActivity;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Calc_NoteActivity;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model.NoteModel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class Calc_NoteAdapter extends RecyclerView.Adapter<Calc_NoteAdapter.ViewHolder> {
    private static List<NoteModel> notes;
    private Activity activity;

    public Calc_NoteAdapter(Activity activity, List<NoteModel> list) {
        this.activity = activity;
        notes = list;
    }

    public void newNote(List<NoteModel> list) {
        notes = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(((LayoutInflater) this.activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.note_list_item, (ViewGroup) null));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(final ViewHolder viewHolder, final int i) {
        String str;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        try {
            str = new SimpleDateFormat("dd MMM").format(simpleDateFormat.parse(notes.get(i).getTimestamp()));
        } catch (ParseException e) {
            e.printStackTrace();
            str = "";
        }
        viewHolder.timestamp.setText(str);
        viewHolder.noteName.setText(notes.get(i).getName());
        viewHolder.noteView.setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.adapter.NoteAdapter.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (Calc_HideItemActivity.itemSelected) {
                    if (((NoteModel) Calc_NoteAdapter.notes.get(i)).isSelected()) {
                        Calc_HideItemActivity.count--;
                        ((NoteModel) Calc_NoteAdapter.notes.get(i)).setSelected(false);
                        viewHolder.imgSelected.setVisibility(View.GONE);
                    } else {
                        Calc_HideItemActivity.count++;
                        ((NoteModel) Calc_NoteAdapter.notes.get(i)).setSelected(true);
                        viewHolder.imgSelected.setVisibility(View.VISIBLE);
                    }
//                    Calc_HideItemActivity.toolbar.setTitle(Calc_HideItemActivity.count + " selected");
                    Calc_NoteAdapter.this.notifyDataSetChanged();
                    return;
                }
                Intent intent = new Intent(Calc_NoteAdapter.this.activity, Calc_NoteActivity.class);
                intent.putExtra("note", ((NoteModel) Calc_NoteAdapter.notes.get(i)).getNote());
                intent.putExtra("position", i);
                Calc_NoteAdapter.this.activity.startActivity(intent);
            }
        });
        if (notes.get(i).isSelected()) {
            viewHolder.imgSelected.setVisibility(View.VISIBLE);
        } else {
            viewHolder.imgSelected.setVisibility(View.GONE);
        }
        viewHolder.noteView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
//                Calc_HideItemActivity.editLayout.setVisibility(View.VISIBLE);
//                Calc_HideItemActivity.share.setVisibility(View.GONE);
//                Calc_HideItemActivity.restore.setVisibility(View.GONE);
                Calc_HideItemActivity.itemSelected = true;
                if (((NoteModel) Calc_NoteAdapter.notes.get(i)).isSelected) {
                    Calc_HideItemActivity.count--;
                    ((NoteModel) Calc_NoteAdapter.notes.get(i)).setSelected(false);
                    viewHolder.imgSelected.setVisibility(View.GONE);
                } else {
                    Calc_HideItemActivity.count++;
                    ((NoteModel) Calc_NoteAdapter.notes.get(i)).setSelected(true);
                    viewHolder.imgSelected.setVisibility(View.VISIBLE);
                }
//                Calc_HideItemActivity.toolbar.setTitle(Calc_HideItemActivity.count + " selected");
                Calc_NoteAdapter.this.notifyDataSetChanged();
                return true;
            }
        });
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout imgSelected;
        TextView noteName;
        RelativeLayout noteView;
        TextView timestamp;

        ViewHolder(View view) {
            super(view);
            this.timestamp = (TextView) view.findViewById(R.id.timestamp);
            this.noteName = (TextView) view.findViewById(R.id.note_name);
            this.noteView = (RelativeLayout) view.findViewById(R.id.note_view);
            this.imgSelected = (RelativeLayout) view.findViewById(R.id.img_selected);
        }
    }

    public static void clearSelection() {
        for (NoteModel note : notes) {
            note.isSelected = false;
        }
    }

    public ArrayList<NoteModel> getSelectedList() {
        ArrayList<NoteModel> arrayList = new ArrayList<>();
        for (int i = 0; i <= notes.size() - 1; i++) {
            if (notes.get(i).isSelected()) {
                arrayList.add(notes.get(i));
            }
        }
        return arrayList;
    }
}
