package com.hdphotosgallery.safephotos.GalleryGroping;

import android.os.Parcel;
import android.os.Parcelable;

public class PhotoListModel implements Parcelable {

    private String picturName;
    private String picturePath;
    private String pictureSize;
    private long dateTaken;
    private long lastModified;
    private int mediaType;

    public PhotoListModel() {
    }

    protected PhotoListModel(Parcel in) {
        picturName = in.readString();
        picturePath = in.readString();
        pictureSize = in.readString();
        dateTaken = in.readLong();
        lastModified = in.readLong();
        mediaType = in.readInt();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(picturName);
        dest.writeString(picturePath);
        dest.writeString(pictureSize);
        dest.writeLong(dateTaken);
        dest.writeLong(lastModified);
        dest.writeInt(mediaType);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<PhotoListModel> CREATOR = new Creator<PhotoListModel>() {
        @Override
        public PhotoListModel createFromParcel(Parcel in) {
            return new PhotoListModel(in);
        }

        @Override
        public PhotoListModel[] newArray(int size) {
            return new PhotoListModel[size];
        }
    };

    public String getPicturName() {
        return picturName;
    }

    public void setPicturName(String picturName) {
        this.picturName = picturName;
    }

    public String getPicturePath() {
        return picturePath;
    }

    public void setPicturePath(String picturePath) {
        this.picturePath = picturePath;
    }

    public String getPictureSize() {
        return pictureSize;
    }

    public void setPictureSize(String pictureSize) {
        this.pictureSize = pictureSize;
    }

    public long getDateTaken() {
        return dateTaken;
    }

    public void setDateTaken(long dateTaken) {
        this.dateTaken = dateTaken;
    }

    public long getLastModified() {
        return lastModified;
    }

    public void setLastModified(long lastModified) {
        this.lastModified = lastModified;
    }

    public int getMediaType() {
        return mediaType;
    }

    public void setMediaType(int mediaType) {
        this.mediaType = mediaType;
    }
}
