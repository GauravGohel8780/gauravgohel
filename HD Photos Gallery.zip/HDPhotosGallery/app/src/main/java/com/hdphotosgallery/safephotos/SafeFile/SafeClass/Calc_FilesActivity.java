package com.hdphotosgallery.safephotos.SafeFile.SafeClass;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Database.DatabaseHelper;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model.DocModel;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Utils.Constant;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.adapters.Calc_FileAdapter;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/* loaded from: classes2.dex */
public class Calc_FilesActivity extends AppCompatActivity {
    public static boolean selected = false;
    Calc_FileAdapter adapter;
    DatabaseHelper db;
    boolean floatingClick;
    ImageView hideItem;
    RecyclerView recycler;
    ArrayList<DocModel> docList = new ArrayList<>();
    ArrayList<DocModel> selectedList = new ArrayList<>();

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_files);

        this.recycler = (RecyclerView) findViewById(R.id.recycler);
        this.hideItem = (ImageView) findViewById(R.id.hide_item);
        System.out.println("*****> ok");
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setDisplayShowTitleEnabled(false);
        this.db = new DatabaseHelper(this);
        getDocList(Environment.getExternalStorageDirectory());
        this.floatingClick = getIntent().getBooleanExtra("floatingClick", false);
        this.adapter = new Calc_FileAdapter(this, this.docList);
        this.recycler.setLayoutManager(new GridLayoutManager(this, 1));
        this.recycler.setAdapter(this.adapter);
        this.hideItem.setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.FilesActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                String str;
                if (Calc_FilesActivity.this.adapter.getSelectedList().size() > 0) {
                    Calc_FilesActivity filesActivity = Calc_FilesActivity.this;
                    filesActivity.selectedList = filesActivity.adapter.getSelectedList();
                    for (int i = 0; i < Calc_FilesActivity.this.selectedList.size(); i++) {
                        String filePath = Calc_FilesActivity.this.selectedList.get(i).getFilePath();
                        String name = new File(filePath).getName();
                        String substring = name.substring(0, name.lastIndexOf("."));
                        String format = new SimpleDateFormat("yyyyMMddhhmmssSSS").format(new Date());
                        if (Calc_FilesActivity.this.selectedList.get(i).getFileName().endsWith(".pdf")) {
                            str = substring + "_" + format + ".pdf";
                        } else if (Calc_FilesActivity.this.selectedList.get(i).getFileName().endsWith(".docx") || Calc_FilesActivity.this.selectedList.get(i).getFileName().endsWith(".doc")) {
                            str = substring + "_" + format + ".doc";
                        } else if (Calc_FilesActivity.this.selectedList.get(i).getFileName().endsWith(".xlsx") || Calc_FilesActivity.this.selectedList.get(i).getFileName().endsWith(".xls")) {
                            str = substring + "_" + format + ".xlsx";
                        } else if (Calc_FilesActivity.this.selectedList.get(i).getFileName().endsWith(".txt")) {
                            str = substring + "_" + format + ".txt";
                        } else if (Calc_FilesActivity.this.selectedList.get(i).getFileName().endsWith(".pptx") || Calc_FilesActivity.this.selectedList.get(i).getFileName().endsWith(".ppt")) {
                            str = substring + "_" + format + ".ppt";
                        } else {
                            str = "";
                        }
                        Toast.makeText(filesActivity, "this..."+str, Toast.LENGTH_SHORT).show();
                        File file = new File(Constant.folderPath + "/Files/", str);
                        Calc_FilesActivity.this.db.insertHideItem(filePath, file.getAbsolutePath());
                        try {
                            Constant.moveFile(new File(filePath), file);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        new File(filePath).delete();
                        if (Calc_FilesActivity.this.floatingClick) {
                            Calc_FilesActivity.this.startActivity(new Intent(Calc_FilesActivity.this.getApplicationContext(), Calc_HideItemActivity.class).putExtra("selectedFolderPath", Constant.folderPath + "/Files"));
                        }
                        Calc_FilesActivity.this.onBackPressed();
                        Calc_FilesActivity.this.finish();
                    }
                    return;
                }
                Calc_FilesActivity filesActivity2 = Calc_FilesActivity.this;
                Toast.makeText(filesActivity2, filesActivity2.getResources().getString(R.string.empty_selected_list), Toast.LENGTH_SHORT).show();
            }
        });
    }


    public void getDocList(File file) {
        File[] listFiles = file.listFiles();
        if (listFiles != null) {
            for (File file2 : listFiles) {
                if (file2.isDirectory()) {
                    getDocList(file2);
                } else if (file2.getName().endsWith(".pdf") || file2.getName().endsWith(".docx") || file2.getName().endsWith(".doc") || file2.getName().endsWith(".xlsx") || file2.getName().endsWith(".xls") || file2.getName().endsWith(".txt") || file2.getName().endsWith(".pptx") || file2.getName().endsWith(".ppt")) {
                    this.docList.add(new DocModel(file2.getName(), file2.getAbsolutePath()));
                }
            }
        }
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
            return true;
        }
        return true;
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (selected) {
            selected = false;
            Calc_FileAdapter.clearSelection();
            this.adapter.notifyDataSetChanged();
            return;
        }
        super.onBackPressed();
    }



}
