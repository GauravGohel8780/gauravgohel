package com.festom.hairclippersound.pranksound.HCSP_util;


import com.festom.hairclippersound.pranksound.HCSP_model.HCSP_FeedBackResponseModel;
import com.festom.hairclippersound.pranksound.HCSP_model.HCSP_FeedbackRequestModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface HCSP_ApiService {

    @POST("api/v1/feedBack/save")
    Call<HCSP_FeedBackResponseModel> feedbackUser(@Body HCSP_FeedbackRequestModel request);
}