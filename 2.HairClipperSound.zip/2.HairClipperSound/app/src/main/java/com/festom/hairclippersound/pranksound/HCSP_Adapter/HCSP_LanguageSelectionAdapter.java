package com.festom.hairclippersound.pranksound.HCSP_Adapter;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.festom.hairclippersound.pranksound.R;
import com.festom.hairclippersound.pranksound.HCSP_model.HCSP_LanguageModel;
import com.google.gson.Gson;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.util.ArrayList;

public class HCSP_LanguageSelectionAdapter extends RecyclerView.Adapter<HCSP_LanguageSelectionAdapter.ViewHolder> {

    ArrayList<HCSP_LanguageModel> languageModelsList;
    public int selectedPosition = 0;
    Context context;

    public HCSP_LanguageSelectionAdapter(Context context, ArrayList<HCSP_LanguageModel> languageModelsList) {
        this.context = context;
        this.languageModelsList = languageModelsList;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_languages, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        HCSP_LanguageModel languageModel = languageModelsList.get(position);

        holder.tvLanguageName.setText(languageModel.getLanguageName());

        Glide.with(holder.itemView.getContext()).load(languageModel.getFlag()).into(holder.ivFlag);

        Log.d("--languages--", "onBindViewHolder: " + new Gson().toJson(languageModelsList));


        if (selectedPosition == -1) {
            holder.ivSelection.setVisibility(View.GONE);
        } else {
            if (selectedPosition == holder.getAdapterPosition()) {
                holder.ivSelection.setVisibility(View.VISIBLE);
            } else {
                holder.ivSelection.setVisibility(View.GONE);
            }
        }


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance((Activity) context).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        if (selectedPosition != holder.getAdapterPosition()) {
                            int previousSelectedPosition = selectedPosition;
                            selectedPosition = holder.getAdapterPosition();

                            notifyItemChanged(previousSelectedPosition);
                            notifyItemChanged(selectedPosition);

                            Log.d("--selection--", "onBindViewHolder: setOnClickListener: " + selectedPosition);
                        }
                    }
                }, MAIN_CLICK);
            }
        });
    }


    @Override
    public int getItemCount() {
        return languageModelsList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivFlag;
        ImageView ivSelection;
        TextView tvLanguageName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivFlag = itemView.findViewById(R.id.ivFlag);
            ivSelection = itemView.findViewById(R.id.ivSelection);
            tvLanguageName = itemView.findViewById(R.id.tvLanguageName);
        }
    }
}