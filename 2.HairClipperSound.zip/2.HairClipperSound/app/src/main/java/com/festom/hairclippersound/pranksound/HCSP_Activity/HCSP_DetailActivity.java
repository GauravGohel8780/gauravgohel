package com.festom.hairclippersound.pranksound.HCSP_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatSeekBar;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;

import com.festom.hairclippersound.pranksound.HCSP_Ads_Common.HCSP_AdsBaseActivity;
import com.festom.hairclippersound.pranksound.R;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class HCSP_DetailActivity extends HCSP_AdsBaseActivity {
    private TextView tvTimer;
    private CountDownTimer countDownTimer;
    private long selectedTimeMillis;
    TextView tvSoundTitle;
    ImageView ivSound;
    AudioManager audioManager;
    ImageView ivSoundPlayPause;
    MediaPlayer mediaPlayer;
    SwitchCompat switchLoop;
    AppCompatSeekBar acsbVolumeLevel;
    SharedPreferences sharedPreferences;

    BroadcastReceiver volumeReceiver;
    int soundResourceId;
    SharedPreferences.OnSharedPreferenceChangeListener listener;

    public static int[] v = {R.raw.haircutter01, R.raw.haircutter02, R.raw.haircutter03, R.raw.haircutter04, R.raw.haircutter05, R.raw.haircutter06, R.raw.haircutter07, R.raw.haircutter08, R.raw.haircutter09, R.raw.haircutter10,
            R.raw.haircutter11, R.raw.haircutter12, R.raw.haircutter13, R.raw.haircutter14, R.raw.haircutter15, R.raw.haircutter16, R.raw.haircutter17, R.raw.haircutter18, R.raw.haircutter19, R.raw.haircutter20,
            R.raw.haircutter21, R.raw.haircutter22, R.raw.haircutter23, R.raw.haircutter24, R.raw.haircutter25, R.raw.haircutter26, R.raw.haircutter27, R.raw.haircutter28, R.raw.haircutter29, R.raw.haircutter30,
            R.raw.haircutter31, R.raw.haircutter32, R.raw.haircutter33, R.raw.haircutter34, R.raw.haircutter35, R.raw.haircutter36, R.raw.haircutter37, R.raw.haircutter38};

    int[] soundResourceIds;
    int i3;
    int intExtra;
    Vibrator vibrator;
    boolean isSwitched;
    boolean isVibrate;
    boolean adapterItemClicked = false;
    private static final int VIBRATION_DURATION = 200;
    private static final int SECOND_VIBRATION_DELAY = 1000;
    Spinner snrTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);


        tvTimer = findViewById(R.id.tvTimer);
        tvTimer.setText(R.string.HCSP_delay_of);


        ivSound = (ImageView) findViewById(R.id.ivSound);
        ivSoundPlayPause = findViewById(R.id.ivPP);
        switchLoop = (SwitchCompat) findViewById(R.id.switchLoop);
        acsbVolumeLevel = (AppCompatSeekBar) findViewById(R.id.acsbVolumeLevel);
        tvSoundTitle = findViewById(R.id.tvSoundTitle);

        intExtra = getIntent().getIntExtra("position", 0);


        sharedPreferences = getSharedPreferences("spCheck", MODE_PRIVATE);
        isVibrate = sharedPreferences.getBoolean("isVibrate", false);

        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        initControls();
        registerVolumeReceiver();
        setVolumeControlStream(AudioManager.STREAM_MUSIC);


        String[] seconds = {"off", "15", "30", "60"};
        List<String> list = Arrays.asList(seconds);

        snrTimer = findViewById(R.id.snrTimer);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        snrTimer.setAdapter(adapter);

        listener = new SharedPreferences.OnSharedPreferenceChangeListener() {
            @Override
            public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, @Nullable String key) {
                assert key != null;

                if (key.equals("spId")) {
                    boolean isSwitched = sharedPreferences.getBoolean("spId", false);
                    switchLoop.setChecked(isSwitched);
                    HCSP_DetailActivity.this.isSwitched = isSwitched;

                    Log.d("--isChecked--", "onSharedPreferenceChanged: -------->" + isSwitched);
                }
            }
        };

        sharedPreferences.registerOnSharedPreferenceChangeListener(listener);

        isSwitched = sharedPreferences.getBoolean("spId", false);
        switchLoop.setChecked(isSwitched);
        setSwitchStyle(isSwitched);

        int numberindex = intExtra + 1;

        tvSoundTitle.setText(getString(R.string.app_name) + " " + numberindex);

        Log.d("--isChecked--", "onCreate: isChecked-------->" + isSwitched);


        findViewById(R.id.cvBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(HCSP_DetailActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        if (mediaPlayer != null) {
                            if (mediaPlayer.isPlaying()) {
                                try {
                                    mediaPlayer.stop();
                                    stopVibration();
                                    mediaPlayer.setLooping(false);
                                    ivSoundPlayPause.setImageResource(R.drawable.ic_play);
                                } catch (Exception ignored) {

                                }
                            }
                            mediaPlayer.release();
                            mediaPlayer = null;
                        }
                        stopVibration();
                        if (countDownTimer != null) {
                            countDownTimer.cancel();
                        }
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });


        this.sharedPreferences = getSharedPreferences("spCheck", 0);
        try {
            Log.e("--sound--", "onCreate: INSDIE TRY ");

            int[] soundArray = v;

            this.soundResourceIds = soundArray;
            i3 = soundArray[intExtra];
            mediaPlayer = MediaPlayer.create(HCSP_DetailActivity.this, i3);

            Log.d("--sound--", "onCreate: sounds--------->" + i3);

            Log.e("--sound--", "onCreate: -----------> IN 18 or 19");

            Log.e("--sound--", "onCreate: -----------> IN 18 or 19 " + i3);

            this.ivSoundPlayPause.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    getInstance(HCSP_DetailActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            Log.e("--sound--", "onClick: ");

                            if (mediaPlayer != null) {
                                try {
                                    if (mediaPlayer.isPlaying()) {
                                        Log.d("--player--", "onClick: isPlaying() ");

                                        mediaPlayer.pause();
                                        ivSoundPlayPause.setImageResource(R.drawable.ic_play);

                                    } else {
                                        Log.d("--player--", "onClick: else notPlaying() ");

                                        mediaPlayer.seekTo(0);
                                        mediaPlayer.start();
                                        startVibrationAndMedia();
                                        ivSoundPlayPause.setImageResource(R.drawable.ic_pause);

                                    }
                                } catch (IllegalStateException e) {
                                    Log.e("--sound--", "onClick: IllegalStateException - " + e.getMessage());
                                    mediaPlayer.release();
                                    mediaPlayer = MediaPlayer.create(HCSP_DetailActivity.this, i3);
                                }
                            }
                        }
                    }, MAIN_CLICK);
                }
            });

            snrTimer.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                    getInstance(HCSP_DetailActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            if (position >= 1) {
                                int selectedSeconds = Integer.parseInt(list.get(position));
                                selectedTimeMillis = selectedSeconds * 1000L;
                                startCountdownTimer(selectedTimeMillis);
                            }
                        }
                    }, MAIN_CLICK);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parentView) {

                }
            });


            if (isSwitched) {
                this.switchLoop.setChecked(true);
                this.mediaPlayer.setLooping(true);
            } else {
                this.switchLoop.setChecked(false);
                this.mediaPlayer.setLooping(false);
            }

            AlphaAnimation alphaAnimation = new AlphaAnimation(0.2f, 1.0f);
            alphaAnimation.setDuration(500L);
            alphaAnimation.setRepeatMode(2);
            alphaAnimation.setRepeatCount(-1);

            this.switchLoop.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    getInstance(HCSP_DetailActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            if (isChecked) {
                                try {
                                    setSwitchStyle(true);

                                    SharedPreferences.Editor editor = getSharedPreferences("spCheck", MODE_PRIVATE).edit();
                                    editor.putBoolean("spId", true);
                                    editor.apply();
                                    HCSP_DetailActivity.this.mediaPlayer.setLooping(true);
                                } catch (Exception ignored) {
                                }
                            } else {
                                try {
                                    setSwitchStyle(false);

                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putBoolean("spId", false);
                                    editor.apply();
                                    HCSP_DetailActivity.this.mediaPlayer.setLooping(false);
                                } catch (Exception ignored) {
                                }
                            }
                        }
                    }, MAIN_CLICK);
                }
            });

            this.mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {

                    if (mediaPlayer.isLooping()) {
                        mediaPlayer.seekTo(0);

                        startVibrationAndMedia();

                    } else {
                        ivSoundPlayPause.setImageResource(R.drawable.ic_play);
                    }
                }
            });

            setVolumeControlStream(3);
            AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            this.audioManager = audioManager;
            this.acsbVolumeLevel.setMax(audioManager.getStreamMaxVolume(3));
            this.acsbVolumeLevel.setProgress(this.audioManager.getStreamVolume(3));
            this.acsbVolumeLevel.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int i4, boolean z) {
                    HCSP_DetailActivity.this.audioManager.setStreamVolume(3, i4, 0);
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {

                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {

                }
            });


            setVolumeControlStream(3);
            AudioManager audioManager2 = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            this.audioManager = audioManager2;
            this.acsbVolumeLevel.setMax(audioManager2.getStreamMaxVolume(3));
            this.acsbVolumeLevel.setProgress(this.audioManager.getStreamVolume(3));
            this.acsbVolumeLevel.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int i4, boolean z) {
                    HCSP_DetailActivity.this.audioManager.setStreamVolume(3, i4, 0);
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                }
            });


            if (isSwitched) {
                this.switchLoop.setChecked(true);
            } else {
                this.switchLoop.setChecked(false);
                this.mediaPlayer.setLooping(false);
            }


            if (this.mediaPlayer == null) {
                Log.e("--sound--", "MediaPlayer creation failed");
                ivSoundPlayPause.setImageResource(R.drawable.ic_play);
                return;
            }


            return;
        } catch (Exception e2) {
            Log.e("--sound--", "catch: ----->" + e2);
            e2.printStackTrace();
        }


        AlphaAnimation alphaAnimation2 = new AlphaAnimation(0.2f, 1.0f);
        alphaAnimation2.setDuration(500L);
        alphaAnimation2.setRepeatMode(2);
        alphaAnimation2.setRepeatCount(-1);

        if (!mediaPlayer.isPlaying() || mediaPlayer == null) {
            ivSoundPlayPause.setImageResource(R.drawable.ic_play);
        } else {
            ivSoundPlayPause.setImageResource(R.drawable.ic_pause);
        }


        mediaPlayer.setLooping(this.sharedPreferences.getBoolean("spId", false));
        if (mediaPlayer != null) {
            this.mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    if (mediaPlayer.isLooping()) {
                        mediaPlayer.seekTo(0);

                        startVibrationAndMedia();

                    } else {
                        HCSP_DetailActivity.this.ivSoundPlayPause.setImageResource(R.drawable.ic_play);
                    }
                }
            });

            this.switchLoop.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        try {
                            setSwitchStyle(true);

                            SharedPreferences.Editor editor = getSharedPreferences("spCheck", MODE_PRIVATE).edit();
                            editor.putBoolean("spId", true);
                            editor.apply();
                            HCSP_DetailActivity.this.mediaPlayer.setLooping(true);
                        } catch (Exception ignored) {
                        }
                    } else {
                        try {
                            setSwitchStyle(false);
                            setSwitchCustomStyle(R.drawable.ic_thumb, R.drawable.bg_switch_track);

                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putBoolean("spId", false);
                            editor.apply();
                            HCSP_DetailActivity.this.mediaPlayer.setLooping(false);
                        } catch (Exception ignored) {
                        }
                    }
                }
            });
        }

    }


    @Override
    protected void onStop() {
        super.onStop();
        stopVibration();
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer.setLooping(false);
            Toast.makeText(this, "Stop: MediaPlayer released", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onPause() {
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) {
                    stopVibration();
                    ivSoundPlayPause.setImageResource(R.drawable.ic_play);
                    mediaPlayer.pause();
                }
            } catch (IllegalStateException e) {
                Log.e("--sound--", "onPause: IllegalStateException - " + e.getMessage());
            }
        }

        if (countDownTimer != null) {
            countDownTimer.cancel();
        }

        super.onPause();
    }

    @Override
    public void onDestroy() {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                try {
                    this.mediaPlayer.stop();
                    stopVibration();
                    this.mediaPlayer.setLooping(false);
                    ivSoundPlayPause.setImageResource(R.drawable.ic_play);
                } catch (Exception ignored) {
                }
            }
            this.mediaPlayer.release();
            this.mediaPlayer = null;
        }
        stopVibration();
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        super.onDestroy();
    }

    @Override
    public boolean onKeyDown(int i2, KeyEvent keyEvent) {
        AppCompatSeekBar seekBar;
        int progress;
        if (i2 != 24) {
            if (i2 == 25) {
                seekBar = this.acsbVolumeLevel;
                progress = seekBar.getProgress() + (-1) < 0 ? 0 : this.acsbVolumeLevel.getProgress() - 1;
            }
            return super.onKeyDown(i2, keyEvent);
        }
        seekBar = this.acsbVolumeLevel;
        progress = seekBar.getProgress() + 1 > this.acsbVolumeLevel.getMax() ? this.acsbVolumeLevel.getMax() : this.acsbVolumeLevel.getProgress() + 1;
        seekBar.setProgress(progress);
        return super.onKeyDown(i2, keyEvent);
    }


    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
        if (mediaPlayer == null && !mediaPlayer.isPlaying()) {
            mediaPlayer = MediaPlayer.create(HCSP_DetailActivity.this, i3);
        }
    }


    private void setSwitchStyle(boolean isChecked) {
        if (isChecked) {
            setSwitchCustomStyle(R.drawable.ic_thumb, R.drawable.bg_switch_track_checked);
        } else {
            setSwitchCustomStyle(R.drawable.ic_thumb, R.drawable.bg_switch_track);
        }
    }

    private void setSwitchCustomStyle(int thumbDrawableRes, int trackDrawableRes) {
        Drawable thumbDrawable = ContextCompat.getDrawable(this, thumbDrawableRes);
        Drawable trackDrawable = ContextCompat.getDrawable(this, trackDrawableRes);

        switchLoop.setThumbDrawable(thumbDrawable);
        switchLoop.setTrackDrawable(trackDrawable);
    }

    private void startCountdownTimer(long millisInFuture) {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        countDownTimer = new CountDownTimer(millisInFuture, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                tvTimer.setText(getString(R.string.HCSP_playing_in) + " " + millisUntilFinished / 1000);
                if (millisInFuture != 0) {
                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                        ivSoundPlayPause.setImageResource(R.drawable.ic_play);
                    }
                    mediaPlayer.setLooping(isSwitched);
                    ivSoundPlayPause.setEnabled(false);
                }
            }

            private Handler handler = new Handler();

            @Override
            public void onFinish() {
                tvTimer.setText(R.string.HCSP_delay_of);
                snrTimer.setSelection(0);
                ivSoundPlayPause.setEnabled(true);

                handler.post(new Runnable() {
                    @Override
                    public void run() {

                        mediaPlayer.setLooping(isSwitched);

                        if (!mediaPlayer.isPlaying()) {
                            mediaPlayer.reset();


                            int currentSoundResourceId;

                            Log.d("--clicked--", "run: " + adapterItemClicked);

                            if (adapterItemClicked) {
                                currentSoundResourceId = soundResourceId;
                            } else {
                                currentSoundResourceId = soundResourceIds[intExtra];
                            }

                            try {
                                mediaPlayer.setDataSource(getApplicationContext(), Uri.parse("android.resource://" + getPackageName() + "/" + currentSoundResourceId));
                                mediaPlayer.prepare();

                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }
                        }


                        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                            @Override
                            public void onCompletion(MediaPlayer mediaPlayer) {
                                if (isSwitched) {
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            mediaPlayer.seekTo(0);
                                            mediaPlayer.start();
                                        }
                                    }, 1000);

                                    startVibrationAndMedia();
                                } else {
                                    ivSoundPlayPause.setImageResource(R.drawable.ic_play);
                                }
                            }
                        });

                        sharedPreferences.registerOnSharedPreferenceChangeListener(listener);

                        // Set looping based on the updated isSwitched

                        mediaPlayer.start();
                        startVibrationAndMedia();

                        ivSoundPlayPause.setImageResource(R.drawable.ic_pause);
                    }
                });
            }
        };

        countDownTimer.start();
    }

    private void initControls() {
        try {
            audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            acsbVolumeLevel.setMax(audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
            acsbVolumeLevel.setProgress(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC));

            acsbVolumeLevel.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onStopTrackingTouch(SeekBar arg0) {
                }

                @Override
                public void onStartTrackingTouch(SeekBar arg0) {
                }

                @Override
                public void onProgressChanged(SeekBar arg0, int progress, boolean arg2) {
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0);

                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void registerVolumeReceiver() {
        volumeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent.getAction() != null && intent.getAction().equals("android.media.VOLUME_CHANGED_ACTION")) {
                    int streamType = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1);
                    if (streamType == AudioManager.STREAM_MUSIC) {
                        int volume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
//                        audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI);
                        acsbVolumeLevel.setProgress(volume);
                    }
                }
            }
        };

        IntentFilter intentFilter = new IntentFilter("android.media.VOLUME_CHANGED_ACTION");
        registerReceiver(volumeReceiver, intentFilter);
    }

    private void startVibrationAndMedia() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    if (isVibrate) {
                        startVibration();
                        try {
                            Thread.sleep(VIBRATION_DURATION);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        stopVibration();

                        try {
                            Thread.sleep(SECOND_VIBRATION_DELAY);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
                stopVibration();
            }
        }).start();
    }

    private void startVibration() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(VIBRATION_DURATION, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            vibrator.vibrate(VIBRATION_DURATION);
        }
    }

    private void stopVibration() {
        vibrator.cancel();
    }

}