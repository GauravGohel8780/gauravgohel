package com.festom.breakingsound.pranksound.BPS_preference;


import android.content.Context;
import android.content.SharedPreferences;

public class BPS_SharePref {
    private static final String PREF_NAME = "APPLICATION_BATTERY_CHARGING";
    public static  String PREF_SELECTED_POSITION = "selectedPosition";
    private static final String PREF_LANGUAGE = "PREF_LANGUAGE";
    static final String MyPref = "MyPrefs";
    static final String IS_FIRST_LAUNCH = "IS_FIRST_LAUNCH";

    public static void putPrefLanguage(Context context, String str) {
        context.getSharedPreferences(PREF_NAME, 0).edit().putString(PREF_LANGUAGE, str).apply();
    }

    public static String getPrefLanguage(Context context) {
        return context.getSharedPreferences(PREF_NAME, 0).getString(PREF_LANGUAGE, null);
    }


    public static void saveSelectedPosition(Context context, int position) {
        SharedPreferences.Editor editor = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE).edit();
        editor.putInt(PREF_SELECTED_POSITION, position);
        editor.apply();
    }

    public static int loadSelectedPosition(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        return prefs.getInt(PREF_SELECTED_POSITION, -1);
    }

    public static boolean IsFirstLaunch(Context context) {
        return context.getApplicationContext().getSharedPreferences(MyPref, 0).getBoolean(IS_FIRST_LAUNCH, false);
    }


    public static void setIsFirstLaunch(Context context, boolean isfirst) {
        SharedPreferences.Editor edit = context.getApplicationContext().getSharedPreferences(MyPref, 0).edit();
        edit.putBoolean(IS_FIRST_LAUNCH, isfirst);
        edit.commit();
    }
}
