package com.festom.breakingsound.pranksound.BPS_util;


import com.festom.breakingsound.pranksound.BPS_model.BPS_FeedBackResponseModel;
import com.festom.breakingsound.pranksound.BPS_model.BPS_FeedbackRequestModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface BPS_ApiService {

    @POST("api/v1/feedBack/save")
    Call<BPS_FeedBackResponseModel> feedbackUser(@Body BPS_FeedbackRequestModel request);
}