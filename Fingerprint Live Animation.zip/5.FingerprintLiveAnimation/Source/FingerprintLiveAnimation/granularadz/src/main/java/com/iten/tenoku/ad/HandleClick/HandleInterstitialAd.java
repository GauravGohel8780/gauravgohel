package com.iten.tenoku.ad.HandleClick;

public interface HandleInterstitialAd {
    void Show(boolean adShow);
}
