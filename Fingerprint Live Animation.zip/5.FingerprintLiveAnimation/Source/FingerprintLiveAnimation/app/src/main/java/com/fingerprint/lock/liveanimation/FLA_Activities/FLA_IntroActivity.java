package com.fingerprint.lock.liveanimation.FLA_Activities;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;


import androidx.fragment.app.FragmentActivity;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.fingerprint.lock.liveanimation.Ads_Common.AdsBaseActivity;
import com.fingerprint.lock.liveanimation.R;
import com.fingerprint.lock.liveanimation.FLA_Utils.FLA_PrefManager;
import com.fingerprint.lock.liveanimation.databinding.ActivityIntroBinding;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class FLA_IntroActivity extends AdsBaseActivity {
    ActivityIntroBinding binding;
    TextView[] dots;
    private int[] layouts;
    MyViewPagerAdapter myViewPagerAdapter;
    private FLA_PrefManager prefManager;
    ViewPager.OnPageChangeListener viewPagerPageChangeListener = new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrollStateChanged(int i) {
        }

        @Override
        public void onPageScrolled(int i, float f, int i2) {
        }

        @Override
        public void onPageSelected(int i) {
            if (i == FLA_IntroActivity.this.layouts.length - 1) {
                FLA_IntroActivity.this.binding.mbNext.setText("Got it");
            } else {
                FLA_IntroActivity.this.binding.mbNext.setText("Next");
            }
            if (i == 0) {
                FLA_IntroActivity.this.changeScreenBg(R.drawable.ic_intro_bg_1);
            } else if (i == 1) {
                FLA_IntroActivity.this.changeScreenBg(R.drawable.ic_intro_bg_1);
            } else {
                FLA_IntroActivity.this.changeScreenBg(R.drawable.ic_intro_bg_1);
            }
        }
    };


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        new FLA_SplashActivity().SetSystemFullScreen(this);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.binding = ActivityIntroBinding.inflate(getLayoutInflater());
        this.prefManager = new FLA_PrefManager(this);
        AdsBaseActivity.registerInAppMsgEventForActivity(this, "ActivityIntroBinding");
        if (!this.prefManager.isFirstTimeLaunch()) {
            launchHomeScreen();
            finish();
        }
        setContentView(this.binding.getRoot());
        this.layouts = new int[]{R.layout.layout_intro_slider1, R.layout.layout_intro_slider2, R.layout.layout_intro_slider3};
        changeStatusBarColor();
        this.myViewPagerAdapter = new MyViewPagerAdapter();
        this.binding.viewPager.setAdapter(this.myViewPagerAdapter);
        this.binding.viewPager.addOnPageChangeListener(this.viewPagerPageChangeListener);
        this.binding.mbNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                getInstance(FLA_IntroActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        int item = getItem(1);
                        if (item < layouts.length) {
                            binding.viewPager.setCurrentItem(item);
                        } else {
                            launchHomeScreen();
                        }
                    }
                }, MAIN_CLICK);
            }
        });
    }


    private int getItem(int i) {
        return this.binding.viewPager.getCurrentItem() + i;
    }

    private void launchHomeScreen() {
        this.prefManager.setFirstTimeLaunch(false);
        startActivity(new Intent(this, FLA_HomeActivity.class).putExtra("isFirstLoad", true));
        finish();
    }


    public void changeScreenBg(int i) {
        Glide.with((FragmentActivity) this).asDrawable().load(Integer.valueOf(i)).into(new CustomTarget<Drawable>() { // from class: com.fingerprint.lock.liveanimation.Activities.IntroActivity.2
            @Override
            public void onLoadCleared(Drawable drawable) {
            }


            public void onResourceReady(Drawable drawable, Transition<? super Drawable> transition) {
                FLA_IntroActivity.this.binding.rootView.setBackground(drawable);
            }
        });
    }

    private void changeStatusBarColor() {
        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.setStatusBarColor(0);
    }

    public class MyViewPagerAdapter extends PagerAdapter {
        @Override
        public boolean isViewFromObject(View view, Object obj) {
            return view == obj;
        }

        public MyViewPagerAdapter() {

        }

        @Override
        public Object instantiateItem(ViewGroup viewGroup, int i) {
            View inflate = ((LayoutInflater) FLA_IntroActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(FLA_IntroActivity.this.layouts[i], viewGroup, false);
            viewGroup.addView(inflate);
            return inflate;
        }

        @Override
        public int getCount() {
            return FLA_IntroActivity.this.layouts.length;
        }

        @Override
        public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
            viewGroup.removeView((View) obj);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
