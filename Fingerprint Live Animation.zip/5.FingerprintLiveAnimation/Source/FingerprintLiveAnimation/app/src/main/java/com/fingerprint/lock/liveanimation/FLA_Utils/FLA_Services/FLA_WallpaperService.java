package com.fingerprint.lock.liveanimation.FLA_Utils.FLA_Services;

import android.app.KeyguardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.media.ThumbnailUtils;
import android.os.Handler;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import android.view.View;

import androidx.recyclerview.widget.ItemTouchHelper;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_EdgeEffect.FLA_Const;
import com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_EdgeEffect.FLA_EdgeBorderBorderLightAnimate;
import com.fingerprint.lock.liveanimation.R;
import com.fingerprint.lock.liveanimation.FLA_Utils.FLA_SharedPreferenceManager;


public class FLA_WallpaperService extends WallpaperService {
    public static boolean isSettingsUpdated = false;
    String animPath;
    private Rect backgroundRect;
    private Bitmap bitmapBg;
    String imgUrl;
    FLA_LottieView lottieView;
    int mHeight;
    int mWidth;
    public FLA_SharedPreferenceManager spm;
    String edgeShapeType = FLA_Const.LINE;
    int scaleValue = ItemTouchHelper.Callback.DEFAULT_SWIPE_ANIMATION_DURATION;
    int edgeColorType = 0;
    float positionValue = 1.5f;
    float animSpeedValue = 1.0f;
    boolean isEdgeActive = false;
    boolean isFingerAnimActive = false;
    int edgeSize = 40;
    int edgeAnimSpeed = 2;
    int edgeRadius = 0;
    boolean isPreviewOnly = false;
    boolean drawOk = false;

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public Engine onCreateEngine() {
        FLA_SharedPreferenceManager sharedPreferenceManager = new FLA_SharedPreferenceManager(getApplicationContext(), "clockData");
        this.spm = sharedPreferenceManager;
        boolean booleanValue = sharedPreferenceManager.getBooleanValue("isFingerAnimActive", this.isFingerAnimActive);
        this.isFingerAnimActive = booleanValue;
        if (booleanValue) {
            this.lottieView = new FLA_LottieView(getApplicationContext());
        }
        return new GIFWallpaperEngine();
    }

    public class GIFWallpaperEngine extends Engine implements SharedPreferences.OnSharedPreferenceChangeListener {
        Bitmap bitmap;
        int frameDuration;
        private final Handler handler;
        FLA_EdgeBorderBorderLightAnimate lightAnimate;
        private final Runnable runnable;
        private boolean visible;

        @Override
        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String str) {

        }

        @Override
        public void onCreate(SurfaceHolder surfaceHolder) {
            super.onCreate(surfaceHolder);
            FLA_WallpaperService.this.spm = new FLA_SharedPreferenceManager(FLA_WallpaperService.this.getApplicationContext(), "clockData");
            FLA_WallpaperService.this.spm.setInterface(this);
            if (isPreview()) {
                return;
            }
            FLA_WallpaperService.this.spm.setBooleanValue("hasApplied", false);
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder surfaceHolder, int i, final int i2, final int i3) {
            super.onSurfaceChanged(surfaceHolder, i, i2, i3);
            FLA_WallpaperService.this.backgroundRect = new Rect(0, 0, i2, i3);
            FLA_WallpaperService.this.mWidth = i2;
            FLA_WallpaperService.this.mHeight = i3;
            FLA_WallpaperService myWallpaperService = FLA_WallpaperService.this;
            myWallpaperService.positionValue = myWallpaperService.spm.getFloatValue("positionValue", FLA_WallpaperService.this.positionValue);
            FLA_WallpaperService myWallpaperService2 = FLA_WallpaperService.this;
            myWallpaperService2.animSpeedValue = myWallpaperService2.spm.getFloatValue("speedValue", FLA_WallpaperService.this.animSpeedValue);
            FLA_WallpaperService myWallpaperService3 = FLA_WallpaperService.this;
            myWallpaperService3.scaleValue = myWallpaperService3.spm.getIntValue("scaleValue", FLA_WallpaperService.this.scaleValue);
            FLA_WallpaperService myWallpaperService4 = FLA_WallpaperService.this;
            myWallpaperService4.animPath = myWallpaperService4.spm.getValue("animPath", FLA_WallpaperService.this.animPath);
            FLA_WallpaperService myWallpaperService5 = FLA_WallpaperService.this;
            myWallpaperService5.imgUrl = myWallpaperService5.spm.getValue("bgImg", FLA_WallpaperService.this.imgUrl);
            FLA_WallpaperService myWallpaperService6 = FLA_WallpaperService.this;
            myWallpaperService6.isEdgeActive = myWallpaperService6.spm.getBooleanValue("isEdgeActive", FLA_WallpaperService.this.isEdgeActive);
            FLA_WallpaperService myWallpaperService7 = FLA_WallpaperService.this;
            myWallpaperService7.isFingerAnimActive = myWallpaperService7.spm.getBooleanValue("isFingerAnimActive", FLA_WallpaperService.this.isFingerAnimActive);
            if (FLA_WallpaperService.this.isEdgeActive) {
                FLA_WallpaperService myWallpaperService8 = FLA_WallpaperService.this;
                myWallpaperService8.edgeSize = myWallpaperService8.spm.getIntValue("edgeSize", FLA_WallpaperService.this.edgeSize);
                FLA_WallpaperService myWallpaperService9 = FLA_WallpaperService.this;
                myWallpaperService9.edgeRadius = myWallpaperService9.spm.getIntValue("edgeRadius", FLA_WallpaperService.this.edgeRadius);
                FLA_WallpaperService myWallpaperService10 = FLA_WallpaperService.this;
                myWallpaperService10.edgeAnimSpeed = myWallpaperService10.spm.getIntValue("edgeAnimSpeed", FLA_WallpaperService.this.edgeAnimSpeed);
                FLA_WallpaperService myWallpaperService11 = FLA_WallpaperService.this;
                myWallpaperService11.edgeColorType = myWallpaperService11.spm.getIntValue("edgeColorType", FLA_WallpaperService.this.edgeColorType);
                FLA_WallpaperService myWallpaperService12 = FLA_WallpaperService.this;
                myWallpaperService12.edgeShapeType = myWallpaperService12.spm.getValue("edgeShapeType", FLA_WallpaperService.this.edgeShapeType);
                FLA_EdgeBorderBorderLightAnimate edgeBorderBorderLightAnimate = this.lightAnimate;
                if (edgeBorderBorderLightAnimate != null) {
                    edgeBorderBorderLightAnimate.onLayout(i2, i3);
                }
                if (edgeBorderBorderLightAnimate != null) {
                    edgeBorderBorderLightAnimate.changeSpeed(FLA_WallpaperService.this.edgeAnimSpeed);
                    edgeBorderBorderLightAnimate.changeSize(FLA_WallpaperService.this.edgeSize);
                    edgeBorderBorderLightAnimate.changeRadius(FLA_WallpaperService.this.edgeRadius, FLA_WallpaperService.this.edgeRadius);
                    edgeBorderBorderLightAnimate.changeColorType(FLA_WallpaperService.this.edgeColorType);
                    edgeBorderBorderLightAnimate.changeType(FLA_WallpaperService.this.edgeShapeType);
                }
            }
            if (FLA_WallpaperService.this.isFingerAnimActive && FLA_WallpaperService.this.lottieView != null) {
                FLA_WallpaperService.this.lottieView.setWidth(i2);
                FLA_WallpaperService.this.lottieView.setHeight(i3);
                FLA_WallpaperService.this.lottieView.setPositionY(FLA_WallpaperService.this.positionValue);
                FLA_WallpaperService.this.lottieView.setSize(FLA_WallpaperService.this.scaleValue);
                FLA_WallpaperService.this.lottieView.setFilePath(FLA_WallpaperService.this.animPath);
                FLA_WallpaperService.this.lottieView.setAnimSpeed(FLA_WallpaperService.this.animSpeedValue);
            }
            if (FLA_WallpaperService.this.imgUrl != null) {
                Glide.with(FLA_WallpaperService.this.getApplicationContext()).asBitmap().load(FLA_WallpaperService.this.imgUrl).into(new CustomTarget<Bitmap>() { // from class: com.fingerprint.lock.liveanimation.Utils.Services.MyWallpaperService.GIFWallpaperEngine.1
                    @Override
                    public void onLoadCleared(Drawable drawable) {
                    }


                    public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                        GIFWallpaperEngine.this.bitmap = bitmap;
                        if (i2 <= 0 || i3 <= 0 || FLA_WallpaperService.cropCenter(GIFWallpaperEngine.this.bitmap, i2, i3) == null) {
                            return;
                        }
                        FLA_WallpaperService.this.bitmapBg = FLA_WallpaperService.cropCenter(GIFWallpaperEngine.this.bitmap, i2, i3);
                    }
                });
            }
            if (this.bitmap == null) {
                Bitmap decodeResource = BitmapFactory.decodeResource(FLA_WallpaperService.this.getApplicationContext().getResources(), R.drawable.img_sample1);
                this.bitmap = decodeResource;
                if (i2 <= 0 || i3 <= 0) {
                    return;
                }
                FLA_WallpaperService.this.bitmapBg = FLA_WallpaperService.cropCenter(decodeResource, i2, i3);
            }
        }

        public GIFWallpaperEngine() {
            super();
            this.runnable = new Runnable() {
                @Override
                public final void run() {
                    GIFWallpaperEngine.this.draw();
                }
            };
            this.frameDuration = 5;
            this.handler = new Handler();
            this.lightAnimate = new FLA_EdgeBorderBorderLightAnimate(FLA_WallpaperService.this.getApplicationContext());
        }

        public void draw() {
            Canvas canvas;
            SurfaceHolder surfaceHolder = getSurfaceHolder();
            if (FLA_WallpaperService.this.drawOk) {
                try {
                    canvas = surfaceHolder.lockCanvas();
                    if (canvas != null) {
                        try {
                            draw(canvas);
                        } catch (Throwable th) {
                            th = th;
                            if (canvas != null) {
                                surfaceHolder.unlockCanvasAndPost(canvas);
                            }
                            throw th;
                        }
                    }
                    if (canvas != null) {
                        surfaceHolder.unlockCanvasAndPost(canvas);
                    }
                } catch (Throwable th2) {
                    canvas = null;
                }
            }
            this.handler.removeCallbacks(this.runnable);
            this.handler.postDelayed(this.runnable, this.frameDuration);
        }

        private void draw(Canvas canvas) {
            FLA_EdgeBorderBorderLightAnimate edgeBorderBorderLightAnimate;
            FLA_EdgeBorderBorderLightAnimate edgeBorderBorderLightAnimate2;
            if (this.visible) {
                FLA_WallpaperService.this.spm = new FLA_SharedPreferenceManager(FLA_WallpaperService.this.getApplicationContext(), "clockData");
                FLA_WallpaperService myWallpaperService = FLA_WallpaperService.this;
                myWallpaperService.isPreviewOnly = myWallpaperService.spm.getBooleanValue("isPreviewOnly", FLA_WallpaperService.this.isPreviewOnly);
                if (FLA_WallpaperService.this.isPreviewOnly) {
                    FLA_WallpaperService myWallpaperService2 = FLA_WallpaperService.this;
                    myWallpaperService2.isEdgeActive = myWallpaperService2.spm.getBooleanValue("isEdgeActive", FLA_WallpaperService.this.isEdgeActive);
                    FLA_WallpaperService myWallpaperService3 = FLA_WallpaperService.this;
                    myWallpaperService3.isFingerAnimActive = myWallpaperService3.spm.getBooleanValue("isFingerAnimActive", FLA_WallpaperService.this.isFingerAnimActive);
                    FLA_WallpaperService myWallpaperService4 = FLA_WallpaperService.this;
                    myWallpaperService4.positionValue = myWallpaperService4.spm.getFloatValue("positionValue", FLA_WallpaperService.this.positionValue);
                    FLA_WallpaperService myWallpaperService5 = FLA_WallpaperService.this;
                    myWallpaperService5.animSpeedValue = myWallpaperService5.spm.getFloatValue("speedValue", FLA_WallpaperService.this.animSpeedValue);
                    FLA_WallpaperService myWallpaperService6 = FLA_WallpaperService.this;
                    myWallpaperService6.scaleValue = myWallpaperService6.spm.getIntValue("scaleValue", FLA_WallpaperService.this.scaleValue);
                    FLA_WallpaperService myWallpaperService7 = FLA_WallpaperService.this;
                    myWallpaperService7.animPath = myWallpaperService7.spm.getValue("animPath", FLA_WallpaperService.this.animPath);
                    FLA_WallpaperService myWallpaperService8 = FLA_WallpaperService.this;
                    myWallpaperService8.imgUrl = myWallpaperService8.spm.getValue("bgImg", FLA_WallpaperService.this.imgUrl);
                    FLA_WallpaperService myWallpaperService9 = FLA_WallpaperService.this;
                    myWallpaperService9.edgeSize = myWallpaperService9.spm.getIntValue("edgeSize", FLA_WallpaperService.this.edgeSize);
                    FLA_WallpaperService myWallpaperService10 = FLA_WallpaperService.this;
                    myWallpaperService10.edgeRadius = myWallpaperService10.spm.getIntValue("edgeRadius", FLA_WallpaperService.this.edgeRadius);
                    FLA_WallpaperService myWallpaperService11 = FLA_WallpaperService.this;
                    myWallpaperService11.edgeAnimSpeed = myWallpaperService11.spm.getIntValue("edgeAnimSpeed", FLA_WallpaperService.this.edgeAnimSpeed);
                    FLA_WallpaperService myWallpaperService12 = FLA_WallpaperService.this;
                    myWallpaperService12.edgeColorType = myWallpaperService12.spm.getIntValue("edgeColorType", FLA_WallpaperService.this.edgeColorType);
                    FLA_WallpaperService myWallpaperService13 = FLA_WallpaperService.this;
                    myWallpaperService13.edgeShapeType = myWallpaperService13.spm.getValue("edgeShapeType", FLA_WallpaperService.this.edgeShapeType);
                    if (FLA_WallpaperService.this.isFingerAnimActive && FLA_WallpaperService.this.lottieView != null) {
                        FLA_WallpaperService.this.lottieView.setPositionY(FLA_WallpaperService.this.positionValue);
                        FLA_WallpaperService.this.lottieView.setSize(FLA_WallpaperService.this.scaleValue);
                        FLA_WallpaperService.this.lottieView.setFilePath(FLA_WallpaperService.this.animPath);
                        FLA_WallpaperService.this.lottieView.setAnimSpeed(FLA_WallpaperService.this.animSpeedValue);
                    }
                    if (FLA_WallpaperService.this.isEdgeActive && (edgeBorderBorderLightAnimate2 = this.lightAnimate) != null) {
                        edgeBorderBorderLightAnimate2.changeSpeed(FLA_WallpaperService.this.edgeAnimSpeed);
                        this.lightAnimate.changeSize(FLA_WallpaperService.this.edgeSize);
                        this.lightAnimate.changeRadius(FLA_WallpaperService.this.edgeRadius, FLA_WallpaperService.this.edgeRadius);
                        this.lightAnimate.changeColorType(FLA_WallpaperService.this.edgeColorType);
                        this.lightAnimate.changeType(FLA_WallpaperService.this.edgeShapeType);
                    }
                    Glide.with(FLA_WallpaperService.this.getApplicationContext()).asBitmap().load(FLA_WallpaperService.this.imgUrl).into(new CustomTarget<Bitmap>() { // from class: com.fingerprint.lock.liveanimation.Utils.Services.MyWallpaperService.GIFWallpaperEngine.2
                        @Override
                        public void onLoadCleared(Drawable drawable) {
                        }


                        public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                            GIFWallpaperEngine.this.bitmap = bitmap;
                            if (FLA_WallpaperService.this.mWidth <= 0 || FLA_WallpaperService.this.mHeight <= 0) {
                                return;
                            }
                            FLA_WallpaperService.this.bitmapBg = FLA_WallpaperService.cropCenter(GIFWallpaperEngine.this.bitmap, FLA_WallpaperService.this.mWidth, FLA_WallpaperService.this.mHeight);
                        }
                    });
                    if (this.bitmap == null) {
                        this.bitmap = BitmapFactory.decodeResource(FLA_WallpaperService.this.getApplicationContext().getResources(), R.drawable.img_sample1);
                        if (FLA_WallpaperService.this.mWidth > 0 && FLA_WallpaperService.this.mHeight > 0) {
                            FLA_WallpaperService myWallpaperService14 = FLA_WallpaperService.this;
                            myWallpaperService14.bitmapBg = FLA_WallpaperService.cropCenter(this.bitmap, myWallpaperService14.mWidth, FLA_WallpaperService.this.mHeight);
                        }
                    }
                    FLA_WallpaperService.isSettingsUpdated = false;
                    FLA_WallpaperService.this.spm.setBooleanValue("isPreviewOnly", false);
                }
                if (FLA_WallpaperService.this.bitmapBg != null) {
                    canvas.drawBitmap(FLA_WallpaperService.this.bitmapBg, (Rect) null, FLA_WallpaperService.this.backgroundRect, (Paint) null);
                }
                if (FLA_WallpaperService.this.isEdgeActive && (edgeBorderBorderLightAnimate = this.lightAnimate) != null) {
                    edgeBorderBorderLightAnimate.onDraw(canvas);
                }
                if (isPreview()) {
                    if (!FLA_WallpaperService.this.isFingerAnimActive || FLA_WallpaperService.this.lottieView == null) {
                        return;
                    }
                    FLA_WallpaperService.this.lottieView.draw(canvas);
                } else if (((KeyguardManager) FLA_WallpaperService.this.getApplicationContext().getSystemService(Context.KEYGUARD_SERVICE)).inKeyguardRestrictedInputMode()) {
                    if (!FLA_WallpaperService.this.isFingerAnimActive || FLA_WallpaperService.this.lottieView == null) {
                        return;
                    }
                    FLA_WallpaperService.this.lottieView.draw(canvas);
                } else if (!FLA_WallpaperService.this.isFingerAnimActive || FLA_WallpaperService.this.lottieView == null) {
                } else {
                    FLA_WallpaperService.this.lottieView.setVisibility(View.GONE);
                }
            }
        }

        @Override
        public void onVisibilityChanged(boolean z) {
            this.visible = z;
            if (z) {
                this.handler.post(this.runnable);
                FLA_WallpaperService.this.drawOk = true;
                return;
            }
            this.handler.removeCallbacks(this.runnable);
            FLA_WallpaperService.this.drawOk = false;
        }

        @Override
        public void onDestroy() {
            super.onDestroy();
            this.handler.removeCallbacks(this.runnable);
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder surfaceHolder) {
            super.onSurfaceDestroyed(surfaceHolder);
            this.handler.removeCallbacks(this.runnable);
            FLA_WallpaperService.this.drawOk = false;
        }
    }

    public static Bitmap cropCenter(Bitmap bitmap, int i, int i2) {
        if (bitmap == null || i <= 0 || i2 <= 0) {
            return null;
        }
        return ThumbnailUtils.extractThumbnail(bitmap, i, i2);
    }

    public static void setToWallPaper(Context context) {
        Intent intent = new Intent("android.service.wallpaper.CHANGE_LIVE_WALLPAPER");
        intent.putExtra("android.service.wallpaper.extra.LIVE_WALLPAPER_COMPONENT", new ComponentName(context, FLA_WallpaperService.class));
        context.startActivity(intent);
    }
}
