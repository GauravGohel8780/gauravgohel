package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_LikeButton;

import android.animation.ArgbEvaluator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Property;
import android.view.View;


public class FLA_DotsView extends View {
    public static final Property<FLA_DotsView, Float> DOTS_PROGRESS = new Property<FLA_DotsView, Float>(Float.class, "dotsProgress") {
        @Override
        public Float get(FLA_DotsView dotsView) {
            return Float.valueOf(dotsView.getCurrentProgress());
        }

        @Override
        public void set(FLA_DotsView dotsView, Float f) {
            dotsView.setCurrentProgress(f.floatValue());
        }
    };
    private int COLOR_1;
    private int COLOR_2;
    private int COLOR_3;
    private int COLOR_4;
    private ArgbEvaluator argbEvaluator;
    private int centerX;
    private int centerY;
    private final Paint[] circlePaints;
    private float currentDotSize1;
    private float currentDotSize2;
    private float currentProgress;
    private float currentRadius1;
    private float currentRadius2;
    private int height;
    private float maxDotSize;
    private float maxInnerDotsRadius;
    private float maxOuterDotsRadius;
    private int width;

    public float getCurrentProgress() {
        return this.currentProgress;
    }

    public FLA_DotsView(Context context) {
        super(context);
        this.COLOR_1 = -16121;
        this.COLOR_2 = -26624;
        this.COLOR_3 = -43230;
        this.COLOR_4 = -769226;
        this.width = 0;
        this.height = 0;
        this.circlePaints = new Paint[4];
        this.currentProgress = 0.0f;
        this.currentRadius1 = 0.0f;
        this.currentDotSize1 = 0.0f;
        this.currentDotSize2 = 0.0f;
        this.currentRadius2 = 0.0f;
        this.argbEvaluator = new ArgbEvaluator();
        init();
    }

    public FLA_DotsView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.COLOR_1 = -16121;
        this.COLOR_2 = -26624;
        this.COLOR_3 = -43230;
        this.COLOR_4 = -769226;
        this.width = 0;
        this.height = 0;
        this.circlePaints = new Paint[4];
        this.currentProgress = 0.0f;
        this.currentRadius1 = 0.0f;
        this.currentDotSize1 = 0.0f;
        this.currentDotSize2 = 0.0f;
        this.currentRadius2 = 0.0f;
        this.argbEvaluator = new ArgbEvaluator();
        init();
    }

    public FLA_DotsView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.COLOR_1 = -16121;
        this.COLOR_2 = -26624;
        this.COLOR_3 = -43230;
        this.COLOR_4 = -769226;
        this.width = 0;
        this.height = 0;
        this.circlePaints = new Paint[4];
        this.currentProgress = 0.0f;
        this.currentRadius1 = 0.0f;
        this.currentDotSize1 = 0.0f;
        this.currentDotSize2 = 0.0f;
        this.currentRadius2 = 0.0f;
        this.argbEvaluator = new ArgbEvaluator();
        init();
    }

    private void init() {
        int i = 0;
        while (true) {
            Paint[] paintArr = this.circlePaints;
            if (i >= paintArr.length) {
                return;
            }
            paintArr[i] = new Paint();
            this.circlePaints[i].setStyle(Paint.Style.FILL);
            this.circlePaints[i].setAntiAlias(true);
            i++;
        }
    }

    @Override 
    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        int i5 = i / 2;
        this.centerX = i5;
        this.centerY = i2 / 2;
        this.maxDotSize = 5.0f;
        float f = i5 - (5.0f * 2.0f);
        this.maxOuterDotsRadius = f;
        this.maxInnerDotsRadius = f * 0.8f;
    }

    @Override 
    protected void onDraw(Canvas canvas) {
        drawOuterDotsFrame(canvas);
        drawInnerDotsFrame(canvas);
    }

    private void drawOuterDotsFrame(Canvas canvas) {
        for (int i = 0; i < 7; i++) {
            double d = ((i * 51) * 3.141592653589793d) / 180.0d;
            float f = this.currentDotSize1;
            Paint[] paintArr = this.circlePaints;
            canvas.drawCircle((int) (this.centerX + (this.currentRadius1 * Math.cos(d))), (int) (this.centerY + (this.currentRadius1 * Math.sin(d))), f, paintArr[i % paintArr.length]);
        }
    }

    private void drawInnerDotsFrame(Canvas canvas) {
        int i = 0;
        while (i < 7) {
            double d = (((i * 51) - 10) * 3.141592653589793d) / 180.0d;
            float f = this.currentDotSize2;
            Paint[] paintArr = this.circlePaints;
            i++;
            canvas.drawCircle((int) (this.centerX + (this.currentRadius2 * Math.cos(d))), (int) (this.centerY + (this.currentRadius2 * Math.sin(d))), f, paintArr[i % paintArr.length]);
        }
    }

    public void setCurrentProgress(float f) {
        this.currentProgress = f;
        updateInnerDotsPosition();
        updateOuterDotsPosition();
        updateDotsPaints();
        updateDotsAlpha();
        postInvalidate();
    }

    private void updateInnerDotsPosition() {
        float f = this.currentProgress;
        if (f < 0.3f) {
            this.currentRadius2 = (float) FLA_Utils.mapValueFromRangeToRange(f, 0.0d, 0.30000001192092896d, 0.0d, this.maxInnerDotsRadius);
        } else {
            this.currentRadius2 = this.maxInnerDotsRadius;
        }
        float f2 = this.currentProgress;
        if (f2 == 0.0f) {
            this.currentDotSize2 = 0.0f;
        } else if (f2 < 0.2d) {
            this.currentDotSize2 = this.maxDotSize;
        } else if (f2 < 0.5d) {
            double d = f2;
            float f3 = this.maxDotSize;
            this.currentDotSize2 = (float) FLA_Utils.mapValueFromRangeToRange(d, 0.20000000298023224d, 0.5d, f3, f3 * 0.3d);
        } else {
            this.currentDotSize2 = (float) FLA_Utils.mapValueFromRangeToRange(f2, 0.5d, 1.0d, this.maxDotSize * 0.3f, 0.0d);
        }
    }

    private void updateOuterDotsPosition() {
        float f = this.currentProgress;
        if (f < 0.3f) {
            this.currentRadius1 = (float) FLA_Utils.mapValueFromRangeToRange(f, 0.0d, 0.30000001192092896d, 0.0d, this.maxOuterDotsRadius * 0.8f);
        } else {
            float f2 = this.maxOuterDotsRadius;
            this.currentRadius1 = (float) FLA_Utils.mapValueFromRangeToRange(f, 0.30000001192092896d, 1.0d, 0.8f * f2, f2);
        }
        float f3 = this.currentProgress;
        if (f3 == 0.0f) {
            this.currentDotSize1 = 0.0f;
        } else if (f3 < 0.7d) {
            this.currentDotSize1 = this.maxDotSize;
        } else {
            this.currentDotSize1 = (float) FLA_Utils.mapValueFromRangeToRange(f3, 0.699999988079071d, 1.0d, this.maxDotSize, 0.0d);
        }
    }

    private void updateDotsPaints() {
        float f = this.currentProgress;
        if (f < 0.5f) {
            float mapValueFromRangeToRange = (float) FLA_Utils.mapValueFromRangeToRange(f, 0.0d, 0.5d, 0.0d, 1.0d);
            this.circlePaints[0].setColor(((Integer) this.argbEvaluator.evaluate(mapValueFromRangeToRange, Integer.valueOf(this.COLOR_1), Integer.valueOf(this.COLOR_2))).intValue());
            this.circlePaints[1].setColor(((Integer) this.argbEvaluator.evaluate(mapValueFromRangeToRange, Integer.valueOf(this.COLOR_2), Integer.valueOf(this.COLOR_3))).intValue());
            this.circlePaints[2].setColor(((Integer) this.argbEvaluator.evaluate(mapValueFromRangeToRange, Integer.valueOf(this.COLOR_3), Integer.valueOf(this.COLOR_4))).intValue());
            this.circlePaints[3].setColor(((Integer) this.argbEvaluator.evaluate(mapValueFromRangeToRange, Integer.valueOf(this.COLOR_4), Integer.valueOf(this.COLOR_1))).intValue());
            return;
        }
        float mapValueFromRangeToRange2 = (float) FLA_Utils.mapValueFromRangeToRange(f, 0.5d, 1.0d, 0.0d, 1.0d);
        this.circlePaints[0].setColor(((Integer) this.argbEvaluator.evaluate(mapValueFromRangeToRange2, Integer.valueOf(this.COLOR_2), Integer.valueOf(this.COLOR_3))).intValue());
        this.circlePaints[1].setColor(((Integer) this.argbEvaluator.evaluate(mapValueFromRangeToRange2, Integer.valueOf(this.COLOR_3), Integer.valueOf(this.COLOR_4))).intValue());
        this.circlePaints[2].setColor(((Integer) this.argbEvaluator.evaluate(mapValueFromRangeToRange2, Integer.valueOf(this.COLOR_4), Integer.valueOf(this.COLOR_1))).intValue());
        this.circlePaints[3].setColor(((Integer) this.argbEvaluator.evaluate(mapValueFromRangeToRange2, Integer.valueOf(this.COLOR_1), Integer.valueOf(this.COLOR_2))).intValue());
    }

    public void setColors(int i, int i2) {
        this.COLOR_1 = i;
        this.COLOR_2 = i2;
        this.COLOR_3 = i;
        this.COLOR_4 = i2;
        invalidate();
    }

    private void updateDotsAlpha() {
        int mapValueFromRangeToRange = (int) FLA_Utils.mapValueFromRangeToRange((float) FLA_Utils.clamp(this.currentProgress, 0.6000000238418579d, 1.0d), 0.6000000238418579d, 1.0d, 255.0d, 0.0d);
        this.circlePaints[0].setAlpha(mapValueFromRangeToRange);
        this.circlePaints[1].setAlpha(mapValueFromRangeToRange);
        this.circlePaints[2].setAlpha(mapValueFromRangeToRange);
        this.circlePaints[3].setAlpha(mapValueFromRangeToRange);
    }

    public void setSize(int i, int i2) {
        this.width = i;
        this.height = i2;
        invalidate();
    }

    @Override 
    protected void onMeasure(int i, int i2) {
        int i3;
        super.onMeasure(i, i2);
        int i4 = this.width;
        if (i4 == 0 || (i3 = this.height) == 0) {
            return;
        }
        setMeasuredDimension(i4, i3);
    }
}
