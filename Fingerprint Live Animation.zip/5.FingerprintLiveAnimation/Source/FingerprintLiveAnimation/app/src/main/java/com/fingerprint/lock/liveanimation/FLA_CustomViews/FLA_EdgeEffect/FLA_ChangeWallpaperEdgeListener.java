package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_EdgeEffect;

import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.fingerprint.lock.liveanimation.R;

import java.io.File;


public class FLA_ChangeWallpaperEdgeListener {
    private static final String TAG = "ListenerChangeWallpaper";
    private final FLA_EdgeBorderBorderLightAnimate animate;
    private final Context context;
    private final int height;
    private final int width;

    public FLA_ChangeWallpaperEdgeListener(FLA_EdgeBorderBorderLightAnimate edgeBorderBorderLightAnimate, Context context, int i, int i2) {
        this.animate = edgeBorderBorderLightAnimate;
        this.context = context;
        this.width = i;
        this.height = i2;
    }

    public void lisenerChangeColor(String str) {
        String string;
        String string2;
        String string3;
        String string4;
        String string5;
        String string6;
        if (str.equals(FLA_Const.Action_DemoLiveWallpaper)) {
            string = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.COLOR1, this.context);
            string2 = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.COLOR2, this.context);
            string3 = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.COLOR3, this.context);
            string4 = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.COLOR4, this.context);
            string5 = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.COLOR5, this.context);
            string6 = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.COLOR6, this.context);
        } else {
            string = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.FINISH_COLOR1, this.context);
            string2 = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.FINISH_COLOR2, this.context);
            string3 = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.FINISH_COLOR3, this.context);
            string4 = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.FINISH_COLOR4, this.context);
            string5 = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.FINISH_COLOR5, this.context);
            string6 = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.FINISH_COLOR6, this.context);
        }
        if (string == null) {
            string = "#EB1111";
        }
        if (string2 == null) {
            string2 = "#1A11EB";
        }
        if (string3 == null) {
            string3 = "#EB11DA";
        }
        if (string4 == null) {
            string4 = "#11D6EB";
        }
        if (string5 == null) {
            string5 = "#EBDA11";
        }
        if (string6 == null) {
            string6 = "#11EB37";
        }
        this.animate.changeColor(new int[]{Color.parseColor(string), Color.parseColor(string2), Color.parseColor(string3), Color.parseColor(string4), Color.parseColor(string5), Color.parseColor(string6), Color.parseColor(string)});
    }

    public void lisenerChangeBorder(String str) {
        int i;
        int i2;
        int i3;
        int i4;
        if (str.equals(FLA_Const.Action_DemoLiveWallpaper)) {
            i = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.SPEED, this.context);
            i2 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.SIZE, this.context);
            i3 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.RADIUSTOP, this.context);
            i4 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.RADIUSBOTTOM, this.context);
        } else {
            i = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.FINISH_SPEED, this.context);
            i2 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.FINISH_SIZE, this.context);
            i3 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.FINISH_RADIUSTOP, this.context);
            i4 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.FINISH_RADIUSBOTTOM, this.context);
        }
        this.animate.changeSpeed(i);
        this.animate.changeSize(i2);
        this.animate.changeRadius(i3, i4);
    }

    public void lisenerChangeNotch(String str) {
        boolean booleanValue;
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        if (str.equals(FLA_Const.Action_DemoLiveWallpaper)) {
            booleanValue = FLA_MySharePreferencesEdge.getBooleanValue(FLA_MySharePreferencesEdge.CHECKNOTCH, this.context);
            i = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.NOTCHTOP, this.context);
            i2 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.NOTCHRADIUSTOP, this.context);
            i3 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.NOTCHRADIUSBOTTOM, this.context);
            i4 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.NOTCHBOTTOM, this.context);
            i5 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.NOTCHHEIGHT, this.context);
        } else {
            booleanValue = FLA_MySharePreferencesEdge.getBooleanValue(FLA_MySharePreferencesEdge.FINISH_CHECKNOTCH, this.context);
            i = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.FINISH_NOTCHTOP, this.context);
            i2 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.FINISH_NOTCHRADIUSTOP, this.context);
            i3 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.FINISH_NOTCHRADIUSBOTTOM, this.context);
            i4 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.FINISH_NOTCHBOTTOM, this.context);
            i5 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.FINISH_NOTCHHEIGHT, this.context);
        }
        FLA_EdgeBorderBorderLightAnimate edgeBorderBorderLightAnimate = this.animate;
        edgeBorderBorderLightAnimate.changeNotch(booleanValue, i, i4, i5, i2, i3);
    }

    public void listenerChangeBackground(String str) {
        int i;
        String string;
        String string2;
        int i2;
        if (str.equals(FLA_Const.Action_DemoLiveWallpaper)) {
            i = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.BACKGROUND, this.context);
            string = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.BACKGROUNDCOLOR, this.context);
            string2 = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.BACKGROUNDLINK, this.context);
        } else {
            i = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.FINISH_BACKGROUND, this.context);
            string = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.FINISH_BACKGROUNDCOLOR, this.context);
            string2 = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.FINISH_BACKGROUNDLINK, this.context);
        }
        if (i == 1) {
            if (ActivityCompat.checkSelfPermission(this.context, "android.permission.READ_EXTERNAL_STORAGE") != 0) {
                return;
            }
            this.animate.setBitmap(Bitmap.createScaledBitmap(drawableToBitmap(WallpaperManager.getInstance(this.context).getDrawable()), this.width, this.height, false));
        } else if (i != 2) {
            int i3 = this.width;
            if (i3 <= 0 || (i2 = this.height) <= 0) {
                return;
            }
            Bitmap createBitmap = Bitmap.createBitmap(i3, i2, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(createBitmap);
            if (string == null) {
                canvas.drawColor(ContextCompat.getColor(this.context, R.color.black));
            } else {
                canvas.drawColor(Color.parseColor(string));
            }
            this.animate.setBitmap(createBitmap);
        } else if (string2 != null) {
            if (new File(string2).exists()) {
                Glide.with(this.context).asBitmap().load(string2).override(this.width, this.height).into(new CustomTarget<Bitmap>() { // from class: com.fingerprint.lock.liveanimation.CustomViews.EdgeEffect.ChangeWallpaperEdgeListener.1
                    @Override 
                    public void onLoadCleared(Drawable drawable) {
                    }

                    public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                        FLA_ChangeWallpaperEdgeListener.this.animate.setBitmap(bitmap);
                    }
                });
                return;
            }
            Bitmap createBitmap2 = Bitmap.createBitmap(this.width, this.height, Bitmap.Config.ARGB_8888);
            Canvas canvas2 = new Canvas(createBitmap2);
            if (string == null) {
                canvas2.drawColor(ContextCompat.getColor(this.context, R.color.black));
            } else {
                canvas2.drawColor(Color.parseColor(string));
            }
            this.animate.setBitmap(createBitmap2);
        }
    }

    public void listenerChangeType(String str) {
        String string;
        if (str.equals(FLA_Const.Action_DemoLiveWallpaper)) {
            string = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.SHAPE, this.context);
        } else {
            string = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.FINISH_SHAPE, this.context);
        }
        if (string != null) {
            if (string.equals(FLA_Const.LINE)) {
                this.animate.changeShape(string, null);
            } else {
                this.animate.changeShape(string, null);
            }
        }
    }

    public void listenerChangeHole(String str) {
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        boolean equals = str.equals(FLA_Const.Action_DemoLiveWallpaper);
        String str2 = FLA_Const.NO;
        if (equals) {
            String string = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.HOLESHARP, this.context);
            if (string != null) {
                str2 = string;
            }
            i = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.HOLEX, this.context);
            i2 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.HOLEY, this.context);
            i3 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.HOLERADIUS, this.context);
            i4 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.HOLERADIUSY, this.context);
            i5 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.HOLECORNER, this.context);
        } else {
            String string2 = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.FINISH_HOLESHARP, this.context);
            if (string2 != null) {
                str2 = string2;
            }
            i = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.FINISH_HOLEX, this.context);
            i2 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.FINISH_HOLEY, this.context);
            i3 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.FINISH_HOLERADIUS, this.context);
            i4 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.FINISH_HOLERADIUSY, this.context);
            i5 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.FINISH_HOLECORNER, this.context);
        }
        FLA_EdgeBorderBorderLightAnimate edgeBorderBorderLightAnimate = this.animate;
        edgeBorderBorderLightAnimate.changeHole(str2, i, i2, i3, i4, i5);
    }

    public void listenerChangeInfility(String str) {
        int i;
        int i2;
        int i3;
        int i4;
        boolean equals = str.equals(FLA_Const.Action_DemoLiveWallpaper);
        String str2 = FLA_Const.NO;
        if (equals) {
            String string = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.INFILITYSHARP, this.context);
            if (string != null) {
                str2 = string;
            }
            i = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.INFILITYWIDTH, this.context);
            i2 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.INFILITYHEIGHT, this.context);
            i3 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.INFILITYRADIUS, this.context);
            i4 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.INFILITYRADIUSB, this.context);
        } else {
            String string2 = FLA_MySharePreferencesEdge.getString(FLA_MySharePreferencesEdge.FINISH_INFILITYSHARP, this.context);
            if (string2 != null) {
                str2 = string2;
            }
            i = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.FINISH_INFILITYWIDTH, this.context);
            i2 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.FINISH_INFILITYHEIGHT, this.context);
            i3 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.FINISH_INFILITYRADIUS, this.context);
            i4 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.FINISH_INFILITYRADIUSB, this.context);
        }
        FLA_EdgeBorderBorderLightAnimate edgeBorderBorderLightAnimate = this.animate;
        edgeBorderBorderLightAnimate.changeInfility(str2, i, i2, i3, i4);
    }

    public static Bitmap drawableToBitmap(Drawable drawable) {
        Bitmap createBitmap;
        if (drawable instanceof BitmapDrawable) {
            BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;
            if (bitmapDrawable.getBitmap() != null) {
                return bitmapDrawable.getBitmap();
            }
        }
        if (drawable.getIntrinsicWidth() <= 0 || drawable.getIntrinsicHeight() <= 0) {
            createBitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        } else {
            createBitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        }
        Canvas canvas = new Canvas(createBitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return createBitmap;
    }
}
