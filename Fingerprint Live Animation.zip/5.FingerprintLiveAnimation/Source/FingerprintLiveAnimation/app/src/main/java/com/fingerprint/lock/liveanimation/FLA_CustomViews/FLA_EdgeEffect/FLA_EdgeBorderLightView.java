package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_EdgeEffect;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.View;

import androidx.core.view.InputDeviceCompat;

import com.fingerprint.lock.liveanimation.R;


public class FLA_EdgeBorderLightView extends View {
    public FLA_EdgeBorderBorderLightAnimate animate;
    private FLA_ChangeWallpaperEdgeListener changeWallpaper;
    int[] colors0;
    int[] colors1;
    int[] colors10;
    int[] colors2;
    int[] colors3;
    int[] colors4;
    int[] colors5;
    int[] colors6;
    int[] colors7;
    int[] colors8;
    int[] colors9;

    public FLA_EdgeBorderLightView(Context context) {
        super(context);
        init();
    }

    public FLA_EdgeBorderLightView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init();
    }

    public FLA_EdgeBorderLightView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init();
    }

    @Override 
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        FLA_EdgeBorderBorderLightAnimate edgeBorderBorderLightAnimate = this.animate;
        if (edgeBorderBorderLightAnimate != null) {
            edgeBorderBorderLightAnimate.onLayout(getWidth(), getHeight());
            invalidate();
        }
    }

    @Override 
    public void onDraw(Canvas canvas) {
        FLA_EdgeBorderBorderLightAnimate edgeBorderBorderLightAnimate = this.animate;
        if (edgeBorderBorderLightAnimate != null) {
            edgeBorderBorderLightAnimate.onDraw(canvas);
            postInvalidateDelayed(30L);
        }
    }

    private void init() {
        this.colors0 = new int[]{-65536, InputDeviceCompat.SOURCE_ANY, -16711936, Color.parseColor("#FF03A9F4"), -16776961, -65281, -65536};
        this.colors1 = getContext().getResources().getIntArray(R.array.color_pack_1);
        this.colors2 = getContext().getResources().getIntArray(R.array.color_pack_2);
        this.colors3 = getContext().getResources().getIntArray(R.array.color_pack_3);
        this.colors4 = getContext().getResources().getIntArray(R.array.color_pack_4);
        this.colors5 = getContext().getResources().getIntArray(R.array.color_pack_5);
        this.colors6 = getContext().getResources().getIntArray(R.array.color_pack_6);
        this.colors7 = getContext().getResources().getIntArray(R.array.color_pack_7);
        this.colors8 = getContext().getResources().getIntArray(R.array.color_pack_8);
        this.colors9 = getContext().getResources().getIntArray(R.array.color_pack_9);
        this.colors10 = getContext().getResources().getIntArray(R.array.color_pack_10);
        FLA_EdgeBorderBorderLightAnimate edgeBorderBorderLightAnimate = new FLA_EdgeBorderBorderLightAnimate(getContext());
        this.animate = edgeBorderBorderLightAnimate;
        this.changeWallpaper = new FLA_ChangeWallpaperEdgeListener(edgeBorderBorderLightAnimate, getContext(), getContext().getResources().getDisplayMetrics().widthPixels, getContext().getResources().getDisplayMetrics().heightPixels);
    }

    public void setShape(String str) {
        this.changeWallpaper.listenerChangeType(str);
    }

    public void changeColorType(int i) {
        switch (i) {
            case 1:
                this.animate.changeColor(this.colors1);
                return;
            case 2:
                this.animate.changeColor(this.colors2);
                return;
            case 3:
                this.animate.changeColor(this.colors3);
                return;
            case 4:
                this.animate.changeColor(this.colors4);
                return;
            case 5:
                this.animate.changeColor(this.colors5);
                return;
            case 6:
                this.animate.changeColor(this.colors6);
                return;
            case 7:
                this.animate.changeColor(this.colors7);
                return;
            case 8:
                this.animate.changeColor(this.colors8);
                return;
            case 9:
                this.animate.changeColor(this.colors9);
                return;
            case 10:
                this.animate.changeColor(this.colors10);
                return;
            default:
                this.animate.changeColor(this.colors0);
                return;
        }
    }

    public void changeSize(int i) {
        this.animate.changeSize(i);
    }

    public void changeSpeed(int i) {
        this.animate.changeSpeed(i);
    }

    public void changeBorder(int i, int i2) {
        this.animate.changeRadius(i, i2);
    }

    public void changeType(final String str) {
        new FLA_DecodeEdgeResource(getContext(), str, new FLA_DecodeEdgeResource.CallBack() {
            @Override
            public void decodeDone(Bitmap bitmap) {
                animate.changeShape(str, bitmap);
            }
        }).execute(new Void[0]);
    }
}
