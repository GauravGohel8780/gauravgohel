package com.fingerprint.lock.liveanimation.Ads_Common;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_EdgeEffect.FLA_Const;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_HomeScreenModel;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_SelectColorModel;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_ShapesModel;
import com.fingerprint.lock.liveanimation.FLA_Utils.FLA_SharedPreferenceManager;
import com.fingerprint.lock.liveanimation.R;
import com.iten.tenoku.utils.AdConstant;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class AdsBaseActivity extends AppCompatActivity {
    @Override
    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
    }

    @Override
    protected void onStart() {
        super.onStart();
        AdConstant.isResume = true;
    }

    public static final String Unl_Frame_List = "un_frame_list";
    public static final String rw_date_spm = "rw_date_spm";
    public Dialog premiumDialog;
    public FLA_SharedPreferenceManager sharedPreferenceManager;
    public FLA_SharedPreferenceManager spm_for_date;
    public FLA_SharedPreferenceManager spm_for_un_list;
    String TAG = "BillingInit_Main_";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.sharedPreferenceManager = new FLA_SharedPreferenceManager(getApplicationContext(), "in_app_purchased");
        this.spm_for_un_list = new FLA_SharedPreferenceManager(getApplicationContext(), Unl_Frame_List);
        this.spm_for_date = new FLA_SharedPreferenceManager(getApplicationContext(), rw_date_spm);

    }

    public void showToast(String str) {
        final Toast makeText = Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT);
        new Handler().postDelayed(new Runnable() {
            @Override
            public final void run() {
                if (makeText != null) {
                    makeText.cancel();
                }
            }
        }, 1000);
        if (makeText != null) {
            makeText.show();
        }
    }

    public static void registerInAppMsgEventForActivity(Activity activity, String str) {
        Bundle bundle = new Bundle();
        bundle.putBoolean(str + "_tag", true);

    }

    public ArrayList<String> loadLikedDataList(Activity activity) {
        SharedPreferences sharedPreferences = activity.getSharedPreferences("liked", 0);
        ArrayList<String> arrayList = new ArrayList<>();
        Set<String> stringSet = sharedPreferences.getStringSet("like", null);
        return stringSet != null ? new ArrayList<>(stringSet) : arrayList;
    }

    public ArrayList<FLA_HomeScreenModel> getHomeScreenData(Context context, String str, ArrayList<String> arrayList, boolean z) {
        ArrayList<FLA_HomeScreenModel> arrayList2 = new ArrayList<>();
        if (context.getExternalCacheDir() != null) {
            String str2 = context.getExternalCacheDir().toString() + "/data/";
            InputStream openRawResource = context.getResources().openRawResource(R.raw.all_data);
            StringWriter stringWriter = new StringWriter();
            char[] cArr = new char[1024];
            try {
                try {
                    try {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(openRawResource, StandardCharsets.UTF_8));
                        while (true) {
                            int read = bufferedReader.read(cArr);
                            if (read == -1) {
                                break;
                            }
                            stringWriter.write(cArr, 0, read);
                        }
                        openRawResource.close();
                    } catch (Throwable th) {
                        try {
                            openRawResource.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        throw th;
                    }
                } catch (Exception e2) {
                    e2.printStackTrace();
                    openRawResource.close();
                }
            } catch (IOException e3) {
                e3.printStackTrace();
            }
            try {
                JSONArray jSONArray = new JSONObject(stringWriter.toString()).getJSONArray(str);
                String str3 = "bgPath";
                if (z) {
                    int length = jSONArray.length() - 1;
                    while (length >= 0) {
                        FLA_HomeScreenModel homeScreenModel = new FLA_HomeScreenModel();
                        JSONObject jSONObject = jSONArray.getJSONObject(length);
                        homeScreenModel.setId(jSONObject.getInt("id"));
                        String str4 = str2 + jSONObject.getString(str3);
                        String str5 = str3;
                        homeScreenModel.setBgPath(str4);
                        homeScreenModel.setAnimPath(str2 + jSONObject.getString("animPath"));

                        arrayList2.add(homeScreenModel);
                        length--;
                        str3 = str5;
                    }
                } else {
                    String str6 = "bgPath";
                    int i = 0;
                    while (i < jSONArray.length()) {
                        FLA_HomeScreenModel homeScreenModel2 = new FLA_HomeScreenModel();
                        JSONObject jSONObject2 = jSONArray.getJSONObject(i);
                        homeScreenModel2.setId(jSONObject2.getInt("id"));
                        String str7 = str6;
                        JSONArray jSONArray2 = jSONArray;
                        homeScreenModel2.setBgPath(str2 + jSONObject2.getString(str7));
                        homeScreenModel2.setAnimPath(str2 + jSONObject2.getString("animPath"));
                        arrayList2.add(homeScreenModel2);
                        i++;
                        jSONArray = jSONArray2;
                        str6 = str7;
                    }
                }
            } catch (JSONException e4) {
                e4.printStackTrace();
            }
        }
        return arrayList2;
    }

    public ArrayList<FLA_ShapesModel> getShapesList() {
        ArrayList<FLA_ShapesModel> arrayList = new ArrayList<>();
        arrayList.add(new FLA_ShapesModel(R.drawable.ic_shape_1, FLA_Const.LINE));
        arrayList.add(new FLA_ShapesModel(R.drawable.ic_shape_2, FLA_Const.SHAPE_2));
        arrayList.add(new FLA_ShapesModel(R.drawable.ic_shape_3, FLA_Const.SHAPE_3));
        arrayList.add(new FLA_ShapesModel(R.drawable.ic_shape_4, FLA_Const.SHAPE_4));
        arrayList.add(new FLA_ShapesModel(R.drawable.ic_shape_5, FLA_Const.SHAPE_5));
        arrayList.add(new FLA_ShapesModel(R.drawable.ic_shape_6, FLA_Const.SHAPE_6));
        arrayList.add(new FLA_ShapesModel(R.drawable.ic_shape_7, FLA_Const.SHAPE_7));
        arrayList.add(new FLA_ShapesModel(R.drawable.ic_shape_8, FLA_Const.SHAPE_8));
        arrayList.add(new FLA_ShapesModel(R.drawable.ic_shape_9, FLA_Const.SHAPE_9));
        arrayList.add(new FLA_ShapesModel(R.drawable.ic_shape_10, FLA_Const.SHAPE_10));
        arrayList.add(new FLA_ShapesModel(R.drawable.ic_shape_11, FLA_Const.SHAPE_11));
        arrayList.add(new FLA_ShapesModel(R.drawable.ic_shape_12, FLA_Const.SHAPE_12));
        arrayList.add(new FLA_ShapesModel(R.drawable.ic_shape_13, FLA_Const.SHAPE_13));
        arrayList.add(new FLA_ShapesModel(R.drawable.ic_shape_14, FLA_Const.SHAPE_14));
        arrayList.add(new FLA_ShapesModel(R.drawable.ic_shape_15, FLA_Const.SHAPE_15));
        arrayList.add(new FLA_ShapesModel(R.drawable.ic_shape_16, FLA_Const.SHAPE_16));
        arrayList.add(new FLA_ShapesModel(R.drawable.ic_shape_17, FLA_Const.SHAPE_17));
        return arrayList;
    }
    public Bitmap createBlurBitmap(Context context, Bitmap bitmap, float f) {
        if (f <= 0.0f) {
            f = 0.1f;
        } else if (f > 25.0f) {
            f = 25.0f;
        }
        RenderScript create = RenderScript.create(context);
        Bitmap createBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Allocation createFromBitmap = Allocation.createFromBitmap(create, bitmap);
        Allocation createFromBitmap2 = Allocation.createFromBitmap(create, createBitmap);
        ScriptIntrinsicBlur create2 = ScriptIntrinsicBlur.create(create, Element.U8_4(create));
        create2.setInput(createFromBitmap);
        create2.setRadius(f);
        create2.forEach(createFromBitmap2);
        createFromBitmap2.copyTo(createBitmap);
        create.destroy();
        return createBitmap;
    }

    public List<FLA_SelectColorModel> getGradientsList(Activity activity) {
        ArrayList arrayList = new ArrayList();
        TypedArray obtainTypedArray = activity.getResources().obtainTypedArray(R.array.gradients_list);
        for (int i = 0; i < obtainTypedArray.length(); i++) {
            arrayList.add(new FLA_SelectColorModel(obtainTypedArray.getResourceId(i, -1), "false"));
        }
        obtainTypedArray.recycle();
        return arrayList;
    }
}
