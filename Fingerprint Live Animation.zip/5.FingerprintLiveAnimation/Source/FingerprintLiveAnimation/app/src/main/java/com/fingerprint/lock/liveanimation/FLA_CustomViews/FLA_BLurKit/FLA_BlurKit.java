package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_BLurKit;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.view.View;


public class FLA_BlurKit {
    private static final float FULL_SCALE = 1.0f;
    private static FLA_BlurKit instance;
    private static RenderScript rs;

    public static void init(Context context) {
        if (instance != null) {
            return;
        }
        instance = new FLA_BlurKit();
        rs = RenderScript.create(context.getApplicationContext());
    }

    public Bitmap blur(Bitmap bitmap, int i) {
        Allocation createFromBitmap = Allocation.createFromBitmap(rs, bitmap);
        Allocation createTyped = Allocation.createTyped(rs, createFromBitmap.getType());
        RenderScript renderScript = rs;
        ScriptIntrinsicBlur create = ScriptIntrinsicBlur.create(renderScript, Element.U8_4(renderScript));
        create.setRadius(i);
        create.setInput(createFromBitmap);
        create.forEach(createTyped);
        createTyped.copyTo(bitmap);
        return bitmap;
    }

    public Bitmap blur(View view, int i) {
        return blur(getBitmapForView(view), i);
    }

    public Bitmap fastBlur(View view, int i, float f) {
        return blur(getBitmapForView(view, f), i);
    }

    private Bitmap getBitmapForView(View view, float f) {
        Bitmap createBitmap = Bitmap.createBitmap((int) (view.getWidth() * f), (int) (view.getHeight() * f), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        Matrix matrix = new Matrix();
        matrix.preScale(f, f);
        canvas.setMatrix(matrix);
        view.draw(canvas);
        return createBitmap;
    }

    private Bitmap getBitmapForView(View view) {
        Bitmap createBitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        view.draw(new Canvas(createBitmap));
        return createBitmap;
    }

    public static FLA_BlurKit getInstance() {
        FLA_BlurKit blurKit = instance;
        if (blurKit != null) {
            return blurKit;
        }
        throw new RuntimeException("BlurKit not initialized!");
    }
}
