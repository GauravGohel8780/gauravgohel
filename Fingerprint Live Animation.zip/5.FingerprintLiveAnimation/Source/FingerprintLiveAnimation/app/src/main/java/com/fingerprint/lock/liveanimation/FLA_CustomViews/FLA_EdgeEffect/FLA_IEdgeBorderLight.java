package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_EdgeEffect;

import android.graphics.Bitmap;
import android.graphics.Canvas;


public interface FLA_IEdgeBorderLight {
    void changeColor(int[] iArr);

    void onDraw(Canvas canvas);

    void onLayout(int i, int i2);

    void setBitmap(Bitmap bitmap);
}
