package com.fingerprint.lock.liveanimation.FLA_Activities;

import static com.iten.tenoku.utils.MyApplication.sharedPreferencesHelper;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.fingerprint.lock.liveanimation.Ads_Common.UnderMaintenanceActivity;
import com.fingerprint.lock.liveanimation.BuildConfig;
import com.fingerprint.lock.liveanimation.R;
import com.fingerprint.lock.liveanimation.FLA_Utils.FLA_DataSaving;
import com.fingerprint.lock.liveanimation.FLA_Utils.FLA_PrefManager;
import com.fingerprint.lock.liveanimation.FLA_Utils.FLA_SharedPreferenceManager;
import com.fingerprint.lock.liveanimation.databinding.ActivitySplashBinding;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.activity.AppSettingActivity;
import com.iten.tenoku.databinding.DialogAppUpdateBinding;
import com.iten.tenoku.databinding.DialogInternetBinding;
import com.iten.tenoku.listeners.AppSettingListeners;
import com.iten.tenoku.networking.AdsResponse;
import com.iten.tenoku.utils.AdConstant;
import com.iten.tenoku.utils.AdUtils;
import com.iten.tenoku.utils.LogUtils;
import com.iten.tenoku.utils.MyApplication;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.single.PermissionListener;

import net.lingala.zip4j.ZipFile;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;

public class FLA_SplashActivity extends AppSettingActivity {
    public static final String COUNTER_FOR_FIRST_TIME_RATINGS_DIALOG = "ratingDialogFirstTimeCounter";
    int APP_VERSION;
    Activity activity = this;
    ActivitySplashBinding binding;
    private FLA_PrefManager prefManager;
    public FLA_SharedPreferenceManager sharedPreferenceManager;
    int LAUNCH_INTERNET_ACTIVITY = 1;

    String currentDate;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        SetSystemFullScreen(this);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);
        this.binding = ActivitySplashBinding.inflate(getLayoutInflater());

        activity = FLA_SplashActivity.this;

        this.prefManager = new FLA_PrefManager(this.activity);
        try {
            this.APP_VERSION = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
            int currentAppVersion = this.prefManager.getCurrentAppVersion();
            setContentView(this.binding.getRoot());
            String str = getExternalCacheDir() + "/data";
            File file = new File(str);
            if (file.exists() && !this.prefManager.isFirstTimeLaunch() && this.APP_VERSION == currentAppVersion) {
                this.binding.llView.setVisibility(View.VISIBLE);
                this.binding.animView.setVisibility(View.VISIBLE);
                this.binding.tvIns.setVisibility(View.GONE);
                this.binding.llProgressView.setVisibility(View.GONE);

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        moveToNextActivity(true);
                    }
                }, 500);

            } else {
                this.binding.llView.setVisibility(View.GONE);
                this.binding.animView.setVisibility(View.GONE);
                this.binding.tvIns.setVisibility(View.VISIBLE);
                this.binding.llProgressView.setVisibility(View.VISIBLE);
                if (file.exists()) {
                    if (deleteAll(file)) {
                        Log.e("LoadingAllData_3", "All Data Deleted");
                        loadAllAppData(str);
                    } else {
                        Log.e("LoadingAllData_3", "Delete data failed");
                    }
                    Log.e("LoadingAllData_1", "Data already exits");
                } else {
                    loadAllAppData(str);
                    Log.d("LoadingAllData_2", "Loading all app's data");
                }
            }
            this.sharedPreferenceManager = new FLA_SharedPreferenceManager(this.activity, "is_in_app_purchased");
            FLA_DataSaving dataSaving = new FLA_DataSaving();
            dataSaving.setIntPrefValue(this.activity, COUNTER_FOR_FIRST_TIME_RATINGS_DIALOG, dataSaving.getIntPrefValue(this.activity, COUNTER_FOR_FIRST_TIME_RATINGS_DIALOG) + 1);
        } catch (PackageManager.NameNotFoundException e) {
            throw new RuntimeException(e);
        }
    }


    public void moveToNextActivity(boolean z) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/YYYY");
        currentDate = simpleDateFormat.format(Calendar.getInstance().getTime());

        setAdRequestStatus();
        checkNotificationPermission();
    }
    private void checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (ActivityCompat.checkSelfPermission(activity, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                intAction();
            } else {
                checkNotificationPermissionAbove33();
            }
        } else {
            intAction();
        }
    }

    public void checkNotificationPermissionAbove33() {
        Dexter.withContext(this).withPermission(Manifest.permission.POST_NOTIFICATIONS).withListener(new PermissionListener() {
            @Override
            public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                LogUtils.logV("TAG", "MyPermission onPermissionGranted");
                intAction();
            }

            @Override
            public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
                intAction();
            }

            @Override
            public void onPermissionRationaleShouldBeShown(com.karumi.dexter.listener.PermissionRequest permissionRequest, PermissionToken permissionToken) {
                permissionToken.continuePermissionRequest();
            }

        }).onSameThread().check();
    }

    private void intAction() {
        checkConnection();
    }

    private void loadAllAppData(final String str) {
        final String string = getResources().getString(R.string.DATA_KEY);
        final AssetManager assets = getAssets();
        ExecutorService newSingleThreadExecutor = Executors.newSingleThreadExecutor();
        final Handler handler = new Handler(Looper.getMainLooper());
        newSingleThreadExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    InputStream open = assets.open("assets.zip");
                    if (open != null) {
                        File createFileFromInputStream = createFileFromInputStream(open);
                        if (createFileFromInputStream != null) {
                            ZipFile zipFile = new ZipFile(createFileFromInputStream);
                            if (zipFile.isEncrypted()) {
                                zipFile.setPassword(string.toCharArray());
                            }
                            zipFile.extractAll(str);
                            prefManager.setCurrentAppVersion(APP_VERSION);
                        } else {
                            final Toast makeText = Toast.makeText(getApplicationContext(), "Failed to load assets", Toast.LENGTH_SHORT);
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public final void run() {
                                    if (makeText != null) {
                                        makeText.cancel();
                                    }
                                }
                            }, 500);
                            if (makeText != null) {
                                makeText.show();
                            }
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        binding.llView.setVisibility(View.VISIBLE);
                        binding.animView.setVisibility(View.VISIBLE);
                        binding.tvIns.setVisibility(View.GONE);
                        binding.llProgressView.setVisibility(View.GONE);
                        System.out.println("wwwwwwwwwwwwwwwwork_is_done_");

                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public final void run() {
                                moveToNextActivity(false);
                            }
                        }, 500);
                    }
                });
            }
        });
    }


    private File createFileFromInputStream(InputStream inputStream) {
        try {
            File file = new File(getFilesDir(), "assets.zip");
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            byte[] bArr = new byte[1024];
            while (true) {
                int read = inputStream.read(bArr);
                if (read > 0) {
                    fileOutputStream.write(bArr, 0, read);
                } else {
                    fileOutputStream.close();
                    inputStream.close();
                    return file;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean deleteAll(File file) {
        if (file == null || !file.exists()) {
            return false;
        }
        boolean z = true;
        if (file.isDirectory()) {
            File[] listFiles = file.listFiles();
            if (listFiles != null && listFiles.length > 0) {
                for (File file2 : listFiles) {
                    if (file2.isDirectory()) {
                        z &= deleteAll(file2);
                    }
                    if (!file2.delete()) {
                        Log.w("deleteAll", "Failed to delete " + file2);
                        z = false;
                    }
                }
            } else if (!file.delete()) {
                Log.w("deleteAll", "Failed to delete " + file);
                return false;
            }
        } else if (!file.delete()) {
            Log.w("deleteAll", "Failed to delete " + file);
            return false;
        }
        return z;
    }

    public static void SetSystemFullScreen(Activity activity) {
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) {
            View v = activity.getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            View decorView = activity.getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }


    private void checkConnection() {
        if (AdUtils.isNetworkAvailable(activity)) {
            loadSetting();
        } else {
            ShowNetworkDialog();
        }
    }


    private void ShowNetworkDialog() {
        Dialog dialog = new Dialog(activity);
        DialogInternetBinding dialogInternetBinding = DialogInternetBinding.inflate(getLayoutInflater());
        dialog.setContentView(dialogInternetBinding.getRoot());
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().getAttributes().gravity = Gravity.CENTER;
        dialog.setCancelable(false);
        dialogInternetBinding.buttonRetry.setOnClickListener(v -> {
            dialog.dismiss();
            if (AdUtils.isNetworkAvailable(activity)) {
                loadSetting();
            } else {
                Intent i = new Intent(Settings.ACTION_SETTINGS);
                startActivityForResult(i, LAUNCH_INTERNET_ACTIVITY);
            }
        });
        dialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == LAUNCH_INTERNET_ACTIVITY) {
            checkConnection();
        }
    }

    private void loadSetting() {
        AppSettings(activity, BuildConfig.VERSION_CODE, BuildConfig.APPLICATION_ID, new AppSettingListeners() {
            @Override
            public void onResponseSuccess() {
                LogUtils.logE("TAG", "onResponseSuccess: ");
                if (sharedPreferencesHelper.getAppOpenAd()) {
                    new Handler().postDelayed(() -> {
                        LogUtils.logD("TAG", "AppOpenManager PassActivity after 5 sec: ");
                        openWelcome();
                    }, 4000);

                } else {
                    new Handler().postDelayed(() -> {
                        GoToMainScreen();
                    }, 3000);
                }
            }

            @Override
            public void onUnderMaintenance() {
                com.iten.tenoku.utils.MyApplication.appOpenManager.ShowOpenAd(true, adShow -> {
                    startActivity(new Intent(activity, UnderMaintenanceActivity.class));
                    finish();
                });
            }

            @Override
            public void onResponseFail() {
                LogUtils.logE("TAG", "onResponseFail  ===> ");
                if (!sharedPreferencesHelper.sharedPreferences.getAll().isEmpty()) {
                    try {
                        AdsResponse appSettings = new Gson().fromJson(sharedPreferencesHelper.getResponse(), AdsResponse.class);
                        if (appSettings.getIsStatus()) {

                            Log.e("TAG", "onResponseFail: " + appSettings.getIsStatus());
                            CheckBooleanValue(appSettings);
                            CheckStringValue(appSettings);
                            CheckIntegerValue(appSettings);
                            SetAdColors(appSettings);
                            SetRecyclerViewAd(sharedPreferencesHelper.getGridViewPerItemAdTwo(), sharedPreferencesHelper.getGridViewPerItemAdThree(), sharedPreferencesHelper.getListViewAd());
                            SetAdData(appSettings);
                            SetHideFeature(appSettings);
                            SetUserData(appSettings);
                            FacebookAd(appSettings);
                            preLoadAd();
                            HandelData(sharedPreferencesHelper.getUnderMaintenance());
                        }
                    } catch (Exception e) {
                    }
                    openWelcome();
                } else {
                    recreate();
                }
            }

            @Override
            public void onAppUpdate(String url) {
                LogUtils.logE("TAG", "onAppUpdate: ");
                AppDialogShow(url, 0);
            }

            @Override
            public void onAppRedirect(String url) {
                LogUtils.logE("TAG", "onAppRedirect: ");
                AppDialogShow(url, 1);
            }

            @Override
            public void onStatusChange() {
                LogUtils.logE("TAG", "onStatusChange: ");

            }
        });

    }

    public final void openWelcome() {
        com.iten.tenoku.utils.MyApplication.appOpenManager.ShowOpenAd(true, adShow -> {
            GoToMainScreen();
        });

    }

    public void GoToMainScreen() {
        startActivity(new Intent(this.activity, FLA_IntroActivity.class));
        finish();
    }

    private void AppDialogShow(String url, int i) {
        Dialog dialog = new Dialog(activity);
        DialogAppUpdateBinding dialogAppUpdateBinding = DialogAppUpdateBinding.inflate(getLayoutInflater());
        dialog.setContentView(dialogAppUpdateBinding.getRoot());
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().getAttributes().gravity = Gravity.CENTER;
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        if (i == 0) {
            dialogAppUpdateBinding.buttonRetry.setText(com.iten.tenoku.R.string.update_title);
            dialogAppUpdateBinding.txtTitle.setText(com.iten.tenoku.R.string.update_sub_title);
            dialogAppUpdateBinding.txtDecription.setText("");
            dialogAppUpdateBinding.txtDecription.setVisibility(View.GONE);
        } else if (i == 1) {
            dialogAppUpdateBinding.buttonRetry.setText(com.iten.tenoku.R.string.install_title);
            dialogAppUpdateBinding.txtTitle.setText(com.iten.tenoku.R.string.install_sub_title);
            dialogAppUpdateBinding.txtDecription.setVisibility(View.VISIBLE);
            dialogAppUpdateBinding.txtDecription.setText(com.iten.tenoku.R.string.install_descrption);
        } else {
            dialog.dismiss();
        }
        dialogAppUpdateBinding.buttonRetry.setOnClickListener(v -> {
            dialog.dismiss();
            try {
                Uri marketUri = Uri.parse(url);
                Intent marketIntent = new Intent(Intent.ACTION_VIEW, marketUri);
                startActivity(marketIntent);
            } catch (ActivityNotFoundException ignored) {
            }
        });
        dialog.show();
    }

    private void setAdRequestStatus() {
        if (!MyApplication.sharedPreferencesHelper.getUserSavedDate().equals(currentDate)) {
//            Log.e(TAG, "Saved Date--------------->" + MyApplication.sharedPreferencesHelper.getUserSavedDate());
//            Log.e(TAG, "Current Date--------------->" + currentDate);
//            Log.e(TAG, "Total Failed Count: ------->" + MyApplication.sharedPreferencesHelper.getTotalFailedCount());
            MyApplication.sharedPreferencesHelper.setTotalFailedCount(AdConstant.ResetTotalCount);
            MyApplication.sharedPreferencesHelper.setAdmobFailedCount(AdConstant.ResetTotalCount);
            MyApplication.sharedPreferencesHelper.setFbFailedCount(AdConstant.ResetTotalCount);
            MyApplication.sharedPreferencesHelper.setUserSavedDate(currentDate);
            sharedPreferencesHelper.setRequestDataSend(false);
        }
    }
}
