package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_EdgeEffect;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

import com.fingerprint.lock.liveanimation.R;


public class FLA_DecodeEdgeResource extends AsyncTask<Void, Void, Bitmap> {
    private final CallBack callBack;
    private final Context context;
    private final String shape;

    
    public interface CallBack {
        void decodeDone(Bitmap bitmap);
    }

    public FLA_DecodeEdgeResource(Context context, String str, CallBack callBack) {
        this.context = context;
        this.shape = str;
        this.callBack = callBack;
    }

    @Override 
    public Bitmap doInBackground(Void... voidArr) {
        return getBitMap(this.shape);
    }

    @Override
    public void onPostExecute(Bitmap bitmap) {
        this.callBack.decodeDone(bitmap);
    }

    private Bitmap getBitMap(String str) {
        if (str.equals(FLA_Const.LINE)) {
            return null;
        }
        if (str.equals(FLA_Const.SHAPE_2)) {
            return BitmapFactory.decodeResource(this.context.getResources(), R.drawable.ic_shape_2);
        }
        if (str.equals(FLA_Const.SHAPE_3)) {
            return BitmapFactory.decodeResource(this.context.getResources(), R.drawable.ic_shape_3);
        }
        if (str.equals(FLA_Const.SHAPE_4)) {
            return BitmapFactory.decodeResource(this.context.getResources(), R.drawable.ic_shape_4);
        }
        if (str.equals(FLA_Const.SHAPE_5)) {
            return BitmapFactory.decodeResource(this.context.getResources(), R.drawable.ic_shape_5);
        }
        if (str.equals(FLA_Const.SHAPE_6)) {
            return BitmapFactory.decodeResource(this.context.getResources(), R.drawable.ic_shape_6);
        }
        if (str.equals(FLA_Const.SHAPE_7)) {
            return BitmapFactory.decodeResource(this.context.getResources(), R.drawable.ic_shape_7);
        }
        if (str.equals(FLA_Const.SHAPE_8)) {
            return BitmapFactory.decodeResource(this.context.getResources(), R.drawable.ic_shape_8);
        }
        if (str.equals(FLA_Const.SHAPE_9)) {
            return BitmapFactory.decodeResource(this.context.getResources(), R.drawable.ic_shape_9);
        }
        if (str.equals(FLA_Const.SHAPE_10)) {
            return BitmapFactory.decodeResource(this.context.getResources(), R.drawable.ic_shape_10);
        }
        if (str.equals(FLA_Const.SHAPE_11)) {
            return BitmapFactory.decodeResource(this.context.getResources(), R.drawable.ic_shape_11);
        }
        if (str.equals(FLA_Const.SHAPE_12)) {
            return BitmapFactory.decodeResource(this.context.getResources(), R.drawable.ic_shape_12);
        }
        if (str.equals(FLA_Const.SHAPE_13)) {
            return BitmapFactory.decodeResource(this.context.getResources(), R.drawable.ic_shape_13);
        }
        if (str.equals(FLA_Const.SHAPE_14)) {
            return BitmapFactory.decodeResource(this.context.getResources(), R.drawable.ic_shape_14);
        }
        if (str.equals(FLA_Const.SHAPE_15)) {
            return BitmapFactory.decodeResource(this.context.getResources(), R.drawable.ic_shape_15);
        }
        if (str.equals(FLA_Const.SHAPE_16)) {
            return BitmapFactory.decodeResource(this.context.getResources(), R.drawable.ic_shape_16);
        }
        if (str.equals(FLA_Const.SHAPE_17)) {
            return BitmapFactory.decodeResource(this.context.getResources(), R.drawable.ic_shape_17);
        }
        return null;
    }
}
