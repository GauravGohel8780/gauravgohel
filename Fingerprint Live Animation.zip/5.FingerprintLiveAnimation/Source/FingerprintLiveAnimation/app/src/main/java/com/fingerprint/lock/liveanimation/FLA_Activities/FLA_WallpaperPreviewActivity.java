package com.fingerprint.lock.liveanimation.FLA_Activities;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

import androidx.recyclerview.widget.ItemTouchHelper;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.fingerprint.lock.liveanimation.Ads_Common.AdsBaseActivity;
import com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_EdgeEffect.FLA_Const;
import com.fingerprint.lock.liveanimation.FLA_Utils.FLA_Services.FLA_WallpaperService;
import com.fingerprint.lock.liveanimation.FLA_Utils.FLA_SharedPreferenceManager;
import com.fingerprint.lock.liveanimation.R;
import com.fingerprint.lock.liveanimation.databinding.ActivityWallpaperPreviewBinding;
import com.fingerprint.lock.liveanimation.databinding.DialogLayoutAlertBinding;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;


public class FLA_WallpaperPreviewActivity extends AdsBaseActivity {
    Dialog alertDialog;
    String animPath;
    String bgImgPath;
    ActivityWallpaperPreviewBinding binding;
    FLA_SharedPreferenceManager spm;
    Activity activity = this;
    Context context = this;
    int sizeValue = ItemTouchHelper.Callback.DEFAULT_SWIPE_ANIMATION_DURATION;
    float positionValue = 1.5f;
    float speedValue = 1.0f;
    int edgeSize = 40;
    int edgeAnimSpeed = 2;
    int edgeRadius = 0;
    boolean isEdgeActive = false;

    int edgeColorType = 0;
    String edgeShapeType = FLA_Const.LINE;


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.bgImgPath = getIntent().getStringExtra("bgImgPath");
        this.animPath = getIntent().getStringExtra("animPath");
        this.sizeValue = getIntent().getIntExtra("scaleValue", this.sizeValue);
        this.positionValue = getIntent().getFloatExtra("positionValue", this.positionValue);
        this.speedValue = getIntent().getFloatExtra("speedValue", this.speedValue);
        this.edgeSize = getIntent().getIntExtra("edgeSize", this.edgeSize);
        this.edgeRadius = getIntent().getIntExtra("edgeRadius", this.edgeRadius);
        this.edgeAnimSpeed = getIntent().getIntExtra("edgeAnimSpeed", this.edgeAnimSpeed);
        this.isEdgeActive = getIntent().getBooleanExtra("isEdgeActive", this.isEdgeActive);
        this.edgeColorType = getIntent().getIntExtra("edgeColorType", this.edgeColorType);
        this.edgeShapeType = getIntent().getStringExtra("edgeShapeType");
        ActivityWallpaperPreviewBinding inflate = ActivityWallpaperPreviewBinding.inflate(getLayoutInflater());
        this.binding = inflate;

        setContentView(this.binding.getRoot());
        this.spm = new FLA_SharedPreferenceManager(this.context, "clockData");
        initAlertDialog(this.activity);
        registerInAppMsgEventForActivity(this.activity, "FinalWallpaperPreviewActivity");
        initViews();
        FLA_WallpaperService.isSettingsUpdated = false;
        this.spm.setBooleanValue("isPreviewOnly", false);
    }

    private void initViews() {
        setSupportActionBar(this.binding.toolbar);
        this.binding.toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(FLA_WallpaperPreviewActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        this.binding.lottieView.setFromActivity(true);
        this.binding.lottieView.setSize(this.sizeValue);
        this.binding.lottieView.setPositionY(this.positionValue);
        this.binding.lottieView.setWidth(this.binding.constraintRoot.getWidth());
        this.binding.lottieView.setHeight(this.binding.constraintRoot.getHeight());
        if (this.bgImgPath != null) {
            Glide.with(this.context).asBitmap().load(this.bgImgPath).into(new CustomTarget<Bitmap>() {
                @Override
                public void onLoadCleared(Drawable drawable) {
                }


                public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                    FLA_WallpaperPreviewActivity.this.binding.imageView.setImageBitmap(bitmap);
                    FLA_WallpaperPreviewActivity wallpaperPreviewActivity = FLA_WallpaperPreviewActivity.this;
                    FLA_WallpaperPreviewActivity.this.binding.imageViewBg.setImageBitmap(wallpaperPreviewActivity.createBlurBitmap(wallpaperPreviewActivity.context, bitmap, 25.0f));
                }
            });
        }
        if (this.animPath != null) {
            this.binding.lottieView.setFilePath(this.animPath);
        }
        if (this.isEdgeActive) {
            this.binding.edgeLightView.setVisibility(View.VISIBLE);
        }
        if (this.binding.edgeLightView.getVisibility() == View.VISIBLE) {
            if (this.edgeSize > 0) {
                this.binding.edgeLightView.changeSize(this.edgeSize);
            }
            if (this.edgeAnimSpeed > 0) {
                this.binding.edgeLightView.changeSpeed(this.edgeAnimSpeed);
            }
            if (this.edgeRadius >= 0) {
                this.binding.edgeLightView.changeBorder(110, 110);
            }
            if (this.edgeShapeType != null) {
                this.binding.edgeLightView.changeType(this.edgeShapeType);
            }
            this.binding.edgeLightView.changeColorType(this.edgeColorType);
        }
        this.binding.continueBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(FLA_WallpaperPreviewActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        showAlertDialog();
                    }
                }, MAIN_CLICK);
            }
        });
    }


    public void initAlertDialog(final Activity activity) {
        DialogLayoutAlertBinding inflate = DialogLayoutAlertBinding.inflate(activity.getLayoutInflater());
        Dialog dialog = new Dialog(activity);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        this.alertDialog = dialog;
        dialog.setContentView(inflate.getRoot());
        this.alertDialog.setCanceledOnTouchOutside(true);
        this.alertDialog.setCancelable(true);
        this.alertDialog.getWindow().setLayout(-1, -2);
        inflate.cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = alertDialog;
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });
        inflate.okBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(FLA_WallpaperPreviewActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Dialog dialog = alertDialog;
                        dialog.dismiss();
                        spm.setIntValue("scaleValue", sizeValue);
                        spm.setFloatValue("positionValue", positionValue);
                        spm.setFloatValue("speedValue", binding.lottieView.getAnimSpeed());
                        spm.setValue("bgImg", bgImgPath);
                        spm.setValue("animPath", animPath);
                        spm.setBooleanValue("isPreviewOnly", true);
                        spm.setIntValue("edgeSize", edgeSize);
                        spm.setIntValue("edgeRadius", edgeRadius);
                        spm.setIntValue("edgeAnimSpeed", edgeAnimSpeed);
                        spm.setValue("edgeShapeType", edgeShapeType);
                        spm.setIntValue("edgeColorType", edgeColorType);
                        spm.setBooleanValue("isEdgeActive", isEdgeActive);
                        FLA_WallpaperService.isSettingsUpdated = true;
                        spm.setBooleanValue("isPreviewOnly", true);
                        FLA_WallpaperPreviewActivity.this.showToast("Wallpaper settings has successfully Updated.");
                        activity.finish();
                    }
                }, MAIN_CLICK);
            }
        });
    }

    private void showAlertDialog() {
        Dialog dialog = this.alertDialog;
        if (dialog != null) {
            dialog.show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
