package com.fingerprint.lock.liveanimation.FLA_CustomViews;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fingerprint.lock.liveanimation.R;


public class FLA_AnimatedRecyclerView extends RecyclerView {
    private int animation;
    private LayoutAnimationController animationController;
    private int animationDuration;
    private int columns;
    private int layoutManagerType;
    private int orientation;
    private boolean reverse;


    public FLA_AnimatedRecyclerView(Context context) {
        super(context);
        this.orientation = 1;
        this.reverse = false;
        this.animationDuration = 600;
        this.layoutManagerType = 0;
        this.columns = 1;
        this.animation = R.anim.layout_animation_from_bottom;
        init(context, null);
    }

    public FLA_AnimatedRecyclerView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.orientation = 1;
        this.reverse = false;
        this.animationDuration = 600;
        this.layoutManagerType = 0;
        this.columns = 1;
        this.animation = R.anim.layout_animation_from_bottom;
        init(context, attributeSet);
    }

    public FLA_AnimatedRecyclerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.orientation = 1;
        this.reverse = false;
        this.animationDuration = 600;
        this.layoutManagerType = 0;
        this.columns = 1;
        this.animation = R.anim.layout_animation_from_bottom;
        init(context, attributeSet);
    }

    private void init(Context context, AttributeSet attributeSet) {
        LayoutAnimationController loadLayoutAnimation;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R.styleable.AnimatedRecyclerView, 0, 0);
        this.orientation = obtainStyledAttributes.getInt(R.styleable.AnimatedRecyclerView_layoutManagerOrientation, this.orientation);
        this.reverse = obtainStyledAttributes.getBoolean(R.styleable.AnimatedRecyclerView_layoutManagerReverse, this.reverse);
        this.animationDuration = obtainStyledAttributes.getInt(R.styleable.AnimatedRecyclerView_animationDuration, this.animationDuration);
        this.layoutManagerType = obtainStyledAttributes.getInt(R.styleable.AnimatedRecyclerView_layoutManagerType, this.layoutManagerType);
        this.columns = obtainStyledAttributes.getInt(R.styleable.AnimatedRecyclerView_gridLayoutManagerColumns, this.columns);
        int resourceId = obtainStyledAttributes.getResourceId(R.styleable.AnimatedRecyclerView_layoutAnimation, -1);
        this.animation = resourceId;
        if (this.animationController == null) {
            if (resourceId != -1) {
                loadLayoutAnimation = AnimationUtils.loadLayoutAnimation(getContext(), this.animation);
            } else {
                loadLayoutAnimation = AnimationUtils.loadLayoutAnimation(getContext(), R.anim.layout_animation_from_bottom);
            }
            this.animationController = loadLayoutAnimation;
        }
        this.animationController.getAnimation().setDuration(this.animationDuration);
        setLayoutAnimation(this.animationController);
        int i = this.layoutManagerType;
        if (i == 0) {
            setLayoutManager(new LinearLayoutManager(context, this.orientation, this.reverse));
        } else if (i == 1) {
            setLayoutManager(new GridLayoutManager(context, this.columns, this.orientation, this.reverse));
        }
    }
}
