package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_BLurKit;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Xfermode;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatImageView;


public class FLA_RoundedImageView extends AppCompatImageView {
    private float mCornerRadius;
    private PorterDuffXfermode porterDuffXfermode;
    private RectF rectF;

    public void setCornerRadius(float f) {
        this.mCornerRadius = f;
    }

    public FLA_RoundedImageView(Context context) {
        super(context, null);
        this.mCornerRadius = 0.0f;
        this.rectF = new RectF();
        this.porterDuffXfermode = new PorterDuffXfermode(PorterDuff.Mode.SRC_IN);
    }

    public FLA_RoundedImageView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mCornerRadius = 0.0f;
        this.rectF = new RectF();
        this.porterDuffXfermode = new PorterDuffXfermode(PorterDuff.Mode.SRC_IN);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Drawable drawable = getDrawable();
        if (drawable != null && (drawable instanceof BitmapDrawable) && this.mCornerRadius > 0.0f) {
            this.rectF.set(drawable.getBounds());
            int saveLayer = canvas.saveLayer(this.rectF, null, 31);
            getImageMatrix().mapRect(this.rectF);
            Paint paint = ((BitmapDrawable) drawable).getPaint();
            paint.setAntiAlias(true);
            paint.setColor(-16777216);
            Xfermode xfermode = paint.getXfermode();
            canvas.drawARGB(0, 0, 0, 0);
            RectF rectF = this.rectF;
            float f = this.mCornerRadius;
            canvas.drawRoundRect(rectF, f, f, paint);
            paint.setXfermode(this.porterDuffXfermode);
            super.onDraw(canvas);
            paint.setXfermode(xfermode);
            canvas.restoreToCount(saveLayer);
            return;
        }
        super.onDraw(canvas);
    }
}
