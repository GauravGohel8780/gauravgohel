package com.fingerprint.lock.liveanimation.FLA_Activities;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;
import static com.iten.tenoku.utils.MyApplication.sharedPreferencesHelper;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.graphics.drawable.ColorDrawable;
import android.hardware.fingerprint.FingerprintManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatButton;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager2.widget.ViewPager2;


import com.bumptech.glide.Glide;
import com.fingerprint.lock.liveanimation.Ads_Common.AdsBaseActivity;
import com.fingerprint.lock.liveanimation.R;
import com.fingerprint.lock.liveanimation.databinding.ActivityHomeBinding;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.fingerprint.lock.liveanimation.FLA_Adapters.FLA_Adapter_ViewPager3;
import com.fingerprint.lock.liveanimation.FLA_Adapters.FLA_ViewPagerFragmentAdapter;
import com.fingerprint.lock.liveanimation.FLA_Fragments.FLA_AnimationsFragment;
import com.fingerprint.lock.liveanimation.FLA_Fragments.FLA_ThemesFragment;
import com.fingerprint.lock.liveanimation.FLA_Fragments.FLA_WallpapersFragment;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_HomeScreenModel;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_OnRvItemClickListener;
import com.google.gson.Gson;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.networking.AdsResponse;
import com.iten.tenoku.utils.AdUtils;
import com.zackratos.ultimatebarx.ultimatebarx.java.Operator;
import com.zackratos.ultimatebarx.ultimatebarx.java.UltimateBarX;

import java.util.ArrayList;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class FLA_HomeActivity extends AdsBaseActivity {

    FLA_AnimationsFragment animationsFragment;
    ActivityHomeBinding binding;
    ArrayList<FLA_HomeScreenModel> homeScreenData;
    ArrayList<String> lst_Unl_frames;
    FLA_ThemesFragment themesFragment;
    FLA_WallpapersFragment wallpapersFragment;
    Activity activity = this;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().setStatusBarColor(getResources().getColor(R.color.colorPrimary, this.getTheme()));
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(getResources().getColor(R.color.colorPrimary));
        }


        registerInAppMsgEventForActivity(this.activity, "HomeActivity");
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, binding.drawerLayout, R.string.navigation_drawer_open, R.string.navigation_drawer_close);


        binding.mainLayout.toolbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        binding.drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        binding.llRateus.setOnClickListener(v -> {
            binding.drawerLayout.close();
            Dialog dialog = new Dialog(FLA_HomeActivity.this, R.style.customDialog);
            dialog.setContentView(R.layout.dialog_layout);
            dialog.setCancelable(false);

            Objects.requireNonNull(dialog.getWindow()).setGravity(Gravity.CENTER);
            dialog.getWindow().setLayout(-1, -2);

            Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(ContextCompat.getDrawable(FLA_HomeActivity.this, android.R.color.transparent));

            dialog.show();


            AppCompatButton abSubmite = dialog.findViewById(R.id.abSubmite);
            AppCompatButton abCancel = dialog.findViewById(R.id.abCancel);

            abSubmite.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    Uri uri = Uri.parse("market://details?id=" + getPackageName());
                    Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
                    try {
                        startActivity(myAppLinkToMarket);
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(FLA_HomeActivity.this, " unable to find market app", Toast.LENGTH_LONG).show();
                    }
                }
            });

            abCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
        });
        binding.llPrivacyPolicy.setOnClickListener(v -> {
            binding.drawerLayout.close();
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    startActivity(new Intent(FLA_HomeActivity.this, FLA_PrivacyPolicyActivity.class));
                }
            }, MAIN_CLICK);
        });
        binding.llShare.setOnClickListener(v -> {
            binding.drawerLayout.close();
            Intent intent2 = new Intent("android.intent.action.SEND");
            intent2.setType("text/plain");
            intent2.putExtra("android.intent.extra.SUBJECT", getResources().getString(R.string.app_name));
            intent2.putExtra("android.intent.extra.TEXT", "\nHey, install this application\n\nhttps://play.google.com/store/apps/details?id=me.grantland.widget\n\n");
            startActivity(Intent.createChooser(intent2, "choose one"));
        });
        binding.llExit.setOnClickListener(v -> {
            binding.drawerLayout.close();
            ExitDialog();
        });

        initViews();
        premiumDialog = new Dialog(this);
        this.premiumDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public final void onDismiss(DialogInterface dialogInterface) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public final void run() {
                        if (Build.VERSION.SDK_INT <= 32 || shouldShowRequestPermissionRationale("112")) {
                            return;
                        }
                        getNotificationPermission();
                    }
                }, 1500L);
            }
        });

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (binding.drawerLayout.isOpen()) {
                    binding.drawerLayout.close();
                } else {
                    ExitDialog();
                }
            }
        };

        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    private void ExitDialog() {

        binding.drawerLayout.close();
        Dialog dialog = new Dialog(FLA_HomeActivity.this, R.style.customDialog);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCancelable(false);

        Objects.requireNonNull(dialog.getWindow()).setGravity(Gravity.CENTER);
        dialog.getWindow().setLayout(-1, -2);

        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(ContextCompat.getDrawable(FLA_HomeActivity.this, android.R.color.transparent));

        dialog.show();


        TextView tvDialogTitle = dialog.findViewById(R.id.tvDialogTitle);
        TextView tvDialogditail = dialog.findViewById(R.id.tvDialogditail);
        ImageView ivDialogimg = dialog.findViewById(R.id.ivDialogimg);
        AppCompatButton abSubmite = dialog.findViewById(R.id.abSubmite);
        AppCompatButton abCancel = dialog.findViewById(R.id.abCancel);

        tvDialogTitle.setText("Exit");
        tvDialogditail.setText("Are You Sure You Want to\n" + "Leave this Apps?");
        Glide.with(this).asBitmap().load(R.drawable.img_exit).into(ivDialogimg);
        abSubmite.setText("Exit");
        abCancel.setText("Cancel");

        abSubmite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finishAffinity();
            }
        });

        abCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }


    private void initViews() {

        this.lst_Unl_frames = this.spm_for_un_list.getStringArrayList("frame");
        this.homeScreenData = getHomeScreenData(this.activity, "Themes", null, true);
        this.wallpapersFragment = new FLA_WallpapersFragment(this.homeScreenData);
        this.animationsFragment = new FLA_AnimationsFragment(this.homeScreenData);
        ArrayList<FLA_HomeScreenModel> arrayList = this.homeScreenData;
        if (arrayList != null && arrayList.size() > 0) {
            loadThemeFragment();
        }
        this.binding.mainLayout.tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                getInstance(FLA_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {

                    }
                }, MAIN_CLICK);
            }
        });
    }

    public View getTabView(int i) {
        View inflate = LayoutInflater.from(this.activity).inflate(R.layout.custom_tab_layout, (ViewGroup) null);
        TextView textView = (TextView) inflate.findViewById(R.id.text1);
        ImageView imageView = (ImageView) inflate.findViewById(R.id.img);
        if (i == 0) {
            textView.setText("Themes");
            imageView.setImageResource(R.drawable.ic_theme);
        } else if (i == 1) {
            textView.setText("Wallpapers");
            imageView.setImageResource(R.drawable.ic_wallpaper);
        }
        return inflate;
    }



    public void getNotificationPermission() {
        if (Build.VERSION.SDK_INT > 32) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.POST_NOTIFICATIONS"}, 112);
        }
    }

    @Override

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 112) {
            if (iArr.length <= 0 || iArr[0] != 0) {
                showDialogOK(new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        permissionSettingScreen();
                    }
                });
            }
        }
    }

    private void permissionSettingScreen() {
        showToast("Please unblock notifications to receive important Notifications.");
        Intent intent = new Intent();
        intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.setData(Uri.fromParts("package", getPackageName(), null));
        startActivity(intent);
        finish();
    }

    private void showDialogOK(DialogInterface.OnClickListener onClickListener) {
        new AlertDialog.Builder(this).setMessage("Please allow to show important notifications.").setPositiveButton("OK", onClickListener).setNegativeButton("Cancel", onClickListener).create().show();
    }

    private void loadThemeFragment() {
        ExecutorService newSingleThreadExecutor = Executors.newSingleThreadExecutor();
        final Handler handler = new Handler(Looper.getMainLooper());
        newSingleThreadExecutor.execute(new Runnable() {
            @Override
            public void run() {
                final FLA_Adapter_ViewPager3 adapter_ViewPager3 = new FLA_Adapter_ViewPager3(activity, homeScreenData, new FLA_OnRvItemClickListener() {
                    @Override
                    public void onItemClicked(int i) {
                        getInstance(FLA_HomeActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                FLA_HomeScreenModel homeScreenModel = FLA_HomeActivity.this.homeScreenData.get(i);
                                if (homeScreenModel != null) {
                                    FLA_HomeActivity.this.startActivity(new Intent(FLA_HomeActivity.this.activity, FLA_WallpaperSettingsActivity.class).putExtra("bgImgPath", homeScreenModel.getBgPath()).putExtra("id", homeScreenModel.getId() - 1).putExtra("animPath", homeScreenModel.getAnimPath()));
                                }
                            }
                        }, MAIN_CLICK);
                    }
                });
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        themesFragment = new FLA_ThemesFragment(binding.mainLayout.imageView, homeScreenData, adapter_ViewPager3);
                        setupViewPager(binding.mainLayout.viewpager);
                        new TabLayoutMediator(binding.mainLayout.tabLayout, binding.mainLayout.viewpager, new TabLayoutMediator.TabConfigurationStrategy() {
                            @Override
                            public final void onConfigureTab(TabLayout.Tab tab, int i) {
                                tab.setCustomView(getTabView(i));
                            }
                        }).attach();
                    }
                });
            }
        });
    }

    private void setupViewPager(ViewPager2 viewPager2) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(this.themesFragment);
        arrayList.add(this.wallpapersFragment);
        viewPager2.setAdapter(new FLA_ViewPagerFragmentAdapter(this, arrayList));
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
