package com.fingerprint.lock.liveanimation.FLA_Models;


public interface FLA_OnRvItemClickListener {
    void onItemClicked(int i);
}
