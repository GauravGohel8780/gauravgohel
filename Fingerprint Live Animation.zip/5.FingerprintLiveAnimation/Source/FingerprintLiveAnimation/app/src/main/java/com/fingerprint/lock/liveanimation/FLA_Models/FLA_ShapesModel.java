package com.fingerprint.lock.liveanimation.FLA_Models;


public class FLA_ShapesModel {
    private int icon;
    private String type;

    public int getIcon() {
        return this.icon;
    }

    public String getType() {
        return this.type;
    }

    public void setIcon(int i) {
        this.icon = i;
    }

    public void setType(String str) {
        this.type = str;
    }

    public FLA_ShapesModel() {
    }

    public FLA_ShapesModel(int i, String str) {
        this.icon = i;
        this.type = str;
    }
}
