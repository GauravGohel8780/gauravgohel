package com.fingerprint.lock.liveanimation.FLA_Activities;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

import com.fingerprint.lock.liveanimation.Ads_Common.AdsBaseActivity;
import com.fingerprint.lock.liveanimation.FLA_Adapters.FLA_Adapter_Rv_Wallpapers;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_HomeScreenModel;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_OnRvItemClickListener;
import com.fingerprint.lock.liveanimation.R;
import com.fingerprint.lock.liveanimation.databinding.ActivitySelectWallpaperBinding;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.util.ArrayList;

public class FLA_SelectWallpaperActivity extends AdsBaseActivity {
    Activity activity = this;
    ActivitySelectWallpaperBinding binding;
    String filePath;
    ArrayList<FLA_HomeScreenModel> rvDataList;
    int type;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        this.type = getIntent().getIntExtra("type", 3);
        this.filePath = getIntent().getStringExtra("filePath");
        ActivitySelectWallpaperBinding inflate = ActivitySelectWallpaperBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView(this.binding.getRoot());
        registerInAppMsgEventForActivity(this, "SelectWallpaperBgActivity");
        initViews();
    }

    private void initViews() {
        setSupportActionBar(this.binding.toolbar);
        this.binding.toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                getInstance(FLA_SelectWallpaperActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

        int i = this.type;
        if (i == 3) {
            this.binding.toolbar.setTitle("Select Wallpaper");
            this.binding.tvHeading.setText("Select Fingerprint animation which looks better with your selected Wallpaper background.");
        } else if (i == 4) {
            this.binding.tvHeading.setText("Select Wallpaper background which looks better with your selected Fingerprint Animation.");
            this.binding.toolbar.setTitle("Select Animation");
        }
        this.rvDataList = getHomeScreenData(this.activity, "Themes", null, true);
        FLA_Adapter_Rv_Wallpapers adapter_Rv_Wallpapers = new FLA_Adapter_Rv_Wallpapers(this.rvDataList, this.filePath, this.type, new FLA_OnRvItemClickListener() {
            @Override
            public final void onItemClicked(int i2) {
                FLA_SelectWallpaperActivity.this.cliclItem(i2);
            }
        });
        this.binding.recyclerView.setAdapter(adapter_Rv_Wallpapers);
        if (this.binding.recyclerView.getAdapter() != null) {
            adapter_Rv_Wallpapers.notifyDataSetChanged();
        }
        this.binding.recyclerView.scheduleLayoutAnimation();
    }

    public void cliclItem(int i) {
        FLA_HomeScreenModel homeScreenModel = rvDataList.get(i);
        if (homeScreenModel != null) {
            int i2 = type;
            if (i2 == 3) {
                getInstance(this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        startActivity(new Intent(activity, FLA_WallpaperSettingsActivity.class).putExtra("bgImgPath", filePath).putExtra("animPath", rvDataList.get(i).getAnimPath()));
                    }
                }, MAIN_CLICK);
            } else if (i2 == 4) {
                getInstance(this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        startActivity(new Intent(activity, FLA_WallpaperSettingsActivity.class).putExtra("bgImgPath", rvDataList.get(i).getBgPath()).putExtra("animPath", filePath));
                    }
                }, MAIN_CLICK);

            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}
