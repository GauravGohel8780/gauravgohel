package com.fingerprint.lock.liveanimation.FLA_Adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_OnRvItemClickListener;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_ShapesModel;
import com.fingerprint.lock.liveanimation.R;

import java.util.ArrayList;


public class FLA_Adapter_Rv_Shapes extends RecyclerView.Adapter<FLA_Adapter_Rv_Shapes.ViewHolder> {
    private final FLA_OnRvItemClickListener onRvItemClickListener;
    private final ArrayList<FLA_ShapesModel> shapesList;

    @Override 
    public long getItemId(int i) {
        return i;
    }

    @Override 
    public int getItemViewType(int i) {
        return i;
    }

    public FLA_Adapter_Rv_Shapes(ArrayList<FLA_ShapesModel> arrayList, FLA_OnRvItemClickListener onRvItemClickListener) {
        this.shapesList = arrayList;
        this.onRvItemClickListener = onRvItemClickListener;
    }

    @Override 
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.rv_row_shapes, viewGroup, false));
    }

    @Override 
    public void onBindViewHolder(final ViewHolder viewHolder, int i) {
        FLA_ShapesModel shapesModel = this.shapesList.get(i);
        if (shapesModel != null) {
            Glide.with(viewHolder.iv_icon).asBitmap().load(Integer.valueOf(shapesModel.getIcon())).into(viewHolder.iv_icon);
            viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override 
                public final void onClick(View view) {
                    onRvItemClickListener.onItemClicked(viewHolder.getAdapterPosition());
                }
            });
        }
    }

    @Override 
    public int getItemCount() {
        return this.shapesList.size();
    }

    
    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView iv_icon;

        public ViewHolder(View view) {
            super(view);
            this.iv_icon = (ImageView) view.findViewById(R.id.ivIcon);
        }
    }
}
