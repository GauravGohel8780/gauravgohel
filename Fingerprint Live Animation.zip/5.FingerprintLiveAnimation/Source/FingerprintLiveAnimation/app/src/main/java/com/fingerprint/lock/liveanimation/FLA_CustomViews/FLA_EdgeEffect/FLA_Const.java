package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_EdgeEffect;


public class FLA_Const {
    public static String Action_DemoLiveWallpaper = "actionDemolivewallpaper";
    public static final String CIRCLE = "circle";
    public static final String INFILITYU = "infilityU";
    public static final String INFILITYV = "infilityV";
    public static final String LINE = "line";
    public static final String NO = "No";
    public static final String ROUND = "round";
    public static final String SHAPE_1 = "shape_1";
    public static final String SHAPE_10 = "shape_10";
    public static final String SHAPE_11 = "shape_11";
    public static final String SHAPE_12 = "shape_12";
    public static final String SHAPE_13 = "shape_13";
    public static final String SHAPE_14 = "shape_14";
    public static final String SHAPE_15 = "shape_15";
    public static final String SHAPE_16 = "shape_16";
    public static final String SHAPE_17 = "shape_17";
    public static final String SHAPE_2 = "shape_2";
    public static final String SHAPE_3 = "shape_3";
    public static final String SHAPE_4 = "shape_4";
    public static final String SHAPE_5 = "shape_5";
    public static final String SHAPE_6 = "shape_6";
    public static final String SHAPE_7 = "shape_7";
    public static final String SHAPE_8 = "shape_8";
    public static final String SHAPE_9 = "shape_9";

}
