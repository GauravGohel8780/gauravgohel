package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_LikeButton;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.core.content.ContextCompat;

import com.fingerprint.lock.liveanimation.R;


public class FLA_LikeButton extends FrameLayout implements View.OnClickListener {
    private FLA_OnAnimationEndListener animationEndListener;
    private float animationScaleFactor;
    private AnimatorSet animatorSet;
    private int circleEndColor;
    private int circleStartColor;
    private FLA_CircleView circleView;
    private FLA_Icon currentIcon;
    private FLA_DotsView dotsView;
    private ImageView icon;
    private int iconSize;
    private boolean isChecked;
    private boolean isEnabled;
    private Drawable likeDrawable;
    private FLA_OnLikeListener likeListener;
    private Drawable unLikeDrawable;
    private static final DecelerateInterpolator DECELERATE_INTERPOLATOR = new DecelerateInterpolator();
    private static final AccelerateDecelerateInterpolator ACCELERATE_DECELERATE_INTERPOLATOR = new AccelerateDecelerateInterpolator();
    private static final OvershootInterpolator OVERSHOOT_INTERPOLATOR = new OvershootInterpolator(4.0f);

    public boolean isLiked() {
        return this.isChecked;
    }

    @Override 
    public void setEnabled(boolean z) {
        this.isEnabled = z;
    }

    public void setOnAnimationEndListener(FLA_OnAnimationEndListener onAnimationEndListener) {
        this.animationEndListener = onAnimationEndListener;
    }

    public void setOnLikeListener(FLA_OnLikeListener onLikeListener) {
        this.likeListener = onLikeListener;
    }

    public FLA_LikeButton(Context context) {
        this(context, null);
    }

    public FLA_LikeButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public FLA_LikeButton(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        if (isInEditMode()) {
            return;
        }
        init(context, attributeSet, i);
    }


    private void init(Context context, AttributeSet attributeSet, int i) {
        LayoutInflater.from(getContext()).inflate(R.layout.like_layout, (ViewGroup) this, true);
        this.icon = (ImageView) findViewById(R.id.icon);
        this.dotsView = (FLA_DotsView) findViewById(R.id.dots);
        this.circleView = (FLA_CircleView) findViewById(R.id.circle);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R.styleable.LikeButton, i, 0);
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(R.styleable.LikeButton_icon_size, -1);
        this.iconSize = dimensionPixelSize;
        if (dimensionPixelSize == -1) {
            this.iconSize = 40;
        }
        String string = obtainStyledAttributes.getString(R.styleable.LikeButton_icon_type);
        Drawable drawableFromResource = getDrawableFromResource(obtainStyledAttributes, R.styleable.LikeButton_like_drawable);
        this.likeDrawable = drawableFromResource;
        if (drawableFromResource != null) {
            setLikeDrawable(drawableFromResource);
        }
        Drawable drawableFromResource2 = getDrawableFromResource(obtainStyledAttributes, R.styleable.LikeButton_unlike_drawable);
        this.unLikeDrawable = drawableFromResource2;
        if (drawableFromResource2 != null) {
            setUnlikeDrawable(drawableFromResource2);
        }
        if (string != null && !string.isEmpty()) {
            this.currentIcon = parseIconType(string);
        }
        int color = obtainStyledAttributes.getColor(R.styleable.LikeButton_circle_start_color, 0);
        this.circleStartColor = color;
        if (color != 0) {
            this.circleView.setStartColor(color);
        }
        int color2 = obtainStyledAttributes.getColor(R.styleable.LikeButton_circle_end_color, 0);
        this.circleEndColor = color2;
        if (color2 != 0) {
            this.circleView.setEndColor(color2);
        }
        int color3 = obtainStyledAttributes.getColor(R.styleable.LikeButton_dots_primary_color, 0);
        int color4 = obtainStyledAttributes.getColor(R.styleable.LikeButton_dots_secondary_color, 0);
        if (color3 != 0 && color4 != 0) {
            this.dotsView.setColors(color3, color4);
        }
        if (this.likeDrawable == null && this.unLikeDrawable == null) {
            if (this.currentIcon != null) {
                setIcon();
            } else {
                setIcon(FLA_IconType.Heart);
            }
        }
        setEnabled(obtainStyledAttributes.getBoolean(R.styleable.LikeButton_is_enabled, true));
        Boolean valueOf = Boolean.valueOf(obtainStyledAttributes.getBoolean(R.styleable.LikeButton_liked, false));
        setAnimationScaleFactor(obtainStyledAttributes.getFloat(R.styleable.LikeButton_anim_scale_factor, 3.0f));
        setLiked(valueOf);
        setOnClickListener(this);
        obtainStyledAttributes.recycle();
    }

    private Drawable getDrawableFromResource(TypedArray typedArray, int i) {
        int resourceId = typedArray.getResourceId(i, -1);
        if (-1 != resourceId) {
            return ContextCompat.getDrawable(getContext(), resourceId);
        }
        return null;
    }

    @Override 
    public void onClick(View view) {
        if (this.isEnabled) {
            boolean z = !this.isChecked;
            this.isChecked = z;
            this.icon.setImageDrawable(z ? this.likeDrawable : this.unLikeDrawable);
            FLA_OnLikeListener onLikeListener = this.likeListener;
            if (onLikeListener != null) {
                if (this.isChecked) {
                    onLikeListener.liked(this);
                } else {
                    onLikeListener.unLiked(this);
                }
            }
            AnimatorSet animatorSet = this.animatorSet;
            if (animatorSet != null) {
                animatorSet.cancel();
            }
            if (this.isChecked) {
                this.icon.animate().cancel();
                this.icon.setScaleX(0.0f);
                this.icon.setScaleY(0.0f);
                this.circleView.setInnerCircleRadiusProgress(0.0f);
                this.circleView.setOuterCircleRadiusProgress(0.0f);
                this.dotsView.setCurrentProgress(0.0f);
                this.animatorSet = new AnimatorSet();
                ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this.circleView, FLA_CircleView.OUTER_CIRCLE_RADIUS_PROGRESS, 0.1f, 1.0f);
                ofFloat.setDuration(250L);
                DecelerateInterpolator decelerateInterpolator = DECELERATE_INTERPOLATOR;
                ofFloat.setInterpolator(decelerateInterpolator);
                ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(this.circleView, FLA_CircleView.INNER_CIRCLE_RADIUS_PROGRESS, 0.1f, 1.0f);
                ofFloat2.setDuration(200L);
                ofFloat2.setStartDelay(200L);
                ofFloat2.setInterpolator(decelerateInterpolator);
                ObjectAnimator ofFloat3 = ObjectAnimator.ofFloat(this.icon, ImageView.SCALE_Y, 0.2f, 1.0f);
                ofFloat3.setDuration(350L);
                ofFloat3.setStartDelay(250L);
                OvershootInterpolator overshootInterpolator = OVERSHOOT_INTERPOLATOR;
                ofFloat3.setInterpolator(overshootInterpolator);
                ObjectAnimator ofFloat4 = ObjectAnimator.ofFloat(this.icon, ImageView.SCALE_X, 0.2f, 1.0f);
                ofFloat4.setDuration(350L);
                ofFloat4.setStartDelay(250L);
                ofFloat4.setInterpolator(overshootInterpolator);
                ObjectAnimator ofFloat5 = ObjectAnimator.ofFloat(this.dotsView, FLA_DotsView.DOTS_PROGRESS, 0.0f, 1.0f);
                ofFloat5.setDuration(900L);
                ofFloat5.setStartDelay(50L);
                ofFloat5.setInterpolator(ACCELERATE_DECELERATE_INTERPOLATOR);
                this.animatorSet.playTogether(ofFloat, ofFloat2, ofFloat3, ofFloat4, ofFloat5);
                this.animatorSet.addListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationCancel(Animator animator) {
                        FLA_LikeButton.this.circleView.setInnerCircleRadiusProgress(0.0f);
                        FLA_LikeButton.this.circleView.setOuterCircleRadiusProgress(0.0f);
                        FLA_LikeButton.this.dotsView.setCurrentProgress(0.0f);
                        FLA_LikeButton.this.icon.setScaleX(1.0f);
                        FLA_LikeButton.this.icon.setScaleY(1.0f);
                    }

                    @Override
                    public void onAnimationEnd(Animator animator) {
                        if (FLA_LikeButton.this.animationEndListener != null) {
                            FLA_LikeButton.this.animationEndListener.onAnimationEnd(FLA_LikeButton.this);
                        }
                    }
                });
                this.animatorSet.start();
            }
        }
    }

    @Override 
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.isEnabled) {
            int action = motionEvent.getAction();
            if (action != 0) {
                boolean z = false;
                if (action == 1) {
                    ViewPropertyAnimator duration = this.icon.animate().scaleX(0.7f).scaleY(0.7f).setDuration(150L);
                    DecelerateInterpolator decelerateInterpolator = DECELERATE_INTERPOLATOR;
                    duration.setInterpolator(decelerateInterpolator);
                    this.icon.animate().scaleX(1.0f).scaleY(1.0f).setInterpolator(decelerateInterpolator);
                    if (isPressed()) {
                        performClick();
                        setPressed(false);
                    }
                } else if (action == 2) {
                    float x = motionEvent.getX();
                    float y = motionEvent.getY();
                    if (x > 0.0f && x < getWidth() && y > 0.0f && y < getHeight()) {
                        z = true;
                    }
                    if (isPressed() != z) {
                        setPressed(z);
                    }
                } else if (action == 3) {
                    setPressed(false);
                }
            } else {
                setPressed(true);
            }
            return true;
        }
        return true;
    }

    public void setLikeDrawableRes(int i) {
        this.likeDrawable = ContextCompat.getDrawable(getContext(), i);
        if (this.iconSize != 0) {
            Context context = getContext();
            Drawable drawable = this.likeDrawable;
            int i2 = this.iconSize;
            this.likeDrawable = FLA_Utils.resizeDrawable(context, drawable, i2, i2);
        }
        if (this.isChecked) {
            this.icon.setImageDrawable(this.likeDrawable);
        }
    }

    public void setLikeDrawable(Drawable drawable) {
        this.likeDrawable = drawable;
        if (this.iconSize != 0) {
            Context context = getContext();
            int i = this.iconSize;
            this.likeDrawable = FLA_Utils.resizeDrawable(context, drawable, i, i);
        }
        if (this.isChecked) {
            this.icon.setImageDrawable(this.likeDrawable);
        }
    }

    public void setUnlikeDrawableRes(int i) {
        this.unLikeDrawable = ContextCompat.getDrawable(getContext(), i);
        if (this.iconSize != 0) {
            Context context = getContext();
            Drawable drawable = this.unLikeDrawable;
            int i2 = this.iconSize;
            this.unLikeDrawable = FLA_Utils.resizeDrawable(context, drawable, i2, i2);
        }
        if (this.isChecked) {
            return;
        }
        this.icon.setImageDrawable(this.unLikeDrawable);
    }

    public void setUnlikeDrawable(Drawable drawable) {
        this.unLikeDrawable = drawable;
        if (this.iconSize != 0) {
            Context context = getContext();
            int i = this.iconSize;
            this.unLikeDrawable = FLA_Utils.resizeDrawable(context, drawable, i, i);
        }
        if (this.isChecked) {
            return;
        }
        this.icon.setImageDrawable(this.unLikeDrawable);
    }

    public void setIcon(FLA_IconType iconType) {
        FLA_Icon parseIconType = parseIconType(iconType);
        this.currentIcon = parseIconType;
        setLikeDrawableRes(parseIconType.getOnIconResourceId());
        setUnlikeDrawableRes(this.currentIcon.getOffIconResourceId());
        this.icon.setImageDrawable(this.unLikeDrawable);
    }

    public void setIcon() {
        setLikeDrawableRes(this.currentIcon.getOnIconResourceId());
        setUnlikeDrawableRes(this.currentIcon.getOffIconResourceId());
        this.icon.setImageDrawable(this.unLikeDrawable);
    }

    public void setIconSizeDp(int i) {
        setIconSizePx((int) FLA_Utils.dipToPixels(getContext(), i));
    }

    public void setIconSizePx(int i) {
        this.iconSize = i;
        setEffectsViewSize();
        this.unLikeDrawable = FLA_Utils.resizeDrawable(getContext(), this.unLikeDrawable, i, i);
        this.likeDrawable = FLA_Utils.resizeDrawable(getContext(), this.likeDrawable, i, i);
    }

    private FLA_Icon parseIconType(String str) {
        for (FLA_Icon icon : FLA_Utils.getIcons()) {
            if (icon.getIconType().name().toLowerCase().equals(str.toLowerCase())) {
                return icon;
            }
        }
        throw new IllegalArgumentException("Correct icon type not specified.");
    }

    private FLA_Icon parseIconType(FLA_IconType iconType) {
        for (FLA_Icon icon : FLA_Utils.getIcons()) {
            if (icon.getIconType().equals(iconType)) {
                return icon;
            }
        }
        throw new IllegalArgumentException("Correct icon type not specified.");
    }

    private void setEffectsViewSize() {
        int i = this.iconSize;
        if (i != 0) {
            FLA_DotsView dotsView = this.dotsView;
            float f = this.animationScaleFactor;
            dotsView.setSize((int) (i * f), (int) (i * f));
            FLA_CircleView circleView = this.circleView;
            int i2 = this.iconSize;
            circleView.setSize(i2, i2);
        }
    }

    public void setLiked(Boolean bool) {
        if (bool.booleanValue()) {
            this.isChecked = true;
            this.icon.setImageDrawable(this.likeDrawable);
            return;
        }
        this.isChecked = false;
        this.icon.setImageDrawable(this.unLikeDrawable);
    }

    public void setAnimationScaleFactor(float f) {
        this.animationScaleFactor = f;
        setEffectsViewSize();
    }
}
