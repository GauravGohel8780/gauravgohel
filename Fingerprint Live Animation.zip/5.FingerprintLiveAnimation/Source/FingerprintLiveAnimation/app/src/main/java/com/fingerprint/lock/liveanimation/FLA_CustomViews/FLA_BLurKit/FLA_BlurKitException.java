package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_BLurKit;


public class FLA_BlurKitException extends Exception {
    public FLA_BlurKitException(String str) {
        super(str);
    }
}
