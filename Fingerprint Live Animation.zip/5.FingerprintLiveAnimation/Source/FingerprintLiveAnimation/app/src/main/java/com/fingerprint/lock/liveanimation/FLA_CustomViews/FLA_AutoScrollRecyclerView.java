package com.fingerprint.lock.liveanimation.FLA_CustomViews;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.view.animation.Interpolator;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;


public class FLA_AutoScrollRecyclerView extends RecyclerView {
    private static final int SPEED = 10;
    private boolean isStopAutoScroll;
    private boolean mCanTouch;
    private int mCurrentSpeed;
    private boolean mInflate;
    UniformSpeedInterpolator mInterpolator;
    private boolean mIsOpenAuto;
    private boolean mLoopEnabled;
    private boolean mPointTouch;
    private boolean mReady;
    private boolean mReverse;
    private int mSpeedDx;
    private int mSpeedDy;

    public boolean canTouch() {
        return this.mCanTouch;
    }

    public boolean getReverse() {
        return this.mReverse;
    }

    public boolean isLoopEnabled() {
        return this.mLoopEnabled;
    }

    public void pauseAutoScroll(boolean z) {
        this.isStopAutoScroll = z;
    }

    public void setCanTouch(boolean z) {
        this.mCanTouch = z;
    }

    public FLA_AutoScrollRecyclerView(Context context) {
        this(context, null);
    }

    public FLA_AutoScrollRecyclerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public FLA_AutoScrollRecyclerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mCurrentSpeed = 10;
        this.mCanTouch = true;
        this.isStopAutoScroll = false;
        this.mInterpolator = new UniformSpeedInterpolator();
        this.mReady = false;
    }

    public void startAutoScroll() {
        this.isStopAutoScroll = false;
        openAutoScroll(this.mCurrentSpeed, false);
    }

    public void openAutoScroll(int i, boolean z) {
        this.mReverse = z;
        this.mCurrentSpeed = i;
        this.mIsOpenAuto = true;
        notifyLayoutManager();
        startScroll();
    }

    private void startScroll() {
        if (this.mIsOpenAuto && getScrollState() != 2 && this.mInflate && this.mReady) {
            this.mSpeedDy = 0;
            this.mSpeedDx = 0;
            smoothScroll();
        }
    }

    private void smoothScroll() {
        if (this.isStopAutoScroll) {
            return;
        }
        int abs = Math.abs(this.mCurrentSpeed);
        if (this.mReverse) {
            abs = -abs;
        }
        smoothScrollBy(abs, abs, this.mInterpolator);
    }

    private void notifyLayoutManager() {
        LayoutManager layoutManager = getLayoutManager();
        if (layoutManager instanceof LinearLayoutManager) {
            ((LinearLayoutManager) layoutManager).setReverseLayout(this.mReverse);
            return;
        }
        StaggeredGridLayoutManager staggeredGridLayoutManager = (StaggeredGridLayoutManager) layoutManager;
        if (staggeredGridLayoutManager != null) {
            staggeredGridLayoutManager.setReverseLayout(this.mReverse);
        }
    }

    @Override
    public void swapAdapter(Adapter adapter, boolean z) {
        super.swapAdapter(generateAdapter(adapter), z);
        this.mReady = true;
    }

    @Override 
    public void setAdapter(Adapter adapter) {
        super.setAdapter(generateAdapter(adapter));
        this.mReady = true;
    }

    @Override 
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        if (this.mCanTouch) {
            int action = motionEvent.getAction();
            if (action == 0) {
                this.mPointTouch = true;
            } else if ((action == 1 || action == 3) && this.mIsOpenAuto) {
                return true;
            }
            return super.onInterceptTouchEvent(motionEvent);
        }
        return true;
    }

    @Override 
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.mCanTouch) {
            int action = motionEvent.getAction();
            if ((action == 1 || action == 3) && this.mIsOpenAuto) {
                this.mPointTouch = false;
                smoothScroll();
                return true;
            }
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    @Override 
    public boolean performClick() {
        return super.performClick();
    }

    
    @Override 
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        startScroll();
    }

    @Override 
    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mInflate = true;
    }

    @Override 
    public void onScrolled(int i, int i2) {
        if (this.mPointTouch) {
            this.mSpeedDx = 0;
            this.mSpeedDy = 0;
        } else if (i == 0) {
            int i3 = this.mSpeedDy + i2;
            this.mSpeedDy = i3;
            if (Math.abs(i3) >= Math.abs(this.mCurrentSpeed)) {
                this.mSpeedDy = 0;
                smoothScroll();
            }
        } else {
            int i4 = this.mSpeedDx + i;
            this.mSpeedDx = i4;
            if (Math.abs(i4) >= Math.abs(this.mCurrentSpeed)) {
                this.mSpeedDx = 0;
                smoothScroll();
            }
        }
    }

    private NestingRecyclerViewAdapter generateAdapter(Adapter adapter) {
        return new NestingRecyclerViewAdapter(this, adapter);
    }

   
    
    public static class UniformSpeedInterpolator implements Interpolator {
        @Override
        public float getInterpolation(float f) {
            return f;
        }

        private UniformSpeedInterpolator() {
        }
    }

   
    
    public static class NestingRecyclerViewAdapter<VH extends ViewHolder> extends Adapter<VH> {
        Adapter<VH> mAdapter;
        private final FLA_AutoScrollRecyclerView mRecyclerView;

        NestingRecyclerViewAdapter(FLA_AutoScrollRecyclerView autoScrollRecyclerView, Adapter<VH> adapter) {
            this.mAdapter = adapter;
            this.mRecyclerView = autoScrollRecyclerView;
        }

        @Override 
        public VH onCreateViewHolder(ViewGroup viewGroup, int i) {
            return this.mAdapter.onCreateViewHolder(viewGroup, i);
        }

        @Override 
        public void registerAdapterDataObserver(AdapterDataObserver adapterDataObserver) {
            super.registerAdapterDataObserver(adapterDataObserver);
            this.mAdapter.registerAdapterDataObserver(adapterDataObserver);
        }

        @Override 
        public void unregisterAdapterDataObserver(AdapterDataObserver adapterDataObserver) {
            super.unregisterAdapterDataObserver(adapterDataObserver);
            this.mAdapter.unregisterAdapterDataObserver(adapterDataObserver);
        }

        @Override 
        public void onBindViewHolder(VH vh, int i) {
            this.mAdapter.onBindViewHolder(vh, generatePosition(i));
        }

        @Override 
        public void setHasStableIds(boolean z) {
            super.setHasStableIds(z);
            this.mAdapter.setHasStableIds(z);
        }

        @Override 
        public int getItemCount() {
            if (getLoopEnable()) {
                return Integer.MAX_VALUE;
            }
            return this.mAdapter.getItemCount();
        }

        @Override 
        public int getItemViewType(int i) {
            return this.mAdapter.getItemViewType(generatePosition(i));
        }

        @Override 
        public long getItemId(int i) {
            return this.mAdapter.getItemId(generatePosition(i));
        }

        private int generatePosition(int i) {
            return getLoopEnable() ? getActualPosition(i) : i;
        }

        private int getActualPosition(int i) {
            int itemCount = this.mAdapter.getItemCount();
            return i >= itemCount ? i % itemCount : i;
        }

        private boolean getLoopEnable() {
            FLA_AutoScrollRecyclerView autoScrollRecyclerView = this.mRecyclerView;
            if (autoScrollRecyclerView != null) {
                return autoScrollRecyclerView.mLoopEnabled;
            }
            return false;
        }

        public boolean getReverse() {
            return this.mRecyclerView.mReverse;
        }
    }
}
