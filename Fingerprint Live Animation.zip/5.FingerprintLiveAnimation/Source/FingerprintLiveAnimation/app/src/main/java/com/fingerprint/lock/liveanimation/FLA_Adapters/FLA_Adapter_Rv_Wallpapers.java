package com.fingerprint.lock.liveanimation.FLA_Adapters;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_HomeScreenModel;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_OnRvItemClickListener;
import com.fingerprint.lock.liveanimation.R;
import com.fingerprint.lock.liveanimation.databinding.RvRowAnimationsBinding;
import com.fingerprint.lock.liveanimation.databinding.RvRowWallpapersAnimBinding;
import com.fingerprint.lock.liveanimation.databinding.RvRowWallpapersBinding;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FLA_Adapter_Rv_Wallpapers extends RecyclerView.Adapter<FLA_Adapter_Rv_Wallpapers.ViewHolder> {
    private final List<FLA_HomeScreenModel> dataList;
    private final String imgPath;
    private final FLA_OnRvItemClickListener onRvItemClickListener;
    int[] strokeColorsList;
    private final int type;

    @Override 
    public long getItemId(int i) {
        return i;
    }

    @Override 
    public int getItemViewType(int i) {
        return i;
    }

    public FLA_Adapter_Rv_Wallpapers(List<FLA_HomeScreenModel> list, String str, int i, FLA_OnRvItemClickListener onRvItemClickListener) {
        this.dataList = list;
        this.imgPath = str;
        this.type = i;
        this.onRvItemClickListener = onRvItemClickListener;
    }

    @Override 
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        this.strokeColorsList = viewGroup.getContext().getResources().getIntArray(R.array.strokeColorArray);
        int i2 = this.type;
        if (i2 == 1) {
            return new ViewHolder(RvRowWallpapersBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
        }
        if (i2 == 2) {
            return new ViewHolder(RvRowAnimationsBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
        }
        return new ViewHolder(RvRowWallpapersAnimBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
    }

    @Override 
    public void onBindViewHolder(final ViewHolder viewHolder, int i) {
        final FLA_HomeScreenModel homeScreenModel = this.dataList.get(i);
        if (homeScreenModel != null) {
            int i2 = this.type;
            if (i2 == 1) {
                Glide.with(viewHolder.binding.ivIcon).asBitmap().override(320).load(homeScreenModel.getBgPath()).into(new CustomTarget<Bitmap>() { // from class: com.fingerprint.lock.liveanimation.Adapters.Adapter_Rv_Wallpapers.1
                    @Override 
                    public void onLoadCleared(Drawable drawable) {
                    }


                    public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                        viewHolder.binding.ivIcon.setImageBitmap(bitmap);
                    }
                });
                if (homeScreenModel.getId() < this.strokeColorsList.length) {
                    viewHolder.binding.mcvItem.setStrokeColor(this.strokeColorsList[homeScreenModel.getId() - 1]);
                }
                viewHolder.binding.mcvItem.setOnClickListener(new View.OnClickListener() {
                    @Override 
                    public final void onClick(View view) {
                        onRvItemClickListener.onItemClicked(viewHolder.getAdapterPosition());
                    }
                });
            } else if (i2 == 2) {
                ExecutorService newSingleThreadExecutor = Executors.newSingleThreadExecutor();
                final Handler handler = new Handler(Looper.getMainLooper());
                newSingleThreadExecutor.execute(new Runnable() {
                    @Override 
                    public void run() {
                        final File file = new File(homeScreenModel.getAnimPath());
                        try {
                            final BufferedInputStream bufferedInputStream;
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                bufferedInputStream = file.exists() ? new BufferedInputStream(Files.newInputStream(file.toPath(), new OpenOption[0])) : null;

                                handler.post(new Runnable() {
                                    @Override 
                                    public final void run() {
                                        if (!file.exists() || bufferedInputStream == null) {
                                            return;
                                        }
                                        viewHolder.binding2.animView.setAnimation(bufferedInputStream, (String) null);
                                        viewHolder.binding2.animView.playAnimation();
                                        viewHolder.binding2.animView.setRepeatCount(-1);
                                    }
                                });
                            }
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
                });
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override 
                    public final void onClick(View view) {
                        onRvItemClickListener.onItemClicked(viewHolder.getAdapterPosition());
                    }
                });
            } else if (i2 == 3) {
                ExecutorService newSingleThreadExecutor2 = Executors.newSingleThreadExecutor();
                final Handler handler2 = new Handler(Looper.getMainLooper());
                newSingleThreadExecutor2.execute(new Runnable() {
                    @Override 
                    public final void run() {
                        final File file = new File(homeScreenModel.getAnimPath());
                        try {
                            final BufferedInputStream bufferedInputStream = file.exists() ? new BufferedInputStream(new FileInputStream(file)) : null;
                            handler2.post(new Runnable() {
                                @Override
                                public final void run() {
                                    if (file.exists() && bufferedInputStream != null) {
                                        viewHolder.binding3.lottieAnimView.setAnimation(bufferedInputStream, (String) null);
                                        viewHolder.binding3.lottieAnimView.playAnimation();
                                        viewHolder.binding3.lottieAnimView.setRepeatCount(-1);
                                    }
                                    Glide.with(viewHolder.binding3.ivIcon).asBitmap().override(320).load(imgPath).into(new CustomTarget<Bitmap>() {
                                        @Override
                                        public void onLoadCleared(Drawable drawable) {
                                        }
                                        public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                                            viewHolder.binding3.ivIcon.setImageBitmap(bitmap);
                                        }
                                    });
                                }
                            });
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
                });
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override 
                    public final void onClick(View view) {
                        onRvItemClickListener.onItemClicked(viewHolder.getAdapterPosition());
                    }
                });
            } else if (i2 == 4) {
                Glide.with(viewHolder.binding3.ivIcon).asBitmap().override(320).load(homeScreenModel.getBgPath()).into(new CustomTarget<Bitmap>() {
                    @Override 
                    public void onLoadCleared(Drawable drawable) {
                    }


                    public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                        viewHolder.binding3.ivIcon.setImageBitmap(bitmap);
                    }
                });
                ExecutorService newSingleThreadExecutor3 = Executors.newSingleThreadExecutor();
                final Handler handler3 = new Handler(Looper.getMainLooper());
                newSingleThreadExecutor3.execute(new Runnable() {
                    @Override 
                    public final void run() {
                        try {
                            final BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(new File(imgPath)));
                            handler3.post(new Runnable() {
                                @Override
                                public final void run() {
                                    if (bufferedInputStream != null) {
                                        viewHolder.binding3.lottieAnimView.setAnimation(bufferedInputStream, (String) null);
                                        viewHolder.binding3.lottieAnimView.playAnimation();
                                        viewHolder.binding3.lottieAnimView.setRepeatCount(-1);
                                    }
                                }
                            });
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
                });
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override 
                    public final void onClick(View view) {
                        onRvItemClickListener.onItemClicked(viewHolder.getAdapterPosition());
                    }
                });
            }
        }
    }


    @Override 
    public int getItemCount() {
        List<FLA_HomeScreenModel> list = this.dataList;
        if (list != null) {
            return list.size();
        }
        return 0;
    }

    
    
    public static class ViewHolder extends RecyclerView.ViewHolder {
        RvRowWallpapersBinding binding;
        RvRowAnimationsBinding binding2;
        RvRowWallpapersAnimBinding binding3;

        public ViewHolder(RvRowWallpapersBinding rvRowWallpapersBinding) {
            super(rvRowWallpapersBinding.getRoot());
            this.binding = rvRowWallpapersBinding;
        }

        public ViewHolder(RvRowAnimationsBinding rvRowAnimationsBinding) {
            super(rvRowAnimationsBinding.getRoot());
            this.binding2 = rvRowAnimationsBinding;
        }

        public ViewHolder(RvRowWallpapersAnimBinding rvRowWallpapersAnimBinding) {
            super(rvRowWallpapersAnimBinding.getRoot());
            this.binding3 = rvRowWallpapersAnimBinding;
        }
    }
}
