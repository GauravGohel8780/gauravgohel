package com.fingerprint.lock.liveanimation.FLA_Models;


public class FLA_SelectColorModel {
    private int color;
    private String isSelected;

    public int getColor() {
        return this.color;
    }

    public String getIsSelected() {
        return this.isSelected;
    }

    public void setColor(int i) {
        this.color = i;
    }

    public void setIsSelected(String str) {
        this.isSelected = str;
    }

    public FLA_SelectColorModel() {
    }

    public FLA_SelectColorModel(int i, String str) {
        this.color = i;
        this.isSelected = str;
    }
}
