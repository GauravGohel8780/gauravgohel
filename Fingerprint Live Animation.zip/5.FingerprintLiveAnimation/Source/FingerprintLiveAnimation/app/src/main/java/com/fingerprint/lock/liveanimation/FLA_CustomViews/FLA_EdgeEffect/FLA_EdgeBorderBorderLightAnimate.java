package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_EdgeEffect;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ComposeShader;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PorterDuff;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;

import androidx.core.view.InputDeviceCompat;

import com.fingerprint.lock.liveanimation.R;

public class FLA_EdgeBorderBorderLightAnimate implements FLA_IEdgeBorderLight {
    private Bitmap bb;
    private Bitmap bitmap;
    private Bitmap bitmapShape;
    private int centerX;
    private int centerY;
    private int[] colors;
    int[] colors1;
    int[] colors10;
    int[] colors2;
    int[] colors3;
    int[] colors4;
    int[] colors5;
    int[] colors6;
    int[] colors7;
    int[] colors8;
    int[] colors9;
    private final Context context;
    private final float distance;
    private Bitmap mBitmap;
    private final Matrix matrix;
    private Paint paint;
    private Path path;
    private PathMeasure pathMeasure;
    private float[] position;
    private float[] positions;
    float[] radii;
    private int radiusBInfility;
    private int radiusBottom;
    private int radiusInfility;
    private int radiusTop;
    private SweepGradient shader;
    private Shader shaderB;
    private String shape;
    private String sharp;
    private float[] slope;
    private float speed;
    private float strokeWidth;
    private int width;
    private int widthInfility;
    private float angle = 0.0f;
    private boolean checkRotate = false;
    private int height = 0;
    private int heigthInfility = 150;
    private int holeRadius = 60;
    private int holeRadiusY = 60;
    private int holeX = 200;
    private int holeY = 200;
    private String infility = FLA_Const.NO;
    private boolean notch = false;
    private int notchBottom = 150;
    private int notchCenter = 200;
    private int notchHeight = 100;
    private int notchRadiusBottom = 200;
    private int notchRadiusTop = 200;
    private int notchTop = 200;
    private float padding = 35.0f;
    int[] colors0 = {-65536, InputDeviceCompat.SOURCE_ANY, -16711936, Color.parseColor("#FF03A9F4"), -16776961, -65281, -65536};
    @Override
    public void setBitmap(Bitmap bitmap) {
        this.mBitmap = bitmap;
    }

    public FLA_EdgeBorderBorderLightAnimate(Context context) {
        this.colors1 = context.getResources().getIntArray(R.array.color_pack_1);
        this.colors2 = context.getResources().getIntArray(R.array.color_pack_2);
        this.colors3 = context.getResources().getIntArray(R.array.color_pack_3);
        this.colors4 = context.getResources().getIntArray(R.array.color_pack_4);
        this.colors5 = context.getResources().getIntArray(R.array.color_pack_5);
        this.colors6 = context.getResources().getIntArray(R.array.color_pack_6);
        this.colors7 = context.getResources().getIntArray(R.array.color_pack_7);
        this.colors8 = context.getResources().getIntArray(R.array.color_pack_8);
        this.colors9 = context.getResources().getIntArray(R.array.color_pack_9);
        this.colors10 = context.getResources().getIntArray(R.array.color_pack_10);
        Paint paint = new Paint();
        this.paint = paint;
        this.position = new float[2];
        this.radii = new float[]{0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
        this.radiusBInfility = 150;
        this.radiusBottom = 0;
        this.radiusInfility = 150;
        this.radiusTop = 0;
        this.shape = FLA_Const.LINE;
        this.sharp = FLA_Const.NO;
        this.slope = new float[2];
        this.speed = 2.0f;
        this.strokeWidth = 70.0f;
        this.width = 0;
        this.widthInfility = 100;
        paint.setStrokeWidth(70.0f);
        this.paint.setStyle(Paint.Style.STROKE);
        this.paint.setStrokeJoin(Paint.Join.MITER);
        this.paint.setStrokeCap(Paint.Cap.ROUND);
        this.paint.setAntiAlias(true);
        this.path = new Path();
        this.matrix = new Matrix();
        this.context = context;
        int[] iArr = this.colors0;
        this.colors = iArr;
        this.distance = 1.0f / (iArr.length - 1);
        initPositions();
    }

    @Override
    public void onLayout(int i, int i2) {
        this.width = i;
        this.height = i2;
        drawPathLine(i, i2, this.notch, this.sharp, this.infility);
        drawShapeInLine();
        this.shader = new SweepGradient(i / 2, i2 / 2, this.colors, this.positions);
    }

    @Override
    public void onDraw(Canvas canvas) {
        Shader shader;
        float f = this.angle + this.speed;
        this.angle = f;
        Matrix matrix = this.matrix;
        if (matrix != null) {
            matrix.setRotate(f, this.width / 2, this.height / 2);
            SweepGradient sweepGradient = this.shader;
            if (sweepGradient != null) {
                sweepGradient.setLocalMatrix(this.matrix);
            }
        }
        int i = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.WIDTH, this.context);
        int i2 = FLA_MySharePreferencesEdge.getInt(FLA_MySharePreferencesEdge.HEIGHT, this.context);
        Bitmap bitmap = this.mBitmap;
        if (bitmap != null) {
            if (i > 0 && i2 > 0) {
                this.mBitmap = Bitmap.createScaledBitmap(bitmap, i, i2, false);
            }
            canvas.save();
            canvas.drawBitmap(this.mBitmap, 0.0f, 0.0f, (Paint) null);
            canvas.restore();
        }
        if (this.shape.equals(FLA_Const.LINE)) {
            this.paint.setShader(this.shader);
            this.paint.setStrokeWidth(this.strokeWidth);
            canvas.drawPath(this.path, this.paint);
        } else if (this.bitmapShape == null || (shader = this.shaderB) == null) {
        } else {
            if (this.shader != null) {
                this.paint.setShader(new ComposeShader(this.shader, shader, PorterDuff.Mode.DST_IN));
            }
            canvas.drawPath(this.path, this.paint);
        }
    }

    @Override
    public void changeColor(int[] iArr) {
        this.colors = iArr;
        initPositions();
        this.shader = new SweepGradient(this.width / 2, this.height / 2, this.colors, this.positions);
    }

    public void changeColorType(int i) {
        switch (i) {
            case 1:
                changeColor(this.colors1);
                return;
            case 2:
                changeColor(this.colors2);
                return;
            case 3:
                changeColor(this.colors3);
                return;
            case 4:
                changeColor(this.colors4);
                return;
            case 5:
                changeColor(this.colors5);
                return;
            case 6:
                changeColor(this.colors6);
                return;
            case 7:
                changeColor(this.colors7);
                return;
            case 8:
                changeColor(this.colors8);
                return;
            case 9:
                changeColor(this.colors9);
                return;
            case 10:
                changeColor(this.colors10);
                return;
            default:
                changeColor(this.colors0);
                return;
        }
    }

    private void initPositions() {

        this.positions = new float[this.colors.length];
        int i = 0;
        while (true) {
            if (i >= this.colors.length) {
                return;
            }
            if (i == 0) {
                this.positions[0] = this.distance / 2.0f;
            }
//            else if (i == iArr.length - 1) {
//                this.positions[iArr.length - 1] = 1.0f;
//            }
            else {
                float[] fArr = this.positions;
                fArr[i] = fArr[i - 1] + this.distance;
            }
            i++;
        }
    }

    private void drawPathLine(int i, int i2, boolean z, String str, String str2) {
        this.path.reset();
        Path path = this.path;
        float f = this.padding;
        path.moveTo(this.radiusTop + f, f);
        drawLed(i, i2, z, str2);
        if (!this.checkRotate) {
            if (str.equals(FLA_Const.CIRCLE)) {
                this.path.addCircle(this.holeX, this.holeY, this.holeRadius, Path.Direction.CW);
            } else if (str.equals(FLA_Const.ROUND)) {
                Path path2 = this.path;
                int i3 = this.holeX;
                int i4 = this.holeRadius;
                int i5 = this.holeY;
                int i6 = this.holeRadiusY;
                path2.addRoundRect(new RectF(i3 - i4, i5 - i6, i3 + i4, i5 + i6), this.radii, Path.Direction.CW);
            }
        } else if (str.equals(FLA_Const.CIRCLE)) {
            this.path.addCircle(i - this.holeY, this.holeX, this.holeRadius, Path.Direction.CW);
        } else if (str.equals(FLA_Const.ROUND)) {
            Path path3 = this.path;
            int i7 = this.holeY;
            int i8 = this.holeRadiusY;
            int i9 = this.holeX;
            int i10 = this.holeRadius;
            int i11 = i - i7;
            path3.addRoundRect(new RectF(i11 - i8, i9 - i10, i11 + i8, i9 + i10), this.radii, Path.Direction.CW);
        }
        this.path.close();
        this.pathMeasure = new PathMeasure(this.path, false);
    }

    private void drawShapeInLine() {
        int i;
        int i2 = this.width;
        if (i2 <= 0 || (i = this.height) <= 0 || this.bb == null) {
            return;
        }
        if (this.pathMeasure != null) {
            this.bitmapShape = Bitmap.createBitmap(i2, i, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(this.bitmapShape);
            int length = (int) (this.pathMeasure.getLength() / this.bb.getWidth());
            int i3 = 1;
            for (int i4 = 0; i4 < length; i4++) {
                this.pathMeasure.getPosTan(i3, this.position, this.slope);
                canvas.save();
                float[] fArr = this.position;
                canvas.translate(fArr[0] - this.centerX, fArr[1] - this.centerY);
                canvas.drawBitmap(this.bb, 0.0f, 0.0f, (Paint) null);
                canvas.restore();
                i3 += this.bb.getWidth();
            }
            if (this.sharp.equals(FLA_Const.CIRCLE) || this.sharp.equals(FLA_Const.ROUND)) {
                Path path = new Path();
                path.reset();
                if (!this.checkRotate) {
                    if (this.sharp.equals(FLA_Const.CIRCLE)) {
                        path.addCircle(this.holeX, this.holeY, this.holeRadius, Path.Direction.CW);
                    } else if (this.sharp.equals(FLA_Const.ROUND)) {
                        int i5 = this.holeX;
                        int i6 = this.holeRadius;
                        int i7 = this.holeY;
                        int i8 = this.holeRadiusY;
                        path.addRoundRect(new RectF(i5 - i6, i7 - i8, i5 + i6, i7 + i8), this.radii, Path.Direction.CW);
                    }
                } else if (this.sharp.equals(FLA_Const.CIRCLE)) {
                    path.addCircle(this.width - this.holeY, this.holeX, this.holeRadius, Path.Direction.CW);
                } else if (this.sharp.equals(FLA_Const.ROUND)) {
                    int i9 = this.width;
                    int i10 = this.holeY;
                    int i11 = this.holeRadiusY;
                    int i12 = this.holeX;
                    int i13 = this.holeRadius;
                    int i14 = i9 - i10;
                    path.addRoundRect(new RectF(i14 - i11, i12 - i13, i14 + i11, i12 + i13), this.radii, Path.Direction.CW);
                }
                path.close();
                PathMeasure pathMeasure = new PathMeasure(path, false);
                int length2 = (int) (pathMeasure.getLength() / this.bb.getWidth());
                int i15 = 1;
                for (int i16 = 0; i16 < length2; i16++) {
                    pathMeasure.getPosTan(i15, this.position, this.slope);
                    canvas.save();
                    float[] fArr2 = this.position;
                    canvas.translate(fArr2[0] - this.centerX, fArr2[1] - this.centerY);
                    canvas.drawBitmap(this.bb, 0.0f, 0.0f, (Paint) null);
                    canvas.restore();
                    i15 += this.bb.getWidth();
                }
            }
        }
        Bitmap bitmap = this.bitmapShape;
        if (bitmap != null) {
            this.shaderB = new BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        }
    }
    int i3;
    int i4;
    int i5;
    int i6;
    int i7;
    int i8;
    int i9;
    int i10;
    int i11;
    int i12;
    int i13;
    int i14;
    int i15;
    int i16;
    int i17;
    int i18;
    int i19;
    int i20;
    int i21;
    int i22;
    int i23;
    private void drawLed(int i, int i2, boolean z, String str) {

        if (!this.checkRotate) {
            if (z) {
                int i24 = i / 2;
                this.path.lineTo((i24 - this.notchTop) - this.notchRadiusTop, this.padding);
                Path path = this.path;
                int i25 = this.notchTop;
                float f = this.padding;
                path.cubicTo(i20 - this.notchRadiusTop, f, i24 - i25, f, i24 - this.notchCenter, f + (this.notchHeight / 2));
                float f2 = this.padding;
                float f3 = f2 + this.notchHeight;
                this.path.cubicTo(i24 - this.notchCenter, (i21 / 2) + f2, i24 - this.notchBottom, f3, i24 - this.notchRadiusBottom, f3);
                this.path.lineTo(this.notchRadiusBottom + i24, this.padding + this.notchHeight);
                Path path2 = this.path;
                float f4 = this.notchRadiusBottom + i24;
                float f5 = this.padding;
                float f6 = f5 + this.notchHeight;
                path2.cubicTo(f4, f6, this.notchBottom + i24, f6, this.notchCenter + i24, f5 + (i22 / 2));
                float f7 = this.padding;
                this.path.cubicTo(this.notchCenter + i24, f7 + (this.notchHeight / 2), this.notchTop + i24, f7, i23 + this.notchRadiusTop, f7);
                Path path3 = this.path;
                float f8 = this.padding;
                path3.lineTo((i - this.radiusTop) - f8, f8);
            } else if (str.equals(FLA_Const.INFILITYV)) {
                int i26 = i / 2;
                this.path.lineTo((i26 - this.widthInfility) - this.radiusInfility, this.padding);
                Path path4 = this.path;
                int i27 = this.widthInfility;
                int i28 = this.radiusInfility;
                float f9 = this.padding;
                path4.cubicTo(i17 - i28, f9, i26 - i27, f9, i26 - (i27 / 2), i28 + f9 + (this.heigthInfility / 2));
                Path path5 = this.path;
                int i29 = this.widthInfility;
                float f10 = this.padding;
                int i30 = this.radiusInfility;
                int i31 = i29 / 2;
                float f11 = i30 + f10;
                float f12 = f11 + (i18 / 2);
                path5.cubicTo(i26 - i31, f12, i26, f11 + this.radiusBInfility + this.heigthInfility, i31 + i26, f12);
                Path path6 = this.path;
                int i32 = this.widthInfility;
                float f13 = this.padding;
                int i33 = i26 + i32;
                path6.cubicTo((i32 / 2) + i26, this.radiusInfility + f13 + (this.heigthInfility / 2), i33, f13, i33 + i19, f13);
                Path path7 = this.path;
                float f14 = this.padding;
                path7.lineTo((i - this.radiusTop) - f14, f14);
            } else if (str.equals(FLA_Const.INFILITYU)) {
                int i34 = i / 2;
                this.path.lineTo((i34 - this.widthInfility) - this.radiusInfility, this.padding);
                Path path8 = this.path;
                int i35 = this.widthInfility;
                int i36 = this.radiusInfility;
                float f15 = this.padding;
                float f16 = i34 - i35;
                path8.cubicTo(i14 - i36, f15, f16, f15, f16, f15 + i36);
                this.path.lineTo(i34 - this.widthInfility, this.padding + this.radiusInfility + this.heigthInfility);
                Path path9 = this.path;
                int i37 = this.widthInfility;
                float f17 = this.padding;
                float f18 = i34;
                float f19 = i34 - i37;
                float f20 = this.radiusInfility;
                float f21 = this.heigthInfility;
                float f22 = f21 + f17 + f20 + 100.0f;
                path9.cubicTo(f19, f20 + f17 + f21, f19, f22, f18, f22);
                Path path10 = this.path;
                float f23 = this.padding;
                float f24 = this.heigthInfility;
                float f25 = this.radiusInfility;
                float f26 = f24 + f23 + f25 + 100.0f;
                float f27 = this.widthInfility + i34;
                path10.cubicTo(f18, f26, f27, f26, f27, f23 + f25 + f24);
                this.path.lineTo(this.widthInfility + i34, this.padding + this.radiusInfility);
                Path path11 = this.path;
                int i38 = this.widthInfility;
                float f28 = this.padding;
                float f29 = i34 + i38;
                path11.cubicTo(f29, f28 + this.radiusInfility, f29, f28, i16 + i15, f28);
                Path path12 = this.path;
                float f30 = this.padding;
                path12.lineTo((i - this.radiusTop) - f30, f30);
            } else {
                Path path13 = this.path;
                float f31 = this.padding;
                path13.lineTo((i - this.radiusTop) - f31, f31);
            }
            Path path14 = this.path;
            int i39 = this.radiusTop;
            float f32 = this.padding;
            float f33 = i;
            float f34 = f33 - f32;
            path14.cubicTo((i - i39) - f32, f32, f34, f32, f34, i39 + f32);
            Path path15 = this.path;
            float f35 = this.padding;
            float f36 = i2;
            path15.lineTo(f33 - f35, (f36 - f35) - this.radiusBottom);
            Path path16 = this.path;
            float f37 = this.padding;
            float f38 = f33 - f37;
            float f39 = f36 - f37;
            float f40 = this.radiusBottom;
            path16.cubicTo(f38, f39 - f40, f38, f39, f38 - f40, f39);
            Path path17 = this.path;
            float f41 = this.padding;
            path17.lineTo(this.radiusBottom + f41, f36 - f41);
            Path path18 = this.path;
            float f42 = this.padding;
            float f43 = this.radiusBottom;
            float f44 = f36 - f42;
            path18.cubicTo(f42 + f43, f44, f42, f44, f42, f44 - f43);
            Path path19 = this.path;
            float f45 = this.padding;
            path19.lineTo(f45, this.radiusTop + f45);
            Path path20 = this.path;
            float f46 = this.padding;
            float f47 = f46 + this.radiusTop;
            path20.cubicTo(f46, f47, f46, f46, f47, f46);
            Path path21 = this.path;
            float f48 = this.padding;
            path21.lineTo(this.radiusTop + f48 + 20.0f, f48);
            return;
        }
        Path path22 = this.path;
        float f49 = this.padding;
        path22.lineTo((i - this.radiusTop) - f49, f49);
        Path path23 = this.path;
        int i40 = this.radiusTop;
        float f50 = this.padding;
        float f51 = i;
        float f52 = f51 - f50;
        path23.cubicTo((i - i40) - f50, f50, f52, f50, f52, i40 + f50);
        if (z) {
            int i41 = i2 / 2;
            this.path.lineTo(f51 - this.padding, (i41 - this.notchTop) - this.notchRadiusTop);
            Path path24 = this.path;
            float f53 = f51 - this.padding;
            path24.cubicTo(f53, i10 - this.notchRadiusTop, f53, i41 - this.notchTop, f53 - (this.notchHeight / 2), i41 - this.notchCenter);
            Path path25 = this.path;
            float f54 = this.padding;
            float f55 = f51 - f54;
            float f56 = f55 - this.notchHeight;
            path25.cubicTo(f55 - (i11 / 2), i41 - this.notchCenter, f56, i41 - this.notchBottom, f56, i41 - this.notchRadiusBottom);
            this.path.lineTo((f51 - this.padding) - this.notchHeight, this.notchRadiusBottom + i41);
            Path path26 = this.path;
            float f57 = this.padding;
            float f58 = f51 - f57;
            float f59 = f58 - this.notchHeight;
            path26.cubicTo(f59, this.notchRadiusBottom + i41, f59, this.notchBottom + i41, f58 - (i12 / 2), this.notchCenter + i41);
            Path path27 = this.path;
            float f60 = f51 - this.padding;
            path27.cubicTo(f60 - (this.notchHeight / 2), this.notchCenter + i41, f60, this.notchTop + i41, f60, i13 + this.notchRadiusTop);
            Path path28 = this.path;
            float f61 = this.padding;
            path28.lineTo(f51 - f61, (i2 - f61) - this.radiusBottom);
        } else if (str.equals(FLA_Const.INFILITYV)) {
            int i42 = i2 / 2;
            this.path.lineTo(f51 - this.padding, (i42 - this.widthInfility) - this.radiusInfility);
            Path path29 = this.path;
            float f62 = this.padding;
            int i43 = this.widthInfility;
            float f63 = f51 - f62;
            int i44 = i42 - i43;
            path29.cubicTo(f63, i44 - i6, f63, i44, (f63 - this.radiusInfility) - (this.heigthInfility / 2), i42 - (i43 / 2));
            Path path30 = this.path;
            float f64 = this.padding;
            int i45 = this.radiusInfility;
            int i46 = this.heigthInfility;
            float f65 = (f51 - f64) - i45;
            float f66 = f65 - (i46 / 2);
            int i47 = this.widthInfility / 2;
            path30.cubicTo(f66, i42 - i47, (f65 - this.radiusBInfility) - i46, i42, f66, i47 + i42);
            Path path31 = this.path;
            float f67 = this.padding;
            float f68 = f51 - f67;
            path31.cubicTo((f68 - this.radiusInfility) - (this.heigthInfility / 2), (i8 / 2) + i42, f68, i42 + this.widthInfility, f68, i9 + i7);
            Path path32 = this.path;
            float f69 = this.padding;
            path32.lineTo(f51 - f69, (i2 - f69) - this.radiusBottom);
        } else if (str.equals(FLA_Const.INFILITYU)) {
            int i48 = i2 / 2;
            this.path.lineTo(f51 - this.padding, (i48 - this.widthInfility) - this.radiusInfility);
            Path path33 = this.path;
            float f70 = this.padding;
            int i49 = this.widthInfility;
            float f71 = f51 - f70;
            float f72 = i48 - i49;
            path33.cubicTo(f71, i4 - i3, f71, f72, f71 - this.radiusInfility, f72);
            this.path.lineTo(((f51 - this.padding) - this.radiusInfility) - this.heigthInfility, i48 - this.widthInfility);
            Path path34 = this.path;
            float f73 = i48;
            float f74 = f51 - this.padding;
            float f75 = this.radiusInfility;
            float f76 = this.heigthInfility;
            float f77 = i48 - this.widthInfility;
            float f78 = ((f74 - f76) - f75) - 100.0f;
            path34.cubicTo((f74 - f75) - f76, f77, f78, f77, f78, f73);
            Path path35 = this.path;
            float f79 = f51 - this.padding;
            float f80 = this.heigthInfility;
            float f81 = this.radiusInfility;
            float f82 = ((f79 - f80) - f81) - 100.0f;
            float f83 = this.widthInfility + i48;
            path35.cubicTo(f82, f73, f82, f83, (f79 - f81) - f80, f83);
            this.path.lineTo((f51 - this.padding) - this.radiusInfility, this.widthInfility + i48);
            Path path36 = this.path;
            float f84 = this.padding;
            int i50 = this.radiusInfility;
            float f85 = f51 - f84;
            float f86 = i48 + this.widthInfility;
            path36.cubicTo(f85 - i50, f86, f85, f86, f85, i5 + i50);
            Path path37 = this.path;
            float f87 = this.padding;
            path37.lineTo(f51 - f87, (i2 - f87) - this.radiusBottom);
        } else {
            Path path38 = this.path;
            float f88 = this.padding;
            path38.lineTo(f51 - f88, (i2 - f88) - this.radiusBottom);
        }
        Path path39 = this.path;
        float f89 = this.padding;
        float f90 = i2;
        float f91 = f51 - f89;
        float f92 = f90 - f89;
        float f93 = this.radiusBottom;
        path39.cubicTo(f91, f92 - f93, f91, f92, f91 - f93, f92);
        Path path40 = this.path;
        float f94 = this.padding;
        path40.lineTo(this.radiusBottom + f94, f90 - f94);
        Path path41 = this.path;
        float f95 = this.padding;
        float f96 = this.radiusBottom;
        float f97 = f90 - f95;
        path41.cubicTo(f95 + f96, f97, f95, f97, f95, f97 - f96);
        Path path42 = this.path;
        float f98 = this.padding;
        path42.lineTo(f98, this.radiusTop + f98);
        Path path43 = this.path;
        float f99 = this.padding;
        float f100 = f99 + this.radiusTop;
        path43.cubicTo(f99, f100, f99, f99, f100, f99);
        Path path44 = this.path;
        float f101 = this.padding;
        path44.lineTo(this.radiusTop + f101 + 20.0f, f101);
    }

    public void changeSpeed(float f) {
        SweepGradient sweepGradient;
        this.speed = f;
        Matrix matrix = this.matrix;
        if (matrix == null || (sweepGradient = this.shader) == null) {
            return;
        }
        sweepGradient.setLocalMatrix(matrix);
        this.matrix.setRotate(this.angle + f, this.width / 2, this.height / 2);
    }

    public void changeSize(int i) {
        Bitmap bitmap;
        float f = i;
        this.strokeWidth = f;
        this.padding = i / 2;
        this.paint.setStrokeWidth(f);
        drawPathLine(this.width, this.height, this.notch, this.sharp, this.infility);
        if (i > 0 && (bitmap = this.bitmap) != null) {
            Bitmap createScaledBitmap = Bitmap.createScaledBitmap(bitmap, i, i, false);
            this.bb = createScaledBitmap;
            this.centerX = createScaledBitmap.getWidth() / 2;
            this.centerY = this.bb.getHeight() / 2;
        }
        drawShapeInLine();
    }

    public void changeRadius(int i, int i2) {
        this.radiusTop = i;
        this.radiusBottom = i2;
        drawPathLine(this.width, this.height, this.notch, this.sharp, this.infility);
        drawShapeInLine();
    }

    public void changeNotch(boolean z, int i, int i2, int i3, int i4, int i5) {
        this.notchTop = i;
        this.notchRadiusTop = i4;
        this.notchRadiusBottom = i5;
        this.notchCenter = (i + i2) / 2;
        this.notchBottom = i2;
        this.notchHeight = i3;
        this.notch = z;
        drawPathLine(this.width, this.height, z, this.sharp, this.infility);
        drawShapeInLine();
    }

    public void changeHole(String str, int i, int i2, int i3, int i4, int i5) {
        float[] fArr = this.radii;
        float f = i5;
        fArr[0] = f;
        fArr[2] = f;
        fArr[3] = f;
        fArr[1] = f;
        fArr[4] = f;
        fArr[5] = f;
        fArr[6] = f;
        fArr[7] = f;
        this.sharp = str;
        this.holeRadius = i3;
        this.holeX = i;
        this.holeY = i2;
        this.holeRadiusY = i4;
        drawPathLine(this.width, this.height, this.notch, str, this.infility);
        drawShapeInLine();
    }

    public void changeInfility(String str, int i, int i2, int i3, int i4) {
        this.infility = str;
        this.widthInfility = i;
        this.heigthInfility = i2;
        this.radiusInfility = i3;
        this.radiusBInfility = i4;
        drawPathLine(this.width, this.height, this.notch, this.sharp, str);
        drawShapeInLine();
    }

    public void changeShape(String str, Bitmap bitmap) {
        this.shape = str;
        this.bitmap = bitmap;
        if (this.paint.getStrokeWidth() > 0.0f && bitmap != null) {
            Bitmap createScaledBitmap = Bitmap.createScaledBitmap(bitmap, (int) this.paint.getStrokeWidth(), (int) this.paint.getStrokeWidth(), false);
            this.bb = createScaledBitmap;
            this.centerX = createScaledBitmap.getWidth() / 2;
            this.centerY = this.bb.getHeight() / 2;
        }
        drawPathLine(this.width, this.height, this.notch, this.sharp, this.infility);
        drawShapeInLine();
    }

    public void changeType(final String str) {
        System.out.println("oooooooop001-=" + str);
        new FLA_DecodeEdgeResource(this.context, str, new FLA_DecodeEdgeResource.CallBack() {
            @Override
            public void decodeDone(Bitmap bitmap) {
                FLA_EdgeBorderBorderLightAnimate.this.changeShape(str, bitmap);
            }
        }).execute(new Void[0]);
    }
}
