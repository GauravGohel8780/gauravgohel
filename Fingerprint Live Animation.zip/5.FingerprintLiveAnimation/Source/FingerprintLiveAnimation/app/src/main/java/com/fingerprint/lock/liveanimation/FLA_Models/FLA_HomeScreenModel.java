package com.fingerprint.lock.liveanimation.FLA_Models;



public class FLA_HomeScreenModel {
    private String animPath;
    private String bgPath;
    private int id;

    public String getAnimPath() {
        return this.animPath;
    }

    public String getBgPath() {
        return this.bgPath;
    }

    public int getId() {
        return this.id;
    }




    public void setAnimPath(String str) {
        this.animPath = str;
    }

    public void setBgPath(String str) {
        this.bgPath = str;
    }

    public void setId(int i) {
        this.id = i;
    }



    public FLA_HomeScreenModel() {
    }
}
