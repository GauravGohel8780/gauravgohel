package com.fingerprint.lock.liveanimation.FLA_Adapters;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import java.util.List;


public class FLA_ViewPagerFragmentAdapter extends FragmentStateAdapter {
    List<Fragment> fragmentList;

    public FLA_ViewPagerFragmentAdapter(FragmentActivity fragmentActivity, List<Fragment> list) {
        super(fragmentActivity);
        this.fragmentList = list;
    }

    @Override
    public Fragment createFragment(int i) {
        return this.fragmentList.get(i);
    }

    @Override 
    public int getItemCount() {
        return this.fragmentList.size();
    }
}
