package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_LikeButton;


public enum FLA_IconType {
    Heart,
    Thumb,
    Star
}
