package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_EdgeEffect;

import android.content.Context;


public class FLA_MySharePreferencesEdge {
    public static String BACKGROUND = "background";
    public static String BACKGROUNDCOLOR = "backgroundcolor";
    public static String BACKGROUNDLINK = "backgroundlink";
    public static String CHECKNOTCH = "checknotch";
    public static String COLOR1 = "color1";
    public static String COLOR2 = "color2";
    public static String COLOR3 = "color3";
    public static String COLOR4 = "color5";
    public static String COLOR5 = "color6";
    public static String COLOR6 = "color4";
    public static String ControlWindowManager = "ChangeWindowManager";
    public static String FINISH_BACKGROUND = "finish_background";
    public static String FINISH_BACKGROUNDCOLOR = "finish_backgroundcolor";
    public static String FINISH_BACKGROUNDLINK = "finish_backgroundlink";
    public static String FINISH_CHECKNOTCH = "finish_checknotch";
    public static String FINISH_CHECKSHAPE = "finish_checkshape";
    public static String FINISH_COLOR1 = "finish_color1";
    public static String FINISH_COLOR2 = "finish_color2";
    public static String FINISH_COLOR3 = "finish_color3";
    public static String FINISH_COLOR4 = "finish_color5";
    public static String FINISH_COLOR5 = "finish_color6";
    public static String FINISH_COLOR6 = "finish_color4";
    public static String FINISH_HOLECORNER = "finish_holecorner";
    public static String FINISH_HOLERADIUS = "finish_holeradius";
    public static String FINISH_HOLERADIUSY = "finish_holeradiusy";
    public static String FINISH_HOLESHARP = "finish_holesharp";
    public static String FINISH_HOLEX = "finish_holex";
    public static String FINISH_HOLEY = "finish_holey";
    public static String FINISH_INFILITYHEIGHT = "finish_infilityheight";
    public static String FINISH_INFILITYRADIUS = "finish_infilityradius";
    public static String FINISH_INFILITYRADIUSB = "finish_infilityradiusb";
    public static String FINISH_INFILITYSHARP = "finish_infilitysharp";
    public static String FINISH_INFILITYWIDTH = "finish_infilitywidth";
    public static String FINISH_NOTCHBOTTOM = "finish_notchbottom";
    public static String FINISH_NOTCHHEIGHT = "finish_notchheight";
    public static String FINISH_NOTCHRADIUSBOTTOM = "finish_notchradiusbottom";
    public static String FINISH_NOTCHRADIUSTOP = "finish_notchradiustop";
    public static String FINISH_NOTCHTOP = "finish_notchtop";
    public static String FINISH_RADIUSBOTTOM = "finish_bottom";
    public static String FINISH_RADIUSTOP = "finish_top";
    public static String FINISH_SHAPE = "finish_shape";
    public static String FINISH_SIZE = "finish_size";
    public static String FINISH_SPEED = "finish_speed";
    public static String HEIGHT = "height";
    public static String HOLECORNER = "holecorner";
    public static String HOLERADIUS = "holeradius";
    public static String HOLERADIUSY = "holeradiusy";
    public static String HOLESHARP = "holesharp";
    public static String HOLEX = "holex";
    public static String HOLEY = "holey";
    public static String INFILITYHEIGHT = "infilityheight";
    public static String INFILITYRADIUS = "infilityradius";
    public static String INFILITYRADIUSB = "infilityradiusb";
    public static String INFILITYSHARP = "infilitysharp";
    public static String INFILITYWIDTH = "infilitywidth";
    private static final String NEWS_ADS_PREFERENCES = "DUONGCV";
    public static String NOTCHBOTTOM = "notchbottom";
    public static String NOTCHHEIGHT = "notchheight";
    public static String NOTCHRADIUSBOTTOM = "notchradiusbottom";
    public static String NOTCHRADIUSTOP = "notchradiustop";
    public static String NOTCHTOP = "notchtop";
    public static String RADIUSBOTTOM = "bottom";
    public static String RADIUSTOP = "top";
    public static String SHAPE = "shape";
    public static String SIZE = "size";
    public static String SPEED = "speed";
    public static String WIDTH = "width";

    public static int getInt(String str, Context context) {
        return getIntValue(str, context);
    }

    public static String getString(String str, Context context) {
        return getStringValue(str, context);
    }

    public static boolean getBooleanValue(String str, Context context) {
        return context.getSharedPreferences(NEWS_ADS_PREFERENCES, 0).getBoolean(str, false);
    }

    public static String getStringValue(String str, Context context) {
        return context.getSharedPreferences(NEWS_ADS_PREFERENCES, 0).getString(str, null);
    }
    public static int getIntValue(String str, Context context) {
        return context.getSharedPreferences(NEWS_ADS_PREFERENCES, 0).getInt(str, -1);
    }
}
