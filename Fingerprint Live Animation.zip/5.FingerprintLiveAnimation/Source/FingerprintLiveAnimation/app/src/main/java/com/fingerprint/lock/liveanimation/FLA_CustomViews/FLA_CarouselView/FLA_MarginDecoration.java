package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_CarouselView;

import android.graphics.Rect;
import android.view.View;

import androidx.recyclerview.widget.RecyclerView;


public final class FLA_MarginDecoration extends RecyclerView.ItemDecoration {
    private final int marginLeft;
    private final int marginRight;

  
    public FLA_MarginDecoration(int i, int i2) {
        this.marginLeft = i;
        this.marginRight = i2;
    }

    @Override
    public void getItemOffsets(Rect rect, View view, RecyclerView recyclerView, RecyclerView.State state) {
        rect.left = this.marginLeft;
        rect.right = this.marginRight;
    }
}
