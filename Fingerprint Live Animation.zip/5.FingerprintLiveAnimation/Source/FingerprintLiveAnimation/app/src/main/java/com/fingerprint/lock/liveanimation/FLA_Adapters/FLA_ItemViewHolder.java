package com.fingerprint.lock.liveanimation.FLA_Adapters;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

import com.fingerprint.lock.liveanimation.databinding.RowPagerAdapterBinding;


public class FLA_ItemViewHolder extends RecyclerView.ViewHolder {
    RowPagerAdapterBinding binding;

    public FLA_ItemViewHolder(View view) {
        super(view);
        this.binding = RowPagerAdapterBinding.bind(view);
    }
}
