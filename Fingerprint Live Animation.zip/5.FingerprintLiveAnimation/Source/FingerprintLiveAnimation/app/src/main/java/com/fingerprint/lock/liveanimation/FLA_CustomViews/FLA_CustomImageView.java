package com.fingerprint.lock.liveanimation.FLA_CustomViews;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatImageView;


public class FLA_CustomImageView extends AppCompatImageView {
    private Bitmap bitmap;
    private int borderColor;
    int borderRadius;
    private int borderWidth;
    private boolean isCircle;
    private boolean removeBorder;

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }


    public void setCircle(boolean z) {
        this.isCircle = z;
    }

    public FLA_CustomImageView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.borderRadius = 35;
        this.borderColor = 0;
        this.removeBorder = true;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Bitmap bitmapResource = getBitmapResource();
        if (bitmapResource != null) {
            Bitmap copy = bitmapResource.copy(Bitmap.Config.ARGB_8888, true);
            canvas.drawBitmap(getRoundedCroppedBitmap(cropBitmap(copy), getWidth()), 0.0f, 0.0f, (Paint) null);
        }
    }

    private Bitmap getBitmapResource() {
        Bitmap bitmap = this.bitmap;
        if (bitmap == null) {
            Drawable drawable = getDrawable();
            if (drawable == null || getWidth() == 0 || getHeight() == 0) {
                return null;
            }
            return getBitmapFromDrawable(drawable);
        }
        return bitmap;
    }

    private Bitmap getBitmapFromDrawable(Drawable drawable) {
        Bitmap createBitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return createBitmap;
    }

    private Bitmap cropBitmap(Bitmap bitmap) {
        if (bitmap.getWidth() > bitmap.getHeight()) {
            return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getHeight(), bitmap.getHeight());
        }
        return bitmap.getWidth() < bitmap.getHeight() ? Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getWidth()) : bitmap;
    }

    private Bitmap getRoundedCroppedBitmap(Bitmap bitmap, int i) {
        if (bitmap.getWidth() != i || bitmap.getHeight() != i) {
            bitmap = Bitmap.createScaledBitmap(bitmap, i, i, false);
        }
        Bitmap createBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        Paint paint = new Paint();
        Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        paint.setAntiAlias(true);
        paint.setFilterBitmap(true);
        paint.setDither(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(-1);
        if (this.isCircle) {
            canvas.drawRoundRect(new RectF(0.0f, 0.0f, bitmap.getWidth(), bitmap.getHeight()), getWidth() / 2.0f, getWidth() / 2.0f, paint);
        } else {
            RectF rectF = new RectF(0.0f, 0.0f, bitmap.getWidth(), bitmap.getHeight());
            int i2 = this.borderRadius;
            canvas.drawRoundRect(rectF, i2, i2, paint);
        }
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);
        if (!this.removeBorder) {
            if (this.isCircle) {
                canvas.drawRoundRect(new RectF(0.0f, 0.0f, bitmap.getWidth(), bitmap.getHeight()), getWidth() / 2.0f, getWidth() / 2.0f, getBorderPaint());
            } else {
                RectF rectF2 = new RectF(0.0f, 0.0f, bitmap.getWidth(), bitmap.getHeight());
                int i3 = this.borderRadius;
                canvas.drawRoundRect(rectF2, i3, i3, getBorderPaint());
            }
        }
        return createBitmap;
    }

    private Paint getBorderPaint() {
        Paint paint = new Paint();
        int i = this.borderColor;
        if (i != 0) {
            paint.setColor(i);
        } else {
            paint.setColor(-1);
        }
        int i2 = this.borderWidth;
        if (i2 != 0) {
            paint.setStrokeWidth(i2);
        } else {
            paint.setStrokeWidth(0.0f);
        }
        paint.setStyle(Paint.Style.STROKE);
        paint.setAntiAlias(true);
        return paint;
    }
}
