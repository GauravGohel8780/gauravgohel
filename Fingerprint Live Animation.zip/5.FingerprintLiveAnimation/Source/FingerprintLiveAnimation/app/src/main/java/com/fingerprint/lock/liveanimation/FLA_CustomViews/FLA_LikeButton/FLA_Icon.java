package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_LikeButton;


public class FLA_Icon {
    private FLA_IconType iconType;
    private int offIconResourceId;
    private int onIconResourceId;

    public FLA_IconType getIconType() {
        return this.iconType;
    }

    public int getOffIconResourceId() {
        return this.offIconResourceId;
    }

    public int getOnIconResourceId() {
        return this.onIconResourceId;
    }

    public void setIconType(FLA_IconType iconType) {
        this.iconType = iconType;
    }

    public void setOffIconResourceId(int i) {
        this.offIconResourceId = i;
    }

    public void setOnIconResourceId(int i) {
        this.onIconResourceId = i;
    }

    public FLA_Icon(int i, int i2, FLA_IconType iconType) {
        this.onIconResourceId = i;
        this.offIconResourceId = i2;
        this.iconType = iconType;
    }
}
