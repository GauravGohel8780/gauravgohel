package com.fingerprint.lock.liveanimation.FLA_Utils;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Set;


public class FLA_SharedPreferenceManager {
    protected Context mContext;
    protected SharedPreferences.Editor mEditor;
    protected SharedPreferences mSettings;

    public FLA_SharedPreferenceManager(Context context, String str) {
        this.mContext = context;
        SharedPreferences sharedPreferences = context.getSharedPreferences(str, 4);
        this.mSettings = sharedPreferences;
        this.mEditor = sharedPreferences.edit();
    }

    public void setInterface(SharedPreferences.OnSharedPreferenceChangeListener onSharedPreferenceChangeListener) {
        this.mSettings.registerOnSharedPreferenceChangeListener(onSharedPreferenceChangeListener);
    }

    public void setValue(String str, String str2) {
        this.mEditor.putString(str, str2);
        this.mEditor.commit();
    }

    public void setIntValue(String str, int i) {
        this.mEditor.putInt(str, i);
        this.mEditor.commit();
    }

    public void setFloatValue(String str, float f) {
        this.mEditor.putFloat(str, f);
        this.mEditor.commit();
    }

    public String getValue(String str, String str2) {
        return this.mSettings.getString(str, str2);
    }

    public int getIntValue(String str, int i) {
        return this.mSettings.getInt(str, i);
    }

    public float getFloatValue(String str, float f) {
        return this.mSettings.getFloat(str, f);
    }


    public boolean getBooleanValue(String str, boolean z) {
        SharedPreferences sharedPreferences = this.mSettings;
        if (sharedPreferences != null) {
            return sharedPreferences.getBoolean(str, z);
        }
        return false;
    }

    public void setBooleanValue(String str, boolean z) {
        this.mEditor.putBoolean(str, z);
        this.mEditor.commit();
    }
    public ArrayList<String> getStringArrayList(String str) {
        ArrayList<String> arrayList = new ArrayList<>();
        Set<String> stringSet = this.mSettings.getStringSet(str, null);
        return stringSet != null ? new ArrayList<>(stringSet) : arrayList;
    }
}
