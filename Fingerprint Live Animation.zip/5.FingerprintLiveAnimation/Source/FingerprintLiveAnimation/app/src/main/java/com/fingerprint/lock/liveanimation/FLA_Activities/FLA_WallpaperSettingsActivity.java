package com.fingerprint.lock.liveanimation.FLA_Activities;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Activity;
import android.app.WallpaperInfo;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.ViewTreeObserver;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.SeekBar;


import androidx.recyclerview.widget.ItemTouchHelper;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.fingerprint.lock.liveanimation.Ads_Common.AdsBaseActivity;
import com.fingerprint.lock.liveanimation.FLA_Adapters.FLA_Adapter_Rv_ColorBg;
import com.fingerprint.lock.liveanimation.FLA_Adapters.FLA_Adapter_Rv_Shapes;
import com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_EdgeEffect.FLA_Const;
import com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_EdgeEffect.FLA_EdgeBorderLightView;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_OnRvItemClickListener;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_ShapesModel;
import com.fingerprint.lock.liveanimation.R;
import com.fingerprint.lock.liveanimation.FLA_Utils.FLA_Services.FLA_WallpaperService;
import com.fingerprint.lock.liveanimation.FLA_Utils.FLA_SharedPreferenceManager;
import com.fingerprint.lock.liveanimation.databinding.ActivityWallpaperSettingsBinding;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.zackratos.ultimatebarx.ultimatebarx.java.UltimateBarX;


import java.io.IOException;
import java.util.ArrayList;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;


public class FLA_WallpaperSettingsActivity extends AdsBaseActivity implements View.OnClickListener {
    String animPath;
    String bgImgPath;
    ActivityWallpaperSettingsBinding binding;
    int disabledColor;
    int enabledColor;
    Bitmap imgBitmap;
    FLA_SharedPreferenceManager spm;
    WallpaperInfo wallpaperInfo;
    WallpaperManager wallpaperManager;
    int whiteColor;
    Activity activity = this;
    Context context = this;
    int sizeValue = ItemTouchHelper.Callback.DEFAULT_SWIPE_ANIMATION_DURATION;
    float positionValue = 1.5f;
    float speedValue = 1.0f;
    int edgeSize = 40;
    int edgeAnimSpeed = 2;
    int edgeRadius = 0;
    int edgeColorType = 0;
    String edgeShapeType = FLA_Const.LINE;
    boolean isEdgeActive = true;
    boolean isFingerAnimActive = true;
    public int durationAnim = 500;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.bgImgPath = getIntent().getStringExtra("bgImgPath");
        this.animPath = getIntent().getStringExtra("animPath");
        this.binding = ActivityWallpaperSettingsBinding.inflate(getLayoutInflater());
        this.enabledColor = getResources().getColor(R.color.colorTabText, getTheme());
        this.disabledColor = getResources().getColor(R.color.colorTabGray, getTheme());
        this.whiteColor = getResources().getColor(R.color.white, getTheme());
        UltimateBarX.navigationBar(this).transparent().colorRes(R.color.transparent).light(false).apply();
        UltimateBarX.statusBar(this).transparent().colorRes(R.color.transparent).light(false).apply();
        setContentView(this.binding.getRoot());
        registerInAppMsgEventForActivity(this, "WallpaperSettingAndPreview");
        WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
        this.wallpaperManager = wallpaperManager;
        this.wallpaperInfo = wallpaperManager.getWallpaperInfo();
        FLA_SharedPreferenceManager sharedPreferenceManager = new FLA_SharedPreferenceManager(this.context, "clockData");
        this.spm = sharedPreferenceManager;
        this.sizeValue = sharedPreferenceManager.getIntValue("scaleValue", this.sizeValue);
        this.positionValue = this.spm.getFloatValue("positionValue", this.positionValue);
        this.speedValue = this.spm.getFloatValue("speedValue", this.speedValue);
        this.edgeSize = this.spm.getIntValue("edgeSize", this.edgeSize);
        this.edgeRadius = this.spm.getIntValue("edgeRadius", this.edgeRadius);
        this.edgeAnimSpeed = this.spm.getIntValue("edgeAnimSpeed", this.edgeAnimSpeed);
        this.isEdgeActive = this.spm.getBooleanValue("isEdgeActive", this.isEdgeActive);
        this.isFingerAnimActive = this.spm.getBooleanValue("isFingerAnimActive", this.isFingerAnimActive);
        this.edgeColorType = this.spm.getIntValue("edgeColorType", this.edgeColorType);
        this.edgeShapeType = this.spm.getValue("edgeShapeType", this.edgeShapeType);
        if (this.bgImgPath != null) {
            Glide.with(this.context).asBitmap().load(this.bgImgPath).into(new CustomTarget<Bitmap>() { // from class: com.modern.wallpaper.fingerprintedgelightwallpaper.Activities.WallpaperSettingsActivity.1
                @Override
                public void onLoadCleared(Drawable drawable) {
                }

                public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                    FLA_WallpaperSettingsActivity.this.imgBitmap = bitmap;
                    FLA_WallpaperSettingsActivity.this.binding.imageView.setImageBitmap(bitmap);
                    FLA_WallpaperSettingsActivity.this.binding.imageView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() { // from class: com.modern.wallpaper.fingerprintedgelightwallpaper.Activities.WallpaperSettingsActivity.1.1
                        @Override
                        public void onGlobalLayout() {
                            FLA_WallpaperSettingsActivity.this.binding.blurView.setupWith(FLA_WallpaperSettingsActivity.this.binding.getRoot());
                            FLA_WallpaperSettingsActivity.this.binding.blurView.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
                            FLA_WallpaperSettingsActivity.this.binding.blurView.setClipToOutline(true);
                            FLA_WallpaperSettingsActivity.this.binding.imageView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                        }
                    });
                }
            });
        }
        initViews();

        FLA_WallpaperService.isSettingsUpdated = false;
        this.spm.setBooleanValue("isPreviewOnly", false);
    }

    private void initViews() {
        int i = 0;
        setSupportActionBar(this.binding.toolbar);
        this.binding.toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                getInstance(FLA_WallpaperSettingsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        if (this.animPath != null) {
            this.binding.lottieView.setFilePath(this.animPath);
        }
        this.binding.lottieView.setSize(this.sizeValue);
        this.binding.lottieView.setPositionY(this.positionValue);
        this.binding.seekbarPosition.setMax(800);
        this.binding.seekbarPosition.setProgress((int) ((this.positionValue - 1.0f) * 1000.0f));
        this.binding.tvValuePosition.setText(100 + "%");
        this.binding.seekbarPosition.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int i2, boolean z) {
                float f4 = i2 / 1000.0f;
                float f5 = 1.0f + f4;
                System.out.println("bbbbbbpopoopopo01-=" + i2 + " - " + f4 + " - " + f5);
                FLA_WallpaperSettingsActivity.this.positionValue = f5;
                FLA_WallpaperSettingsActivity.this.binding.lottieView.setPositionY(f5);
                FLA_WallpaperSettingsActivity.this.binding.tvValuePosition.setText(((int) (i2 / 8.0f)) + "%");
            }
        });
        this.binding.seekbarSize.setMax(750);
        int i2 = this.sizeValue - 25;
        this.binding.seekbarSize.setProgress(i2);
        if (i2 + 50.0f > 0.0f) {
            this.binding.tvValueScale.setText(((int) positionValue) + "%");
        }
        this.binding.seekbarSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int i3, boolean z) {
                int i4 = i3 + ItemTouchHelper.Callback.DEFAULT_SWIPE_ANIMATION_DURATION;
                System.out.println("bbbbbbpopoopopo01-=" + i3 + " - " + i4);
                FLA_WallpaperSettingsActivity.this.sizeValue = i4;
                FLA_WallpaperSettingsActivity.this.binding.lottieView.setSize(i4);
                float f3 = i3 + 50.0f;
                if (f3 > 0.0f) {
                    FLA_WallpaperSettingsActivity.this.binding.tvValueScale.setText(((int) i3) + "%");
                }
            }
        });
        this.binding.seekbarSpeed.setMax(510);
        this.binding.seekbarSpeed.setProgress((int) (this.speedValue * 100.0f));
        this.binding.tvValueSpeed.setText(((int) (speedValue - 10.0f)) + "%");
        this.binding.seekbarSpeed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int i3, boolean z) {
                float f3;
                float f4 = i3 / 100.0f;
                if (f4 >= 0.1d) {
                    FLA_WallpaperSettingsActivity.this.binding.lottieView.setAnimSpeed(f4);
                    FLA_WallpaperSettingsActivity.this.binding.tvValueSpeed.setText(((int) (i3 - 10.0f)) + "%");
                }
            }
        });

        this.binding.continueBtn.setOnClickListener(this);
        this.binding.mtbOption1.setOnClickListener(this);
        this.binding.mtbOption2.setOnClickListener(this);
        this.binding.constraintSwitchFinger.setOnClickListener(this);
        this.binding.constraintSwitchEdgeLight.setOnClickListener(this);
        this.binding.checkbox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(FLA_WallpaperSettingsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        if (!binding.checkbox.isChecked()) {
                            binding.checkbox.setChecked(false);
                            binding.mcvOptions.animate().alpha(0.0f).setDuration(i).setInterpolator(new DecelerateInterpolator()).withEndAction(new Runnable() {
                                @Override
                                public void run() {
                                    binding.mcvOptions.animate().alpha(1.0f).setDuration(i).setInterpolator(new AccelerateInterpolator()).start();
                                    binding.mcvOptions.setVisibility(View.VISIBLE);
                                }
                            }).start();
                            return;
                        }
                        binding.checkbox.setChecked(true);
                        binding.mcvOptions.animate().alpha(1.0f).setDuration(i).setInterpolator(new DecelerateInterpolator()).withEndAction(new Runnable() {
                            @Override
                            public void run() {
                                binding.mcvOptions.animate().alpha(0.0f).setDuration(i).setInterpolator(new AccelerateInterpolator()).withEndAction(new Runnable() { // from class: com.modern.wallpaper.fingerprintedgelightwallpaper.Activities.WallpaperSettingsActivity$$ExternalSyntheticLambda9
                                    @Override
                                    public final void run() {
                                        binding.mcvOptions.setVisibility(View.GONE);
                                    }
                                }).start();
                            }
                        }).start();
                    }
                }, MAIN_CLICK);
            }

        });
        this.binding.seekbarEdgeSize.setProgress(this.edgeSize);
        this.binding.tvValueEdgeSize.setText(String.valueOf(this.edgeSize));
        this.binding.seekbarEdgeSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int i3, boolean z) {
                FLA_WallpaperSettingsActivity.this.binding.edgeLightView.changeSize(i3);
                FLA_WallpaperSettingsActivity.this.edgeSize = i3;
                FLA_WallpaperSettingsActivity.this.binding.tvValueEdgeSize.setText(String.valueOf(FLA_WallpaperSettingsActivity.this.edgeSize));
            }
        });
        this.binding.seekbarEdgeSpeed.setMax(100);
        this.binding.seekbarEdgeSpeed.setProgress(this.edgeAnimSpeed);
        this.binding.tvValueEdgeSpeed.setText(String.valueOf(this.edgeAnimSpeed * 10));
        this.binding.seekbarEdgeSpeed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int i3, boolean z) {
                int i4 = i3 / 10;
                FLA_WallpaperSettingsActivity.this.binding.edgeLightView.changeSpeed(i4);
                FLA_WallpaperSettingsActivity.this.edgeAnimSpeed = i4;
                FLA_WallpaperSettingsActivity.this.binding.tvValueEdgeSpeed.setText(String.valueOf(i3));
            }
        });
        this.binding.seekbarEdgeRadius.setProgress(this.edgeRadius);
        this.binding.tvValueEdgeRadius.setText(String.valueOf(this.edgeRadius));
        this.binding.seekbarEdgeRadius.setMax(180);
        this.binding.seekbarEdgeRadius.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int i3, boolean z) {
                FLA_WallpaperSettingsActivity.this.binding.edgeLightView.changeBorder(i3, i3);
                FLA_WallpaperSettingsActivity.this.edgeRadius = i3;
                FLA_WallpaperSettingsActivity.this.binding.tvValueEdgeRadius.setText(String.valueOf(FLA_WallpaperSettingsActivity.this.edgeRadius));
            }
        });
        this.binding.lottieView.setVisibility(this.isFingerAnimActive ? View.VISIBLE : View.GONE);
        this.binding.llFingerprintOpt.setVisibility(this.isFingerAnimActive ? View.VISIBLE : View.GONE);
        this.binding.edgeLightView.setVisibility(this.isEdgeActive ? View.VISIBLE : View.GONE);
        this.binding.switchFingerprint.setChecked(this.isFingerAnimActive, false);
        this.binding.switchEdgeLight.setChecked(this.isEdgeActive, false);
        this.binding.switchFingerprint.setOnCheckedChangeListener(new Function1() {
            @Override
            public final Object invoke(Object obj) {
                return unit1((Boolean) obj);
            }
        });
        this.binding.switchEdgeLight.setOnCheckedChangeListener(new Function1() {
            @Override
            public final Object invoke(Object obj) {
                return unit((Boolean) obj);
            }
        });
        this.binding.rvGradients.setAdapter(new FLA_Adapter_Rv_ColorBg(this.activity, getGradientsList(this.activity), new FLA_OnRvItemClickListener() {
            @Override
            public final void onItemClicked(int i3) {
                binding.edgeLightView.changeColorType(i3);
                edgeColorType = i3;
            }
        }));
        final ArrayList<FLA_ShapesModel> shapesList = getShapesList();
        this.binding.rvShapes.setAdapter(new FLA_Adapter_Rv_Shapes(shapesList, new FLA_OnRvItemClickListener() {
            @Override
            public final void onItemClicked(int i3) {
                FLA_ShapesModel shapesModel = (FLA_ShapesModel) shapesList.get(i3);
                if (shapesModel != null) {
                    edgeShapeType = shapesModel.getType();
                    binding.edgeLightView.changeType(shapesModel.getType());
                }
            }
        }));
        if (this.binding.edgeLightView.getVisibility() == View.VISIBLE) {
            if (this.edgeAnimSpeed > 0) {
                this.binding.edgeLightView.changeSpeed(this.edgeAnimSpeed);
            }
            if (this.edgeRadius >= 0) {
                FLA_EdgeBorderLightView edgeBorderLightView = this.binding.edgeLightView;
                int i3 = this.edgeRadius;
                edgeBorderLightView.changeBorder(i3, i3);
            }
            if (this.edgeSize > 0) {
                this.binding.edgeLightView.changeSize(this.edgeSize);
            }
            if (this.edgeShapeType != null) {
                this.binding.edgeLightView.changeType(this.edgeShapeType);
            }
            this.binding.edgeLightView.changeColorType(this.edgeColorType);
        }
    }


    public Unit unit1(Boolean bool) {
        this.isFingerAnimActive = bool.booleanValue();
        if (bool.booleanValue()) {
            this.binding.tvEnableFinger.setTextColor(this.whiteColor);
        } else {
            this.binding.tvEnableFinger.setTextColor(this.disabledColor);
        }
        this.binding.llFingerprintOpt.setVisibility(bool.booleanValue() ? View.VISIBLE : View.GONE);
        this.binding.lottieView.setVisibility(bool.booleanValue() ? View.VISIBLE : View.GONE);
        return null;
    }


    public Unit unit(Boolean bool) {
        this.isEdgeActive = bool.booleanValue();
        if (bool.booleanValue()) {
            this.binding.tvEnableEdgeLight.setTextColor(this.whiteColor);
            if (this.binding.edgeLightView.getVisibility() == View.VISIBLE) {
                if (this.edgeSize > 0) {
                    this.binding.edgeLightView.changeSize(this.edgeSize);
                }
                if (this.binding.edgeLightView.isShown() && this.edgeAnimSpeed > 0) {
                    this.binding.edgeLightView.changeSpeed(this.edgeAnimSpeed);
                }
                if (this.edgeRadius >= 0) {
                    FLA_EdgeBorderLightView edgeBorderLightView = this.binding.edgeLightView;
                    int i = this.edgeRadius;
                    edgeBorderLightView.changeBorder(i, i);
                }
            }
        } else {
            this.binding.tvEnableEdgeLight.setTextColor(this.disabledColor);
        }
        this.binding.llEdgeLight.setVisibility(bool.booleanValue() ? View.VISIBLE : View.GONE);
        this.binding.edgeLightView.setVisibility(bool.booleanValue() ? View.VISIBLE : View.GONE);
        return null;
    }

    @Override
    public void onResume() {
        super.onResume();
        WallpaperInfo wallpaperInfo = this.wallpaperInfo;
        if (wallpaperInfo == null || !wallpaperInfo.getPackageName().equals(getPackageName())) {
            return;
        }
        this.binding.checkbox.setVisibility(View.VISIBLE);
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id != R.id.continueBtn) {
            if (id == R.id.mtbOption1) {
                this.binding.mtbOption1.setTextColor(this.enabledColor);
                this.binding.mtbOption2.setTextColor(this.disabledColor);
                if (this.binding.switchFingerprint.isChecked()) {
                    this.binding.llFingerprintOpt.setVisibility(View.VISIBLE);
                    this.binding.lottieView.setVisibility(View.VISIBLE);
                } else {
                    this.binding.llFingerprintOpt.setVisibility(View.GONE);
                    this.binding.lottieView.setVisibility(View.GONE);
                }
                this.binding.constraintSwitchEdgeLight.setVisibility(View.GONE);
                this.binding.constraintSwitchFinger.setVisibility(View.VISIBLE);
                this.binding.llEdgeLight.setVisibility(View.GONE);
            } else if (id == R.id.mtbOption2) {
                this.binding.mtbOption1.setTextColor(this.disabledColor);
                this.binding.mtbOption2.setTextColor(this.enabledColor);
                this.binding.llFingerprintOpt.setVisibility(View.GONE);
                if (this.binding.switchEdgeLight.isChecked()) {
                    this.binding.llEdgeLight.setVisibility(View.VISIBLE);
                } else {
                    this.binding.llEdgeLight.setVisibility(View.GONE);
                }
                this.binding.constraintSwitchEdgeLight.setVisibility(View.VISIBLE);
                this.binding.constraintSwitchFinger.setVisibility(View.GONE);
                this.binding.llFingerprintOpt.setVisibility(View.GONE);
            } else if (id == R.id.constraintSwitchFinger) {
                this.binding.switchFingerprint.setChecked(!this.binding.switchFingerprint.isChecked(), true);
            } else if (id == R.id.constraintSwitchEdgeLight) {
                this.binding.switchEdgeLight.setChecked(!this.binding.switchEdgeLight.isChecked(), true);
            }
        } else if (!this.isEdgeActive && !this.isFingerAnimActive) {
            if (this.imgBitmap != null) {
                try {
                    WallpaperManager.getInstance(getApplicationContext()).setBitmap(this.imgBitmap);
                    showToast("Wallpaper Successfully Applied");
                } catch (IOException e) {
                    showToast("Failed! " + e.getMessage());
                    throw new RuntimeException(e);
                }
            }
        } else {
//            getInstance(FLA_WallpaperSettingsActivity.this).ShowAd(new HandleClick() {
//                @Override
//                public void Show(boolean adShow) {
                    if (wallpaperInfo != null && wallpaperInfo.getPackageName().equals(getPackageName())) {
                        Log.d("WallpaperSettingAndPreview_0", "We're already running");
                        startActivity(new Intent(activity, FLA_WallpaperPreviewActivity.class).putExtra("bgImgPath", bgImgPath).putExtra("animPath", animPath).putExtra("scaleValue", sizeValue).putExtra("positionValue", positionValue).putExtra("speedValue", binding.lottieView.getAnimSpeed()).putExtra("edgeSize", edgeSize).putExtra("edgeRadius", edgeRadius).putExtra("edgeAnimSpeed", edgeAnimSpeed).putExtra("isEdgeActive", isEdgeActive).putExtra("edgeShapeType", edgeShapeType).putExtra("edgeColorType", edgeColorType));
                        return;
                    }
                    spm.setIntValue("scaleValue", sizeValue);
                    spm.setFloatValue("positionValue", positionValue);
                    spm.setFloatValue("speedValue", binding.lottieView.getAnimSpeed());
                    spm.setValue("bgImg", bgImgPath);
                    spm.setValue("animPath", animPath);
                    spm.setBooleanValue("isPreviewOnly", true);
                    spm.setIntValue("edgeSize", edgeSize);
                    spm.setIntValue("edgeRadius", edgeRadius);
                    spm.setIntValue("edgeAnimSpeed", edgeAnimSpeed);
                    spm.setValue("edgeShapeType", edgeShapeType);
                    spm.setIntValue("edgeColorType", edgeColorType);
                    spm.setBooleanValue("isEdgeActive", isEdgeActive);
                    spm.setBooleanValue("isFingerAnimActive", isFingerAnimActive);
                    FLA_WallpaperService.isSettingsUpdated = true;
                    FLA_WallpaperService.setToWallPaper(FLA_WallpaperSettingsActivity.this);
                    finish();
//                }
//            }, MAIN_CLICK);

        }
    }

}
