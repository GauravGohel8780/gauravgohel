package com.fingerprint.lock.liveanimation.FLA_Utils.FLA_Services;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;

import androidx.recyclerview.widget.ItemTouchHelper;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieCompositionFactory;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieListener;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;


public class FLA_LottieView extends View {
    float animSpeed;
    LottieAnimationView animationView;
    private String filePath;
    boolean isFromActivity;
    int mHeight;
    private LottieDrawable mLottieDrawable;
    int mWidth;
    float positionY;
    int size;

    public float getAnimSpeed() {
        return this.animSpeed;
    }


    public int getSize() {
        return this.size;
    }


    public void setFromActivity(boolean z) {
        this.isFromActivity = z;
    }

    public void setHeight(int i) {
        this.mHeight = i;
    }

    public FLA_LottieView(Context context) {
        super(context);
        this.size = ItemTouchHelper.Callback.DEFAULT_SWIPE_ANIMATION_DURATION;
        this.positionY = 1.5f;
        this.animSpeed = 1.0f;
        init();
    }

    public void setPositionY(float f) {
        this.positionY = f;
        invalidate();
    }

    public void setWidth(int i) {
        this.mWidth = i;
        invalidate();
    }

    public void setAnimSpeed(float f) {
        this.animSpeed = f;
        LottieDrawable lottieDrawable = this.mLottieDrawable;
        if (lottieDrawable != null && f >= 0.1f) {
            lottieDrawable.setSpeed(f);
        }
        invalidate();
    }


    public void setSize(int i) {
        this.size = i;
        if (this.isFromActivity) {
            this.size = (int) (i * 0.6d);
        }
        invalidate();
    }

    public void setFilePath(String str) {
        this.filePath = str;
        init();
        invalidate();
    }

    public FLA_LottieView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.size = ItemTouchHelper.Callback.DEFAULT_SWIPE_ANIMATION_DURATION;
        this.positionY = 1.5f;
        this.animSpeed = 1.0f;
        init();
    }

    public FLA_LottieView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.size = ItemTouchHelper.Callback.DEFAULT_SWIPE_ANIMATION_DURATION;
        this.positionY = 1.5f;
        this.animSpeed = 1.0f;
        init();
    }

    private void init() {
        this.mLottieDrawable = new LottieDrawable();
        this.animationView = new LottieAnimationView(getContext());
        if (this.filePath != null) {
            File file = new File(this.filePath);
            try {
                if (file.exists()) {
                    LottieCompositionFactory.fromJsonInputStream(new BufferedInputStream(new FileInputStream(file)), null).addListener(new LottieListener() {
                        @Override // com.airbnb.lottie.LottieListener
                        public final void onResult(Object obj) {
                            mLottieDrawable.setComposition((LottieComposition) obj);
                        }
                    });
                    this.mLottieDrawable.enableMergePathsForKitKatAndAbove(true);
                    this.mLottieDrawable.setCallback(this);
                    this.mLottieDrawable.setRepeatCount(-1);
                    this.mLottieDrawable.setSpeed(this.animSpeed);
                    this.mLottieDrawable.addAnimatorUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                        @Override
                        public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                            invalidate();
                        }
                    });
                    this.mLottieDrawable.playAnimation();
                    this.mLottieDrawable.start();
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    public int getScreenWidth() {
        if (this.isFromActivity) {
            return getWidth();
        }
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    public int getScreenHeight() {
        if (this.isFromActivity) {
            return getHeight();
        }
        return Resources.getSystem().getDisplayMetrics().heightPixels;
    }

    @Override 
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        LottieDrawable lottieDrawable = this.mLottieDrawable;
        if (lottieDrawable == null || lottieDrawable.getComposition() == null) {
            return;
        }
        LottieDrawable lottieDrawable2 = this.mLottieDrawable;
        int i = this.size;
        lottieDrawable2.setBounds(0, 0, i, i);
        canvas.translate((getScreenWidth() / 2) - (this.size / 2.0f), (getScreenHeight() / 2.0f) * this.positionY);
        this.mLottieDrawable.draw(canvas);
    }
}
