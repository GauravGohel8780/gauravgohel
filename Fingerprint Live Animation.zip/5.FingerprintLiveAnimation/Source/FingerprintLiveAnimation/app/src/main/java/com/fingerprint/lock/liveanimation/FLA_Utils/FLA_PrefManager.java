package com.fingerprint.lock.liveanimation.FLA_Utils;

import android.content.Context;
import android.content.SharedPreferences;


public class FLA_PrefManager {
    private static final String APP_VERSION_KEY = "APP_VERSION";
    private static final String IS_FIRST_TIME_LAUNCH = "IsFirstTimeLaunch";
    private static final String PREF_NAME = "my-intro-slider";
    Context context;
    SharedPreferences.Editor editor;
    SharedPreferences sharedPreferences;

    public FLA_PrefManager(Context context) {
        this.context = context;
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, 0);
        this.sharedPreferences = sharedPreferences;
        this.editor = sharedPreferences.edit();
    }

    public void setFirstTimeLaunch(boolean z) {
        this.editor.putBoolean(IS_FIRST_TIME_LAUNCH, z);
        this.editor.commit();
    }

    public boolean isFirstTimeLaunch() {
        return this.sharedPreferences.getBoolean(IS_FIRST_TIME_LAUNCH, true);
    }

    public void setCurrentAppVersion(int i) {
        this.editor.putInt(APP_VERSION_KEY, i);
        this.editor.commit();
    }

    public int getCurrentAppVersion() {
        return this.sharedPreferences.getInt(APP_VERSION_KEY, 0);
    }
}
