package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_CarouselView;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.ViewGroup;

import androidx.viewpager2.widget.ViewPager2;

import com.fingerprint.lock.liveanimation.FLA_Adapters.FLA_Adapter_ViewPager3;
import com.fingerprint.lock.liveanimation.R;


public class FLA_CarouselView extends ViewGroup {
    private static final float DEFAULT_SCALE_FACTOR = 0.15f;
    private static final float MAX_SCALE_FACTOR = 0.4f;
    private static final float MIN_SCALE_FACTOR = 0.1f;
    FLA_Adapter_ViewPager3 adapter;
    private final Rect childRect;
    private final Rect containerRect;
    private int currentPosition;
    private boolean initialPositionChanged;
    private int itemMargin;
    private Mode mode;
    private ViewPager2.OnPageChangeCallback onPageChangeCallback;
    private int previewOffset;
    private float previewScaleFactor;
    private PreviewSide previewSide;
    private PreviewSideBySideStyle sideBySideStyle;
    private ViewPager2 viewPager2;

    
    public enum Mode {
        SNAP,
        PREVIEW
    }

    
    public enum PreviewSide {
        SIDE_BY_SIDE,
        RIGHT
    }

    
    public enum PreviewSideBySideStyle {
        NORMAL,
        SCALE
    }


    public Mode getMode() {
        return this.mode;
    }



    public FLA_CarouselView(Context context) {
        super(context);
        this.mode = Mode.SNAP;
        this.previewSide = PreviewSide.SIDE_BY_SIDE;
        this.sideBySideStyle = PreviewSideBySideStyle.SCALE;
        this.previewScaleFactor = DEFAULT_SCALE_FACTOR;
        this.initialPositionChanged = false;
        this.containerRect = new Rect();
        this.childRect = new Rect();
        removeAllViews();
        setupViewPager();
        ViewPager2 viewPager2 = this.viewPager2;
        attachViewToParent(viewPager2, 0, viewPager2.getLayoutParams());
    }

    public FLA_CarouselView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mode = Mode.SNAP;
        this.previewSide = PreviewSide.SIDE_BY_SIDE;
        this.sideBySideStyle = PreviewSideBySideStyle.SCALE;
        this.previewScaleFactor = DEFAULT_SCALE_FACTOR;
        this.initialPositionChanged = false;
        this.containerRect = new Rect();
        this.childRect = new Rect();
        initialize(context, attributeSet);
    }

    private void initialize(Context context, AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(attributeSet, R.styleable.CarouselView, 0, 0);
        try {
            this.mode = Mode.values()[obtainStyledAttributes.getInt(R.styleable.CarouselView_carouselMode, 0)];
            this.previewSide = PreviewSide.values()[obtainStyledAttributes.getInt(R.styleable.CarouselView_carouselPreviewSide, 0)];
            this.sideBySideStyle = PreviewSideBySideStyle.values()[obtainStyledAttributes.getInt(R.styleable.CarouselView_carouselPreviewSideBySideStyle, 0)];
            this.previewScaleFactor = obtainStyledAttributes.getFloat(R.styleable.CarouselView_carouselPreviewScaleFactor, DEFAULT_SCALE_FACTOR);
            this.previewOffset = obtainStyledAttributes.getDimensionPixelSize(R.styleable.CarouselView_carouselPreviewOffset, 0);
            this.itemMargin = obtainStyledAttributes.getDimensionPixelSize(R.styleable.CarouselView_carouselMargin, 0);
            obtainStyledAttributes.recycle();
            float f = this.previewScaleFactor;
            if (f < 0.1f) {
                this.previewScaleFactor = 0.1f;
            } else if (f > MAX_SCALE_FACTOR) {
                this.previewScaleFactor = MAX_SCALE_FACTOR;
            }
            removeAllViews();
            setupViewPager();
            ViewPager2 viewPager2 = this.viewPager2;
            attachViewToParent(viewPager2, 0, viewPager2.getLayoutParams());
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    @Override
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int measuredWidth = this.viewPager2.getMeasuredWidth();
        int measuredHeight = this.viewPager2.getMeasuredHeight();
        this.containerRect.left = getPaddingLeft();
        this.containerRect.right = (i3 - i) - getPaddingRight();
        this.containerRect.top = getPaddingTop();
        this.containerRect.bottom = (i4 - i2) - getPaddingBottom();
        Gravity.apply(8388659, measuredWidth, measuredHeight, this.containerRect, this.childRect);
        this.viewPager2.layout(this.childRect.left, this.childRect.top, this.childRect.right, this.childRect.bottom);
    }

    @Override 
    protected void onMeasure(int i, int i2) {
        measureChild(this.viewPager2, i, i2);
        int measuredWidth = this.viewPager2.getMeasuredWidth();
        int measuredHeight = this.viewPager2.getMeasuredHeight();
        int scrollState = this.viewPager2.getScrollState();
        int paddingLeft = measuredWidth + getPaddingLeft() + getPaddingRight();
        int paddingTop = measuredHeight + getPaddingTop() + getPaddingBottom();
        setMeasuredDimension(resolveSizeAndState(Math.max(paddingLeft, getSuggestedMinimumWidth()), i, scrollState), resolveSizeAndState(Math.max(paddingTop, getSuggestedMinimumHeight()), i2, scrollState << 16));
    }

    private void setupViewPager() {
        if (this.viewPager2 == null) {
            this.viewPager2 = new ViewPager2(getContext());
        }
        this.viewPager2.setLayoutParams(new LayoutParams(-1, -1));
        this.viewPager2.setOffscreenPageLimit(3);
        if (this.onPageChangeCallback == null) {
            this.onPageChangeCallback = new ViewPager2.OnPageChangeCallback() { // from class: com.fingerprint.lock.liveanimation.CustomViews.CarouselView.CarouselView.1
                @Override // androidx.viewpager2.widget.ViewPager2.OnPageChangeCallback
                public void onPageScrollStateChanged(int i) {
                    if (i == 2) {
                        if (FLA_CarouselView.this.adapter == null || FLA_CarouselView.this.adapter.getItemCount() <= 0) {
                            FLA_CarouselView.this.currentPosition = 0;
                            return;
                        }
                        FLA_CarouselView carouselView = FLA_CarouselView.this;
                        carouselView.currentPosition = carouselView.viewPager2.getCurrentItem();
                    }
                }
            };
        }
        this.viewPager2.unregisterOnPageChangeCallback(this.onPageChangeCallback);
        this.viewPager2.registerOnPageChangeCallback(this.onPageChangeCallback);
        ViewPager2.PageTransformer pageTransformer = null;
        this.viewPager2.setPageTransformer(null);
        if (this.mode == Mode.PREVIEW) {
            if (this.previewSide == PreviewSide.RIGHT) {
                FLA_PreviewTransformer.RightSideTransformer rightSideTransformer = new FLA_PreviewTransformer.RightSideTransformer(this.itemMargin, this.previewOffset, this.viewPager2);
                ViewPager2 viewPager2 = this.viewPager2;
                int i = this.itemMargin;
                viewPager2.addItemDecoration(new FLA_MarginDecoration(i, this.previewOffset + i));
                this.viewPager2.setPageTransformer(rightSideTransformer);
                return;
            }
            int i2 = AnonymousClass2.i1[this.sideBySideStyle.ordinal()];
            if (i2 == 1) {
                pageTransformer = new FLA_PreviewTransformer.SideBySideTransformer(this.itemMargin, this.previewOffset, this.viewPager2);
            } else if (i2 == 2) {
                pageTransformer = new FLA_PreviewTransformer.ScaleTransformer(this.previewScaleFactor, this.itemMargin, this.previewOffset, this.viewPager2);
            }
            ViewPager2 viewPager22 = this.viewPager2;
            int i3 = this.itemMargin;
            int i4 = this.previewOffset;
            viewPager22.addItemDecoration(new FLA_MarginDecoration(i3 + i4, i3 + i4));
            this.viewPager2.setPageTransformer(pageTransformer);
            return;
        }
        this.previewSide = PreviewSide.RIGHT;
        this.sideBySideStyle = PreviewSideBySideStyle.NORMAL;
    }


    
    public static  class AnonymousClass2 {
        static final  int[] i1;

        static {
            int[] iArr = new int[PreviewSideBySideStyle.values().length];
            i1 = iArr;
            try {
                iArr[PreviewSideBySideStyle.NORMAL.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                i1[PreviewSideBySideStyle.SCALE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }


    public void setMode(Mode mode) {
        this.mode = mode;
        setupViewPager();
    }
}
