package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_BLurKit;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.Choreographer;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.fingerprint.lock.liveanimation.R;

import java.lang.ref.WeakReference;


public class FLA_BlurLayout extends FrameLayout {
    private Choreographer.FrameCallback invalidationLoop;
    private WeakReference<View> mActivityView;
    private float mAlpha;
    private boolean mAttachedToWindow;
    private int mBlurRadius;
    private float mCornerRadius;
    private float mDownscaleFactor;
    private int mFPS;
    private FLA_RoundedImageView mImageView;
    private Bitmap mLockedBitmap;
    private Point mLockedPoint;
    private boolean mPositionLocked;
    private boolean mRunning;
    private boolean mViewLocked;

    @Override
    public float getAlpha() {
        return this.mAlpha;
    }


    public FLA_BlurLayout(Context context) {
        super(context, null);
        this.invalidationLoop = new Choreographer.FrameCallback() { // from class: com.fingerprint.lock.liveanimation.CustomViews.BLurKit.BlurLayout.1
            @Override // android.view.Choreographer.FrameCallback
            public void doFrame(long j) {
                FLA_BlurLayout.this.invalidate();
                Choreographer.getInstance().postFrameCallbackDelayed(this, 1000 / FLA_BlurLayout.this.mFPS);
            }
        };
    }

    public FLA_BlurLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.invalidationLoop = new Choreographer.FrameCallback() { // from class: com.fingerprint.lock.liveanimation.CustomViews.BLurKit.BlurLayout.1
            @Override // android.view.Choreographer.FrameCallback
            public void doFrame(long j) {
                FLA_BlurLayout.this.invalidate();
                Choreographer.getInstance().postFrameCallbackDelayed(this, 1000 / FLA_BlurLayout.this.mFPS);
            }
        };
        if (!isInEditMode()) {
            FLA_BlurKit.init(context);
        }


        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(attributeSet, R.styleable.BlurLayout, 0, 0);
        try {
            this.mDownscaleFactor = obtainStyledAttributes.getFloat(R.styleable.BlurLayout_blk_downscaleFactor, 0.12f);
            this.mBlurRadius = obtainStyledAttributes.getInteger(R.styleable.BlurLayout_blk_blurRadius, 12);
            this.mFPS = obtainStyledAttributes.getInteger(R.styleable.BlurLayout_blk_fps, 60);
            this.mCornerRadius = obtainStyledAttributes.getDimension(R.styleable.BlurLayout_blk_cornerRadius, 0.0f);
            this.mAlpha = obtainStyledAttributes.getDimension(R.styleable.BlurLayout_blk_alpha, 1.0f);
            obtainStyledAttributes.recycle();
            FLA_RoundedImageView roundedImageView = new FLA_RoundedImageView(getContext());
            this.mImageView = roundedImageView;
            roundedImageView.setScaleType(ImageView.ScaleType.FIT_XY);
            addView(this.mImageView);
            setCornerRadius(this.mCornerRadius);
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    public void startBlur() {
        if (!this.mRunning && this.mFPS > 0) {
            this.mRunning = true;
            Choreographer.getInstance().postFrameCallback(this.invalidationLoop);
        }
    }

    public void pauseBlur() {
        if (this.mRunning) {
            this.mRunning = false;
            Choreographer.getInstance().removeFrameCallback(this.invalidationLoop);
        }
    }

    @Override 
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.mAttachedToWindow = true;
        startBlur();
    }

    @Override 
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.mAttachedToWindow = false;
        pauseBlur();
    }

    @Override 
    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        invalidate();
    }

    @Override 
    public void invalidate() {
        super.invalidate();
        Bitmap blur = blur();
        if (blur != null) {
            this.mImageView.setImageBitmap(blur);
        }
    }

    Bitmap downscaledBitmapForView;
    private Bitmap blur() {
        Point positionInScreen;
        if (getContext() != null && !isInEditMode()) {
            WeakReference<View> weakReference = this.mActivityView;
            if (weakReference == null || weakReference.get() == null) {
                WeakReference<View> weakReference2 = new WeakReference<>(getActivityView());
                this.mActivityView = weakReference2;
                if (weakReference2.get() == null) {
                    return null;
                }
            }
            if (this.mPositionLocked) {
                if (this.mLockedPoint == null) {
                    this.mLockedPoint = getPositionInScreen();
                }
                positionInScreen = this.mLockedPoint;
            } else {
                positionInScreen = getPositionInScreen();
            }
            super.setAlpha(0.0f);
            int width = this.mActivityView.get().getWidth();
            int height = this.mActivityView.get().getHeight();
            int width2 = (int) (getWidth() * this.mDownscaleFactor);
            int height2 = (int) (getHeight() * this.mDownscaleFactor);
            int i = (int) (positionInScreen.x * this.mDownscaleFactor);
            int i2 = (int) (positionInScreen.y * this.mDownscaleFactor);
            int width3 = getWidth() / 8;
            int height3 = getHeight() / 8;
            int i3 = -width3;
            if (i + i3 < 0) {
                i3 = 0;
            }
            if ((i + width) - width3 > width) {
                width3 = (width + width) - i;
            }
            int i4 = -height3;
            if (i2 + i4 < 0) {
                i4 = 0;
            }
            if (getHeight() + i2 + height3 > height) {
                height3 = 0;
            }
            if (this.mViewLocked) {
                if (this.mLockedBitmap == null) {
                    lockView();
                }
                if (width2 == 0 || height2 == 0) {
                    return null;
                }
                downscaledBitmapForView = Bitmap.createBitmap(this.mLockedBitmap, i, i2, width2, height2);
            } else {
                try {
                    downscaledBitmapForView = getDownscaledBitmapForView(this.mActivityView.get(), new Rect(positionInScreen.x + i3, positionInScreen.y + i4, positionInScreen.x + getWidth() + Math.abs(i3) + width3, positionInScreen.y + getHeight() + Math.abs(i4) + height3), this.mDownscaleFactor);
                } catch (FLA_BlurKitException | NullPointerException unused) {
                }
            }
            if (!this.mViewLocked) {
                downscaledBitmapForView = Bitmap.createBitmap(FLA_BlurKit.getInstance().blur(downscaledBitmapForView, this.mBlurRadius), (int) (Math.abs(i3) * this.mDownscaleFactor), (int) (Math.abs(i4) * this.mDownscaleFactor), width2, height2);
            }
            if (Float.isNaN(this.mAlpha)) {
                super.setAlpha(1.0f);
            } else {
                super.setAlpha(this.mAlpha);
            }
            return downscaledBitmapForView;
        }
        return null;
    }

    private View getActivityView() {
        try {
            return ((Activity) getContext()).getWindow().getDecorView().findViewById(16908290);
        } catch (ClassCastException unused) {
            return null;
        }
    }

    private Point getPositionInScreen() {
        PointF positionInScreen = getPositionInScreen(this);
        return new Point((int) positionInScreen.x, (int) positionInScreen.y);
    }

    private PointF getPositionInScreen(View view) {
        if (getParent() == null) {
            return new PointF();
        }
        try {
            ViewGroup viewGroup = (ViewGroup) view.getParent();
            if (viewGroup == null) {
                return new PointF();
            }
            PointF positionInScreen = getPositionInScreen(viewGroup);
            positionInScreen.offset(view.getX(), view.getY());
            return positionInScreen;
        } catch (Exception unused) {
            return new PointF();
        }
    }

    private Bitmap getDownscaledBitmapForView(View view, Rect rect, float f) throws FLA_BlurKitException, NullPointerException {
        View rootView = view.getRootView();
        int width = (int) (rect.width() * f);
        int height = (int) (rect.height() * f);
        if (rootView.getWidth() <= 0 || rootView.getHeight() <= 0 || width <= 0 || height <= 0) {
            throw new FLA_BlurKitException("No screen available (width or height = 0)");
        }
        Bitmap createBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        Matrix matrix = new Matrix();
        matrix.preScale(f, f);
        matrix.postTranslate((-rect.left) * f, (-rect.top) * f);
        canvas.setMatrix(matrix);
        rootView.draw(canvas);
        return createBitmap;
    }


    public void setCornerRadius(float f) {
        this.mCornerRadius = f;
        FLA_RoundedImageView roundedImageView = this.mImageView;
        if (roundedImageView != null) {
            roundedImageView.setCornerRadius(f);
        }
        invalidate();
    }

    @Override 
    public void setAlpha(float f) {
        this.mAlpha = f;
        if (this.mViewLocked) {
            return;
        }
        super.setAlpha(f);
    }

    public void lockView() {
        this.mViewLocked = true;
        WeakReference<View> weakReference = this.mActivityView;
        if (weakReference == null || weakReference.get() == null) {
            return;
        }
        View rootView = this.mActivityView.get().getRootView();
        try {
            super.setAlpha(0.0f);
            this.mLockedBitmap = getDownscaledBitmapForView(rootView, new Rect(0, 0, rootView.getWidth(), rootView.getHeight()), this.mDownscaleFactor);
            if (Float.isNaN(this.mAlpha)) {
                super.setAlpha(1.0f);
            } else {
                super.setAlpha(this.mAlpha);
            }
            this.mLockedBitmap = FLA_BlurKit.getInstance().blur(this.mLockedBitmap, this.mBlurRadius);
        } catch (Exception unused) {
        }
    }
}
