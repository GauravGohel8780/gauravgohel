package com.fingerprint.lock.liveanimation.FLA_Adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;

import com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_CustomImageView;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_OnRvItemClickListener;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_SelectColorModel;
import com.fingerprint.lock.liveanimation.R;

import java.util.List;


public class FLA_Adapter_Rv_ColorBg extends RecyclerView.Adapter<FLA_Adapter_Rv_ColorBg.ViewHolder> {
    private final Activity activity;
    private final List<FLA_SelectColorModel> colorModelList;
    private final FLA_OnRvItemClickListener onRvItemClickListener;

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override 
    public int getItemViewType(int i) {
        return i;
    }

    public FLA_Adapter_Rv_ColorBg(Activity activity, List<FLA_SelectColorModel> list, FLA_OnRvItemClickListener onRvItemClickListener) {
        this.activity = activity;
        this.colorModelList = list;
        this.onRvItemClickListener = onRvItemClickListener;
    }

    @Override 
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.rv_row_gradients, viewGroup, false));
    }

    @Override 
    public void onBindViewHolder(final ViewHolder viewHolder, int i) {
        FLA_SelectColorModel selectColorModel = this.colorModelList.get(i);
        if (selectColorModel != null) {
            viewHolder.iv_icon.setImageResource(selectColorModel.getColor());
            viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public final void onClick(View view) {
                    onRvItemClickListener.onItemClicked(viewHolder.getAdapterPosition());
                }
            });
        }
    }

    @Override 
    public int getItemCount() {
        return this.colorModelList.size();
    }

    
    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView iv_icon;

        public ViewHolder(View view) {
            super(view);
            ImageView imageView = (ImageView) view.findViewById(R.id.ivIcon);
            this.iv_icon = imageView;
            ((FLA_CustomImageView) imageView).setCircle(true);
        }
    }
}
