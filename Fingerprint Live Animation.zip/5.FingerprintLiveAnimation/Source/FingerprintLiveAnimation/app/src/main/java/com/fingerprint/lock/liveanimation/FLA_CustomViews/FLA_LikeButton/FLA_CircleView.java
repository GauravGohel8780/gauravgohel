package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_LikeButton;

import android.animation.ArgbEvaluator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.util.AttributeSet;
import android.util.Property;
import android.view.View;

import androidx.core.view.ViewCompat;


public class FLA_CircleView extends View {
    public static final Property<FLA_CircleView, Float> INNER_CIRCLE_RADIUS_PROGRESS = new Property<FLA_CircleView, Float>(Float.class, "innerCircleRadiusProgress") {
        @Override
        public Float get(FLA_CircleView circleView) {
            return Float.valueOf(circleView.getInnerCircleRadiusProgress());
        }

        @Override
        public void set(FLA_CircleView circleView, Float f) {
            circleView.setInnerCircleRadiusProgress(f.floatValue());
        }
    };
    public static final Property<FLA_CircleView, Float> OUTER_CIRCLE_RADIUS_PROGRESS = new Property<FLA_CircleView, Float>(Float.class, "outerCircleRadiusProgress") {
        @Override
        public Float get(FLA_CircleView circleView) {
            return Float.valueOf(circleView.getOuterCircleRadiusProgress());
        }

        @Override
        public void set(FLA_CircleView circleView, Float f) {
            circleView.setOuterCircleRadiusProgress(f.floatValue());
        }
    };
    private int END_COLOR;
    private int START_COLOR;
    private ArgbEvaluator argbEvaluator;
    private Paint circlePaint;
    private int height;
    private float innerCircleRadiusProgress;
    private Paint maskPaint;
    private int maxCircleSize;
    private float outerCircleRadiusProgress;
    private Bitmap tempBitmap;
    private Canvas tempCanvas;
    private int width;

    public float getInnerCircleRadiusProgress() {
        return this.innerCircleRadiusProgress;
    }

    public float getOuterCircleRadiusProgress() {
        return this.outerCircleRadiusProgress;
    }

    public FLA_CircleView(Context context) {
        super(context);
        this.START_COLOR = -43230;
        this.END_COLOR = -16121;
        this.argbEvaluator = new ArgbEvaluator();
        this.circlePaint = new Paint();
        this.maskPaint = new Paint();
        this.outerCircleRadiusProgress = 0.0f;
        this.innerCircleRadiusProgress = 0.0f;
        this.width = 0;
        this.height = 0;
        init();
    }

    public FLA_CircleView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.START_COLOR = -43230;
        this.END_COLOR = -16121;
        this.argbEvaluator = new ArgbEvaluator();
        this.circlePaint = new Paint();
        this.maskPaint = new Paint();
        this.outerCircleRadiusProgress = 0.0f;
        this.innerCircleRadiusProgress = 0.0f;
        this.width = 0;
        this.height = 0;
        init();
    }

    public FLA_CircleView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.START_COLOR = -43230;
        this.END_COLOR = -16121;
        this.argbEvaluator = new ArgbEvaluator();
        this.circlePaint = new Paint();
        this.maskPaint = new Paint();
        this.outerCircleRadiusProgress = 0.0f;
        this.innerCircleRadiusProgress = 0.0f;
        this.width = 0;
        this.height = 0;
        init();
    }

    private void init() {
        this.circlePaint.setStyle(Paint.Style.FILL);
        this.circlePaint.setAntiAlias(true);
        this.maskPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        this.maskPaint.setAntiAlias(true);
    }

    public void setSize(int i, int i2) {
        this.width = i;
        this.height = i2;
        invalidate();
    }

    @Override 
    protected void onMeasure(int i, int i2) {
        int i3;
        super.onMeasure(i, i2);
        int i4 = this.width;
        if (i4 == 0 || (i3 = this.height) == 0) {
            return;
        }
        setMeasuredDimension(i4, i3);
    }

    @Override 
    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        this.maxCircleSize = i / 2;
        this.tempBitmap = Bitmap.createBitmap(getWidth(), getWidth(), Bitmap.Config.ARGB_8888);
        this.tempCanvas = new Canvas(this.tempBitmap);
    }

    @Override 
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.tempCanvas.drawColor(ViewCompat.MEASURED_SIZE_MASK, PorterDuff.Mode.CLEAR);
        this.tempCanvas.drawCircle(getWidth() / 2.0f, getHeight() / 2.0f, this.outerCircleRadiusProgress * this.maxCircleSize, this.circlePaint);
        this.tempCanvas.drawCircle(getWidth() / 2.0f, getHeight() / 2.0f, (this.innerCircleRadiusProgress * this.maxCircleSize) + 1.0f, this.maskPaint);
        canvas.drawBitmap(this.tempBitmap, 0.0f, 0.0f, (Paint) null);
    }

    public void setInnerCircleRadiusProgress(float f) {
        this.innerCircleRadiusProgress = f;
        postInvalidate();
    }

    public void setOuterCircleRadiusProgress(float f) {
        this.outerCircleRadiusProgress = f;
        updateCircleColor();
        postInvalidate();
    }

    private void updateCircleColor() {
        this.circlePaint.setColor(((Integer) this.argbEvaluator.evaluate((float) FLA_Utils.mapValueFromRangeToRange((float) FLA_Utils.clamp(this.outerCircleRadiusProgress, 0.5d, 1.0d), 0.5d, 1.0d, 0.0d, 1.0d), Integer.valueOf(this.START_COLOR), Integer.valueOf(this.END_COLOR))).intValue());
    }

    public void setStartColor(int i) {
        this.START_COLOR = i;
        invalidate();
    }

    public void setEndColor(int i) {
        this.END_COLOR = i;
        invalidate();
    }
}
