package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_LikeButton;


public interface FLA_OnAnimationEndListener {
    void onAnimationEnd(FLA_LikeButton likeButton);
}
