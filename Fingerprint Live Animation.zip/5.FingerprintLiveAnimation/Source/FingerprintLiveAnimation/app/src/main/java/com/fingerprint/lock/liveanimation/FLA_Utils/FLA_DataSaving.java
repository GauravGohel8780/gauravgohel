package com.fingerprint.lock.liveanimation.FLA_Utils;

import android.content.Context;
import android.content.SharedPreferences;


public class FLA_DataSaving {
    private String PREF_NAME = "mpPref";
    int PRIVATE_MODE = 0;
    Context _context;
    SharedPreferences.Editor editor;
    SharedPreferences pref;

    public int getIntPrefValue(Context context, String str) {
        this._context = context;
        SharedPreferences sharedPreferences = context.getSharedPreferences(this.PREF_NAME, this.PRIVATE_MODE);
        this.pref = sharedPreferences;
        return sharedPreferences.getInt(str, 0);
    }

    public boolean setIntPrefValue(Context context, String str, int i) {
        this._context = context;
        SharedPreferences sharedPreferences = context.getSharedPreferences(this.PREF_NAME, this.PRIVATE_MODE);
        this.pref = sharedPreferences;
        SharedPreferences.Editor edit = sharedPreferences.edit();
        this.editor = edit;
        edit.putInt(str, i);
        return this.editor.commit();
    }
}
