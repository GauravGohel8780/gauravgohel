package com.fingerprint.lock.liveanimation.FLA_Activities;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.MyApplication.sharedPreferencesHelper;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.fingerprint.lock.liveanimation.Ads_Common.AdsBaseActivity;
import com.fingerprint.lock.liveanimation.R;
import com.fingerprint.lock.liveanimation.databinding.ActivityPrivacyPolicyBinding;
import com.google.gson.Gson;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.networking.AdsResponse;
import com.iten.tenoku.utils.AdUtils;
import com.zackratos.ultimatebarx.ultimatebarx.java.UltimateBarX;

public class FLA_PrivacyPolicyActivity extends AdsBaseActivity {

    ActivityPrivacyPolicyBinding binding;
    AdsResponse appSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityPrivacyPolicyBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        UltimateBarX.statusBar(this).transparent().colorRes(R.color.transparent).light(false).apply();


        binding.ivBack.setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });

        appSettings = new Gson().fromJson(sharedPreferencesHelper.getResponse(), AdsResponse.class);
        binding.webView.loadUrl(appSettings.data.getObjAPPSETTINGS().getVPrivacyPolicy());
        binding.webView.getSettings().setJavaScriptEnabled(true);
        binding.webView.setWebViewClient(new WebViewClient());
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}