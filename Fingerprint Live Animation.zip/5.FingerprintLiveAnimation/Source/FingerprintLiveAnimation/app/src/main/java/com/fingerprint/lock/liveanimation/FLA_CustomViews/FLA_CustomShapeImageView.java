package com.fingerprint.lock.liveanimation.FLA_CustomViews;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.view.ViewCompat;

import com.fingerprint.lock.liveanimation.R;


public class FLA_CustomShapeImageView extends AppCompatImageView {
    private Paint mBlackPaint;
    private Rect mBounds;
    private RectF mBoundsF;
    private Bitmap mCacheBitmap;
    private boolean mCacheValid;
    private int mCachedHeight;
    private int mCachedWidth;
    private int mImageShape;
    private Drawable mMaskDrawable;
    private Paint mMaskedPaint;

    public FLA_CustomShapeImageView(Context context) {
        this(context, null);
    }

    
    public FLA_CustomShapeImageView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mCacheValid = false;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R.styleable.ShapesImage);
        int integer = obtainStyledAttributes.getInteger(R.styleable.ShapesImage_shape, 0);
        this.mImageShape = integer;
        if (integer == 0) {
            Drawable drawable = obtainStyledAttributes.getDrawable(R.styleable.ShapesImage_shapeDrawable);
            this.mMaskDrawable = drawable;
            if (drawable != null) {
                drawable.setCallback(this);
            }
        }
        obtainStyledAttributes.recycle();
        setUpPaints();
    }

    private void setUpPaints() {
        Paint paint = new Paint();
        this.mBlackPaint = paint;
        paint.setColor(-16777216);
        Paint paint2 = new Paint();
        this.mMaskedPaint = paint2;
        paint2.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        this.mCacheBitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
    }

    @Override // android.widget.ImageView
    protected boolean setFrame(int i, int i2, int i3, int i4) {
        boolean frame = super.setFrame(i, i2, i3, i4);
        this.mBounds = new Rect(0, 0, i3 - i, i4 - i2);
        this.mBoundsF = new RectF(this.mBounds);
        Drawable drawable = this.mMaskDrawable;
        if (drawable != null) {
            drawable.setBounds(this.mBounds);
        }
        if (frame) {
            this.mCacheValid = false;
        }
        return frame;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Rect rect = this.mBounds;
        if (rect == null) {
            return;
        }
        int width = rect.width();
        int height = this.mBounds.height();
        if (width == 0 || height == 0) {
            return;
        }
        if (!this.mCacheValid || width != this.mCachedWidth || height != this.mCachedHeight) {
            if (width == this.mCachedWidth && height == this.mCachedHeight) {
                this.mCacheBitmap.eraseColor(0);
            } else {
                this.mCacheBitmap.recycle();
                this.mCacheBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                this.mCachedWidth = width;
                this.mCachedHeight = height;
            }
            Canvas canvas2 = new Canvas(this.mCacheBitmap);
            if (this.mMaskDrawable != null) {
                int save = canvas2.save();
                this.mMaskDrawable.draw(canvas2);
                canvas2.saveLayer(this.mBoundsF, this.mMaskedPaint, Canvas.ALL_SAVE_FLAG);
                super.onDraw(canvas2);
                canvas2.restoreToCount(save);
            } else {
                super.onDraw(canvas2);
            }
        }
        canvas.drawBitmap(this.mCacheBitmap, this.mBounds.left, this.mBounds.top, (Paint) null);
    }

    
    @Override
    public void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.mMaskDrawable;
        if (drawable != null && drawable.isStateful()) {
            this.mMaskDrawable.setState(getDrawableState());
        }
        if (isDuplicateParentStateEnabled()) {
            ViewCompat.postInvalidateOnAnimation(this);
        }
    }

    @Override
    public void invalidateDrawable(Drawable drawable) {
        if (drawable == this.mMaskDrawable) {
            invalidate();
        } else {
            super.invalidateDrawable(drawable);
        }
    }

    @Override // android.widget.ImageView, android.view.View
    protected boolean verifyDrawable(Drawable drawable) {
        return drawable == this.mMaskDrawable || super.verifyDrawable(drawable);
    }
}
