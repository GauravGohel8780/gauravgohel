package com.fingerprint.lock.liveanimation.FLA_Fragments;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.fingerprint.lock.liveanimation.Ads_Common.AdsBaseActivity;
import com.fingerprint.lock.liveanimation.FLA_Adapters.FLA_Adapter_ViewPager3;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_HomeScreenModel;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_OnRvItemClickListener;
import com.fingerprint.lock.liveanimation.databinding.FragmentThemesBinding;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class FLA_ThemesFragment extends Fragment implements FLA_OnRvItemClickListener {
    Activity activity;
    FLA_Adapter_ViewPager3 adapter_viewPager2;
    FragmentThemesBinding fragmentBinding;
    ArrayList<FLA_HomeScreenModel> homeScreenData;
    ImageView imageViewBg;
    ArrayList<String> likedList;


    public FLA_ThemesFragment() {
    }

    public FLA_ThemesFragment(ImageView imageView, ArrayList<FLA_HomeScreenModel> arrayList, FLA_Adapter_ViewPager3 adapter_ViewPager3) {
        this.imageViewBg = imageView;
        this.homeScreenData = arrayList;
        this.adapter_viewPager2 = adapter_ViewPager3;
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.activity = requireActivity();
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.fragmentBinding = FragmentThemesBinding.inflate(layoutInflater);
        if (this.activity != null) {
            initViews();
        }
        return this.fragmentBinding.getRoot();
    }

    private void initViews() {
        Activity activity = this.activity;
        this.likedList = ((AdsBaseActivity) activity).loadLikedDataList(activity);
        ArrayList<FLA_HomeScreenModel> arrayList = this.homeScreenData;
        if (arrayList == null || arrayList.size() <= 0) {
            return;
        }
        this.fragmentBinding.recyclerView.setAdapter(this.adapter_viewPager2);
        this.fragmentBinding.recyclerView.getAdapter();
    }

    @Override 
    public void onItemClicked(int i) {
        getInstance(getActivity()).ShowAd(new HandleClick() {
            @Override
            public void Show(boolean adShow) {
                FLA_HomeScreenModel homeScreenModel = homeScreenData.get(i);
                if (homeScreenModel != null) {
                    Glide.with(activity.getApplicationContext()).asBitmap().load(homeScreenModel.getBgPath()).into(new CustomTarget<Bitmap>() {
                        @Override
                        public void onLoadCleared(Drawable drawable) {
                        }


                        public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                            ExecutorService newSingleThreadExecutor = Executors.newSingleThreadExecutor();
                            final Handler handler = new Handler(Looper.getMainLooper());
                            newSingleThreadExecutor.execute(new Runnable() {
                                @Override
                                public final void run() {
                                    handler.post(new Runnable() {
                                        @Override
                                        public final void run() {

                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            }
        }, MAIN_CLICK);
    }
}
