package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_LikeButton;


public interface FLA_OnLikeListener {
    void liked(FLA_LikeButton likeButton);

    void unLiked(FLA_LikeButton likeButton);
}
