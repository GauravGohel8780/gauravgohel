package com.fingerprint.lock.liveanimation.FLA_Fragments;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import com.fingerprint.lock.liveanimation.FLA_Activities.FLA_SelectWallpaperActivity;
import com.fingerprint.lock.liveanimation.FLA_Adapters.FLA_Adapter_Rv_Wallpapers;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_HomeScreenModel;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_OnRvItemClickListener;
import com.fingerprint.lock.liveanimation.databinding.FragmentWallpapersBinding;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.util.ArrayList;


public class FLA_WallpapersFragment extends Fragment implements FLA_OnRvItemClickListener {
    FragmentWallpapersBinding fragmentBinding;
    ArrayList<FLA_HomeScreenModel> rvDataList;

    public FLA_WallpapersFragment() {
    }

    public FLA_WallpapersFragment(ArrayList<FLA_HomeScreenModel> arrayList) {
        this.rvDataList = arrayList;
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.fragmentBinding = FragmentWallpapersBinding.inflate(layoutInflater);
        initViews();
        return this.fragmentBinding.getRoot();
    }

    private void initViews() {
        ArrayList<FLA_HomeScreenModel> arrayList = this.rvDataList;
        if (arrayList == null || arrayList.size() <= 0) {
            return;
        }
        FLA_Adapter_Rv_Wallpapers adapter_Rv_Wallpapers = new FLA_Adapter_Rv_Wallpapers(this.rvDataList, null, 1, this);
        this.fragmentBinding.recyclerView.setAdapter(adapter_Rv_Wallpapers);
        if (this.fragmentBinding.recyclerView.getAdapter() != null) {
            adapter_Rv_Wallpapers.notifyDataSetChanged();
            this.fragmentBinding.recyclerView.scheduleLayoutAnimation();
        }
    }

    @Override
    public void onItemClicked(int i) {
        getInstance(getActivity()).ShowAd(new HandleClick() {
            @Override
            public void Show(boolean adShow) {
                FLA_HomeScreenModel homeScreenModel;
                ArrayList<FLA_HomeScreenModel> arrayList = rvDataList;
                if (arrayList == null || (homeScreenModel = arrayList.get(i)) == null) {
                    return;
                }
                startActivity(new Intent(requireActivity(), FLA_SelectWallpaperActivity.class).putExtra("filePath", rvDataList.get(i).getBgPath()).putExtra("type", 3));
            }
        }, MAIN_CLICK);

    }
}
