package com.fingerprint.lock.liveanimation.FLA_Adapters;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.Key;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_HomeScreenModel;
import com.fingerprint.lock.liveanimation.FLA_Models.FLA_OnRvItemClickListener;
import com.fingerprint.lock.liveanimation.R;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.Executors;


public class FLA_Adapter_ViewPager3 extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final Activity activity;
    private final ArrayList<FLA_HomeScreenModel> homeScreenData;
    private final FLA_OnRvItemClickListener onRvItemClickListener;
    int[] strokeColorsList;

    @Override 
    public long getItemId(int i) {
        return i;
    }

    @Override 
    public int getItemViewType(int i) {
        return i;
    }

    public FLA_Adapter_ViewPager3(Activity activity, ArrayList<FLA_HomeScreenModel> arrayList, FLA_OnRvItemClickListener onRvItemClickListener) {
        this.activity = activity;
        this.homeScreenData = arrayList;
        this.onRvItemClickListener = onRvItemClickListener;
        this.strokeColorsList = activity.getResources().getIntArray(R.array.strokeColorArray);
    }

    @Override 
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new FLA_ItemViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.row_pager_adapter, viewGroup, false));
    }

    @Override 
    public void onBindViewHolder(final RecyclerView.ViewHolder viewHolder, int i) {
        FLA_ItemViewHolder itemViewHolder = (FLA_ItemViewHolder) viewHolder;
        FLA_HomeScreenModel homeScreenModel = this.homeScreenData.get(i);
        if (homeScreenModel != null) {
            int id = homeScreenModel.getId() - 1;
            if (id >= 0 && id < this.strokeColorsList.length) {
                itemViewHolder.binding.parentCv.setStrokeColor(this.strokeColorsList[id]);
            }
            if (!TextUtils.isEmpty(homeScreenModel.getBgPath())) {
                loadGlideImage(itemViewHolder.binding.image, homeScreenModel.getBgPath());
            }
            String animPath = homeScreenModel.getAnimPath();
            if (!TextUtils.isEmpty(animPath)) {
                loadLottieAnimation(itemViewHolder.binding.lottieView, animPath);
            }
            itemViewHolder.binding.parentCv.setOnClickListener(new View.OnClickListener() {
                @Override 
                public final void onClick(View view) {
                    onRvItemClickListener.onItemClicked(viewHolder.getAdapterPosition());
                }
            });
        }
    }


    private void loadGlideImage(final ImageView imageView, String str) {
        Glide.with(imageView).asBitmap().load(str).override(360).into(new CustomTarget<Bitmap>() { // from class: com.fingerprint.lock.liveanimation.Adapters.Adapter_ViewPager3.1
            @Override 
            public void onLoadCleared(Drawable drawable) {
            }


            public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                imageView.setImageBitmap(bitmap);
            }
        });
    }

    private void loadLottieAnimation(final LottieAnimationView lottieAnimationView, final String str) {
        if (TextUtils.isEmpty(str)) {
            return;
        }
        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override 
            public final void run() {
                try {
                    BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(str));
                    final String next = new Scanner(bufferedInputStream, Key.STRING_CHARSET_NAME).useDelimiter("\\A").next();
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override 
                        public final void run() {
//                            LottieAnimationView.this.setAnimationFromJson(next, null);
                        }
                    });
                    bufferedInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }


    @Override 
    public int getItemCount() {
        return this.homeScreenData.size();
    }
}
