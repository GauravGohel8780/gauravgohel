package com.fingerprint.lock.liveanimation.FLA_CustomViews.FLA_CarouselView;

import android.view.View;

import androidx.viewpager2.widget.ViewPager2;


abstract class FLA_PreviewTransformer implements ViewPager2.PageTransformer {
    int pageMargin;
    int previewOffset;
    ViewPager2 viewPager2;

    FLA_PreviewTransformer(int i, int i2, ViewPager2 viewPager2) {
        this.pageMargin = i;
        this.previewOffset = i2;
        this.viewPager2 = viewPager2;
    }

    
    static class RightSideTransformer extends FLA_PreviewTransformer {
      
        public RightSideTransformer(int i, int i2, ViewPager2 viewPager2) {
            super(i, i2, viewPager2);
        }

        @Override
        public void transformPage(View view, float f) {
            float f2 = f * (-(this.previewOffset + this.pageMargin));
            if (this.viewPager2.getOrientation() == ViewPager2.ORIENTATION_HORIZONTAL) {
                view.setTranslationX(f2);
            }
        }
    }

    
    static class SideBySideTransformer extends FLA_PreviewTransformer {
      
        public SideBySideTransformer(int i, int i2, ViewPager2 viewPager2) {
            super(i, i2, viewPager2);
        }

        @Override
        public void transformPage(View view, float f) {
            float f2 = f * (-((this.previewOffset * 2) + this.pageMargin));
            if (this.viewPager2.getOrientation() == ViewPager2.ORIENTATION_HORIZONTAL) {
                view.setTranslationX(f2);
            }
        }
    }

    
    static class ScaleTransformer extends FLA_PreviewTransformer {
        private final float scaleFactory;

      
        public ScaleTransformer(float f, int i, int i2, ViewPager2 viewPager2) {
            super(i, i2, viewPager2);
            this.scaleFactory = f;
        }

        @Override
        public void transformPage(View view, float f) {
            float f2 = (-((this.previewOffset * 2) + this.pageMargin)) * f;
            if (this.viewPager2.getOrientation() == ViewPager2.ORIENTATION_HORIZONTAL) {
                view.setTranslationX(f2);
                view.setScaleY(1.0f - (this.scaleFactory * Math.abs(f)));
            }
        }
    }
}
