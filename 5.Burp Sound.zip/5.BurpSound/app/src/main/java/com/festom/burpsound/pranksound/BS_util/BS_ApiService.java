package com.festom.burpsound.pranksound.BS_util;


import com.festom.burpsound.pranksound.BS_model.BS_FeedBackResponseModel;
import com.festom.burpsound.pranksound.BS_model.BS_FeedbackRequestModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface BS_ApiService {

    @POST("api/v1/feedBack/save")
    Call<BS_FeedBackResponseModel> feedbackUser(@Body BS_FeedbackRequestModel request);
}