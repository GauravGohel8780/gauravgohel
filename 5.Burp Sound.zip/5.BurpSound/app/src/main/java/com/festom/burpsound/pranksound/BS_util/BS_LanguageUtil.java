package com.festom.burpsound.pranksound.BS_util;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;

import com.festom.burpsound.pranksound.BS_preference.BS_SharePref;

import java.util.Locale;

public class BS_LanguageUtil {
    public static void setLanguage(Context context) {
        if (context == null) {
            return;
        }
        String prefLanguage = BS_SharePref.getPrefLanguage(context);
        if (prefLanguage == null) {
            prefLanguage = Locale.getDefault().getLanguage();
        }
        Locale locale = new Locale(prefLanguage.toLowerCase());
        Locale.setDefault(locale);
        Resources resources = context.getResources();
        Configuration configuration = resources.getConfiguration();
        configuration.setLocale(locale);
        resources.updateConfiguration(configuration, resources.getDisplayMetrics());
    }
}
