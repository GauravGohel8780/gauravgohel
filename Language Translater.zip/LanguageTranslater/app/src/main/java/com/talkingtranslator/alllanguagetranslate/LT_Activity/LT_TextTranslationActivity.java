package com.talkingtranslator.alllanguagetranslate.LT_Activity;


import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.text.Editable;
import android.text.Selection;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.perf.network.FirebasePerfHttpClient;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.talkingtranslator.alllanguagetranslate.Ads_Common.AdsBaseActivity;
import com.talkingtranslator.alllanguagetranslate.Database.Translator_Data_Helper;
import com.talkingtranslator.alllanguagetranslate.R;
import com.talkingtranslator.alllanguagetranslate.LT_Utilies.LT_Translator_AppUtils;
import com.talkingtranslator.alllanguagetranslate.LT_Utilies.LT_Translator_Constants;
import com.talkingtranslator.alllanguagetranslate.LT_model.LT_Language_Model;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class LT_TextTranslationActivity extends AdsBaseActivity {
    ImageView flagSource;
    EditText etSourceText;
    TextView tvSourceName;
    LinearLayout llSourcePicker;
    LT_Language_Model target_data;
    ImageView FlagFinal;
    LinearLayout llTargetPicker;
    TextToSpeech translator_textToSpeech;
    TextView tvTranslatedText;
    ImageView tvInterchange;
    TextView tvTargetName;
    String Str_DeviceLanguage;
    Dialog dialog;
    Editable translator_Edt_Text;
    Translator_Data_Helper Data_Helper;
    RecyclerView translator_Language_List;
    List<LT_Language_Model> _languageModels = new ArrayList();
    String mText;
    int mpostion;
    ProgressDialog progressDialog;
    RelativeLayout rlScrollView;
    EditText etSearchLang;
    List<LT_Language_Model> search_list1 = new ArrayList();
    String selection;
    LT_Language_Model source_data;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_translationtext);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        findViewById(R.id.ivBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(LT_TextTranslationActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        TextView titles = findViewById(R.id.titles);
        titles.setText("Text Translator");


        progressDialog = new ProgressDialog(LT_TextTranslationActivity.this);
        progressDialog.setMessage(getString(R.string.translating));
        Data_Helper = new Translator_Data_Helper(LT_TextTranslationActivity.this);
        flagSource = (ImageView) findViewById(R.id.flagSource);
        FlagFinal = (ImageView) findViewById(R.id.FlagFinal);
        tvSourceName = (TextView) findViewById(R.id.tvSourceName);
        tvSourceName.setSelected(true);
        tvTargetName = (TextView) findViewById(R.id.tvTargetName);
        tvTargetName.setSelected(true);

        llSourcePicker = findViewById(R.id.llSourcePicker);
        llTargetPicker = findViewById(R.id.llTargetPicker);
        rlScrollView = findViewById(R.id.rlScrollView);
        etSourceText = (EditText) findViewById(R.id.etSourceText);
        tvTranslatedText = (TextView) findViewById(R.id.tvTranslatedText);
        tvTranslatedText.setMovementMethod(new ScrollingMovementMethod());

        tvInterchange = (ImageView) findViewById(R.id.tvInterchange);
        for (int i = 0; i < LT_Translator_Constants.All_languages.length; i++) {
            LT_Language_Model modelLanguage = new LT_Language_Model();
            modelLanguage.setLanguage_name(LT_Translator_Constants.All_languages[i]);
            modelLanguage.setLanguage_flag(LT_Translator_Constants.flags[i]);
            modelLanguage.setLanguage_code(LT_Translator_Constants.languages_code[i]);
            modelLanguage.setLanguage_speech_code(LT_Translator_Constants.speech_code[i]);
            _languageModels.add(modelLanguage);
        }
        LT_Translator_Constants.sharedPreferences = getSharedPreferences(LT_Translator_Constants.FILE_NAME, 0);
        LT_Translator_Constants.editor = LT_Translator_Constants.sharedPreferences.edit();
        LT_Translator_Constants.language1 = LT_Translator_Constants.sharedPreferences.getInt(LT_Translator_Constants.KEY_Language_1, LT_Translator_Constants.language1);
        LT_Translator_Constants.language2 = LT_Translator_Constants.sharedPreferences.getInt(LT_Translator_Constants.KEY_Language_2, LT_Translator_Constants.language2);
        Str_DeviceLanguage = Locale.getDefault().getLanguage();
        if (LT_Translator_Constants.language1 != 0) {
            source_data = _languageModels.get(LT_Translator_Constants.language1);
        } else {
            for (int i2 = 0; i2 < LT_Translator_Constants.All_languages.length; i2++) {
                if (Str_DeviceLanguage.equals(_languageModels.get(i2).getLanguage_code())) {
                    source_data = _languageModels.get(i2);
                }
            }
        }
        if (source_data == null) {
            source_data = _languageModels.get(21);
        }
        if (LT_Translator_Constants.language2 != 0) {
            target_data = _languageModels.get(LT_Translator_Constants.language2);
        } else if (!Str_DeviceLanguage.equals("en")) {
            target_data = _languageModels.get(21);
        } else {
            target_data = _languageModels.get(86);
        }
        tvSourceName.setText(source_data.getLanguage_name());
        flagSource.setImageResource(source_data.getLanguage_flag());
        tvTargetName.setText(target_data.getLanguage_name());
        FlagFinal.setImageResource(target_data.getLanguage_flag());
        llSourcePicker.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(LT_TextTranslationActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        selection = "source";
                        PickLanguage();
                    }
                }, MAIN_CLICK);
            }
        });
        llTargetPicker.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(LT_TextTranslationActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        selection = "target";
                        PickLanguage();
                    }
                }, MAIN_CLICK);
            }
        });
        tvInterchange.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                LT_Language_Model modelLanguage = source_data;
                LT_TextTranslationActivity activityTextTranslation = LT_TextTranslationActivity.this;
                activityTextTranslation.source_data = activityTextTranslation.target_data;
                target_data = modelLanguage;
                tvSourceName.setText(source_data.getLanguage_name());
                flagSource.setImageResource(source_data.getLanguage_flag());
                tvTargetName.setText(target_data.getLanguage_name());
                FlagFinal.setImageResource(target_data.getLanguage_flag());
            }
        });

        int i = getIntent().getIntExtra("from", 0);
        if (i == 1) {
            titles.setText("Camera Translator");
        } else {
            titles.setText("Text Translator");
        }

        ((ImageView) findViewById(R.id.ivPasteSource)).setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                if (etSourceText.getText().toString().length() != 0) {
                    getInstance(LT_TextTranslationActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            try {
                                ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Copy", etSourceText.getText().toString()));
                                Toast.makeText(LT_TextTranslationActivity.this, (int) R.string.text_copied, Toast.LENGTH_SHORT).show();
                                return;
                            } catch (Exception e) {
                                Toast.makeText(LT_TextTranslationActivity.this, "" + e.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }, MAIN_CLICK);
                } else {
                    Toast.makeText(LT_TextTranslationActivity.this, (int) R.string.nothing_to_copy, Toast.LENGTH_SHORT).show();
                }
            }
        });
        ((ImageView) findViewById(R.id.ivCopy)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (tvTranslatedText.getText().toString().length() != 0) {
                    getInstance(LT_TextTranslationActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Copy", tvTranslatedText.getText().toString()));
                            Toast.makeText(LT_TextTranslationActivity.this, (int) R.string.text_copied, Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }, MAIN_CLICK);
                }
                Toast.makeText(LT_TextTranslationActivity.this, (int) R.string.nothing_to_copy, Toast.LENGTH_SHORT).show();
            }
        });
        ((ImageView) findViewById(R.id.ivClear)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(LT_TextTranslationActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        etSourceText.setText("");
                        tvTranslatedText.setText("");
                        Toast.makeText(LT_TextTranslationActivity.this, (int) R.string.text_deleted, Toast.LENGTH_SHORT).show();
                    }
                }, MAIN_CLICK);
            }
        });
        ((ImageView) findViewById(R.id.ivPlaySource)).setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                if (TextUtils.isEmpty(etSourceText.getText().toString())) {
                    Toast.makeText(LT_TextTranslationActivity.this, "Please First Translate Text !", Toast.LENGTH_SHORT).show();
                    return;
                } else if (source_data.getLanguage_code().equals("")) {
                    Toast.makeText(LT_TextTranslationActivity.this, "This Language not Support Speak Function !", Toast.LENGTH_SHORT).show();
                    return;
                } else {
                    LT_Translator_AppUtils.SpeakText(LT_TextTranslationActivity.this, etSourceText.getText().toString(), source_data.getLanguage_speech_code());
                    return;
                }
            }
        });
        ((ImageView) findViewById(R.id.ivPlayTarget)).setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                if (TextUtils.isEmpty(tvTranslatedText.getText().toString())) {
                    Toast.makeText(LT_TextTranslationActivity.this, "Please First Translate Text !", Toast.LENGTH_SHORT).show();
                    return;
                } else if (target_data.getLanguage_code().equals("")) {
                    Toast.makeText(LT_TextTranslationActivity.this, "This Language not Support Speak Function !", Toast.LENGTH_SHORT).show();
                    return;
                } else {
                    LT_Translator_AppUtils.SpeakText(LT_TextTranslationActivity.this, tvTranslatedText.getText().toString(), target_data.getLanguage_speech_code());
                    return;
                }
            }
        });
        ((ImageView) findViewById(R.id.ivShare)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(LT_TextTranslationActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        String charSequence = tvTranslatedText.getText().toString();
                        if (charSequence.isEmpty()) {
                            Toast.makeText(LT_TextTranslationActivity.this, (int) R.string.nothing_to_share, Toast.LENGTH_SHORT).show();
                            return;
                        }
                        Intent intent = new Intent("android.intent.action.SEND");
                        intent.setType("text/plain");
                        intent.putExtra("android.intent.extra.SUBJECT", "Translated Text");
                        intent.putExtra("android.intent.extra.TEXT", charSequence);
                        startActivity(Intent.createChooser(intent, getString(R.string.share_via)));
                    }
                }, MAIN_CLICK);
            }
        });
        (findViewById(R.id.tvTranslate)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(LT_TextTranslationActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        CloseKeyboard();
                        if (etSourceText.getText().length() == 0) {
                            Toast.makeText(LT_TextTranslationActivity.this, (int) R.string.write_here, Toast.LENGTH_SHORT).show();
                            return;
                        }
                        LT_TextTranslationActivity activityTextTranslation = LT_TextTranslationActivity.this;
                        if (!activityTextTranslation.isOnline(activityTextTranslation)) {
                            Toast.makeText(LT_TextTranslationActivity.this, (int) R.string.internet_required, Toast.LENGTH_SHORT).show();
                            return;
                        }
                        try {
                            progressDialog.show();
                            Translate();
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }
                    }
                }, MAIN_CLICK);
            }
        });
        rlScrollView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ShowKeyboard();
            }
        });


        try {
            String intentData = getIntent().getStringExtra("key");
            if (intentData.equals("")) {
            } else {
                etSourceText.setText(intentData);
            }
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }


    private boolean isOnline(Context context2) {
        if (context2 == null) {
            return false;
        }
        ConnectivityManager connectivityManager = (ConnectivityManager) context2.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager != null) {
            if (Build.VERSION.SDK_INT > 26) {
                NetworkCapabilities networkCapabilities = connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork());
                if (networkCapabilities != null && (networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) || networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))) {
                    return true;
                }
            } else {
                try {
                    NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
                    if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
                        return true;
                    }
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        }
        return false;
    }


    public String readJSON(String str) {
        StringBuilder sb = new StringBuilder();
        try {
            HttpResponse execute = FirebasePerfHttpClient.execute(new DefaultHttpClient(), new HttpGet(str));
            if (execute == null) {
                System.out.println(R.string.download_failed);
            } else if (execute.getStatusLine().getStatusCode() == 200) {
                InputStream content = execute.getEntity().getContent();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(content));
                while (true) {
                    String readLine = bufferedReader.readLine();
                    if (readLine == null) {
                        break;
                    }
                    sb.append(readLine);
                }
                content.close();
            } else {
                Toast.makeText(LT_TextTranslationActivity.this, (int) R.string.error, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            sb.append("[\"ERROR\"]");
        }
        return sb.toString();
    }

    public void Translate() throws UnsupportedEncodingException {
        mText = URLEncoder.encode(etSourceText.getText().toString(), "UTF-8");
        new ReadLanguageTask().execute("https://translate.googleapis.com/translate_a/single?client=gtx&sl=" + source_data.getLanguage_code() + "&tl=" + target_data.getLanguage_code() + "&dt=t&ie=UTF-8&oe=UTF-8&q=" + mText);
    }

    private void CloseKeyboard() {
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(etSourceText.getWindowToken(), 0);
    }

    private void ShowKeyboard() {
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(etSourceText, 0);
    }

    private void PickLanguage() {
        _languageModels.clear();
        search_list1.clear();
        for (int i = 0; i < LT_Translator_Constants.All_languages.length; i++) {
            LT_Language_Model modelLanguage = new LT_Language_Model();
            modelLanguage.setLanguage_name(LT_Translator_Constants.All_languages[i]);
            modelLanguage.setLanguage_flag(LT_Translator_Constants.flags[i]);
            modelLanguage.setLanguage_code(LT_Translator_Constants.languages_code[i]);
            modelLanguage.setLanguage_speech_code(LT_Translator_Constants.speech_code[i]);
            _languageModels.add(modelLanguage);
        }
        search_list1.addAll(_languageModels);
        dialog = new Dialog(LT_TextTranslationActivity.this, R.style.MyDialog);
        dialog.requestWindowFeature(1);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.custom_dialog_layout);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));

        dialog.show();
        translator_Language_List = (RecyclerView) dialog.findViewById(R.id.lang_rev);
        translator_Language_List.setLayoutManager(new LinearLayoutManager(this));
        translator_Language_List.setAdapter(new LanguageAdapter(this));
        etSearchLang = (EditText) dialog.findViewById(R.id.etSearchLang);
        etSearchLang.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable editable) {
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                filter(charSequence.toString());
            }
        });
    }

    private void filter(String str) {
        str.toLowerCase();
        _languageModels.clear();
        if (str.length() == 0) {
            _languageModels.addAll(search_list1);
        } else {
            for (int i = 0; i < search_list1.size(); i++) {
                LT_Language_Model modelLanguage = search_list1.get(i);
                if (modelLanguage.getLanguage_name().toLowerCase().contains(str)) {
                    _languageModels.add(modelLanguage);
                }
            }
        }
        translator_Language_List.setAdapter(new LanguageAdapter(this));
    }

    @Override
    public void onResume() {
        super.onResume();
        getPreference();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }

    public void getPreference() {
        LT_Translator_Constants.sharedPreferences = getSharedPreferences(LT_Translator_Constants.FILE_NAME, 0);
        LT_Translator_Constants.editor = LT_Translator_Constants.sharedPreferences.edit();
        LT_Translator_Constants.source_color = LT_Translator_Constants.sharedPreferences.getInt(LT_Translator_Constants.KEY_SOURCE_COLOR, LT_Translator_Constants.source_color);
        LT_Translator_Constants.target_color = LT_Translator_Constants.sharedPreferences.getInt(LT_Translator_Constants.KEY_TARGET_COLOR, LT_Translator_Constants.target_color);
        LT_Translator_Constants.enable_history = LT_Translator_Constants.sharedPreferences.getString(LT_Translator_Constants.KEY_SAVE_HISTORY, LT_Translator_Constants.enable_history);
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if ((i == 1 || i == 101) && i2 == -1 && intent != null) {
            etSourceText.setText(intent.getStringArrayListExtra("android.speech.extra.RESULTS").get(0));
            mpostion = etSourceText.length();
            translator_Edt_Text = etSourceText.getText();
            Selection.setSelection(translator_Edt_Text, mpostion);
            try {
                progressDialog.show();
                Translate();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onDestroy() {
        if (translator_textToSpeech != null) {
            translator_textToSpeech.stop();
            translator_textToSpeech.shutdown();
        }
        super.onDestroy();
    }

    public void setData() {
        if (selection.equals("source")) {
            tvSourceName.setText(source_data.getLanguage_name());
            flagSource.setImageResource(source_data.getLanguage_flag());
            return;
        }
        tvTargetName.setText(target_data.getLanguage_name());
        FlagFinal.setImageResource(target_data.getLanguage_flag());
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        try {
            if (translator_textToSpeech != null) {
                translator_textToSpeech.stop();
            }

            finish();
        } catch (NullPointerException exception) {
            exception.printStackTrace();
        }
    }


    @Override
    protected void onPause() {
        LT_Translator_AppUtils.releasedMediaPlayer();
        super.onPause();
        try {
            if (translator_textToSpeech != null) {
                translator_textToSpeech.stop();
            }
        } catch (NullPointerException exception) {
            exception.printStackTrace();
        }
    }

    public class ReadLanguageTask extends AsyncTask<String, Void, String> {
        private ReadLanguageTask() {
        }

        public String doInBackground(String... strArr) {
            return readJSON(strArr[0]);
        }

        public void onPostExecute(String str) {
            if (!str.equals("[\"ERROR\"]")) {
                try {

                    JSONArray jSONArray = new JSONArray(str);
                    String str2 = "";
                    for (int i = 0; i < jSONArray.getJSONArray(0).length(); i++) {
                        str2 = str2 + jSONArray.getJSONArray(0).getJSONArray(i).getString(0);
                    }
                    tvTranslatedText.setText(str2);
                    progressDialog.dismiss();

                    LT_Translator_Constants.enable_history = LT_Translator_Constants.sharedPreferences.getString(LT_Translator_Constants.KEY_SAVE_HISTORY, LT_Translator_Constants.enable_history);
                    if (LT_Translator_Constants.enable_history.equals("") || LT_Translator_Constants.enable_history == null || LT_Translator_Constants.enable_history.equals("1")) {
                        Data_Helper.InsertRecord("Translation_Data", source_data.getLanguage_name(), etSourceText.getText().toString(), target_data.getLanguage_name(), str2);
                    }
                    ((ScrollView) findViewById(R.id.main_scroll)).fullScroll(ScrollView.FOCUS_DOWN);

                } catch (Exception unused) {

                    progressDialog.dismiss();
                }
            }

        }
    }

    public class LanguageAdapter extends RecyclerView.Adapter<LanguageAdapter.ViewHolder> {
        Context context;
        ViewHolder holder;
        LT_Language_Model language_model;

        LanguageAdapter(Context context2) {
            context = context2;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_language, viewGroup, false));
        }

        public void onBindViewHolder(ViewHolder viewHolder, int i) {
            holder = viewHolder;
            try {
                language_model = _languageModels.get(i);
                viewHolder.tvFlagName.setText(language_model.getLanguage_name());
                viewHolder.ivflag.setImageResource(language_model.getLanguage_flag());
            } catch (Exception e) {
                e.printStackTrace();
                Context context2 = context;
                Toast.makeText(context2, "" + e.toString(), Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        public int getItemCount() {
            return _languageModels.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            ImageView ivflag;
            TextView tvFlagName;

            ViewHolder(View view) {
                super(view);
                tvFlagName = (TextView) view.findViewById(R.id.tvFlagName);
                ivflag = (ImageView) view.findViewById(R.id.ivflag);

                view.setOnClickListener(view1 -> {
                    if (selection.equals("source")) {
                        try {
                            source_data = _languageModels.get(getAdapterPosition());
                            dialog.dismiss();
                            setData();
                            int i = 0;
                            while (true) {
                                if (i >= search_list1.size()) {
                                    break;
                                } else if (search_list1.get(i).getLanguage_name().equals(source_data.getLanguage_name())) {
                                    LT_Translator_Constants.editor.putInt(LT_Translator_Constants.KEY_Language_1, i);
                                    LT_Translator_Constants.editor.commit();
                                    break;
                                } else {
                                    i++;
                                }
                            }
                        } catch (Exception e) {
                            Toast.makeText(LT_TextTranslationActivity.this, "" + e.toString(), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        try {
                            target_data = _languageModels.get(getAdapterPosition());
                            dialog.dismiss();
                            setData();
                            int i2 = 0;
                            while (true) {
                                if (i2 >= search_list1.size()) {
                                    break;
                                } else if (search_list1.get(i2).getLanguage_name().equals(target_data.getLanguage_name())) {
                                    LT_Translator_Constants.editor.putInt(LT_Translator_Constants.KEY_Language_2, i2);
                                    LT_Translator_Constants.editor.commit();
                                    break;
                                } else {
                                    i2++;
                                }
                            }
                        } catch (Exception e2) {
                            Toast.makeText(LT_TextTranslationActivity.this, "" + e2.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }
    }
}