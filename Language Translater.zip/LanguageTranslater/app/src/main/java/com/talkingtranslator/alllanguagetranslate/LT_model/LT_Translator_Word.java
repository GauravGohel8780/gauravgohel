package com.talkingtranslator.alllanguagetranslate.LT_model;

import java.io.Serializable;


public class LT_Translator_Word implements Serializable {
    public String id;
    public String meaning;
    public String word;

    public String getMeaning() {
        return meaning;
    }

    public String getId() {
        return id;
    }

    public void setId(String str) {
        id = str;
    }

    public String getWord() {
        return word;
    }

}
