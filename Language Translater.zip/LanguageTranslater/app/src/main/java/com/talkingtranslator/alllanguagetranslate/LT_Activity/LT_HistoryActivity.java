package com.talkingtranslator.alllanguagetranslate.LT_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.talkingtranslator.alllanguagetranslate.LT_Adapter.LT_HistoryAdapter;
import com.talkingtranslator.alllanguagetranslate.Ads_Common.AdsBaseActivity;
import com.talkingtranslator.alllanguagetranslate.Database.Translator_Data_Helper;
import com.talkingtranslator.alllanguagetranslate.R;
import com.talkingtranslator.alllanguagetranslate.LT_Utilies.LT_HitoryClick;
import com.talkingtranslator.alllanguagetranslate.LT_model.LT_History_Model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;

public class LT_HistoryActivity extends AdsBaseActivity {

    int cnt = 0;
    LT_History_Model translator_historyModel;
    ArrayList<LT_History_Model> data_models = new ArrayList<>();
    ImageView ivDelete;
    TextView tvEmpty;
    Translator_Data_Helper translator_Data_Helper;
    RecyclerView tvHistory;
    LT_HistoryAdapter translator_adpter_history;
    TextView translator_titles;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_history);


        findViewById(R.id.ivBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(LT_HistoryActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

        translator_titles = findViewById(R.id.titles);
        translator_titles.setText("History");
        tvEmpty = (TextView) findViewById(R.id.tvEmpty);
        tvHistory = (RecyclerView) findViewById(R.id.tvHistory);
        tvHistory.setLayoutManager(new LinearLayoutManager(this));
        translator_Data_Helper = new Translator_Data_Helper(this);
        ivDelete = findViewById(R.id.ivDelete);

        ivDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Dialog dialog = new Dialog(LT_HistoryActivity.this, R.style.customDialog);
                dialog.setContentView(R.layout.delete_dialog);
                dialog.setCancelable(false);

                Objects.requireNonNull(dialog.getWindow()).setGravity(Gravity.CENTER);
                dialog.getWindow().setLayout(RecyclerView.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

                Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(ContextCompat.getDrawable(LT_HistoryActivity.this, R.color.tranperent));

                dialog.show();


                TextView tvCancel = dialog.findViewById(R.id.tvCancel);
                TextView tvDelete = dialog.findViewById(R.id.tvDelete);

                tvDelete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        getInstance(LT_HistoryActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                dialog.dismiss();
                                translator_Data_Helper.delAll();
                                tvHistory.setVisibility(View.GONE);
                                ivDelete.setVisibility(View.GONE);
                                tvEmpty.setVisibility(View.VISIBLE);
                            }
                        }, MAIN_CLICK);
                    }
                });

                tvCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        getInstance(LT_HistoryActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                dialog.dismiss();
                            }
                        }, MAIN_CLICK);
                    }
                });
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);

        data_models.clear();
        cnt = checkData();
        if (cnt == 0) {
            tvEmpty.setVisibility(View.VISIBLE);
            tvHistory.setVisibility(View.GONE);
            ivDelete.setVisibility(View.GONE);
            return;
        }
        tvEmpty.setVisibility(View.GONE);
        Cursor transData = translator_Data_Helper.getTransData();
        while (transData.moveToNext()) {
            translator_historyModel = new LT_History_Model();
            translator_historyModel.setId(transData.getInt(0));
            translator_historyModel.setSource_language(transData.getString(1));
            translator_historyModel.setSource_language_txt(transData.getString(2));
            translator_historyModel.setTarget_language(transData.getString(3));
            translator_historyModel.setTarget_language_txt(transData.getString(4));
            data_models.add(translator_historyModel);
        }
        transData.close();
        translator_Data_Helper.close();
        Collections.reverse(data_models);
        translator_adpter_history = new LT_HistoryAdapter(this, data_models, new LT_HitoryClick() {
            @Override
            public void onHistoryClick() {
                getInstance(LT_HistoryActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(LT_HistoryActivity.this, LT_HistoryDetailsActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });
        tvHistory.setAdapter(translator_adpter_history);
        tvHistory.setVisibility(View.VISIBLE);
    }

    public int checkData() {
        SQLiteDatabase writableDatabase = new Translator_Data_Helper(this).getWritableDatabase();
        Cursor rawQuery = writableDatabase.rawQuery("SELECT * FROM Translation_Data", null);
        int count2 = rawQuery.getCount();
        rawQuery.close();
        writableDatabase.close();
        return count2;
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        finish();
    }
}