package com.talkingtranslator.alllanguagetranslate.LT_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.text.Editable;
import android.text.Selection;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.perf.network.FirebasePerfHttpClient;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.talkingtranslator.alllanguagetranslate.Ads_Common.AdsBaseActivity;
import com.talkingtranslator.alllanguagetranslate.Database.Translator_Data_Helper;
import com.talkingtranslator.alllanguagetranslate.R;
import com.talkingtranslator.alllanguagetranslate.LT_Utilies.LT_Translator_AppUtils;
import com.talkingtranslator.alllanguagetranslate.LT_Utilies.LT_Translator_Constants;
import com.talkingtranslator.alllanguagetranslate.LT_model.LT_Language_Model;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class LT_VoiceTranslationActivity extends AdsBaseActivity {

    ProgressDialog progressDialog;
    ImageView ivInterchange;
    TextView tvTargetName;
    String translator_Str_Device_language;
    Dialog dialog;
    Editable etext;
    Translator_Data_Helper translator_helperDB;
    RecyclerView translator_Lang_List;
    List<LT_Language_Model> languages_data = new ArrayList();
    String mText;
    int mpostion;
    RelativeLayout rlScrollView;
    EditText etSearchLang;
    List<LT_Language_Model> translator_search_list1 = new ArrayList();
    String selection;

    ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
        public void onActivityResult(ActivityResult activityResult) {
            if (activityResult.getResultCode() == -1 && activityResult.getData() != null && etSourceText != null) {
                Intent data = activityResult.getData();
                if (data.getStringArrayListExtra("android.speech.extra.RESULTS").size() > 0) {
                    etSourceText.setText(data.getStringArrayListExtra("android.speech.extra.RESULTS").get(0));
                    mpostion = etSourceText.length();
                    etext = etSourceText.getText();
                    Selection.setSelection(etext, mpostion);
                    try {
                        progressDialog.show();
                        Translate();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    });
    LT_Language_Model tr_source_data;
    ImageView FlagSource;
    EditText etSourceText;
    TextView tvSourceName;
    LinearLayout llSourcePicker;
    String speakMode;
    LT_Language_Model tr_target_data;
    ImageView FlagFinal;
    LinearLayout tv_target_picker;
    TextToSpeech textToSpeech;
    TextView tvTranslatedText;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);

        setContentView(R.layout.activity_translationvoice);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getString(R.string.translating));

        findViewById(R.id.ivBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(LT_VoiceTranslationActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        TextView titles = findViewById(R.id.titles);
        titles.setText("Voice Translator");

        translator_helperDB = new Translator_Data_Helper(LT_VoiceTranslationActivity.this);
        FlagSource = (ImageView) findViewById(R.id.FlagSource);
        FlagFinal = (ImageView) findViewById(R.id.FlagFinal);
        tvSourceName = (TextView) findViewById(R.id.tvSourceName);
        tvSourceName.setSelected(true);
        tvTargetName = (TextView) findViewById(R.id.tvTargetName);
        tvTargetName.setSelected(true);
        llSourcePicker = findViewById(R.id.llSourcePicker);
        tv_target_picker = findViewById(R.id.target_picker);
        rlScrollView = findViewById(R.id.rlScrollView);
        etSourceText = (EditText) findViewById(R.id.etSourceText);
        tvTranslatedText = (TextView) findViewById(R.id.tvTranslatedText);
        tvTranslatedText.setMovementMethod(new ScrollingMovementMethod());

        ivInterchange = (ImageView) findViewById(R.id.ivInterchange);
        for (int i = 0; i < LT_Translator_Constants.All_languages.length; i++) {
            LT_Language_Model languageModel = new LT_Language_Model();
            languageModel.setLanguage_name(LT_Translator_Constants.All_languages[i]);
            languageModel.setLanguage_flag(LT_Translator_Constants.flags[i]);
            languageModel.setLanguage_code(LT_Translator_Constants.languages_code[i]);
            languageModel.setLanguage_speech_code(LT_Translator_Constants.speech_code[i]);
            languages_data.add(languageModel);
        }
        LT_Translator_Constants.sharedPreferences = getSharedPreferences(LT_Translator_Constants.FILE_NAME, 0);
        LT_Translator_Constants.editor = LT_Translator_Constants.sharedPreferences.edit();
        LT_Translator_Constants.language1 = LT_Translator_Constants.sharedPreferences.getInt(LT_Translator_Constants.KEY_Language_1, LT_Translator_Constants.language1);
        LT_Translator_Constants.language2 = LT_Translator_Constants.sharedPreferences.getInt(LT_Translator_Constants.KEY_Language_2, LT_Translator_Constants.language2);
        translator_Str_Device_language = Locale.getDefault().getLanguage();
        if (LT_Translator_Constants.language1 != 0) {
            tr_source_data = languages_data.get(LT_Translator_Constants.language1);
        } else {
            for (int i2 = 0; i2 < LT_Translator_Constants.All_languages.length; i2++) {
                if (translator_Str_Device_language.equals(languages_data.get(i2).getLanguage_code())) {
                    tr_source_data = languages_data.get(i2);
                }
            }
        }
        if (tr_source_data == null) {
            tr_source_data = languages_data.get(21);
        }
        if (LT_Translator_Constants.language2 != 0) {
            tr_target_data = languages_data.get(LT_Translator_Constants.language2);
        } else if (!translator_Str_Device_language.equals("en")) {
            tr_target_data = languages_data.get(21);
        } else {
            tr_target_data = languages_data.get(86);
        }
        tvSourceName.setText(tr_source_data.getLanguage_name());
        FlagSource.setImageResource(tr_source_data.getLanguage_flag());
        tvTargetName.setText(tr_target_data.getLanguage_name());
        FlagFinal.setImageResource(tr_target_data.getLanguage_flag());
        llSourcePicker.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(LT_VoiceTranslationActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        selection = "source";
                        PickLanguage();
                    }
                }, MAIN_CLICK);
            }
        });
        tv_target_picker.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(LT_VoiceTranslationActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        selection = "target";
                        PickLanguage();
                    }
                }, MAIN_CLICK);
            }
        });
        ivInterchange.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                LT_Language_Model languageModel = tr_source_data;
                tr_source_data = tr_target_data;
                tr_target_data = languageModel;
                tvSourceName.setText(tr_source_data.getLanguage_name());
                FlagSource.setImageResource(tr_source_data.getLanguage_flag());
                tvTargetName.setText(tr_target_data.getLanguage_name());
                FlagFinal.setImageResource(tr_target_data.getLanguage_flag());
            }
        });
        ((ImageView) findViewById(R.id.ivCopy)).setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {

                if (tvTranslatedText.getText().toString().length() != 0) {
                    ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText(getString(R.string.copy), tvTranslatedText.getText().toString()));
                    Toast.makeText(LT_VoiceTranslationActivity.this, (int) R.string.text_copied, Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(LT_VoiceTranslationActivity.this, (int) R.string.nothing_to_copy, Toast.LENGTH_SHORT).show();
            }
        });
        ((ImageView) findViewById(R.id.ivClear)).setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                etSourceText.setText("");
                tvTranslatedText.setText("");
                Toast.makeText(LT_VoiceTranslationActivity.this, (int) R.string.text_deleted, Toast.LENGTH_SHORT).show();
            }
        });
        ((ImageView) findViewById(R.id.ivPlaySource)).setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                if (TextUtils.isEmpty(etSourceText.getText().toString())) {
                    Toast.makeText(LT_VoiceTranslationActivity.this, "Please First Translate Text !", Toast.LENGTH_SHORT).show();
                    return;
                } else if (tr_source_data.getLanguage_code().equals("")) {
                    Toast.makeText(LT_VoiceTranslationActivity.this, "This Language not Support Speak Function !", Toast.LENGTH_SHORT).show();
                    return;
                } else {
                    LT_Translator_AppUtils.SpeakText(LT_VoiceTranslationActivity.this, etSourceText.getText().toString(), tr_source_data.getLanguage_speech_code());
                    return;
                }

            }
        });
        ((TextView) findViewById(R.id.tvTranslate)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (tr_source_data.getLanguage_speech_code().equals("")) {
                    Toast.makeText(LT_VoiceTranslationActivity.this, (int) R.string.stt_not_available, Toast.LENGTH_SHORT).show();
                } else {
                    getInstance(LT_VoiceTranslationActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            ChangeSpeechToText();
                        }
                    }, MAIN_CLICK);
                }
            }
        });
        ((ImageView) findViewById(R.id.ivShare)).setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                String charSequence = tvTranslatedText.getText().toString();
                if (charSequence.isEmpty()) {
                    Toast.makeText(LT_VoiceTranslationActivity.this, (int) R.string.nothing_to_share, Toast.LENGTH_SHORT).show();
                    return;
                }

                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.SUBJECT", "Translated Text");
                intent.putExtra("android.intent.extra.TEXT", charSequence);
                LT_VoiceTranslationActivity activityVoiceTranslation = LT_VoiceTranslationActivity.this;
                activityVoiceTranslation.startActivity(Intent.createChooser(intent, activityVoiceTranslation.getString(R.string.share_via)));
            }
        });
        ((ImageView) findViewById(R.id.ivPlayTarget)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                if (TextUtils.isEmpty(tvTranslatedText.getText().toString())) {
                    Toast.makeText(LT_VoiceTranslationActivity.this, "Please First Translate Text !", Toast.LENGTH_SHORT).show();
                    return;
                } else if (tr_target_data.getLanguage_code().equals("")) {
                    Toast.makeText(LT_VoiceTranslationActivity.this, "This Language not Support Speak Function !", Toast.LENGTH_SHORT).show();
                    return;
                } else {
                    getInstance(LT_VoiceTranslationActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            LT_Translator_AppUtils.SpeakText(LT_VoiceTranslationActivity.this, tvTranslatedText.getText().toString(), tr_target_data.getLanguage_speech_code());
                            return;
                        }
                    }, MAIN_CLICK);
                }
            }
        });
        rlScrollView.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                ShowKeyboard();
            }
        });


        ((ImageView) findViewById(R.id.ivPasteSource)).setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                if (etSourceText.getText().toString().length() != 0) {
                    try {
                        ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Copy", etSourceText.getText().toString()));
                        Toast.makeText(LT_VoiceTranslationActivity.this, (int) R.string.text_copied, Toast.LENGTH_SHORT).show();
                        return;

                    } catch (Exception e) {
                        Toast.makeText(LT_VoiceTranslationActivity.this, "" + e.toString(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(LT_VoiceTranslationActivity.this, (int) R.string.nothing_to_copy, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void ChangeSpeechToText() {
        Intent intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", tr_source_data.getLanguage_name());
        intent.putExtra("android.speech.extra.LANGUAGE", tr_source_data.getLanguage_speech_code());
        intent.putExtra("android.speech.extra.LANGUAGE_PREFERENCE", tr_source_data.getLanguage_name());
        try {
            someActivityResultLauncher.launch(intent);
            etSourceText.setText("");
        } catch (ActivityNotFoundException unused) {
            Toast.makeText(getApplicationContext(), (int) R.string.error, Toast.LENGTH_SHORT).show();
        }
    }

    private void ChangeTextToSpeech(String str) {

        if (str.equals("source")) {
            if (!etSourceText.getText().toString().isEmpty()) {
                textToSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int i) {
                        TxonInit(i);

                    }
                });
                TxonInit(0);
                return;
            }
            Toast.makeText(this, (int) R.string.nothing_to_speak, Toast.LENGTH_SHORT).show();
        } else if (!str.equals("target")) {
        } else {
            if (!tvTranslatedText.getText().toString().isEmpty()) {
                textToSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int i) {
                        TxonInit(i);
                    }
                });
                TxonInit(0);
                return;
            }
            Toast.makeText(this, (int) R.string.nothing_to_speak, Toast.LENGTH_SHORT).show();
        }
    }


    public void TxonInit(int i) {
        if (i != 0) {
            return;
        }
        if (speakMode.equals("source")) {
            try {
                textToSpeech.setLanguage(new Locale(tr_source_data.getLanguage_name(), ""));
                textToSpeech.speak(etSourceText.getText().toString(), 0, null, null);
            } catch (Exception unused) {
                Toast.makeText(this, (int) R.string.tts_not_available, Toast.LENGTH_SHORT).show();
            }
        } else {
            try {
                textToSpeech.setLanguage(new Locale(tr_target_data.getLanguage_name(), ""));
                textToSpeech.speak(tvTranslatedText.getText().toString(), 0, null, null);
            } catch (Exception unused2) {
                Toast.makeText(this, (int) R.string.tts_not_available, Toast.LENGTH_SHORT).show();
            }
        }
    }


    public String readJSON(String str) {
        StringBuilder sb = new StringBuilder();
        try {
            HttpResponse execute = FirebasePerfHttpClient.execute(new DefaultHttpClient(), new HttpGet(str));
            if (execute == null) {
            } else if (execute.getStatusLine().getStatusCode() == 200) {
                InputStream content = execute.getEntity().getContent();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(content));
                while (true) {
                    String readLine = bufferedReader.readLine();
                    if (readLine == null) {
                        break;
                    }
                    sb.append(readLine);
                }
                content.close();
            } else {
                Toast.makeText(LT_VoiceTranslationActivity.this, (int) R.string.error, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            sb.append("[\"ERROR\"]");
        }
        return sb.toString();
    }

    public void Translate() throws UnsupportedEncodingException {
        mText = URLEncoder.encode(etSourceText.getText().toString(), "UTF-8");
        new ReadLanguageTask().execute("https://translate.googleapis.com/translate_a/single?client=gtx&sl=" + tr_source_data.getLanguage_code() + "&tl=" + tr_target_data.getLanguage_code() + "&dt=t&ie=UTF-8&oe=UTF-8&q=" + mText);
    }


    private void ShowKeyboard() {
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(etSourceText, 0);
    }

    private void PickLanguage() {
        languages_data.clear();
        translator_search_list1.clear();
        for (int i = 0; i < LT_Translator_Constants.All_languages.length; i++) {
            LT_Language_Model languageModel = new LT_Language_Model();
            languageModel.setLanguage_name(LT_Translator_Constants.All_languages[i]);
            languageModel.setLanguage_flag(LT_Translator_Constants.flags[i]);
            languageModel.setLanguage_code(LT_Translator_Constants.languages_code[i]);
            languageModel.setLanguage_speech_code(LT_Translator_Constants.speech_code[i]);
            languages_data.add(languageModel);
        }
        translator_search_list1.addAll(languages_data);
        dialog = new Dialog(LT_VoiceTranslationActivity.this, R.style.MyDialog);
        dialog.requestWindowFeature(1);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.custom_dialog_layout);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.show();
        translator_Lang_List = (RecyclerView) dialog.findViewById(R.id.lang_rev);
        translator_Lang_List.setLayoutManager(new LinearLayoutManager(this));
        translator_Lang_List.setAdapter(new Language_Adapter(this));
        etSearchLang = (EditText) dialog.findViewById(R.id.etSearchLang);
        etSearchLang.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable editable) {
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                filter(charSequence.toString());
            }
        });
    }

    private void filter(String str) {
        str.toLowerCase();
        languages_data.clear();
        if (str.length() == 0) {
            languages_data.addAll(translator_search_list1);
        } else {
            for (int i = 0; i < translator_search_list1.size(); i++) {
                LT_Language_Model languageModel = translator_search_list1.get(i);
                if (languageModel.getLanguage_name().toLowerCase().contains(str)) {
                    languages_data.add(languageModel);
                }
            }
        }
        translator_Lang_List.setAdapter(new Language_Adapter(this));
    }

    @Override
    public void onResume() {
        super.onResume();
        getPreference();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }

    public void getPreference() {
        LT_Translator_Constants.sharedPreferences = getSharedPreferences(LT_Translator_Constants.FILE_NAME, 0);
        LT_Translator_Constants.editor = LT_Translator_Constants.sharedPreferences.edit();
        LT_Translator_Constants.source_color = LT_Translator_Constants.sharedPreferences.getInt(LT_Translator_Constants.KEY_SOURCE_COLOR, LT_Translator_Constants.source_color);
        LT_Translator_Constants.target_color = LT_Translator_Constants.sharedPreferences.getInt(LT_Translator_Constants.KEY_TARGET_COLOR, LT_Translator_Constants.target_color);
        LT_Translator_Constants.enable_history = LT_Translator_Constants.sharedPreferences.getString(LT_Translator_Constants.KEY_SAVE_HISTORY, LT_Translator_Constants.enable_history);
    }

    @Override
    public void onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }

    public void setData() {
        if (selection.equals("source")) {
            tvSourceName.setText(tr_source_data.getLanguage_name());
            FlagSource.setImageResource(tr_source_data.getLanguage_flag());
            return;
        }
        tvTargetName.setText(tr_target_data.getLanguage_name());
        FlagFinal.setImageResource(tr_target_data.getLanguage_flag());
    }

    public class ReadLanguageTask extends AsyncTask<String, Void, String> {
        private ReadLanguageTask() {
        }

        public String doInBackground(String... strArr) {
            return readJSON(strArr[0]);
        }

        public void onPostExecute(String str) {
            if (!str.equals("[\"ERROR\"]")) {
                try {
                    JSONArray jSONArray = new JSONArray(str);
                    String str2 = "";
                    for (int i = 0; i < jSONArray.getJSONArray(0).length(); i++) {
                        str2 = str2 + jSONArray.getJSONArray(0).getJSONArray(i).getString(0);
                    }
                    tvTranslatedText.setText(str2);
                    progressDialog.dismiss();

                    speakMode = "target";
                    LT_VoiceTranslationActivity activityVoiceTranslation = LT_VoiceTranslationActivity.this;
                    activityVoiceTranslation.ChangeTextToSpeech(activityVoiceTranslation.speakMode);
                    LT_Translator_Constants.enable_history = LT_Translator_Constants.sharedPreferences.getString(LT_Translator_Constants.KEY_SAVE_HISTORY, LT_Translator_Constants.enable_history);
                    if (LT_Translator_Constants.enable_history.equals("") || LT_Translator_Constants.enable_history == null || LT_Translator_Constants.enable_history.equals("1")) {
                        translator_helperDB.InsertRecord("Translation_Data", tr_source_data.getLanguage_name(), etSourceText.getText().toString(), tr_target_data.getLanguage_name(), str2);
                    }
                    ((ScrollView) findViewById(R.id.svMainScroll)).fullScroll(ScrollView.FOCUS_DOWN);

                } catch (Exception unused) {
                    progressDialog.dismiss();
                }
            }
        }
    }

    public class Language_Adapter extends RecyclerView.Adapter<Language_Adapter.ViewHolder> {
        Context context;
        ViewHolder holder;
        LT_Language_Model trLanguage_model;

        Language_Adapter(Context context2) {
            context = context2;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_language, viewGroup, false));
        }

        public void onBindViewHolder(ViewHolder viewHolder, int i) {
            holder = viewHolder;
            try {
                trLanguage_model = languages_data.get(i);
                viewHolder.tvFlagName.setText(trLanguage_model.getLanguage_name());
                viewHolder.ivflag.setImageResource(trLanguage_model.getLanguage_flag());
            } catch (Exception e) {
                e.printStackTrace();
                Context context2 = context;
                Toast.makeText(context2, "" + e.toString(), Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        public int getItemCount() {
            return languages_data.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            ImageView ivflag;
            TextView tvFlagName;

            ViewHolder(View view) {
                super(view);
                tvFlagName = (TextView) view.findViewById(R.id.tvFlagName);
                ivflag = (ImageView) view.findViewById(R.id.ivflag);
                view.setOnClickListener(view1 -> {
                    if (selection.equals("source")) {
                        try {
                            tr_source_data = languages_data.get(getAdapterPosition());
                            dialog.dismiss();
                            setData();
                            int i = 0;
                            while (true) {
                                if (i >= translator_search_list1.size()) {
                                    break;
                                } else if (translator_search_list1.get(i).getLanguage_name().equals(tr_source_data.getLanguage_name())) {
                                    LT_Translator_Constants.editor.putInt(LT_Translator_Constants.KEY_Language_1, i);
                                    LT_Translator_Constants.editor.commit();
                                    break;
                                } else {
                                    i++;
                                }
                            }
                        } catch (Exception e) {
                            Toast.makeText(LT_VoiceTranslationActivity.this, "" + e.toString(), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        try {
                            tr_target_data = languages_data.get(getAdapterPosition());
                            dialog.dismiss();
                            setData();
                            int i2 = 0;
                            while (true) {
                                if (i2 >= translator_search_list1.size()) {
                                    break;
                                } else if (translator_search_list1.get(i2).getLanguage_name().equals(tr_target_data.getLanguage_name())) {
                                    LT_Translator_Constants.editor.putInt(LT_Translator_Constants.KEY_Language_2, i2);
                                    LT_Translator_Constants.editor.commit();
                                    break;
                                } else {
                                    i2++;
                                }
                            }
                        } catch (Exception e2) {
                            Toast.makeText(LT_VoiceTranslationActivity.this, "" + e2.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }
    }

    @Override
    protected void onPause() {
        LT_Translator_AppUtils.releasedMediaPlayer();
        super.onPause();
        try {
            if (textToSpeech != null) {
                textToSpeech.stop();
            }
        } catch (NullPointerException exception) {
            exception.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        try {
            if (textToSpeech != null) {
                textToSpeech.stop();
                finish();
            }
        } catch (NullPointerException exception) {
            exception.printStackTrace();
        }
    }

}