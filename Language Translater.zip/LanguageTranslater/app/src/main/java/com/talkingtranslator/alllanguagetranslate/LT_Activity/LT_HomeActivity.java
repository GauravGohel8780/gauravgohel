package com.talkingtranslator.alllanguagetranslate.LT_Activity;


import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.talkingtranslator.alllanguagetranslate.Ads_Common.AdsBaseActivity;
import com.talkingtranslator.alllanguagetranslate.R;
import com.talkingtranslator.alllanguagetranslate.LT_ExtraScreen.Activity.WebActivity;
import com.talkingtranslator.alllanguagetranslate.LT_Utilies.LT_Translator_Constants;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

public class LT_HomeActivity extends AdsBaseActivity {
    final String[] arr_a = LT_Translator_Constants.array_a;
    final String[] arr_c = LT_Translator_Constants.array_c;
    Calendar cal;
    int position;
    TextView tv1, tv3, tvDate;
    LinearLayout llWord;

    ImageView  tvPrivacy, ivTranslateText, ivTranslateVoice, ivTranslatePicture, ivGame;
    RelativeLayout rlHistory;

    public void AllClick(Class cls) {
        Dexter.withActivity(LT_HomeActivity.this).withPermissions(
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.CAMERA,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        startActivity(new Intent(LT_HomeActivity.this, cls).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).
                withErrorListener(new PermissionRequestErrorListener() {
                    @Override
                    public void onError(DexterError error) {
                        Toast.makeText(getApplicationContext(), "Error" + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                })
                .onSameThread()
                .check();
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_home);

        findViewById(R.id.ivBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(LT_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        cal = Calendar.getInstance();
        StringBuilder sb = new StringBuilder(new SimpleDateFormat("dd-MM-yyyy").format(cal.getTime()));
        sb.append(" ");
        int i = cal.get(6);
        int i2 = i - 1;
        position = i2;
        fvd();
        tvPrivacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(LT_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        startActivity(new Intent(LT_HomeActivity.this, WebActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    }
                }, MAIN_CLICK);
            }
        });
        ivTranslateText.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(LT_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        AllClick(LT_TextTranslationActivity.class);
                    }
                }, MAIN_CLICK);
            }
        });
        ivGame.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(LT_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        AllClick(LT_WordGameActivity.class);
                    }
                }, MAIN_CLICK);
            }
        });
        llWord.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(LT_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        AllClick(LT_WordOfTheDayActivity.class);
                    }
                }, MAIN_CLICK);
            }
        });
        ivTranslateVoice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(LT_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        AllClick(LT_VoiceTranslationActivity.class);
                    }
                }, MAIN_CLICK);
            }
        });
        ivTranslatePicture.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(LT_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        AllClick(LT_CameraTranslationActivity.class);
                    }
                }, MAIN_CLICK);
            }
        });
        rlHistory.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(LT_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        AllClick(LT_HistoryActivity.class);
                    }
                }, MAIN_CLICK);
            }
        });

        tv1.setText(arr_a[i2]);
        tv3.setText(arr_c[position]);
        tvDate.setText(sb);

    }

    void fvd() {
        tv1 = (TextView) findViewById(R.id.tv1);
        tv3 = (TextView) findViewById(R.id.tv3);
        tvDate = (TextView) findViewById(R.id.tvDate);
        ivTranslateText = findViewById(R.id.ivTranslateText);
        ivTranslateVoice = findViewById(R.id.ivTranslateVoice);
        ivTranslatePicture = findViewById(R.id.ivTranslatePicture);
        rlHistory = (RelativeLayout) findViewById(R.id.rlHistory);
        tvPrivacy = (ImageView) findViewById(R.id.tvPrivacy);
        ivGame = findViewById(R.id.ivGame);
        llWord = findViewById(R.id.llWord);
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall1).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }

}