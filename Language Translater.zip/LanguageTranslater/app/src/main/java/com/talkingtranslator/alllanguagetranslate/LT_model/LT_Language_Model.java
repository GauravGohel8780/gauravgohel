package com.talkingtranslator.alllanguagetranslate.LT_model;

public class LT_Language_Model {
    String language_code;
    int language_flag;
    String language_name;
    String language_speech_code;

    public String getLanguage_name() {
        return language_name;
    }

    public void setLanguage_name(String str) {
        language_name = str;
    }

    public int getLanguage_flag() {
        return language_flag;
    }

    public void setLanguage_flag(int i) {
        language_flag = i;
    }

    public String getLanguage_code() {
        return language_code;
    }

    public void setLanguage_code(String str) {
        language_code = str;
    }

    public String getLanguage_speech_code() {
        return language_speech_code;
    }

    public void setLanguage_speech_code(String str) {
        language_speech_code = str;
    }
}