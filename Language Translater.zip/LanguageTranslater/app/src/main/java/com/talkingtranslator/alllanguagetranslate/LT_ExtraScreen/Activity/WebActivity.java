package com.talkingtranslator.alllanguagetranslate.LT_ExtraScreen.Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.MyApplication.sharedPreferencesHelper;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.talkingtranslator.alllanguagetranslate.Ads_Common.AdsBaseActivity;
import com.talkingtranslator.alllanguagetranslate.R;


public class WebActivity extends AdsBaseActivity {
    private WebView webPrivacyPolicy;
    TextView Tv_TitleHead;
    private ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.splash_web);

        ((ImageView) findViewById(R.id.ivBack)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(WebActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        progress = findViewById(R.id.progress);

        Tv_TitleHead = findViewById(R.id.titles);
        Tv_TitleHead.setSelected(true);
        Tv_TitleHead.setText("Privacy Policy");

        webPrivacyPolicy = (WebView) findViewById(R.id.wvPrivacyPolicy);

        webPrivacyPolicy.loadUrl(sharedPreferencesHelper.getPrivacyPolicy());
        webPrivacyPolicy.getSettings().setJavaScriptEnabled(true);
        webPrivacyPolicy.setVisibility(View.INVISIBLE);
        webPrivacyPolicy.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                webPrivacyPolicy.setVisibility(View.VISIBLE);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
