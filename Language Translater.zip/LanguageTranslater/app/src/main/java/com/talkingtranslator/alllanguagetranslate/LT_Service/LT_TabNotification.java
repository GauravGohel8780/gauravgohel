package com.talkingtranslator.alllanguagetranslate.LT_Service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.widget.RemoteViews;

import androidx.core.app.NotificationCompat;

import com.talkingtranslator.alllanguagetranslate.LT_Activity.LT_CameraTranslationActivity;
import com.talkingtranslator.alllanguagetranslate.LT_Activity.LT_HistoryActivity;
import com.talkingtranslator.alllanguagetranslate.LT_Activity.LT_TextTranslationActivity;
import com.talkingtranslator.alllanguagetranslate.LT_Activity.LT_VoiceTranslationActivity;
import com.talkingtranslator.alllanguagetranslate.R;

public class LT_TabNotification extends Service {

    public static final String ACTION_START = "tab_start";
    public static final String ACTION_STOP = "tab_stop";

    public IBinder onBind(Intent intent) {
        return null;
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        if (intent != null) {
            if (intent.getAction().equals(ACTION_START)) {
                start();
            } else if (intent.getAction().equals(ACTION_STOP)) {
                stop();
            }
        }
        return super.onStartCommand(intent, i, i2);
    }

    private void start() {
        Notification notification;
        createNotificationChannel();
        RemoteViews remoteViews = new RemoteViews(getPackageName(), (int) R.layout.notification);
        remoteViews.setOnClickPendingIntent(R.id.translate_text_tab, generatePendingIntent(LT_TextTranslationActivity.class));
        remoteViews.setOnClickPendingIntent(R.id.translate_voice_tab, generatePendingIntent(LT_VoiceTranslationActivity.class));
        remoteViews.setOnClickPendingIntent(R.id.translate_camera_tab, generatePendingIntent(LT_CameraTranslationActivity.class));
        remoteViews.setOnClickPendingIntent(R.id.translate_history_tab, generatePendingIntent(LT_HistoryActivity.class));
        if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder ongoing = new Notification.Builder(getApplicationContext(), "translator").setContentTitle("").setContentText("").setCustomContentView(remoteViews).setStyle(new Notification.DecoratedCustomViewStyle()).setSmallIcon(R.mipmap.ic_launcher).setOngoing(true);
            if (Build.VERSION.SDK_INT >= 31) {
                ongoing.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
            }
            notification = ongoing.build();
        } else {
            notification = new NotificationCompat.Builder(getApplicationContext(), "translator").setContentTitle("").setContentText("").setCustomContentView(remoteViews).setStyle(new NotificationCompat.DecoratedCustomViewStyle()).setSmallIcon(R.mipmap.ic_launcher).setOngoing(true).build();
        }
        startForeground(1, notification);
    }

    private PendingIntent generatePendingIntent(Class<?> cls) {
        Intent intent = new Intent(this, cls);
        intent.putExtra("notification_click", cls.toString());
        intent.setAction("destination.toString()");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return PendingIntent.getActivity(getApplicationContext(), 0, intent, PendingIntent.FLAG_IMMUTABLE);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(new NotificationChannel("translator", "translator", NotificationManager.IMPORTANCE_LOW));
        }
    }

    private void stop() {
        if (Build.VERSION.SDK_INT >= 24) {
            stopForeground(Service.STOP_FOREGROUND_REMOVE);
        } else {
            stopForeground(true);
        }
        stopSelf();
    }
}