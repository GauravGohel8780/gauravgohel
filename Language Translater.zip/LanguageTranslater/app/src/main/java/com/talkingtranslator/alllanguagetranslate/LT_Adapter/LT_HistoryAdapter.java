package com.talkingtranslator.alllanguagetranslate.LT_Adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.talkingtranslator.alllanguagetranslate.R;
import com.talkingtranslator.alllanguagetranslate.LT_Utilies.LT_HitoryClick;
import com.talkingtranslator.alllanguagetranslate.LT_Utilies.LT_Translator_Constants;
import com.talkingtranslator.alllanguagetranslate.LT_model.LT_History_Model;

import java.util.List;

public class LT_HistoryAdapter extends RecyclerView.Adapter<LT_HistoryAdapter.ViewHolder> {

    private final List<LT_History_Model> list;
    private final LT_HitoryClick translator_listner;
    Activity context;
    LT_History_Model model;

    public LT_HistoryAdapter(Activity context2, List<LT_History_Model> list2, LT_HitoryClick listener) {
        context = context2;
        list = list2;
        translator_listner = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_history, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        model = list.get(i);
        viewHolder.tvSourceLang.setText(model.getSource_language());
        viewHolder.tvSourceText.setText(model.getSource_language_txt());
        viewHolder.tvTargetLang.setText(model.getTarget_language());
        viewHolder.tvTargetText.setText(model.getTarget_language_txt());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvSourceLang;
        TextView tvSourceText;
        TextView tvTargetLang;
        TextView tvTargetText;

        ViewHolder(View view) {
            super(view);
            tvSourceLang = (TextView) view.findViewById(R.id.tvSourceLang);
            tvSourceText = (TextView) view.findViewById(R.id.tvSourceText);
            tvTargetLang = (TextView) view.findViewById(R.id.tvTargetLang);
            tvTargetText = (TextView) view.findViewById(R.id.tvTargetText);

            view.setOnClickListener(view1 -> {
                model = (LT_History_Model) list.get(getAdapterPosition());
                LT_Translator_Constants.source_l = model.getSource_language();
                LT_Translator_Constants.source_t = model.getSource_language_txt();
                LT_Translator_Constants.target_l = model.getTarget_language();
                LT_Translator_Constants.target_t = model.getTarget_language_txt();
                LT_Translator_Constants.position = model.getId();
                translator_listner.onHistoryClick();
            });
        }
    }
}