package com.talkingtranslator.alllanguagetranslate.LT_Activity;


import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.google.firebase.perf.network.FirebasePerfHttpClient;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.talkingtranslator.alllanguagetranslate.Ads_Common.AdsBaseActivity;
import com.talkingtranslator.alllanguagetranslate.Database.Translator_DataManager;
import com.talkingtranslator.alllanguagetranslate.Database.Translator_Data_Helper;
import com.talkingtranslator.alllanguagetranslate.R;
import com.talkingtranslator.alllanguagetranslate.LT_Utilies.LT_Translator_Constants;
import com.talkingtranslator.alllanguagetranslate.LT_model.LT_Translator_Word;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class LT_WordGameActivity extends AdsBaseActivity {
    Button btnAns1;
    Button btnAns2;
    Button btnAns3;
    Button btnAns4;
    Translator_DataManager translator_DataManager;
    List<LT_Translator_Word> translator_item_data;
    String translator_strQuestion;
    int translator_toatal;
    TextView tvDisplayQuestion;
    TextView tvQuestion;
    int intRightAns = 0;
    int translator_intTotalQuestion = 10;
    int start = 1;

    String mText;
    Translator_Data_Helper Data_Helper;
    String data_ans_1;
    String data_ans_2;
    String data_ans_3;
    String data_ans_4;
    boolean data_Ans1_Translated = false;
    boolean data_Ans2_Translated = false;
    boolean data_Ans3_Translated = false;
    boolean data_Ans4_Translated = false;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_game);

        Data_Helper = new Translator_Data_Helper(LT_WordGameActivity.this);

        fvd();

        translator_DataManager = new Translator_DataManager(this);
        translator_item_data = new ArrayList();
        RadioQuestion();
        btnAns1.setOnClickListener(new Ans1());
        btnAns2.setOnClickListener(new Ans2());
        btnAns3.setOnClickListener(new Ans3());
        btnAns4.setOnClickListener(new Ans4());
    }

    void fvd() {
        ((TextView) findViewById(R.id.titles)).setText("Word Game");
        findViewById(R.id.ivBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(LT_WordGameActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        tvDisplayQuestion = (TextView) findViewById(R.id.tvDisplayQuestion);
        tvQuestion = (TextView) findViewById(R.id.tvQuestion);
        btnAns1 = (Button) findViewById(R.id.btnAns1);
        btnAns2 = (Button) findViewById(R.id.btnAns2);
        btnAns3 = (Button) findViewById(R.id.btnAns3);
        btnAns4 = (Button) findViewById(R.id.btnAns4);
    }

    class Ans1 implements View.OnClickListener {

        class tr_btnAns1 implements Runnable {
            tr_btnAns1() {
            }

            @Override
            public void run() {
                TextView textView = tvDisplayQuestion;
                StringBuilder sb = new StringBuilder();
                sb.append("Question : ");
                sb.append(translator_strQuestion + " of 10");
                textView.setText(sb.toString());
                RadioQuestion();
            }
        }


        @Override
        public void onClick(View view) {
            getInstance(LT_WordGameActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    if (btnAns1.getText().toString().equals(btnAns1.getTag())) {
                        btnAns1.setBackgroundResource(R.drawable.bg_wordgame_btn_correct);
                        btnAns1.startAnimation(AnimationUtils.loadAnimation(LT_WordGameActivity.this, R.anim.blink));

                        intRightAns++;
                        LT_WordGameActivity word_Game_activity = LT_WordGameActivity.this;
                        word_Game_activity.translator_toatal = word_Game_activity.intRightAns - translator_intTotalQuestion;
                    } else {
                        btnAns1.setBackgroundResource(R.drawable.bg_wordgame_btn_wrong);
                    }
                    if (btnAns2.getText().toString().equals(btnAns2.getTag())) {
                        btnAns2.setBackgroundResource(R.drawable.bg_wordgame_btn_correct);
                        btnAns2.startAnimation(AnimationUtils.loadAnimation(LT_WordGameActivity.this, R.anim.blink));
                    } else {
                        btnAns2.setBackgroundResource(R.drawable.bg_wordgame_btn_normal);
                    }
                    if (btnAns3.getText().toString().equals(btnAns3.getTag())) {
                        btnAns3.setBackgroundResource(R.drawable.bg_wordgame_btn_correct);
                        btnAns3.startAnimation(AnimationUtils.loadAnimation(LT_WordGameActivity.this, R.anim.blink));
                    } else {
                        btnAns3.setBackgroundResource(R.drawable.bg_wordgame_btn_normal);
                    }
                    if (btnAns4.getText().toString().equals(btnAns4.getTag())) {
                        btnAns4.setBackgroundResource(R.drawable.bg_wordgame_btn_correct);
                        btnAns4.startAnimation(AnimationUtils.loadAnimation(LT_WordGameActivity.this, R.anim.blink));
                    } else {
                        btnAns4.setBackgroundResource(R.drawable.bg_wordgame_btn_normal);
                    }
                    if (start < 10) {
                        start++;
                        LT_WordGameActivity word_Game_activity2 = LT_WordGameActivity.this;
                        word_Game_activity2.translator_strQuestion = String.valueOf(word_Game_activity2.start);
                        new Handler().postDelayed(new tr_btnAns1(), 1000L);
                    } else if (start == 10) {
                        showWinDialog(LT_WordGameActivity.this, intRightAns);
                    }
                }
            }, MAIN_CLICK);
        }
    }


    class Ans2 implements View.OnClickListener {

        class tr_btnAns2 implements Runnable {
            tr_btnAns2() {
            }

            @Override
            public void run() {
                TextView textView = tvDisplayQuestion;
                StringBuilder sb = new StringBuilder();
                sb.append("Question : ");
                sb.append(String.valueOf(translator_strQuestion) + " of 10");
                textView.setText(sb.toString());
                RadioQuestion();
            }
        }

        @Override
        public void onClick(View view) {
            getInstance(LT_WordGameActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    if (btnAns1.getText().toString().equals(btnAns1.getTag())) {
                        btnAns1.setBackgroundResource(R.drawable.bg_wordgame_btn_correct);
                        btnAns1.startAnimation(AnimationUtils.loadAnimation(LT_WordGameActivity.this, R.anim.blink));
                    } else {
                        btnAns1.setBackgroundResource(R.drawable.bg_wordgame_btn_normal);
                    }
                    if (btnAns2.getText().toString().equals(btnAns2.getTag())) {
                        btnAns2.setBackgroundResource(R.drawable.bg_wordgame_btn_correct);
                        btnAns2.startAnimation(AnimationUtils.loadAnimation(LT_WordGameActivity.this, R.anim.blink));
                        intRightAns++;
                        LT_WordGameActivity word_Game_activity = LT_WordGameActivity.this;
                        word_Game_activity.translator_toatal = word_Game_activity.intRightAns - translator_intTotalQuestion;
                    } else {
                        btnAns2.setBackgroundResource(R.drawable.bg_wordgame_btn_wrong);
                    }
                    if (btnAns3.getText().toString().equals(btnAns3.getTag())) {
                        btnAns3.setBackgroundResource(R.drawable.bg_wordgame_btn_correct);
                        btnAns3.startAnimation(AnimationUtils.loadAnimation(LT_WordGameActivity.this, R.anim.blink));
                    } else {
                        btnAns3.setBackgroundResource(R.drawable.bg_wordgame_btn_normal);
                    }
                    if (btnAns4.getText().toString().equals(btnAns4.getTag())) {
                        btnAns4.setBackgroundResource(R.drawable.bg_wordgame_btn_correct);
                        btnAns4.startAnimation(AnimationUtils.loadAnimation(LT_WordGameActivity.this, R.anim.blink));
                    } else {
                        btnAns4.setBackgroundResource(R.drawable.bg_wordgame_btn_normal);
                    }
                    if (start < 10) {
                        start++;
                        LT_WordGameActivity word_Game_activity2 = LT_WordGameActivity.this;
                        word_Game_activity2.translator_strQuestion = String.valueOf(word_Game_activity2.start);
                        new Handler().postDelayed(new tr_btnAns2(), 1000L);
                    } else if (start == 10) {
                        showWinDialog(LT_WordGameActivity.this, intRightAns);
                    }
                }
            }, MAIN_CLICK);
        }
    }


    class Ans3 implements View.OnClickListener {


        class tr_btnAns3 implements Runnable {
            tr_btnAns3() {
            }

            @Override
            public void run() {
                StringBuilder sb = new StringBuilder();
                sb.append("Question : ");
                sb.append(translator_strQuestion + " of 10");
                tvDisplayQuestion.setText(sb.toString());
                RadioQuestion();
            }
        }

        @Override
        public void onClick(View view) {
            getInstance(LT_WordGameActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    if (btnAns1.getText().toString().equals(btnAns1.getTag())) {
                        btnAns1.setBackgroundResource(R.drawable.bg_wordgame_btn_correct);
                        btnAns1.startAnimation(AnimationUtils.loadAnimation(LT_WordGameActivity.this, R.anim.blink));
                    } else {
                        btnAns1.setBackgroundResource(R.drawable.bg_wordgame_btn_normal);
                    }
                    if (btnAns2.getText().toString().equals(btnAns2.getTag())) {
                        btnAns2.setBackgroundResource(R.drawable.bg_wordgame_btn_correct);
                        btnAns2.startAnimation(AnimationUtils.loadAnimation(LT_WordGameActivity.this, R.anim.blink));
                    } else {
                        btnAns2.setBackgroundResource(R.drawable.bg_wordgame_btn_normal);
                    }
                    if (btnAns3.getText().toString().equals(btnAns3.getTag())) {
                        btnAns3.setBackgroundResource(R.drawable.bg_wordgame_btn_correct);
                        btnAns3.startAnimation(AnimationUtils.loadAnimation(LT_WordGameActivity.this, R.anim.blink));
                        intRightAns++;
                        LT_WordGameActivity word_Game_activity = LT_WordGameActivity.this;
                        word_Game_activity.translator_toatal = word_Game_activity.intRightAns - translator_intTotalQuestion;
                    } else {
                        btnAns3.setBackgroundResource(R.drawable.bg_wordgame_btn_wrong);
                    }
                    if (btnAns4.getText().toString().equals(btnAns4.getTag())) {
                        btnAns4.setBackgroundResource(R.drawable.bg_wordgame_btn_correct);
                        btnAns4.startAnimation(AnimationUtils.loadAnimation(LT_WordGameActivity.this, R.anim.blink));
                    } else {
                        btnAns4.setBackgroundResource(R.drawable.bg_wordgame_btn_normal);
                    }
                    if (start < 10) {
                        start++;
                        LT_WordGameActivity word_Game_activity2 = LT_WordGameActivity.this;
                        word_Game_activity2.translator_strQuestion = String.valueOf(word_Game_activity2.start);
                        new Handler().postDelayed(new tr_btnAns3(), 1000L);
                    } else if (start == 10) {
                        showWinDialog(LT_WordGameActivity.this, intRightAns);
                    }
                }
            }, MAIN_CLICK);
        }
    }


    class Ans4 implements View.OnClickListener {


        class tr_btnAns4 implements Runnable {
            tr_btnAns4() {
            }

            @Override
            public void run() {
                TextView textView = tvDisplayQuestion;
                StringBuilder sb = new StringBuilder();
                sb.append("Question : ");
                sb.append(translator_strQuestion + " of 10");
                textView.setText(sb.toString());
                RadioQuestion();
            }
        }

        @Override
        public void onClick(View view) {
            getInstance(LT_WordGameActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    if (btnAns1.getText().toString().equals(btnAns1.getTag())) {
                        btnAns1.setBackgroundResource(R.drawable.bg_wordgame_btn_correct);
                        btnAns1.startAnimation(AnimationUtils.loadAnimation(LT_WordGameActivity.this, R.anim.blink));
                    } else {
                        btnAns1.setBackgroundResource(R.drawable.bg_wordgame_btn_normal);
                    }
                    if (btnAns2.getText().toString().equals(btnAns2.getTag())) {
                        btnAns2.setBackgroundResource(R.drawable.bg_wordgame_btn_correct);
                        btnAns2.startAnimation(AnimationUtils.loadAnimation(LT_WordGameActivity.this, R.anim.blink));
                    } else {
                        btnAns2.setBackgroundResource(R.drawable.bg_wordgame_btn_normal);
                    }
                    if (btnAns3.getText().toString().equals(btnAns3.getTag())) {
                        btnAns3.setBackgroundResource(R.drawable.bg_wordgame_btn_correct);
                        btnAns3.startAnimation(AnimationUtils.loadAnimation(LT_WordGameActivity.this, R.anim.blink));
                    } else {
                        btnAns3.setBackgroundResource(R.drawable.bg_wordgame_btn_normal);
                    }
                    if (btnAns4.getText().toString().equals(btnAns4.getTag())) {
                        btnAns4.setBackgroundResource(R.drawable.bg_wordgame_btn_correct);
                        btnAns4.startAnimation(AnimationUtils.loadAnimation(LT_WordGameActivity.this, R.anim.blink));
                        intRightAns++;
                        translator_toatal = intRightAns - translator_intTotalQuestion;
                    } else {
                        btnAns4.setBackgroundResource(R.drawable.bg_wordgame_btn_wrong);
                    }
                    if (start < 10) {
                        start++;
                        translator_strQuestion = String.valueOf(start);
                        new Handler().postDelayed(new tr_btnAns4(), 1000L);
                    } else if (start == 10) {
                        showWinDialog(LT_WordGameActivity.this, intRightAns);
                    }
                }
            }, MAIN_CLICK);
        }
    }

    public void showWinDialog(Activity activity, int intRightAns) {
        final Dialog dialog = new Dialog(activity, R.style.MyDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog_winning);
        LottieAnimationView sad, happy;
        TextView tvResult, tvScore;
        TextView btn_back;
        sad = dialog.findViewById(R.id.sad);
        happy = dialog.findViewById(R.id.happy);
        tvResult = dialog.findViewById(R.id.tvResult);
        tvScore = dialog.findViewById(R.id.tvScore);
        btn_back = dialog.findViewById(R.id.tvBack);
        if (intRightAns >= 5) {
            tvResult.setText("Victory");
            happy.setVisibility(View.VISIBLE);
            sad.setVisibility(View.GONE);
        } else {
            tvResult.setText("Failure");
            happy.setVisibility(View.GONE);
            sad.setVisibility(View.VISIBLE);
        }
        tvScore.setText("" + intRightAns);
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(LT_WordGameActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        dialog.dismiss();
                        onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

        dialog.show();
    }

    int tagManager = -1;

    public void RadioQuestion() {
        btnAns1.setBackgroundResource(R.drawable.bg_wordgame_btn_normal);
        btnAns2.setBackgroundResource(R.drawable.bg_wordgame_btn_normal);
        btnAns3.setBackgroundResource(R.drawable.bg_wordgame_btn_normal);
        btnAns4.setBackgroundResource(R.drawable.bg_wordgame_btn_normal);
        translator_item_data.clear();
        translator_item_data = translator_DataManager.Quiz();
        int generateRandomNumberInRange = LT_Translator_Constants.generateRandomNumberInRange(0, 3);
        if (generateRandomNumberInRange == 0) {
            tvQuestion.setText(translator_item_data.get(0).getWord());

            try {
                tagManager = 0;
                Translate2(translator_item_data.get(0).getMeaning());
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

        } else if (generateRandomNumberInRange == 1) {
            tvQuestion.setText(translator_item_data.get(1).getWord());
            try {
                tagManager = 1;
                Translate2(translator_item_data.get(1).getMeaning());
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

        } else if (generateRandomNumberInRange == 2) {
            tvQuestion.setText(translator_item_data.get(2).getWord());
            try {
                tagManager = 2;
                Translate2(translator_item_data.get(2).getMeaning());
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        } else if (generateRandomNumberInRange == 3) {
            tvQuestion.setText(translator_item_data.get(3).getWord());
            try {
                tagManager = 3;
                Translate2(translator_item_data.get(3).getMeaning());
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }

        data_ans_1 = translator_item_data.get(0).getMeaning();
        data_ans_2 = translator_item_data.get(1).getMeaning();
        data_ans_3 = translator_item_data.get(2).getMeaning();
        data_ans_4 = translator_item_data.get(3).getMeaning();

        try {
            data_Ans1_Translated = false;
            data_Ans2_Translated = false;
            data_Ans3_Translated = false;
            data_Ans4_Translated = false;
            btnAns1.setText("Loading...");
            btnAns2.setText("Loading...");
            btnAns3.setText("Loading...");
            btnAns4.setText("Loading...");

            if (!data_Ans1_Translated) {
                Translate(data_ans_1);
            }
        } catch (UnsupportedEncodingException e) {

        }
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        finish();
    }

    public void Translate2(String targetText) throws UnsupportedEncodingException {
        mText = URLEncoder.encode(targetText, "UTF-8");
        new ReadLanguageTask2().execute("https://translate.googleapis.com/translate_a/single?client=gtx&sl=" + "hi" + "&tl=" + "es" + "&dt=t&ie=UTF-8&oe=UTF-8&q=" + mText);
    }

    public class ReadLanguageTask2 extends AsyncTask<String, Void, String> {
        private ReadLanguageTask2() {
        }

        public String doInBackground(String... strArr) {
            return readJSON(strArr[0]);
        }

        public void onPostExecute(String str) {
            if (!str.equals("[\"ERROR\"]")) {
                try {

                    JSONArray jSONArray = new JSONArray(str);
                    String datum = "";
                    for (int i = 0; i < jSONArray.getJSONArray(0).length(); i++) {
                        datum = datum + jSONArray.getJSONArray(0).getJSONArray(i).getString(0);
                    }

                    if (tagManager == 0) {
                        btnAns1.setTag(datum);
                    } else if (tagManager == 1) {
                        btnAns2.setTag(datum);
                    } else if (tagManager == 2) {
                        btnAns3.setTag(datum);
                    } else if (tagManager == 3) {
                        btnAns4.setTag(datum);
                    }


                } catch (Exception unused) {

                }
            }

        }
    }


    public void Translate(String targetText) throws UnsupportedEncodingException {
        mText = URLEncoder.encode(targetText, "UTF-8");
        new ReadLanguageTask().execute("https://translate.googleapis.com/translate_a/single?client=gtx&sl=" + "hi" + "&tl=" + "es" + "&dt=t&ie=UTF-8&oe=UTF-8&q=" + mText);
    }

    public class ReadLanguageTask extends AsyncTask<String, Void, String> {
        private ReadLanguageTask() {
        }

        public String doInBackground(String... strArr) {
            return readJSON(strArr[0]);
        }

        public void onPostExecute(String str) {
            if (!str.equals("[\"ERROR\"]")) {
                try {

                    JSONArray jSONArray = new JSONArray(str);
                    String datum = "";
                    for (int i = 0; i < jSONArray.getJSONArray(0).length(); i++) {
                        datum = datum + jSONArray.getJSONArray(0).getJSONArray(i).getString(0);
                    }

                    if (!data_Ans1_Translated) {
                        btnAns1.setText(datum);
                        data_Ans1_Translated = true;

                        if (!data_Ans2_Translated) {
                            Translate(data_ans_2);
                        } else if (!data_Ans3_Translated) {
                            Translate(data_ans_3);
                        } else if (!data_Ans4_Translated) {
                            Translate(data_ans_4);
                        }

                    } else if (!data_Ans2_Translated) {
                        btnAns2.setText(datum);
                        data_Ans2_Translated = true;

                        if (!data_Ans3_Translated) {
                            Translate(data_ans_3);
                        } else if (!data_Ans4_Translated) {
                            Translate(data_ans_4);
                        }
                    } else if (!data_Ans3_Translated) {
                        btnAns3.setText(datum);
                        data_Ans3_Translated = true;

                        if (!data_Ans4_Translated) {
                            Translate(data_ans_4);
                        }
                    } else if (!data_Ans4_Translated) {
                        btnAns4.setText(datum);
                        data_Ans4_Translated = true;
                    }

                } catch (Exception unused) {

                }
            }

        }
    }


    public String readJSON(String str) {
        StringBuilder sb = new StringBuilder();
        try {
            HttpResponse execute = FirebasePerfHttpClient.execute(new DefaultHttpClient(), new HttpGet(str));
            if (execute == null) {
                System.out.println(R.string.download_failed);
            } else if (execute.getStatusLine().getStatusCode() == 200) {
                InputStream content = execute.getEntity().getContent();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(content));
                while (true) {
                    String readLine = bufferedReader.readLine();
                    if (readLine == null) {
                        break;
                    }
                    sb.append(readLine);
                }
                content.close();
            } else {
                Toast.makeText(LT_WordGameActivity.this, (int) R.string.error, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            sb.append("[\"ERROR\"]");
        }
        return sb.toString();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
