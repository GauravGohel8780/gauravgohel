package com.talkingtranslator.alllanguagetranslate.Database;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class Translator_DataBaseHelper extends SQLiteOpenHelper {
    public static String DB_NAME = "Database";
    public static String DB_PATH;
    public final Context context;
    public SQLiteDatabase database;

    public Translator_DataBaseHelper(Context context) {
        super(context, DB_NAME, (SQLiteDatabase.CursorFactory) null, 1);
        this.context = context;
        DB_PATH = String.format("//data//data//%s//databases//", context.getPackageName());
        openDataBase();
    }

    @Override
    public void onCreate(SQLiteDatabase sQLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {

    }


    public void createDataBase() {
        if (checkDataBase()) {
            return;
        }
        getReadableDatabase();
        try {
            copyDataBase();
        } catch (IOException unused) {
            throw new Error("Error copying database!");
        }
    }

    private boolean checkDataBase() {
        SQLiteDatabase sQLiteDatabase = null;
        try {
            sQLiteDatabase = SQLiteDatabase.openDatabase(DB_PATH + DB_NAME, null, 1);
        } catch (SQLException unused) {
        }
        if (sQLiteDatabase != null) {
            sQLiteDatabase.close();
        }
        return sQLiteDatabase != null;
    }

    private void copyDataBase() throws IOException {
        InputStream open = context.getAssets().open(DB_NAME);
        FileOutputStream fileOutputStream = new FileOutputStream(DB_PATH + DB_NAME);
        byte[] bArr = new byte[1024];
        while (true) {
            int read = open.read(bArr);
            if (read > 0) {
                fileOutputStream.write(bArr, 0, read);
            } else {
                fileOutputStream.close();
                open.close();
                return;
            }
        }
    }

    public SQLiteDatabase openDataBase() throws SQLException {
        String str = DB_PATH + DB_NAME;
        if (database == null) {
            createDataBase();
            database = SQLiteDatabase.openDatabase(str, null, 0);
        }
        return database;
    }

    @Override
    public synchronized void close() {
        if (database != null) {
            database.close();
        }
        super.close();
    }

    @Override
    public void onOpen(SQLiteDatabase sQLiteDatabase) {
        super.onOpen(sQLiteDatabase);
        sQLiteDatabase.disableWriteAheadLogging();
    }
}
