package com.talkingtranslator.alllanguagetranslate.LT_ExtraScreen.Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.iten.tenoku.utils.AdUtils;
import com.talkingtranslator.alllanguagetranslate.Ads_Common.AdsBaseActivity;
import com.talkingtranslator.alllanguagetranslate.R;


public class LT_ThankyouActivity extends AdsBaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.thankyou_activity);


        findViewById(R.id.ivOk).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finishAffinity();
            }
        });
        findViewById(R.id.ivCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LT_ThankyouActivity.this, LT_StartActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}
