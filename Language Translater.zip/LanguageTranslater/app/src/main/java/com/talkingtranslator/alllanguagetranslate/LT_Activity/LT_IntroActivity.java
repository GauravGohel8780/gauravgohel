package com.talkingtranslator.alllanguagetranslate.LT_Activity;


import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.tabs.TabLayout;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.talkingtranslator.alllanguagetranslate.Ads_Common.AdsBaseActivity;
import com.talkingtranslator.alllanguagetranslate.R;
import com.talkingtranslator.alllanguagetranslate.LT_ExtraScreen.Activity.LT_PermissionActivity;
import com.talkingtranslator.alllanguagetranslate.LT_ExtraScreen.Activity.LT_StartActivity;
import com.talkingtranslator.alllanguagetranslate.LT_ExtraScreen.Utils.LT_Glob;

import java.util.ArrayList;
import java.util.List;

public class LT_IntroActivity extends AdsBaseActivity {

    Animation btnAnim;
    TextView tvStart;
    ImageView ivIndicator;
    Wifi_IntroViewPagerAdapter introViewPagerAdapter;
    TextView tvNext;
    int position = 0;
    private ViewPager vpScreenViewpager;
    TabLayout tab_indicator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        SetSystemFullScreen();
        setContentView(R.layout.activity_intro);

        final ArrayList arrayList = new ArrayList();
        arrayList.add(new Wifi_ScreenItem(getString(R.string.intro_1), R.drawable.ic_intro_logo_1));
        arrayList.add(new Wifi_ScreenItem(getString(R.string.intro_2), R.drawable.ic_intro_logo_2));
        arrayList.add(new Wifi_ScreenItem(getString(R.string.intro_3), R.drawable.ic_intro_logo_3));
        this.vpScreenViewpager = (ViewPager) findViewById(R.id.vpScreenViewpager);
        this.tab_indicator = (TabLayout) findViewById(R.id.tab_indicator);
        this.ivIndicator = (ImageView) findViewById(R.id.ivIndicator);
        this.tvNext = (TextView) findViewById(R.id.tvNext);
        this.tvStart = (TextView) findViewById(R.id.tvStart);
        Wifi_IntroViewPagerAdapter introViewPagerAdapter = new Wifi_IntroViewPagerAdapter(this, arrayList);
        this.introViewPagerAdapter = introViewPagerAdapter;
        this.vpScreenViewpager.setAdapter(introViewPagerAdapter);
        this.tab_indicator.setupWithViewPager(this.vpScreenViewpager);
        findViewById(R.id.tvNext).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(LT_IntroActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        LT_IntroActivity intro_Activity = LT_IntroActivity.this;
                        intro_Activity.position = intro_Activity.vpScreenViewpager.getCurrentItem();
                        if (position < arrayList.size()) {
                            position++;
                            vpScreenViewpager.setCurrentItem(position);
                        }
                        if (position == arrayList.size() - 1) {
                            loaddLastScreen();
                        }
                    }
                }, MAIN_CLICK);
            }
        });
        this.tab_indicator.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    ivIndicator.setImageResource(R.drawable.ic_intro_page_1);
                } else if (tab.getPosition() == 1) {
                    ivIndicator.setImageResource(R.drawable.ic_intro_page_2);
                } else if (tab.getPosition() == 2) {
                    ivIndicator .setImageResource(R.drawable.ic_intro_page_3);
                }
                if (tab.getPosition() == arrayList.size() - 1) {
                    loaddLastScreen();
                }
                if (tab.getPosition() == arrayList.size() - 2) {
                    tvNext.setVisibility(View.VISIBLE);
                    tvStart.setVisibility(View.INVISIBLE);
                    tab_indicator.setVisibility(View.INVISIBLE);
                }
            }
        });
        this.tvStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                if (!LT_Glob.checkPermissionForExternalStorage(LT_IntroActivity.this)) {
                    startActivity(new Intent(LT_IntroActivity.this, LT_PermissionActivity.class));
                    finish();
                } else {
                    startActivity(new Intent(LT_IntroActivity.this, LT_StartActivity.class));
                    finish();
                }
            }
        });
    }

    public void loaddLastScreen() {
        this.tvNext.setVisibility(View.INVISIBLE);
        this.tvStart.setVisibility(View.VISIBLE);
        this.tab_indicator.setVisibility(View.INVISIBLE);
        this.tvStart.setAnimation(this.btnAnim);
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        finishAffinity();
    }

    public class Wifi_IntroViewPagerAdapter extends PagerAdapter {
        Context mContext;
        List<Wifi_ScreenItem> mListScreen;

        @Override
        public boolean isViewFromObject(View view, Object obj) {
            return view == obj;
        }

        public Wifi_IntroViewPagerAdapter(Context context, List<Wifi_ScreenItem> list) {
            this.mContext = context;
            this.mListScreen = list;
        }

        @Override
        public Object instantiateItem(ViewGroup viewGroup, int i) {
            View inflate = ((LayoutInflater) this.mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.layout_introscreen, (ViewGroup) null);
            ((TextView) inflate.findViewById(R.id.tv_IntroDescription)).setText(this.mListScreen.get(i).getDescription());
            ((ImageView) inflate.findViewById(R.id.ivIntro)).setImageResource(this.mListScreen.get(i).getScreenImg());
            viewGroup.addView(inflate);
            return inflate;
        }

        @Override
        public int getCount() {
            return this.mListScreen.size();
        }

        @Override
        public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
            viewGroup.removeView((View) obj);
        }
    }

    public class Wifi_ScreenItem {
        String Description;
        int ScreenImg;

        public Wifi_ScreenItem(String str2, int i) {
            this.Description = str2;
            this.ScreenImg = i;
        }

        public String getDescription() {
            return this.Description;
        }

        public int getScreenImg() {
            return this.ScreenImg;
        }
    }

    public void SetSystemFullScreen() {
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) { // lower api
            View v = getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }

}