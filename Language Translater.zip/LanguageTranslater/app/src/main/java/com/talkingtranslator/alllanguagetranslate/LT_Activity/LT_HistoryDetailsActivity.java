package com.talkingtranslator.alllanguagetranslate.LT_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.talkingtranslator.alllanguagetranslate.Ads_Common.AdsBaseActivity;
import com.talkingtranslator.alllanguagetranslate.Database.Translator_Data_Helper;
import com.talkingtranslator.alllanguagetranslate.R;
import com.talkingtranslator.alllanguagetranslate.LT_Utilies.LT_Translator_Constants;


public class LT_HistoryDetailsActivity extends AdsBaseActivity {

    ImageView ivCopy;
    ImageView iv_Delete;
    Translator_Data_Helper translator_helper;
    ImageView ivShare;
    TextView tvSourceDetaleLabel;
    TextView tvSourceDetaile;
    TextView tvTargetDetaleLabel;
    TextView tvTargetDtaileText;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_historydetails);


        findViewById(R.id.ivBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(LT_HistoryDetailsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

        TextView titles = findViewById(R.id.titles);
        titles.setText("History Details");

        translator_helper = new Translator_Data_Helper(getApplicationContext());
        tvSourceDetaleLabel = (TextView) findViewById(R.id.tvSourceDetaleLabel);
        tvTargetDetaleLabel = (TextView) findViewById(R.id.tvTargetDetaleLabel);
        tvSourceDetaile = (TextView) findViewById(R.id.tvSourceDetaile);
        tvTargetDtaileText = (TextView) findViewById(R.id.tvTargetDtaileText);
        tvSourceDetaile.setMovementMethod(new ScrollingMovementMethod());
        tvTargetDtaileText.setMovementMethod(new ScrollingMovementMethod());

        ivCopy = (ImageView) findViewById(R.id.ivCopy);
        tvSourceDetaleLabel.setText(LT_Translator_Constants.source_l);
        tvTargetDetaleLabel.setText(LT_Translator_Constants.target_l);
        tvSourceDetaile.setText(LT_Translator_Constants.source_t);
        tvTargetDtaileText.setText(LT_Translator_Constants.target_t);
        iv_Delete = (ImageView) findViewById(R.id.iv_Delete);
        ivShare = (ImageView) findViewById(R.id.ivShare);

        iv_Delete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (translator_helper.delTrans(String.valueOf(LT_Translator_Constants.position)).intValue() == 1) {
                    getInstance(LT_HistoryDetailsActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            Toast.makeText(LT_HistoryDetailsActivity.this, R.string.deleted, Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }, MAIN_CLICK);
                }
            }
        });

        ivShare.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                try {
                    Intent intent = new Intent("android.intent.action.SEND");
                    intent.setType("text/plain");
                    intent.putExtra("android.intent.extra.SUBJECT", R.string.app_name);
                    intent.putExtra("android.intent.extra.TEXT", (((getString(R.string.translation_result) + "\n\n") + LT_Translator_Constants.source_t + "\n") + LT_Translator_Constants.target_t + "\n"));
                    startActivity(Intent.createChooser(intent, getString(R.string.share_via)));
                } catch (Exception unused) {
                    Toast.makeText(LT_HistoryDetailsActivity.this, (int) R.string.error, Toast.LENGTH_SHORT).show();
                }
            }
        });

        ivCopy.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (tvTargetDtaileText.getText().toString().length() != 0) {
                    getInstance(LT_HistoryDetailsActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Copy", tvTargetDtaileText.getText().toString()));
                            Toast.makeText(LT_HistoryDetailsActivity.this, R.string.text_copied, Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }, MAIN_CLICK);
                }
                Toast.makeText(LT_HistoryDetailsActivity.this, R.string.nothing_to_copy, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}