package com.talkingtranslator.alllanguagetranslate.LT_ExtraScreen.Utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SharePrefUtils {
    private static SharedPreferences mPreferences;
    public static final String FistTimeEnter = "FistTimeEnter";

    private static SharedPreferences getInstance(Context context) {
        if (mPreferences == null) {
            mPreferences = context.getApplicationContext()
                    .getSharedPreferences("all_saver_data", Context.MODE_PRIVATE);
        }
        return mPreferences;
    }

    public static void setFistTimeEnter(Context context, boolean value) {
        getInstance(context).edit().putBoolean(FistTimeEnter, value).apply();
    }

    public static boolean getFistTimeEnter(Context context) {
        return getInstance(context).getBoolean(FistTimeEnter, false);
    }
}
