package com.talkingtranslator.alllanguagetranslate.Database;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.talkingtranslator.alllanguagetranslate.LT_model.LT_Translator_Word;

import java.util.ArrayList;
import java.util.List;


public class Translator_DataManager {
    public SQLiteDatabase db;
    public Translator_DataBaseHelper myDbHelper;

    public Translator_DataManager(Context context) {
        myDbHelper = new Translator_DataBaseHelper(context);
        myDbHelper.createDataBase();
        try {
            myDbHelper.openDataBase();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        db = myDbHelper.getReadableDatabase();
    }

    public List<LT_Translator_Word> Quiz() {
        Cursor rawQuery = db.rawQuery("SELECT * FROM Dictionary ORDER BY RANDOM() LIMIT 4 ;", null);
        ArrayList arrayList = new ArrayList();
        if (rawQuery.getCount() == 0 || !rawQuery.moveToFirst()) {
            return arrayList;
        }
        do {
            LT_Translator_Word trWord = new LT_Translator_Word();
            trWord.id = rawQuery.getString(rawQuery.getColumnIndex("Id"));
            trWord.word = rawQuery.getString(rawQuery.getColumnIndex("Word"));
            trWord.meaning = rawQuery.getString(rawQuery.getColumnIndex("Meaning"));
            arrayList.add(trWord);
        } while (rawQuery.moveToNext());
        return arrayList;
    }

}
