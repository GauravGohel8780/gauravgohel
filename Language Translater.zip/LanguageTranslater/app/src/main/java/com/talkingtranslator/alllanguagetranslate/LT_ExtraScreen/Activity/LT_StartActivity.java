package com.talkingtranslator.alllanguagetranslate.LT_ExtraScreen.Activity;


import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.talkingtranslator.alllanguagetranslate.LT_Activity.LT_HomeActivity;
import com.talkingtranslator.alllanguagetranslate.Ads_Common.AdsBaseActivity;
import com.talkingtranslator.alllanguagetranslate.R;

import java.io.File;
import java.io.FileOutputStream;


public class LT_StartActivity extends AdsBaseActivity {

    private ImageView ivShare, ivRate, ivPrivacy;
    RelativeLayout rlStart;
    public static boolean backad = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.start_activity);


        rlStart = findViewById(R.id.rlStart);
        ivShare = findViewById(R.id.ivShare);
        ivRate = findViewById(R.id.ivRate);
        ivPrivacy = findViewById(R.id.ivPrivacy);

        findViewById(R.id.ivBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(LT_StartActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        rlStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Next();
            }
        });
        ivShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                share(LT_StartActivity.this);
            }
        });
        ivRate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoStore(LT_StartActivity.this);
            }
        });
        ivPrivacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(LT_StartActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        startActivity(new Intent(LT_StartActivity.this, WebActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    }
                }, MAIN_CLICK);
            }
        });
    }

    public static void gotoStore(Context context) {
        Uri uri = Uri.parse("market://details?id=" + context.getPackageName());
        Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
        try {
            myAppLinkToMarket.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(myAppLinkToMarket);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(context, "Please Check Internet Connenction", Toast.LENGTH_LONG).show();
        }
    }

    public static void share(Context context) {
        Bitmap bm = BitmapFactory.decodeResource(context.getResources(), R.mipmap.banner);
        File f = new File(context.getExternalCacheDir() + "/image.png");
        try {
            FileOutputStream outStream = new FileOutputStream(f);
            bm.compress(Bitmap.CompressFormat.PNG, 100, outStream);
            outStream.flush();
            outStream.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("image/*");
        shareIntent.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=" + context.getPackageName());
        Uri urishare;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            urishare = FileProvider.getUriForFile(context, context.getPackageName() + ".provider", f);
        } else {
            urishare = Uri.fromFile(f);
        }
        shareIntent.putExtra(Intent.EXTRA_STREAM, urishare);
        context.startActivity(Intent.createChooser(shareIntent, "Share Image using"));
    }

    private void Next() {
        getInstance(LT_StartActivity.this).ShowAd(new HandleClick() {
            @Override
            public void Show(boolean adShow) {
                startActivity(new Intent(LT_StartActivity.this, LT_HomeActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        }, MAIN_CLICK);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        backad = true;
        startActivity(new Intent(LT_StartActivity.this, LT_ThankyouActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));}

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}
