package com.talkingtranslator.alllanguagetranslate.LT_Activity;


import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.perf.network.FirebasePerfHttpClient;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.talkingtranslator.alllanguagetranslate.Ads_Common.AdsBaseActivity;
import com.talkingtranslator.alllanguagetranslate.Database.Translator_Data_Helper;
import com.talkingtranslator.alllanguagetranslate.R;
import com.talkingtranslator.alllanguagetranslate.LT_Utilies.LT_Translator_Constants;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;


public class LT_WordOfTheDayActivity extends AdsBaseActivity {

    final String[] arr_a = LT_Translator_Constants.array_a;
    final String[] arr_b = LT_Translator_Constants.array_b;
    final String[] arr_c = LT_Translator_Constants.array_c;
    final String[] arr_d = LT_Translator_Constants.array_d;
    Calendar cal;
    int position;
    TextView tv1;
    TextView tv2;
    TextView tv3;
    TextView tv4;
    TextView tvDate;
    String mText;
    Translator_Data_Helper Data_Helper;
    String data_B;
    String data_D;
    boolean data_B_Translated = false;
    boolean data_D_Translated = false;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_wordoftheday);


        Data_Helper = new Translator_Data_Helper(LT_WordOfTheDayActivity.this);

        ((TextView) findViewById(R.id.titles)).setText("Word Of The Day");
        ((ImageView) findViewById(R.id.ivBack)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(LT_WordOfTheDayActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        init();
        cal = Calendar.getInstance();

        StringBuilder sb = new StringBuilder(new SimpleDateFormat("dd-MM-yyyy").format(cal.getTime()));
        sb.append(" ");
        tvDate.setText(sb);
        int i = cal.get(6);
        int i2 = i - 1;
        position = i2;


        tv1.setText(arr_a[i2]);
        tv3.setText(arr_c[position]);

        data_B = arr_b[i2];
        data_D = arr_d[position];

        try {
            if (!data_B_Translated) {
                Translate(data_B);
            }
        } catch (UnsupportedEncodingException e) {
        }


    }

    void init() {
        tv1 = (TextView) findViewById(R.id.tv1);
        tv2 = (TextView) findViewById(R.id.tv2);
        tv3 = (TextView) findViewById(R.id.tv3);
        tv4 = (TextView) findViewById(R.id.tv4);
        tvDate = (TextView) findViewById(R.id.tvDate);

    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        finish();
    }


    public void Translate(String targetText) throws UnsupportedEncodingException {
        mText = URLEncoder.encode(targetText, "UTF-8");
        new ReadLanguageTask().execute("https://translate.googleapis.com/translate_a/single?client=gtx&sl=" + "hi" + "&tl=" + "es" + "&dt=t&ie=UTF-8&oe=UTF-8&q=" + mText);
    }

    public class ReadLanguageTask extends AsyncTask<String, Void, String> {
        private ReadLanguageTask() {
        }

        public String doInBackground(String... strArr) {
            return readJSON(strArr[0]);
        }

        public void onPostExecute(String str) {
            if (!str.equals("[\"ERROR\"]")) {
                try {

                    JSONArray jSONArray = new JSONArray(str);
                    String str2 = "";
                    for (int i = 0; i < jSONArray.getJSONArray(0).length(); i++) {
                        str2 = str2 + jSONArray.getJSONArray(0).getJSONArray(i).getString(0);
                    }

                    if (!data_B_Translated) {
                        tv2.setText(str2);
                        data_B_Translated = true;

                        if (!data_D_Translated) {
                            Translate(data_D);
                        }

                    } else if (!data_D_Translated) {
                        tv4.setText(str2);
                        data_D_Translated = true;
                    }
                } catch (Exception unused) {
                }
            }
        }
    }


    public String readJSON(String str) {
        StringBuilder sb = new StringBuilder();
        try {
            HttpResponse execute = FirebasePerfHttpClient.execute(new DefaultHttpClient(), new HttpGet(str));
            if (execute == null) {
                System.out.println(R.string.download_failed);
            } else if (execute.getStatusLine().getStatusCode() == 200) {
                InputStream content = execute.getEntity().getContent();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(content));
                while (true) {
                    String readLine = bufferedReader.readLine();
                    if (readLine == null) {
                        break;
                    }
                    sb.append(readLine);
                }
                content.close();
            } else {
                Toast.makeText(LT_WordOfTheDayActivity.this, (int) R.string.error, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            sb.append("[\"ERROR\"]");
        }
        return sb.toString();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}
