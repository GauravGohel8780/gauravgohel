package com.talkingtranslator.alllanguagetranslate.LT_ExtraScreen.Activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.talkingtranslator.alllanguagetranslate.LT_ExtraScreen.Utils.SharePrefUtils;
import com.talkingtranslator.alllanguagetranslate.R;
import com.talkingtranslator.alllanguagetranslate.LT_ExtraScreen.Utils.LT_Glob;

public class LT_PermissionActivity extends AppCompatActivity {

    FrameLayout flPermission;
    ImageView ivStorage, ivOverlay, ivCamera, ivCheckStorage, ivCheckOverlay, ivSeleCamera, ivAllowSelct, ivAllowUnslect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(getResources().getColor(R.color.yellow));
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        ivStorage = findViewById(R.id.ivStorage);
        ivOverlay = findViewById(R.id.ivOverlay);
        ivCamera = findViewById(R.id.ivCamera);
        ivCheckStorage = findViewById(R.id.ivCheckStorage);
        ivCheckOverlay = findViewById(R.id.ivCheckOverlay);
        ivSeleCamera = findViewById(R.id.ivSeleCamera);
        flPermission = findViewById(R.id.flPermission);
        ivAllowSelct = findViewById(R.id.ivAllowSelct);
        ivAllowUnslect = findViewById(R.id.ivAllowUnslect);


        if (LT_Glob.isPermissionForExternalStorageGranted(LT_PermissionActivity.this)) {
            ivCheckStorage.setVisibility(View.VISIBLE);
        }

        if (LT_Glob.isPermissionForAudioGranted(LT_PermissionActivity.this)) {
            ivSeleCamera.setVisibility(View.VISIBLE);
        }

        if (checkDrawOverlayPermission()) {
            ivCheckOverlay.setVisibility(View.VISIBLE);
        } else {
            ivCheckOverlay.setVisibility(View.GONE);
        }


        ivStorage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!LT_Glob.isPermissionForExternalStorageGranted(LT_PermissionActivity.this)) {
                    LT_Glob.getPermissionforscreen(LT_PermissionActivity.this, 100);
                }
            }
        });

        ivOverlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkDrawOverlayPermission()) {
                    Toast.makeText(LT_PermissionActivity.this, "Already Granted.", Toast.LENGTH_SHORT).show();
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        showOverDialog(LT_PermissionActivity.this);
                    } else {
                        nextActivity();
                    }
                }
            }
        });

        ivCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!LT_Glob.isPermissionForAudioGranted(LT_PermissionActivity.this)) {
                    LT_Glob.getPermissionforAudio(LT_PermissionActivity.this, 22);
                }
            }
        });

        flPermission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ivCheckStorage.getVisibility() == View.GONE) {
                    if (!LT_Glob.isPermissionForExternalStorageGranted(LT_PermissionActivity.this)) {
                        LT_Glob.getPermissionforscreen(LT_PermissionActivity.this, 100);
                    }
                } else if (ivSeleCamera.getVisibility() == View.GONE) {
                    if (!LT_Glob.isPermissionForAudioGranted(LT_PermissionActivity.this)) {
                        LT_Glob.getPermissionforAudio(LT_PermissionActivity.this, 22);
                    }
                } else if (ivCheckOverlay.getVisibility() == View.GONE) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        showOverDialog(LT_PermissionActivity.this);
                    } else {
                        nextActivity();
                    }
                } else {
                    nextActivity();
                }
            }
        });
    }

    public boolean checkDrawOverlayPermission() {
        if (!Settings.canDrawOverlays((this))) {
            return false;
        } else {
            return true;
        }
    }

    private void nextActivity() {
        startActivity(new Intent(LT_PermissionActivity.this, LT_StartActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
        SharePrefUtils.setFistTimeEnter(this,true);
        finish();
    }

    private void changeButtonColor() {
        ivAllowSelct.setVisibility(View.VISIBLE);
        ivAllowUnslect.setVisibility(View.GONE);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 100:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    ivCheckStorage.setVisibility(View.VISIBLE);
                    if (ivSeleCamera.getVisibility() == View.GONE) {
                        if (!LT_Glob.isPermissionForAudioGranted(LT_PermissionActivity.this)) {
                            LT_Glob.getPermissionforAudio(LT_PermissionActivity.this, 22);
                        }
                    } else if (ivCheckOverlay.getVisibility() == View.GONE) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            showOverDialog(LT_PermissionActivity.this);
                        } else {
                            nextActivity();
                        }
                    } else {
                        changeButtonColor();
                    }
                } else {
                    ivCheckStorage.setVisibility(View.VISIBLE);
                    if (ivSeleCamera.getVisibility() == View.GONE) {
                        if (!LT_Glob.isPermissionForAudioGranted(LT_PermissionActivity.this)) {
                            LT_Glob.getPermissionforAudio(LT_PermissionActivity.this, 22);
                        }
                    } else if (ivCheckOverlay.getVisibility() == View.GONE) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            showOverDialog(LT_PermissionActivity.this);
                        } else {
                            nextActivity();
                        }
                    } else {
                        changeButtonColor();
                    }
                }
                return;
            case 22:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    ivSeleCamera.setVisibility(View.VISIBLE);
                    if (ivCheckStorage.getVisibility() == View.GONE) {
                        if (!LT_Glob.isPermissionForExternalStorageGranted(LT_PermissionActivity.this)) {
                            LT_Glob.getPermissionforscreen(LT_PermissionActivity.this, 100);
                        }
                    } else if (ivCheckOverlay.getVisibility() == View.GONE) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            showOverDialog(LT_PermissionActivity.this);
                        } else {
                            nextActivity();
                        }
                    } else {
                        changeButtonColor();
                    }
                } else {
                    ivSeleCamera.setVisibility(View.VISIBLE);
                    if (ivCheckStorage.getVisibility() == View.GONE) {
                        if (!LT_Glob.isPermissionForExternalStorageGranted(LT_PermissionActivity.this)) {
                            LT_Glob.getPermissionforscreen(LT_PermissionActivity.this, 100);
                        }
                    } else if (ivCheckOverlay.getVisibility() == View.GONE) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            showOverDialog(LT_PermissionActivity.this);
                        } else {
                            nextActivity();
                        }
                    } else {
                        changeButtonColor();
                    }
                }
                return;
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 101:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (Settings.canDrawOverlays((this))) {
                        ivCheckOverlay.setVisibility(View.VISIBLE);
                        if (ivCheckStorage.getVisibility() == View.GONE) {
                            if (!LT_Glob.isPermissionForExternalStorageGranted(LT_PermissionActivity.this)) {
                                LT_Glob.getPermissionforscreen(LT_PermissionActivity.this, 100);
                            }
                        } else if (ivSeleCamera.getVisibility() == View.GONE) {
                            if (!LT_Glob.isPermissionForAudioGranted(LT_PermissionActivity.this)) {
                                LT_Glob.getPermissionforAudio(LT_PermissionActivity.this, 22);
                            }
                        } else {
                            changeButtonColor();
                        }
                    } else {
                        ivCheckOverlay.setVisibility(View.VISIBLE);
                        if (ivCheckStorage.getVisibility() == View.GONE) {
                            if (!LT_Glob.isPermissionForExternalStorageGranted(LT_PermissionActivity.this)) {
                                LT_Glob.getPermissionforscreen(LT_PermissionActivity.this, 100);
                            }
                        } else {
                            changeButtonColor();
                        }
                    }
                } else {
                    changeButtonColor();
                }
                return;
        }

    }


    public void showOverDialog(Activity activity) {
        final Dialog dialog = new Dialog(activity, R.style.MyDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.permit_layout);

        TextView img = dialog.findViewById(R.id.tvAllowPermission);
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (!Settings.canDrawOverlays((getApplicationContext()))) {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                        startActivityForResult(intent, 101);
                    } else {
                        nextActivity();
                    }
                } else {
                    changeButtonColor();
                }
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}