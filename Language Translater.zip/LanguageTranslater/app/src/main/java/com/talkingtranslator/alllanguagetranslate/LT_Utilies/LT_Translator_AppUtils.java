package com.talkingtranslator.alllanguagetranslate.LT_Utilies;

import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.widget.Toast;


public class LT_Translator_AppUtils {

    public static boolean isPlaying = false;
    public static MediaPlayer mediaPlayer;

    public static void SpeakText(final Context context, final String str, final String str2) {
        Toast makeText;
        try {
            if (isPlaying) {
                isPlaying = false;
                makeText = Toast.makeText(context, "Please Wait", 0);
            } else {
                {
                    isPlaying = true;
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            String str3 = "&q=" + str.replaceAll(" ", "%20");
                            LT_Translator_AppUtils.releasedMediaPlayer();
                            MediaPlayer mediaPlayer2 = new MediaPlayer();
                            LT_Translator_AppUtils.mediaPlayer = mediaPlayer2;
                            try {
                                mediaPlayer2.setDataSource(context, Uri.parse("https://translate.google.com/translate_tts?ie=UTF-8" + str3 + "&tl=" + str2 + "&client=tw-ob"));
                                LT_Translator_AppUtils.mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                                    @Override
                                    public void onPrepared(MediaPlayer mediaPlayer3) {
                                        mediaPlayer3.start();
                                    }
                                });
                                LT_Translator_AppUtils.mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                                    @Override
                                    public void onCompletion(MediaPlayer mediaPlayer3) {
                                        LT_Translator_AppUtils.isPlaying = false;
                                    }
                                });
                                LT_Translator_AppUtils.mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                                    @Override
                                    public boolean onError(MediaPlayer mediaPlayer3, int i, int i2) {
                                        LT_Translator_AppUtils.isPlaying = false;
                                        return false;
                                    }
                                });
                                LT_Translator_AppUtils.mediaPlayer.prepare();
                            } catch (Exception e) {
                                LT_Translator_AppUtils.isPlaying = false;
                                e.printStackTrace();
                            }
                        }
                    }).start();
                    return;
                }

            }
            makeText.show();
        } catch (Exception unused) {
            isPlaying = false;
        }
    }

    public static void releasedMediaPlayer() {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
            mediaPlayer.reset();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

}
