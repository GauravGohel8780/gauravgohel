package com.talkingtranslator.alllanguagetranslate.LT_model;

public class LT_History_Model {
    int id;
    String source_language;
    String source_language_txt;
    String target_language;
    String target_language_txt;

    public int getId() {
        return id;
    }

    public void setId(int i) {
        id = i;
    }

    public String getSource_language() {
        return source_language;
    }

    public void setSource_language(String str) {
        source_language = str;
    }

    public String getSource_language_txt() {
        return source_language_txt;
    }

    public void setSource_language_txt(String str) {
        source_language_txt = str;
    }

    public String getTarget_language() {
        return target_language;
    }

    public void setTarget_language(String str) {
        target_language = str;
    }

    public String getTarget_language_txt() {
        return target_language_txt;
    }

    public void setTarget_language_txt(String str) {
        target_language_txt = str;
    }
}