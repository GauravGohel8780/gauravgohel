package com.talkingtranslator.alllanguagetranslate.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Translator_Data_Helper extends SQLiteOpenHelper {

    SQLiteDatabase myDb;

    public Translator_Data_Helper(Context context) {
        super(context, "LangTranslation.db", (SQLiteDatabase.CursorFactory) null, 1);
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        myDb = sQLiteDatabase;
        sQLiteDatabase.execSQL("CREATE  TABLE IF NOT EXISTS Translation_Data(id integer PRIMARY KEY AUTOINCREMENT,source_lan text, source_txt text, target_lan text, target_txt text);");
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS Trans_Data");
        onCreate(sQLiteDatabase);
    }

    public boolean InsertRecord(String str, String str2, String str3, String str4, String str5) {
        myDb = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("source_lan", str2);
        contentValues.put("source_txt", str3);
        contentValues.put("target_lan", str4);
        contentValues.put("target_txt", str5);
        return myDb.insert(str, null, contentValues) != -1;
    }

    public Cursor getTransData() {
        return getReadableDatabase().rawQuery("select * from Translation_Data", null);
    }

    public Integer delTrans(String str) {
        myDb = getReadableDatabase();
        return Integer.valueOf(myDb.delete("Translation_Data", "id= ?", new String[]{str}));
    }

    public void delAll() {
        myDb = getReadableDatabase();
        myDb.delete("Translation_Data", null, null);
    }
}