package com.talkingtranslator.alllanguagetranslate.LT_Utilies;

public interface LT_HitoryClick {
    void onHistoryClick();
}
