package com.talkingtranslator.alllanguagetranslate.LT_Activity;


import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.SparseArray;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.talkingtranslator.alllanguagetranslate.Ads_Common.AdsBaseActivity;
import com.talkingtranslator.alllanguagetranslate.R;
import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.text.TextBlock;
import com.google.android.gms.vision.text.TextRecognizer;

import java.io.IOException;

public class LT_CameraTranslationActivity extends AdsBaseActivity {

    CameraSource translator_cmrsourse;
    SurfaceView translator_surfcview;
    TextRecognizer translator_textrecogniz;
    ImageView ivFabCamera;
    String translator_ScanText;
    TextView tvTextV;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);

        setContentView(R.layout.activity_translationcamera);
        findViewById(R.id.ivBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(LT_CameraTranslationActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        TextView titles = findViewById(R.id.titles);
        titles.setText("Camera Translator");

        translator_surfcview = (SurfaceView) findViewById(R.id.surfaceV);
        tvTextV = (TextView) findViewById(R.id.tvTextV);
        ivFabCamera = (ImageView) findViewById(R.id.ivFabCamera);

        ivFabCamera.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (translator_ScanText == null) {
                    Toast.makeText(LT_CameraTranslationActivity.this, (int) R.string.could_not_catch_text, Toast.LENGTH_SHORT).show();
                    return;
                }
                if (tvTextV.getText().toString().trim().equals("")) {
                    Toast.makeText(LT_CameraTranslationActivity.this, (int) R.string.no_text, Toast.LENGTH_SHORT).show();
                    return;
                }
                getInstance(LT_CameraTranslationActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(LT_CameraTranslationActivity.this, LT_TextTranslationActivity.class);
                        intent.putExtra("key", translator_ScanText);
                        intent.putExtra("from", 1);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });

        TextRecognizer();

    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (translator_cmrsourse != null) {
            translator_cmrsourse.release();
            translator_cmrsourse = null;
        }
    }

    private void TextRecognizer() {
        translator_textrecogniz = new TextRecognizer.Builder(this).build();
        translator_cmrsourse = new CameraSource.Builder(this, translator_textrecogniz).setRequestedPreviewSize(1920, 1080).setAutoFocusEnabled(true).build();
        translator_surfcview.getHolder().addCallback(new SurfaceHolder.Callback() {

            public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
            }

            public void surfaceCreated(SurfaceHolder surfaceHolder) {
                try {
                    if (ActivityCompat.checkSelfPermission(LT_CameraTranslationActivity.this, "android.permission.CAMERA") == 0) {

                        translator_cmrsourse.start(translator_surfcview.getHolder());
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
                translator_cmrsourse.stop();
            }
        });
        translator_textrecogniz.setProcessor(new Detector.Processor<TextBlock>() {
            @Override
            public void release() {
            }

            @Override
            public void receiveDetections(Detector.Detections<TextBlock> detections) {
                SparseArray<TextBlock> detectedItems = detections.getDetectedItems();
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < detectedItems.size(); i++) {
                    TextBlock valueAt = detectedItems.valueAt(i);
                    if (!(valueAt == null || valueAt.getValue() == null)) {
                        sb.append(valueAt.getValue() + " ");
                    }
                }
                translator_ScanText = sb.toString();
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    public void run() {
                        tvTextV.setText(translator_ScanText);
                    }
                });
            }
        });
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}