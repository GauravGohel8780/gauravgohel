package com.festom.toiletflushingsound.pranksound.TFPS_util;


import com.festom.toiletflushingsound.pranksound.TFPS_model.TFPS_FeedBackResponseModel;
import com.festom.toiletflushingsound.pranksound.TFPS_model.TFPS_FeedbackRequestModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface TFPS_ApiService {

    @POST("api/v1/feedBack/save")
    Call<TFPS_FeedBackResponseModel> feedbackUser(@Body TFPS_FeedbackRequestModel request);
}