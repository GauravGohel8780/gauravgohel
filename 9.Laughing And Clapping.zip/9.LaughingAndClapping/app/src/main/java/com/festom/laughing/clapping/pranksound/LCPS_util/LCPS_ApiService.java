package com.festom.laughing.clapping.pranksound.LCPS_util;


import com.festom.laughing.clapping.pranksound.LCPS_model.LCPS_FeedBackResponseModel;
import com.festom.laughing.clapping.pranksound.LCPS_model.LCPS_FeedbackRequestModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface LCPS_ApiService {

    @POST("api/v1/feedBack/save")
    Call<LCPS_FeedBackResponseModel> feedbackUser(@Body LCPS_FeedbackRequestModel request);
}