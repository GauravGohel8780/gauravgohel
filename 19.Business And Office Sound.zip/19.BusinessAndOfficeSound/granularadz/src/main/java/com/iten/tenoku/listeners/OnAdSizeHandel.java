package com.iten.tenoku.listeners;

public interface OnAdSizeHandel {
    void onSmallAd();

    void onMediumAd();

    void onBigAd();
}
