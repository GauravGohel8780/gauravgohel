package com.festom.businessandofficesound.pranksound.BOPS_util;


import com.festom.businessandofficesound.pranksound.BOPS_model.BOPS_FeedBackResponseModel;
import com.festom.businessandofficesound.pranksound.BOPS_model.BOPS_FeedbackRequestModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface BOPS_ApiService {

    @POST("api/v1/feedBack/save")
    Call<BOPS_FeedBackResponseModel> feedbackUser(@Body BOPS_FeedbackRequestModel request);
}