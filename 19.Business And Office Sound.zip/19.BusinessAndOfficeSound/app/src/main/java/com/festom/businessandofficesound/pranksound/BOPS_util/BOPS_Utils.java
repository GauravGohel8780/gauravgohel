package com.festom.businessandofficesound.pranksound.BOPS_util;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.view.Window;
import android.view.WindowManager;

import androidx.core.content.ContextCompat;

import com.festom.businessandofficesound.pranksound.R;

public class BOPS_Utils {

    public static void setStatusBarGradiant(Activity activity) {
        Window window = activity.getWindow();
        Drawable background = ContextCompat.getDrawable(activity, R.drawable.bg_app);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

        window.setStatusBarColor(activity.getResources().getColor(android.R.color.transparent));
        window.setNavigationBarColor(activity.getResources().getColor(R.color.bg_app_color));
        window.setBackgroundDrawable(background);
    }


}
