package com.festom.fartsound.pranksound.FSP_util;


import com.festom.fartsound.pranksound.FSP_model.FSP_FeedBackResponseModel;
import com.festom.fartsound.pranksound.FSP_model.FSP_FeedbackRequestModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface FSP_ApiService {

    @POST("api/v1/feedBack/save")
    Call<FSP_FeedBackResponseModel> feedbackUser(@Body FSP_FeedbackRequestModel request);
}