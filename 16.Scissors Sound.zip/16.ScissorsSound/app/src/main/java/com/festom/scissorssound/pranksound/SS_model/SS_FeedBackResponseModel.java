package com.festom.scissorssound.pranksound.SS_model;

public class SS_FeedBackResponseModel {

    public int iStatusCode;
    public boolean isStatus;
    public SS_FeedbackDataModel data;
    public String vMessage;

    public int getiStatusCode() {
        return iStatusCode;
    }

    public void setiStatusCode(int iStatusCode) {
        this.iStatusCode = iStatusCode;
    }

    public boolean isStatus() {
        return isStatus;
    }

    public void setStatus(boolean status) {
        isStatus = status;
    }

    public SS_FeedbackDataModel getFeedbackDataModel() {
        return data;
    }

    public void setFeedbackDataModel(SS_FeedbackDataModel data) {
        this.data = data;
    }

    public String getvMessage() {
        return vMessage;
    }

    public void setvMessage(String vMessage) {
        this.vMessage = vMessage;
    }
}
