package com.festom.scissorssound.pranksound.SS_util;


import com.festom.scissorssound.pranksound.SS_model.SS_FeedBackResponseModel;
import com.festom.scissorssound.pranksound.SS_model.SS_FeedbackRequestModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface SS_ApiService {

    @POST("api/v1/feedBack/save")
    Call<SS_FeedBackResponseModel> feedbackUser(@Body SS_FeedbackRequestModel request);
}