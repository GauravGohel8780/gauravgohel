package com.festom.gunsound.pranksound.GPS_util;


import com.festom.gunsound.pranksound.GPS_model.GPS_FeedBackResponseModel;
import com.festom.gunsound.pranksound.GPS_model.GPS_FeedbackRequestModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface GPS_ApiService {

    @POST("api/v1/feedBack/save")
    Call<GPS_FeedBackResponseModel> feedbackUser(@Body GPS_FeedbackRequestModel request);
}