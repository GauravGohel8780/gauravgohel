package com.controlcenter.allphone.ioscontrolcenter.service;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import com.controlcenter.allphone.ioscontrolcenter.ActivityScreenshot;
import com.controlcenter.allphone.ioscontrolcenter.MainActivity;
import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.screen.RecorderManager;
import com.controlcenter.allphone.ioscontrolcenter.screen.ScreenshotManager;
import com.controlcenter.allphone.ioscontrolcenter.screen.ScreenshotResult;
import com.controlcenter.allphone.ioscontrolcenter.screen.ViewPreview;
import com.controlcenter.allphone.ioscontrolcenter.util.MyConst;
import com.controlcenter.allphone.ioscontrolcenter.util.MyShare;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ServiceScreen extends Service {
    private static Intent screenshotPermission;
    private boolean addImage;
    private int height;
    private WindowManager manager;
    private MediaProjection mediaProjection;
    private MediaProjectionManager mediaProjectionManager;
    private WindowManager.LayoutParams pScreen;
    private boolean portrait;
    private RecorderManager recorderManager;
    private ScreenshotManager screenshotManager;
    private final ScreenshotResult screenshotResult = new ScreenshotResult() { // from class: com.controlcenter.allphone.ioscontrolcenter.service.ServiceScreen.1
        @Override // com.controlcenter.allphone.ioscontrolcenter.screen.ScreenshotResult
        public void onImageResult(Uri uri, boolean z) {
            if (ServiceScreen.this.portrait) {
                ServiceScreen.this.pScreen.width = ServiceScreen.this.width;
                ServiceScreen.this.pScreen.height = ServiceScreen.this.height;
            } else {
                ServiceScreen.this.pScreen.width = ServiceScreen.this.height;
                ServiceScreen.this.pScreen.height = ServiceScreen.this.width;
            }
            ServiceScreen.this.addViewLock();
            ServiceScreen.this.viewPreview.setPreview(uri, ServiceScreen.this.portrait, z);
        }
    };
    private int status;
    private ViewPreview viewPreview;
    private int width;

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @SuppressLint("WrongConstant")
    @Override // android.app.Service
    public void onCreate() {
        Notification build;
        super.onCreate();
        PendingIntent activity = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        int i = Build.VERSION.SDK_INT;
        if (i >= 26) {
            build = new Notification.Builder(this, OtherUtils.createChannel(this)).setContentTitle(getString(R.string.app_name)).setContentIntent(activity).build();
        } else {
            build = new NotificationCompat.Builder(this, getString(R.string.app_name)).setSmallIcon(R.drawable.ic_camera_while).setContentTitle(getString(R.string.app_name)).setContentText(getString(R.string.screen_record)).setContentIntent(activity).build();
        }
        startForeground(12222, build);
        this.mediaProjectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        this.manager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        int widthScreen = OtherUtils.getWidthScreen(this);
        int[] sizes = MyShare.getSizes(this);
        int i2 = (widthScreen * 2) / 25;
        int i22 = ((widthScreen * 19) / 100) + i2;
        this.width = i22;
        this.height = ((sizes[1] * i22) / sizes[0]) + i2;
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        this.pScreen = layoutParams;
        if (i >= 26) {
            layoutParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
            layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        } else {
            layoutParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ERROR;
            layoutParams.flags = 201326600;
        }
        layoutParams.format = -3;
        layoutParams.gravity = Gravity.CENTER_VERTICAL | Gravity.END;
        ViewPreview viewPreview = new ViewPreview(this);
        this.viewPreview = viewPreview;
        viewPreview.setShowEndResult(new ViewPreview.ShowEndResult() {
            @Override
            public void onEnd() {
                ServiceScreen.this.removeViewLock();
            }

            @Override
            public void onClickImage(Uri uri) {
                try {
                    Intent intent = new Intent("android.intent.action.VIEW");
                    intent.setDataAndType(uri, "image/*");
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    ServiceScreen.this.startActivity(intent);
                } catch (Exception e) {
                    try {
                        Toast.makeText(ServiceScreen.this, (int) R.string.error, Toast.LENGTH_SHORT).show();
                    } catch (Exception e2) {
                        Intent intent2 = new Intent("android.intent.action.VIEW");
                        intent2.setDataAndType(Uri.parse(uri.toString().replace("file://", "content://")), "image/*");
                        intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent2.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        ServiceScreen.this.startActivity(intent2);
                    }
                }
            }
        });
        this.screenshotManager = new ScreenshotManager(this, this.screenshotResult);
        this.recorderManager = new RecorderManager(this, this.screenshotResult);
    }

    public void addViewLock() {
        if (this.addImage) {
            return;
        }
        this.addImage = true;
        this.viewPreview.setVisibility(View.VISIBLE);
        try {
            this.manager.addView(this.viewPreview, this.pScreen);
        } catch (IllegalStateException e) {
        }
    }

    public void removeViewLock() {
        if (this.addImage) {
            this.addImage = false;
            this.viewPreview.setVisibility(View.GONE);
            try {
                this.manager.removeView(this.viewPreview);
            } catch (IllegalStateException e) {
            }
        }
        stopSelf();
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        if (intent != null) {
            this.status = intent.getIntExtra(MyConst.DATA_PKG, this.status);
            this.portrait = intent.getBooleanExtra(MyConst.DATA_ID_NOTIFICATION, this.portrait);
        }
        if (this.status == 3) {
            this.recorderManager.stopRecording();
        } else {
            getPermission();
        }
        return super.onStartCommand(intent, i, i2);
    }

    private void getPermission() {
        try {
            if (screenshotPermission != null) {
                MediaProjection mediaProjection = this.mediaProjection;
                if (mediaProjection != null) {
                    mediaProjection.stop();
                    this.mediaProjection = null;
                }
                MediaProjection mediaProjection2 = this.mediaProjectionManager.getMediaProjection(-1, (Intent) screenshotPermission.clone());
                this.mediaProjection = mediaProjection2;
                int i = this.status;
                if (i == 1) {
                    this.screenshotManager.startProjection(mediaProjection2, this.portrait);
                    return;
                } else if (i == 2) {
                    this.recorderManager.startRecording(mediaProjection2, this.portrait);
                    return;
                } else {
                    return;
                }
            }
            openScreenshotPermissionRequester();
        } catch (RuntimeException e) {
            openScreenshotPermissionRequester();
        }
    }

    private void openScreenshotPermissionRequester() {
        Intent intent = new Intent(this, ActivityScreenshot.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    public static void setScreenshotPermission(Context context, Intent intent) {
        screenshotPermission = intent;
        Intent intent2 = new Intent(context, ServiceControl.class);
        intent2.putExtra(MyConst.DATA_ID_NOTIFICATION, 15);
        context.startService(intent2);
    }
}
