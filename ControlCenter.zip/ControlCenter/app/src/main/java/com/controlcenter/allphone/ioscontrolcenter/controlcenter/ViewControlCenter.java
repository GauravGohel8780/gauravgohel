package com.controlcenter.allphone.ioscontrolcenter.controlcenter;

import android.app.NotificationManager;
import android.bluetooth.BluetoothAdapter;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.PlaybackState;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.provider.Settings;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;

import androidx.core.view.PointerIconCompat;

import com.controlcenter.allphone.ioscontrolcenter.controlcenter.custom.ViewBgControl;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.BaseViewControl;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.connect.ConnectClickResult;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.connect.ViewConnect;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.connect.ViewConnectBig;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.music.ViewMusic;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.music.ViewMusicBig;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.status.ViewStatusBar;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewone.RecordScreenResult;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewone.ViewFlash;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewone.ViewLock;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewone.ViewOneChange;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewone.ViewScreenRecord;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewone.ViewSilent;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewone.ViewTimeScreen;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewone.ViewTimeScreenBig;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewprogress.OnProgressChange;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewprogress.ViewBigBright;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewprogress.ViewBigVolume;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewprogress.ViewProgress;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewprogress.ViewStatusBright;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewprogress.ViewStatusVolume;
import com.controlcenter.allphone.ioscontrolcenter.custom.MyScrollViewHor;
import com.controlcenter.allphone.ioscontrolcenter.custom.OnSwipeTouchListener;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemControl;
import com.controlcenter.allphone.ioscontrolcenter.service.MusicControlResult;
import com.controlcenter.allphone.ioscontrolcenter.util.CheckUtils;
import com.controlcenter.allphone.ioscontrolcenter.util.FlashlightProvider;
import com.controlcenter.allphone.ioscontrolcenter.util.MyShare;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.util.ArrayList;
import java.util.Iterator;

import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;


public class ViewControlCenter extends RelativeLayout {
    private AudioManager am;
    private final ArrayList<BaseViewControl> arrAllView;
    private final ArrayList<ViewOneChange> arrIconChange;
    private ControlResult controlResult;
    private boolean disTouch;
    private FlashlightProvider flashlightProvider;
    private boolean isShowViewNotChangeScreen;
    private final OnProgressChange onProgressChange;
    private final OnSwipeTouchListener onSwipeControl;
    private boolean portrait;
    private RecordScreenResult recordScreenResult;
    private final RelativeLayout rlBig;
    private final RelativeLayout rlLan;
    private final MyScrollViewHor svLan;
    private final BaseViewControl.BaseTouchDownResult touchDownResult;
    private final OnSwipeTouchListener.TouchResult touchResult;
    private boolean update;
    private final ViewBgControl vBg;
    private final ViewProgress vBright;
    private final View vCenter;
    private final ViewProgress vVolume;
    private BaseViewControl viewClick;
    private final ViewConnect viewConnect;
    private final ViewConnectBig viewConnectBig;
    private ViewFlash viewFlash;
    private final ViewLock viewLock;
    private final ViewMusic viewMusic;
    private final ViewMusicBig viewMusicBig;
    private ViewScreenRecord viewScreenRecord;
    private final ViewSilent viewSilent;
    private final ViewStatusBar viewStatusBar;
    private final ViewTimeScreen viewTimeScreen;
    private final ViewTimeScreenBig viewTimeScreenBig;
    private BaseViewControl viewTouch;

    public void setControlResult(ControlResult controlResult, ConnectClickResult connectClickResult, MusicControlResult musicControlResult, FlashlightProvider flashlightProvider, RecordScreenResult recordScreenResult) {
        this.controlResult = controlResult;
        this.recordScreenResult = recordScreenResult;
        this.flashlightProvider = flashlightProvider;
        this.viewConnect.setConnectClickResult(connectClickResult);
        this.viewConnectBig.setConnectClickResult(connectClickResult);
        this.viewMusic.setMusicControlResult(musicControlResult);
        this.viewMusicBig.setMusicControlResult(musicControlResult);
        ViewScreenRecord viewScreenRecord = this.viewScreenRecord;
        if (viewScreenRecord != null) {
            viewScreenRecord.setRecordScreenResult(recordScreenResult);
        }
    }

    public ViewControlCenter(Context context) {
        super(context);
        this.update = true;
        this.touchDownResult = new BaseViewControl.BaseTouchDownResult() {
            @Override
            public void onTouchDownBaseView(BaseViewControl baseViewControl) {
                ViewControlCenter.this.viewClick = baseViewControl;
                ViewControlCenter.this.viewTouch = baseViewControl;
                ViewControlCenter.this.viewTouch.touchDown();
            }
        };
        OnSwipeTouchListener.TouchResult touchResult = new OnSwipeTouchListener.TouchResult() {
            @Override
            public void onCancelTouch() {
            }

            @Override
            public void onDoubleClick() {
            }

            @Override
            public void onSwipeLeft() {
            }

            @Override
            public void onSwipeRight() {
            }

            @Override
            public void onSwipeBottom() {
                onCancel();
            }

            @Override
            public void onSwipeUp() {
                if (ViewControlCenter.this.viewClick != null) {
                    ViewControlCenter.this.viewClick = null;
                }
                onClick();
            }

            @Override
            public void onCancel() {
                ViewControlCenter.this.onShowView();
            }

            @Override
            public void onMoveHorizontal(float f) {
                if (ViewControlCenter.this.viewClick != null) {
                    ViewControlCenter.this.viewClick = null;
                }
                if (ViewControlCenter.this.viewTouch != null) {
                    ViewControlCenter.this.viewTouch.touchUp();
                    ViewControlCenter.this.viewTouch = null;
                }
            }

            @Override
            public void onMoveVertical(float f) {
                if (f > -180.0f) {
                    Iterator it = ViewControlCenter.this.arrAllView.iterator();
                    while (it.hasNext()) {
                        ((BaseViewControl) it.next()).run(180.0f + f);
                    }
                }
                if (ViewControlCenter.this.viewTouch != null) {
                    ViewControlCenter.this.viewTouch.touchUp();
                    ViewControlCenter.this.viewTouch = null;
                }
                ViewControlCenter.this.viewConnect.resetViewTouch();
                ViewControlCenter.this.viewMusic.clearViewClick();
                if (ViewControlCenter.this.viewClick != null) {
                    ViewControlCenter.this.viewClick = null;
                }
            }

            @Override
            public void onClick() {
                if (ViewControlCenter.this.viewClick == null) {
                    ViewControlCenter.this.controlResult.onGone();
                    return;
                }
                if (ViewControlCenter.this.viewClick != ViewControlCenter.this.viewSilent) {
                    if (ViewControlCenter.this.viewClick != ViewControlCenter.this.viewTimeScreen) {
                        if (ViewControlCenter.this.viewClick != ViewControlCenter.this.viewFlash) {
                            if (ViewControlCenter.this.viewClick instanceof ViewOneChange) {
                                ViewControlCenter viewControlCenter = ViewControlCenter.this;
                                viewControlCenter.action(((ViewOneChange) viewControlCenter.viewClick).getItemControl());
                            }
                        } else {
                            ViewControlCenter.this.flashClick();
                        }
                    } else {
                        ViewControlCenter.this.onHideView();
                        ViewControlCenter.this.showBigTime();
                    }
                } else if (!CheckUtils.checkSystemWriteSettingEndAction(ViewControlCenter.this.getContext())) {
                    ViewControlCenter.this.controlResult.onGone();
                } else {
                    NotificationManager notificationManager = (NotificationManager) ViewControlCenter.this.getContext().getSystemService(Context.NOTIFICATION_SERVICE);
                    if (Build.VERSION.SDK_INT < 23 || notificationManager.isNotificationPolicyAccessGranted()) {
                        if (ViewControlCenter.this.am.getRingerMode() == 0) {
                            ViewControlCenter.this.am.setRingerMode(2);
                        } else {
                            ViewControlCenter.this.am.setRingerMode(0);
                        }
                        ViewControlCenter.this.viewSilent.setSilent(ViewControlCenter.this.am.getRingerMode() == 0, true);
                    } else {
                        Intent intent = new Intent("android.settings.NOTIFICATION_POLICY_ACCESS_SETTINGS");
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        ViewControlCenter.this.getContext().startActivity(intent);
                        ViewControlCenter.this.controlResult.onGone();
                    }
                }
                ViewControlCenter.this.viewClick.onClick();
                ViewControlCenter.this.viewClick = null;
            }

            @Override
            public void onLongClick() {
                ViewControlCenter.this.viewClick = null;
                if (ViewControlCenter.this.viewTouch != null && ViewControlCenter.this.viewTouch.onLongClick(ViewControlCenter.this)) {
                    ViewControlCenter.this.onHideView();
                }
                ViewControlCenter.this.viewTouch = null;
            }

            @Override
            public void onTouchUp() {
                if (ViewControlCenter.this.viewTouch != null) {
                    ViewControlCenter.this.viewTouch.touchUp();
                    ViewControlCenter.this.viewTouch = null;
                }
                if (ViewControlCenter.this.viewClick != null) {
                    ViewControlCenter.this.viewClick = null;
                }
            }
        };
        this.touchResult = touchResult;
        OnProgressChange onProgressChange = new OnProgressChange() {
            @Override
            public void onTouchDown() {
                ViewControlCenter.this.disTouch = true;
                ViewControlCenter.this.svLan.setTouchDis(true);
            }

            @Override
            public void onChange(View view, int i) {
                if (CheckUtils.checkSystemWriteSetting(ViewControlCenter.this.getContext())) {
                    if (view == ViewControlCenter.this.vVolume) {
                        ViewControlCenter.this.am.setStreamVolume(3, (ViewControlCenter.this.am.getStreamMaxVolume(3) * i) / 100, 0);
                    } else {
                        Settings.System.putInt(ViewControlCenter.this.getContext().getContentResolver(), "screen_brightness", (i * 255) / 100);
                    }
                }
            }

            @Override
            public void onLongClick(View view) {
                if (view == ViewControlCenter.this.vVolume || view == ViewControlCenter.this.vBright) {
                    ((BaseViewControl) view).onLongClick(ViewControlCenter.this);
                    ViewControlCenter.this.onHideView();
                }
            }

            @Override
            public void onTouchUp() {
                ViewControlCenter.this.disTouch = false;
                ViewControlCenter.this.svLan.setTouchDis(false);
            }
        };
        this.onProgressChange = onProgressChange;
        ViewBgControl viewBgControl = new ViewBgControl(context);
        this.vBg = viewBgControl;
        viewBgControl.setAlpha(0.0f);
        this.onSwipeControl = new OnSwipeTouchListener(context, touchResult);
        ArrayList<BaseViewControl> arrayList = new ArrayList<>();
        this.arrAllView = arrayList;
        View view = new View(context);
        this.vCenter = view;
        view.setId(1000);
        MyScrollViewHor myScrollViewHor = new MyScrollViewHor(context);
        this.svLan = myScrollViewHor;
        myScrollViewHor.setFillViewport(true);
        RelativeLayout relativeLayout = new RelativeLayout(context);
        this.rlLan = relativeLayout;
        myScrollViewHor.addView(relativeLayout, -1, -1);
        OverScrollDecoratorHelper.setUpOverScroll(myScrollViewHor);
        ViewConnect viewConnect = new ViewConnect(context);
        this.viewConnect = viewConnect;
        viewConnect.setId(PointerIconCompat.TYPE_CONTEXT_MENU);
        viewConnect.setSpeed(1.0f);
        arrayList.add(viewConnect);
        ViewMusic viewMusic = new ViewMusic(context);
        this.viewMusic = viewMusic;
        viewMusic.setSpeed(1.0f);
        viewMusic.setId(PointerIconCompat.TYPE_HAND);
        arrayList.add(viewMusic);
        ViewStatusBar viewStatusBar = new ViewStatusBar(context);
        this.viewStatusBar = viewStatusBar;
        viewStatusBar.setSpeed(1.0f);
        arrayList.add(viewStatusBar);
        ViewLock viewLock = new ViewLock(context);
        this.viewLock = viewLock;
        viewLock.setId(PointerIconCompat.TYPE_HELP);
        viewLock.setSpeed(1.15f);
        arrayList.add(viewLock);
        ViewSilent viewSilent = new ViewSilent(context);
        this.viewSilent = viewSilent;
        viewSilent.setId(PointerIconCompat.TYPE_WAIT);
        viewSilent.setSpeed(1.15f);
        arrayList.add(viewSilent);
        int widthScreen = (OtherUtils.getWidthScreen(getContext()) * 18) / 100;
        ViewProgress viewProgress = new ViewProgress(context);
        this.vBright = viewProgress;
        viewProgress.setId(1005);
        viewProgress.setSpeed(1.15f);
        viewProgress.setOnProgressChange(onProgressChange);
        viewProgress.setBaseViewStatus(new ViewStatusBright(context), widthScreen);
        arrayList.add(viewProgress);
        ViewProgress viewProgress2 = new ViewProgress(context);
        this.vVolume = viewProgress2;
        viewProgress2.setId(PointerIconCompat.TYPE_CELL);
        viewProgress2.setSpeed(1.15f);
        viewProgress2.setOnProgressChange(onProgressChange);
        viewProgress2.setBaseViewStatus(new ViewStatusVolume(context), widthScreen);
        arrayList.add(viewProgress2);
        ViewTimeScreen viewTimeScreen = new ViewTimeScreen(context);
        this.viewTimeScreen = viewTimeScreen;
        viewTimeScreen.setId(PointerIconCompat.TYPE_CROSSHAIR);
        viewTimeScreen.setSpeed(1.3f);
        arrayList.add(viewTimeScreen);
        RelativeLayout relativeLayout2 = new RelativeLayout(context);
        this.rlBig = relativeLayout2;
        relativeLayout2.setAlpha(0.0f);
        relativeLayout2.setOnClickListener(new OnClickListener() {
            @Override 
            public final void onClick(View view2) {
                ViewControlCenter.this.m42x80c58497(view2);
            }
        });
        this.viewConnectBig = new ViewConnectBig(context);
        this.viewMusicBig = new ViewMusicBig(context);
        ViewTimeScreenBig viewTimeScreenBig = new ViewTimeScreenBig(context);
        this.viewTimeScreenBig = viewTimeScreenBig;
        viewTimeScreenBig.setViewTime(viewTimeScreen);
        this.arrIconChange = new ArrayList<>();
        makeArrIconChange();
        changeScreen(true);
        Iterator<BaseViewControl> it = arrayList.iterator();
        while (it.hasNext()) {
            Iterator<BaseViewControl> it2 = it;
            BaseViewControl next = it.next();
            RelativeLayout relativeLayout22 = relativeLayout2;
            if (!(next instanceof ViewProgress)) {
                next.setBaseTouchDownResult(this.touchDownResult);
            }
            relativeLayout2 = relativeLayout22;
            it = it2;
        }
    }

    public void m42x80c58497(View view) {
        hideBigView();
    }

    public void changeScreen(boolean z) {
        if (this.portrait == z) {
            return;
        }
        if (this.isShowViewNotChangeScreen) {
            hideBigView();
        }
        this.portrait = z;
        updateView();
    }

    public void updateView() {
        int i7;
        int widthScreen;
        int i;
        LayoutParams layoutParams7;
        this.viewConnectBig.changeScreen(this.portrait);
        this.viewMusicBig.changeScreen(this.portrait);
        boolean z = indexOfChild(this.rlBig) != -1;
        this.rlLan.removeAllViews();
        removeAllViews();
        addView(this.vBg, -1, -1);
        int widthScreen2 = OtherUtils.getWidthScreen(getContext());
        int i2 = (widthScreen2 * 2) / 5;
        int i3 = (widthScreen2 * 18) / 100;
        int i4 = widthScreen2 / 25;
        if (!this.portrait) {
            addView(this.svLan, -1, -1);
            int i6 = i4 * 3;
            int i72 = i2 + i3 + i4;
            LayoutParams layoutParams11 = new LayoutParams(i6, i72);
            layoutParams11.addRule(15);
            this.rlLan.addView(this.vCenter, layoutParams11);
            LayoutParams layoutParams12 = new LayoutParams(i2, i2);
            layoutParams12.addRule(17, this.vCenter.getId());
            layoutParams12.addRule(6, this.vCenter.getId());
            layoutParams12.setMargins(0, 0, i4, i4);
            this.rlLan.addView(this.viewConnect, layoutParams12);
            LayoutParams layoutParams13 = new LayoutParams(-1, widthScreen2 / 22);
            layoutParams13.setMargins(i6, ((widthScreen2 - i72) / 2) - ((widthScreen2 * 7) / 100), i6, 0);
            addView(this.viewStatusBar, layoutParams13);
            LayoutParams layoutParams14 = new LayoutParams(i2, i2);
            layoutParams14.addRule(6, this.vCenter.getId());
            layoutParams14.addRule(17, this.viewConnect.getId());
            layoutParams14.setMargins(0, 0, i4, i4);
            this.rlLan.addView(this.viewMusic, layoutParams14);
            LayoutParams layoutParams15 = new LayoutParams(i3, i3);
            layoutParams15.addRule(17, this.vCenter.getId());
            layoutParams15.addRule(3, this.viewConnect.getId());
            this.rlLan.addView(this.viewLock, layoutParams15);
            LayoutParams layoutParams16 = new LayoutParams(i3, i3);
            layoutParams16.addRule(3, this.viewConnect.getId());
            layoutParams16.addRule(19, this.viewConnect.getId());
            this.rlLan.addView(this.viewSilent, layoutParams16);
            LayoutParams layoutParams17 = new LayoutParams(i2, i3);
            layoutParams17.addRule(3, this.viewMusic.getId());
            layoutParams17.addRule(17, this.viewConnect.getId());
            this.rlLan.addView(this.viewTimeScreen, layoutParams17);
            LayoutParams layoutParams18 = new LayoutParams(i3, i72);
            layoutParams18.addRule(17, this.viewMusic.getId());
            layoutParams18.addRule(6, this.vCenter.getId());
            layoutParams18.setMargins(0, 0, i4, 0);
            this.rlLan.addView(this.vBright, layoutParams18);
            LayoutParams layoutParams19 = new LayoutParams(i3, i72);
            layoutParams19.addRule(6, this.vCenter.getId());
            layoutParams19.addRule(17, this.vBright.getId());
            this.rlLan.addView(this.vVolume, layoutParams19);
            if (this.arrIconChange.size() == 0) {
                return;
            }
            ViewOneChange viewOneChange = null;
            int i8 = 0;
            while (true) {
                LayoutParams layoutParams192 = layoutParams19;
                if (i8 >= this.arrIconChange.size()) {
                    break;
                }
                LayoutParams layoutParams20 = new LayoutParams(i3, i3);
                ViewOneChange viewOneChange2 = viewOneChange;
                if (i8 == 3 || i8 == 6 || i8 == 9) {
                    i7 = i72;
                    ViewOneChange viewOneChange3 = this.arrIconChange.get(i8 - 3);
                    viewOneChange2 = viewOneChange3;
                    layoutParams20.addRule(17, viewOneChange3.getId());
                } else {
                    i7 = i72;
                }
                int i9 = i8 % 3;
                if (i9 == 0) {
                    widthScreen = widthScreen2;
                    layoutParams20.addRule(6, this.vVolume.getId());
                    i = 1;
                } else {
                    widthScreen = widthScreen2;
                    if (i9 == 1) {
                        i = 1;
                        layoutParams20.addRule(8, this.viewMusic.getId());
                    } else {
                        i = 1;
                        layoutParams20.addRule(8, this.vVolume.getId());
                    }
                }
                if (i8 < this.arrIconChange.size() - i) {
                    layoutParams20.setMargins(i4, 0, 0, 0);
                } else {
                    layoutParams20.setMargins(i4, 0, i4, 0);
                }
                this.rlLan.addView(this.arrIconChange.get(i8), layoutParams20);
                i8++;
                layoutParams19 = layoutParams192;
                viewOneChange = viewOneChange2;
                i72 = i7;
                widthScreen2 = widthScreen;
            }
        } else {
            LayoutParams layoutParams = new LayoutParams(i4, i4);
            layoutParams.addRule(14);
            layoutParams.setMargins(0, widthScreen2 / 4, 0, 0);
            addView(this.vCenter, layoutParams);
            LayoutParams layoutParams2 = new LayoutParams(i2, i2);
            layoutParams2.addRule(6, this.vCenter.getId());
            layoutParams2.addRule(16, this.vCenter.getId());
            addView(this.viewConnect, layoutParams2);
            LayoutParams layoutParams3 = new LayoutParams(i2, i2);
            layoutParams3.addRule(6, this.vCenter.getId());
            layoutParams3.addRule(17, this.vCenter.getId());
            addView(this.viewMusic, layoutParams3);
            LayoutParams layoutParams4 = new LayoutParams(-1, widthScreen2 / 22);
            layoutParams4.setMargins(0, 0, 0, (int) ((widthScreen2 * 4.8f) / 100.0f));
            layoutParams4.addRule(2, this.viewConnect.getId());
            layoutParams4.addRule(18, this.viewConnect.getId());
            layoutParams4.addRule(19, this.viewMusic.getId());
            addView(this.viewStatusBar, layoutParams4);
            LayoutParams layoutParams5 = new LayoutParams(i3, i3);
            layoutParams5.addRule(3, this.viewConnect.getId());
            layoutParams5.addRule(18, this.viewConnect.getId());
            layoutParams5.setMargins(0, i4, i4, i4);
            addView(this.viewLock, layoutParams5);
            LayoutParams layoutParams6 = new LayoutParams(i3, i3);
            layoutParams6.addRule(6, this.viewLock.getId());
            layoutParams6.addRule(19, this.viewConnect.getId());
            addView(this.viewSilent, layoutParams6);
            LayoutParams layoutParams72 = new LayoutParams(i2, i3);
            layoutParams72.addRule(3, this.viewLock.getId());
            layoutParams72.addRule(18, this.viewConnect.getId());
            addView(this.viewTimeScreen, layoutParams72);
            LayoutParams layoutParams8 = new LayoutParams(i3, i2);
            layoutParams8.addRule(6, this.viewLock.getId());
            layoutParams8.addRule(17, this.vCenter.getId());
            addView(this.vBright, layoutParams8);
            LayoutParams layoutParams9 = new LayoutParams(i3, i2);
            layoutParams9.addRule(6, this.viewLock.getId());
            layoutParams9.addRule(19, this.viewMusic.getId());
            layoutParams9.setMargins(0, 0, 0, i4);
            addView(this.vVolume, layoutParams9);
            if (this.arrIconChange.size() == 0) {
                return;
            }
            int i5 = 0;
            while (i5 < this.arrIconChange.size()) {
                LayoutParams layoutParams10 = new LayoutParams(i3, i3);
                LayoutParams layoutParams62 = layoutParams6;
                if (i5 < 4) {
                    layoutParams7 = layoutParams72;
                    layoutParams10.addRule(3, this.vVolume.getId());
                    if (i5 == 0) {
                        layoutParams10.addRule(18, this.viewTimeScreen.getId());
                    } else {
                        layoutParams10.addRule(17, this.arrIconChange.get(i5 - 1).getId());
                    }
                    if (i5 < 3) {
                        layoutParams10.setMargins(0, 0, i4, i4);
                    }
                } else {
                    layoutParams7 = layoutParams72;
                    if (i5 < 8) {
                        layoutParams10.addRule(3, this.arrIconChange.get(0).getId());
                        if (i5 == 4) {
                            layoutParams10.addRule(18, this.viewTimeScreen.getId());
                        } else {
                            layoutParams10.addRule(17, this.arrIconChange.get(i5 - 1).getId());
                        }
                        if (i5 < 7) {
                            layoutParams10.setMargins(0, 0, i4, i4);
                        }
                    } else {
                        layoutParams10.addRule(3, this.arrIconChange.get(4).getId());
                        if (i5 != 8) {
                            layoutParams10.addRule(17, this.arrIconChange.get(i5 - 1).getId());
                        } else {
                            layoutParams10.addRule(18, this.viewTimeScreen.getId());
                        }
                        if (i5 < 11) {
                            layoutParams10.setMargins(0, 0, i4, i4);
                        }
                    }
                }
                addView(this.arrIconChange.get(i5), layoutParams10);
                i5++;
                layoutParams6 = layoutParams62;
                layoutParams72 = layoutParams7;
            }
        }
        if (z) {
            addView(this.rlBig, -1, -1);
        }
    }

    public void makeArrIconChange() {
        if (this.viewFlash != null) {
            this.viewFlash = null;
        }
        if (this.viewScreenRecord != null) {
            this.viewScreenRecord = null;
        }
        for (int size = this.arrAllView.size() - 1; size >= 0; size--) {
            if (this.arrAllView.get(size) instanceof ViewOneChange) {
                this.arrAllView.remove(size);
            }
        }
        this.arrIconChange.clear();
        ArrayList<ItemControl> arrControl = MyShare.getArrControl(getContext());
        if (arrControl == null || arrControl.size() == 0) {
            return;
        }
        int i = PointerIconCompat.TYPE_CROSSHAIR;
        for (int i2 = 0; i2 < arrControl.size(); i2++) {
            i++;
            float f = 1.45f;
            if (i2 > 3 && i2 < 8) {
                f = 1.6f;
            } else if (i2 >= 8) {
                f = 1.75f;
            }
            int i3 = arrControl.get(i2).type;
            if (i3 == 1) {
                ViewFlash viewFlash = new ViewFlash(getContext());
                this.viewFlash = viewFlash;
                viewFlash.setItemControl(arrControl.get(i2));
                this.viewFlash.setId(i);
                this.viewFlash.setSpeed(f);
                this.viewFlash.setBaseTouchDownResult(this.touchDownResult);
                this.arrIconChange.add(this.viewFlash);
                this.arrAllView.add(this.viewFlash);
            } else if (i3 == 5) {
                ViewScreenRecord viewScreenRecord = new ViewScreenRecord(getContext());
                this.viewScreenRecord = viewScreenRecord;
                viewScreenRecord.setItemControl(arrControl.get(i2));
                this.viewScreenRecord.setId(i);
                this.viewScreenRecord.setSpeed(f);
                this.viewScreenRecord.setBaseTouchDownResult(this.touchDownResult);
                RecordScreenResult recordScreenResult = this.recordScreenResult;
                if (recordScreenResult != null) {
                    this.viewScreenRecord.setRecordScreenResult(recordScreenResult);
                }
                this.arrIconChange.add(this.viewScreenRecord);
                this.arrAllView.add(this.viewScreenRecord);
            } else {
                ViewOneChange viewOneChange = new ViewOneChange(getContext());
                viewOneChange.setId(i);
                viewOneChange.setSpeed(f);
                viewOneChange.setItemControl(arrControl.get(i2));
                viewOneChange.setBaseTouchDownResult(this.touchDownResult);
                this.arrIconChange.add(viewOneChange);
                this.arrAllView.add(viewOneChange);
            }
        }
    }

    public void onShowView() {
        this.vBg.animate().alpha(1.0f).setDuration(400L).start();
        Iterator<BaseViewControl> it = this.arrAllView.iterator();
        while (it.hasNext()) {
            it.next().onEndRun();
        }
    }

    public void onHideView() {
        this.update = true;
        Iterator<BaseViewControl> it = this.arrAllView.iterator();
        while (it.hasNext()) {
            it.next().onGone();
        }
    }

    public void onMoveView(float f) {
        float f2 = 0.0f;
        if (f > 0.0f) {
            float height = (6.0f * f) / getHeight();
            ViewBgControl viewBgControl = this.vBg;
            if (height >= 0.0f) {
                f2 = height > 1.0f ? 1.0f : height;
            }
            viewBgControl.setAlpha(f2);
        }
        if (this.update) {
            updateNotListen();
        }
        Iterator<BaseViewControl> it = this.arrAllView.iterator();
        while (it.hasNext()) {
            it.next().run(f);
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (!this.disTouch && indexOfChild(this.rlBig) == -1) {
            this.onSwipeControl.onTouch(this, motionEvent);
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public void setBackground(Bitmap bitmap) {
        this.vBg.setBgBlur(bitmap);
    }

    public void clearBg() {
        this.vBg.clearBg();
    }

    public ViewBgControl getViewBg() {
        return this.vBg;
    }

    public void updateFist(BluetoothAdapter bluetoothAdapter, WifiManager wifiManager, AudioManager audioManager) {
        this.am = audioManager;
        updateAir(CheckUtils.checkAirplane(getContext()));
        updateWifi(wifiManager);
        updateBlu(bluetoothAdapter);
        updateVolume(audioManager.getStreamVolume(3));
    }

    public void updateNotListen() {
        int i = 0;
        this.update = false;
        boolean hasMobileData = CheckUtils.hasMobileData(getContext());
        this.viewStatusBar.updateAll(hasMobileData, OtherUtils.getItemStatusBattery(getContext()));
        this.viewConnect.updateData(hasMobileData);
        this.viewConnectBig.updateData(hasMobileData);
        updateHotpot(CheckUtils.isApOn(getContext()));
        updateSync();
        this.viewLock.setLock(Settings.System.getInt(getContext().getContentResolver(), "accelerometer_rotation", 0) != 1, false);
        this.viewSilent.setSilent(this.am.getRingerMode() == 0, false);
        this.viewTimeScreen.updateTime();
        this.viewTimeScreenBig.updateTime();
        try {
            i = (Settings.System.getInt(getContext().getContentResolver(), "screen_brightness") * 100) / 256;
        } catch (Settings.SettingNotFoundException e) {
        }
        this.vBright.setProgress(i);
    }

    public void updateAir(boolean z) {
        this.viewConnect.updateAir(z);
        this.viewConnectBig.updateAir(z);
    }

    public void updateWifi(WifiManager wifiManager) {
        this.viewConnect.updateWifi(wifiManager.isWifiEnabled());
        this.viewConnectBig.updateWifi(wifiManager.isWifiEnabled());
        this.viewStatusBar.updateWifi(wifiManager.isWifiEnabled());
    }

    public void updateBlu(BluetoothAdapter bluetoothAdapter) {
        this.viewConnect.updateBlu(bluetoothAdapter.isEnabled());
        this.viewConnectBig.updateBlu(bluetoothAdapter.isEnabled());
    }

    public void updateHotpot(boolean z) {
        this.viewConnectBig.updateHot(z);
    }

    public void updateSync() {
        this.viewConnectBig.updateSync(ContentResolver.getMasterSyncAutomatically());
    }

    public void updateVolume(int i) {
        this.viewMusicBig.updateVolume(i);
        this.vVolume.setProgress((i * 100) / this.am.getStreamMaxVolume(3));
    }

    public void onEndMusic() {
        this.viewMusic.endMedia();
    }

    public void updateMetadata(MediaMetadata mediaMetadata, MediaController mediaController) {
        this.viewMusic.updateMetadata(mediaMetadata);
        this.viewMusicBig.updateMetadata(mediaMetadata, mediaController);
    }

    public void updateStatus(PlaybackState playbackState, int i) {
        this.viewMusic.updateStatus(playbackState);
        this.viewMusicBig.updateStatus(playbackState, i);
    }

    public void updateFlash(boolean z) {
        ViewFlash viewFlash = this.viewFlash;
        if (viewFlash != null) {
            viewFlash.updateFlash(z);
        }
    }

    public void nightShiftClick() {
        MyShare.putScheduled(getContext(), false);
        boolean z = !MyShare.getEnaNightShift(getContext());
        MyShare.putEnaNightShift(getContext(), z);
        this.controlResult.changeNightShift(z);
    }

    public void action(ItemControl itemControl) {
        ViewScreenRecord viewScreenRecord;
        if (itemControl.type == 6 && (viewScreenRecord = this.viewScreenRecord) != null && viewScreenRecord.isRecord()) {
            return;
        }
        int i = itemControl.type;
        if (i == 2 || i == 3 || i == 4 || i == 6 || i == 7 || i == 8 || i == 9 || itemControl.pkg != null) {
            this.controlResult.onGoneWithAction(itemControl);
        }
    }

    private void showBigView() {
        this.rlBig.animate().alpha(1.0f).setDuration(300L).start();
    }

    public void hideBigView() {
        this.isShowViewNotChangeScreen = false;
        onShowView();
        this.rlBig.animate().alpha(0.0f).setDuration(300L).withEndAction(new Runnable() {
            @Override 
            public final void run() {
                ViewControlCenter.this.m41x2ada3553();
            }
        }).start();
    }

    public void m41x2ada3553() {
        removeView(this.rlBig);
    }

    public void checkViewBig(boolean z) {
        if (indexOfChild(this.rlBig) != -1) {
            if (!z) {
                removeView(this.rlBig);
                this.rlBig.setAlpha(0.0f);
                return;
            }
            this.rlBig.animate().alpha(0.0f).setDuration(300L).withEndAction(new Runnable() {
                @Override 
                public final void run() {
                    removeView(rlBig);
                }
            }).start();
        }
    }


    public void showBigViewConnect() {
        addView(this.rlBig, -1, -1);
        this.rlBig.removeAllViews();
        LayoutParams layoutParams = new LayoutParams(-2, -2);
        layoutParams.addRule(13);
        this.rlBig.addView(this.viewConnectBig, layoutParams);
        showBigView();
    }

    public void showBigMusic() {
        addView(this.rlBig, -1, -1);
        this.rlBig.removeAllViews();
        LayoutParams layoutParams = new LayoutParams(-2, -2);
        layoutParams.addRule(13);
        this.rlBig.addView(this.viewMusicBig, layoutParams);
        showBigView();
    }

    public void showBigTime() {
        this.rlBig.removeAllViews();
        addView(this.rlBig, -1, -1);
        LayoutParams layoutParams = new LayoutParams(-2, -2);
        layoutParams.addRule(13);
        this.rlBig.addView(this.viewTimeScreenBig, layoutParams);
        showBigView();
    }

    public void showBigBright() {
        this.isShowViewNotChangeScreen = true;
        this.rlBig.removeAllViews();
        addView(this.rlBig, -1, -1);
        new ViewBigBright(this, this.rlBig, this.portrait, this.vBright.getProgress(), this.onProgressChange);
        showBigView();
    }

    public void showBigVolume() {
        this.isShowViewNotChangeScreen = true;
        this.rlBig.removeAllViews();
        addView(this.rlBig, -1, -1);
        new ViewBigVolume(this.rlBig, this.portrait);
        showBigView();
    }

    public void onEndRecordScreen() {
        ViewScreenRecord viewScreenRecord = this.viewScreenRecord;
        if (viewScreenRecord != null) {
            viewScreenRecord.stopViewRecord();
        }
    }

    public void onStartRecordScreen() {
        ViewScreenRecord viewScreenRecord = this.viewScreenRecord;
        if (viewScreenRecord != null) {
            viewScreenRecord.startViewRecord();
        }
    }

    public void flashClick() {
        if (!CheckUtils.checkPer(getContext(), "android.permission.CAMERA")) {
            this.controlResult.onGone();
            Dexter.withContext(getContext()).withPermission("android.permission.CAMERA").withListener(new PermissionListener() {
                @Override
                public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
                }

                @Override
                public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                    if (ViewControlCenter.this.flashlightProvider.isOn()) {
                        ViewControlCenter.this.flashlightProvider.turnFlashlightOff();
                    } else {
                        ViewControlCenter.this.flashlightProvider.turnFlashlightOn();
                    }
                }

                @Override
                public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                    permissionToken.continuePermissionRequest();
                }
            }).check();
        } else if (this.flashlightProvider.isOn()) {
            this.flashlightProvider.turnFlashlightOff();
        } else {
            this.flashlightProvider.turnFlashlightOn();
        }
    }
}
