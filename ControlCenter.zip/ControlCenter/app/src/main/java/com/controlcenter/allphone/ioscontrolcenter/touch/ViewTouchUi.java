package com.controlcenter.allphone.ioscontrolcenter.touch;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.BaseRequestOptions;
import com.bumptech.glide.request.RequestOptions;
import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.adapter.ModeAssisClick;
import com.controlcenter.allphone.ioscontrolcenter.custom.BaseSetting;
import com.controlcenter.allphone.ioscontrolcenter.custom.ViewItem;
import com.controlcenter.allphone.ioscontrolcenter.dialog.DialogModeAssis;
import com.controlcenter.allphone.ioscontrolcenter.util.AssistiveUtils;
import com.controlcenter.allphone.ioscontrolcenter.util.MyShare;
import com.controlcenter.allphone.ioscontrolcenter.view.ViewControlCenterUi;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.yalantis.ucrop.view.CropImageView;


public class ViewTouchUi extends BaseSetting {
    private final ActivityTouch activityTouch;
    private ViewItem vClick;

    public ViewTouchUi(Context context) {
        super(context);
        this.activityTouch = (ActivityTouch) context;
        setTitle(R.string.touch);
        int i = getResources().getDisplayMetrics().widthPixels;
        int i2 = i / 7;
        ImageView imageView = new ImageView(context);
        imageView.setAdjustViewBounds(true);
        LayoutParams layoutParams = new LayoutParams(-1, -2);
        int i3 = i / 25;
        int i4 = i / 20;
        layoutParams.setMargins(i3, i / 30, i3, i4);
        addView(imageView, layoutParams);
        int i5 = i - ((i * 2) / 25);
        Glide.with(imageView).load("file:///android_asset/main.jpg").apply((BaseRequestOptions<?>) new RequestOptions().override(i5, (i5 * CropImageView.DEFAULT_IMAGE_TO_CROP_BOUNDS_ANIM_DURATION) / 1024).transform(new RoundedCorners((int) getResources().getDimension(R.dimen.border_layout_setting)))).into(imageView);


        LinearLayout makeL = makeL(2);
        ViewItem viewItem = new ViewItem(context);
        viewItem.setItem(R.drawable.ic_single_tap, R.string.single_tap);
        viewItem.addTextMode(MyShare.getSingleTap(context));
        viewItem.setOnClickListener(new OnClickListener() {
            @Override 
            public final void onClick(View view) {
                getInstance((Activity) getContext()).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        ViewTouchUi.this.onItemClick(view);
                    }
                }, MAIN_CLICK);
            }
        });
        makeL.addView(viewItem, -1, i2);
        ViewItem viewItem2 = new ViewItem(context);
        viewItem2.setItem(R.drawable.ic_double_tap, R.string.double_tap);
        viewItem2.addTextMode(MyShare.getDoubleTap(context));
        viewItem2.setOnClickListener(new OnClickListener() {
            @Override 
            public final void onClick(View view) {
                getInstance((Activity) getContext()).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        ViewTouchUi.this.onItemClick(view);
                    }
                }, MAIN_CLICK);
            }
        });
        makeL.addView(viewItem2, -1, i2);
        ViewItem viewItem3 = new ViewItem(context);
        viewItem3.goneDivider();
        viewItem3.setItem(R.drawable.ic_long_press, R.string.long_press);
        viewItem3.addTextMode(MyShare.getLongPress(context));
        viewItem3.setOnClickListener(new OnClickListener() {
            @Override 
            public final void onClick(View view) {
                getInstance((Activity) getContext()).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        ViewTouchUi.this.onItemClick(view);
                    }
                }, MAIN_CLICK);
            }
        });
        makeL.addView(viewItem3, -1, i2);



        ViewItem viewItem4 = new ViewItem(context);
        makeL.addView(viewItem4, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LayoutParams.WRAP_CONTENT
        ));

        getInstance((Activity) getContext()).ShowNativeAd(makeL, AdUtils.NativeType.NATIVE_BIG);
    }

    public void onItemClick(View view) {
        this.vClick = (ViewItem) view;
        new DialogModeAssis(getContext(), AssistiveUtils.makeArrHomeMode(), new ModeAssisClick() {
            @Override
            public final void onItemModeClick(int i) {
                ViewTouchUi.this.m105x37508f2e(i);
            }
        }).show();
    }

    public void m105x37508f2e(int i) {
        this.vClick.addTextMode(i);
        int id = this.vClick.getId();
        if (id == R.string.double_tap) {
            MyShare.putDoubleTap(getContext(), i);
        } else if (id == R.string.long_press) {
            MyShare.putLongPress(getContext(), i);
        } else if (id == R.string.single_tap) {
            MyShare.putSingleTap(getContext(), i);
        }
    }
}
