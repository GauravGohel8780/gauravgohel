package com.controlcenter.allphone.ioscontrolcenter.dialog;


public interface DialogPerResult {
    void onRequestAccessibility();

    void onRequestDrawOther();

    void onRequestPer();

    void onRequestService();

    void onRequestWriteSetting();
}
