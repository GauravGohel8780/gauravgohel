package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewone;

import android.content.Context;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.BaseRequestOptions;
import com.bumptech.glide.request.RequestOptions;
import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemControl;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemIcon;
import com.controlcenter.allphone.ioscontrolcenter.util.LoadApps;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ViewOneChange extends BaseViewOne {
    private ItemControl itemControl;

    public ViewOneChange(Context context) {
        super(context);
    }

    public ItemControl getItemControl() {
        return this.itemControl;
    }

    public void setItemControl(ItemControl itemControl) {
        this.itemControl = itemControl;
        if (itemControl.pkg != null) {
            int widthScreen = (int) ((OtherUtils.getWidthScreen(getContext()) * 2.4f) / 100.0f);
            this.image.setPadding(widthScreen, widthScreen, widthScreen, widthScreen);
            ItemIcon appForPkg = LoadApps.getAppForPkg(getContext().getApplicationContext(), itemControl.pkg, itemControl.className);
            RequestOptions transform = new RequestOptions().override(200, 200).transform(new CenterCrop(), new RoundedCorners(46));
            if (appForPkg != null) {
                if (appForPkg.icon != null) {
                    Glide.with(this.image).load(appForPkg.icon).apply((BaseRequestOptions<?>) transform).into(this.image);
                    return;
                } else {
                    this.image.setImageResource(R.drawable.icon_null);
                    return;
                }
            }
            return;
        }
        switch (itemControl.type) {
            case 1:
                this.image.setImageResource(R.drawable.ic_flash);
                return;
            case 2:
                this.image.setImageResource(R.drawable.ic_timer);
                return;
            case 3:
                this.image.setImageResource(R.drawable.ic_calculator);
                return;
            case 4:
                this.image.setImageResource(R.drawable.ic_camera_control);
                return;
            case 5:
                this.image.setImageResource(R.drawable.ic_screen_record);
                return;
            case 6:
                this.image.setImageResource(R.drawable.ic_screenshot);
                return;
            case 7:
                this.image.setImageResource(R.drawable.ic_battery);
                return;
            case 8:
                this.image.setImageResource(R.drawable.ic_voice_control);
                return;
            case 9:
                this.image.setImageResource(R.drawable.ic_setting_control);
                return;
            default:
                return;
        }
    }
}
