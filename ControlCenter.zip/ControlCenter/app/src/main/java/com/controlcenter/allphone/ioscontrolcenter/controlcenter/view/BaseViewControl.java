package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Color;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.RelativeLayout;

import com.controlcenter.allphone.ioscontrolcenter.controlcenter.ViewControlCenter;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;
import com.controlcenter.allphone.ioscontrolcenter.util.anim.PathInterpolatorCompat;


public class BaseViewControl extends RelativeLayout {
    private final AnimatorSet animRing;
    private BaseTouchDownResult baseTouchDownResult;
    private boolean isAnimRunning;
    private boolean show;
    private float speed;


    public interface BaseTouchDownResult {
        void onTouchDownBaseView(BaseViewControl baseViewControl);
    }

    public void onClick() {
    }

    public boolean onLongClick(ViewControlCenter viewControlCenter) {
        return false;
    }

    public void touchUp() {
    }

    public void setBaseTouchDownResult(BaseTouchDownResult baseTouchDownResult) {
        this.baseTouchDownResult = baseTouchDownResult;
    }

    public BaseViewControl(Context context) {
        super(context);
        setBackground(OtherUtils.bgIcon(Color.parseColor("#70000000"), (OtherUtils.getWidthScreen(context) * 22) / 100));
        setAlpha(0.0f);
        setOnTouchListener(new OnTouchListener() {
            @Override 
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                return BaseViewControl.this.m43xf1bc6895(view, motionEvent);
            }
        });
        ObjectAnimator ofPropertyValuesHolder = ObjectAnimator.ofPropertyValuesHolder(this, PropertyValuesHolder.ofFloat(View.SCALE_X, 1.0f, 0.96f), PropertyValuesHolder.ofFloat(View.SCALE_Y, 1.0f, 0.96f));
        ofPropertyValuesHolder.setDuration(200L);
        ofPropertyValuesHolder.setRepeatCount(1);
        ofPropertyValuesHolder.setRepeatMode(ValueAnimator.REVERSE);
        ofPropertyValuesHolder.setInterpolator(new LinearInterpolator());
        AnimatorSet animatorSet = new AnimatorSet();
        this.animRing = animatorSet;
        animatorSet.play(ofPropertyValuesHolder);
    }

    public boolean m43xf1bc6895(View view, MotionEvent motionEvent) {
        BaseTouchDownResult baseTouchDownResult = this.baseTouchDownResult;
        if (baseTouchDownResult == null) {
            return false;
        }
        baseTouchDownResult.onTouchDownBaseView(this);
        return false;
    }

    public void setSpeed(float f) {
        this.speed = f;
    }

    public void touchDown() {
        setPivotX(getWidth() / 2.0f);
        setPivotY(getHeight() / 2.0f);
        if (this.animRing.isRunning()) {
            this.animRing.cancel();
        }
        this.animRing.start();
    }

    public void onGone() {
        this.show = false;
        this.isAnimRunning = true;
        animate().alpha(0.0f).scaleX(0.8f).scaleY(0.8f).setDuration(250L).withEndAction(new Runnable() {
            @Override 
            public final void run() {
                BaseViewControl.this.m44xb6917ae();
            }
        }).start();
    }

    public void m44xb6917ae() {
        this.isAnimRunning = false;
    }

    private void onShow() {
        this.show = true;
        setPivotX(getWidth() / 2.0f);
        setPivotY(getHeight() / 2.0f);
        setScaleX(0.8f);
        setScaleY(0.8f);
        this.isAnimRunning = true;
        animate().alpha(1.0f).scaleX(1.0f).scaleY(1.0f).setDuration(250L).withEndAction(new Runnable() {
            @Override 
            public final void run() {
                BaseViewControl.this.m45xfd159ecd();
            }
        }).start();
    }

    public void m45xfd159ecd() {
        this.isAnimRunning = false;
    }

    public void run(float f) {
        float f2 = f - 110.0f;
        if (f2 < 0.0f) {
            if (this.show) {
                onGone();
                return;
            }
            return;
        }
        if (!this.show) {
            onShow();
        }
        if (!this.isAnimRunning) {
            animate().cancel();
        }
        setTranslationY((this.speed * f2) / 3.0f);
    }

    public void onEndRun() {
        int translationY = (int) ((getTranslationY() * 730.0f) / 700.0f);
        if (translationY > 730) {
            translationY = 730;
        } else if (translationY < 150) {
            translationY = 150;
        }
        this.show = true;
        animate().translationY(0.0f).alpha(1.0f).scaleX(1.0f).scaleY(1.0f).setDuration(translationY).setInterpolator(PathInterpolatorCompat.create(0.16d, 0.545d, 0.455d, 1.0d)).start();
    }
}
