package com.controlcenter.allphone.ioscontrolcenter.controlcenter.custom;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.View;

import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ViewBattery extends View {
    private Bitmap bm;
    private final Bitmap bmClear;
    private final Bitmap bmSet;
    private Canvas cBm;
    private boolean isChange;
    private final Paint paint;
    private final Paint paintClear;
    private int per;
    private final RectF rIn;
    private RectF rOut;

    public ViewBattery(Context context) {
        super(context);
        Paint paint = new Paint(1);
        this.paint = paint;
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        Paint paint2 = new Paint();
        this.paintClear = paint2;
        paint2.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
        this.rIn = new RectF();
        this.bmClear = OtherUtils.getBitmapFromAsset(context, "icon/icon_set_clear.png");
        this.bmSet = OtherUtils.getBitmapFromAsset(context, "icon/icon_set.png");
    }

    public void setPer(int i, boolean z) {
        this.per = i;
        this.isChange = z;
        invalidate();
    }

    @Override 
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float widthScreen = OtherUtils.getWidthScreen(getContext()) / 300.0f;
        float f = widthScreen < 2.0f ? 2.0f : widthScreen;
        float width = getWidth() - (6.0f * f);
        if (this.rOut == null) {
            float f2 = f / 2.0f;
            this.rOut = new RectF(f2, f2, getWidth() - ((5.0f * f) / 2.0f), getHeight() - f2);
        }
        if (this.isChange) {
            if (this.bm == null) {
                this.bm = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.ARGB_8888);
                this.cBm = new Canvas(this.bm);
            }
            this.cBm.drawColor(-1, PorterDuff.Mode.CLEAR);
            this.paint.setColor(-1);
            this.paint.setStrokeWidth(f);
            this.paint.setStyle(Paint.Style.STROKE);
            this.paint.setAlpha(75);
            float f5 = f * 2.0f;
            this.cBm.drawRoundRect(this.rOut, f5, f5, this.paint);
            this.paint.setStrokeWidth(1.0f);
            this.paint.setStyle(Paint.Style.FILL);
            this.cBm.drawArc(getWidth() - f5, ((getHeight() / 2.0f) - f) - 2.0f, getWidth(), (getHeight() / 2.0f) + f + 2.0f, -90.0f, 180.0f, true, this.paint);
            this.paint.setAlpha(255);
            this.paint.setColor(Color.parseColor("#65c466"));
            int i2 = this.per;
            if (i2 > 1) {
                if (i2 < 4) {
                    i2 = 4;
                }
                this.rIn.set(f5, f5, ((i2 * width) / 100.0f) + f5, getHeight() - f5);
                float f6 = (f * 3.3f) / 3.0f;
                this.cBm.drawRoundRect(this.rIn, f6, f6, this.paint);
            }
            float width2 = (getWidth() * 41.0f) / 100.0f;
            this.rIn.set(((getWidth() - width2) / 2.0f) - f, 0.0f, ((getWidth() + width2) / 2.0f) - f, getHeight());
            this.cBm.drawBitmap(this.bmClear, (Rect) null, this.rIn, this.paintClear);
            this.cBm.drawBitmap(this.bmSet, (Rect) null, this.rIn, (Paint) null);
            canvas.drawBitmap(this.bm, 0.0f, 0.0f, (Paint) null);
            return;
        }
        this.paint.setColor(-1);
        this.paint.setStrokeWidth(f);
        this.paint.setStyle(Paint.Style.STROKE);
        this.paint.setAlpha(75);
        float f3 = f * 2.0f;
        canvas.drawRoundRect(this.rOut, f3, f3, this.paint);
        this.paint.setStrokeWidth(1.0f);
        this.paint.setStyle(Paint.Style.FILL);
        canvas.drawArc(getWidth() - f3, ((getHeight() / 2.0f) - f) - 2.0f, getWidth(), (getHeight() / 2.0f) + f + 2.0f, -90.0f, 180.0f, true, this.paint);
        this.paint.setAlpha(255);
        if (this.per <= 20) {
            this.paint.setColor(Color.parseColor("#e24242"));
        } else {
            this.paint.setColor(-1);
        }
        int i = this.per;
        if (i > 1) {
            if (i < 4) {
                i = 4;
            }
            this.rIn.set(f3, f3, f3 + ((i * width) / 100.0f), getHeight() - f3);
            float f4 = (f * 3.3f) / 3.0f;
            canvas.drawRoundRect(this.rIn, f4, f4, this.paint);
        }
    }
}
