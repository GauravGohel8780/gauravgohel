package com.controlcenter.allphone.ioscontrolcenter;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import static java.security.AccessController.getContext;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.controlcenter.allphone.ioscontrolcenter.custom.ViewSetupVideo;
import com.controlcenter.allphone.ioscontrolcenter.custom.ViewSwitch;
import com.controlcenter.allphone.ioscontrolcenter.dialog.DialogVideo;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemInt;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemVideoConfig;
import com.controlcenter.allphone.ioscontrolcenter.util.MyShare;
import com.controlcenter.allphone.ioscontrolcenter.util.VideoConfig;
import com.controlcenter.allphone.ioscontrolcenter.view.ViewControlCenterUi;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.util.ArrayList;


public class ActivitySetupVideo extends BaseActivity {
    private ItemVideoConfig it;
    private LinearLayout llAdvance;
    private LinearLayout llAudio;
    private ViewSwitch sw;
    private TextView tvAdvance;
    private TextView tvBitAudio;
    private TextView tvBitVideo;
    private TextView tvChang;
    private TextView tvFrame;
    private TextView tvRes;
    private TextView tvSam;
    ViewSetupVideo viewSetupVideo;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        viewSetupVideo = new ViewSetupVideo(this);
        setContentView(viewSetupVideo);
        this.it = MyShare.getRecord(this);

        this.tvAdvance = (TextView) viewSetupVideo.findViewById(R.id.tv_advance);
        this.tvRes = (TextView) viewSetupVideo.findViewById(R.id.tv_resolution);
        this.tvBitVideo = (TextView) viewSetupVideo.findViewById(R.id.tv_bitrate);
        this.tvFrame = (TextView) viewSetupVideo.findViewById(R.id.tv_frame);
        this.tvChang = (TextView) viewSetupVideo.findViewById(R.id.tv_channels);
        this.tvSam = (TextView) viewSetupVideo.findViewById(R.id.tv_sample_rate);
        this.tvBitAudio = (TextView) viewSetupVideo.findViewById(R.id.tv_bitrate_audio);
        this.sw = (ViewSwitch) viewSetupVideo.findViewById(R.id.sw_ena_audio);
        int i = (int) ((getResources().getDisplayMetrics().widthPixels * 6.3f) / 100.0f);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams((int) ((i * 13.6f) / 8.3f), i);
        int i2 = i / 2;
        layoutParams.setMargins(i2, 0, i2, 0);
        this.sw.setLayoutParams(layoutParams);
        this.llAdvance = (LinearLayout) findViewById(R.id.ll_advance);
        this.llAudio = (LinearLayout) findViewById(R.id.ll_audio_more);
        this.sw.setStatusResult(new ViewSwitch.StatusResult() { 
            @Override 
            public final void onSwitchResult(boolean z) {
                ActivitySetupVideo.this.cluck(z);
            }
        });
        updateLayout();
    }

    public void cluck(boolean z) {
        this.it.setEnaAudio(z);
        updateLayout();
    }
    int i;
    String str;
    ArrayList<ItemInt> arrayList;
    public void onClick(final View view) {
        if (view.getId() == R.id.tv_advance) {
            ItemVideoConfig itemVideoConfig = this.it;
            itemVideoConfig.setAdvance(!itemVideoConfig.isAdvance());
            updateLayout();
            return;
        }
        switch (view.getId()) {
            case R.id.ll_bitrate :
                getInstance(ActivitySetupVideo.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        int bitrateVideo = it.getBitrateVideo();
                        String string = getString(R.string.bitrate_kbps);
                        ArrayList<ItemInt> arrBitrateVideo = VideoConfig.arrBitrateVideo();
                        i = bitrateVideo;
                        str = string;
                        arrayList = arrBitrateVideo;
                    }
                }, MAIN_CLICK);

                break;
            case R.id.ll_bitrate_audio :
                getInstance(ActivitySetupVideo.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        int bitrateVideo2 = it.getBitrateAudio();
                        String string2 = getString(R.string.bitrate_kbps);
                        ArrayList<ItemInt> arrBitrateVideo2 = VideoConfig.arrBitrateAudio();
                        i = bitrateVideo2;
                        str = string2;
                        arrayList = arrBitrateVideo2;
                    }
                }, MAIN_CLICK);

                break;
            case R.id.ll_channels :
                getInstance(ActivitySetupVideo.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        int bitrateVideo3 = it.getChannels();
                        String string3 = getString(R.string.channels);
                        ArrayList<ItemInt> arrBitrateVideo3 = VideoConfig.arrChannels();
                        i = bitrateVideo3;
                        str = string3;
                        arrayList = arrBitrateVideo3;
                    }
                }, MAIN_CLICK);

                break;
            case R.id.ll_frame :
                getInstance(ActivitySetupVideo.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        int bitrateVideo4 = it.getFrameRate();
                        String string4 = getString(R.string.frame_rate_fps);
                        ArrayList<ItemInt> arrBitrateVideo4 = VideoConfig.arrFrame();
                        i = bitrateVideo4;
                        str = string4;
                        arrayList = arrBitrateVideo4;
                    }
                }, MAIN_CLICK);

                break;
            case R.id.ll_resolution :
                getInstance(ActivitySetupVideo.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        int bitrateVideo5 = it.getQuality();
                        String string5 = getString(R.string.resolution);
                        ArrayList<ItemInt> arrBitrateVideo5 = VideoConfig.arrRes(ActivitySetupVideo.this);
                        i = bitrateVideo5;
                        str = string5;
                        arrayList = arrBitrateVideo5;
                    }
                }, MAIN_CLICK);

                break;
            case R.id.ll_sample_rate :
                getInstance(ActivitySetupVideo.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        int bitrateVideo6 = it.getSampleRate();
                        String string6 = getString(R.string.sample_rate_hz);
                        ArrayList<ItemInt> arrBitrateVideo6 = VideoConfig.arrSample();
                        i = bitrateVideo6;
                        str = string6;
                        arrayList = arrBitrateVideo6;
                    }
                }, MAIN_CLICK);

                break;
            default:
                str = "";
                arrayList = new ArrayList<>();
                i = 0;
                break;
        }
        new DialogVideo(this, i, str, arrayList, new DialogVideo.VideoResult() {
            @Override
            public final void onResultInt(int i2) {
                ActivitySetupVideo.this.m32xde67ff12(view, i2);
            }
        }).show();
    }

    public void m32xde67ff12(View view, int i) {
        switch (view.getId()) {
            case R.id.ll_bitrate :
                this.it.setBitrateVideo(i);
                break;
            case R.id.ll_bitrate_audio :
                this.it.setBitrateAudio(i);
                break;
            case R.id.ll_channels :
                this.it.setChannels(i);
                break;
            case R.id.ll_frame :
                this.it.setFrameRate(i);
                break;
            case R.id.ll_resolution :
                this.it.setQuality(i);
                break;
            case R.id.ll_sample_rate :
                this.it.setSampleRate(i);
                break;
        }
        updateLayout();
    }

    private void updateLayout() {
        this.tvRes.setText(VideoConfig.getQuality(this, this.it.getQuality()));
        if (!this.it.isAdvance()) {
            this.llAdvance.setVisibility(View.GONE);
            this.tvAdvance.setText(R.string.advance);
        } else {
            this.llAdvance.setVisibility(View.VISIBLE);
            this.tvAdvance.setText(R.string.simple);
            this.tvRes.setText(VideoConfig.getQuality(this, this.it.getQuality()));
            TextView textView = this.tvBitVideo;
            textView.setText(this.it.getBitrateVideo() + "");
            TextView textView2 = this.tvFrame;
            textView2.setText(this.it.getFrameRate() + "");
            if (!this.it.isEnaAudio()) {
                this.sw.setStatus(false);
                this.llAudio.setVisibility(View.GONE);
            } else {
                this.sw.setStatus(true);
                this.llAudio.setVisibility(View.VISIBLE);
                this.tvChang.setText(VideoConfig.getChannels(this.it.getChannels()));
                TextView textView3 = this.tvSam;
                textView3.setText(this.it.getSampleRate() + "");
                TextView textView4 = this.tvBitAudio;
                textView4.setText(this.it.getBitrateAudio() + "");
            }
        }
        MyShare.putRecord(this, this.it);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(ActivitySetupVideo.this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}
