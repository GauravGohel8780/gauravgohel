package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewone;


public interface RecordScreenResult {
    void onRequestPer();

    void onStartRecord();

    void onStopRecord();
}
