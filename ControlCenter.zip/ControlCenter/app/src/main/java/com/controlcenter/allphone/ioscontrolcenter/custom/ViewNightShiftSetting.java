package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.app.TimePickerDialog;
import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TimePicker;

import androidx.core.view.ViewCompat;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.util.MyShare;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;

import java.util.Calendar;


public class ViewNightShiftSetting extends BaseSettingBottom implements View.OnClickListener {
    private NightShiftSettingResult nightShiftSettingResult;
    private final ViewSwitch swManually;
    private final ViewSwitch swScheduled;
    private final ViewTimeScheduled tvFrom;
    private final ViewTimeScheduled tvTo;

    
    public interface NightShiftSettingResult {
        void onChange();
    }

    public void setNightShiftSettingResult(NightShiftSettingResult nightShiftSettingResult) {
        this.nightShiftSettingResult = nightShiftSettingResult;
    }

    public ViewNightShiftSetting(Context context) {
        super(context);
        int i = getResources().getDisplayMetrics().widthPixels;
        this.rlBot.setBackground(OtherUtils.bgTopSearch(Color.parseColor("#f2f2f6"), (i * 21) / 100));
        TextM textM = new TextM(context);
        textM.setId(1230);
        textM.setTextColor(Color.parseColor("#85858a"));
        float f = i;
        float f2 = (3.0f * f) / 100.0f;
        textM.setTextSize(0, f2);
        textM.setText(R.string.content_night_shift);
        LayoutParams layoutParams = new LayoutParams(-2, -2);
        int i2 = i / 15;
        int i3 = i / 20;
        layoutParams.setMargins(i2, i3, i2, i3);
        this.rlBot.addView(textM, layoutParams);
        addDivider(textM);
        int i4 = (int) ((6.3f * f) / 100.0f);
        int i5 = (int) ((i4 * 13.6f) / 8.3f);
        int i6 = i / 25;
        RelativeLayout relativeLayout = new RelativeLayout(context);
        relativeLayout.setId(1231);
        relativeLayout.setBackgroundColor(-1);
        int i7 = i4 + (i6 * 2);
        LayoutParams layoutParams2 = new LayoutParams(-1, i7);
        layoutParams2.addRule(3, textM.getId());
        this.rlBot.addView(relativeLayout, layoutParams2);
        ViewSwitch viewSwitch = new ViewSwitch(context);
        this.swManually = viewSwitch;
        ViewSwitch viewSwitch2 = new ViewSwitch(context);
        this.swScheduled = viewSwitch2;
        viewSwitch2.setStatusResult(new ViewSwitch.StatusResult() {
            @Override
            public final void onSwitchResult(boolean z) {
                MyShare.putEnaNightShift(getContext(), false);
                MyShare.putScheduled(getContext(), z);
                nightShiftSettingResult.onChange();
                swManually.setStatus(false);
            }
        });
        viewSwitch2.setStatus(MyShare.getScheduled(context));
        LayoutParams layoutParams3 = new LayoutParams(i5, i4);
        layoutParams3.addRule(21);
        layoutParams3.addRule(15);
        int i8 = i6 / 2;
        layoutParams3.setMargins(0, 0, i8, 0);
        relativeLayout.addView(viewSwitch2, layoutParams3);
        TextM textM2 = new TextM(context);
        float f3 = (4.2f * f) / 100.0f;
        textM2.setTextSize(0, f3);
        textM2.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        textM2.setText(R.string.scheduled);
        LayoutParams layoutParams4 = new LayoutParams(-2, -2);
        layoutParams4.addRule(15);
        layoutParams4.setMargins(i6, 0, 0, 0);
        relativeLayout.addView(textM2, layoutParams4);
        addDivider(relativeLayout, i6);
        RelativeLayout relativeLayout2 = new RelativeLayout(context);
        relativeLayout2.setId(1232);
        relativeLayout2.setBackgroundColor(-1);
        LayoutParams layoutParams5 = new LayoutParams(-1, i7);
        layoutParams5.addRule(3, relativeLayout.getId());
        this.rlBot.addView(relativeLayout2, layoutParams5);
        TextM textM3 = new TextM(context);
        textM3.setText(R.string.from);
        textM3.setTextSize(0, f3);
        textM3.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        LayoutParams layoutParams6 = new LayoutParams(-2, -2);
        layoutParams6.addRule(15);
        layoutParams6.setMargins(i6, 0, 0, 0);
        relativeLayout2.addView(textM3, layoutParams6);
        ViewTimeScheduled viewTimeScheduled = new ViewTimeScheduled(context);
        this.tvFrom = viewTimeScheduled;
        viewTimeScheduled.setOnClickListener(this);
        viewTimeScheduled.setTime(MyShare.getTimeFrom(context));
        LayoutParams layoutParams7 = new LayoutParams(-2, -2);
        layoutParams7.addRule(21);
        layoutParams7.addRule(15);
        layoutParams7.setMargins(0, 0, i8, 0);
        relativeLayout2.addView(viewTimeScheduled, layoutParams7);
        addDivider(relativeLayout2, i6);
        RelativeLayout relativeLayout3 = new RelativeLayout(context);
        relativeLayout3.setId(1233);
        relativeLayout3.setBackgroundColor(-1);
        LayoutParams layoutParams8 = new LayoutParams(-1, i7);
        layoutParams8.addRule(3, relativeLayout2.getId());
        layoutParams8.setMargins(0, 0, 0, i6);
        this.rlBot.addView(relativeLayout3, layoutParams8);
        TextM textM4 = new TextM(context);
        textM4.setText(R.string.to);
        textM4.setTextSize(0, f3);
        textM4.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        LayoutParams layoutParams9 = new LayoutParams(-2, -2);
        layoutParams9.addRule(15);
        layoutParams9.setMargins(i6, 0, 0, 0);
        relativeLayout3.addView(textM4, layoutParams9);
        ViewTimeScheduled viewTimeScheduled2 = new ViewTimeScheduled(context);
        this.tvTo = viewTimeScheduled2;
        viewTimeScheduled2.setOnClickListener(this);
        viewTimeScheduled2.setTime(MyShare.getTimeTo(context));
        LayoutParams layoutParams10 = new LayoutParams(-2, -2);
        layoutParams10.addRule(21);
        layoutParams10.addRule(15);
        layoutParams10.setMargins(0, 0, i8, 0);
        relativeLayout3.addView(viewTimeScheduled2, layoutParams10);
        RelativeLayout relativeLayout4 = new RelativeLayout(context);
        relativeLayout4.setId(1234);
        relativeLayout4.setBackgroundColor(-1);
        LayoutParams layoutParams11 = new LayoutParams(-1, i7);
        layoutParams11.addRule(3, relativeLayout3.getId());
        layoutParams11.setMargins(0, 0, 0, i6);
        this.rlBot.addView(relativeLayout4, layoutParams11);
        TextM textM5 = new TextM(context);
        textM5.setText(R.string.manually);
        textM5.setTextSize(0, f3);
        textM5.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        LayoutParams layoutParams12 = new LayoutParams(-2, -2);
        layoutParams12.addRule(15);
        layoutParams12.setMargins(i6, 0, 0, 0);
        relativeLayout4.addView(textM5, layoutParams12);
        viewSwitch.setStatusResult(new ViewSwitch.StatusResult() {
            @Override
            public final void onSwitchResult(boolean z) {
                MyShare.putEnaNightShift(getContext(), z);
                MyShare.putScheduled(getContext(), false);
                nightShiftSettingResult.onChange();
                swScheduled.setStatus(false);
            }
        });
        viewSwitch.setStatus(MyShare.getEnaNightShift(context));
        LayoutParams layoutParams13 = new LayoutParams(i5, i4);
        layoutParams13.addRule(21);
        layoutParams13.addRule(15);
        layoutParams13.setMargins(0, 0, i8, 0);
        relativeLayout4.addView(viewSwitch, layoutParams13);
        TextM textM6 = new TextM(context);
        textM6.setId(1235);
        textM6.setTextColor(Color.parseColor("#85858a"));
        textM6.setTextSize(0, f2);
        textM6.setText(R.string.color_tem);
        LayoutParams layoutParams14 = new LayoutParams(-2, -2);
        layoutParams14.setMargins(i2, i3, i2, i / 50);
        layoutParams14.addRule(3, relativeLayout4.getId());
        this.rlBot.addView(textM6, layoutParams14);
        RelativeLayout relativeLayout5 = new RelativeLayout(context);
        relativeLayout5.setBackgroundColor(-1);
        LayoutParams layoutParams15 = new LayoutParams(-1, -2);
        layoutParams15.addRule(3, textM6.getId());
        this.rlBot.addView(relativeLayout5, layoutParams15);
        TextM textM7 = new TextM(context);
        textM7.setId(1236);
        textM7.setText(R.string.less_warm);
        textM7.setTextSize(0, f3);
        textM7.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        LayoutParams layoutParams16 = new LayoutParams(-2, -2);
        layoutParams16.setMargins(i6, i6, 0, 0);
        relativeLayout5.addView(textM7, layoutParams16);
        TextM textM8 = new TextM(context);
        textM8.setText(R.string.more_warm);
        textM8.setTextSize(0, f3);
        textM8.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        LayoutParams layoutParams17 = new LayoutParams(-2, -2);
        layoutParams17.addRule(21);
        layoutParams17.setMargins(0, i6, i6, 0);
        relativeLayout5.addView(textM8, layoutParams17);
        SeekbarNightShift seekbarNightShift = new SeekbarNightShift(context);
        seekbarNightShift.setNightShiftResult(new SeekbarNightShift.OnSbNightShiftResult() {
            @Override
            public final void onChangeValue(int i9) {
                int colorNightShift = MyShare.getColorNightShift(getContext());
                MyShare.putColorNightShift(getContext(), Color.argb(i9 + 20, Color.red(colorNightShift), Color.green(colorNightShift), Color.blue(colorNightShift)));
                nightShiftSettingResult.onChange();
            }
        });
        LayoutParams layoutParams18 = new LayoutParams(-1, i / 10);
        layoutParams18.addRule(3, textM7.getId());
        layoutParams18.setMargins(0, 0, 0, i6);
        relativeLayout5.addView(seekbarNightShift, layoutParams18);
        seekbarNightShift.setProgress(Color.alpha(MyShare.getColorNightShift(getContext())) - 20);
    }

    public void m67xe5a473c0(boolean z) {

    }

    public void m68xa01a1441(boolean z) {

    }

    public void m69x5a8fb4c2(int i) {

    }

    public void updateNightShift() {
        this.swManually.setStatus(MyShare.getEnaNightShift(getContext()));
        this.swScheduled.setStatus(MyShare.getScheduled(getContext()));
    }

    @Override 
    public void onClick(final View view) {
        long timeTo;
        if (view == this.tvFrom) {
            timeTo = MyShare.getTimeFrom(getContext());
        } else {
            timeTo = MyShare.getTimeTo(getContext());
        }
        final Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(timeTo);
        new TimePickerDialog(getContext(), new TimePickerDialog.OnTimeSetListener() {
            @Override
            public final void onTimeSet(TimePicker timePicker, int i, int i2) {
                ViewNightShiftSetting.this.clickTimeset(calendar, view, timePicker, i, i2);
            }
        }, calendar.get(11), calendar.get(12), true).show();
    }

    public void clickTimeset(Calendar calendar, View view, TimePicker timePicker, int i, int i2) {
        calendar.set(11, i);
        calendar.set(12, i2);
        if (view == this.tvFrom) {
            MyShare.putTimeFrom(getContext(), calendar.getTimeInMillis());
            this.tvFrom.setTime(calendar.getTimeInMillis());
        } else {
            MyShare.putTimeTo(getContext(), calendar.getTimeInMillis());
            this.tvTo.setTime(calendar.getTimeInMillis());
        }
        this.nightShiftSettingResult.onChange();
    }
}
