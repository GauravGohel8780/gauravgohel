package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewone;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.TransitionDrawable;
import android.os.Handler;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.RelativeLayout;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.custom.TextM;
import com.controlcenter.allphone.ioscontrolcenter.util.CheckUtils;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;


public class ViewScreenRecord extends ViewOneChange {
    private final AnimatorSet animLock;
    private int count;
    private final Handler handler;
    private int isRecord;
    private RecordScreenResult recordScreenResult;
    private final Runnable runnable;
    private final TransitionDrawable transition;
    private final TextM tvCount;

    static int access$010(ViewScreenRecord viewScreenRecord) {
        int i = viewScreenRecord.count;
        viewScreenRecord.count = i - 1;
        return i;
    }

    public void setRecordScreenResult(RecordScreenResult recordScreenResult) {
        this.recordScreenResult = recordScreenResult;
    }

    public ViewScreenRecord(Context context) {
        super(context);
        this.runnable = new Runnable() {
            @Override 
            public void run() {
                ViewScreenRecord.access$010(ViewScreenRecord.this);
                TextM textM = ViewScreenRecord.this.tvCount;
                textM.setText(ViewScreenRecord.this.count + "");
                if (ViewScreenRecord.this.count > 0) {
                    ViewScreenRecord.this.handler.postDelayed(this, 1000L);
                } else {
                    ViewScreenRecord.this.startRecord();
                }
            }
        };
        float widthScreen = (OtherUtils.getWidthScreen(getContext()) * 22) / 100;
        TransitionDrawable transitionDrawable = new TransitionDrawable(new Drawable[]{OtherUtils.bgIcon(Color.parseColor("#70000000"), widthScreen), OtherUtils.bgIcon(Color.parseColor("#c3ffffff"), widthScreen)});
        this.transition = transitionDrawable;
        setBackground(transitionDrawable);
        TextM textM = new TextM(context);
        this.tvCount = textM;
        textM.setBackgroundResource(R.drawable.ic_screen_record_in);
        textM.setGravity(17);
        textM.setTextColor(-1);
        textM.setTextSize(0, (4.0f * widthScreen) / 22.0f);
        int widthScreen2 = (int) ((OtherUtils.getWidthScreen(context) * 4.4f) / 100.0f);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
        layoutParams.setMargins(widthScreen2, widthScreen2, widthScreen2, widthScreen2);
        addView(textM, layoutParams);
        this.handler = new Handler();
        ObjectAnimator ofPropertyValuesHolder = ObjectAnimator.ofPropertyValuesHolder(textM, PropertyValuesHolder.ofFloat(View.ALPHA, 1.0f, 0.0f));
        ofPropertyValuesHolder.setDuration(1000L);
        ofPropertyValuesHolder.setRepeatCount(-1);
        ofPropertyValuesHolder.setRepeatMode(ValueAnimator.REVERSE);
        ofPropertyValuesHolder.setInterpolator(new DecelerateInterpolator());
        AnimatorSet animatorSet = new AnimatorSet();
        this.animLock = animatorSet;
        animatorSet.play(ofPropertyValuesHolder);
    }

    @Override
    public void onClick() {
        super.onClick();
        int i = this.isRecord;
        if (i == 0) {
            if (!CheckUtils.checkPer(getContext(), "android.permission.RECORD_AUDIO")) {
                this.recordScreenResult.onRequestPer();
            }
            Dexter.withContext(getContext()).withPermission("android.permission.RECORD_AUDIO").withListener(new PermissionListener() {
                @Override
                public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
                }

                @Override
                public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                    ViewScreenRecord.this.pre();
                }

                @Override
                public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                    permissionToken.continuePermissionRequest();
                }
            }).check();
        } else if (i == -1) {
            this.handler.removeCallbacks(this.runnable);
            this.isRecord = 0;
            this.tvCount.setBackgroundResource(R.drawable.ic_screen_record_in);
            this.tvCount.setText("");
        } else {
            stopRecord();
        }
    }

    public void pre() {
        this.tvCount.setBackgroundColor(0);
        this.isRecord = -1;
        this.count = 4;
        this.handler.removeCallbacks(this.runnable);
        this.handler.post(this.runnable);
    }

    public void startRecord() {
        startViewRecord();
        this.recordScreenResult.onStartRecord();
    }

    private void stopRecord() {
        stopViewRecord();
        this.recordScreenResult.onStopRecord();
    }

    public void startViewRecord() {
        this.tvCount.setText("");
        this.isRecord = 1;
        this.image.setColorFilter(Color.parseColor("#e06361"));
        this.tvCount.setBackgroundResource(R.drawable.ic_screen_record_in_on);
        this.animLock.start();
        this.transition.startTransition(300);
    }

    public void stopViewRecord() {
        if (this.isRecord == 0) {
            return;
        }
        this.isRecord = 0;
        this.transition.reverseTransition(300);
        this.animLock.cancel();
        this.image.clearColorFilter();
        this.tvCount.setAlpha(1.0f);
        this.tvCount.setBackgroundResource(R.drawable.ic_screen_record_in);
    }

    public boolean isRecord() {
        return this.isRecord != 0;
    }
}
