package com.controlcenter.allphone.ioscontrolcenter.util;

import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.widget.Toast;

import androidx.core.net.MailTo;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemIcon;


public class ActionUtils {
    public static void openApp(Context context, ItemIcon itemIcon) {
        try {
            Intent intent = new Intent("android.intent.action.MAIN");
            intent.addCategory("android.intent.category.LAUNCHER");
            intent.setComponent(new ComponentName(itemIcon.pkg, itemIcon.className));
            intent.setFlags(270532608);
            context.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(context, (int) R.string.not_app, Toast.LENGTH_SHORT).show();
        }
    }

    public static void openApp(Context context, String str, String str2) {
        try {
            Intent intent = new Intent("android.intent.action.MAIN");
            intent.addCategory("android.intent.category.LAUNCHER");
            intent.setComponent(new ComponentName(str, str2));
            intent.setFlags(270532608);
            context.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(context, (int) R.string.not_app, Toast.LENGTH_SHORT).show();
        }
    }

    public static void feedback(Context context) {
        Uri uri = Uri.parse("market://details?id=" + context.getPackageName());
        Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
        try {
            context.startActivity(myAppLinkToMarket);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(context.getApplicationContext(), " unable to find market app", Toast.LENGTH_LONG).show();
        }
    }

    public static void vibration(Context context) {
        Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null) {
            if (Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(VibrationEffect.createOneShot(100L, -1));
            } else {
                vibrator.vibrate(100L);
            }
        }
    }

    public static void openTimer(Context context) {
        try {
            Intent intent = new Intent("android.intent.action.SET_TIMER");
            intent.putExtra("android.intent.extra.alarm.MESSAGE", "New Alarm");
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            ItemIcon findAppForKey = LoadApps.findAppForKey(context, "clock");
            if (findAppForKey != null) {
                openApp(context, findAppForKey);
            } else {
                Toast.makeText(context, (int) R.string.cancel_not_open, Toast.LENGTH_SHORT).show();
            }
        }
    }

    public static void openCal(Context context) {
        ItemIcon findAppForKey = LoadApps.findAppForKey(context, "calculator");
        if (findAppForKey != null) {
            openApp(context, findAppForKey);
        } else {
            Toast.makeText(context, (int) R.string.cancel_not_open, Toast.LENGTH_SHORT).show();
        }
    }

    public static void openCameraDefault(Context context) {
        try {
            Intent intent = new Intent("android.media.action.STILL_IMAGE_CAMERA");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(context, (int) R.string.cancel_not_open, Toast.LENGTH_SHORT).show();
        }
    }

    public static void openVoice(Context context) {
        try {
            Intent intent = new Intent("android.provider.MediaStore.RECORD_SOUND");
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            ItemIcon findAppForKey = LoadApps.findAppForKey(context, "recorder", "voice", "record");
            if (findAppForKey != null) {
                openApp(context, findAppForKey);
            } else {
                Toast.makeText(context, (int) R.string.cancel_not_open, Toast.LENGTH_SHORT).show();
            }
        }
    }

    public static void openSetting(Context context) {
        try {
            Intent intent = new Intent("android.settings.SETTINGS");
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(context, (int) R.string.cancel_not_open, Toast.LENGTH_SHORT).show();
        }
    }

    public static void openBattery(Context context) {
        if (Build.VERSION.SDK_INT >= 22) {
            try {
                Intent intent = new Intent("android.settings.BATTERY_SAVER_SETTINGS");
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(context, (int) R.string.cancel_not_open, Toast.LENGTH_SHORT).show();
            }
        }
    }

    public static void openLink(Context context, String str) {
        try {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse(str.replace("HTTPS", "https")));
            context.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(context, context.getString(R.string.no_browser), Toast.LENGTH_SHORT).show();
        }
    }

    public static void openOtherApps(Context context) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse("https://play.google.com/store/apps/dev").buildUpon().appendQueryParameter("id", MyConst.ID_DEV).build());
        try {
            context.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void playSoundScreenShot(Context context) {
        MediaPlayer.create(context, (int) R.raw.screenshot_sound).start();
    }
}
