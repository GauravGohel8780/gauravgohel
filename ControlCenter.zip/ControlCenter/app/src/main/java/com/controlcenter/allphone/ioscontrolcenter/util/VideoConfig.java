package com.controlcenter.allphone.ioscontrolcenter.util;

import android.content.Context;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemInt;

import java.util.ArrayList;


public class VideoConfig {
    public static String getChannels(int i) {
        return i == 1 ? "mono" : "stereo";
    }

    public static String getQuality(Context context, int i) {
        switch (i) {
            case 4:
                return "720x480";
            case 5:
                return "1280x720";
            case 6:
                return "1920x1080";
            case 7:
                return "320x240";
            case 8:
                return "3840x2160";
            default:
                return context.getString(R.string.recommend);
        }
    }

    public static ArrayList<ItemInt> arrRes(Context context) {
        ArrayList<ItemInt> arrayList = new ArrayList<>();
        arrayList.add(new ItemInt(getQuality(context, 1), 1));
        arrayList.add(new ItemInt(getQuality(context, 7), 7));
        arrayList.add(new ItemInt(getQuality(context, 4), 4));
        arrayList.add(new ItemInt(getQuality(context, 5), 5));
        arrayList.add(new ItemInt(getQuality(context, 6), 6));
        arrayList.add(new ItemInt(getQuality(context, 8), 8));
        return arrayList;
    }

    public static ArrayList<ItemInt> arrBitrateVideo() {
        ArrayList<ItemInt> arrayList = new ArrayList<>();
        arrayList.add(new ItemInt("1200", 1200000));
        arrayList.add(new ItemInt("1600", 1600000));
        arrayList.add(new ItemInt("2000", 2000000));
        arrayList.add(new ItemInt("2500", 2500000));
        arrayList.add(new ItemInt("5000", 5000000));
        arrayList.add(new ItemInt("10000", 10000000));
        arrayList.add(new ItemInt("15000", 15000000));
        arrayList.add(new ItemInt("20000", 20000000));
        arrayList.add(new ItemInt("25000", 25000000));
        return arrayList;
    }

    public static ArrayList<ItemInt> arrFrame() {
        ArrayList<ItemInt> arrayList = new ArrayList<>();
        arrayList.add(new ItemInt("15", 15));
        arrayList.add(new ItemInt("25", 25));
        arrayList.add(new ItemInt("30", 30));
        arrayList.add(new ItemInt("60", 60));
        arrayList.add(new ItemInt("90", 90));
        arrayList.add(new ItemInt("120", 120));
        return arrayList;
    }

    public static ArrayList<ItemInt> arrChannels() {
        ArrayList<ItemInt> arrayList = new ArrayList<>();
        arrayList.add(new ItemInt("mono", 1));
        arrayList.add(new ItemInt("stereo", 2));
        return arrayList;
    }

    public static ArrayList<ItemInt> arrSample() {
        ArrayList<ItemInt> arrayList = new ArrayList<>();
        arrayList.add(new ItemInt("8000", 8000));
        arrayList.add(new ItemInt("11000", 11000));
        arrayList.add(new ItemInt("12000", 12000));
        arrayList.add(new ItemInt("16000", 16000));
        arrayList.add(new ItemInt("22000", 22000));
        arrayList.add(new ItemInt("24000", 24000));
        arrayList.add(new ItemInt("32000", 32000));
        arrayList.add(new ItemInt("44100", 44100));
        arrayList.add(new ItemInt("48000", 48000));
        arrayList.add(new ItemInt("96000", 96000));
        return arrayList;
    }

    public static ArrayList<ItemInt> arrBitrateAudio() {
        ArrayList<ItemInt> arrayList = new ArrayList<>();
        arrayList.add(new ItemInt("80", 80000));
        arrayList.add(new ItemInt("160", 160000));
        arrayList.add(new ItemInt("240", 240000));
        arrayList.add(new ItemInt("320", 320000));
        arrayList.add(new ItemInt("400", 400000));
        arrayList.add(new ItemInt("480", 480000));
        return arrayList;
    }
}
