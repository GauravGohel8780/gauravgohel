package com.controlcenter.allphone.ioscontrolcenter.service;

import android.service.notification.NotificationListenerService;


public class NotificationService extends NotificationListenerService {
}
