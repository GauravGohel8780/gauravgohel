package com.controlcenter.allphone.ioscontrolcenter.item;


public class ItemStatusBattery {
    private boolean isChange;
    private int per;

    public ItemStatusBattery(boolean z, int i) {
        this.isChange = z;
        this.per = i;
    }

    public boolean isChange() {
        return this.isChange;
    }

    public int getPer() {
        return this.per;
    }
}
