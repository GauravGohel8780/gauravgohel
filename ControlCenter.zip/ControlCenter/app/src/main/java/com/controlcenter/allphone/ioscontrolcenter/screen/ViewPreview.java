package com.controlcenter.allphone.ioscontrolcenter.screen;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.cardview.widget.CardView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.BaseRequestOptions;
import com.bumptech.glide.request.RequestOptions;
import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.util.MyShare;
import com.controlcenter.allphone.ioscontrolcenter.util.OnSwipeFolder;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ViewPreview extends RelativeLayout {
    private final CardView cv;
    private final Handler handler;
    private final int height;
    private final ImageView imPreview;
    private final Runnable runnable;
    private ShowEndResult showEndResult;
    private Uri uri;
    private final ImageView vPlay;
    private final int width;


    public interface ShowEndResult {
        void onClickImage(Uri uri);

        void onEnd();
    }

    public void setShowEndResult(ShowEndResult showEndResult) {
        this.showEndResult = showEndResult;
    }

    public ViewPreview(Context context) {
        super(context);
        this.runnable = new AnonymousClass2();
        int[] sizes = MyShare.getSizes(context);
        int widthScreen = OtherUtils.getWidthScreen(context);
        int i = (widthScreen * 19) / 100;
        this.width = i;
        this.height = (sizes[1] * i) / sizes[0];
        CardView cardView = new CardView(context);
        this.cv = cardView;
        cardView.setCardBackgroundColor(0);
        float f = widthScreen;
        cardView.setRadius(f / 60.0f);
        cardView.setCardElevation(f / 100.0f);
        RelativeLayout relativeLayout = new RelativeLayout(context);
        cardView.addView(relativeLayout, -1, -1);
        ImageView imageView = new ImageView(context);
        this.imPreview = imageView;
        relativeLayout.addView(imageView, -1, -1);
        ImageView imageView2 = new ImageView(context);
        this.vPlay = imageView2;
        imageView2.setImageResource(R.drawable.ic_play);
        imageView2.setColorFilter(-1);
        LayoutParams layoutParams = new LayoutParams(i / 4, i / 4);
        layoutParams.addRule(13);
        relativeLayout.addView(imageView2, layoutParams);
        this.handler = new Handler();
        imageView.setOnTouchListener(new OnSwipeFolder(context, new OnSwipeFolder.TouchResult() {
            @Override
            public void onTouchUp() {
            }

            @Override
            public void onSwipeRight() {
                onSwipeLeft();
            }

            @Override
            public void onSwipeLeft() {
                ViewPreview.this.handler.post(ViewPreview.this.runnable);
            }

            @Override
            public void onCancel() {
                onSwipeLeft();
            }

            @Override
            public void onMoveHorizontal(float f2) {
                ViewPreview.this.handler.removeCallbacks(ViewPreview.this.runnable);
                if (f2 < 0.0f) {
                    ViewPreview.this.cv.setTranslationX(f2);
                }
            }

            @Override
            public void onClick() {
                ViewPreview.this.handler.removeCallbacks(ViewPreview.this.runnable);
                ViewPreview.this.handler.post(ViewPreview.this.runnable);
                ViewPreview.this.showEndResult.onClickImage(ViewPreview.this.uri);
            }

            @Override
            public void onLongClick() {
                ViewPreview.this.handler.removeCallbacks(ViewPreview.this.runnable);
                ViewPreview.this.handler.post(ViewPreview.this.runnable);
                ViewPreview.this.showEndResult.onClickImage(ViewPreview.this.uri);
            }
        }));
    }

    public void setPreview(Uri uri, boolean z, boolean z2) {
        removeAllViews();
        int i = this.width;
        int i2 = this.height;
        if (!z) {
            i2 = i;
        }
        if (z2) {
            this.vPlay.setVisibility(View.VISIBLE);
        } else {
            this.vPlay.setVisibility(View.GONE);
        }
        int i3 = (i * 4) / 19;
        LayoutParams layoutParams = new LayoutParams(i, i2);
        layoutParams.addRule(15);
        layoutParams.setMargins(i3, 0, 0, i3);
        addView(this.cv, layoutParams);
        this.uri = uri;
        Glide.with(this.imPreview).load(uri).apply((BaseRequestOptions<?>) new RequestOptions().override(i, i2).transform(new CenterCrop(), new RoundedCorners((this.width * 38) / 180))).placeholder((int) R.drawable.bg_place).into(this.imPreview);
        this.cv.setAlpha(0.0f);
        this.cv.setTranslationX(0.0f);
        this.cv.animate().alpha(1.0f).setDuration(1000L).withEndAction(null).start();
        this.handler.postDelayed(this.runnable, 4000L);
    }


    public class AnonymousClass2 implements Runnable {
        AnonymousClass2() {
        }

        @Override 
        public void run() {
            ViewPreview.this.cv.animate().alpha(0.0f).translationX(-((OtherUtils.getWidthScreen(ViewPreview.this.getContext()) * 28) / 100)).setDuration(350L).withEndAction(new Runnable() { // from class: com.controlcenter.allphone.ioscontrolcenter.screen.ViewPreview.AnonymousClass2.1
                @Override 
                public final void run() {
                    ViewPreview.this.showEndResult.onEnd();
                }
            }).start();
        }
    }
}
