package com.controlcenter.allphone.ioscontrolcenter.dialog;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;

import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.adapter.AdapterMode;
import com.controlcenter.allphone.ioscontrolcenter.adapter.ModeAssisClick;
import com.controlcenter.allphone.ioscontrolcenter.custom.TextB;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemMode;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;

import java.util.ArrayList;


public class DialogModeAssis extends BaseDialog {
    private final ArrayList<ItemMode> arrMode;
    private final ModeAssisClick modeAssisClick;

    public DialogModeAssis(Context context, ArrayList<ItemMode> arrayList, ModeAssisClick modeAssisClick) {
        super(context);
        this.modeAssisClick = modeAssisClick;
        this.arrMode = arrayList;
        setCancelable(true);
    }

    @Override 
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        int i = getContext().getResources().getDisplayMetrics().widthPixels;
        LinearLayout linearLayout = new LinearLayout(getContext());
        linearLayout.setGravity(17);
        LinearLayout linearLayout2 = new LinearLayout(getContext());
        linearLayout2.setOrientation(LinearLayout.VERTICAL);
        linearLayout2.setGravity(1);
        linearLayout.addView(linearLayout2, (i * 72) / 100, (i * 11) / 10);
        setContentView(linearLayout);
        int i2 = i / 30;
        TextB textB = new TextB(getContext());
        textB.setTextSize(0, (i * 4.0f) / 100.0f);
        textB.setPadding(i2, i2, i2, i2);
        textB.setText(R.string.select_action);
        linearLayout2.addView(textB, -2, -2);
        RecyclerView recyclerView = new RecyclerView(getContext());
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        layoutParams.setMargins(0, 0, 0, i2);
        linearLayout2.addView(recyclerView, layoutParams);
        recyclerView.setAdapter(new AdapterMode(this.arrMode, new ModeAssisClick() { // from class: com.controlcenter.allphone.ioscontrolcenter.dialog.DialogModeAssis.1
            @Override // com.controlcenter.allphone.ioscontrolcenter.adapter.ModeAssisClick
            public final void onItemModeClick(int i3) {
                modeAssisClick.onItemModeClick(i);
                cancel();
            }
        }));
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 4, RecyclerView.VERTICAL, false));
        linearLayout2.setBackground(OtherUtils.bgLayout(getContext(), Color.parseColor("#eaffffff")));
        textB.setTextColor(ViewCompat.MEASURED_STATE_MASK);
    }


}
