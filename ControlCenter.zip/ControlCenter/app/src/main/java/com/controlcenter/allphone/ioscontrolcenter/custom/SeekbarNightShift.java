package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class SeekbarNightShift extends View {
    private OnSbNightShiftResult nightShiftResult;
    private final Paint paint;
    private int progress;

    
    public interface OnSbNightShiftResult {
        void onChangeValue(int i);
    }

    public void setNightShiftResult(OnSbNightShiftResult onSbNightShiftResult) {
        this.nightShiftResult = onSbNightShiftResult;
    }

    public SeekbarNightShift(Context context) {
        super(context);
        Paint paint = new Paint(1);
        this.paint = paint;
        paint.setStyle(Paint.Style.FILL);
        paint.setStrokeWidth(OtherUtils.getWidthScreen(getContext()) / 100.0f);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeCap(Paint.Cap.ROUND);
    }

    public void setProgress(int i) {
        this.progress = i;
        invalidate();
    }

    @Override 
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int widthScreen = OtherUtils.getWidthScreen(getContext());
        this.paint.clearShadowLayer();
        this.paint.setColor(Color.parseColor("#989898"));
        float f = widthScreen;
        float f2 = f / 35.0f;
        float f3 = (widthScreen * 6) / 100.0f;
        canvas.drawLine(f3, getHeight() / 2.0f, getWidth() - f3, getHeight() / 2.0f, this.paint);
        float f4 = f / 110.0f;
        canvas.drawCircle(f3, getHeight() / 2.0f, f4, this.paint);
        canvas.drawCircle(getWidth() - f3, getHeight() / 2.0f, f4, this.paint);
        canvas.drawCircle(getWidth() / 2.0f, getHeight() / 2.0f, f4, this.paint);
        this.paint.setColor(-1);
        this.paint.setShadowLayer(f2 / 2.0f, 0.0f, 0.0f, Color.parseColor("#30000000"));
        canvas.drawCircle((((getWidth() - (f3 * 2.0f)) * this.progress) / 100.0f) + f3, getHeight() / 2.0f, f2, this.paint);
    }

    @Override 
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 2) {
            float widthScreen = (OtherUtils.getWidthScreen(getContext()) * 6) / 100.0f;
            float x = motionEvent.getX();
            if (x < widthScreen) {
                x = widthScreen;
            } else if (x > getWidth() - widthScreen) {
                x = getWidth() - widthScreen;
            }
            this.progress = (int) (((x - widthScreen) * 100.0f) / (getWidth() - (2.0f * widthScreen)));
            invalidate();
        } else if (motionEvent.getAction() == 1) {
            this.nightShiftResult.onChangeValue(this.progress);
        }
        return true;
    }
}
