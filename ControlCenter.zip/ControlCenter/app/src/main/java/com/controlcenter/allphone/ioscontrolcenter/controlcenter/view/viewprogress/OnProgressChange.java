package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewprogress;

import android.view.View;


public interface OnProgressChange {
    void onChange(View view, int i);

    void onLongClick(View view);

    void onTouchDown();

    void onTouchUp();
}
