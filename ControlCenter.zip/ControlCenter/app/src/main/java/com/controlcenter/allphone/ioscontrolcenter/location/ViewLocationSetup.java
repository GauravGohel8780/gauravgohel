package com.controlcenter.allphone.ioscontrolcenter.location;

import static com.iten.tenoku.ad.AdShow.getInstance;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.widget.LinearLayout;

import androidx.appcompat.view.menu.MenuView;
import androidx.core.view.ViewCompat;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.custom.BaseSetting;
import com.controlcenter.allphone.ioscontrolcenter.custom.LayoutClick;
import com.controlcenter.allphone.ioscontrolcenter.custom.LayoutColor;
import com.controlcenter.allphone.ioscontrolcenter.custom.LayoutSeeBar;
import com.controlcenter.allphone.ioscontrolcenter.custom.MyScrollView;
import com.controlcenter.allphone.ioscontrolcenter.custom.TextB;
import com.controlcenter.allphone.ioscontrolcenter.custom.TextM;
import com.controlcenter.allphone.ioscontrolcenter.custom.ViewItem;
import com.controlcenter.allphone.ioscontrolcenter.custom.ViewItemPosition;
import com.controlcenter.allphone.ioscontrolcenter.util.ActionUtils;
import com.controlcenter.allphone.ioscontrolcenter.util.MyConst;
import com.controlcenter.allphone.ioscontrolcenter.util.MyShare;
import com.iten.tenoku.utils.AdUtils;


public class ViewLocationSetup extends BaseSetting implements LayoutSeeBar.SeeBarResult {
    private final ActivityLocation activityLocation;
    private int color;
    private final LayoutSeeBar lAlpha;
    private final LayoutSeeBar lHeight;
    private final LayoutSeeBar lWidth;
    private ViewItemPosition vClick;

    public void setSv(MyScrollView myScrollView) {
        this.lAlpha.setSv(myScrollView);
        this.lWidth.setSv(myScrollView);
        this.lHeight.setSv(myScrollView);
    }

    public ViewLocationSetup(Context context) {
        super(context);
        this.activityLocation = (ActivityLocation) context;
        setTitle(R.string.setting_d);
        int i2 = getResources().getDisplayMetrics().widthPixels;
        int i3 = (i2 * 22) / 100;
        TextM textM = new TextM(context);
        textM.setText(R.string.content_loc);
        textM.setTextColor(Color.parseColor("#222222"));
        float f = i2;
        textM.setTextSize(0, (3.3f * f) / 100.0f);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        int i4 = i2 / 25;
        int i5 = i2 / 50;
        layoutParams.setMargins(i2 / 15, i4, i4, i5);
        addView(textM, layoutParams);
        LinearLayout makeL = makeL(0);
        makeL.setOrientation(LinearLayout.HORIZONTAL);
        makeL.setGravity(1);
        int orientation = MyShare.getOrientation(context);
        ViewItemPosition viewItemPosition = new ViewItemPosition(context);
        viewItemPosition.setId(3);
        viewItemPosition.setImage("file:///android_asset/preview/img_pre_left.png", R.string.left);
        viewItemPosition.setLayoutClick(new LayoutClick() {
            @Override
            public final void onActionClick(View view) {
                ViewLocationSetup.this.onActionClick(view);
            }
        });
        viewItemPosition.choose(orientation == 3);
        makeL.addView(viewItemPosition, i3, -2);
        ViewItemPosition viewItemPosition2 = new ViewItemPosition(context);
        viewItemPosition2.setId(1);
        viewItemPosition2.setImage("file:///android_asset/preview/img_pre_top.png", R.string.top);
        viewItemPosition2.setLayoutClick(new LayoutClick() {
            @Override
            public final void onActionClick(View view) {
                ViewLocationSetup.this.onActionClick(view);
            }
        });
        viewItemPosition2.choose(orientation == 1);
        makeL.addView(viewItemPosition2, i3, -2);
        ViewItemPosition viewItemPosition3 = new ViewItemPosition(context);
        viewItemPosition3.setId(4);
        viewItemPosition3.setImage("file:///android_asset/preview/img_pre_right.png", R.string.right);
        viewItemPosition3.setLayoutClick(new LayoutClick() {
            @Override
            public final void onActionClick(View view) {
                ViewLocationSetup.this.onActionClick(view);
            }
        });
        viewItemPosition3.choose(orientation == 4);
        makeL.addView(viewItemPosition3, i3, -2);
        ViewItemPosition viewItemPosition4 = new ViewItemPosition(context);
        viewItemPosition4.setId(2);
        viewItemPosition4.setImage("file:///android_asset/preview/img_pre_bot.png", R.string.bot);
        viewItemPosition4.setLayoutClick(new LayoutClick() {
            @Override
            public final void onActionClick(View view) {
                ViewLocationSetup.this.onActionClick(view);
            }
        });
        viewItemPosition4.choose(orientation == 2);
        makeL.addView(viewItemPosition4, i3, -2);
        if (orientation == 1) {
            this.vClick = viewItemPosition2;
        } else if (orientation == 3) {
            this.vClick = viewItemPosition;
        } else if (orientation == 4) {
            this.vClick = viewItemPosition3;
        } else {
            this.vClick = viewItemPosition4;
        }
        int[] sizeNotification = MyShare.getSizeNotification(context);
        LinearLayout makeL3 = makeL(0);
        LayoutColor layoutColor = new LayoutColor(context);
        layoutColor.setColorResult(new LayoutColor.ColorResult() {
            @Override
            public final void onColorChange(int i9) {
                ViewLocationSetup.this.onColorChange(i9);
            }
        });
        makeL3.addView(layoutColor, -1, (i2 * 16) / 100);

        LinearLayout llads1 = makeL(4);
        ViewItem viads2 = new ViewItem(context);
        llads1.addView(viads2, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
        ));

        getInstance((Activity) getContext()).ShowNativeAd(llads1, AdUtils.NativeType.NATIVE_MEDIUM);

        LayoutSeeBar layoutSeeBar = new LayoutSeeBar(context);
        this.lWidth = layoutSeeBar;
        layoutSeeBar.setData(R.string.width, false);
        layoutSeeBar.setOnSeekBarChange(this);
        makeL3.addView(layoutSeeBar, -1, -2);
        layoutSeeBar.setProgress(((sizeNotification[0] - i4) * 100) / ((i2 * 45) / 100));
        LayoutSeeBar layoutSeeBar2 = new LayoutSeeBar(context);
        this.lHeight = layoutSeeBar2;
        layoutSeeBar2.setData(R.string.height, false);
        layoutSeeBar2.setOnSeekBarChange(this);
        makeL3.addView(layoutSeeBar2, -1, -2);
        layoutSeeBar2.setProgress(((sizeNotification[1] - i4) * 100) / ((i2 * 6) / 100));
        this.color = MyShare.getColorNotification(context);
        LayoutSeeBar layoutSeeBar3 = new LayoutSeeBar(context);
        this.lAlpha = layoutSeeBar3;
        layoutSeeBar3.setColor(Color.rgb(Color.red(this.color), Color.green(this.color), Color.blue(this.color)));
        layoutSeeBar3.setProgress((Color.alpha(this.color) * 100) / 256);
        layoutSeeBar3.setData(R.string.alpha, true);
        layoutSeeBar3.setOnSeekBarChange(this);
        makeL3.addView(layoutSeeBar3, -1, -2);
        LinearLayout makeL4 = makeL(0);
        TextB textB2 = new TextB(context);
        textB2.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        textB2.setText(R.string.note);
        textB2.setTextSize(0, (4.5f * f) / 100.0f);
        textB2.setPadding(i4, i4, i4, 0);
        makeL4.addView(textB2, -2, -2);
        TextM textM3 = new TextM(context);
        textM3.setText(R.string.content_note);
        textM3.setTextSize(0, (3.0f * f) / 100.0f);
        textM3.setTextColor(Color.parseColor("#222222"));
        textM3.setPadding(i4, 0, i4, i4);
        makeL4.addView(textM3, -2, -2);
        TextB textB3 = new TextB(context);
        textB3.setText(R.string.guild);
        textB3.setGravity(1);
        int i9 = i4 / 3;
        textB3.setPadding(0, i9, 0, i9);
        textB3.setTextSize(0, (3.5f * f) / 100.0f);
        textB3.setTextColor(-1);
        textB3.setBackgroundResource(R.drawable.bg_sel_tv_premium);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams4.setMargins(i4, 0, i4, i4);
        makeL4.addView(textB3, layoutParams4);
        textB3.setOnClickListener(new View.OnClickListener() {
            @Override 
            public final void onClick(View view) {
                ActionUtils.openLink(getContext(), MyConst.GUILD_VIDEO);
            }
        });
    }


    public void onActionClick(View view) {
        this.vClick.choose(false);
        ViewItemPosition viewItemPosition = (ViewItemPosition) view;
        this.vClick = viewItemPosition;
        viewItemPosition.choose(true);
        MyShare.putOrientation(getContext(), view.getId());
        this.activityLocation.startService(makeIntent(10));
    }

    public void onColorChange(int i) {
        int argb = Color.argb(Color.alpha(this.color), Color.red(i), Color.green(i), Color.blue(i));
        this.color = argb;
        this.lAlpha.setColor(Color.rgb(Color.red(argb), Color.green(this.color), Color.blue(this.color)));
        updateColor();
    }

    private void updateColor() {
        MyShare.putColorNotification(getContext(), this.color);
        this.activityLocation.startService(makeIntent(10));
    }

    @Override
    public void onChange(View view, int i) {
        int i2 = getResources().getDisplayMetrics().widthPixels;
        int i3 = i2 / 25;
        int id = view.getId();
        if (id == R.string.alpha) {
            int i4 = (i * 256) / 100;
            if (i4 < 0) {
                i4 = 0;
            } else if (i4 > 255) {
                i4 = 255;
            }
            this.color = Color.argb(i4, Color.red(this.color), Color.green(this.color), Color.blue(this.color));
            updateColor();
        } else if (id == R.string.height) {
            int i5 = (i2 * 6) / 100;
            int i6 = ((i * i5) / 100) + i3;
            if (i6 >= i3) {
                int i7 = i3 + i5;
                i3 = i7;
                if (i6 <= i7) {
                    i3 = i6;
                }
            }
            MyShare.putHeightNotification(getContext(), i3);
            this.activityLocation.startService(makeIntent(10));
        } else if (id == R.string.width) {
            int i72 = (i2 * 45) / 100;
            int i8 = ((i * i72) / 100) + i3;
            if (i8 >= i3) {
                int i9 = i3 + i72;
                i3 = i9;
                if (i8 <= i9) {
                    i3 = i8;
                }
            }
            MyShare.putWidthNotification(getContext(), i3);
            this.activityLocation.startService(makeIntent(10));
        }
    }
}
