package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

import androidx.core.view.ViewCompat;

import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ViewSeekbar extends View {
    private final int COLOR;
    private final int DEFAULT;
    private final int VOLUME;
    private int color;
    private LinearGradient gradient;
    private boolean isTouch;
    private long max;
    private MyScrollView myScrollView;
    private OnSeekBarChange onSeekBarChange;
    private final Paint p;
    private long progress;
    private int status;

    
    public interface OnSeekBarChange {
        void onChangeProgress(View view, long j);

        void onUp(View view);
    }

    public void setMyScrollView(MyScrollView myScrollView) {
        this.myScrollView = myScrollView;
    }

    public void setOnSeekBarChange(OnSeekBarChange onSeekBarChange) {
        this.onSeekBarChange = onSeekBarChange;
    }

    public ViewSeekbar(Context context) {
        super(context);
        this.DEFAULT = 0;
        this.VOLUME = 1;
        this.COLOR = 2;
        this.status = 0;
        this.max = 100L;
        this.progress = 50L;
        Paint paint = new Paint(1);
        this.p = paint;
        paint.setStyle(Paint.Style.FILL);
    }

    @Override 
    protected void onDraw(Canvas canvas) {
        float f;
        float f4;
        super.onDraw(canvas);
        float widthScreen = this.status != 0 ? (OtherUtils.getWidthScreen(getContext()) * 3.1f) / 100.0f : 0.0f;
        float widthScreen2 = (OtherUtils.getWidthScreen(getContext()) * 1.1f) / 100.0f;
        this.p.clearShadowLayer();
        if (this.status != 2) {
            this.p.setColor(Color.parseColor("#45000000"));
        } else {
            if (this.gradient == null) {
                this.gradient = new LinearGradient(0.0f, 0.0f, getWidth(), 0.0f, 0, this.color, Shader.TileMode.CLAMP);
            }
            this.p.setShader(this.gradient);
        }
        canvas.drawRoundRect(widthScreen, (getHeight() - widthScreen2) / 2.0f, getWidth() - widthScreen, (getHeight() + widthScreen2) / 2.0f, widthScreen2, widthScreen2, this.p);
        this.p.setShader(null);
        this.p.setColor(ViewCompat.MEASURED_STATE_MASK);
        float width = (getWidth() * ((float) this.progress)) / ((float) this.max);
        float f3 = widthScreen * 2.0f;
        if (width < f3) {
            f = f3;
        } else {
            if (width > getWidth() - widthScreen) {
                width = getWidth() - widthScreen;
            }
            f = width;
        }
        if (this.status != 2) {
            canvas.drawRoundRect(widthScreen, (getHeight() - widthScreen2) / 2.0f, f - (widthScreen / 2.0f), (getHeight() + widthScreen2) / 2.0f, widthScreen2, widthScreen2, this.p);
        }
        int i = this.status;
        if (i == 0) {
            widthScreen = this.isTouch ? (OtherUtils.getWidthScreen(getContext()) * 3.1f) / 100.0f : widthScreen2;
            if (f < widthScreen) {
                f4 = widthScreen;
            } else {
                if (f > getWidth() - widthScreen) {
                    f = getWidth() - widthScreen;
                }
                f4 = f;
            }
        } else {
            if (i != 1) {
                this.p.setColor(this.color);
            } else {
                this.p.setColor(-1);
            }
            float f42 = widthScreen2 * 2.0f;
            this.p.setShadowLayer(f42, 0.0f, 0.0f, Color.parseColor("#30000000"));
            float f2 = widthScreen + f42;
            if (f < f2) {
                f4 = f2;
            } else {
                if (f > (getWidth() - widthScreen) - f42) {
                    f = (getWidth() - widthScreen) - f42;
                }
                f4 = f;
            }
        }
        canvas.drawCircle(f4, getHeight() / 2.0f, widthScreen, this.p);
    }

    public void setModeVolume() {
        this.status = 1;
        invalidate();
    }

    public void setModeColor() {
        this.status = 2;
        invalidate();
    }

    public void setColorSeekbar(int i) {
        this.color = i;
        if (getWidth() > 0) {
            this.gradient = new LinearGradient(0.0f, 0.0f, getWidth(), 0.0f, 0, i, Shader.TileMode.CLAMP);
        }
        invalidate();
    }

    @Override 
    public boolean onTouchEvent(MotionEvent motionEvent) {
        evenTouch(motionEvent);
        return true;
    }

    private void evenTouch(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        if (action == 0) {
            MyScrollView myScrollView = this.myScrollView;
            if (myScrollView != null) {
                myScrollView.setTouchDis(false);
            }
        } else if (action == 1) {
            MyScrollView myScrollView2 = this.myScrollView;
            if (myScrollView2 != null) {
                myScrollView2.setTouchDis(true);
            }
            if (!this.isTouch) {
                this.isTouch = true;
            }
            long x = (int) ((motionEvent.getX() * ((float) this.max)) / getWidth());
            this.progress = x;
            if (x < 0) {
                this.progress = 0L;
            } else {
                long j = this.max;
                if (x > j) {
                    this.progress = j;
                }
            }
            invalidate();
            OnSeekBarChange onSeekBarChange = this.onSeekBarChange;
            if (onSeekBarChange != null) {
                onSeekBarChange.onChangeProgress(this, this.progress);
            }
            OnSeekBarChange onSeekBarChange2 = this.onSeekBarChange;
            if (onSeekBarChange2 != null) {
                onSeekBarChange2.onUp(this);
            }
            this.isTouch = false;
        } else if (action == 2) {
            if (!this.isTouch) {
                this.isTouch = true;
            }
            long x2 = (int) ((motionEvent.getX() * ((float) this.max)) / getWidth());
            this.progress = x2;
            if (x2 < 0) {
                this.progress = 0L;
            } else {
                long j2 = this.max;
                if (x2 > j2) {
                    this.progress = j2;
                }
            }
            invalidate();
            OnSeekBarChange onSeekBarChange3 = this.onSeekBarChange;
            if (onSeekBarChange3 != null) {
                onSeekBarChange3.onChangeProgress(this, this.progress);
            }
        }
    }

    public void setMax(long j) {
        this.max = j;
        invalidate();
    }

    public void setProgress(long j) {
        if (!this.isTouch) {
            this.progress = j;
            invalidate();
        }
    }

    public long getProgress() {
        return this.progress;
    }

    public long getMax() {
        return this.max;
    }
}
