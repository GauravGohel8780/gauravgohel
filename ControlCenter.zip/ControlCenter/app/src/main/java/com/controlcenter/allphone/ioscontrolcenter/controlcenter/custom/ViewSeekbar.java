package com.controlcenter.allphone.ioscontrolcenter.controlcenter.custom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ViewSeekbar extends View {
    private float disX;
    private float disY;
    private boolean isTouch;
    private boolean isVolume;
    private long max;
    private OnSeekBarChange onSeekBarChange;
    private final Paint p;
    private long progress;
    private int touchStatus;

    
    public interface OnSeekBarChange {
        void onChangeProgress(View view, long j);

        void onUp(ViewSeekbar viewSeekbar);
    }

    public void setOnSeekBarChange(OnSeekBarChange onSeekBarChange) {
        this.onSeekBarChange = onSeekBarChange;
    }

    public ViewSeekbar(Context context) {
        super(context);
        Paint paint = new Paint(1);
        this.p = paint;
        paint.setStyle(Paint.Style.FILL);
        this.max = 100L;
        this.progress = 50L;
    }

    @Override 
    protected void onDraw(Canvas canvas) {
        float f;
        float f4;
        super.onDraw(canvas);
        float widthScreen = this.isVolume ? (OtherUtils.getWidthScreen(getContext()) * 3.1f) / 100.0f : 0.0f;
        float widthScreen2 = (OtherUtils.getWidthScreen(getContext()) * 1.1f) / 100.0f;
        this.p.clearShadowLayer();
        this.p.setColor(Color.parseColor("#45ffffff"));
        canvas.drawRoundRect(widthScreen, (getHeight() - widthScreen2) / 2.0f, getWidth() - widthScreen, (getHeight() + widthScreen2) / 2.0f, widthScreen2, widthScreen2, this.p);
        this.p.setShader(null);
        this.p.setColor(-1);
        float width = (getWidth() * ((float) this.progress)) / ((float) this.max);
        float f2 = widthScreen * 2.0f;
        if (width < f2) {
            f = f2;
        } else {
            if (width > getWidth() - widthScreen) {
                width = getWidth() - widthScreen;
            }
            f = width;
        }
        canvas.drawRoundRect(widthScreen, (getHeight() - widthScreen2) / 2.0f, f - (widthScreen / 3.0f), (getHeight() + widthScreen2) / 2.0f, widthScreen2, widthScreen2, this.p);
        if (!this.isVolume) {
            widthScreen = this.isTouch ? (OtherUtils.getWidthScreen(getContext()) * 3.0f) / 100.0f : widthScreen2;
            if (f < widthScreen) {
                f4 = widthScreen;
            } else if (f <= getWidth() - widthScreen) {
                f4 = f;
            } else {
                float f3 = getWidth() - widthScreen;
                f4 = f3;
            }
        } else {
            this.p.setColor(-1);
            float f32 = 2.0f * widthScreen2;
            f4 = widthScreen + f32;
            if (f >= f4) {
                if (f <= (getWidth() - widthScreen) - f32) {
                    f4 = f;
                } else {
                    float f5 = (getWidth() - widthScreen) - f32;
                    f4 = f5;
                }
            }
        }
        canvas.drawCircle(f4, getHeight() / 2, widthScreen, this.p);
    }

    public void setModeVolume() {
        this.isVolume = true;
        invalidate();
    }

    @Override 
    public boolean onTouchEvent(MotionEvent motionEvent) {
        evenTouch(motionEvent);
        return true;
    }

    private void evenTouch(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        if (action == 0) {
            this.touchStatus = 0;
            this.disX = motionEvent.getX();
            this.disY = motionEvent.getY();
        } else if (action == 1) {
            if (!this.isTouch) {
                this.isTouch = true;
            }
            long x = (int) ((motionEvent.getX() * ((float) this.max)) / getWidth());
            this.progress = x;
            if (x < 0) {
                this.progress = 0L;
            } else {
                long j = this.max;
                if (x > j) {
                    this.progress = j;
                }
            }
            invalidate();
            OnSeekBarChange onSeekBarChange = this.onSeekBarChange;
            if (onSeekBarChange != null) {
                onSeekBarChange.onChangeProgress(this, this.progress);
            }
            OnSeekBarChange onSeekBarChange2 = this.onSeekBarChange;
            if (onSeekBarChange2 != null) {
                onSeekBarChange2.onUp(this);
            }
            this.isTouch = false;
        } else if (action == 2) {
            int i = this.touchStatus;
            if (i == 0) {
                float abs = Math.abs(motionEvent.getX() - this.disX);
                float abs2 = Math.abs(motionEvent.getY() - this.disY);
                if (abs > 30.0f || abs2 > 30.0f) {
                    if (abs >= abs2) {
                        this.touchStatus = 1;
                    } else {
                        this.touchStatus = 2;
                    }
                }
            } else if (i == 1) {
                if (!this.isTouch) {
                    this.isTouch = true;
                }
                long x2 = (int) ((motionEvent.getX() * ((float) this.max)) / getWidth());
                this.progress = x2;
                if (x2 < 0) {
                    this.progress = 0L;
                } else {
                    long j2 = this.max;
                    if (x2 > j2) {
                        this.progress = j2;
                    }
                }
                invalidate();
                OnSeekBarChange onSeekBarChange3 = this.onSeekBarChange;
                if (onSeekBarChange3 != null) {
                    onSeekBarChange3.onChangeProgress(this, this.progress);
                }
            }
        }
    }

    public void setMax(long j) {
        this.max = j;
        invalidate();
    }

    public void setProgress(long j) {
        if (this.isTouch) {
            return;
        }
        this.progress = j;
        invalidate();
    }

    public long getProgress() {
        return this.progress;
    }

    public long getMax() {
        return this.max;
    }
}
