package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.core.view.ViewCompat;

import com.bumptech.glide.Glide;
import com.controlcenter.allphone.ioscontrolcenter.R;


public class ViewItemPosition extends LinearLayout {
    private final ImageView imPreview;
    private LayoutClick layoutClick;
    private final TextM tvName;

    public void setLayoutClick(LayoutClick layoutClick) {
        this.layoutClick = layoutClick;
    }

    public ViewItemPosition(Context context) {
        super(context);
        setOrientation(1);
        setGravity(1);
        int i = getResources().getDisplayMetrics().widthPixels;
        int i2 = (i * 19) / 100;
        int i3 = i / 100;
        int i4 = i3 * 3;
        setPadding(0, i4, 0, i3);
        ImageView imageView = new ImageView(context);
        this.imPreview = imageView;
        addView(imageView, i2, (i2 * 327) / 300);
        TextM textM = new TextM(context);
        this.tvName = textM;
        textM.setGravity(1);
        textM.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        textM.setSingleLine();
        textM.setTextSize(0, (i * 3.1f) / 100.0f);
        int i5 = i3 / 4;
        textM.setPadding(0, i5, 0, i5);
        LayoutParams layoutParams = new LayoutParams(-1, -2);
        layoutParams.setMargins(i3, i4 / 2, i3, i3);
        addView(textM, layoutParams);
        imageView.setOnClickListener(new OnClickListener() {
            @Override 
            public final void onClick(View view) {
                layoutClick.onActionClick(ViewItemPosition.this);
            }
        });
    }


    public void setImage(String str, int i) {
        this.tvName.setText(i);
        Glide.with(getContext()).load(str).into(this.imPreview);
    }

    public void choose(boolean z) {
        if (z) {
            this.tvName.setBackgroundResource(R.drawable.bg_sel_tv_policy);
            this.tvName.setTextColor(-1);
            return;
        }
        this.tvName.setBackgroundColor(0);
        this.tvName.setTextColor(ViewCompat.MEASURED_STATE_MASK);
    }
}
