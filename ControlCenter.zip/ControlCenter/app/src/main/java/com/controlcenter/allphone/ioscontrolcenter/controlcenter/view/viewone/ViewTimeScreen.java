package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewone;

import android.content.Context;
import android.graphics.Color;
import android.provider.Settings;
import android.widget.RelativeLayout;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.ViewControlCenter;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.BaseViewControl;
import com.controlcenter.allphone.ioscontrolcenter.custom.TextB;
import com.controlcenter.allphone.ioscontrolcenter.custom.TextM;
import com.controlcenter.allphone.ioscontrolcenter.util.CheckUtils;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ViewTimeScreen extends BaseViewControl {
    private final TextB tvTime;

    public ViewTimeScreen(Context context) {
        super(context);
        float widthScreen = OtherUtils.getWidthScreen(context);
        int i = (int) ((12.8f * widthScreen) / 100.0f);
        int i2 = (int) ((3.2f * widthScreen) / 100.0f);
        TextB textB = new TextB(context);
        this.tvTime = textB;
        textB.setId(123);
        textB.setGravity(17);
        textB.setSingleLine();
        textB.setTextColor(-1);
        textB.setTextSize(0, (3.5f * widthScreen) / 100.0f);
        textB.setBackground(OtherUtils.makeOval(Color.parseColor("#30ffffff")));
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(i, i);
        layoutParams.addRule(15);
        layoutParams.setMargins(i2, 0, i2, 0);
        addView(textB, layoutParams);
        TextM textM = new TextM(context);
        textM.setGravity(1);
        textM.setTextColor(-1);
        textM.setTextSize(0, (2.75f * widthScreen) / 100.0f);
        textM.setText(R.string.screen_timeout);
        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-1, -2);
        layoutParams2.addRule(17, textB.getId());
        layoutParams2.addRule(15);
        layoutParams2.setMargins(0, 0, i2, 0);
        addView(textM, layoutParams2);
    }

    public void updateTime() {
        int i = Settings.System.getInt(getContext().getContentResolver(), "screen_off_timeout", 30000) / 1000;
        if (i < 20) {
            this.tvTime.setText("15s");
        } else if (i < 40) {
            this.tvTime.setText("30s");
        } else if (i < 70) {
            this.tvTime.setText("1m");
        } else if (i < 150) {
            this.tvTime.setText("2m");
        } else if (i < 350) {
            this.tvTime.setText("5m");
        } else if (i < 650) {
            this.tvTime.setText("10m");
        } else {
            this.tvTime.setText("30m");
        }
    }

    @Override
    public boolean onLongClick(ViewControlCenter viewControlCenter) {
        if (CheckUtils.checkSystemWriteSettingEndAction(getContext())) {
            viewControlCenter.showBigTime();
            return true;
        }
        return true;
    }
}
