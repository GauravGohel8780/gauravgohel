package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;


public class TextL extends TextView {
    public TextL(Context context) {
        super(context);
        init();
    }

    public TextL(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init();
    }

    public TextL(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init();
    }

    private void init() {
        setTypeface(Typeface.createFromAsset(getContext().getAssets(), "fonts/IOS_0.ttf"));
    }
}
