package com.controlcenter.allphone.ioscontrolcenter.service;

import android.app.WallpaperManager;
import android.bluetooth.BluetoothAdapter;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.ControlResult;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.ViewControlCenter;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.connect.ConnectClickResult;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.nightshift.ViewNightShift;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewone.RecordScreenResult;
import com.controlcenter.allphone.ioscontrolcenter.custom.OnSwipeTouchListener;
import com.controlcenter.allphone.ioscontrolcenter.custom.ViewStart;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemControl;
import com.controlcenter.allphone.ioscontrolcenter.util.ActionUtils;
import com.controlcenter.allphone.ioscontrolcenter.util.CheckUtils;
import com.controlcenter.allphone.ioscontrolcenter.util.FlashlightProvider;
import com.controlcenter.allphone.ioscontrolcenter.util.MyConst;
import com.controlcenter.allphone.ioscontrolcenter.util.MyShare;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import kotlin.jvm.internal.CharCompanionObject;


public class ControlCenterManager {
    private static final int ACTION_OPEN_APP = -1000;
    private int action;
    private boolean addControl;
    private boolean addNightShift;
    private boolean addStart;
    private AudioManager am;
    private Bitmap bmBg;
    private final BroadcastReceiver broadcastReceiver;
    private String className;
    private int color;
    private final ServiceControl context;
    private int height;
    private int loc;
    private BluetoothAdapter mBluetoothAdapter;
    private final WindowManager manager;
    private final WindowManager.LayoutParams paramControl;
    private final WindowManager.LayoutParams paramNightShift;
    private final WindowManager.LayoutParams paramStart;
    private String pkg;
    private boolean portrait = true;
    private int position;
    private boolean screenRecord;
    private boolean setting;
    public final OnSwipeTouchListener.TouchResult touchResult;
    private final ViewStart vStart;
    private final ViewControlCenter viewControlCenter;
    private final ViewNightShift viewNightShift;
    private int width;
    private WifiManager wifiManager;

    public ControlCenterManager(ServiceControl serviceControl, MusicControlResult musicControlResult, FlashlightProvider flashlightProvider) {
        BroadcastReceiver broadcastReceiver = new BroadcastReceiver() { // from class: com.controlcenter.allphone.ioscontrolcenter.service.ControlCenterManager.1
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (action == null) {
                    return;
                }
                char c = CharCompanionObject.MAX_VALUE;
                char c2 = '\uffff';
                switch (action.hashCode()) {
                    case -1875733435:
                        if (action.equals("android.net.wifi.WIFI_STATE_CHANGED")) {
                            c2 = 0;
                            break;
                        }
                        break;
                    case -1530327060:
                        if (action.equals("android.bluetooth.adapter.action.STATE_CHANGED")) {
                            c2 = 1;
                            break;
                        }
                        break;
                    case -1076576821:
                        if (action.equals("android.intent.action.AIRPLANE_MODE")) {
                            c2 = 2;
                            break;
                        }
                        break;
                    case 409953495:
                        if (action.equals("android.net.wifi.WIFI_AP_STATE_CHANGED")) {
                            c2 = 3;
                            break;
                        }
                        break;
                }
                switch (c2) {
                    case 0:
                        c = 0;
                        break;
                    case 1:
                        c = 1;
                        break;
                    case 2:
                        c = 2;
                        break;
                    case 3:
                        c = 3;
                        break;
                }
                switch (c) {
                    case 0:
                        ControlCenterManager.this.viewControlCenter.updateWifi(ControlCenterManager.this.wifiManager);
                        return;
                    case 1:
                        ControlCenterManager.this.viewControlCenter.updateBlu(ControlCenterManager.this.mBluetoothAdapter);
                        return;
                    case 2:
                        ControlCenterManager.this.viewControlCenter.updateAir(CheckUtils.checkAirplane(ControlCenterManager.this.context));
                        return;
                    case 3:
                        ControlCenterManager.this.viewControlCenter.updateHotpot(3 == intent.getIntExtra("wifi_state", 0) % 10);
                        return;
                    default:
                        return;
                }
            }
        };
        this.broadcastReceiver = broadcastReceiver;
        C0016AnonymousClass6 anonymousClass6 = new C0016AnonymousClass6();
        this.touchResult = anonymousClass6;
        this.context = serviceControl;
        this.manager = (WindowManager) serviceControl.getSystemService(Context.WINDOW_SERVICE);
        int[] sizes = MyShare.getSizes(serviceControl);
        int[] sizeNotification = MyShare.getSizeNotification(serviceControl);
        this.height = sizeNotification[1];
        this.color = sizeNotification[2];
        this.position = MyShare.getOrientation(serviceControl);
        ViewControlCenter viewControlCenter = new ViewControlCenter(serviceControl);
        this.viewControlCenter = viewControlCenter;
        viewControlCenter.setControlResult(new ControlResult() { // from class: com.controlcenter.allphone.ioscontrolcenter.service.ControlCenterManager.2
            @Override
            public void onGone() {
                ControlCenterManager.this.touchResult.onCancel();
            }

            @Override
            public void onGoneWithAction(ItemControl itemControl) {
                String str = itemControl.pkg;
                if (str != null) {
                    ControlCenterManager.this.pkg = str;
                    ControlCenterManager.this.className = itemControl.className;
                    ControlCenterManager.this.action = -1000;
                } else {
                    ControlCenterManager.this.action = itemControl.type * 10;
                }
                ControlCenterManager.this.touchResult.onCancel();
            }

            @Override
            public void changeNightShift(boolean z) {
                ControlCenterManager.this.updateNightShift();
            }
        }, new C0015AnonymousClass2(serviceControl), musicControlResult, flashlightProvider, new RecordScreenResult() { // from class: com.controlcenter.allphone.ioscontrolcenter.service.ControlCenterManager.3
            @Override
            public void onStartRecord() {
                ControlCenterManager.this.recordScreen(2);
            }

            @Override
            public void onStopRecord() {
                ControlCenterManager.this.recordScreen(3);
                ControlCenterManager.this.touchResult.onCancel();
            }

            @Override
            public void onRequestPer() {
                ControlCenterManager.this.touchResult.onCancel();
            }
        });
        ViewStart viewStart = new ViewStart(serviceControl);
        this.vStart = viewStart;
        viewStart.setColor(this.color);
        viewStart.setOnTouchListener(new OnSwipeTouchListener(serviceControl, anonymousClass6));
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        this.paramStart = layoutParams;
        WindowManager.LayoutParams layoutParams2 = new WindowManager.LayoutParams();
        this.paramControl = layoutParams2;
        WindowManager.LayoutParams layoutParams3 = new WindowManager.LayoutParams();
        this.paramNightShift = layoutParams3;
        if (Build.VERSION.SDK_INT >= 22) {
            layoutParams.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
            layoutParams.flags = 808;
            layoutParams2.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
            layoutParams2.flags = 1824;
            layoutParams3.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
        } else {
            layoutParams3.type = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;
            layoutParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ERROR;
            layoutParams.flags = 201326600;
            layoutParams2.type = 2010;
            layoutParams2.flags = 201326600;
        }
        layoutParams3.flags = 792;
        layoutParams3.format = -3;
        layoutParams3.x = 0;
        layoutParams3.y = 0;
        layoutParams3.width = sizes[0];
        layoutParams3.height = sizes[1];
        layoutParams3.gravity = 8388659;
        layoutParams.format = -3;
        layoutParams.gravity = 8388661;
        layoutParams2.width = sizes[0];
        layoutParams2.height = sizes[1];
        layoutParams2.gravity = 8388659;
        layoutParams2.format = -3;
        changeSizeViewStart();
        if (MyShare.enableControlCenter(serviceControl)) {
            addViewStart();
        }
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.AIRPLANE_MODE");
        intentFilter.addAction("android.net.wifi.WIFI_STATE_CHANGED");
        intentFilter.addAction("android.bluetooth.adapter.action.STATE_CHANGED");
        intentFilter.addAction("android.net.wifi.WIFI_AP_STATE_CHANGED");
        setup();
        serviceControl.registerReceiver(broadcastReceiver, intentFilter);
        viewControlCenter.updateFist(this.mBluetoothAdapter, this.wifiManager, this.am);
        ViewNightShift viewNightShift = new ViewNightShift(serviceControl);
        this.viewNightShift = viewNightShift;
        viewNightShift.setNightShiftResult(new ViewNightShift.NightShiftResult() { // from class: com.controlcenter.allphone.ioscontrolcenter.service.ControlCenterManager.4
            @Override
            public final void onHideComplete() {
                ControlCenterManager.this.removeNightShift();
            }
        });
        updateNightShift();
        Dexter.withContext(serviceControl).withPermission("android.permission.READ_EXTERNAL_STORAGE").withListener(new PermissionListener() { // from class: com.controlcenter.allphone.ioscontrolcenter.service.ControlCenterManager.5
            @Override 
            public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
            }

            @Override 
            public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                ControlCenterManager.this.getWallpaper();
            }

            @Override 
            public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                permissionToken.continuePermissionRequest();
            }
        }).check();
    }

    /* renamed from: com.controlcenter.allphone.ioscontrolcenter.service.ControlCenterManager$AnonymousClass2  reason: case insensitive filesystem */

    public class C0015AnonymousClass2 implements ConnectClickResult {
        final ServiceControl val$context;

        C0015AnonymousClass2(ServiceControl serviceControl) {
            this.val$context = serviceControl;
        }

        @Override
        public void onAirClick() {
            ControlCenterManager.this.action = 1;
            ControlCenterManager.this.touchResult.onCancel();
        }

        @Override
        public void onDataClick() {
            ControlCenterManager.this.action = 2;
            ControlCenterManager.this.touchResult.onCancel();
        }

        @Override
        public void onWifiClick() {
            if (Build.VERSION.SDK_INT >= 29) {
                ControlCenterManager.this.action = 3;
                ControlCenterManager.this.touchResult.onCancel();
                return;
            }
            new Thread(new Runnable() { // from class: com.controlcenter.allphone.ioscontrolcenter.service.ControlCenterManager.AnonymousClass2.1
                @Override 
                public final void run() {
                    C0015AnonymousClass2.this.m100x59c999f0();
                }
            }).start();
        }

        public void m100x59c999f0() {
            try {
                ControlCenterManager.this.wifiManager.setWifiEnabled(!ControlCenterManager.this.wifiManager.isWifiEnabled());
            } catch (Exception e) {
            }
        }

        @Override
        public void onBlueClick() {
            if (ContextCompat.checkSelfPermission(this.val$context, "android.permission.BLUETOOTH_CONNECT") == 0) {
                if (ControlCenterManager.this.mBluetoothAdapter.isEnabled()) {
                    ControlCenterManager.this.mBluetoothAdapter.disable();
                } else {
                    ControlCenterManager.this.mBluetoothAdapter.enable();
                }
            }
        }

        @Override
        public void onSyncClick() {
            ContentResolver.setMasterSyncAutomatically(!ContentResolver.getMasterSyncAutomatically());
            ControlCenterManager.this.viewControlCenter.updateSync();
        }

        @Override
        public void onHotClick() {
            ControlCenterManager.this.action = 4;
            ControlCenterManager.this.touchResult.onCancel();
        }
    }

    public void updateNightShift() {
        if (MyShare.getEnaNightShift(this.context) || MyShare.checkScheduled(this.context)) {
            addNightShift();
            this.viewNightShift.updateColor();
        } else if (this.addNightShift) {
            this.viewNightShift.hide();
        }
    }

    public void onChangeScreen(boolean z) {
        this.portrait = z;
        int[] sizes = MyShare.getSizes(this.context);
        if (z) {
            WindowManager.LayoutParams layoutParams = this.paramControl;
            layoutParams.width = sizes[0];
            layoutParams.height = sizes[1];
            WindowManager.LayoutParams layoutParams2 = this.paramNightShift;
            layoutParams2.width = sizes[0];
            layoutParams2.height = sizes[1];
        } else {
            WindowManager.LayoutParams layoutParams3 = this.paramControl;
            layoutParams3.width = sizes[1];
            layoutParams3.height = sizes[0];
            WindowManager.LayoutParams layoutParams4 = this.paramNightShift;
            layoutParams4.width = sizes[1];
            layoutParams4.height = sizes[0];
        }
        if (this.addStart) {
            changeSizeViewStart();
        }
        if (this.addControl) {
            this.manager.updateViewLayout(this.viewControlCenter, this.paramControl);
        }
        if (this.addNightShift) {
            this.manager.updateViewLayout(this.viewNightShift, this.paramNightShift);
        }
        this.viewControlCenter.changeScreen(z);
    }

    private void setup() {
        this.mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        this.wifiManager = (WifiManager) this.context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        this.am = (AudioManager) this.context.getSystemService(Context.AUDIO_SERVICE);
    }

    public void addViewStart() {
        if (this.addStart) {
            return;
        }
        this.addStart = true;
        try {
            this.manager.addView(this.vStart, this.paramStart);
        } catch (Exception e) {
        }
    }

    public void removeStart() {
        if (this.addStart) {
            this.addStart = false;
            try {
                this.manager.removeView(this.vStart);
            } catch (Exception e) {
            }
        }
        if (this.addNightShift) {
            this.viewNightShift.hide();
        }
    }

    public void addViewControl() {
        if (this.addControl) {
            return;
        }
        this.addControl = true;
        this.viewControlCenter.setVisibility(View.VISIBLE);
        try {
            this.manager.addView(this.viewControlCenter, this.paramControl);
        } catch (Exception e) {
        }
    }

    public void removeViewControl() {
        if (this.addControl) {
            this.addControl = false;
            this.viewControlCenter.checkViewBig(false);
            this.viewControlCenter.setVisibility(View.GONE);
            try {
                this.manager.removeView(this.viewControlCenter);
            } catch (Exception e) {
            }
        }
        startActionSetting();
        startActionConnect();
        this.action = 0;
    }

    public void getWallpaper() {
        final int statusWallpaper = MyShare.getStatusWallpaper(this.context);
        final Handler handler = new Handler(new Handler.Callback() { // from class: com.controlcenter.allphone.ioscontrolcenter.service.ControlCenterManager.6
            @Override
            public final boolean handleMessage(Message message) {
                return ControlCenterManager.this.m98x47ef5874(statusWallpaper, message);
            }
        });
        new Thread(new Runnable() { // from class: com.controlcenter.allphone.ioscontrolcenter.service.ControlCenterManager.7
            @Override 
            public final void run() {
                ControlCenterManager.this.m99x264f8f5(statusWallpaper, handler);
            }
        }).start();
    }

    public boolean m98x47ef5874(int i, Message message) {
        if (i == 2) {
            this.viewControlCenter.clearBg();
            return true;
        }
        Bitmap bitmap = this.bmBg;
        if (bitmap != null) {
            this.viewControlCenter.setBackground(bitmap);
        }
        return true;
    }

    public void m99x264f8f5(int i, Handler handler) {
        boolean enableBlur = MyShare.enableBlur(this.context);
        if (i == 1) {
            if (CheckUtils.checkPer(this.context, "android.permission.READ_EXTERNAL_STORAGE")) {
                Drawable drawable = WallpaperManager.getInstance(this.context).getDrawable();
                if (enableBlur) {
                    this.bmBg = OtherUtils.fastBlur(OtherUtils.drawableToBitmap(this.context, drawable), 0.2f, 30);
                } else {
                    this.bmBg = OtherUtils.drawableToBitmap(this.context, drawable);
                }
            } else {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = 4;
                options.inDither = false;
                options.inPurgeable = true;
                if (enableBlur) {
                    this.bmBg = OtherUtils.fastBlur(BitmapFactory.decodeResource(this.context.getResources(), R.drawable.img_bg_def, options), 0.2f, 30);
                } else {
                    this.bmBg = BitmapFactory.decodeResource(this.context.getResources(), R.drawable.img_bg_def, options);
                }
            }
        } else if (i == 3) {
            String wallpaper = MyShare.getWallpaper(this.context);
            if (wallpaper.isEmpty()) {
                BitmapFactory.Options options2 = new BitmapFactory.Options();
                options2.inSampleSize = 4;
                options2.inDither = false;
                options2.inPurgeable = true;
                if (enableBlur) {
                    this.bmBg = OtherUtils.fastBlur(BitmapFactory.decodeResource(this.context.getResources(), R.drawable.img_bg_def, options2), 0.2f, 30);
                } else {
                    this.bmBg = BitmapFactory.decodeResource(this.context.getResources(), R.drawable.img_bg_def, options2);
                }
            } else {
                try {
                    if (enableBlur) {
                        this.bmBg = OtherUtils.fastBlur(BitmapFactory.decodeFile(wallpaper), 0.2f, 30);
                    } else {
                        this.bmBg = BitmapFactory.decodeFile(wallpaper);
                    }
                } catch (Exception e) {
                    BitmapFactory.Options options3 = new BitmapFactory.Options();
                    options3.inSampleSize = 4;
                    options3.inDither = false;
                    options3.inPurgeable = true;
                    if (enableBlur) {
                        this.bmBg = OtherUtils.fastBlur(BitmapFactory.decodeResource(this.context.getResources(), R.drawable.img_bg_def, options3), 0.2f, 30);
                    } else {
                        this.bmBg = BitmapFactory.decodeResource(this.context.getResources(), R.drawable.img_bg_def, options3);
                    }
                }
            }
        }
        handler.sendEmptyMessage(1);
    }

    public void changeSizeViewStart() {
        int[] sizeNotification = MyShare.getSizeNotification(this.context);
        if (this.color != sizeNotification[2]) {
            this.color = sizeNotification[2];
            this.vStart.setColor(sizeNotification[2]);
            return;
        }
        Point point = new Point();
        this.manager.getDefaultDisplay().getRealSize(point);
        this.loc = MyShare.getLocation(this.context);
        int orientation = MyShare.getOrientation(this.context);
        boolean z = (this.height == sizeNotification[1] && orientation == this.position) ? false : true;
        this.position = orientation;
        this.height = sizeNotification[1];
        this.width = sizeNotification[0];
        this.vStart.setPosition(orientation);
        int i = this.position;
        if (i == 1) {
            WindowManager.LayoutParams layoutParams = this.paramStart;
            layoutParams.gravity = 8388661;
            layoutParams.width = sizeNotification[0];
            layoutParams.height = sizeNotification[1];
            layoutParams.y = 0;
        } else if (i == 3) {
            WindowManager.LayoutParams layoutParams2 = this.paramStart;
            layoutParams2.gravity = 8388659;
            layoutParams2.width = sizeNotification[1];
            layoutParams2.height = sizeNotification[0];
            layoutParams2.y = (this.loc * (point.y - sizeNotification[0])) / 100;
        } else if (i == 4) {
            WindowManager.LayoutParams layoutParams3 = this.paramStart;
            layoutParams3.gravity = 8388661;
            layoutParams3.width = sizeNotification[1];
            layoutParams3.height = sizeNotification[0];
            layoutParams3.y = (this.loc * (point.y - sizeNotification[0])) / 100;
        } else {
            WindowManager.LayoutParams layoutParams4 = this.paramStart;
            layoutParams4.gravity = 8388693;
            layoutParams4.width = sizeNotification[0];
            layoutParams4.height = sizeNotification[1];
            layoutParams4.y = 0;
        }
        if (this.addStart) {
            try {
                this.manager.updateViewLayout(this.vStart, this.paramStart);
                if (z) {
                    this.vStart.changeHeight();
                }
            } catch (Exception e) {
            }
        }
    }

    public void onDestroy() {
        this.context.unregisterReceiver(this.broadcastReceiver);
        removeViewControl();
        removeStart();
    }

    public void screenOff() {
        this.touchResult.onCancel();
    }

    public ViewControlCenter getViewControlCenter() {
        return this.viewControlCenter;
    }


    public class C0016AnonymousClass6 implements OnSwipeTouchListener.TouchResult {
        C0016AnonymousClass6() {
        }

        @Override
        public void onSwipeRight() {
            if (!ControlCenterManager.this.setting) {
                if (ControlCenterManager.this.position != 3) {
                    if (ControlCenterManager.this.position == 4) {
                        onCancel();
                        return;
                    }
                    return;
                }
                ControlCenterManager.this.addViewControl();
                if (MyShare.vibrationControl(ControlCenterManager.this.context)) {
                    ActionUtils.vibration(ControlCenterManager.this.context);
                }
                ControlCenterManager.this.viewControlCenter.onShowView();
            }
        }

        @Override
        public void onSwipeLeft() {
            if (!ControlCenterManager.this.setting) {
                if (ControlCenterManager.this.position != 4) {
                    if (ControlCenterManager.this.position == 3) {
                        onCancel();
                        return;
                    }
                    return;
                }
                ControlCenterManager.this.addViewControl();
                if (MyShare.vibrationControl(ControlCenterManager.this.context)) {
                    ActionUtils.vibration(ControlCenterManager.this.context);
                }
                ControlCenterManager.this.viewControlCenter.onShowView();
            }
        }

        @Override
        public void onSwipeBottom() {
            if (!ControlCenterManager.this.setting) {
                if (ControlCenterManager.this.position != 1) {
                    if (ControlCenterManager.this.position == 2) {
                        onCancel();
                        return;
                    }
                    return;
                }
                ControlCenterManager.this.addViewControl();
                if (MyShare.vibrationControl(ControlCenterManager.this.context)) {
                    ActionUtils.vibration(ControlCenterManager.this.context);
                }
                ControlCenterManager.this.viewControlCenter.onShowView();
            }
        }

        @Override
        public void onSwipeUp() {
            if (!ControlCenterManager.this.setting) {
                if (ControlCenterManager.this.position != 2) {
                    if (ControlCenterManager.this.position == 1) {
                        onCancel();
                        return;
                    }
                    return;
                }
                ControlCenterManager.this.addViewControl();
                if (MyShare.vibrationControl(ControlCenterManager.this.context)) {
                    ActionUtils.vibration(ControlCenterManager.this.context);
                }
                ControlCenterManager.this.viewControlCenter.onShowView();
            }
        }

        @Override
        public void onCancel() {
            if (!ControlCenterManager.this.setting) {
                ControlCenterManager.this.viewControlCenter.onHideView();
                ControlCenterManager.this.viewControlCenter.checkViewBig(true);
                ControlCenterManager.this.viewControlCenter.getViewBg().animate().alpha(0.0f).setDuration(400L).withEndAction(new Runnable() { // from class: com.controlcenter.allphone.ioscontrolcenter.service.ControlCenterManager.AnonymousClass6.1
                    @Override 
                    public final void run() {
                        C0016AnonymousClass6.this.m101x1a6d1473();
                    }
                }).start();
            }
        }

        public void m101x1a6d1473() {
            ControlCenterManager.this.removeViewControl();
        }

        @Override
        public void onMoveHorizontal(float f) {
            if (!ControlCenterManager.this.setting) {
                if (ControlCenterManager.this.position == 3 || ControlCenterManager.this.position == 4) {
                    ControlCenterManager.this.addViewControl();
                    ControlCenterManager.this.viewControlCenter.onMoveView(Math.abs(f));
                }
            }
        }

        @Override
        public void onMoveVertical(float f) {
            if (ControlCenterManager.this.position == 2 || ControlCenterManager.this.position == 1) {
                if (ControlCenterManager.this.setting) {
                    return;
                }
                ControlCenterManager.this.addViewControl();
                ControlCenterManager.this.viewControlCenter.onMoveView(Math.abs(f));
            } else if (ControlCenterManager.this.setting) {
                Point point = new Point();
                ControlCenterManager.this.manager.getDefaultDisplay().getRealSize(point);
                int i = (int) (((ControlCenterManager.this.loc * (point.y - ControlCenterManager.this.width)) / 100) + f);
                if (i >= 0) {
                    if (i > point.y - ControlCenterManager.this.width) {
                        i = point.y - ControlCenterManager.this.width;
                    }
                } else {
                    i = 0;
                }
                ControlCenterManager.this.paramStart.y = i;
                try {
                    ControlCenterManager.this.manager.updateViewLayout(ControlCenterManager.this.vStart, ControlCenterManager.this.paramStart);
                } catch (Exception e) {
                }
            }
        }

        @Override
        public void onClick() {
            ControlCenterManager controlCenterManager = ControlCenterManager.this;
            controlCenterManager.onActionTouch(MyShare.getSingleTap(controlCenterManager.context));
        }

        @Override
        public void onLongClick() {
            ControlCenterManager controlCenterManager = ControlCenterManager.this;
            controlCenterManager.onActionTouch(MyShare.getLongPress(controlCenterManager.context));
        }

        @Override
        public void onDoubleClick() {
            ControlCenterManager controlCenterManager = ControlCenterManager.this;
            controlCenterManager.onActionTouch(MyShare.getDoubleTap(controlCenterManager.context));
        }

        @Override
        public void onTouchUp() {
            if (ControlCenterManager.this.setting) {
                if (ControlCenterManager.this.position == 3 || ControlCenterManager.this.position == 4) {
                    Point point = new Point();
                    ControlCenterManager.this.manager.getDefaultDisplay().getRealSize(point);
                    ControlCenterManager controlCenterManager = ControlCenterManager.this;
                    controlCenterManager.loc = (controlCenterManager.paramStart.y * 100) / (point.y - ControlCenterManager.this.width);
                    MyShare.putLocation(ControlCenterManager.this.context, ControlCenterManager.this.loc);
                }
            }
        }

        @Override
        public void onCancelTouch() {
            if (ControlCenterManager.this.setting) {
                return;
            }
            ControlCenterManager.this.showControl();
        }
    }

    public void showControl() {
        this.viewControlCenter.onMoveView(OtherUtils.getWidthScreen(this.context) / 2.0f);
        addViewControl();
        if (MyShare.vibrationControl(this.context)) {
            ActionUtils.vibration(this.context);
        }
        this.viewControlCenter.onShowView();
    }

    private void startActionConnect() {
        try {
            int i = this.action;
            Intent intent = null;
            if (i == 1) {
                intent = new Intent("android.settings.AIRPLANE_MODE_SETTINGS");
            } else if (i != 2) {
                if (i != 3) {
                    if (i == 4) {
                        Intent intent2 = new Intent("android.intent.action.MAIN", (Uri) null);
                        intent2.addCategory("android.intent.category.LAUNCHER");
                        intent2.setComponent(new ComponentName("com.android.settings", "com.android.settings.TetherSettings"));
                        intent = intent2;
                    }
                } else if (Build.VERSION.SDK_INT >= 29) {
                    intent = new Intent("android.settings.panel.action.WIFI");
                } else {
                    intent = new Intent("android.settings.WIRELESS_SETTINGS");
                }
            } else {
                int i2 = Build.VERSION.SDK_INT;
                if (i2 >= 29) {
                    intent = new Intent("android.settings.panel.action.INTERNET_CONNECTIVITY");
                } else if (i2 >= 28) {
                    intent = new Intent("android.settings.DATA_USAGE_SETTINGS");
                } else {
                    intent = new Intent();
                    intent.setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$DataUsageSummaryActivity"));
                }
            }
            if (intent != null) {
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                this.context.startActivity(intent);
            }
        } catch (Exception e) {
            try {
                Intent intent3 = new Intent("android.settings.WIRELESS_SETTINGS");
                intent3.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                this.context.startActivity(intent3);
            } catch (ActivityNotFoundException e2) {
                Toast.makeText(this.context, (int) R.string.cancel_not_open, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void startActionSetting() {
        int i = this.action;
        if (i == -1000) {
            ActionUtils.openApp(this.context, this.pkg, this.className);
        } else if (i == 20) {
            ActionUtils.openTimer(this.context);
        } else if (i == 30) {
            ActionUtils.openCal(this.context);
        } else if (i == 40) {
            ActionUtils.openCameraDefault(this.context);
        } else if (i == 60) {
            recordScreen(1);
        } else if (i == 70) {
            ActionUtils.openBattery(this.context);
        } else if (i == 80) {
            ActionUtils.openVoice(this.context);
        } else if (i == 90) {
            ActionUtils.openSetting(this.context);
        }
    }

    public void recordScreen(int i) {
        if (i == 2) {
            this.screenRecord = true;
        } else if (i == 3) {
            this.screenRecord = false;
        }
        Intent intent = new Intent(this.context, ServiceScreen.class);
        intent.putExtra(MyConst.DATA_PKG, i);
        intent.putExtra(MyConst.DATA_ID_NOTIFICATION, this.portrait);
        this.context.startService(intent);
    }

    private void addNightShift() {
        if (this.addNightShift) {
            return;
        }
        this.addNightShift = true;
        try {
            this.manager.addView(this.viewNightShift, this.paramNightShift);
        } catch (Exception e) {
        }
        this.viewNightShift.show();
    }

    public void removeNightShift() {
        if (this.addNightShift) {
            this.addNightShift = false;
            try {
                this.manager.removeView(this.viewNightShift);
            } catch (Exception e) {
            }
        }
    }

    public void updateIconCustom() {
        this.viewControlCenter.makeArrIconChange();
        this.viewControlCenter.updateView();
    }

    public void stopViewRecord() {
        this.viewControlCenter.onEndRecordScreen();
    }

    public void setSetting(boolean z) {
        this.setting = z;
    }

    public void onActionTouch(int i) {
        if (i == 1) {
            this.context.performGlobalAction(2);
        } else if (i == 2) {
            this.context.performGlobalAction(3);
        } else if (i == 3) {
            this.context.performGlobalAction(1);
        } else if (i == 20) {
            showControl();
        } else if (i == 23) {
            recordScreen(1);
        } else if (i == 24) {
            Dexter.withContext(this.context).withPermission("android.permission.RECORD_AUDIO").withListener(new PermissionListener() { // from class: com.controlcenter.allphone.ioscontrolcenter.service.ControlCenterManager.8
                @Override 
                public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                    if (ControlCenterManager.this.screenRecord) {
                        ControlCenterManager.this.recordScreen(3);
                        ControlCenterManager.this.viewControlCenter.onEndRecordScreen();
                        return;
                    }
                    ControlCenterManager.this.recordScreen(2);
                    ControlCenterManager.this.viewControlCenter.onStartRecordScreen();
                }

                @Override 
                public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
                    Toast.makeText(ControlCenterManager.this.context, (int) R.string.per_audio, Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                    permissionToken.continuePermissionRequest();
                }
            }).check();
        } else if (i == 30) {
            ActionUtils.openCameraDefault(this.context);
        } else if (i != 31) {
            switch (i) {
                case 8:
                    this.context.performGlobalAction(4);
                    return;
                case 9:
                    this.viewControlCenter.flashClick();
                    return;
                case 10:
                    this.context.performGlobalAction(8);
                    return;
                default:
                    return;
            }
        } else {
            this.context.performGlobalAction(6);
        }
    }
}
