package com.controlcenter.allphone.ioscontrolcenter.adapter;

import android.view.MotionEvent;
import android.view.View;

import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;


public class SimpleItemTouchHelperCallback extends ItemTouchHelper.Callback {
    private final AdapterApp mAdapter;

    @Override 
    public boolean isItemViewSwipeEnabled() {
        return false;
    }

    @Override 
    public boolean isLongPressDragEnabled() {
        return true;
    }

    @Override 
    public void onSwiped(RecyclerView.ViewHolder viewHolder, int i) {
    }

    public SimpleItemTouchHelperCallback(final AdapterApp adapterApp, RecyclerView recyclerView) {
        this.mAdapter = adapterApp;
        recyclerView.setOnTouchListener(new View.OnTouchListener() { // from class: com.controlcenter.allphone.ioscontrolcenter.adapter.SimpleItemTouchHelperCallback.1
            @Override 
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                return SimpleItemTouchHelperCallback.lambda$new$0(adapterApp, view, motionEvent);
            }
        });
    }

    public static boolean lambda$new$0(AdapterApp adapterApp, View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == 1) {
            adapterApp.onUp();
            return false;
        }
        return false;
    }

    @Override 
    public int getMovementFlags(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {
        return ItemTouchHelper.Callback.makeMovementFlags(3, 48);
    }

    @Override 
    public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder viewHolder2) {
        this.mAdapter.onItemMove(viewHolder.getLayoutPosition(), viewHolder2.getLayoutPosition());
        return true;
    }
}
