package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.core.view.ViewCompat;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.dialog.DialogPerResult;
import com.controlcenter.allphone.ioscontrolcenter.service.ServiceControl;
import com.controlcenter.allphone.ioscontrolcenter.util.CheckUtils;
import com.controlcenter.allphone.ioscontrolcenter.util.MyConst;
import com.iten.tenoku.utils.AdConstant;


public class BaseSetting extends LinearLayout implements View.OnClickListener {
    public DialogPerResult dialogPerResult;
    public LinearLayout llPer;
    public boolean permissionDone;
    private final TextB tvTitle;
    public ViewItem vDraw;
    public ViewItem vNotiManager;
    public ViewItem vPer;
    public ViewItem vService;
    public ViewItem vWriteSetting;

    public void setDialogPerResult(DialogPerResult dialogPerResult) {
        this.dialogPerResult = dialogPerResult;
    }

    public BaseSetting(Context context) {
        super(context);
        setOrientation(LinearLayout.VERTICAL);
        int i = getResources().getDisplayMetrics().widthPixels;
        int i2 = i / 25;
        TextB textB = new TextB(context);
        this.tvTitle = textB;
        textB.setText(R.string.setting_d);
        textB.setPadding((i2 * 3) / 2, i2 / 3, i2, 0);
        textB.setTextSize(0, (i * 8.0f) / 100.0f);
        textB.setTextColor(Color.parseColor("#1a1a1a"));
        addView(textB, -2, -2);
    }

    public LinearLayout makeL(int i) {
        LinearLayout linearLayout = new LinearLayout(getContext());
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setBackgroundResource(R.drawable.bg_main);
        LayoutParams layoutParams = new LayoutParams(-1, -2);
        int i2 = getResources().getDisplayMetrics().widthPixels;
        int i3 = i2 / 25;
        layoutParams.setMargins(i3, (i * i2) / 100, i3, i2 / 20);
        addView(linearLayout, layoutParams);
        return linearLayout;
    }

    public void setTitle(int i) {
        this.tvTitle.setText(i);
    }

    public void addLayoutPer() {
        int i = getResources().getDisplayMetrics().widthPixels / 7;
        this.llPer = makeL(4);
        TextB textB = new TextB(getContext());
        textB.setTextSize(0, getResources().getDisplayMetrics().widthPixels / 20.0f);
        textB.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        textB.setText(R.string.permission);
        textB.setGravity(16);
        LayoutParams layoutParams = new LayoutParams(-1, -2);
        int i2 = i / 4;
        layoutParams.setMargins(i2, i2, 0, i / 8);
        this.llPer.addView(textB, layoutParams);
        ViewItem viewItem = new ViewItem(getContext());
        this.vPer = viewItem;
        viewItem.addNext();
        this.vPer.setOnClickListener(this);
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 33) {
            this.vPer.setItem(R.drawable.ic_per_camera_store, R.string.per_miss_13);
        } else if (i3 >= 31) {
            this.vPer.setItem(R.drawable.ic_per_camera_store, R.string.per_miss_12);
        } else {
            this.vPer.setItem(R.drawable.ic_per_camera_store, R.string.per_miss);
        }
        this.llPer.addView(this.vPer, -1, i);
        ViewItem viewItem2 = new ViewItem(getContext());
        this.vNotiManager = viewItem2;
        viewItem2.addNext();
        this.vNotiManager.setOnClickListener(this);
        this.vNotiManager.setItem(R.drawable.ic_per_notification, R.string.listen_notification);
        this.llPer.addView(this.vNotiManager, -1, i);
        ViewItem viewItem3 = new ViewItem(getContext());
        this.vDraw = viewItem3;
        viewItem3.addNext();
        this.vDraw.setOnClickListener(this);
        this.vDraw.setItem(R.drawable.ic_draw_other_app, R.string.draw_other_apps);
        this.llPer.addView(this.vDraw, -1, i);
        ViewItem viewItem4 = new ViewItem(getContext());
        this.vWriteSetting = viewItem4;
        viewItem4.addNext();
        this.vWriteSetting.setOnClickListener(this);
        this.vWriteSetting.setItem(R.drawable.ic_write_setting, R.string.write_setting);
        this.llPer.addView(this.vWriteSetting, new LayoutParams(-1, i));
        ViewItem viewItem5 = new ViewItem(getContext());
        this.vService = viewItem5;
        viewItem5.addNext();
        this.vService.setOnClickListener(this);
        this.vService.goneDivider();
        this.vService.setItem(R.drawable.ic_accessibility, R.string.permission_service);
        this.llPer.addView(this.vService, -1, i);
    }

    public Intent makeIntent(int i) {
        Intent intent = new Intent(getContext(), ServiceControl.class);
        intent.putExtra(MyConst.DATA_ID_NOTIFICATION, i);
        return intent;
    }

    public void checkPer() {
        boolean z = true;
        int i = Build.VERSION.SDK_INT;
        boolean z2 = true;
        if (i >= 33) {
            this.permissionDone = CheckUtils.checkCanDrawOtherApp(getContext()) && CheckUtils.isNotificationServiceRunning(getContext()) && CheckUtils.checkSystemWriteSetting(getContext()) && CheckUtils.isAccessibilitySettingsOn(getContext()) && CheckUtils.checkPer(getContext(), "android.permission.BLUETOOTH_CONNECT") && CheckUtils.checkPer(getContext(), "android.permission.CAMERA");
        } else if (i >= 31) {
            this.permissionDone = CheckUtils.checkCanDrawOtherApp(getContext()) && CheckUtils.isNotificationServiceRunning(getContext()) && CheckUtils.checkSystemWriteSetting(getContext()) && CheckUtils.isAccessibilitySettingsOn(getContext()) && CheckUtils.canWriteInMediaStore(getContext()) && CheckUtils.checkPer(getContext(), "android.permission.READ_EXTERNAL_STORAGE") && CheckUtils.checkPer(getContext(), "android.permission.BLUETOOTH_CONNECT") && CheckUtils.checkPer(getContext(), "android.permission.CAMERA");
        } else {
            this.permissionDone = CheckUtils.checkCanDrawOtherApp(getContext()) && CheckUtils.isNotificationServiceRunning(getContext()) && CheckUtils.checkSystemWriteSetting(getContext()) && CheckUtils.isAccessibilitySettingsOn(getContext()) && CheckUtils.canWriteInMediaStore(getContext()) && CheckUtils.checkPer(getContext(), "android.permission.READ_EXTERNAL_STORAGE") && CheckUtils.checkPer(getContext(), "android.permission.CAMERA");
        }
        if (this.vDraw != null) {
            this.vPer.setAlpha(0.5f);
            this.vDraw.setAlpha(0.5f);
            this.vService.setAlpha(0.5f);
            this.vWriteSetting.setAlpha(0.5f);
            this.vNotiManager.setAlpha(0.5f);
            if (CheckUtils.canWriteInMediaStore(getContext()) && CheckUtils.checkPer(getContext(), "android.permission.READ_EXTERNAL_STORAGE") && CheckUtils.checkPer(getContext(), "android.permission.CAMERA")) {
                z2 = false;
            }
            if (i >= 33) {
                if (CheckUtils.checkPer(getContext(), "android.permission.BLUETOOTH_CONNECT") && CheckUtils.checkPer(getContext(), "android.permission.CAMERA")) {
                    z = false;
                }
                z2 = z;
            } else if (i >= 31) {
                if (CheckUtils.canWriteInMediaStore(getContext()) && CheckUtils.checkPer(getContext(), "android.permission.READ_EXTERNAL_STORAGE") && CheckUtils.checkPer(getContext(), "android.permission.BLUETOOTH_CONNECT") && CheckUtils.checkPer(getContext(), "android.permission.CAMERA")) {
                    z = false;
                }
                z2 = z;
            }
            if (z2) {
                this.vPer.setAlpha(1.0f);
            } else if (!CheckUtils.isNotificationServiceRunning(getContext())) {
                this.vNotiManager.setAlpha(1.0f);
            } else if (!CheckUtils.checkCanDrawOtherApp(getContext())) {
                this.vDraw.setAlpha(1.0f);
            } else if (this.vWriteSetting != null && !CheckUtils.checkSystemWriteSetting(getContext())) {
                this.vWriteSetting.setAlpha(1.0f);
            } else if (!CheckUtils.isAccessibilitySettingsOn(getContext())) {
                this.vService.setAlpha(1.0f);
            }
        }
    }

    @Override 
    public void onClick(View view) {
        if (this.dialogPerResult == null || view.getAlpha() < 1.0f) {
            return;
        }
        if (view == this.vNotiManager && !CheckUtils.isNotificationServiceRunning(getContext())) {
            this.dialogPerResult.onRequestService();
        }
        if (view == this.vDraw && !CheckUtils.checkCanDrawOtherApp(getContext())) {
            this.dialogPerResult.onRequestDrawOther();
        } else if (view == this.vService) {
            this.dialogPerResult.onRequestAccessibility();
        } else if (view == this.vWriteSetting) {
            this.dialogPerResult.onRequestWriteSetting();
        } else if (view == this.vPer) {
            this.dialogPerResult.onRequestPer();
        }
    }

}
