package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.view.View;


public interface LayoutClick {
    void onActionClick(View view);
}
