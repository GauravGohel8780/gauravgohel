package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;


public class TextM extends TextView {
    public TextM(Context context) {
        super(context);
        init();
    }

    public TextM(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init();
    }

    public TextM(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init();
    }

    private void init() {
        setTypeface(Typeface.createFromAsset(getContext().getAssets(), "fonts/IOS_1.otf"));
    }
}
