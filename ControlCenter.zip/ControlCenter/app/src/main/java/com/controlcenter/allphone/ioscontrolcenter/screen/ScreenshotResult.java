package com.controlcenter.allphone.ioscontrolcenter.screen;

import android.net.Uri;


public interface ScreenshotResult {
    void onImageResult(Uri uri, boolean z);
}
