package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.content.Context;
import android.view.MotionEvent;
import android.widget.ScrollView;


public class MyScrollView extends ScrollView {
    private boolean touchDis;

    public MyScrollView(Context context) {
        super(context);
        this.touchDis = true;
    }

    public void setTouchDis(boolean z) {
        this.touchDis = z;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        if (this.touchDis) {
            return super.onInterceptTouchEvent(motionEvent);
        }
        return false;
    }
}
