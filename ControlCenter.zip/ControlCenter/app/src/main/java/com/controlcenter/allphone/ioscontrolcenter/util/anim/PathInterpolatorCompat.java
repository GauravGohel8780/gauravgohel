package com.controlcenter.allphone.ioscontrolcenter.util.anim;

import android.graphics.Path;
import android.view.animation.Interpolator;


public class PathInterpolatorCompat {
    private PathInterpolatorCompat() {
    }

    public static Interpolator create(Path path) {
        return PathInterpolatorCompatApi21.create(path);
    }

    public static Interpolator create(float f, float f2) {
        return PathInterpolatorCompatApi21.create(f, f2);
    }

    public static Interpolator create(float f, float f2, float f3, float f4) {
        return PathInterpolatorCompatApi21.create(f, f2, f3, f4);
    }

    public static Interpolator create(double d, double d2, double d3, double d4) {
        return create((float) d, (float) d2, (float) d3, (float) d4);
    }
}
