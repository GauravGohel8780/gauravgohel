package com.controlcenter.allphone.ioscontrolcenter.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.custom.LayoutClick;
import com.controlcenter.allphone.ioscontrolcenter.custom.LayoutCustomControl;
import com.controlcenter.allphone.ioscontrolcenter.custom.LayoutTop;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemIcon;

import java.util.ArrayList;
import java.util.Collections;


public class AdapterApp extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final AppClickResult appClickResult;
    private final ArrayList<ItemIcon> arrBot;
    private final ArrayList<ItemIcon> arrTop;
    private boolean change;

    
    public interface AppClickResult {
        void onItemClick(int i);

        void onMove();
    }

    public AdapterApp(ArrayList<ItemIcon> arrayList, ArrayList<ItemIcon> arrayList2, AppClickResult appClickResult) {
        this.arrTop = arrayList;
        this.arrBot = arrayList2;
        this.appClickResult = appClickResult;
    }

    @Override
    public int getItemViewType(int i) {
        return (i == 0 || i == this.arrTop.size() + 1) ? 0 : 1;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        if (i == 0) {
            return new HolderTop(new LayoutTop(viewGroup.getContext()));
        }
        return new Holder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_custom, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder.getItemViewType() == 0) {
            if (i == 0) {
                ((HolderTop) viewHolder).layoutTop.setTitle(R.string.include);
            } else {
                ((HolderTop) viewHolder).layoutTop.setTitle(R.string.more_apps);
            }
        } else if (i < this.arrTop.size() + 1) {
            Holder holder = (Holder) viewHolder;
            holder.layoutCustomControl.setImAction(false);
            holder.layoutCustomControl.setApp(this.arrTop.get(i - 1));
        } else {
            Holder holder2 = (Holder) viewHolder;
            holder2.layoutCustomControl.setImAction(true);
            holder2.layoutCustomControl.setApp(this.arrBot.get(i - (this.arrTop.size() + 2)));
        }
    }

    @Override
    public int getItemCount() {
        return this.arrTop.size() + this.arrBot.size() + 2;
    }

    public void onItemMove(int i, int i2) {
        this.change = true;
        if (i <= 0 || i >= this.arrTop.size() + 1 || i2 <= 0 || i2 >= this.arrTop.size() + 1) {
            return;
        }
        if (i < i2) {
            int i3 = i - 1;
            while (i3 < i2 - 1) {
                int i4 = i3 + 1;
                Collections.swap(this.arrTop, i3, i4);
                i3 = i4;
            }
        } else {
            for (int i5 = i - 1; i5 > i2 - 1; i5--) {
                Collections.swap(this.arrTop, i5, i5 - 1);
            }
        }
        notifyItemMoved(i, i2);
    }

    public void onUp() {
        if (this.change) {
            this.change = false;
            this.appClickResult.onMove();
        }
    }

    
    class HolderTop extends RecyclerView.ViewHolder {
        LayoutTop layoutTop;

        public HolderTop(LayoutTop layoutTop) {
            super(layoutTop);
            this.layoutTop = layoutTop;
        }
    }

    
    public class Holder extends RecyclerView.ViewHolder {
        LayoutCustomControl layoutCustomControl;

        public Holder(View view) {
            super(view);
            LayoutCustomControl layoutCustomControl = (LayoutCustomControl) view.findViewById(R.id.layout_custom);
            this.layoutCustomControl = layoutCustomControl;
            layoutCustomControl.setLayoutClick(new LayoutClick() {
                @Override
                public final void onActionClick(View view2) {
                    AdapterApp.this.appClickResult.onItemClick(getLayoutPosition());
                }
            });
        }
    }
}
