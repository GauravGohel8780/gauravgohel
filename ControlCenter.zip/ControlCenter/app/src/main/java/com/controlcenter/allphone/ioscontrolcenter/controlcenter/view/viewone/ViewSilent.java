package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewone;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.TransitionDrawable;
import android.os.Handler;
import android.view.View;
import android.widget.RelativeLayout;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ViewSilent extends BaseViewOne {
    private final ViewSli im;
    private final TransitionDrawable transition;
    private boolean value;

    public ViewSilent(Context context) {
        super(context);
        removeView(this.image);
        int widthScreen = (OtherUtils.getWidthScreen(context) * 22) / 400;
        setPadding(widthScreen, widthScreen, widthScreen, widthScreen);
        ViewSli viewSli = new ViewSli(getContext());
        this.im = viewSli;
        addView(viewSli, new RelativeLayout.LayoutParams(-1, -1));
        float widthScreen2 = (OtherUtils.getWidthScreen(getContext()) * 22) / 100;
        TransitionDrawable transitionDrawable = new TransitionDrawable(new Drawable[]{OtherUtils.bgIcon(Color.parseColor("#70000000"), widthScreen2), OtherUtils.bgIcon(Color.parseColor("#c3ffffff"), widthScreen2)});
        this.transition = transitionDrawable;
        setBackground(transitionDrawable);
    }

    public void setSilent(boolean z, boolean z2) {
        if (this.value != z) {
            this.value = z;
            if (!z) {
                this.transition.reverseTransition(300);
            } else {
                this.transition.startTransition(300);
            }
        }
        this.im.setSilent(z, z2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    
    public class ViewSli extends View {
        private Bitmap bm;
        private Bitmap bmChange;
        private boolean down;
        private final Handler handler;
        private final Paint pClear;
        private int radius;
        private Rect rect;
        private final Runnable runnable;
        private boolean silent;

        public ViewSli(Context context) {
            super(context);
            this.runnable = new Runnable() {
                @Override 
                public void run() {
                    ViewSli.this.handler.postDelayed(this, 10L);
                    if (ViewSli.this.down) {
                        int i2 = ViewSli.this.radius + 8;
                        ViewSli.this.radius = i2;
                        if (ViewSli.this.radius >= (ViewSli.this.bm.getWidth() * Math.sqrt(2.0d)) / 2.0d) {
                            ViewSli.this.down = false;
                            if (ViewSli.this.silent) {
                                ViewSli viewSli = ViewSli.this;
                                viewSli.bm = BitmapFactory.decodeResource(viewSli.getResources(), R.drawable.ic_silent_on);
                            } else {
                                ViewSli viewSli2 = ViewSli.this;
                                viewSli2.bm = BitmapFactory.decodeResource(viewSli2.getResources(), R.drawable.ic_silent);
                            }
                        }
                    } else {
                        int i22 = ViewSli.this.radius - 8;
                        ViewSli.this.radius = i22;
                        if (ViewSli.this.radius <= 0) {
                            ViewSli.this.handler.removeCallbacks(this);
                        }
                    }
                    ViewSli viewSli3 = ViewSli.this;
                    viewSli3.bmChange = Bitmap.createBitmap(viewSli3.bm.getWidth(), ViewSli.this.bm.getHeight(), ViewSli.this.bm.getConfig());
                    Canvas canvas = new Canvas(ViewSli.this.bmChange);
                    canvas.drawBitmap(ViewSli.this.bm, 0.0f, 0.0f, (Paint) null);
                    if (ViewSli.this.radius > 0) {
                        canvas.drawCircle(ViewSli.this.bm.getWidth() - ViewSli.this.radius, ViewSli.this.radius, (ViewSli.this.bm.getWidth() * 9.0f) / 12.0f, ViewSli.this.pClear);
                    }
                    ViewSli.this.invalidate();
                }
            };
            Paint paint = new Paint(1);
            this.pClear = paint;
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
            this.bm = BitmapFactory.decodeResource(getResources(), R.drawable.ic_silent);
            this.bmChange = BitmapFactory.decodeResource(getResources(), R.drawable.ic_silent);
            this.handler = new Handler();
        }

        @Override 
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (this.rect == null) {
                this.rect = new Rect(0, 0, getWidth(), getHeight());
            }
            canvas.drawBitmap(this.bmChange, (Rect) null, this.rect, (Paint) null);
        }

        public void reset() {
            this.rect = null;
            invalidate();
        }

        public void setSilent(boolean z, boolean z2) {
            this.silent = z;
            if (z2) {
                this.down = true;
                this.radius = 0;
                this.handler.post(this.runnable);
                return;
            }
            if (z) {
                this.bmChange = BitmapFactory.decodeResource(getResources(), R.drawable.ic_silent_on);
            } else {
                this.bmChange = BitmapFactory.decodeResource(getResources(), R.drawable.ic_silent);
            }
            invalidate();
        }
    }
}
