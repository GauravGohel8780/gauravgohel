package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewprogress;

import android.content.Context;
import android.graphics.Canvas;

import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ViewStatusBright extends BaseViewStatus {
    public ViewStatusBright(Context context) {
        super(context);
    }

    @Override 
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float widthScreen2 = OtherUtils.getWidthScreen(getContext());
        int widthScreen = (int) widthScreen2;
        float f = (4.0f * widthScreen2) / 200.0f;
        float f2 = ((this.progress * widthScreen) * 1.6f) / 10000.0f;
        canvas.drawCircle(getWidth() / 2.0f, getHeight() / 2.0f, f, this.paint);
        if (f2 > 0.0f) {
            canvas.save();
            for (int i = 0; i < 359; i += 45) {
                canvas.rotate(i, getWidth() / 2.0f, getHeight() / 2.0f);
                float height = ((getHeight() / 2.0f) - f) - ((1.1f * widthScreen2) / 100.0f);
                canvas.drawLine(getWidth() / 2.0f, height, getWidth() / 2.0f, height - f2, this.paint);
            }
            canvas.restore();
        }
    }

    public void setColor(int i) {
        this.paint.setColor(i);
    }
}
