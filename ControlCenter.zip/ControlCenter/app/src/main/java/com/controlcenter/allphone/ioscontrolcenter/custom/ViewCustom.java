package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.adapter.AdapterApp;
import com.controlcenter.allphone.ioscontrolcenter.adapter.SimpleItemTouchHelperCallback;
import com.controlcenter.allphone.ioscontrolcenter.dialog.DialogLoad;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemControl;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemIcon;
import com.controlcenter.allphone.ioscontrolcenter.util.LoadApps;
import com.controlcenter.allphone.ioscontrolcenter.util.MyShare;

import java.util.ArrayList;
import java.util.Iterator;


public class ViewCustom extends BaseSetting implements AdapterApp.AppClickResult {
    private AdapterApp adapterApp;
    private ArrayList<ItemIcon> arrDis;
    private ArrayList<ItemIcon> arrEna;
    private DialogLoad dialogLoad;
    private final Handler handler;

    public ViewCustom(Context context) {
        super(context);
        setTitle(R.string.custom_controls);
        this.handler = new Handler(new Handler.Callback() {
            @Override
            public final boolean handleMessage(Message message) {
                if (dialogLoad != null && dialogLoad.isShowing()) {
                    dialogLoad.cancel();
                }
                addRv();
                return true;
            }
        });
        loadAllIcon();
    }


    private void loadAllIcon() {
        DialogLoad dialogLoad = new DialogLoad(getContext());
        this.dialogLoad = dialogLoad;
        dialogLoad.show();
        new Thread(new Runnable() {
            @Override 
            public final void run() {
                ViewCustom.this.loadAllIcon1();
            }
        }).start();
    }

    public void loadAllIcon1() {
        String str;
        this.arrEna = new ArrayList<>();
        ArrayList<ItemControl> arrControl = MyShare.getArrControl(getContext());
        this.arrDis = LoadApps.getAllIcon(getContext());
        if (arrControl != null) {
            Iterator<ItemControl> it = arrControl.iterator();
            while (it.hasNext()) {
                ItemControl next = it.next();
                Iterator<ItemIcon> it2 = this.arrDis.iterator();
                while (true) {
                    if (it2.hasNext()) {
                        ItemIcon next2 = it2.next();
                        String str2 = next.pkg;
                        if (str2 == null && next.type == next2.type) {
                            this.arrEna.add(next2);
                            this.arrDis.remove(next2);
                            break;
                        } else if (str2 != null && next.className != null && (str = next2.pkg) != null && next2.className != null && str2.equals(str) && next.className.equals(next2.className)) {
                            this.arrEna.add(next2);
                            this.arrDis.remove(next2);
                            break;
                        }
                    }
                }
            }
        }
        this.handler.sendEmptyMessage(1);
    }

    private void addRv() {
        LinearLayout makeL = makeL(4);
        RecyclerView recyclerView = new RecyclerView(getContext());
        makeL.addView(recyclerView, -1, -1);
        AdapterApp adapterApp = new AdapterApp(this.arrEna, this.arrDis, this);
        this.adapterApp = adapterApp;
        recyclerView.setAdapter(adapterApp);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
        new ItemTouchHelper(new SimpleItemTouchHelperCallback(this.adapterApp, recyclerView)).attachToRecyclerView(recyclerView);
    }

    @Override
    public void onItemClick(int i) {
        if (i < this.arrEna.size() + 1) {
            int i2 = i - 1;
            this.arrEna.remove(i2);
            this.adapterApp.notifyItemRemoved(i);
            this.arrDis.add(0, this.arrEna.get(i2));
            this.adapterApp.notifyItemInserted(this.arrEna.size() + 2);
        } else if (this.arrEna.size() >= 12) {
            Toast.makeText(getContext(), (int) R.string.full, Toast.LENGTH_SHORT).show();
            return;
        } else {
            ItemIcon itemIcon = this.arrDis.get(i - (this.arrEna.size() + 2));
            this.arrDis.remove(itemIcon);
            this.adapterApp.notifyItemRemoved(i);
            this.arrEna.add(itemIcon);
            this.adapterApp.notifyItemInserted(this.arrEna.size());
        }
        updateSetting();
    }

    @Override
    public void onMove() {
        updateSetting();
    }

    private void updateSetting() {
        ArrayList arrayList = new ArrayList();
        Iterator<ItemIcon> it = this.arrEna.iterator();
        while (it.hasNext()) {
            ItemIcon next = it.next();
            arrayList.add(new ItemControl(next.type, next.pkg, next.className));
        }
        MyShare.putArrControl(getContext(), arrayList);
        getContext().startService(makeIntent(14));
    }
}
