package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.music;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.PlaybackState;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.BaseRequestOptions;
import com.bumptech.glide.request.RequestOptions;
import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.custom.ViewSeekbar;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.BaseViewControl;
import com.controlcenter.allphone.ioscontrolcenter.custom.TextL;
import com.controlcenter.allphone.ioscontrolcenter.custom.TextM;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemIcon;
import com.controlcenter.allphone.ioscontrolcenter.service.MusicControlResult;
import com.controlcenter.allphone.ioscontrolcenter.util.LoadApps;
import com.controlcenter.allphone.ioscontrolcenter.util.MyConst;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;

import kotlinx.coroutines.scheduling.WorkQueueKt;


public class ViewMusicBig extends BaseViewControl implements ViewSeekbar.OnSeekBarChange {
    private final AudioManager audio;
    private final ImageView imAlbum;
    private final ImageView imApp;
    private final ImageView imPlay;
    private final LinearLayout llButton;
    private final LinearLayout llVolume;
    private MusicControlResult musicControlResult;
    private int state;
    private final TextM tvApp;
    private final TextL tvContent;
    private final TextView tvRun;
    private final TextM tvSong;
    private final TextView tvSub;
    private final ViewSeekbar vSong;
    private final View vTop;
    private final ViewSeekbar vVolume;

    public void setMusicControlResult(MusicControlResult musicControlResult) {
        this.musicControlResult = musicControlResult;
    }

    public ViewMusicBig(Context context) {
        super(context);
        this.audio = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        AudioManager audioManager = this.audio;
        float widthScreen = OtherUtils.getWidthScreen(context);
        setBackground(OtherUtils.bgIcon(Color.parseColor("#70000000"), (36.0f * widthScreen) / 100.0f));
        setAlpha(1.0f);
        View view = new View(context);
        this.vTop = view;
        view.setId(122);
        ImageView imageView = new ImageView(context);
        this.imAlbum = imageView;
        imageView.setId(123);
        imageView.setImageResource(R.drawable.img_no_album);
        int i = (int) ((4.3f * widthScreen) / 100.0f);
        imageView.setBackground(OtherUtils.bgIcon(Color.parseColor("#70000000"), i));
        ImageView imageView2 = new ImageView(context);
        this.imApp = imageView2;
        Glide.with(imageView2).load(Integer.valueOf((int) R.drawable.ic_music_icon)).apply((BaseRequestOptions<?>) new RequestOptions().override(i, i).transform(new CenterCrop(), new RoundedCorners((i * 42) / 180))).into(imageView2);
        TextM textM = new TextM(context);
        this.tvApp = textM;
        textM.setId(124);
        textM.setText(R.string.app_name);
        textM.setTextColor(Color.parseColor("#50eeeeee"));
        textM.setTextSize(0, (3.0f * widthScreen) / 100.0f);
        textM.setSingleLine();
        textM.setEllipsize(TextUtils.TruncateAt.END);
        TextM textM2 = new TextM(context);
        this.tvSong = textM2;
        textM2.setId(125);
        textM2.setText(R.string.unknown);
        textM2.setTextColor(-1);
        textM2.setTextSize(0, (4.2f * widthScreen) / 100.0f);
        textM2.setSingleLine();
        textM2.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        TextL textL = new TextL(context);
        this.tvContent = textL;
        textL.setId(126);
        textL.setText(R.string.unknown);
        textL.setTextColor(-1);
        textL.setTextSize(0, (4.1f * widthScreen) / 100.0f);
        textL.setSingleLine();
        textL.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        ViewSeekbar viewSeekbar = new ViewSeekbar(context);
        this.vSong = viewSeekbar;
        viewSeekbar.setId(127);
        viewSeekbar.setOnSeekBarChange(this);
        ViewSeekbar viewSeekbar2 = new ViewSeekbar(context);
        this.vVolume = viewSeekbar2;
        viewSeekbar2.setId(128);
        viewSeekbar2.setModeVolume();
        viewSeekbar2.setOnSeekBarChange(this);
        viewSeekbar2.setMax(audioManager.getStreamMaxVolume(3));
        TextView textView = new TextView(context);
        this.tvRun = textView;
        textView.setId(129);
        textView.setTextColor(Color.parseColor("#50eeeeee"));
        float f = (2.6f * widthScreen) / 100.0f;
        textView.setTextSize(0, f);
        TextView textView2 = new TextView(context);
        this.tvSub = textView2;
        textView2.setId(130);
        textView2.setTextColor(Color.parseColor("#50eeeeee"));
        textView2.setTextSize(0, f);
        textView.setText(OtherUtils.longToTime(0L, false));
        textView2.setText(OtherUtils.longToTime(0L, true));
        int widthScreen2 = (OtherUtils.getWidthScreen(context) * 3) / 100;
        ImageView imageView3 = new ImageView(context);
        imageView3.setId(131);
        imageView3.setImageResource(R.drawable.ic_pre);
        imageView3.setColorFilter(-1);
        imageView3.setPadding(widthScreen2, widthScreen2, widthScreen2, widthScreen2);
        ImageView imageView4 = new ImageView(context);
        this.imPlay = imageView4;
        imageView4.setId(132);
        imageView4.setImageResource(R.drawable.ic_play);
        imageView4.setColorFilter(-1);
        imageView4.setPadding(widthScreen2, widthScreen2, widthScreen2, widthScreen2);
        ImageView imageView5 = new ImageView(context);
        imageView5.setId(133);
        imageView5.setImageResource(R.drawable.ic_next_black);
        imageView5.setColorFilter(-1);
        imageView5.setPadding(widthScreen2, widthScreen2, widthScreen2, widthScreen2);
        int i2 = (widthScreen2 * 14) / 3;
        LinearLayout linearLayout = new LinearLayout(context);
        this.llButton = linearLayout;
        linearLayout.setId(134);
        linearLayout.setOrientation(LinearLayout.HORIZONTAL);
        linearLayout.setGravity(1);
        linearLayout.addView(imageView3, i2, i2);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(i2, i2);
        int i3 = i2 / 2;
        layoutParams.setMargins(i3, 0, i3, 0);
        linearLayout.addView(imageView4, layoutParams);
        linearLayout.addView(imageView5, i2, i2);
        int i4 = (i2 * 5) / 14;
        int i5 = i4 / 10;
        LinearLayout linearLayout2 = new LinearLayout(context);
        this.llVolume = linearLayout2;
        linearLayout2.setOrientation(LinearLayout.HORIZONTAL);
        ImageView imageView6 = new ImageView(context);
        imageView6.setPadding(i5, i5, i5, i5);
        imageView6.setColorFilter(Color.parseColor("#a0eeeeee"));
        imageView6.setImageResource(R.drawable.ic_volume_down);
        linearLayout2.addView(imageView6, i4, -1);
        linearLayout2.addView(viewSeekbar2, new LinearLayout.LayoutParams(0, -1, 1.0f));
        ImageView imageView7 = new ImageView(context);
        imageView7.setPadding(i5, i5, i5, i5);
        imageView7.setColorFilter(Color.parseColor("#a0eeeeee"));
        imageView7.setImageResource(R.drawable.ic_volume_up);
        linearLayout2.addView(imageView7, i4, -1);
        changeScreen(true);
        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override 
            public final void onClick(View view2) {
                musicControlResult.onControlMedia(MyConst.DATA_PRE);
            }
        });
        imageView5.setOnClickListener(new View.OnClickListener() {
            @Override 
            public final void onClick(View view2) {
                musicControlResult.onControlMedia(MyConst.DATA_NEX);
            }
        });
        imageView4.setOnClickListener(new View.OnClickListener() {
            @Override 
            public final void onClick(View view2) {
                musicControlResult.onControlMedia(MyConst.DATA_PLAY);
            }
        });
    }


    public void changeScreen(boolean z) {
        removeAllViews();
        int widthScreen = OtherUtils.getWidthScreen(getContext());
        int i = (widthScreen * 6) / 100;
        if (z) {
            int i2 = (widthScreen * 7) / 10;
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(i2, i2);
            layoutParams.setMargins(i, i, i, i);
            addView(this.imAlbum, layoutParams);
            RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
            layoutParams2.addRule(18, this.imAlbum.getId());
            layoutParams2.addRule(3, this.imAlbum.getId());
            layoutParams2.addRule(19, this.imAlbum.getId());
            addView(this.tvApp, layoutParams2);
            RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(-2, -2);
            layoutParams3.addRule(18, this.tvApp.getId());
            layoutParams3.addRule(3, this.tvApp.getId());
            layoutParams3.addRule(19, this.imAlbum.getId());
            addView(this.tvSong, layoutParams3);
            RelativeLayout.LayoutParams layoutParams4 = new RelativeLayout.LayoutParams(-2, -2);
            layoutParams4.addRule(18, this.tvApp.getId());
            layoutParams4.addRule(3, this.tvSong.getId());
            layoutParams4.addRule(19, this.imAlbum.getId());
            layoutParams4.setMargins(0, 0, 0, widthScreen / 50);
            addView(this.tvContent, layoutParams4);
            RelativeLayout.LayoutParams layoutParams5 = new RelativeLayout.LayoutParams(-1, i);
            layoutParams5.addRule(3, this.tvContent.getId());
            layoutParams5.addRule(18, this.imAlbum.getId());
            layoutParams5.addRule(19, this.imAlbum.getId());
            addView(this.vSong, layoutParams5);
            RelativeLayout.LayoutParams layoutParams6 = new RelativeLayout.LayoutParams(-2, -2);
            layoutParams6.addRule(18, this.vSong.getId());
            layoutParams6.addRule(3, this.vSong.getId());
            int i3 = (-widthScreen) / 100;
            layoutParams6.setMargins(0, i3, 0, 0);
            addView(this.tvRun, layoutParams6);
            RelativeLayout.LayoutParams layoutParams7 = new RelativeLayout.LayoutParams(-2, -2);
            layoutParams7.addRule(19, this.vSong.getId());
            layoutParams7.addRule(3, this.vSong.getId());
            layoutParams7.setMargins(0, i3, 0, 0);
            addView(this.tvSub, layoutParams7);
            RelativeLayout.LayoutParams layoutParams8 = new RelativeLayout.LayoutParams(-1, -2);
            layoutParams8.addRule(3, this.vSong.getId());
            layoutParams8.addRule(18, this.imAlbum.getId());
            layoutParams8.addRule(19, this.imAlbum.getId());
            int i4 = i / 2;
            layoutParams8.setMargins(0, i4, 0, i4);
            addView(this.llButton, layoutParams8);
            RelativeLayout.LayoutParams layoutParams9 = new RelativeLayout.LayoutParams(-1, widthScreen / 10);
            layoutParams9.addRule(3, this.llButton.getId());
            layoutParams9.addRule(18, this.imAlbum.getId());
            layoutParams9.addRule(19, this.imAlbum.getId());
            layoutParams9.setMargins(0, 0, 0, i);
            addView(this.llVolume, layoutParams9);
        } else {
            int i5 = (widthScreen * 62) / 100;
            int i6 = widthScreen / 10;
            addView(this.vTop, i6, i6);
            RelativeLayout.LayoutParams layoutParams10 = new RelativeLayout.LayoutParams(i5, i5);
            layoutParams10.setMargins(i, 0, i, i6);
            layoutParams10.addRule(3, this.vTop.getId());
            addView(this.imAlbum, layoutParams10);
            RelativeLayout.LayoutParams layoutParams11 = new RelativeLayout.LayoutParams(-2, -2);
            layoutParams11.addRule(17, this.imAlbum.getId());
            layoutParams11.addRule(2, this.imAlbum.getId());
            addView(this.tvApp, layoutParams11);
            RelativeLayout.LayoutParams layoutParams12 = new RelativeLayout.LayoutParams(i5, -2);
            layoutParams12.addRule(18, this.tvApp.getId());
            layoutParams12.addRule(3, this.tvApp.getId());
            addView(this.tvSong, layoutParams12);
            RelativeLayout.LayoutParams layoutParams13 = new RelativeLayout.LayoutParams(i5, -2);
            layoutParams13.addRule(18, this.tvSong.getId());
            layoutParams13.addRule(3, this.tvSong.getId());
            int i7 = widthScreen / 50;
            layoutParams13.setMargins(0, 0, i, i7);
            addView(this.tvContent, layoutParams13);
            RelativeLayout.LayoutParams layoutParams14 = new RelativeLayout.LayoutParams(i5, i);
            layoutParams14.addRule(3, this.tvContent.getId());
            layoutParams14.addRule(18, this.tvContent.getId());
            layoutParams14.setMargins(0, i7, 0, 0);
            addView(this.vSong, layoutParams14);
            RelativeLayout.LayoutParams layoutParams15 = new RelativeLayout.LayoutParams(-2, -2);
            layoutParams15.addRule(18, this.vSong.getId());
            layoutParams15.addRule(3, this.vSong.getId());
            addView(this.tvRun, layoutParams15);
            RelativeLayout.LayoutParams layoutParams16 = new RelativeLayout.LayoutParams(-2, -2);
            layoutParams16.addRule(19, this.vSong.getId());
            layoutParams16.addRule(3, this.vSong.getId());
            addView(this.tvSub, layoutParams16);
            RelativeLayout.LayoutParams layoutParams17 = new RelativeLayout.LayoutParams(i5, -2);
            layoutParams17.addRule(3, this.vSong.getId());
            layoutParams17.addRule(18, this.tvSong.getId());
            int i8 = widthScreen / 12;
            layoutParams17.setMargins(0, i8, 0, i8);
            addView(this.llButton, layoutParams17);
            RelativeLayout.LayoutParams layoutParams18 = new RelativeLayout.LayoutParams(i5, i6);
            layoutParams18.addRule(3, this.llButton.getId());
            layoutParams18.addRule(18, this.tvSong.getId());
            layoutParams18.addRule(19, this.tvContent.getId());
            layoutParams18.setMargins(0, 0, 0, i);
            addView(this.llVolume, layoutParams18);
        }
        RelativeLayout.LayoutParams layoutParams19 = new RelativeLayout.LayoutParams(i, i);
        layoutParams19.addRule(19, this.imAlbum.getId());
        layoutParams19.addRule(8, this.imAlbum.getId());
        int i9 = widthScreen / 50;
        layoutParams19.setMargins(0, 0, i9, i9);
        addView(this.imApp, layoutParams19);
    }

    @Override
    public void onChangeProgress(View view, long j) {
        if (view == this.vVolume) {
            this.audio.setStreamVolume(3, (int) j, 0);
        }
    }

    @Override
    public void onUp(ViewSeekbar viewSeekbar) {
        ViewSeekbar viewSeekbar2 = this.vSong;
        if (viewSeekbar == viewSeekbar2) {
            this.musicControlResult.onSeekTo(viewSeekbar2.getProgress());
        }
    }

    public void updateMetadata(MediaMetadata mediaMetadata, MediaController mediaController) {
        boolean z;
        String string = mediaMetadata.getString(MediaMetadata.METADATA_KEY_TITLE);
        String string2 = mediaMetadata.getString(MediaMetadata.METADATA_KEY_ARTIST);
        long j = mediaMetadata.getLong(MediaMetadata.METADATA_KEY_DURATION);
        long position = mediaController.getPlaybackState() != null ? mediaController.getPlaybackState().getPosition() : 0L;
        int maxVolume = mediaController.getPlaybackInfo().getMaxVolume();
        int currentVolume = mediaController.getPlaybackInfo().getCurrentVolume();
        Bitmap bitmap = mediaMetadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
        if (bitmap == null) {
            bitmap = mediaMetadata.getBitmap(MediaMetadata.METADATA_KEY_ART);
        }
        float widthScreen = OtherUtils.getWidthScreen(getContext());
        int i = (int) ((4.3f * widthScreen) / 100.0f);
        if (bitmap == null) {
            this.imAlbum.setImageResource(R.drawable.img_no_album);
            this.imAlbum.setBackground(OtherUtils.bgIcon(Color.parseColor("#70000000"), i));
        } else {
            this.imAlbum.setBackgroundColor(0);
            int i2 = (int) ((26.7f * widthScreen) / 100.0f);
            Glide.with(this.imAlbum).load(bitmap).apply((BaseRequestOptions<?>) new RequestOptions().override(i2, i2).transform(new CenterCrop(), new RoundedCorners((i * 42) / 180))).into(this.imAlbum);
        }
        ItemIcon appForPkg = LoadApps.getAppForPkg(getContext(), mediaController.getPackageName());
        if (appForPkg != null) {
            this.tvApp.setText(appForPkg.label);
            Glide.with(this.imApp).load(appForPkg.icon).apply((BaseRequestOptions<?>) new RequestOptions().override(i, i).transform(new CenterCrop(), new RoundedCorners((i * 42) / 180))).into(this.imApp);
        } else {
            this.tvApp.setText(R.string.app_name);
            Glide.with(this.imApp).load(Integer.valueOf((int) R.drawable.ic_music_icon)).apply((BaseRequestOptions<?>) new RequestOptions().override(i, i).transform(new CenterCrop(), new RoundedCorners((i * 42) / 180))).into(this.imApp);
        }
        if (string != null) {
            this.tvSong.setText(string);
            z = true;
            this.tvSong.setSelected(true);
        } else {
            z = true;
        }
        if (string2 != null) {
            this.tvContent.setText(string2);
            this.tvContent.setSelected(z);
        }
        this.vSong.setMax(j);
        this.vSong.setProgress(position);
        this.vVolume.setMax(maxVolume);
        this.vVolume.setProgress(currentVolume);
        updateTextTime();
    }

    public void updateStatus(PlaybackState playbackState, int i) {
        int state = playbackState.getState();
        long position = playbackState.getPosition();
        if (this.state != state) {
            if (state == 3) {
                this.imPlay.setImageResource(R.drawable.ic_pause);
            } else {
                this.imPlay.setImageResource(R.drawable.ic_play);
            }
            this.state = state;
        }
        updateVolume(i);
        this.vSong.setProgress(position);
        updateTextTime();
    }

    private void updateTextTime() {
        this.tvRun.setText(OtherUtils.longToTime(this.vSong.getProgress(), false));
        this.tvSub.setText(OtherUtils.longToTime(this.vSong.getMax() - this.vSong.getProgress(), true));
    }

    public void updateVolume(int i) {
        long j = i;
        if (this.vVolume.getProgress() != j) {
            this.vVolume.setProgress(j);
        }
    }
}
