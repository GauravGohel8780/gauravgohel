package com.controlcenter.allphone.ioscontrolcenter.adapter;

import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.controlcenter.allphone.ioscontrolcenter.custom.ViewItemAssis;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemMode;

import java.util.ArrayList;


public class AdapterMode extends RecyclerView.Adapter<AdapterMode.Holder> {
    private final ArrayList<ItemMode> arrMode;
    private final ModeAssisClick modeAssisClick;

    public AdapterMode(ArrayList<ItemMode> arrayList, ModeAssisClick modeAssisClick) {
        this.modeAssisClick = modeAssisClick;
        this.arrMode = arrayList;
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(new ViewItemAssis(viewGroup.getContext()));
    }

    @Override
    public void onBindViewHolder(Holder holder, int i) {
        holder.viewItemAssis.setType(this.arrMode.get(i).getId());
    }

    @Override
    public int getItemCount() {
        return this.arrMode.size();
    }

    
    public class Holder extends RecyclerView.ViewHolder {
        ViewItemAssis viewItemAssis;

        public Holder(ViewItemAssis viewItemAssis) {
            super(viewItemAssis);
            this.viewItemAssis = viewItemAssis;
            viewItemAssis.setOnClickListener(new View.OnClickListener() {
                @Override 
                public final void onClick(View view) {
                    AdapterMode.this.modeAssisClick.onItemModeClick(((ItemMode) AdapterMode.this.arrMode.get(getLayoutPosition())).getId());
                }
            });
        }

    }
}
