package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewprogress;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.CornerPathEffect;
import android.graphics.Paint;
import android.graphics.Path;

import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ViewStatusVolume extends BaseViewStatus {
    private final Path path;
    private final Path pathChange;
    private float size;
    private float w;

    public ViewStatusVolume(Context context) {
        super(context);
        this.w = OtherUtils.getWidthScreen(getContext());
        this.paint.setDither(true);
        this.paint.setPathEffect(new CornerPathEffect(this.w / 150.0f));
        this.paint.setAntiAlias(true);
        this.paint.setStrokeWidth(this.w / 250.0f);
        this.pathChange = new Path();
        this.path = new Path();
    }

    @Override
    public void setProgress(int i) {
        this.path.reset();
        this.pathChange.reset();
        this.size = ((i * this.w) * 2.0f) / 10000.0f;
        super.setProgress(i);
    }

    @Override 
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float width = ((getWidth() / 2.0f) - this.size) + ((this.w * 1.5f) / 100.0f);
        this.path.moveTo(width, getHeight() / 2.0f);
        this.path.lineTo(width, (getHeight() / 2.0f) - ((this.w * 2.8f) / 100.0f));
        this.path.lineTo(width - ((this.w * 1.8f) / 100.0f), (getHeight() / 2.0f) - ((this.w * 1.19f) / 100.0f));
        this.path.lineTo(width - ((this.w * 3.4f) / 100.0f), (getHeight() / 2.0f) - ((this.w * 1.19f) / 100.0f));
        this.path.lineTo(width - ((this.w * 3.4f) / 100.0f), (getHeight() / 2.0f) + ((this.w * 1.19f) / 100.0f));
        this.path.lineTo(width - ((this.w * 1.8f) / 100.0f), (getHeight() / 2.0f) + ((this.w * 1.19f) / 100.0f));
        this.path.lineTo(width, (getHeight() / 2.0f) + ((this.w * 2.8f) / 100.0f));
        this.path.lineTo(width, getHeight() / 2.0f);
        this.paint.setStyle(Paint.Style.FILL);
        canvas.drawPath(this.path, this.paint);
        if (this.progress == 0) {
            float f = (this.w * 2.1f) / 100.0f;
            float f2 = (3.0f * f) / 2.0f;
            this.pathChange.moveTo((getWidth() / 2.0f) - f2, (getHeight() / 2.0f) - f);
            this.pathChange.lineTo((getWidth() / 2.0f) + f2, (getHeight() / 2.0f) + f);
            this.paint.setStyle(Paint.Style.STROKE);
            this.paint.setStrokeWidth(this.w / 80.0f);
            this.paint.setColor(Color.parseColor("#80333333"));
            canvas.drawPath(this.pathChange, this.paint);
            this.paint.setStrokeWidth(this.w / 250.0f);
            this.paint.setColor(Color.parseColor("#e0aaaaaa"));
            canvas.drawPath(this.pathChange, this.paint);
            return;
        }
        for (int i = 0; i < 3; i++) {
            float f3 = (this.size * 1.5f) - ((this.w * i) / 100.0f);
            if (f3 <= 0.0f) {
                break;
            }
            float f4 = f3 * 2.0f;
            float f5 = (f4 * 3.0f) / 4.0f;
            this.pathChange.addArc(width - (f4 / 5.0f), (getHeight() / 2.0f) - f5, f4 + width, (getHeight() / 2.0f) + f5, -45.0f, 90.0f);
        }
        this.paint.setStyle(Paint.Style.STROKE);
        canvas.drawPath(this.pathChange, this.paint);
    }
}
