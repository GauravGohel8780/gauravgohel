package com.controlcenter.allphone.ioscontrolcenter.controlcenter;

import com.controlcenter.allphone.ioscontrolcenter.item.ItemControl;


public interface ControlResult {
    void changeNightShift(boolean z);

    void onGone();

    void onGoneWithAction(ItemControl itemControl);
}
