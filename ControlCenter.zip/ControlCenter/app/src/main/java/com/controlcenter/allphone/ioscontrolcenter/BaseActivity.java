package com.controlcenter.allphone.ioscontrolcenter;

import android.os.Build;
import android.os.Bundle;
import android.view.Window;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.iten.tenoku.utils.AdConstant;


public class BaseActivity extends AppCompatActivity {
    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(67108864);
        window.setStatusBarColor(getResources().getColor(R.color.color_bg_main));
        window.setNavigationBarColor(getResources().getColor(R.color.color_bg_main));
        window.getDecorView().setBackgroundColor(getResources().getColor(R.color.color_bg_main));
        int i = Build.VERSION.SDK_INT;
        int i2 = i >= 23 ? 8192 : 0;
        if (i >= 26) {
            i2 |= 16;
        }
        window.getDecorView().setSystemUiVisibility(i2);
    }


    @Override
    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
    }

    @Override
    protected void onStart() {
        super.onStart();
        AdConstant.isResume = true;
    }

}
