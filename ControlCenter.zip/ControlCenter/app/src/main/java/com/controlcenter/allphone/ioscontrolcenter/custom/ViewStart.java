package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ViewStart extends View {
    private final ValueAnimator animator;
    private final Paint paint;
    private int position;
    private float value;

    public ViewStart(Context context) {
        super(context);
        Paint paint = new Paint(1);
        this.paint = paint;
        paint.setStyle(Paint.Style.FILL);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setColor(Color.parseColor("#90afd8f7"));
        this.value = OtherUtils.getWidthScreen(getContext()) / 70.0f;
        ValueAnimator ofFloat = ValueAnimator.ofFloat(0.0f, 200.0f);
        this.animator = ofFloat;
        ofFloat.setDuration(1000L);
        ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                ViewStart.this.clickAnimationUpdate(valueAnimator);
            }
        });
    }

    public void clickAnimationUpdate(ValueAnimator valueAnimator) {
        int height = getHeight();
        int i = this.position;
        if (i == 3 || i == 4) {
            height = getWidth();
        }
        float floatValue = ((Float) this.animator.getAnimatedValue()).floatValue();
        if (floatValue < 100.0f) {
            this.value = (height * floatValue) / 100.0f;
        } else {
            if (this.value > OtherUtils.getWidthScreen(getContext()) / 70.0f) {
                float f = height;
                this.value = f - (((floatValue - 100.0f) * f) / 100.0f);
            }
            if (this.value < OtherUtils.getWidthScreen(getContext()) / 70.0f) {
                this.value = OtherUtils.getWidthScreen(getContext()) / 70.0f;
            }
        }
        invalidate();
    }

    public void setColor(int i) {
        this.paint.setColor(i);
        invalidate();
    }

    @Override 
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float widthScreen = OtherUtils.getWidthScreen(getContext()) / 50.0f;
        int i = this.position;
        if (i == 1) {
            canvas.drawRoundRect(0.0f, 0.0f, getWidth(), this.value, widthScreen, widthScreen, this.paint);
        } else if (i == 2) {
            canvas.drawRoundRect(0.0f, getHeight() - this.value, getWidth(), getHeight(), widthScreen, widthScreen, this.paint);
        } else if (i == 3) {
            canvas.drawRoundRect(0.0f, 0.0f, this.value, getHeight(), widthScreen, widthScreen, this.paint);
        } else {
            canvas.drawRoundRect(getWidth(), 0.0f, getWidth() - this.value, getHeight(), widthScreen, widthScreen, this.paint);
        }
    }

    public void changeHeight() {
        if (this.animator.isRunning()) {
            this.animator.cancel();
        }
        this.animator.start();
    }

    public void setPosition(int i) {
        this.position = i;
        invalidate();
    }
}
