package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewone;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.TransitionDrawable;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.util.CheckUtils;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ViewLock extends BaseViewOne {
    private final AnimatorSet animLock;
    private final AnimatorSet animUnLock;
    private final ImageView imOut;
    private boolean lock;
    private final TransitionDrawable transition;

    public ViewLock(Context context) {
        super(context);
        ImageView imageView = new ImageView(context);
        this.imOut = imageView;
        int widthScreen = (int) ((OtherUtils.getWidthScreen(context) * 3.4f) / 100.0f);
        imageView.setPadding(widthScreen, widthScreen, widthScreen, widthScreen);
        addView(imageView, -1, -1);
        this.image.setImageResource(R.drawable.ic_lock_rotate_off);
        imageView.setImageResource(R.drawable.ic_lock_rotate_out_off);
        ObjectAnimator ofPropertyValuesHolder = ObjectAnimator.ofPropertyValuesHolder(imageView, PropertyValuesHolder.ofFloat(View.ROTATION, 0.0f, 20.0f));
        ofPropertyValuesHolder.setDuration(400L);
        ofPropertyValuesHolder.setRepeatCount(1);
        ofPropertyValuesHolder.setRepeatMode(ValueAnimator.REVERSE);
        ofPropertyValuesHolder.setInterpolator(new DecelerateInterpolator());
        AnimatorSet animatorSet = new AnimatorSet();
        this.animLock = animatorSet;
        animatorSet.play(ofPropertyValuesHolder);
        ObjectAnimator ofPropertyValuesHolder2 = ObjectAnimator.ofPropertyValuesHolder(imageView, PropertyValuesHolder.ofFloat(View.ROTATION, 0.0f, 360.0f));
        ofPropertyValuesHolder2.setDuration(500L);
        ofPropertyValuesHolder2.setInterpolator(new DecelerateInterpolator());
        AnimatorSet animatorSet2 = new AnimatorSet();
        this.animUnLock = animatorSet2;
        animatorSet2.play(ofPropertyValuesHolder2);
        float widthScreen2 = (OtherUtils.getWidthScreen(getContext()) * 22) / 100;
        TransitionDrawable transitionDrawable = new TransitionDrawable(new Drawable[]{OtherUtils.bgIcon(Color.parseColor("#70000000"), widthScreen2), OtherUtils.bgIcon(Color.parseColor("#c3ffffff"), widthScreen2)});
        this.transition = transitionDrawable;
        setBackground(transitionDrawable);
    }

    public void setLock(boolean z, boolean z2) {
        if (this.lock != z) {
            this.lock = z;
            if (z) {
                this.transition.startTransition(300);
                this.image.setImageResource(R.drawable.ic_lock_rotate_on);
                this.imOut.setImageResource(R.drawable.ic_lock_rotate_out_on);
                if (z2) {
                    if (this.animUnLock.isRunning()) {
                        this.animUnLock.clone();
                    }
                    this.animLock.start();
                    return;
                }
                return;
            }
            this.transition.reverseTransition(300);
            this.image.setImageResource(R.drawable.ic_lock_rotate_off);
            this.imOut.setImageResource(R.drawable.ic_lock_rotate_out_off);
            if (z2) {
                if (this.animLock.isRunning()) {
                    this.animLock.clone();
                }
                this.animUnLock.start();
            }
        }
    }

    @Override
    public void onClick() {
        super.onClick();
        if (CheckUtils.checkSystemWriteSettingEndAction(getContext())) {
            CheckUtils.setAutoOrientationEnabled(this.lock, getContext());
            setLock(!this.lock, true);
        }
    }
}
