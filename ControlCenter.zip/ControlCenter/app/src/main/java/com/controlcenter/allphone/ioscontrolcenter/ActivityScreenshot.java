package com.controlcenter.allphone.ioscontrolcenter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import com.controlcenter.allphone.ioscontrolcenter.service.ServiceScreen;
import com.controlcenter.allphone.ioscontrolcenter.util.CheckUtils;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.util.List;


public class ActivityScreenshot extends Activity {
    private MediaProjectionManager mProjectionManager;

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Log.e("sssss", "sssssssssssssssssssss");
        if (Build.VERSION.SDK_INT >= 33) {
            String[] strArr = {"android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VIDEO"};
            Dexter.withContext(this).withPermissions(strArr).withListener(new AnonymousClass1()).check();
        } else if (CheckUtils.canWriteInMediaStore(this)) {
            String[] strArr2 = {"android.permission.READ_EXTERNAL_STORAGE"};
            Dexter.withContext(this).withPermissions(strArr2).withListener(new AnonymousClass1()).check();
        } else {
            String[] strArr3 = {"android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"};
            Dexter.withContext(this).withPermissions(strArr3).withListener(new AnonymousClass1()).check();
        }
    }

    
    class AnonymousClass1 implements MultiplePermissionsListener {
        AnonymousClass1() {
        }

        @Override 
        public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
            if (multiplePermissionsReport.areAllPermissionsGranted()) {
                ActivityScreenshot activityScreenshot = ActivityScreenshot.this;
                activityScreenshot.mProjectionManager = (MediaProjectionManager) activityScreenshot.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override 
                    public final void run() {
                        ActivityScreenshot.this.startProjection();
                    }
                }, 100L);
                return;
            }
            Toast.makeText(ActivityScreenshot.this, (int) R.string.error, Toast.LENGTH_SHORT).show();
        }

        @Override 
        public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
            permissionToken.continuePermissionRequest();
        }
    }

    @Override 
    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i2 == -1) {
            if (i == 100) {
                ServiceScreen.setScreenshotPermission(this, (Intent) intent.clone());
                finish();
                return;
            }
        } else if (i2 == 0) {
            ServiceScreen.setScreenshotPermission(this, null);
        }
        Toast.makeText(this, (int) R.string.not_granted, Toast.LENGTH_SHORT).show();
        finish();
    }

    public void startProjection() {
        startActivityForResult(this.mProjectionManager.createScreenCaptureIntent(), 100);
    }
}
