package com.controlcenter.allphone.ioscontrolcenter.util;

import android.content.Context;
import android.hardware.Camera;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.widget.Toast;

import com.controlcenter.allphone.ioscontrolcenter.R;

import kotlinx.coroutines.DebugKt;


public class FlashlightProvider {
    private CameraManager camManager;
    private final Context context;
    private final FlashChangeResult flashChangeResult;
    private boolean isOn;
    private Camera mCamera;
    private Camera.Parameters parameters;

    
    public interface FlashChangeResult {
        void onChangeFlash(boolean z);
    }

    public FlashlightProvider(Context context, FlashChangeResult flashChangeResult) {
        this.context = context;
        this.flashChangeResult = flashChangeResult;
    }

    public void turnFlashlightOn() {
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                CameraManager cameraManager = (CameraManager) this.context.getSystemService("camera");
                this.camManager = cameraManager;
                if (cameraManager != null) {
                    cameraManager.setTorchMode(cameraManager.getCameraIdList()[0], true);
                    this.isOn = true;
                } else {
                    this.isOn = false;
                }
            } catch (Exception e) {
                this.isOn = false;
                Toast.makeText(this.context, (int) R.string.error, 0).show();
            }
        } else {
            try {
                Camera open = Camera.open();
                this.mCamera = open;
                Camera.Parameters parameters = open.getParameters();
                this.parameters = parameters;
                parameters.setFlashMode("torch");
                this.mCamera.setParameters(this.parameters);
                this.mCamera.startPreview();
                this.isOn = true;
            } catch (Exception e2) {
                Toast.makeText(this.context, (int) R.string.error, 0).show();
            }
        }
        this.flashChangeResult.onChangeFlash(this.isOn);
    }

    public void turnFlashlightOff() {
        this.isOn = false;
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                CameraManager cameraManager = (CameraManager) this.context.getSystemService(Context.CAMERA_SERVICE);
                this.camManager = cameraManager;
                if (cameraManager != null) {
                    cameraManager.setTorchMode(cameraManager.getCameraIdList()[0], false);
                }
            } catch (Exception e) {
                Toast.makeText(this.context, (int) R.string.error, Toast.LENGTH_SHORT).show();
            }
        } else {
            try {
                Camera open = Camera.open();
                this.mCamera = open;
                Camera.Parameters parameters = open.getParameters();
                this.parameters = parameters;
                parameters.setFlashMode(DebugKt.DEBUG_PROPERTY_VALUE_OFF);
                this.mCamera.setParameters(this.parameters);
                this.mCamera.stopPreview();
            } catch (Exception e2) {
                Toast.makeText(this.context, (int) R.string.error, 0).show();
            }
        }
        this.flashChangeResult.onChangeFlash(this.isOn);
    }

    public boolean isOn() {
        return this.isOn;
    }
}
