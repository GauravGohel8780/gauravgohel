package com.controlcenter.allphone.ioscontrolcenter.touch;

import android.os.Bundle;
import android.widget.ScrollView;

import com.controlcenter.allphone.ioscontrolcenter.BaseActivity;

import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;


public class ActivityTouch extends BaseActivity {
    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        
        
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setVerticalScrollBarEnabled(false);
        OverScrollDecoratorHelper.setUpOverScroll(scrollView);
        scrollView.addView(new ViewTouchUi(this));
        setContentView(scrollView);
    }
}
