package com.controlcenter.allphone.ioscontrolcenter.dialog;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;

import androidx.core.view.ViewCompat;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.custom.TextB;
import com.controlcenter.allphone.ioscontrolcenter.custom.TextM;
import com.controlcenter.allphone.ioscontrolcenter.util.MyShare;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class DialogChangeBg extends BaseDialog {
    private final DialogWallpaperResult dialogPerResult;

    public DialogChangeBg(Context context, DialogWallpaperResult dialogWallpaperResult) {
        super(context);
        this.dialogPerResult = dialogWallpaperResult;
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        int i = getContext().getResources().getDisplayMetrics().widthPixels;
        LinearLayout linearLayout = new LinearLayout(getContext());
        linearLayout.setGravity(17);
        LinearLayout linearLayout2 = new LinearLayout(getContext());
        linearLayout2.setOrientation(1);
        linearLayout2.setGravity(1);
        linearLayout.addView(linearLayout2, (i * 72) / 100, -2);
        setContentView(linearLayout);
        int i2 = i / 25;
        linearLayout2.setBackground(OtherUtils.bgLayout(getContext(), Color.parseColor("#eaffffff")));
        TextB textB = new TextB(getContext());
        textB.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        float f = i;
        float f2 = (4.3f * f) / 100.0f;
        textB.setTextSize(0, f2);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        int i3 = (i2 * 4) / 3;
        layoutParams.setMargins(i2, i3, i2, i2 / 6);
        linearLayout2.addView(textB, layoutParams);
        textB.setText(R.string.bg);
        textB.setSingleLine();
        TextM textM = new TextM(getContext());
        textM.setText(R.string.content_wallpaper);
        textM.setGravity(1);
        textM.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        textM.setEllipsize(TextUtils.TruncateAt.END);
        textM.setTextSize(0, (3.3f * f) / 100.0f);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.setMargins(i2, 0, i2, i3);
        linearLayout2.addView(textM, layoutParams2);
        linearLayout2.addView(vDivider(), -1, 1);
        TextB textB2 = new TextB(getContext());
        textB2.setId(1);
        textB2.setTextColor(Color.parseColor("#3478f6"));
        textB2.setTextSize(0, f2);
        textB2.setText(R.string.wallpaper);
        textB2.setOnClickListener(new View.OnClickListener() {
            @Override 
            public final void onClick(View view) {
                DialogChangeBg.this.onClick(view);
            }
        });
        textB2.setGravity(17);
        int i4 = (int) ((11.5f * f) / 100.0f);
        linearLayout2.addView(textB2, -1, i4);
        linearLayout2.addView(vDivider(), -1, 1);
        TextB textB3 = new TextB(getContext());
        textB3.setId(2);
        textB3.setTextColor(Color.parseColor("#3478f6"));
        textB3.setTextSize(0, f2);
        textB3.setText(R.string.tran);
        textB3.setOnClickListener(new View.OnClickListener() {
            @Override 
            public final void onClick(View view) {
                DialogChangeBg.this.onClick(view);
            }
        });
        textB3.setGravity(17);
        linearLayout2.addView(textB3, -1, i4);
        linearLayout2.addView(vDivider(), -1, 1);

        TextM textM2 = new TextM(getContext());
        textM2.setId(125);
        textM2.setTextColor(Color.parseColor("#3478f6"));
        textM2.setTextSize(0, f2);
        textM2.setText(R.string.cancel);
        textM2.setOnClickListener(new View.OnClickListener() {
            @Override 
            public final void onClick(View view) {
                DialogChangeBg.this.onClick(view);
            }
        });
        textM2.setGravity(17);
        linearLayout2.addView(textM2, -1, i4);
        int statusWallpaper = MyShare.getStatusWallpaper(getContext());
        if (statusWallpaper == 1) {
            textB2.setText("       " + getContext().getString(R.string.wallpaper) + "    \u2714");
        } else if (statusWallpaper == 2) {
            textB3.setText("       " + getContext().getString(R.string.tran) + "    \u2714");
        }
    }

    private View vDivider() {
        View view = new View(getContext());
        view.setBackgroundColor(Color.parseColor("#30000000"));
        return view;
    }

    public void onClick(View view) {
        if (this.dialogPerResult != null && view.getId() != 125) {
            this.dialogPerResult.onChangeWallpaper(view.getId());
        }
        cancel();
    }
}
