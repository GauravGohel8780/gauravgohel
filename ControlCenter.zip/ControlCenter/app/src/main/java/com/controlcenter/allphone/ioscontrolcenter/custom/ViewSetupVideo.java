package com.controlcenter.allphone.ioscontrolcenter.custom;

import static com.iten.tenoku.ad.AdShow.getInstance;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.iten.tenoku.utils.AdUtils;


public class ViewSetupVideo extends BaseSetting {
    public ViewSetupVideo(Context context) {
        super(context);
        setTitle(R.string.setup_the_record);



        makeL(4).addView(LayoutInflater.from(context).inflate(R.layout.layout_setting_video, (ViewGroup) null), -1, -2);


    }
}
