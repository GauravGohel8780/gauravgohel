package com.controlcenter.allphone.ioscontrolcenter.adapter;


public interface ModeAssisClick {
    void onItemModeClick(int i);
}
