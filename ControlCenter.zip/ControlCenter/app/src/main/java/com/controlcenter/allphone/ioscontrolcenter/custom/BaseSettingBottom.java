package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.widget.RelativeLayout;

import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class BaseSettingBottom extends RelativeLayout {
    final RelativeLayout rlBot;
    RelativeLayout rlMain;
    final View vBg;

    public static void lambda$new$1(View view) {
    }

    public BaseSettingBottom(Context context) {
        super(context);
        View view = new View(context);
        this.vBg = view;
        view.setOnClickListener(new OnClickListener() {
            @Override 
            public final void onClick(View view2) {
                hideView();
            }
        });
        view.setBackgroundColor(Color.parseColor("#60000000"));
        view.setAlpha(0.0f);
        addView(view, -1, -1);
        int i = getResources().getDisplayMetrics().widthPixels;
        RelativeLayout relativeLayout = new RelativeLayout(context);
        this.rlBot = relativeLayout;
        relativeLayout.setOnClickListener(new OnClickListener() {
            @Override 
            public final void onClick(View view2) {
                BaseSettingBottom.lambda$new$1(view2);
            }
        });
        relativeLayout.setBackground(OtherUtils.bgTopSearch(Color.parseColor("#faf7f7f7"), (i * 21) / 100));
        LayoutParams layoutParams = new LayoutParams(-1, -2);
        layoutParams.addRule(12);
        addView(relativeLayout, layoutParams);
    }



    public void showView(RelativeLayout relativeLayout) {
        this.rlMain = relativeLayout;
        if (relativeLayout.indexOfChild(this) == -1) {
            relativeLayout.addView(this, -1, -1);
        }
        int height = this.rlBot.getHeight();
        if (height < 1) {
            height = getResources().getDisplayMetrics().widthPixels;
        }
        this.rlBot.setTranslationY(height);
        this.vBg.animate().alpha(1.0f).setDuration(300L).start();
        this.rlBot.animate().translationY(0.0f).setDuration(300L).start();
    }

    public void hideView() {
        this.vBg.animate().alpha(0.0f).setDuration(300L).start();
        this.rlBot.animate().translationY(this.rlBot.getHeight()).setDuration(300L).withEndAction(new Runnable() {
            @Override 
            public final void run() {
                if (rlMain.indexOfChild(BaseSettingBottom.this) != -1) {
                    rlMain.removeView(BaseSettingBottom.this);
                }
            }
        }).start();
    }


    public void addDivider(View view) {
        View view2 = new View(getContext());
        view2.setBackgroundColor(Color.parseColor("#aaaaaa"));
        LayoutParams layoutParams = new LayoutParams(-1, 1);
        layoutParams.addRule(3, view.getId());
        this.rlBot.addView(view2, layoutParams);
    }

    public void addDivider(RelativeLayout relativeLayout, int i) {
        View view = new View(getContext());
        view.setBackgroundColor(Color.parseColor("#eeeeee"));
        LayoutParams layoutParams = new LayoutParams(-1, 1);
        layoutParams.addRule(12);
        layoutParams.setMargins(i, 0, 0, 0);
        relativeLayout.addView(view, layoutParams);
    }
}
