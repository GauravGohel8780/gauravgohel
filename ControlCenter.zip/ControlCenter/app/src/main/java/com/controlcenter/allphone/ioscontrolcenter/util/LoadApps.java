package com.controlcenter.allphone.ioscontrolcenter.util;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.LauncherActivityInfo;
import android.content.pm.LauncherApps;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.UserHandle;

import com.controlcenter.allphone.ioscontrolcenter.item.ItemControl;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemIcon;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class LoadApps {
    public static ArrayList<ItemIcon> getAllIcon(Context context) {
        List<UserHandle> profiles;
        ArrayList<ItemIcon> arrayList = new ArrayList<>();
        Iterator<ItemControl> it = MyShare.arrDefault().iterator();
        while (it.hasNext()) {
            arrayList.add(new ItemIcon(it.next().type, context));
        }
        if (Build.VERSION.SDK_INT >= 26) {
            LauncherApps launcherApps = (LauncherApps) context.getSystemService("launcherapps");
            profiles = launcherApps.getProfiles();
            for (UserHandle userHandle : profiles) {
                for (LauncherActivityInfo launcherActivityInfo : launcherApps.getActivityList(null, userHandle)) {
                    arrayList.add(new ItemIcon(launcherActivityInfo.getComponentName().getPackageName(), launcherActivityInfo.getName(), launcherActivityInfo.getLabel().toString(), launcherActivityInfo.getIcon(0)));
                }
            }
        } else {
            Intent intent = new Intent("android.intent.action.MAIN", (Uri) null);
            intent.addCategory("android.intent.category.LAUNCHER");
            for (ResolveInfo resolveInfo : context.getPackageManager().queryIntentActivities(intent, 0)) {
                ActivityInfo activityInfo = resolveInfo.activityInfo;
                arrayList.add(new ItemIcon(activityInfo.packageName, activityInfo.name, resolveInfo.loadLabel(context.getPackageManager()).toString(), resolveInfo.loadIcon(context.getPackageManager())));
            }
        }
        return arrayList;
    }

    public static ItemIcon getAppForPkg(Context context, String str) {
        List<UserHandle> profiles;
        if (Build.VERSION.SDK_INT >= 26) {
            LauncherApps launcherApps = (LauncherApps) context.getSystemService(Context.LAUNCHER_APPS_SERVICE);
            profiles = launcherApps.getProfiles();
            for (UserHandle userHandle : profiles) {
                for (LauncherActivityInfo launcherActivityInfo : launcherApps.getActivityList(null, userHandle)) {
                    String packageName = launcherActivityInfo.getComponentName().getPackageName();
                    String name = launcherActivityInfo.getName();
                    if (packageName.equals(str)) {
                        return new ItemIcon(str, name, launcherActivityInfo.getLabel().toString(), launcherActivityInfo.getIcon(0));
                    }
                }
            }
        } else {
            Intent intent = new Intent("android.intent.action.MAIN", (Uri) null);
            intent.addCategory("android.intent.category.LAUNCHER");
            for (ResolveInfo resolveInfo : context.getPackageManager().queryIntentActivities(intent, 0)) {
                ActivityInfo activityInfo = resolveInfo.activityInfo;
                String str2 = activityInfo.packageName;
                String str3 = activityInfo.name;
                if (str2.equals(str)) {
                    return new ItemIcon(str, str3, resolveInfo.loadLabel(context.getPackageManager()).toString(), resolveInfo.loadIcon(context.getPackageManager()));
                }
            }
        }
        return null;
    }

    public static ItemIcon getAppForPkg(Context context, String str, String str2) {
        List<UserHandle> profiles;
        if (Build.VERSION.SDK_INT >= 26) {
            LauncherApps launcherApps = (LauncherApps) context.getSystemService(Context.LAUNCHER_APPS_SERVICE);
            profiles = launcherApps.getProfiles();
            for (UserHandle userHandle : profiles) {
                for (LauncherActivityInfo launcherActivityInfo : launcherApps.getActivityList(null, userHandle)) {
                    String packageName = launcherActivityInfo.getComponentName().getPackageName();
                    String name = launcherActivityInfo.getName();
                    if (packageName.equals(str) && str2.equals(name)) {
                        return new ItemIcon(str, name, launcherActivityInfo.getLabel().toString(), launcherActivityInfo.getIcon(0));
                    }
                }
            }
        } else {
            Intent intent = new Intent("android.intent.action.MAIN", (Uri) null);
            intent.addCategory("android.intent.category.LAUNCHER");
            for (ResolveInfo resolveInfo : context.getPackageManager().queryIntentActivities(intent, 0)) {
                ActivityInfo activityInfo = resolveInfo.activityInfo;
                String str3 = activityInfo.packageName;
                String str4 = activityInfo.name;
                if (str3.equals(str) && str2.equals(str4)) {
                    return new ItemIcon(str, str4, resolveInfo.loadLabel(context.getPackageManager()).toString(), resolveInfo.loadIcon(context.getPackageManager()));
                }
            }
        }
        return null;
    }

    public static ItemIcon findAppForKey(Context context, String... strArr) {
        boolean z;
        List<UserHandle> profiles;
        boolean z2;
        if (Build.VERSION.SDK_INT >= 26) {
            LauncherApps launcherApps = (LauncherApps) context.getSystemService(Context.LAUNCHER_APPS_SERVICE);
            profiles = launcherApps.getProfiles();
            for (UserHandle userHandle : profiles) {
                for (LauncherActivityInfo launcherActivityInfo : launcherApps.getActivityList(null, userHandle)) {
                    if ((launcherActivityInfo.getApplicationInfo().flags & 1) != 0) {
                        String packageName = launcherActivityInfo.getComponentName().getPackageName();
                        int length = strArr.length;
                        int i = 0;
                        while (true) {
                            if (i >= length) {
                                z2 = false;
                                break;
                            } else if (packageName.contains(strArr[i])) {
                                z2 = true;
                                break;
                            } else {
                                i++;
                            }
                        }
                        if (z2) {
                            return new ItemIcon(packageName, launcherActivityInfo.getName(), launcherActivityInfo.getLabel().toString(), launcherActivityInfo.getIcon(0));
                        }
                    }
                }
            }
            return null;
        }
        Intent intent = new Intent("android.intent.action.MAIN", (Uri) null);
        intent.addCategory("android.intent.category.LAUNCHER");
        List<ResolveInfo> queryIntentActivities = context.getPackageManager().queryIntentActivities(intent, 0);
        if (queryIntentActivities != null) {
            for (ResolveInfo resolveInfo : queryIntentActivities) {
                ActivityInfo activityInfo = resolveInfo.activityInfo;
                if ((activityInfo.applicationInfo.flags & 1) != 0) {
                    String str = activityInfo.packageName;
                    int length2 = strArr.length;
                    int i2 = 0;
                    while (true) {
                        if (i2 >= length2) {
                            z = false;
                            break;
                        } else if (str.contains(strArr[i2])) {
                            z = true;
                            break;
                        } else {
                            i2++;
                        }
                    }
                    if (z) {
                        ActivityInfo activityInfo2 = resolveInfo.activityInfo;
                        return new ItemIcon(activityInfo2.packageName, activityInfo2.name, resolveInfo.loadLabel(context.getPackageManager()).toString(), resolveInfo.loadIcon(context.getPackageManager()));
                    }
                }
            }
            return null;
        }
        return null;
    }

    public static boolean checkAppForPackage(Context context, String str) {
        List<UserHandle> profiles;
        if (Build.VERSION.SDK_INT >= 26) {
            LauncherApps launcherApps = (LauncherApps) context.getSystemService(Context.LAUNCHER_APPS_SERVICE);
            profiles = launcherApps.getProfiles();
            for (UserHandle userHandle : profiles) {
                for (LauncherActivityInfo launcherActivityInfo : launcherApps.getActivityList(null, userHandle)) {
                    if (launcherActivityInfo.getComponentName().getPackageName().equals(str)) {
                        return true;
                    }
                }
            }
        } else {
            Intent intent = new Intent("android.intent.action.MAIN", (Uri) null);
            intent.addCategory("android.intent.category.LAUNCHER");
            List<ResolveInfo> queryIntentActivities = context.getPackageManager().queryIntentActivities(intent, 0);
            if (queryIntentActivities != null) {
                for (ResolveInfo resolveInfo : queryIntentActivities) {
                    if (resolveInfo.activityInfo.packageName.equals(str)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
