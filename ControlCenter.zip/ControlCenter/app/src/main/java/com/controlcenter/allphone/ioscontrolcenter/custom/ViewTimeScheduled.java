package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.content.Context;
import android.graphics.Color;

import androidx.core.view.ViewCompat;

import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;

import java.util.Calendar;


public class ViewTimeScheduled extends TextM {
    public ViewTimeScheduled(Context context) {
        super(context);
        int widthScreen = OtherUtils.getWidthScreen(context);
        float f = widthScreen;
        setBackground(OtherUtils.bgIcon(Color.parseColor("#eeeeee"), f / 20.0f));
        setGravity(17);
        setTextSize(0, (4.2f * f) / 100.0f);
        setTextColor(ViewCompat.MEASURED_STATE_MASK);
        int i = widthScreen / 50;
        int i2 = i / 2;
        setPadding(i, i2, i, i2);
    }

    public void setTime(long j) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(j);
        setText(OtherUtils.setNum(calendar.get(11)) + ":" + OtherUtils.setNum(calendar.get(12)));
    }
}
