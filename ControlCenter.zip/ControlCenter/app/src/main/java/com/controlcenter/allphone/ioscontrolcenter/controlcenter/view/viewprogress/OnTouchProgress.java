package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewprogress;

import android.content.Context;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;


public class OnTouchProgress implements View.OnTouchListener {
    private boolean flagScroll;
    private final GestureDetector gestureDetector;
    private final TouchResult touchResult;

    
    public interface TouchResult {
        void onLongClick();

        void onMoveVertical(float f);

        void onTouchDown();

        void onTouchUp();
    }

    public OnTouchProgress(Context context, TouchResult touchResult) {
        this.gestureDetector = new GestureDetector(context, new GestureListener());
        this.touchResult = touchResult;
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.touchResult.onTouchDown();
        } else if (motionEvent.getAction() == 1 || motionEvent.getAction() == 3) {
            this.touchResult.onTouchUp();
        }
        this.gestureDetector.onTouchEvent(motionEvent);
        return true;
    }

    
    private final class GestureListener extends GestureDetector.SimpleOnGestureListener {
        private GestureListener() {
        }

        @Override
        public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
            if (!OnTouchProgress.this.flagScroll) {
                OnTouchProgress.this.flagScroll = true;
            }
            OnTouchProgress.this.touchResult.onMoveVertical(motionEvent2.getRawY() - motionEvent.getRawY());
            return super.onScroll(motionEvent, motionEvent2, f, f2);
        }

        @Override
        public void onLongPress(MotionEvent motionEvent) {
            super.onLongPress(motionEvent);
            OnTouchProgress.this.touchResult.onLongClick();
        }
    }
}
