package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.connect;


public interface ConnectClickResult {
    void onAirClick();

    void onBlueClick();

    void onDataClick();

    void onHotClick();

    void onSyncClick();

    void onWifiClick();
}
