package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.core.view.ViewCompat;

import com.bumptech.glide.Glide;
import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemMode;
import com.controlcenter.allphone.ioscontrolcenter.util.AssistiveUtils;

import java.util.Iterator;


public class ViewItem extends RelativeLayout {
    private final ImageView im;
    private String pkg;
    private ViewSwitch sw;
    private SwitchListener switchListener;
    private final TextM tv;
    private TextM tvMode;
    private final View vDivider;

    
    public interface SwitchListener {
        void onSwitchChange(ViewItem viewItem, boolean z);
    }

    public ViewItem(Context context) {
        super(context);
        setBackgroundResource(R.drawable.bg_sel_item_main);
        int i = getResources().getDisplayMetrics().widthPixels;
        int i2 = i / 25;
        int i3 = i / 7;
        ImageView imageView = new ImageView(context);
        this.im = imageView;
        imageView.setId(123);
        int i4 = i3 - ((i2 * 3) / 2);
        LayoutParams layoutParams = new LayoutParams(i4, i4);
        layoutParams.setMargins(i2, 0, i2, 0);
        layoutParams.addRule(15);
        addView(imageView, layoutParams);
        TextM textM = new TextM(context);
        this.tv = textM;
        textM.setSingleLine();
        textM.setEllipsize(TextUtils.TruncateAt.END);
        textM.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        textM.setTextSize(0, (i * 3.8f) / 100.0f);
        LayoutParams layoutParams2 = new LayoutParams(-2, -2);
        layoutParams2.addRule(15);
        layoutParams2.addRule(17, imageView.getId());
        layoutParams2.setMargins(0, 0, i3, 0);
        addView(textM, layoutParams2);
        View view = new View(context);
        this.vDivider = view;
        view.setBackgroundColor(Color.parseColor("#40555555"));
        LayoutParams layoutParams3 = new LayoutParams(-1, 1);
        layoutParams3.addRule(12);
        layoutParams3.addRule(17, imageView.getId());
        addView(view, layoutParams3);
    }

    public void addNew() {
        int i = getResources().getDisplayMetrics().widthPixels / 25;
        ImageView imageView = new ImageView(getContext());
        imageView.setImageResource(R.drawable.ic_new);
        LayoutParams layoutParams = new LayoutParams((i * 7) / 2, -1);
        layoutParams.addRule(21);
        layoutParams.addRule(15);
        layoutParams.setMargins(0, 0, i / 2, 0);
        addView(imageView, layoutParams);
    }

    public void addNext() {
        int i = getResources().getDisplayMetrics().widthPixels / 25;
        ImageView imageView = new ImageView(getContext());
        imageView.setImageResource(R.drawable.ic_item_next_main);
        int i2 = (i * 2) / 3;
        LayoutParams layoutParams = new LayoutParams(i2, i2);
        layoutParams.addRule(21);
        layoutParams.addRule(15);
        layoutParams.setMargins(0, 0, i / 2, 0);
        addView(imageView, layoutParams);
    }

    public void addSwitch(SwitchListener switchListener, boolean z) {
        this.switchListener = switchListener;
        ViewSwitch viewSwitch = new ViewSwitch(getContext());
        this.sw = viewSwitch;
        viewSwitch.setStatus(z);
        this.sw.setStatusResult(new ViewSwitch.StatusResult() {
            @Override
            public final void onSwitchResult(boolean z2) {
                switchListener.onSwitchChange(ViewItem.this, z2);
            }
        });
        int i = getResources().getDisplayMetrics().widthPixels;
        int i2 = (int) ((i * 6.3f) / 100.0f);
        LayoutParams layoutParams = new LayoutParams((int) ((i2 * 13.6f) / 8.3f), i2);
        layoutParams.addRule(21);
        layoutParams.addRule(15);
        layoutParams.setMargins(0, 0, (i / 25) / 2, 0);
        addView(this.sw, layoutParams);
    }



    public void setItem(int i, int i2) {
        setId(i2);
        this.im.setImageResource(i);
        this.tv.setText(i2);
    }

    public void setItem(String str, String str2, String str3) {
        this.pkg = str3;
        this.tv.setText(str2);
        Glide.with(getContext()).load(str).into(this.im);
    }

    public void addTextMode(int i) {
        int i2;
        Iterator<ItemMode> it = AssistiveUtils.makeArrHomeMode().iterator();
        while (true) {
            if (!it.hasNext()) {
                i2 = R.string.a_none_action;
                break;
            }
            ItemMode next = it.next();
            if (next.getId() == i) {
                int i22 = next.getText();
                i2 = i22;
                break;
            }
        }
        TextM textM = this.tvMode;
        if (textM != null) {
            textM.setText(i2);
            return;
        }
        int i3 = getResources().getDisplayMetrics().widthPixels / 25;
        TextM textM2 = new TextM(getContext());
        this.tvMode = textM2;
        textM2.setText(i2);
        int i4 = i3 / 2;
        int i5 = i3 / 8;
        this.tvMode.setPadding(i4, i5, i4, i5);
        this.tvMode.setTextColor(Color.parseColor("#777777"));
        this.tvMode.setTextSize(0, (getResources().getDisplayMetrics().widthPixels * 3.3f) / 100.0f);
        LayoutParams layoutParams = new LayoutParams(-2, -2);
        layoutParams.addRule(21);
        layoutParams.addRule(15);
        layoutParams.setMargins(0, 0, i4, 0);
        addView(this.tvMode, layoutParams);
    }

    public String getPkg() {
        return this.pkg;
    }

    public void goneDivider() {
        this.vDivider.setVisibility(View.GONE);
    }

    public void setStatus(boolean z) {
        ViewSwitch viewSwitch = this.sw;
        if (viewSwitch != null) {
            viewSwitch.setStatus(z);
        }
    }
}
