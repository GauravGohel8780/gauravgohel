package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.connect;

import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.custom.TextB;
import com.controlcenter.allphone.ioscontrolcenter.custom.TextM;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ViewItemConnect extends LinearLayout {
    private final ImageView im;
    private final TextM tvContent;
    private final TextB tvTitle;

    public ViewItemConnect(Context context) {
        super(context);
        int widthScreen = OtherUtils.getWidthScreen(context);
        int i = widthScreen / 25;
        setOrientation(LinearLayout.VERTICAL);
        setGravity(1);
        setPadding(i, 0, i, 0);
        int i2 = (widthScreen * 14) / 100;
        int i3 = widthScreen / 110;
        ImageView imageView = new ImageView(context);
        this.im = imageView;
        imageView.setPadding(i3, i3, i3, i3);
        addView(imageView, i2, i2);
        TextB textB = new TextB(context);
        this.tvTitle = textB;
        textB.setTextColor(-1);
        float f = (widthScreen * 2.7f) / 100.0f;
        textB.setTextSize(0, f);
        textB.setSingleLine();
        textB.setEllipsize(TextUtils.TruncateAt.END);
        LayoutParams layoutParams = new LayoutParams(-2, -2);
        layoutParams.setMargins(0, widthScreen / 80, 0, 0);
        addView(textB, layoutParams);
        TextM textM = new TextM(context);
        this.tvContent = textM;
        textM.setTextColor(-1);
        textM.setTextSize(0, f);
        textM.setSingleLine();
        textM.setEllipsize(TextUtils.TruncateAt.END);
        addView(textM, -2, -2);
    }

    public void setData(int i, int i2) {
        this.im.setImageResource(i);
        this.tvTitle.setText(i2);
    }

    public void setContent(String str) {
        this.tvContent.setText(str);
    }

    public void setContent(int i) {
        this.tvContent.setText(i);
    }

    public void setStatus(boolean z, int i) {
        if (z) {
            this.tvContent.setText(R.string.on);
            this.im.setBackground(OtherUtils.makeOval(i));
            return;
        }
        this.tvContent.setText(R.string.off);
        this.im.setBackground(OtherUtils.makeOval(Color.parseColor("#30ffffff")));
    }
}
