package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.music;

import android.content.Context;
import android.media.MediaMetadata;
import android.media.session.PlaybackState;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.ViewControlCenter;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.BaseViewControl;
import com.controlcenter.allphone.ioscontrolcenter.custom.TextB;
import com.controlcenter.allphone.ioscontrolcenter.custom.TextM;
import com.controlcenter.allphone.ioscontrolcenter.service.MusicControlResult;
import com.controlcenter.allphone.ioscontrolcenter.util.MyConst;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ViewMusic extends BaseViewControl {
    private final ImageView imPlay;
    private MusicControlResult musicControlResult;
    private int state;
    private final TextM tvContent;
    private final TextB tvTitle;
    private View vClick;

    public void setMusicControlResult(MusicControlResult musicControlResult) {
        this.musicControlResult = musicControlResult;
    }

    public ViewMusic(Context context) {
        super(context);
        OnTouchListener onTouchListener = new OnTouchListener() {
            @Override
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                return ViewMusic.this.m54xd02f4606(view, motionEvent);
            }
        };
        int widthScreen = OtherUtils.getWidthScreen(context);
        int i = (widthScreen * 14) / 100;
        int i2 = (widthScreen * 4) / 100;
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(LinearLayout.HORIZONTAL);
        LayoutParams layoutParams = new LayoutParams(-1, i);
        layoutParams.setMargins(0, 0, 0, widthScreen / 25);
        layoutParams.addRule(12);
        addView(linearLayout, layoutParams);
        ImageView imageView = new ImageView(context);
        imageView.setId(124);
        imageView.setPadding(i2, i2, i2, i2);
        imageView.setImageResource(R.drawable.ic_pre);
        imageView.setColorFilter(-1);
        imageView.setOnTouchListener(onTouchListener);
        linearLayout.addView(imageView, new LinearLayout.LayoutParams(0, -1, 1.0f));
        ImageView imageView2 = new ImageView(context);
        this.imPlay = imageView2;
        imageView2.setId(125);
        imageView2.setPadding(i2, i2, i2, i2);
        imageView2.setImageResource(R.drawable.ic_play);
        imageView2.setColorFilter(-1);
        imageView2.setOnTouchListener(onTouchListener);
        linearLayout.addView(imageView2, new LinearLayout.LayoutParams(0, -1, 1.0f));
        ImageView imageView3 = new ImageView(context);
        imageView3.setId(126);
        imageView3.setPadding(i2, i2, i2, i2);
        imageView3.setImageResource(R.drawable.ic_next_black);
        imageView3.setColorFilter(-1);
        imageView3.setOnTouchListener(onTouchListener);
        linearLayout.addView(imageView3, new LinearLayout.LayoutParams(0, -1, 1.0f));
        LinearLayout linearLayout2 = new LinearLayout(context);
        linearLayout2.setOrientation(LinearLayout.VERTICAL);
        linearLayout2.setGravity(17);
        linearLayout2.setPadding(i2, 0, i2, 0);
        LayoutParams layoutParams2 = new LayoutParams(-1, -1);
        layoutParams2.setMargins(0, 0, 0, i);
        addView(linearLayout2, layoutParams2);
        TextB textB = new TextB(context);
        this.tvTitle = textB;
        textB.setText(R.string.unknown);
        float f = widthScreen;
        textB.setTextSize(0, (3.78f * f) / 100.0f);
        textB.setTextColor(-1);
        textB.setSingleLine();
        textB.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        linearLayout2.addView(textB, -2, -2);
        TextM textM = new TextM(context);
        this.tvContent = textM;
        textM.setText(R.string.unknown);
        textM.setTextSize(0, (3.75f * f) / 100.0f);
        textM.setTextColor(-1);
        textM.setSingleLine();
        textM.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        linearLayout2.addView(textM, -2, -2);
    }

    public boolean m54xd02f4606(View view, MotionEvent motionEvent) {
        this.vClick = view;
        return false;
    }

    public void updateMetadata(MediaMetadata mediaMetadata) {
        String string = mediaMetadata.getString(MediaMetadata.METADATA_KEY_TITLE);
        String string2 = mediaMetadata.getString(MediaMetadata.METADATA_KEY_ARTIST);
        if (string != null) {
            this.tvTitle.setText(string);
            this.tvTitle.setSelected(true);
        } else {
            this.tvTitle.setText(R.string.unknown);
        }
        if (string2 != null) {
            this.tvContent.setText(string2);
            this.tvContent.setSelected(true);
            return;
        }
        this.tvContent.setText(R.string.unknown);
    }

    public void updateStatus(PlaybackState playbackState) {
        int state = playbackState.getState();
        if (this.state != state) {
            if (state == 3) {
                this.imPlay.setImageResource(R.drawable.ic_pause);
            } else {
                this.imPlay.setImageResource(R.drawable.ic_play);
            }
            this.state = state;
        }
    }

    public void endMedia() {
        this.tvContent.setText(R.string.unknown);
        this.tvTitle.setText(R.string.unknown);
    }

    @Override
    public boolean onLongClick(ViewControlCenter viewControlCenter) {
        this.vClick = null;
        viewControlCenter.showBigMusic();
        return true;
    }

    @Override
    public void onClick() {
        super.onClick();
        action();
        this.vClick = null;
    }

    public void action() {
        View view = this.vClick;
        if (view == null) {
            return;
        }
        switch (view.getId()) {
            case 124:
                this.musicControlResult.onControlMedia(MyConst.DATA_PRE);
                return;
            case 125:
                this.musicControlResult.onControlMedia(MyConst.DATA_PLAY);
                return;
            case 126:
                this.musicControlResult.onControlMedia(MyConst.DATA_NEX);
                return;
            default:
                return;
        }
    }

    public void clearViewClick() {
        if (this.vClick != null) {
            this.vClick = null;
        }
    }
}
