package com.controlcenter.allphone.ioscontrolcenter.dialog;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.RatingBar;
import android.widget.TextView;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.util.ActionUtils;
import com.controlcenter.allphone.ioscontrolcenter.util.MyShare;


public class RateDialog extends Dialog {
    private RateResult rateResult;
    private float start;
    private TextView tvRate;

    
    public interface RateResult {
        void onEnd();
    }

    public RateDialog(Context context) {
        super(context, R.style.Theme_Dialog);
    }

    public RateDialog(Context context, RateResult rateResult) {
        super(context, R.style.Theme_Dialog);
        this.rateResult = rateResult;
    }

    @Override 
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.dialog_rate);
        ((RatingBar) findViewById(R.id.rate_bar)).setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public final void onRatingChanged(RatingBar ratingBar, float f, boolean z) {
                start = f;
                change();
            }
        });
        this.start = 5.0f;
        TextView textView = (TextView) findViewById(R.id.tv_create);
        this.tvRate = textView;
        textView.setOnClickListener(new View.OnClickListener() {
            @Override 
            public final void onClick(View view) {
                RateDialog.this.onClick(view);
            }
        });
        findViewById(R.id.tv_cancel).setOnClickListener(new View.OnClickListener() {
            @Override 
            public final void onClick(View view) {
                RateDialog.this.onClick(view);
            }
        });
        change();
    }


    private void change() {
        if (this.start < 4.0f) {
            this.tvRate.setText("Submit");
        } else {
            this.tvRate.setText("Submit");
        }
    }

    public void onClick(View view) {
        if (view.getId() == R.id.tv_create) {
            if (this.start < 4.0f) {
                feedback();
            } else {
                rate();
            }
        }
        cancel();
        if (this.rateResult != null) {
            new Handler().postDelayed(new Runnable() {
                @Override 
                public final void run() {
                    rateResult.onEnd();
                }
            }, 150L);
        }
    }
    private void feedback() {
        MyShare.rated(getContext());
        ActionUtils.feedback(getContext());
    }

    private void rate() {
        MyShare.rated(getContext());
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + getContext().getPackageName()));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            getContext().startActivity(intent);
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }
}
