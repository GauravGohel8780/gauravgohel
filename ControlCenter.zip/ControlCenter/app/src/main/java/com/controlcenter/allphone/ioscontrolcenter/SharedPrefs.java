package com.controlcenter.allphone.ioscontrolcenter;

import android.content.Context;
import android.content.SharedPreferences;


public class SharedPrefs {
    public static final String FirstTimeStartScreen = "FirstTimeStartScreen";
    public static final String IntroScreenActivity = "IntroScreenActivity";

    private static SharedPreferences mPreferences;

    private static SharedPreferences getInstance(Context context) {
        if (mPreferences == null) {
            mPreferences = context.getApplicationContext().getSharedPreferences("stat_data", 0);
        }
        return mPreferences;
    }

    public static void setFirstTimeStartScreen(Context context, boolean str) {
        getInstance(context).edit().putBoolean(FirstTimeStartScreen, str).apply();
    }

    public static boolean getFirstTimeStartScreen(Context context) {
        return getInstance(context).getBoolean(FirstTimeStartScreen, false);
    }

    public static void setIntroScreenActivity(Context context, boolean str) {
        getInstance(context).edit().putBoolean(IntroScreenActivity, str).apply();
    }

    public static boolean getIntroScreenActivity(Context context) {
        return getInstance(context).getBoolean(IntroScreenActivity, false);
    }

}
