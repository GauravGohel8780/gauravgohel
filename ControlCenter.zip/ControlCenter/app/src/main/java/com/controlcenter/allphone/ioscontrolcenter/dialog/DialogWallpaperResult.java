package com.controlcenter.allphone.ioscontrolcenter.dialog;


public interface DialogWallpaperResult {
    void onChangeWallpaper(int i);
}
