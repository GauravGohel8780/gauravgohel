package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.content.Context;
import android.os.Handler;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;


public class OnSwipeTouchListener implements View.OnTouchListener {
    private static final int TOUCH_OVER = 11;
    private float disX;
    private float disY;
    private boolean flagScroll;
    private boolean flagTapUp;
    private final GestureDetector gestureDetector;
    private float oldX;
    private float oldY;
    private VectorTouch status;
    private final TouchResult touchResult;
    private float value;
    private final int w;
    private final Runnable runnable = new Runnable() {
        @Override 
        public void run() {
            if (!OnSwipeTouchListener.this.flagTapUp) {
                OnSwipeTouchListener.this.flagTapUp = true;
                OnSwipeTouchListener.this.h.postDelayed(this, 250L);
                if (OnSwipeTouchListener.this.flagScroll) {
                    if (OnSwipeTouchListener.this.status == VectorTouch.VERTICAL) {
                        if (OnSwipeTouchListener.this.value > OnSwipeTouchListener.this.w / 4) {
                            OnSwipeTouchListener.this.touchResult.onSwipeBottom();
                            return;
                        } else if (OnSwipeTouchListener.this.value < (-OnSwipeTouchListener.this.w) / 4) {
                            OnSwipeTouchListener.this.touchResult.onSwipeUp();
                            return;
                        } else {
                            OnSwipeTouchListener.this.touchResult.onCancel();
                            return;
                        }
                    } else if (OnSwipeTouchListener.this.value > OnSwipeTouchListener.this.w / 2) {
                        OnSwipeTouchListener.this.touchResult.onSwipeRight();
                        return;
                    } else if (OnSwipeTouchListener.this.value < (-OnSwipeTouchListener.this.w) / 2) {
                        OnSwipeTouchListener.this.touchResult.onSwipeLeft();
                        return;
                    } else {
                        OnSwipeTouchListener.this.touchResult.onCancel();
                        return;
                    }
                }
                return;
            }
            OnSwipeTouchListener.this.touchResult.onTouchUp();
        }
    };
    private final Handler h = new Handler();

    
    public interface TouchResult {
        void onCancel();

        void onCancelTouch();

        void onClick();

        void onDoubleClick();

        void onLongClick();

        void onMoveHorizontal(float f);

        void onMoveVertical(float f);

        void onSwipeBottom();

        void onSwipeLeft();

        void onSwipeRight();

        void onSwipeUp();

        void onTouchUp();
    }

    
    enum VectorTouch {
        NULL,
        HORIZONTAL,
        VERTICAL
    }

    public OnSwipeTouchListener(Context context, TouchResult touchResult) {
        this.gestureDetector = new GestureDetector(context, new GestureListener());
        this.touchResult = touchResult;
        this.w = context.getResources().getDisplayMetrics().widthPixels;
    }

    @Override 
    public boolean onTouch(View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.flagTapUp = false;
            this.h.removeCallbacks(this.runnable);
            this.oldX = motionEvent.getRawX();
            this.oldY = motionEvent.getRawY();
            this.flagScroll = false;
            this.value = 0.0f;
        } else if (motionEvent.getAction() == 1) {
            this.h.postDelayed(this.runnable, 100L);
        } else if (motionEvent.getAction() == 2) {
            this.disX = motionEvent.getRawX() - this.oldX;
            this.disY = motionEvent.getRawY() - this.oldY;
            this.oldX = motionEvent.getRawX();
            this.oldY = motionEvent.getRawY();
        } else if (motionEvent.getAction() == 3) {
            this.touchResult.onCancelTouch();
        }
        this.gestureDetector.onTouchEvent(motionEvent);
        return true;
    }

    
    private final class GestureListener extends GestureDetector.SimpleOnGestureListener {
        private static final int SWIPE_THRESHOLD = 20;

        private GestureListener() {
        }

        @Override
        public boolean onDown(MotionEvent motionEvent) {
            OnSwipeTouchListener.this.status = VectorTouch.NULL;
            return true;
        }

        @Override
        public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
            if (OnSwipeTouchListener.this.status == VectorTouch.NULL) {
                OnSwipeTouchListener.this.flagScroll = true;
                float rawX = motionEvent2.getRawX() - motionEvent.getRawX();
                float rawY = motionEvent2.getRawY() - motionEvent.getRawY();
                if (Math.abs(rawX) > 11.0f || Math.abs(rawY) > 11.0f) {
                    if (Math.abs(rawY) > Math.abs(rawX)) {
                        OnSwipeTouchListener.this.status = VectorTouch.VERTICAL;
                    } else {
                        OnSwipeTouchListener.this.status = VectorTouch.HORIZONTAL;
                    }
                }
            } else if (OnSwipeTouchListener.this.status == VectorTouch.VERTICAL) {
                OnSwipeTouchListener.this.value = motionEvent2.getRawY() - motionEvent.getRawY();
                OnSwipeTouchListener.this.touchResult.onMoveVertical(OnSwipeTouchListener.this.value);
            } else {
                OnSwipeTouchListener.this.value = motionEvent2.getRawX() - motionEvent.getRawX();
                OnSwipeTouchListener.this.touchResult.onMoveHorizontal(OnSwipeTouchListener.this.value);
            }
            return super.onScroll(motionEvent, motionEvent2, f, f2);
        }

        @Override
        public void onLongPress(MotionEvent motionEvent) {
            super.onLongPress(motionEvent);
            OnSwipeTouchListener.this.touchResult.onLongClick();
        }

        @Override
        public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
            OnSwipeTouchListener.this.touchResult.onClick();
            return super.onSingleTapConfirmed(motionEvent);
        }

        @Override
        public boolean onDoubleTap(MotionEvent motionEvent) {
            OnSwipeTouchListener.this.touchResult.onDoubleClick();
            return super.onDoubleTap(motionEvent);
        }

        @Override
        public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
            OnSwipeTouchListener.this.flagScroll = false;
            if (OnSwipeTouchListener.this.status != VectorTouch.HORIZONTAL) {
                if (OnSwipeTouchListener.this.status != VectorTouch.VERTICAL) {
                    OnSwipeTouchListener.this.touchResult.onCancel();
                    return false;
                }
                float rawY = motionEvent2.getRawY() - motionEvent.getRawY();
                if (Math.abs(rawY) <= 20.0f) {
                    OnSwipeTouchListener.this.touchResult.onCancel();
                    return false;
                } else if (rawY > 0.0f) {
                    if (OnSwipeTouchListener.this.disY >= 0.0f) {
                        OnSwipeTouchListener.this.touchResult.onSwipeBottom();
                        return true;
                    }
                    OnSwipeTouchListener.this.touchResult.onCancel();
                    return true;
                } else if (OnSwipeTouchListener.this.disY <= 0.0f) {
                    OnSwipeTouchListener.this.touchResult.onSwipeUp();
                    return true;
                } else {
                    OnSwipeTouchListener.this.touchResult.onCancel();
                    return true;
                }
            }
            float rawX = motionEvent2.getRawX() - motionEvent.getRawX();
            if (Math.abs(rawX) <= 20.0f) {
                OnSwipeTouchListener.this.touchResult.onCancel();
                return false;
            } else if (rawX > 0.0f) {
                if (OnSwipeTouchListener.this.disX >= 0.0f) {
                    OnSwipeTouchListener.this.touchResult.onSwipeRight();
                    return true;
                }
                OnSwipeTouchListener.this.touchResult.onCancel();
                return true;
            } else if (OnSwipeTouchListener.this.disX <= 0.0f) {
                OnSwipeTouchListener.this.touchResult.onSwipeLeft();
                return true;
            } else {
                OnSwipeTouchListener.this.touchResult.onCancel();
                return true;
            }
        }
    }
}
