package com.controlcenter.allphone.ioscontrolcenter.item;


import com.google.gson.annotations.SerializedName;


public class ItemInt {
    @SerializedName("name")
    private String name;
    @SerializedName("value")
    private int value;

    public ItemInt(String str, int i) {
        this.name = str;
        this.value = i;
    }

    public String getName() {
        return this.name;
    }

    public int getValue() {
        return this.value;
    }
}
