package com.controlcenter.allphone.ioscontrolcenter.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;

import androidx.recyclerview.widget.RecyclerView;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemInt;

import java.util.ArrayList;


public class AdapterVideoConfig extends RecyclerView.Adapter<AdapterVideoConfig.Holder> {
    private final AdapterVideoResult adapterVideoResult;
    private final ArrayList<ItemInt> arr;
    private final int value;


    public interface AdapterVideoResult {
        void onItemClick(int i);
    }

    public AdapterVideoConfig(int i, ArrayList<ItemInt> arrayList, AdapterVideoResult adapterVideoResult) {
        this.value = i;
        this.arr = arrayList;
        this.adapterVideoResult = adapterVideoResult;
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_video_config, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(Holder holder, int i) {
        holder.rb.setText(this.arr.get(i).getName());
        holder.rb.setChecked(this.arr.get(i).getValue() == this.value);
    }

    @Override
    public int getItemCount() {
        return this.arr.size();
    }


    public class Holder extends RecyclerView.ViewHolder {
        RadioButton rb;

        Holder(View view) {
            super(view);
            RadioButton radioButton = (RadioButton) view.findViewById(R.id.rb);
            this.rb = radioButton;
            radioButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public final void onClick(View view2) {
                    AdapterVideoConfig.this.adapterVideoResult.onItemClick(((ItemInt) AdapterVideoConfig.this.arr.get(getLayoutPosition())).getValue());
                }
            });
        }

    }
}
