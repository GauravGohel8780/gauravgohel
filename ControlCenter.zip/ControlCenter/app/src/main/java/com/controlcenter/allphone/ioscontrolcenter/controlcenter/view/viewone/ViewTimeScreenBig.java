package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewone;

import android.content.Context;
import android.graphics.Color;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;

import com.controlcenter.allphone.ioscontrolcenter.custom.TextB;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ViewTimeScreenBig extends LinearLayout implements View.OnClickListener {
    private final TextB tv1;
    private final TextB tv10;
    private final TextB tv15;
    private final TextB tv2;
    private final TextB tv3;
    private final TextB tv30;
    private final TextB tv5;
    private ViewTimeScreen viewTime;

    public void setViewTime(ViewTimeScreen viewTimeScreen) {
        this.viewTime = viewTimeScreen;
    }

    public ViewTimeScreenBig(Context context) {
        super(context);
        setOrientation(LinearLayout.VERTICAL);
        this.tv15 = makeTv(15, "15s");
        this.tv30 = makeTv(30, "30s");
        this.tv1 = makeTv(1, "1m");
        this.tv2 = makeTv(2, "2m");
        this.tv5 = makeTv(5, "5m");
        this.tv10 = makeTv(10, "10m");
        this.tv3 = makeTv(3, "30m");
    }

    public void updateTime() {
        float widthScreen = (OtherUtils.getWidthScreen(getContext()) * 22.0f) / 100.0f;
        this.tv15.setBackground(OtherUtils.bgIcon(Color.parseColor("#70000000"), widthScreen));
        this.tv30.setBackground(OtherUtils.bgIcon(Color.parseColor("#70000000"), widthScreen));
        this.tv1.setBackground(OtherUtils.bgIcon(Color.parseColor("#70000000"), widthScreen));
        this.tv2.setBackground(OtherUtils.bgIcon(Color.parseColor("#70000000"), widthScreen));
        this.tv10.setBackground(OtherUtils.bgIcon(Color.parseColor("#70000000"), widthScreen));
        this.tv5.setBackground(OtherUtils.bgIcon(Color.parseColor("#70000000"), widthScreen));
        this.tv3.setBackground(OtherUtils.bgIcon(Color.parseColor("#70000000"), widthScreen));
        int i = Settings.System.getInt(getContext().getContentResolver(), "screen_off_timeout", 30000) / 1000;
        if (i < 20) {
            this.tv15.setBackground(OtherUtils.bgIcon(Color.parseColor("#70ffffff"), widthScreen));
        } else if (i < 40) {
            this.tv30.setBackground(OtherUtils.bgIcon(Color.parseColor("#70ffffff"), widthScreen));
        } else if (i < 70) {
            this.tv1.setBackground(OtherUtils.bgIcon(Color.parseColor("#70ffffff"), widthScreen));
        } else if (i < 150) {
            this.tv2.setBackground(OtherUtils.bgIcon(Color.parseColor("#70ffffff"), widthScreen));
        } else if (i < 350) {
            this.tv5.setBackground(OtherUtils.bgIcon(Color.parseColor("#70ffffff"), widthScreen));
        } else if (i < 650) {
            this.tv10.setBackground(OtherUtils.bgIcon(Color.parseColor("#70ffffff"), widthScreen));
        } else {
            this.tv3.setBackground(OtherUtils.bgIcon(Color.parseColor("#70ffffff"), widthScreen));
        }
    }

    private TextB makeTv(int i, String str) {
        int widthScreen = OtherUtils.getWidthScreen(getContext());
        int i2 = (widthScreen * 12) / 100;
        TextB textB = new TextB(getContext());
        textB.setText(str);
        textB.setId(i);
        float f = widthScreen;
        textB.setTextSize(0, (3.7f * f) / 100.0f);
        textB.setGravity(17);
        textB.setTextColor(-1);
        textB.setBackground(OtherUtils.bgIcon(Color.parseColor("#70000000"), (22.0f * f) / 100.0f));
        textB.setOnClickListener(this);
        LayoutParams layoutParams = new LayoutParams(i2 * 6, i2);
        layoutParams.setMargins(0, widthScreen / 50, 0, 0);
        addView(textB, layoutParams);
        return textB;
    }

    @Override 
    public void onClick(View view) {
        int i;
        if (view == this.tv30) {
            i = 30000;
        } else if (view == this.tv1) {
            i = 60000;
        } else if (view == this.tv2) {
            i = 120000;
        } else if (view == this.tv10) {
            i = 600000;
        } else if (view == this.tv3) {
            i = 1800000;
        } else {
            i = view == this.tv5 ? 300000 : 15000;
        }
        Settings.System.putInt(getContext().getContentResolver(), "screen_off_timeout", i);
        updateTime();
        this.viewTime.updateTime();
    }
}
