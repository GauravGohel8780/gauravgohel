package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemIcon;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class LayoutCustomControl extends LinearLayout {
    private ImageView imAction;
    private ImageView imDrag;
    private ImageView imIcon;
    private LayoutClick layoutClick;
    private TextM tvLabel;

    public LayoutCustomControl(Context context) {
        super(context);
        init();
    }

    public LayoutCustomControl(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init();
    }

    public LayoutCustomControl(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init();
    }

    public void setLayoutClick(LayoutClick layoutClick) {
        this.layoutClick = layoutClick;
    }

    private void init() {
        setOrientation(LinearLayout.HORIZONTAL);
        setGravity(16);
        int i = getResources().getDisplayMetrics().widthPixels;
        int i2 = (i * 4) / 100;
        int i3 = (i * 15) / 100;
        ImageView imageView = new ImageView(getContext());
        this.imAction = imageView;
        imageView.setPadding(i2, i2, i2, i2);
        addView(this.imAction, i3, i3);
        int i4 = (i * 10) / 100;
        ImageView imageView2 = new ImageView(getContext());
        this.imIcon = imageView2;
        imageView2.setBackground(OtherUtils.bgIcon(Color.parseColor("#70000000"), i2 * 2));
        int i5 = i2 / 2;
        this.imIcon.setPadding(i5, i5, i5, i5);
        addView(this.imIcon, i4, i4);
        TextM textM = new TextM(getContext());
        this.tvLabel = textM;
        textM.setPadding(i2, 0, i2, 0);
        this.tvLabel.setTextSize(0, (i * 3.5f) / 100.0f);
        this.tvLabel.setTextColor(Color.parseColor("#17222a"));
        this.tvLabel.setSingleLine();
        this.tvLabel.setEllipsize(TextUtils.TruncateAt.END);
        addView(this.tvLabel, new LayoutParams(0, -2, 1.0f));
        ImageView imageView3 = new ImageView(getContext());
        this.imDrag = imageView3;
        imageView3.setImageResource(R.drawable.ic_menu);
        addView(this.imDrag, i4, i4);
        this.imAction.setOnClickListener(new OnClickListener() {
            @Override 
            public final void onClick(View view) {
                LayoutCustomControl.this.m62xb40af2b(view);
            }
        });
    }

    public void m62xb40af2b(View view) {
        this.layoutClick.onActionClick(this);
    }

    public void setApp(ItemIcon itemIcon) {
        Drawable drawable = itemIcon.icon;
        if (drawable != null) {
            this.imIcon.setImageDrawable(drawable);
        } else {
            this.imIcon.setImageResource(itemIcon.image);
        }
        this.tvLabel.setText(itemIcon.label);
    }

    public void setImAction(boolean z) {
        if (z) {
            this.imAction.setImageResource(R.drawable.ic_add_round);
            this.imDrag.setVisibility(View.GONE);
            return;
        }
        this.imAction.setImageResource(R.drawable.ic_remove_app_hide);
        this.imDrag.setVisibility(View.VISIBLE);
    }
}
