package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewone;

import android.content.Context;
import android.widget.ImageView;

import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.BaseViewControl;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class BaseViewOne extends BaseViewControl {
    final ImageView image;

    public BaseViewOne(Context context) {
        super(context);
        int widthScreen = (int) ((OtherUtils.getWidthScreen(context) * 4.4f) / 100.0f);
        ImageView imageView = new ImageView(context);
        this.image = imageView;
        imageView.setPadding(widthScreen, widthScreen, widthScreen, widthScreen);
        addView(imageView, -1, -1);
    }
}
