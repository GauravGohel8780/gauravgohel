package com.controlcenter.allphone.ioscontrolcenter.location;

import android.content.Intent;
import android.os.Bundle;

import com.controlcenter.allphone.ioscontrolcenter.BaseActivity;
import com.controlcenter.allphone.ioscontrolcenter.custom.MyScrollView;
import com.controlcenter.allphone.ioscontrolcenter.service.ServiceControl;
import com.controlcenter.allphone.ioscontrolcenter.util.MyConst;

import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;


public class ActivityLocation extends BaseActivity {
    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        MyScrollView myScrollView = new MyScrollView(this);
        myScrollView.setFillViewport(true);
        myScrollView.setVerticalScrollBarEnabled(false);
        OverScrollDecoratorHelper.setUpOverScroll(myScrollView);
        ViewLocationSetup viewLocationSetup = new ViewLocationSetup(this);
        viewLocationSetup.setSv(myScrollView);
        myScrollView.addView(viewLocationSetup, -1, -1);
        setContentView(myScrollView);
    }

    @Override
    public void onResume() {
        super.onResume();
        Intent intent = new Intent(this, ServiceControl.class);
        intent.putExtra(MyConst.DATA_ID_NOTIFICATION, 18);
        startService(intent);
    }

    @Override
    public void onPause() {
        super.onPause();
        Intent intent = new Intent(this, ServiceControl.class);
        intent.putExtra(MyConst.DATA_ID_NOTIFICATION, 19);
        startService(intent);
    }
}
