package com.controlcenter.allphone.ioscontrolcenter.item;

import com.google.gson.annotations.SerializedName;


public class ItemControl {
    @SerializedName("className")
    public String className;
    @SerializedName("pkg")
    public String pkg;
    @SerializedName("type")
    public int type;

    public ItemControl() {
    }

    public ItemControl(int i) {
        this.type = i;
    }

    public ItemControl(int i, String str, String str2) {
        this.type = i;
        this.pkg = str;
        this.className = str2;
    }
}
