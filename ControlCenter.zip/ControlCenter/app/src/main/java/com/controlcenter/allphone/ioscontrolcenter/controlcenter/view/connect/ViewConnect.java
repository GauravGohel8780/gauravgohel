package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.connect;

import android.content.Context;
import android.graphics.Color;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.ViewControlCenter;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.BaseViewControl;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ViewConnect extends BaseViewControl {
    private ConnectClickResult connectClickResult;
    private final ImageView imAir;
    private final ImageView imBlu;
    private final ImageView imData;
    private final ImageView imWifi;
    private View vTouch;

    public void setConnectClickResult(ConnectClickResult connectClickResult) {
        this.connectClickResult = connectClickResult;
    }

    public ViewConnect(Context context) {
        super(context);
        int widthScreen = OtherUtils.getWidthScreen(context);
        int i = (widthScreen * 14) / 100;
        int i2 = widthScreen / 25;
        int i3 = widthScreen / 110;
        ImageView imageView = new ImageView(context);
        this.imAir = imageView;
        imageView.setPadding(i3, i3, i3, i3);
        imageView.setImageResource(R.drawable.ic_airplan);
        imageView.setId(123);
        OnTouchListener onTouchListener = new OnTouchListener() {
            @Override 
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                return ViewConnect.this.m46x6abfac50(view, motionEvent);
            }
        };
        imageView.setOnTouchListener(onTouchListener);
        LayoutParams layoutParams = new LayoutParams(i, i);
        layoutParams.setMargins(i2, i2, i2, i2);
        addView(imageView, layoutParams);
        ImageView imageView2 = new ImageView(context);
        this.imData = imageView2;
        imageView2.setPadding(i3, i3, i3, i3);
        imageView2.setId(124);
        imageView2.setImageResource(R.drawable.ic_data);
        imageView2.setOnTouchListener(onTouchListener);
        LayoutParams layoutParams2 = new LayoutParams(i, i);
        layoutParams2.addRule(17, imageView.getId());
        layoutParams2.addRule(6, imageView.getId());
        addView(imageView2, layoutParams2);
        ImageView imageView3 = new ImageView(context);
        this.imBlu = imageView3;
        imageView3.setPadding(i3, i3, i3, i3);
        imageView3.setId(125);
        imageView3.setImageResource(R.drawable.ic_bluetooth);
        imageView3.setOnTouchListener(onTouchListener);
        LayoutParams layoutParams3 = new LayoutParams(i, i);
        layoutParams3.addRule(17, imageView.getId());
        layoutParams3.addRule(3, imageView.getId());
        addView(imageView3, layoutParams3);
        ImageView imageView4 = new ImageView(context);
        this.imWifi = imageView4;
        imageView4.setId(126);
        imageView4.setPadding(i3, i3, i3, i3);
        imageView4.setImageResource(R.drawable.ic_wifi);
        imageView4.setOnTouchListener(onTouchListener);
        LayoutParams layoutParams4 = new LayoutParams(i, i);
        layoutParams4.addRule(3, imageView.getId());
        layoutParams4.addRule(18, imageView.getId());
        addView(imageView4, layoutParams4);
        setStatusImage(imageView, false, -1);
        setStatusImage(imageView2, false, -1);
        setStatusImage(imageView3, false, -1);
        setStatusImage(imageView4, false, -1);
    }

    public boolean m46x6abfac50(View view, MotionEvent motionEvent) {
        this.vTouch = view;
        return false;
    }

    private void setStatusImage(ImageView imageView, boolean z, int i) {
        if (z) {
            imageView.setBackground(OtherUtils.makeOval(i));
        } else {
            imageView.setBackground(OtherUtils.makeOval(Color.parseColor("#30ffffff")));
        }
    }

    public void updateAir(boolean z) {
        setStatusImage(this.imAir, z, Color.parseColor("#FCD04E"));
    }

    public void updateData(boolean z) {
        setStatusImage(this.imData, z, Color.parseColor("#3bc551"));
    }

    public void updateBlu(boolean z) {
        setStatusImage(this.imBlu, z, Color.parseColor("#3478f6"));
    }

    public void updateWifi(boolean z) {
        setStatusImage(this.imWifi, z, Color.parseColor("#3478f6"));
    }

    @Override
    public void onClick() {
        super.onClick();
        View view = this.vTouch;
        if (view == null) {
            return;
        }
        if (view == this.imAir) {
            this.connectClickResult.onAirClick();
        } else if (view == this.imData) {
            this.connectClickResult.onDataClick();
        } else if (view == this.imWifi) {
            this.connectClickResult.onWifiClick();
        } else if (view == this.imBlu) {
            this.connectClickResult.onBlueClick();
        }
        this.vTouch = null;
    }

    public void resetViewTouch() {
        if (this.vTouch != null) {
            this.vTouch = null;
        }
    }

    @Override
    public boolean onLongClick(ViewControlCenter viewControlCenter) {
        resetViewTouch();
        viewControlCenter.showBigViewConnect();
        return true;
    }
}
