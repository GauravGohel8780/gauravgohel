package com.controlcenter.allphone.ioscontrolcenter.controlcenter.custom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;


public class ViewWaveMobile extends View {
    private final Paint paint;
    private final RectF rectF;
    private int status;

    public ViewWaveMobile(Context context) {
        super(context);
        Paint paint = new Paint(1);
        this.paint = paint;
        paint.setColor(-1);
        this.rectF = new RectF();
        this.status = 2;
    }

    public void setStatus(int i) {
        this.status = i;
        invalidate();
    }

    @Override 
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float width = getWidth() / 19.0f;
        for (int i = 0; i < 4; i++) {
            if (i < this.status) {
                this.paint.setAlpha(255);
            } else {
                this.paint.setAlpha(65);
            }
            if (i == 0) {
                this.rectF.set(0.0f, (getHeight() * 61.5f) / 100.0f, (getWidth() * 17.7f) / 100.0f, getHeight());
            } else if (i == 1) {
                this.rectF.set((getWidth() * 27.4f) / 100.0f, (getHeight() * 46.2f) / 100.0f, (getWidth() * 45.2f) / 100.0f, getHeight());
            } else if (i != 2) {
                this.rectF.set((getWidth() * 82.3f) / 100.0f, 0.0f, getWidth(), getHeight());
            } else {
                this.rectF.set((getWidth() * 54.8f) / 100.0f, (getHeight() * 23.1f) / 100.0f, (getWidth() * 72.6f) / 100.0f, getHeight());
            }
            canvas.drawRoundRect(this.rectF, width, width, this.paint);
        }
    }
}
