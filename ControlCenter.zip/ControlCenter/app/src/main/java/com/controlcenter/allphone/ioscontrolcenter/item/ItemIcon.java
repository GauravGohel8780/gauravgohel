package com.controlcenter.allphone.ioscontrolcenter.item;

import android.content.Context;
import android.graphics.drawable.Drawable;

import com.controlcenter.allphone.ioscontrolcenter.R;


public class ItemIcon {
    public String className;
    public Drawable icon;
    public int image;
    public String label;
    public String pkg;
    public int type;

    public ItemIcon(String str, String str2, String str3, Drawable drawable) {
        this.type = -1;
        this.pkg = str;
        this.className = str2;
        this.label = str3;
        this.icon = drawable;
    }

    public ItemIcon(int i, Context context) {
        this.type = i;
        switch (i) {
            case 1:
                this.label = context.getString(R.string.flashlight);
                this.image = R.drawable.ic_flash;
                return;
            case 2:
                this.label = context.getString(R.string.clock);
                this.image = R.drawable.ic_timer;
                return;
            case 3:
                this.label = context.getString(R.string.calculator);
                this.image = R.drawable.ic_calculator;
                return;
            case 4:
                this.label = context.getString(R.string.camera);
                this.image = R.drawable.ic_camera_while;
                return;
            case 5:
                this.label = context.getString(R.string.screen_record);
                this.image = R.drawable.ic_screen_record_all;
                return;
            case 6:
                this.label = context.getString(R.string.screenshot);
                this.image = R.drawable.ic_screenshot;
                return;
            case 7:
                this.label = context.getString(R.string.battery);
                this.image = R.drawable.ic_battery;
                return;
            case 8:
                this.label = context.getString(R.string.voice_record);
                this.image = R.drawable.ic_voice_control;
                return;
            default:
                this.label = context.getString(R.string.setting_d);
                this.image = R.drawable.ic_setting_control;
                return;
        }
    }
}
