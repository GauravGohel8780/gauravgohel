package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.core.view.ViewCompat;

import com.controlcenter.allphone.ioscontrolcenter.R;


public class ViewPolicy extends LinearLayout {
    private CheckBox cb;
    private PolicyResult policyResult;
    private TextView tvOk;

    
    public interface PolicyResult {
        void onCancel();

        void onOk();
    }

    public static void lambda$init$1(View view) {
    }

    public void setPolicyResult(PolicyResult policyResult) {
        this.policyResult = policyResult;
    }

    public ViewPolicy(Context context) {
        super(context);
        init();
    }

    public ViewPolicy(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init();
    }

    public ViewPolicy(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init();
    }

    private void init() {
        setOrientation(LinearLayout.VERTICAL);
        setGravity(17);
        setBackgroundColor(Color.parseColor("#58000000"));
        setOnClickListener(new OnClickListener() {
            @Override 
            public final void onClick(View view) {
                policyResult.onCancel();
            }
        });
        int i = getResources().getDisplayMetrics().widthPixels;
        LinearLayout linearLayout = new LinearLayout(getContext());
        linearLayout.setBackgroundResource(R.drawable.bg_layout_policy);
        linearLayout.setOnClickListener(new OnClickListener() {
            @Override 
            public final void onClick(View view) {
                ViewPolicy.lambda$init$1(view);
            }
        });
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        LayoutParams layoutParams = new LayoutParams(-1, -2);
        int i2 = i / 19;
        layoutParams.setMargins(i2, 0, i2, 0);
        addView(linearLayout, layoutParams);
        TextView textView = new TextView(getContext());
        textView.setTextColor(Color.parseColor("#158FE1"));
        textView.setText(R.string.terms_of_service);
        float f = i;
        textView.setTextSize(0, (5.0f * f) / 100.0f);
        int i3 = i / 25;
        int i4 = i / 30;
        textView.setPadding(i3, i4, 0, i4);
        linearLayout.addView(textView, -2, -2);
        View view = new View(getContext());
        view.setBackgroundColor(Color.parseColor("#aaaaaa"));
        linearLayout.addView(view, -1, 2);
        ScrollView scrollView = new ScrollView(getContext());
        linearLayout.addView(scrollView, new LayoutParams(-1, 0, 1.0f));
        TextView textView2 = new TextView(getContext());
        textView2.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        float f2 = (4.5f * f) / 100.0f;
        textView2.setTextSize(0, f2);
        textView2.setPadding(i3, i3, i3, i / 50);
        textView2.setText(R.string.content_policy_dialog);
        scrollView.addView(textView2, -1, -1);
        CheckBox checkBox = new CheckBox(getContext());
        this.cb = checkBox;
        checkBox.setText(R.string.tv_cb_policy);
        this.cb.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        this.cb.setTextSize(0, (3.9f * f) / 100.0f);
        int i5 = i / 40;
        this.cb.setPadding(i5, i5, i5, i5);
        linearLayout.addView(this.cb, -1, -2);
        this.cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (z) {
                    tvOk.setTextColor(Color.parseColor("#158FE1"));
                } else {
                    tvOk.setTextColor(Color.parseColor("#60555555"));
                }
            }
        });
        View view2 = new View(getContext());
        view2.setBackgroundColor(Color.parseColor("#aaaaaa"));
        linearLayout.addView(view2, -1, 2);
        LinearLayout linearLayout2 = new LinearLayout(getContext());
        linearLayout2.setOrientation(LinearLayout.HORIZONTAL);
        linearLayout.addView(linearLayout2, -1, i / 7);
        TextView textView3 = new TextView(getContext());
        textView3.setGravity(17);
        textView3.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        textView3.setText(R.string.decline);
        textView3.setOnClickListener(new OnClickListener() {
            @Override 
            public final void onClick(View view3) {
                policyResult.onCancel();
            }
        });
        textView3.setTextSize(0, f2);
        linearLayout2.addView(textView3, new LayoutParams(0, -1, 1.0f));
        View view3 = new View(getContext());
        view3.setBackgroundColor(Color.parseColor("#aaaaaa"));
        linearLayout2.addView(view3, 2, -1);
        TextView textView4 = new TextView(getContext());
        this.tvOk = textView4;
        textView4.setGravity(17);
        this.tvOk.setTextColor(Color.parseColor("#60555555"));
        this.tvOk.setTextSize(0, f2);
        this.tvOk.setText(R.string.accept);
        linearLayout2.addView(this.tvOk, new LayoutParams(0, -1, 1.0f));
        this.tvOk.setOnClickListener(new OnClickListener() {
            @Override 
            public final void onClick(View view4) {
                if (cb.isChecked()) {
                    policyResult.onOk();
                }
            }
        });
    }

    public void show() {
        this.cb.setChecked(false);
    }
}
