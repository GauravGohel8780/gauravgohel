package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewone;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.TransitionDrawable;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ViewFlash extends ViewOneChange {
    private final TransitionDrawable transition;

    public ViewFlash(Context context) {
        super(context);
        float widthScreen = (OtherUtils.getWidthScreen(getContext()) * 22) / 100;
        TransitionDrawable transitionDrawable = new TransitionDrawable(new Drawable[]{OtherUtils.bgIcon(Color.parseColor("#70000000"), widthScreen), OtherUtils.bgIcon(Color.parseColor("#c3ffffff"), widthScreen)});
        this.transition = transitionDrawable;
        setBackground(transitionDrawable);
    }

    public void updateFlash(boolean z) {
        if (z) {
            this.image.setImageResource(R.drawable.ic_flash_on);
            this.transition.startTransition(300);
            return;
        }
        this.image.setImageResource(R.drawable.ic_flash);
        this.transition.reverseTransition(300);
    }
}
