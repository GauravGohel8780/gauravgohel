package com.controlcenter.allphone.ioscontrolcenter;

import android.content.Context;
import android.graphics.Point;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;

import com.controlcenter.allphone.ioscontrolcenter.custom.ViewPolicy;
import com.controlcenter.allphone.ioscontrolcenter.util.ActionUtils;
import com.controlcenter.allphone.ioscontrolcenter.util.MyConst;
import com.controlcenter.allphone.ioscontrolcenter.util.MyShare;


public class ActivityPolicy extends AppCompatActivity {
    private ViewPolicy viewPolicy;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(67108864);
        int i = Build.VERSION.SDK_INT;
        int i2 = i >= 23 ? 9984 : 1792;
        if (i >= 26) {
            i2 |= 16;
        }
        window.getDecorView().setSystemUiVisibility(i2);
        window.setNavigationBarColor(-1);
        window.setStatusBarColor(-1);
        setContentView(R.layout.activity_policy);
        findViewById(R.id.tv_policy).setOnClickListener(new View.OnClickListener() {
            @Override 
            public final void onClick(View view) {
                ActionUtils.openLink(ActivityPolicy.this, MyConst.LINK_POLICY);
            }
        });
        findViewById(R.id.tv_ok).setOnClickListener(new View.OnClickListener() {
            @Override 
            public final void onClick(View view) {
                ActivityPolicy.this.onClick(view);
            }
        });
        ViewPolicy viewPolicy = (ViewPolicy) findViewById(R.id.dialog_policy);
        this.viewPolicy = viewPolicy;
        viewPolicy.setAlpha(0.0f);
        this.viewPolicy.setPolicyResult(new cliclView());
        setResult(0);
    }


    
    public class cliclView implements ViewPolicy.PolicyResult {
        cliclView() {
        }


        @Override
        public void onCancel() {
            ActivityPolicy.this.viewPolicy.animate().alpha(0.0f).setDuration(300L).withEndAction(new Runnable() {
                @Override 
                public final void run() {
                    ActivityPolicy.this.viewPolicy.setVisibility(View.GONE);
                }
            }).start();
        }

        @Override
        public void onOk() {
            Point point = new Point();
            ((WindowManager) ActivityPolicy.this.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRealSize(point);
            MyShare.putSize(ActivityPolicy.this, new int[]{point.x, point.y, 0});
            MyShare.applyPolicy(ActivityPolicy.this);
            ActivityPolicy.this.setResult(-1);
            ActivityPolicy.this.finish();
        }
    }

    public void onClick(View view) {
        if (this.viewPolicy.getVisibility() == View.GONE) {
            this.viewPolicy.show();
            this.viewPolicy.setVisibility(View.VISIBLE);
            this.viewPolicy.animate().alpha(1.0f).setDuration(300L).withEndAction(null).start();
        }
    }
}
