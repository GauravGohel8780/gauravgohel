package com.controlcenter.allphone.ioscontrolcenter.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;

import com.controlcenter.allphone.ioscontrolcenter.item.ItemControl;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemVideoConfig;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.Calendar;


public class MyShare {
    private static SharedPreferences getShare(Context context) {
        return context.getSharedPreferences("sharedpreferences", 0);
    }

    public static void applyPolicy(Context context) {
        getShare(context).edit().putBoolean("apply_policy", true).apply();
    }

    public static boolean isApplyPolicy(Context context) {
        return getShare(context).getBoolean("apply_policy", false);
    }

    public static void putEnableControlCenter(Context context, boolean z) {
        getShare(context).edit().putBoolean("ena_control_center", z).apply();
    }

    public static boolean enableControlCenter(Context context) {
        return getShare(context).getBoolean("ena_control_center", false);
    }

    public static void putOrientation(Context context, int i) {
        getShare(context).edit().putInt("orientation_view", i).apply();
    }

    public static int getOrientation(Context context) {
        return getShare(context).getInt("orientation_view", 1);
    }

    public static void putLocation(Context context, int i) {
        getShare(context).edit().putInt("location_view", i).apply();
    }

    public static int getLocation(Context context) {
        return getShare(context).getInt("location_view", 50);
    }

    public static void putEnableBlur(Context context, boolean z) {
        getShare(context).edit().putBoolean("ena_blur", z).apply();
    }

    public static boolean enableBlur(Context context) {
        return getShare(context).getBoolean("ena_blur", true);
    }

    public static void putEnaNightShift(Context context, boolean z) {
        getShare(context).edit().putBoolean("night_shift", z).apply();
    }

    public static boolean getEnaNightShift(Context context) {
        return getShare(context).getBoolean("night_shift", false);
    }

    public static void putScheduled(Context context, boolean z) {
        getShare(context).edit().putBoolean("scheduled", z).apply();
    }

    public static boolean getScheduled(Context context) {
        return getShare(context).getBoolean("scheduled", false);
    }

    public static void putTimeFrom(Context context, long j) {
        getShare(context).edit().putLong("time_from", j).apply();
    }

    public static void putTimeTo(Context context, long j) {
        getShare(context).edit().putLong("time_to", j).apply();
    }

    public static long getTimeFrom(Context context) {
        long j = getShare(context).getLong("time_from", -1L);
        if (j == -1) {
            Calendar calendar = Calendar.getInstance();
            calendar.set(2021, 10, 30, 22, 0);
            return calendar.getTimeInMillis();
        }
        return j;
    }

    public static long getTimeTo(Context context) {
        long j = getShare(context).getLong("time_to", -1L);
        if (j == -1) {
            Calendar calendar = Calendar.getInstance();
            calendar.set(2021, 10, 30, 7, 0);
            return calendar.getTimeInMillis();
        }
        return j;
    }

    public static boolean checkScheduled(Context context) {
        if (getScheduled(context)) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(getTimeFrom(context));
            Calendar calendar2 = Calendar.getInstance();
            calendar2.set(11, calendar.get(11));
            calendar2.set(12, calendar.get(12));
            long timeInMillis = calendar2.getTimeInMillis();
            calendar.setTimeInMillis(getTimeTo(context));
            calendar2.set(11, calendar.get(11));
            calendar2.set(12, calendar.get(12));
            return timeInMillis <= System.currentTimeMillis() || calendar2.getTimeInMillis() > System.currentTimeMillis();
        }
        return false;
    }

    public static void putColorNightShift(Context context, int i) {
        getShare(context).edit().putInt("color_night_shift", i).apply();
    }

    public static int getColorNightShift(Context context) {
        return getShare(context).getInt("color_night_shift", Color.parseColor("#40ffd925"));
    }

    public static void putVibrationControl(Context context, boolean z) {
        getShare(context).edit().putBoolean("vibration_control", z).apply();
    }

    public static boolean vibrationControl(Context context) {
        return getShare(context).getBoolean("vibration_control", false);
    }

    public static void putColorNotification(Context context, int i) {
        getShare(context).edit().putInt("color_notification", i).apply();
    }

    public static void putWidthNotification(Context context, int i) {
        getShare(context).edit().putInt("width_notification", i).apply();
    }

    public static void putHeightNotification(Context context, int i) {
        getShare(context).edit().putInt("height_notification", i).apply();
    }

    public static int[] getSizeNotification(Context context) {
        return new int[]{getShare(context).getInt("width_notification", OtherUtils.getWidthScreen(context) / 5), getShare(context).getInt("height_notification", OtherUtils.getWidthScreen(context) / 20), getShare(context).getInt("color_notification", Color.parseColor("#50000000"))};
    }

    public static int getColorNotification(Context context) {
        return getShare(context).getInt("color_notification", Color.parseColor("#50000000"));
    }

    public static void putArrControl(Context context, ArrayList<ItemControl> arrayList) {
        getShare(context).edit().putString("arr_control", new Gson().toJson(arrayList)).apply();
    }

    public static ArrayList<ItemControl> getArrControl(Context context) {
        String string = getShare(context).getString("arr_control", "null");
        if (string.isEmpty()) {
            return null;
        }
        if (string.equals("null")) {
            return arrDefault();
        }
        return (ArrayList) new Gson().fromJson(string, new TypeToken<ArrayList<ItemControl>>() { // from class: com.controlcenter.allphone.ioscontrolcenter.util.MyShare.1
        }.getType());
    }

    public static ArrayList<ItemControl> arrDefault() {
        ArrayList<ItemControl> arrayList = new ArrayList<>();
        arrayList.add(new ItemControl(1));
        arrayList.add(new ItemControl(2));
        arrayList.add(new ItemControl(3));
        arrayList.add(new ItemControl(4));
        arrayList.add(new ItemControl(5));
        arrayList.add(new ItemControl(6));
        arrayList.add(new ItemControl(7));
        arrayList.add(new ItemControl(8));
        arrayList.add(new ItemControl(9));
        return arrayList;
    }

    public static void putRecord(Context context, ItemVideoConfig itemVideoConfig) {
        getShare(context).edit().putString("record", new Gson().toJson(itemVideoConfig)).apply();
    }

    public static ItemVideoConfig getRecord(Context context) {
        String string = getShare(context).getString("record", "");
        if (!string.isEmpty()) {
            return (ItemVideoConfig) new Gson().fromJson(string, new TypeToken<ItemVideoConfig>() { // from class: com.controlcenter.allphone.ioscontrolcenter.util.MyShare.2
            }.getType());
        }
        return new ItemVideoConfig(false, 1, true, 2500000, 30, 1, 16000, 160000);
    }

    public static void putSize(Context context, int[] iArr) {
        if (iArr[0] != 0) {
            getShare(context).edit().putInt("width_s", iArr[0]).apply();
        }
        if (iArr[1] != 0) {
            getShare(context).edit().putInt("height_s", iArr[1]).apply();
        }
        if (iArr[2] != 0) {
            getShare(context).edit().putInt("noti_s", iArr[2]).apply();
        }
    }

    public static int[] getSizes(Context context) {
        return new int[]{getShare(context).getInt("width_s", 0), getShare(context).getInt("height_s", 0), getShare(context).getInt("noti_s", 0)};
    }

    public static void putStatusWallpaper(Context context, int i) {
        getShare(context).edit().putInt("wallpaper_ct", i).apply();
    }

    public static int getStatusWallpaper(Context context) {
        return getShare(context).getInt("wallpaper_ct", 1);
    }

    public static void putWallpaper(Context context, String str) {
        getShare(context).edit().putString("wallpaper_gallery", str).apply();
    }

    public static String getWallpaper(Context context) {
        return getShare(context).getString("wallpaper_gallery", "");
    }

    public static void putSingleTap(Context context, int i) {
        getShare(context).edit().putInt("single_tap", i).apply();
    }

    public static void putDoubleTap(Context context, int i) {
        getShare(context).edit().putInt("double_tap", i).apply();
    }

    public static void putLongPress(Context context, int i) {
        getShare(context).edit().putInt("long_press", i).apply();
    }

    public static int getSingleTap(Context context) {
        return getShare(context).getInt("single_tap", 0);
    }

    public static int getDoubleTap(Context context) {
        return getShare(context).getInt("double_tap", 0);
    }

    public static int getLongPress(Context context) {
        return getShare(context).getInt("long_press", 0);
    }

    public static boolean isRate(Context context) {
        return getShare(context).getBoolean("is_rate_app", false);
    }

    public static void rated(Context context) {
        getShare(context).edit().putBoolean("is_rate_app", true).apply();
    }
}
