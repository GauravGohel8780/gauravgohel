package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.connect;

import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.view.View;
import android.widget.RelativeLayout;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.BaseViewControl;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ViewConnectBig extends BaseViewControl {
    private ConnectClickResult connectClickResult;
    private final ViewItemConnect vAir;
    private final ViewItemConnect vBlu;
    private final ViewItemConnect vData;
    private final ViewItemConnect vHot;
    private final ViewItemConnect vSync;
    private final ViewItemConnect vWifi;

    public void setConnectClickResult(ConnectClickResult connectClickResult) {
        this.connectClickResult = connectClickResult;
    }

    public ViewConnectBig(Context context) {
        super(context);
        setBackground(OtherUtils.bgIcon(Color.parseColor("#70000000"), (OtherUtils.getWidthScreen(context) * 36) / 100));
        setAlpha(1.0f);
        ViewItemConnect viewItemConnect = new ViewItemConnect(context);
        this.vAir = viewItemConnect;
        viewItemConnect.setId(343);
        viewItemConnect.setData(R.drawable.ic_airplan, R.string.air);
        viewItemConnect.setOnClickListener(new View.OnClickListener() { 
            @Override
            public final void onClick(View view) {
                connectClickResult.onAirClick();
            }
        });
        ViewItemConnect viewItemConnect2 = new ViewItemConnect(context);
        this.vData = viewItemConnect2;
        viewItemConnect2.setId(344);
        viewItemConnect2.setData(R.drawable.ic_data, R.string.data);
        viewItemConnect2.setOnClickListener(new View.OnClickListener() {
            @Override 
            public final void onClick(View view) {
                connectClickResult.onDataClick();
            }
        });
        ViewItemConnect viewItemConnect3 = new ViewItemConnect(context);
        this.vBlu = viewItemConnect3;
        viewItemConnect3.setId(345);
        viewItemConnect3.setData(R.drawable.ic_bluetooth, R.string.blu);
        viewItemConnect3.setOnClickListener(new View.OnClickListener() {
            @Override 
            public final void onClick(View view) {
                connectClickResult.onBlueClick();
            }
        });
        ViewItemConnect viewItemConnect4 = new ViewItemConnect(context);
        this.vSync = viewItemConnect4;
        viewItemConnect4.setId(346);
        viewItemConnect4.setData(R.drawable.ic_sync, R.string.syn);
        viewItemConnect4.setOnClickListener(new View.OnClickListener() {
            @Override 
            public final void onClick(View view) {
                connectClickResult.onSyncClick();
            }
        });
        ViewItemConnect viewItemConnect5 = new ViewItemConnect(context);
        this.vWifi = viewItemConnect5;
        viewItemConnect5.setId(347);
        viewItemConnect5.setData(R.drawable.ic_wifi, R.string.wifi);
        viewItemConnect5.setOnClickListener(new View.OnClickListener() {
            @Override 
            public final void onClick(View view) {
                connectClickResult.onWifiClick();
            }
        });
        ViewItemConnect viewItemConnect6 = new ViewItemConnect(context);
        this.vHot = viewItemConnect6;
        viewItemConnect6.setId(348);
        viewItemConnect6.setData(R.drawable.ic_hotspot, R.string.hot);
        viewItemConnect6.setOnClickListener(new View.OnClickListener() {
            @Override 
            public final void onClick(View view) {
                connectClickResult.onHotClick();
            }
        });
        changeScreen(true);
    }


    public void updateAir(boolean z) {
        this.vAir.setStatus(z, Color.parseColor("#FCD04E"));
    }

    public void updateData(boolean z) {
        this.vData.setStatus(z, Color.parseColor("#3bc551"));
    }

    public void updateBlu(boolean z) {
        this.vBlu.setStatus(z, Color.parseColor("#3478f6"));
    }

    public void updateWifi(boolean z) {
        this.vWifi.setStatus(z, Color.parseColor("#3478f6"));
        if (z) {
            new Handler().postDelayed(new Runnable() { // from class: com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.connect.ViewConnectBig.7
                @Override 
                public final void run() {
                    vWifi.setContent(OtherUtils.getWifiName(getContext()));
                }
            }, 5000L);
        }
    }


    public void updateHot(boolean z) {
        this.vHot.setStatus(z, Color.parseColor("#3478f6"));
    }

    public void updateSync(boolean z) {
        this.vSync.setStatus(z, Color.parseColor("#8b34f6"));
    }

    public void changeScreen(boolean z) {
        removeAllViews();
        int widthScreen = OtherUtils.getWidthScreen(getContext());
        int i = (widthScreen * 42) / 100;
        int i2 = widthScreen / 20;
        if (z) {
            setPadding(0, i2, 0, i2);
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(i, -2);
            layoutParams.setMargins(0, i2, 0, i2);
            addView(this.vAir, layoutParams);
            RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(i, -2);
            layoutParams2.addRule(17, this.vAir.getId());
            layoutParams2.addRule(6, this.vAir.getId());
            addView(this.vData, layoutParams2);
            RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(i, -2);
            layoutParams3.addRule(3, this.vAir.getId());
            layoutParams3.setMargins(0, i2, 0, i2);
            addView(this.vWifi, layoutParams3);
            RelativeLayout.LayoutParams layoutParams4 = new RelativeLayout.LayoutParams(i, -2);
            layoutParams4.addRule(17, this.vAir.getId());
            layoutParams4.addRule(6, this.vWifi.getId());
            addView(this.vBlu, layoutParams4);
            RelativeLayout.LayoutParams layoutParams5 = new RelativeLayout.LayoutParams(i, -2);
            layoutParams5.addRule(3, this.vWifi.getId());
            layoutParams5.setMargins(0, i2, 0, i2);
            addView(this.vSync, layoutParams5);
            RelativeLayout.LayoutParams layoutParams6 = new RelativeLayout.LayoutParams(i, -2);
            layoutParams6.addRule(17, this.vAir.getId());
            layoutParams6.addRule(6, this.vSync.getId());
            addView(this.vHot, layoutParams6);
            return;
        }
        int i3 = i2 / 2;
        setPadding(i3, i2, i3, i2);
        RelativeLayout.LayoutParams layoutParams7 = new RelativeLayout.LayoutParams(i, -2);
        int i4 = i2 / 4;
        layoutParams7.setMargins(i4, i2, i4, i2);
        addView(this.vAir, layoutParams7);
        RelativeLayout.LayoutParams layoutParams8 = new RelativeLayout.LayoutParams(i, -2);
        layoutParams8.addRule(6, this.vAir.getId());
        layoutParams8.addRule(17, this.vAir.getId());
        layoutParams8.setMargins(i4, 0, i4, 0);
        addView(this.vData, layoutParams8);
        RelativeLayout.LayoutParams layoutParams9 = new RelativeLayout.LayoutParams(i, -2);
        layoutParams9.addRule(6, this.vAir.getId());
        layoutParams9.addRule(17, this.vData.getId());
        layoutParams9.setMargins(i4, 0, i4, 0);
        addView(this.vHot, layoutParams9);
        RelativeLayout.LayoutParams layoutParams10 = new RelativeLayout.LayoutParams(i, -2);
        layoutParams10.setMargins(i4, i2, i4, i2);
        layoutParams10.addRule(3, this.vAir.getId());
        addView(this.vWifi, layoutParams10);
        RelativeLayout.LayoutParams layoutParams11 = new RelativeLayout.LayoutParams(i, -2);
        layoutParams11.addRule(6, this.vWifi.getId());
        layoutParams11.addRule(17, this.vAir.getId());
        layoutParams11.setMargins(i4, 0, i4, 0);
        addView(this.vBlu, layoutParams11);
        RelativeLayout.LayoutParams layoutParams12 = new RelativeLayout.LayoutParams(i, -2);
        layoutParams12.addRule(6, this.vWifi.getId());
        layoutParams12.addRule(17, this.vBlu.getId());
        layoutParams12.setMargins(i4, 0, i4, 0);
        addView(this.vSync, layoutParams12);
    }
}
