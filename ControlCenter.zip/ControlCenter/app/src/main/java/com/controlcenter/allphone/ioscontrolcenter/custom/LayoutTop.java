package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;

import androidx.core.view.ViewCompat;

import com.controlcenter.allphone.ioscontrolcenter.R;


public class LayoutTop extends LinearLayout {
    private final TextM tv;
    private final TextM tvInclude;

    public LayoutTop(Context context) {
        super(context);
        setOrientation(LinearLayout.VERTICAL);
        int i = getResources().getDisplayMetrics().widthPixels;
        int i2 = i / 25;
        TextM textM = new TextM(context);
        this.tv = textM;
        textM.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        float f = i;
        textM.setTextSize(0, (3.1f * f) / 100.0f);
        textM.setGravity(1);
        textM.setPadding(i2, i2, i2, i2);
        textM.setText(R.string.content_top);
        addView(textM, -2, -2);
        TextM textM2 = new TextM(context);
        this.tvInclude = textM2;
        textM2.setText(R.string.include);
        textM2.setTextSize(0, (3.8f * f) / 100.0f);
        int i3 = i2 / 2;
        textM2.setPadding(i2, i3, 0, i3);
        textM2.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        addView(textM2, -2, -2);
    }

    public void setTitle(int i) {
        this.tvInclude.setText(i);
        if (i == R.string.include) {
            this.tv.setVisibility(View.VISIBLE);
        } else {
            this.tv.setVisibility(View.GONE);
        }
    }
}
