package com.controlcenter.allphone.ioscontrolcenter.util;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemMode;

import java.util.ArrayList;


public class AssistiveUtils {
    public static final int A_BACK = 3;
    public static final int A_CAMERA = 30;
    public static final int A_CONTROL = 20;
    public static final int A_DIALOG_RESET = 31;
    public static final int A_FLASH_LIGHT = 9;
    public static final int A_HOME = 1;
    public static final int A_LOCK = 10;
    public static final int A_NONE_ACTION = 0;
    public static final int A_NOTIFICATION = 8;
    public static final int A_RECENT = 2;
    public static final int A_SCREENSHOT = 23;
    public static final int A_SCREEN_RECORD = 24;

    public static ArrayList<ItemMode> makeArrHomeMode() {
        ArrayList<ItemMode> arrayList = new ArrayList<>();
        arrayList.add(new ItemMode(0, R.string.a_none_action, R.drawable.ic_a_none));
        arrayList.add(new ItemMode(1, R.string.a_home, R.drawable.ic_a_home));
        arrayList.add(new ItemMode(2, R.string.a_recent, R.drawable.ic_a_recent));
        arrayList.add(new ItemMode(3, R.string.a_back, R.drawable.ic_a_back));
        arrayList.add(new ItemMode(8, R.string.a_notification, R.drawable.ic_a_notification));
        arrayList.add(new ItemMode(10, R.string.a_lock, R.drawable.ic_a_lock));
        arrayList.add(new ItemMode(20, R.string.a_control, R.drawable.ic_a_controlcenter));
        arrayList.add(new ItemMode(23, R.string.a_screenshot, R.drawable.ic_a_screenshot));
        arrayList.add(new ItemMode(9, R.string.a_flash_light, R.drawable.ic_a_flashlight));
        arrayList.add(new ItemMode(30, R.string.camera, R.drawable.ic_camera_while));
        arrayList.add(new ItemMode(31, R.string.a_power, R.drawable.ic_a_power));
        arrayList.add(new ItemMode(24, R.string.a_screen_record, R.drawable.ic_a_screen_record));
        return arrayList;
    }
}
