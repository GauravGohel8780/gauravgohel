package com.controlcenter.allphone.ioscontrolcenter.dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.View;


public class BaseDialog extends Dialog {
    public BaseDialog(Context context) {
        super(context);
        requestWindowFeature(1);
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        theme();
        setCancelable(false);
    }

    private void theme() {
        getWindow().getDecorView().setSystemUiVisibility(1536);
        final View decorView = getWindow().getDecorView();
        decorView.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public final void onSystemUiVisibilityChange(int i) {
                BaseDialog.lambda$theme$0(decorView, i);
            }
        });
    }

    public static void lambda$theme$0(View view, int i) {
        if ((i & 4) == 0) {
            view.setSystemUiVisibility(1536);
        }
    }
}
