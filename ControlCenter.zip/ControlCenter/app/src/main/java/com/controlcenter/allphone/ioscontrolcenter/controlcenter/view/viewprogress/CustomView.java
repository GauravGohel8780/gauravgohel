package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewprogress;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.View;

import androidx.core.view.ViewCompat;

import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class CustomView extends View {
    private Bitmap bm;
    private Canvas c;
    private final int max;
    private final PorterDuffXfermode pCut;
    private final Paint paint;
    private int progress;
    private final Rect rPro;
    private float ra;
    private RectF rectF;

    public CustomView(Context context) {
        super(context);
        this.ra = (OtherUtils.getWidthScreen(context) * 9.24f) / 180.0f;
        Paint paint = new Paint(1);
        this.paint = paint;
        paint.setStyle(Paint.Style.FILL);
        this.rPro = new Rect();
        this.pCut = new PorterDuffXfermode(PorterDuff.Mode.SRC_IN);
        this.max = 100;
        this.progress = 40;
    }

    public void setProgress(int i) {
        this.progress = i;
        invalidate();
    }

    public void setRa(float f) {
        this.ra = f;
        invalidate();
    }

    @Override 
    protected void onDraw(Canvas canvas) {
        Bitmap bitmap;
        super.onDraw(canvas);
        if (this.rectF == null || ((bitmap = this.bm) != null && bitmap.getHeight() != getHeight())) {
            changeLayout();
        }
        this.c.drawColor(0, PorterDuff.Mode.CLEAR);
        this.paint.setXfermode(null);
        this.paint.setColor(-1);
        Canvas canvas2 = this.c;
        RectF rectF = this.rectF;
        float f = this.ra;
        canvas2.drawRoundRect(rectF, f, f, this.paint);
        float aa = this.progress / this.max;
        int height = (int) ((1.0f - aa) * getHeight());
        this.paint.setXfermode(this.pCut);
        this.paint.setColor(Color.parseColor("#e0ffffff"));
        this.rPro.set(0, height, getWidth(), getHeight());
        this.c.drawRect(this.rPro, this.paint);
        this.paint.setColor(Color.parseColor("#70000000"));
        this.rPro.set(0, 0, getWidth(), height);
        this.c.drawRect(this.rPro, this.paint);
        canvas.drawBitmap(this.bm, 0.0f, 0.0f, (Paint) null);
    }

    public void changeLayout() {
        setPivotX(getWidth() / 2.0f);
        setPivotY(getHeight() / 2.0f);
        this.rectF = new RectF(0.0f, 0.0f, getWidth(), getHeight());
        this.bm = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.ARGB_8888);
        this.c = new Canvas(this.bm);
        this.paint.setColor(ViewCompat.MEASURED_STATE_MASK);
        Canvas canvas = this.c;
        RectF rectF = this.rectF;
        float f = this.ra;
        canvas.drawRoundRect(rectF, f, f, this.paint);
    }

    public int getProgress() {
        return this.progress;
    }
}
