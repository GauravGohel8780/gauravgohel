package com.controlcenter.allphone.ioscontrolcenter.util;


public class MyConst {
    public static final String ACTION_NIGHT_SHIFT_CHANGE = "com.demo.controlcenter.night_shift_change";
    public static final String DATA_ID_NOTIFICATION = "data_id_notification";
    public static final String DATA_NEX = "data_nex";
    public static final String DATA_PKG = "data_pkg";
    public static final String DATA_PLAY = "data_play";
    public static final String DATA_PRE = "data_pre";
    public static final String GUILD_VIDEO = "https://youtu.be/CV5IXmWcYpo";
    public static final String ID_DEV = "8333071100450515738";
    public static final String LINK_POLICY = "https://www.google.com";
}
