package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.status;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.custom.ViewBattery;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.custom.ViewWaveMobile;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.BaseViewControl;
import com.controlcenter.allphone.ioscontrolcenter.custom.TextM;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemStatusBattery;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemStrengthMobile;
import com.controlcenter.allphone.ioscontrolcenter.util.CheckUtils;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ViewStatusBar extends BaseViewControl {
    private boolean data;
    private boolean enaWifi;
    private final ImageView imWifi;
    private final TextM tvName;
    private final TextM tvPer;
    private final ViewWaveMobile vWave1;
    private final ViewWaveMobile vWave2;
    private final ViewBattery viewBattery;

    @Override
    public void touchDown() {
    }

    public ViewStatusBar(Context context) {
        super(context);
        setBackgroundColor(0);
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(LinearLayout.HORIZONTAL);
        linearLayout.setGravity(16);
        addView(linearLayout, -1, -1);
        int widthScreen = OtherUtils.getWidthScreen(context);
        ViewWaveMobile viewWaveMobile = new ViewWaveMobile(context);
        this.vWave1 = viewWaveMobile;
        float f = widthScreen;
        int i = (int) ((4.4f * f) / 100.0f);
        int i2 = (int) ((2.8f * f) / 100.0f);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(i, i2);
        int i3 = widthScreen / 80;
        layoutParams.setMargins(i3, 0, 0, 0);
        linearLayout.addView(viewWaveMobile, layoutParams);
        ViewWaveMobile viewWaveMobile2 = new ViewWaveMobile(context);
        this.vWave2 = viewWaveMobile2;
        viewWaveMobile2.setVisibility(View.GONE);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(i, i2);
        int i4 = widthScreen / 90;
        layoutParams2.setMargins(i4, 0, 0, 0);
        linearLayout.addView(viewWaveMobile2, layoutParams2);
        TextM textM = new TextM(context);
        this.tvName = textM;
        textM.setTextColor(-1);
        float f2 = (3.3f * f) / 100.0f;
        textM.setTextSize(0, f2);
        LayoutParams layoutParams3 = new LayoutParams(-2, -2);
        layoutParams3.setMargins(i4, 0, 0, 0);
        linearLayout.addView(textM, layoutParams3);
        ImageView imageView = new ImageView(context);
        this.imWifi = imageView;
        imageView.setImageResource(R.drawable.ic_wifi_small);
        imageView.setVisibility(View.GONE);
        int i5 = (int) ((4.1f * f) / 100.0f);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(i5, i5);
        layoutParams4.setMargins(i4, 0, 0, 0);
        linearLayout.addView(imageView, layoutParams4);
        linearLayout.addView(new View(context), new LinearLayout.LayoutParams(0, -1, 1.0f));
        TextM textM2 = new TextM(context);
        this.tvPer = textM2;
        textM2.setTextColor(-1);
        textM2.setTextSize(0, f2);
        LayoutParams layoutParams5 = new LayoutParams(-2, -2);
        layoutParams5.setMargins(0, 0, i4, 0);
        linearLayout.addView(textM2, layoutParams5);
        ViewBattery viewBattery = new ViewBattery(context);
        this.viewBattery = viewBattery;
        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams((int) ((6.6f * f) / 100.0f), (int) ((3.2f * f) / 100.0f));
        layoutParams6.setMargins(0, 0, i3, 0);
        linearLayout.addView(viewBattery, layoutParams6);
    }

    public void updateAll(boolean z, ItemStatusBattery itemStatusBattery) {
        String typeNetwork;
        this.data = z;
        String nameNetwork = CheckUtils.getNameNetwork(getContext());
        if (nameNetwork == null || nameNetwork.isEmpty()) {
            this.tvName.setVisibility(View.GONE);
        } else {
            this.tvName.setVisibility(View.VISIBLE);
            this.tvName.setText(nameNetwork);
        }
        ItemStrengthMobile[] strengthMobile = CheckUtils.getStrengthMobile(getContext());
        if (strengthMobile[1].getLevel() == -1) {
            this.vWave2.setVisibility(View.GONE);
        } else {
            this.vWave2.setVisibility(View.VISIBLE);
            this.vWave2.setStatus(strengthMobile[1].getLevel());
        }
        this.vWave1.setStatus(strengthMobile[0].getLevel());
        if (!this.enaWifi) {
            this.imWifi.setVisibility(View.GONE);
            if (z && (typeNetwork = CheckUtils.getTypeNetwork(strengthMobile[0].getType())) != null) {
                this.tvName.setVisibility(View.VISIBLE);
                if (nameNetwork == null || nameNetwork.isEmpty()) {
                    TextM textM = this.tvName;
                    textM.setText(typeNetwork);
                } else {
                    TextM textM2 = this.tvName;
                    textM2.setText(nameNetwork + " " + typeNetwork);
                }
            }
        } else {
            this.imWifi.setVisibility(View.VISIBLE);
        }
        if (itemStatusBattery != null) {
            TextM textM22 = this.tvPer;
            textM22.setText(itemStatusBattery.getPer() + getContext().getString(R.string.per));
            this.viewBattery.setPer(itemStatusBattery.getPer(), itemStatusBattery.isChange());
        }
    }

    public void updateWifi(boolean z) {
        this.enaWifi = z;
        updateAll(this.data, null);
    }
}
