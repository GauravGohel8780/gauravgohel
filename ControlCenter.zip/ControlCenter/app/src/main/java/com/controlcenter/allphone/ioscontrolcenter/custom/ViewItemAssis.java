package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.content.Context;
import android.graphics.Color;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.controlcenter.allphone.ioscontrolcenter.item.ItemMode;
import com.controlcenter.allphone.ioscontrolcenter.util.AssistiveUtils;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;

import java.util.Iterator;


public class ViewItemAssis extends LinearLayout {
    private final ImageView im;
    private final TextL tv;
    private int type;

    public ViewItemAssis(Context context) {
        super(context);
        this.type = -1;
        setOrientation(LinearLayout.VERTICAL);
        int widthScreen = OtherUtils.getWidthScreen(context);
        int i = ((widthScreen * 24) / 100) / 5;
        ImageView imageView = new ImageView(context);
        this.im = imageView;
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int i2 = (i * 8) / 12;
        imageView.setPadding(i, i2, i, i2);
        addView(imageView, new LayoutParams(-1, 0, 1.0f));
        TextL textL = new TextL(context);
        this.tv = textL;
        textL.setTextColor(-1);
        textL.setTextSize(0, (widthScreen * 3.0f) / 100.0f);
        textL.setGravity(1);
        textL.setLines(2);
        int i3 = widthScreen / 100;
        textL.setPadding(i3, 0, i3, i3);
        addView(textL, -1, -2);
        imageView.setColorFilter(Color.parseColor("#222222"));
        textL.setTextColor(Color.parseColor("#222222"));
    }

    public void setType(int i) {
        this.type = i;
        Iterator<ItemMode> it = AssistiveUtils.makeArrHomeMode().iterator();
        while (it.hasNext()) {
            ItemMode next = it.next();
            if (next.getId() == i) {
                this.tv.setText(next.getText());
                this.im.setImageResource(next.getImage());
                return;
            }
        }
    }

    public int getType() {
        return this.type;
    }

    public void setImage(int i) {
        this.im.setImageResource(i);
    }
}
