package com.controlcenter.allphone.ioscontrolcenter;


import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

import com.controlcenter.allphone.ioscontrolcenter.Ads_Common.AdsBaseActivity;
import com.controlcenter.allphone.ioscontrolcenter.databinding.ActivityIntroScreenBinding;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.util.ArrayList;
import java.util.List;

public class CC_IntroScreenActivity extends AdsBaseActivity {
    IntroPagerAdapter introPagerAdapter;
    ActivityIntroScreenBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        SetSystemFullScreen();
        binding = ActivityIntroScreenBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        introPagerAdapter = new IntroPagerAdapter(getSupportFragmentManager());
        introPagerAdapter.add(new CC_FirstIntroFragment());
        introPagerAdapter.add(new CC_SecondIntroFragment());
        introPagerAdapter.add(new CC_ThirdIntroFragment());
        binding.vpIntro.setAdapter(introPagerAdapter);


        binding.tvNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(CC_IntroScreenActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        int currentItem = binding.vpIntro.getCurrentItem();
                        int lastItem = introPagerAdapter.getCount() - 1;
                        if (currentItem == lastItem) {
                            gotoLanguageSelection();
                        } else {
                            binding.vpIntro.setCurrentItem(currentItem + 1);
                        }
                    }
                }, MAIN_CLICK);
            }
        });

        binding.vpIntro.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                updateIndicators(position);
                binding.vpIntro.setCurrentItem(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });

    }


    private void gotoLanguageSelection() {
        SharedPrefs.setIntroScreenActivity(CC_IntroScreenActivity.this, true);
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
        finish();
    }


    private void updateIndicators(int position) {
        if (position == 0) {
            binding.tvNext.setText("Next");
        } else if (position == 1) {
            binding.tvNext.setText("Continue");
        } else {
            binding.tvNext.setText("Done");
        }
    }

    public class IntroPagerAdapter extends FragmentPagerAdapter {

        private final List<Fragment> fragments;

        public IntroPagerAdapter(@NonNull FragmentManager fm) {
            super(fm, FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
            this.fragments = new ArrayList();
        }

        @Override
        public Fragment getItem(int position) {
            return this.fragments.get(position);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return super.getPageTitle(position);
        }

        public void add(Fragment fragment) {
            this.fragments.add(fragment);
        }

        @Override
        public int getCount() {
            return this.fragments.size();
        }
    }
    public void SetSystemFullScreen() {
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) {
            View v = getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}