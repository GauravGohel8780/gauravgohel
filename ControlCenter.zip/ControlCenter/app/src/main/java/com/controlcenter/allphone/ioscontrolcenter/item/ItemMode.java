package com.controlcenter.allphone.ioscontrolcenter.item;

import com.google.gson.annotations.SerializedName;


public class ItemMode {
    @SerializedName("id")
    private int id;
    @SerializedName("image")
    private int image;
    @SerializedName("text")
    private int text;

    public ItemMode(int i, int i2, int i3) {
        this.id = i;
        this.text = i2;
        this.image = i3;
    }

    public ItemMode() {
    }

    public int getId() {
        return this.id;
    }

    public int getText() {
        return this.text;
    }

    public int getImage() {
        return this.image;
    }
}
