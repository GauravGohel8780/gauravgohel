package com.controlcenter.allphone.ioscontrolcenter;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.controlcenter.allphone.ioscontrolcenter.dialog.DialogPerResult;
import com.controlcenter.allphone.ioscontrolcenter.location.ActivityLocation;
import com.controlcenter.allphone.ioscontrolcenter.service.ServiceControl;
import com.controlcenter.allphone.ioscontrolcenter.touch.ActivityTouch;
import com.controlcenter.allphone.ioscontrolcenter.util.CheckUtils;
import com.controlcenter.allphone.ioscontrolcenter.util.MyConst;
import com.controlcenter.allphone.ioscontrolcenter.util.MyShare;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;
import com.controlcenter.allphone.ioscontrolcenter.view.ViewControlCenterUi;
import com.google.android.material.card.MaterialCardView;
import com.google.gson.GsonBuilder;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Objects;

import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;


public class MainActivity extends BaseActivity implements DialogPerResult {
    public ViewControlCenterUi baseSetting;
    private int checkPro;
    private String name;
    private String pathImage;
    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            MainActivity.this.baseSetting.updateNightShift();
        }
    };
    private final ActivityResultLauncher<Intent> launcher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
        @Override
        public void onActivityResult(ActivityResult activityResult) {
            MainActivity.this.baseSetting.checkPer();
        }
    });
    private final ActivityResultLauncher<Intent> launcherPer = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() {
        @Override
        public final void onActivityResult(Object obj) {
            MainActivity.this.clickActivityResult((ActivityResult) obj);
        }
    });

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);


    }

    public void sentDataToService(Intent intent) {
        startService(intent);
    }

    @Override
    public void onDestroy() {
        unregisterReceiver(this.receiver);
        super.onDestroy();
    }

    @Override
    public void onRequestPer() {
        String[] strArr;
        int i = Build.VERSION.SDK_INT;
        if (i >= 33 && CheckUtils.checkPer(this, "android.permission.CAMERA")) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.BLUETOOTH_CONNECT"}, 1);
        } else if (i >= 31 && CheckUtils.canWriteInMediaStore(this) && CheckUtils.checkPer(this, "android.permission.READ_EXTERNAL_STORAGE") && CheckUtils.checkPer(this, "android.permission.CAMERA")) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.BLUETOOTH_CONNECT"}, 1);
        } else {
            if (CheckUtils.canWriteInMediaStore(this)) {
                strArr = new String[]{"android.permission.READ_EXTERNAL_STORAGE", "android.permission.CAMERA"};
            } else {
                strArr = new String[]{"android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.CAMERA"};
            }
            Dexter.withContext(this).withPermissions(strArr).withListener(new MultiplePermissionsListener() {
                @Override
                public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
                    if (!multiplePermissionsReport.areAllPermissionsGranted()) {
                        Toast.makeText(MainActivity.this, (int) R.string.per_error, Toast.LENGTH_SHORT).show();
                    } else if (Build.VERSION.SDK_INT >= 31) {
                        MainActivity.this.onRequestPer();
                    }
                }

                @Override
                public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
                    permissionToken.continuePermissionRequest();
                }
            }).withErrorListener(new PermissionRequestErrorListener() {
                @Override
                public final void onError(DexterError dexterError) {
                    Toast.makeText(MainActivity.this, (int) R.string.per_error, Toast.LENGTH_SHORT).show();
                }
            }).check();
        }
    }


    @Override
    public void onRequestDrawOther() {
        this.checkPro = 0;
        if (Build.VERSION.SDK_INT >= 23) {
            ActivityResultLauncher<Intent> activityResultLauncher = this.launcher;
            activityResultLauncher.launch(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + getPackageName())));
        }
    }

    @Override
    public void onRequestService() {
        this.checkPro = 0;
        this.launcher.launch(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
    }

    @Override
    public void onRequestWriteSetting() {
        this.checkPro = 0;
        if (Build.VERSION.SDK_INT >= 23) {
            Intent intent = new Intent("android.settings.action.MANAGE_WRITE_SETTINGS");
            intent.setData(Uri.parse("package:" + getPackageName()));
            this.launcher.launch(intent);
        }
    }

    @Override
    public void onRequestAccessibility() {
        if (!MyShare.isApplyPolicy(this)) {
            this.launcherPer.launch(new Intent(this, ActivityPolicy.class));
            return;
        }
        this.checkPro = 0;
        Intent intent = new Intent("android.settings.ACCESSIBILITY_SETTINGS");
        this.launcher.launch(intent);
    }

    public void clickActivityResult(ActivityResult activityResult) {
        if (activityResult.getResultCode() == -1) {
            onRequestAccessibility();
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        RelativeLayout relativeLayout = new RelativeLayout(this);

        Drawable background = getResources().getDrawable(R.drawable.img_main_bg);
        relativeLayout.setBackground(background);
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setVerticalScrollBarEnabled(false);
        OverScrollDecoratorHelper.setUpOverScroll(scrollView);
        relativeLayout.addView(scrollView, -1, -1);
        ViewControlCenterUi viewControlCenterUi = new ViewControlCenterUi(this);
        this.baseSetting = viewControlCenterUi;
        viewControlCenterUi.setDialogPerResult(this);
        this.baseSetting.setActivity(this, relativeLayout);
        scrollView.addView(this.baseSetting, -1, -1);
        setContentView(relativeLayout);

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.POST_NOTIFICATIONS"}, 22);
        }

        this.baseSetting.checkPer();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    public void pickPhoto() {
        Intent addCategory = new Intent("android.intent.action.GET_CONTENT").setType("image/*").addCategory("android.intent.category.OPENABLE");
        addCategory.putExtra("android.intent.extra.MIME_TYPES", new String[]{"image/jpeg", "image/png"});
        startActivityForResult(Intent.createChooser(addCategory, getString(R.string.app_name)), 20);
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i2 != -1 || intent == null) {
            return;
        }
        if (i != 20) {
            if (i == 69) {
                OtherUtils.clearWallpaper(this, this.name);
                MyShare.putWallpaper(this, this.pathImage);
                MyShare.putStatusWallpaper(this, 3);
                Intent intent2 = new Intent(this, ServiceControl.class);
                intent2.putExtra(MyConst.DATA_ID_NOTIFICATION, 16);
                sentDataToService(intent2);
                Toast.makeText(this, (int) R.string.done, Toast.LENGTH_SHORT).show();
                return;
            }
            return;
        }
        this.name = System.currentTimeMillis() + ".jpg";
        this.pathImage = OtherUtils.makePathWallpaper(this) + "/" + this.name;
        try {
            File file = new File(this.pathImage);
            file.createNewFile();
            int[] sizes = MyShare.getSizes(this);
            UCrop.of(intent.getData(), Uri.fromFile(file)).withAspectRatio(sizes[0], sizes[1]).withMaxResultSize(1000, 1000).start(this);
        } catch (IOException e) {
            Toast.makeText(this, (int) R.string.error, Toast.LENGTH_SHORT).show();
        }
    }

    public void startPositionActivity() {
        this.checkPro = 1;
        this.launcher.launch(new Intent(this, ActivityLocation.class));
    }

    public void startTouchActivity() {
        this.checkPro = 2;
        this.launcher.launch(new Intent(this, ActivityTouch.class));
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        Dialog dialog = new Dialog(MainActivity.this, R.style.customDialog);
        dialog.setContentView(R.layout.exit_dialog);
        dialog.setCancelable(false);

        Objects.requireNonNull(dialog.getWindow()).setGravity(Gravity.CENTER);
        dialog.getWindow().setLayout(-1, -2);

        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(ContextCompat.getDrawable(MainActivity.this, android.R.color.transparent));

        dialog.show();


        TextView tvExit = dialog.findViewById(R.id.tvExit);
        TextView tvCancel = dialog.findViewById(R.id.tvCancel);

        tvExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finishAffinity();
            }
        });

        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }
}
