package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewprogress;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class BaseViewStatus extends View {
    final AnimatorSet anim;
    final Paint paint;
    int progress;

    public BaseViewStatus(Context context) {
        super(context);
        ObjectAnimator ofPropertyValuesHolder = ObjectAnimator.ofPropertyValuesHolder(this, PropertyValuesHolder.ofFloat(View.SCALE_X, 1.0f, 1.17f), PropertyValuesHolder.ofFloat(View.SCALE_Y, 1.0f, 1.17f));
        ofPropertyValuesHolder.setDuration(200L);
        ofPropertyValuesHolder.setRepeatCount(1);
        ofPropertyValuesHolder.setRepeatMode(ValueAnimator.REVERSE);
        ofPropertyValuesHolder.setInterpolator(new DecelerateInterpolator());
        AnimatorSet animatorSet = new AnimatorSet();
        this.anim = animatorSet;
        animatorSet.play(ofPropertyValuesHolder);
        int widthScreen = OtherUtils.getWidthScreen(context);
        Paint paint = new Paint(1);
        this.paint = paint;
        paint.setStyle(Paint.Style.FILL);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeWidth(widthScreen / 200.0f);
        paint.setColor(Color.parseColor("#e0aaaaaa"));
    }

    public void setProgress(int i) {
        if (this.progress != i) {
            this.progress = i;
            if (i > 100) {
                this.progress = 100;
            }
            invalidate();
            if (i != 100 || this.anim.isRunning()) {
                return;
            }
            this.anim.start();
        }
    }
}
