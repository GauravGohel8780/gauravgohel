package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewprogress;

import android.content.Context;
import android.media.AudioManager;
import android.view.View;
import android.widget.RelativeLayout;

import androidx.core.app.NotificationManagerCompat;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.custom.TextM;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class ViewBigVolume {
    private final AudioManager am;
    private final OnProgressChange onProgressChange = new OnProgressChange() {
        @Override
        public void onLongClick(View view) {
        }

        @Override
        public void onTouchDown() {
        }

        @Override
        public void onTouchUp() {
        }

        @Override
        public void onChange(View view, int i) {
            ViewBigVolume.this.am.setStreamVolume(view.getId() + NotificationManagerCompat.IMPORTANCE_UNSPECIFIED, (ViewBigVolume.this.am.getStreamMaxVolume(view.getId() + NotificationManagerCompat.IMPORTANCE_UNSPECIFIED) * i) / 100, 0);
        }
    };
    private final RelativeLayout rl;

    public ViewBigVolume(RelativeLayout relativeLayout, boolean z) {
        int i;
        int i2;
        int i3;
        this.rl = relativeLayout;
        this.am = (AudioManager) relativeLayout.getContext().getSystemService(Context.AUDIO_SERVICE);
        int widthScreen = OtherUtils.getWidthScreen(relativeLayout.getContext());
        if (z) {
            i = (widthScreen * 22) / 100;
            i2 = (i * 5) / 2;
            i3 = (widthScreen * 8) / 100;
        } else {
            i = (widthScreen * 19) / 100;
            i2 = (i * 60) / 19;
            i3 = widthScreen / 10;
        }
        ViewProgress makePro = makePro(i, 0, R.string.volume_call);
        ViewProgress makePro2 = makePro(i, 1, R.string.volume_system);
        View makePro3 = makePro(i, 2, R.string.volume_ring);
        ViewProgress makePro4 = makePro(i, 3, R.string.volume_music);
        ViewProgress makePro5 = makePro(i, 4, R.string.volume_alarm);
        View makePro6 = makePro(i, 5, R.string.volume_notification);
        if (z) {
            View view = new View(relativeLayout.getContext());
            view.setId(120);
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, (widthScreen * 24) / 100);
            layoutParams.addRule(15);
            relativeLayout.addView(view, layoutParams);
            RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(i, i2);
            layoutParams2.addRule(14);
            layoutParams2.addRule(2, view.getId());
            layoutParams2.setMargins(i3, 0, i3, 0);
            relativeLayout.addView(makePro, layoutParams2);
            RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(i, i2);
            layoutParams3.addRule(2, view.getId());
            layoutParams3.addRule(16, makePro.getId());
            relativeLayout.addView(makePro2, layoutParams3);
            RelativeLayout.LayoutParams layoutParams4 = new RelativeLayout.LayoutParams(i, i2);
            layoutParams4.addRule(2, view.getId());
            layoutParams4.addRule(17, makePro.getId());
            relativeLayout.addView(makePro3, layoutParams4);
            RelativeLayout.LayoutParams layoutParams5 = new RelativeLayout.LayoutParams(i, i2);
            layoutParams5.addRule(14);
            layoutParams5.addRule(3, view.getId());
            layoutParams5.setMargins(i3, 0, i3, 0);
            relativeLayout.addView(makePro4, layoutParams5);
            RelativeLayout.LayoutParams layoutParams6 = new RelativeLayout.LayoutParams(i, i2);
            layoutParams6.addRule(3, view.getId());
            layoutParams6.addRule(16, makePro4.getId());
            relativeLayout.addView(makePro5, layoutParams6);
            RelativeLayout.LayoutParams layoutParams7 = new RelativeLayout.LayoutParams(i, i2);
            layoutParams7.addRule(3, view.getId());
            layoutParams7.addRule(17, makePro4.getId());
            relativeLayout.addView(makePro6, layoutParams7);
            return;
        }
        View view2 = new View(relativeLayout.getContext());
        view2.setId(120);
        RelativeLayout.LayoutParams layoutParams8 = new RelativeLayout.LayoutParams(i3, -1);
        layoutParams8.addRule(14);
        relativeLayout.addView(view2, layoutParams8);
        RelativeLayout.LayoutParams layoutParams9 = new RelativeLayout.LayoutParams(i, i2);
        layoutParams9.addRule(15);
        layoutParams9.addRule(16, view2.getId());
        relativeLayout.addView(makePro, layoutParams9);
        RelativeLayout.LayoutParams layoutParams10 = new RelativeLayout.LayoutParams(i, i2);
        layoutParams10.addRule(15);
        layoutParams10.addRule(16, makePro.getId());
        layoutParams10.setMargins(0, 0, i3, 0);
        relativeLayout.addView(makePro2, layoutParams10);
        RelativeLayout.LayoutParams layoutParams11 = new RelativeLayout.LayoutParams(i, i2);
        layoutParams11.addRule(15);
        layoutParams11.addRule(16, makePro2.getId());
        layoutParams11.setMargins(0, 0, i3, 0);
        relativeLayout.addView(makePro3, layoutParams11);
        RelativeLayout.LayoutParams layoutParams12 = new RelativeLayout.LayoutParams(i, i2);
        layoutParams12.addRule(15);
        layoutParams12.addRule(17, view2.getId());
        relativeLayout.addView(makePro4, layoutParams12);
        RelativeLayout.LayoutParams layoutParams13 = new RelativeLayout.LayoutParams(i, i2);
        layoutParams13.addRule(15);
        layoutParams13.addRule(17, makePro4.getId());
        layoutParams13.setMargins(i3, 0, 0, 0);
        relativeLayout.addView(makePro5, layoutParams13);
        RelativeLayout.LayoutParams layoutParams14 = new RelativeLayout.LayoutParams(i, i2);
        layoutParams14.addRule(15);
        layoutParams14.addRule(17, makePro5.getId());
        layoutParams14.setMargins(i3, 0, 0, 0);
        relativeLayout.addView(makePro6, layoutParams14);
    }

    private ViewProgress makePro(int i, int i2, int i3) {
        ViewProgress viewProgress = new ViewProgress(this.rl.getContext());
        viewProgress.setId(i2 + 1000);
        viewProgress.setAlpha(1.0f);
        viewProgress.setOnProgressChange(this.onProgressChange);
        viewProgress.setBaseViewStatus(new ViewStatusVolume(this.rl.getContext()), i);
        viewProgress.setProgress((this.am.getStreamVolume(i2) * 100) / this.am.getStreamMaxVolume(i2));
        TextM textM = new TextM(this.rl.getContext());
        textM.setTextColor(-1);
        textM.setText(i3);
        textM.setTextSize(0, i / 7.5f);
        textM.setGravity(1);
        textM.setSingleLine();
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -2);
        layoutParams.addRule(18, viewProgress.getId());
        layoutParams.addRule(19, viewProgress.getId());
        layoutParams.addRule(2, viewProgress.getId());
        layoutParams.setMargins(0, 0, 0, i / 5);
        this.rl.addView(textM, layoutParams);
        return viewProgress;
    }
}
