package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.nightshift;

import android.content.Context;
import android.view.View;

import com.controlcenter.allphone.ioscontrolcenter.util.MyShare;


public class ViewNightShift extends View {
    private NightShiftResult nightShiftResult;

    
    public interface NightShiftResult {
        void onHideComplete();
    }

    public void setNightShiftResult(NightShiftResult nightShiftResult) {
        this.nightShiftResult = nightShiftResult;
    }

    public ViewNightShift(Context context) {
        super(context);
        updateColor();
    }

    public void updateColor() {
        setBackgroundColor(MyShare.getColorNightShift(getContext()));
    }

    public void show() {
        setVisibility(View.VISIBLE);
        setAlpha(0.0f);
        animate().alpha(1.0f).setDuration(1000L).withEndAction(null).start();
    }

    public void hide() {
        animate().alpha(0.0f).setDuration(1000L).withEndAction(new Runnable() {
            @Override 
            public final void run() {
                setVisibility(View.GONE);
                nightShiftResult.onHideComplete();
            }
        }).start();
    }
}
