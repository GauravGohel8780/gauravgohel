package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewprogress;

import android.content.Intent;
import android.graphics.Color;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.ViewControlCenter;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.connect.ViewItemConnect;
import com.controlcenter.allphone.ioscontrolcenter.util.MyConst;
import com.controlcenter.allphone.ioscontrolcenter.util.MyShare;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;

import java.util.Calendar;


public class ViewBigBright implements View.OnClickListener {
    private final RelativeLayout rl;
    private final ViewItemConnect vAuto;
    private final ViewItemConnect vNight;
    private final ViewControlCenter viewControlCenter;

    public ViewBigBright(ViewControlCenter viewControlCenter, RelativeLayout relativeLayout, boolean z, int i, OnProgressChange onProgressChange) {
        this.viewControlCenter = viewControlCenter;
        this.rl = relativeLayout;
        int widthScreen = OtherUtils.getWidthScreen(relativeLayout.getContext());
        ViewStatusBright viewStatusBright = new ViewStatusBright(relativeLayout.getContext());
        viewStatusBright.setColor(Color.parseColor("#fefefe"));
        ViewProgress viewProgress = new ViewProgress(relativeLayout.getContext());
        viewProgress.setId(123);
        viewProgress.setAlpha(1.0f);
        viewProgress.setOnProgressChange(onProgressChange);
        viewProgress.setRa((widthScreen * 18.0f) / 180.0f);
        viewProgress.setBaseViewStatusOut(viewStatusBright);
        viewProgress.setProgress(i);
        ViewItemConnect viewItemConnect = new ViewItemConnect(relativeLayout.getContext());
        this.vNight = viewItemConnect;
        viewItemConnect.setData(R.drawable.ic_night_mode, R.string.night_shift);
        updateNightShift();
        viewItemConnect.setOnClickListener(this);
        ViewItemConnect viewItemConnect2 = new ViewItemConnect(relativeLayout.getContext());
        this.vAuto = viewItemConnect2;
        viewItemConnect2.setData(R.drawable.ic_true_tone, R.string.auto_bright);
        viewItemConnect2.setStatus(isAuto(), Color.parseColor("#3b82f6"));
        viewItemConnect2.setOnClickListener(this);
        LinearLayout linearLayout = new LinearLayout(relativeLayout.getContext());
        LinearLayout linearLayout2 = new LinearLayout(relativeLayout.getContext());
        if (z) {
            int i2 = (widthScreen * 35) / 100;
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(i2, (i2 * 47) / 18);
            layoutParams.addRule(13);
            relativeLayout.addView(viewProgress, layoutParams);
            linearLayout2.setOrientation(LinearLayout.HORIZONTAL);
            linearLayout2.setGravity(17);
            RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-1, -1);
            layoutParams2.addRule(2, viewProgress.getId());
            relativeLayout.addView(linearLayout2, layoutParams2);
            linearLayout2.addView(viewStatusBright, i2, i2);
            linearLayout.setOrientation(LinearLayout.HORIZONTAL);
            linearLayout.setGravity(17);
            RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(-1, -1);
            layoutParams3.addRule(3, viewProgress.getId());
            relativeLayout.addView(linearLayout, layoutParams3);
            int i3 = (widthScreen * 28) / 100;
            linearLayout.addView(viewItemConnect, i3, -2);
            linearLayout.addView(viewItemConnect2, i3, -2);
            return;
        }
        int i4 = (widthScreen * 8) / 10;
        int i5 = (i4 * 18) / 47;
        RelativeLayout.LayoutParams layoutParams4 = new RelativeLayout.LayoutParams(i5, i4);
        layoutParams4.addRule(13);
        relativeLayout.addView(viewProgress, layoutParams4);
        linearLayout2.setOrientation(LinearLayout.HORIZONTAL);
        linearLayout2.setGravity(17);
        RelativeLayout.LayoutParams layoutParams5 = new RelativeLayout.LayoutParams(-1, -1);
        layoutParams5.addRule(14);
        layoutParams5.addRule(16, viewProgress.getId());
        relativeLayout.addView(linearLayout2, layoutParams5);
        linearLayout2.addView(viewStatusBright, i5, i5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(17);
        RelativeLayout.LayoutParams layoutParams6 = new RelativeLayout.LayoutParams(-1, -1);
        layoutParams6.addRule(17, viewProgress.getId());
        relativeLayout.addView(linearLayout, layoutParams6);
        int i6 = (widthScreen * 28) / 100;
        linearLayout.addView(new View(relativeLayout.getContext()), new LinearLayout.LayoutParams(-1, 0, 1.0f));
        linearLayout.addView(viewItemConnect, i6, -2);
        linearLayout.addView(new View(relativeLayout.getContext()), new LinearLayout.LayoutParams(-1, 0, 1.0f));
        linearLayout.addView(viewItemConnect2, i6, -2);
        linearLayout.addView(new View(relativeLayout.getContext()), new LinearLayout.LayoutParams(-1, 0, 1.0f));
    }

    private boolean isAuto() {
        int i;
        try {
            i = Settings.System.getInt(this.rl.getContext().getContentResolver(), "screen_brightness_mode");
        } catch (Exception e) {
            i = 1;
        }
        return i == 1;
    }

    @Override 
    public void onClick(View view) {
        int i;
        if (view != this.vNight) {
            try {
                i = Settings.System.getInt(this.rl.getContext().getContentResolver(), "screen_brightness_mode");
            } catch (Exception e) {
                i = 1;
            }
            if (i == 0) {
                Settings.System.putInt(this.rl.getContext().getContentResolver(), "screen_brightness_mode", 1);
            } else {
                Settings.System.putInt(this.rl.getContext().getContentResolver(), "screen_brightness_mode", 0);
            }
            this.vAuto.setStatus(isAuto(), Color.parseColor("#3b82f6"));
            return;
        }
        this.rl.getContext().sendBroadcast(new Intent(MyConst.ACTION_NIGHT_SHIFT_CHANGE));
        this.viewControlCenter.nightShiftClick();
        this.vNight.setStatus(MyShare.getEnaNightShift(this.rl.getContext()), Color.parseColor("#dea645"));
    }

    private void updateNightShift() {
        boolean scheduled = MyShare.getScheduled(this.rl.getContext());
        if (MyShare.getEnaNightShift(this.rl.getContext()) || scheduled) {
            this.vNight.setStatus(true, Color.parseColor("#dea645"));
            if (scheduled) {
                StringBuilder sb = new StringBuilder();
                Calendar calendar = Calendar.getInstance();
                calendar.setTimeInMillis(MyShare.getTimeFrom(this.rl.getContext()));
                sb.append(calendar.get(11));
                sb.append(":");
                sb.append(OtherUtils.setNum(calendar.get(12)));
                sb.append(" - ");
                calendar.setTimeInMillis(MyShare.getTimeTo(this.rl.getContext()));
                sb.append(calendar.get(11));
                sb.append(":");
                sb.append(OtherUtils.setNum(calendar.get(12)));
                this.vNight.setContent(sb.toString());
                return;
            }
            this.vNight.setContent(R.string.on);
            return;
        }
        this.vNight.setStatus(false, Color.parseColor("#dea645"));
    }
}
