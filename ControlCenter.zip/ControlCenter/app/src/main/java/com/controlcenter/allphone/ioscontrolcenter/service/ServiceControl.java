package com.controlcenter.allphone.ioscontrolcenter.service;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

import com.controlcenter.allphone.ioscontrolcenter.util.CheckUtils;
import com.controlcenter.allphone.ioscontrolcenter.util.FlashlightProvider;
import com.controlcenter.allphone.ioscontrolcenter.util.MyConst;
import com.controlcenter.allphone.ioscontrolcenter.util.MyShare;

import java.util.List;

import kotlin.jvm.internal.CharCompanionObject;


public class ServiceControl extends AccessibilityService {
    private boolean addViewScreen;
    private BroadcastScreen broadcastScreen;
    private ControlCenterManager controlManager;
    private List<MediaController> controllers;
    private FlashlightProvider flashlightProvider;
    private Handler handler;
    private WindowManager manager;
    private MediaController mediaController;
    private MediaSessionManager msm;
    private WindowManager.LayoutParams pScreen;
    private boolean screen;
    private SettingsContentObserver settingsContentObserver;
    private View vScreen;
    private final MusicControlResult musicControlResult = new MusicControlResult() { // from class: com.controlcenter.allphone.ioscontrolcenter.service.ServiceControl.1
        @Override // com.controlcenter.allphone.ioscontrolcenter.service.MusicControlResult
        public void onControlMedia(String str) {
            if (str == null || ServiceControl.this.mediaController == null || ServiceControl.this.mediaController.getTransportControls() == null || ServiceControl.this.mediaController.getPlaybackState() == null) {
                return;
            }
            if (str.equals(MyConst.DATA_PLAY)) {
                if (ServiceControl.this.mediaController.getPlaybackState().getState() == 3) {
                    ServiceControl.this.mediaController.getTransportControls().pause();
                } else {
                    ServiceControl.this.mediaController.getTransportControls().play();
                }
            } else if (str.equals(MyConst.DATA_PRE)) {
                ServiceControl.this.mediaController.getTransportControls().skipToPrevious();
            } else {
                ServiceControl.this.mediaController.getTransportControls().skipToNext();
            }
        }

        @Override // com.controlcenter.allphone.ioscontrolcenter.service.MusicControlResult
        public void onSeekTo(long j) {
            if (ServiceControl.this.mediaController != null && ServiceControl.this.mediaController.getTransportControls() != null) {
                ServiceControl.this.mediaController.getTransportControls().seekTo(j);
            }
        }
    };
    private final Runnable rChangeScreen = new Runnable() { // from class: com.controlcenter.allphone.ioscontrolcenter.service.ServiceControl.2
        @Override 
        public void run() {
            int[] iArr = new int[2];
            ServiceControl.this.vScreen.getLocationOnScreen(iArr);
            boolean z = iArr[0] <= MyShare.getSizes(ServiceControl.this)[0];
            if (ServiceControl.this.controlManager != null) {
                ServiceControl.this.controlManager.onChangeScreen(z);
            }
        }
    };
    private final Runnable rChooseMedia = new Runnable() { // from class: com.controlcenter.allphone.ioscontrolcenter.service.ServiceControl.3
        @Override 
        public void run() {
            int state;
            if (ServiceControl.this.mediaController != null) {
                ServiceControl.this.mediaController.unregisterCallback(ServiceControl.this.callback);
            }
            for (MediaController mediaController : ServiceControl.this.controllers) {
                if (mediaController.getPlaybackState() != null && (state = mediaController.getPlaybackState().getState()) != 0 && state != -1 && state != 7) {
                    if (ServiceControl.this.mediaController == null) {
                        ServiceControl.this.mediaController = mediaController;
                    } else if (state == 3) {
                        ServiceControl.this.mediaController = mediaController;
                    }
                }
            }
            if (ServiceControl.this.mediaController != null) {
                ServiceControl.this.mediaController.registerCallback(ServiceControl.this.callback);
                if (ServiceControl.this.mediaController.getMetadata() != null) {
                    ServiceControl serviceControl = ServiceControl.this;
                    serviceControl.makeMedia(serviceControl.mediaController.getMetadata());
                    if (ServiceControl.this.mediaController.getPlaybackState() != null) {
                        if (ServiceControl.this.mediaController.getPlaybackState().getState() == 3) {
                            ServiceControl.this.handler.removeCallbacks(ServiceControl.this.runnable);
                            ServiceControl.this.handler.post(ServiceControl.this.runnable);
                        }
                        ServiceControl serviceControl2 = ServiceControl.this;
                        serviceControl2.makeStatus(serviceControl2.mediaController.getPlaybackState());
                    }
                }
            } else if (ServiceControl.this.isViewControlExist()) {
                ServiceControl.this.controlManager.getViewControlCenter().onEndMusic();
            }
        }
    };
    private final MediaSessionManager.OnActiveSessionsChangedListener listener = new MediaSessionManager.OnActiveSessionsChangedListener() { // from class: com.controlcenter.allphone.ioscontrolcenter.service.ServiceControl.4
        @Override // android.media.session.MediaSessionManager.OnActiveSessionsChangedListener
        public final void onActiveSessionsChanged(List list) {
            ServiceControl.this.mediaChange(list);
        }
    };
    private final Runnable runnable = new Runnable() { // from class: com.controlcenter.allphone.ioscontrolcenter.service.ServiceControl.5
        @Override 
        public void run() {
            if (ServiceControl.this.mediaController != null && ServiceControl.this.mediaController.getPlaybackState() != null && ServiceControl.this.screen && ServiceControl.this.mediaController.getPlaybackState().getState() == 3) {
                ServiceControl.this.handler.postDelayed(ServiceControl.this.runnable, 1000L);
                ServiceControl serviceControl = ServiceControl.this;
                serviceControl.makeStatus(serviceControl.mediaController.getPlaybackState());
            }
        }
    };
    private final MediaController.Callback callback = new MediaController.Callback() { // from class: com.controlcenter.allphone.ioscontrolcenter.service.ServiceControl.6
        @Override // android.media.session.MediaController.Callback
        public void onSessionDestroyed() {
            super.onSessionDestroyed();
            if (ServiceControl.this.mediaController != null) {
                ServiceControl.this.mediaController.unregisterCallback(ServiceControl.this.callback);
                ServiceControl.this.mediaController = null;
                if (ServiceControl.this.isViewControlExist()) {
                    ServiceControl.this.controlManager.getViewControlCenter().onEndMusic();
                }
            }
        }

        @Override // android.media.session.MediaController.Callback
        public void onPlaybackStateChanged(PlaybackState playbackState) {
            super.onPlaybackStateChanged(playbackState);
            if (playbackState == null || ServiceControl.this.mediaController == null) {
                return;
            }
            ServiceControl.this.makeStatus(playbackState);
            if (ServiceControl.this.screen && playbackState.getState() == 3) {
                ServiceControl.this.handler.removeCallbacks(ServiceControl.this.runnable);
                ServiceControl.this.handler.post(ServiceControl.this.runnable);
            }
        }

        @Override // android.media.session.MediaController.Callback
        public void onMetadataChanged(MediaMetadata mediaMetadata) {
            super.onMetadataChanged(mediaMetadata);
            if (mediaMetadata == null || ServiceControl.this.mediaController == null) {
                return;
            }
            ServiceControl.this.makeMedia(mediaMetadata);
        }
    };

    @Override // android.accessibilityservice.AccessibilityService
    public void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
    }

    @Override // android.accessibilityservice.AccessibilityService
    public void onInterrupt() {
    }

    @Override // android.accessibilityservice.AccessibilityService
    protected void onServiceConnected() {
        super.onServiceConnected();
        this.controlManager = new ControlCenterManager(this, this.musicControlResult, this.flashlightProvider);
        initMediaSession();
        addViewScreen();
    }

    private void addViewScreen() {
        if (this.addViewScreen) {
            return;
        }
        this.addViewScreen = true;
        try {
            this.manager.addView(this.vScreen, this.pScreen);
        } catch (Exception e) {
        }
    }

    private void removeViewScreen() {
        if (this.addViewScreen) {
            this.addViewScreen = false;
            try {
                this.manager.removeView(this.vScreen);
            } catch (Exception e) {
            }
        }
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        this.screen = true;
        this.flashlightProvider = new FlashlightProvider(this, new FlashlightProvider.FlashChangeResult() { // from class: com.controlcenter.allphone.ioscontrolcenter.service.ServiceControl.7
            @Override // com.controlcenter.allphone.ioscontrolcenter.util.FlashlightProvider.FlashChangeResult
            public final void onChangeFlash(boolean z) {
                ServiceControl.this.m102x914882d0(z);
            }
        });
        this.broadcastScreen = new BroadcastScreen();
//        IntentFilter intentFilter = new IntentFilter();
//        intentFilter.addAction("android.intent.action.SCREEN_ON");
//        intentFilter.addAction("android.intent.action.SCREEN_OFF");
//        intentFilter.addAction("android.intent.action.SET_WALLPAPER");
//        intentFilter.addAction("android.intent.action.WALLPAPER_CHANGED");
//        intentFilter.addAction("android.intent.action.CONFIGURATION_CHANGED");
//        registerReceiver(this.broadcastScreen, intentFilter);
        this.handler = new Handler();
        this.settingsContentObserver = new SettingsContentObserver(null);
        getApplicationContext().getContentResolver().registerContentObserver(Settings.System.CONTENT_URI, true, this.settingsContentObserver);
        this.manager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        this.vScreen = new View(this);
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        this.pScreen = layoutParams;
        if (Build.VERSION.SDK_INT >= 26) {
            layoutParams.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
        } else {
            layoutParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;
        }
        layoutParams.flags = 792;
        layoutParams.format = -3;
        layoutParams.x = 0;
        layoutParams.y = 0;
        layoutParams.width = 10;
        layoutParams.height = 10;
        layoutParams.gravity = 8388661;
    }

    public void m102x914882d0(boolean z) {
        ControlCenterManager controlCenterManager = this.controlManager;
        if (controlCenterManager != null) {
            controlCenterManager.getViewControlCenter().updateFlash(z);
        }
    }

    private void releaseControl() {
        ControlCenterManager controlCenterManager = this.controlManager;
        if (controlCenterManager != null) {
            controlCenterManager.onDestroy();
            this.controlManager = null;
        }
    }

    private void initMediaSession() {
        if (this.msm == null) {
            this.msm = (MediaSessionManager) getApplicationContext().getSystemService("media_session");
            ComponentName componentName = new ComponentName(getApplicationContext(), NotificationService.class);
            try {
                mediaChange(this.msm.getActiveSessions(componentName));
                this.msm.addOnActiveSessionsChangedListener(this.listener, componentName);
            } catch (Exception e) {
                this.msm = null;
            }
        }
    }

    @Override // android.app.Service
    public void onDestroy() {
        MediaSessionManager mediaSessionManager = this.msm;
        if (mediaSessionManager != null) {
            mediaSessionManager.removeOnActiveSessionsChangedListener(this.listener);
            this.msm = null;
            if (this.mediaController != null) {
                this.mediaController = null;
            }
        }
        unregisterReceiver(this.broadcastScreen);
        getApplicationContext().getContentResolver().unregisterContentObserver(this.settingsContentObserver);
        releaseControl();
        removeViewScreen();
        super.onDestroy();
    }


    private final class BroadcastScreen extends BroadcastReceiver {
        private BroadcastScreen() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action == null) {
                return;
            }
            char c = CharCompanionObject.MAX_VALUE;
            char c2 = '\uffff';
            switch (action.hashCode()) {
                case -2128145023:
                    if (action.equals("android.intent.action.SCREEN_OFF")) {
                        c2 = 0;
                        break;
                    }
                    break;
                case -1454123155:
                    if (action.equals("android.intent.action.SCREEN_ON")) {
                        c2 = 1;
                        break;
                    }
                    break;
                case 158859398:
                    if (action.equals("android.intent.action.CONFIGURATION_CHANGED")) {
                        c2 = 2;
                        break;
                    }
                    break;
            }
            switch (c2) {
                case 0:
                    c = 0;
                    break;
                case 1:
                    c = 1;
                    break;
                case 2:
                    c = 2;
                    break;
            }
            switch (c) {
                case 0:
                    ServiceControl.this.screen = false;
                    if (ServiceControl.this.isViewControlExist()) {
                        ServiceControl.this.controlManager.screenOff();
                        return;
                    }
                    return;
                case 1:
                    ServiceControl.this.screen = true;
                    if (CheckUtils.checkCanDrawOtherApp(ServiceControl.this)) {
                        if (ServiceControl.this.mediaController != null && ServiceControl.this.controlManager != null) {
                            if (ServiceControl.this.mediaController.getPlaybackState() != null && ServiceControl.this.mediaController.getPlaybackState().getState() == 3) {
                                ServiceControl.this.handler.removeCallbacks(ServiceControl.this.runnable);
                                ServiceControl.this.handler.post(ServiceControl.this.runnable);
                            }
                            if (ServiceControl.this.mediaController != null && ServiceControl.this.mediaController.getMetadata() != null) {
                                ServiceControl serviceControl = ServiceControl.this;
                                serviceControl.makeMedia(serviceControl.mediaController.getMetadata());
                            }
                            if (ServiceControl.this.mediaController != null && ServiceControl.this.mediaController.getPlaybackState() != null) {
                                ServiceControl serviceControl2 = ServiceControl.this;
                                serviceControl2.makeStatus(serviceControl2.mediaController.getPlaybackState());
                            }
                        }
                        if (ServiceControl.this.controlManager != null) {
                            ServiceControl.this.controlManager.updateNightShift();
                            if (ServiceControl.this.mediaController == null) {
                                ServiceControl.this.controlManager.getViewControlCenter().onEndMusic();
                                return;
                            }
                            return;
                        }
                        return;
                    }
                    return;
                case 2:
                    if (ServiceControl.this.controlManager != null) {
                        ServiceControl.this.handler.removeCallbacks(ServiceControl.this.rChangeScreen);
                        ServiceControl.this.handler.postDelayed(ServiceControl.this.rChangeScreen, 200L);
                        return;
                    }
                    return;
                default:
                    if (ServiceControl.this.isViewControlExist() && MyShare.getStatusWallpaper(context) == 1) {
                        ServiceControl.this.controlManager.getWallpaper();
                        return;
                    }
                    return;
            }
        }
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        if (intent == null) {
            return super.onStartCommand(null, i, i2);
        }
        switch (intent.getIntExtra(MyConst.DATA_ID_NOTIFICATION, -1)) {
            case 10:
                ControlCenterManager controlCenterManager = this.controlManager;
                if (controlCenterManager != null) {
                    controlCenterManager.changeSizeViewStart();
                    break;
                }
                break;
            case 11:
                if (MyShare.enableControlCenter(this)) {
                    ControlCenterManager controlCenterManager2 = this.controlManager;
                    if (controlCenterManager2 != null) {
                        controlCenterManager2.addViewStart();
                        break;
                    }
                } else {
                    ControlCenterManager controlCenterManager3 = this.controlManager;
                    if (controlCenterManager3 != null) {
                        controlCenterManager3.removeStart();
                        break;
                    }
                }
                break;
            case 13:
                ControlCenterManager controlCenterManager5 = this.controlManager;
                if (controlCenterManager5 != null) {
                    controlCenterManager5.updateNightShift();
                    break;
                }
                break;
            case 14:
                ControlCenterManager controlCenterManager6 = this.controlManager;
                if (controlCenterManager6 != null) {
                    controlCenterManager6.updateIconCustom();
                    break;
                }
                break;
            case 15:
                ControlCenterManager controlCenterManager7 = this.controlManager;
                if (controlCenterManager7 != null) {
                    controlCenterManager7.stopViewRecord();
                    break;
                }
                break;
            case 16:
            case 17:
                ControlCenterManager controlCenterManager8 = this.controlManager;
                if (controlCenterManager8 != null) {
                    controlCenterManager8.getWallpaper();
                    break;
                }
                break;
            case 18:
                ControlCenterManager controlCenterManager9 = this.controlManager;
                if (controlCenterManager9 != null) {
                    controlCenterManager9.setSetting(true);
                    break;
                }
                break;
            case 19:
                ControlCenterManager controlCenterManager92 = this.controlManager;
                if (controlCenterManager92 != null) {
                    controlCenterManager92.setSetting(false);
                    break;
                }
                break;
        }
        return super.onStartCommand(intent, i, i2);
    }


    private class SettingsContentObserver extends ContentObserver {
        private final AudioManager audioManager;

        @Override // android.database.ContentObserver
        public boolean deliverSelfNotifications() {
            return false;
        }

        public SettingsContentObserver(Handler handler) {
            super(handler);
            this.audioManager = (AudioManager) ServiceControl.this.getApplicationContext().getSystemService("audio");
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean z) {
            int streamVolume = this.audioManager.getStreamVolume(3);
            if (ServiceControl.this.controlManager != null) {
                ServiceControl.this.controlManager.getViewControlCenter().updateVolume(streamVolume);
            }
        }
    }

    public void mediaChange(List<MediaController> list) {
        if (!isViewControlExist() || list == null || list.size() == 0) {
            return;
        }
        this.controllers = list;
        this.handler.removeCallbacks(this.rChooseMedia);
        this.handler.postDelayed(this.rChooseMedia, 1000L);
    }

    public void makeMedia(MediaMetadata mediaMetadata) {
        if (isViewControlExist() && this.screen) {
            this.controlManager.getViewControlCenter().updateMetadata(mediaMetadata, this.mediaController);
        }
    }

    public void makeStatus(PlaybackState playbackState) {
        if (isViewControlExist() && this.screen) {
            this.controlManager.getViewControlCenter().updateStatus(playbackState, this.mediaController.getPlaybackInfo().getCurrentVolume());
        }
    }

    public boolean isViewControlExist() {
        return this.controlManager != null && CheckUtils.checkCanDrawOtherApp(this) && MyShare.enableControlCenter(this);
    }
}
