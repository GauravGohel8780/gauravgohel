package com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.viewprogress;

import android.content.Context;
import android.widget.RelativeLayout;

import com.controlcenter.allphone.ioscontrolcenter.controlcenter.ViewControlCenter;
import com.controlcenter.allphone.ioscontrolcenter.controlcenter.view.BaseViewControl;


public class ViewProgress extends BaseViewControl {
    private BaseViewStatus baseViewStatus;
    private OnProgressChange onProgressChange;
    private int progressStart;
    private final CustomView vProgress;

    public void setOnProgressChange(OnProgressChange onProgressChange) {
        this.onProgressChange = onProgressChange;
    }

    public ViewProgress(Context context) {
        super(context);
        setBackgroundColor(0);
        CustomView customView = new CustomView(context);
        this.vProgress = customView;
        addView(customView, -1, -1);
        setOnTouchListener(new OnTouchProgress(context, new OnTouchProgress.TouchResult() {
            @Override
            public void onTouchDown() {
                ViewProgress.this.onProgressChange.onTouchDown();
                ViewProgress.this.touchDown();
                ViewProgress viewProgress = ViewProgress.this;
                viewProgress.progressStart = viewProgress.vProgress.getProgress();
            }

            @Override
            public void onMoveVertical(float f) {
                int height = (int) (ViewProgress.this.progressStart - ((100.0f * f) / ViewProgress.this.getHeight()));
                if (height < 0) {
                    height = 0;
                } else if (height > 100) {
                    height = 100;
                }
                ViewProgress.this.setProgress(height);
                if (ViewProgress.this.onProgressChange != null) {
                    ViewProgress.this.onProgressChange.onChange(ViewProgress.this, height);
                }
            }

            @Override
            public void onLongClick() {
                if (ViewProgress.this.onProgressChange != null) {
                    ViewProgress.this.onProgressChange.onLongClick(ViewProgress.this);
                }
            }

            @Override
            public void onTouchUp() {
                ViewProgress.this.onProgressChange.onTouchUp();
                ViewProgress.this.touchUp();
            }
        }));
    }

    public void setRa(float f) {
        this.vProgress.setRa(f);
    }

    public int getProgress() {
        return this.vProgress.getProgress();
    }

    public void setBaseViewStatus(BaseViewStatus baseViewStatus, int i) {
        this.baseViewStatus = baseViewStatus;
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(i, i);
        layoutParams.addRule(12);
        addView(baseViewStatus, layoutParams);
    }

    public void setBaseViewStatusOut(BaseViewStatus baseViewStatus) {
        this.baseViewStatus = baseViewStatus;
    }

    public void setProgress(int i) {
        this.vProgress.setProgress(i);
        BaseViewStatus baseViewStatus = this.baseViewStatus;
        if (baseViewStatus != null) {
            baseViewStatus.setProgress(i);
        }
    }

    @Override
    public boolean onLongClick(ViewControlCenter viewControlCenter) {
        BaseViewStatus baseViewStatus = this.baseViewStatus;
        if (baseViewStatus == null) {
            return false;
        }
        if (baseViewStatus instanceof ViewStatusBright) {
            viewControlCenter.showBigBright();
            return true;
        }
        viewControlCenter.showBigVolume();
        return true;
    }
}
