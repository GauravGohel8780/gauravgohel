package com.controlcenter.allphone.ioscontrolcenter.util;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Environment;
import android.widget.Toast;


import androidx.core.app.NotificationCompat;
import androidx.core.view.MotionEventCompat;
import androidx.core.view.ViewCompat;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemStatusBattery;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Array;


public class OtherUtils {
    public static Bitmap getBitmapFromAsset(Context context, String str) {
        try {
            InputStream open = context.getAssets().open(str);
            Bitmap decodeStream = BitmapFactory.decodeStream(open);
            open.close();
            return decodeStream;
        } catch (IOException e) {
            return BitmapFactory.decodeResource(context.getResources(), R.drawable.ic_music_icon);
        }
    }

    public static GradientDrawable bgIcon(int i, float f) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(GradientDrawable.RECTANGLE);
        gradientDrawable.setCornerRadius((42.0f * f) / 180.0f);
        gradientDrawable.setColor(i);
        return gradientDrawable;
    }

    public static GradientDrawable makeOval(int i) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(GradientDrawable.OVAL);
        gradientDrawable.setSize(150, 150);
        gradientDrawable.setColor(i);
        return gradientDrawable;
    }

    public static GradientDrawable bgTopSearch(int i, int i2) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(GradientDrawable.RECTANGLE);
        float f = (i2 * 42.0f) / 120.0f;
        gradientDrawable.setCornerRadii(new float[]{f, f, f, f, 0.0f, 0.0f, 0.0f, 0.0f});
        gradientDrawable.setColor(i);
        return gradientDrawable;
    }

    public static GradientDrawable bgLayout(Context context, int i) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(GradientDrawable.RECTANGLE);
        gradientDrawable.setCornerRadius((context.getResources().getDisplayMetrics().widthPixels * 4.0f) / 80.0f);
        gradientDrawable.setColor(i);
        return gradientDrawable;
    }

    public static int getWidthScreen(Context context) {
        return Math.min(context.getResources().getDisplayMetrics().widthPixels, context.getResources().getDisplayMetrics().heightPixels);
    }

    public static int getHeightScreen(Context context) {
        return Math.max(context.getResources().getDisplayMetrics().widthPixels, context.getResources().getDisplayMetrics().heightPixels);
    }

    public static String setNum(int i) {
        if (i < 10) {
            return "0" + i;
        }
        return "" + i;
    }

    public static String createChannel(Service service) {
        NotificationManager notificationManager = (NotificationManager) service.getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            String channelName = service.getString(R.string.app_name);
            NotificationChannel notificationChannel = null;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                notificationChannel = new NotificationChannel(channelName, "iControl", NotificationManager.IMPORTANCE_DEFAULT);
                notificationChannel.enableLights(true);
                notificationChannel.setLightColor(Color.BLUE);
                notificationManager.createNotificationChannel(notificationChannel);
            }
            return channelName;
        } else {
            // If notification manager is null, stop the service
            service.stopSelf();
            return null;
        }
    }

    public static Bitmap cropBitmapTransparency(Bitmap bitmap) {
        int i2;
        int i;
        int width;
        int width2 = bitmap.getWidth();
        int height = bitmap.getHeight();
        int i22 = 0;
        while (true) {
            if (i22 >= bitmap.getWidth()) {
                i2 = 0;
                break;
            } else if (Color.alpha(bitmap.getPixel(i22, bitmap.getHeight() / 2)) > 0) {
                i2 = i22;
                break;
            } else {
                i22++;
            }
        }
        int i3 = 0;
        while (true) {
            if (i3 >= bitmap.getHeight()) {
                i = 0;
                break;
            } else if (Color.alpha(bitmap.getPixel(bitmap.getWidth() / 2, i3)) > 0) {
                int i4 = i3;
                i = i4;
                break;
            } else {
                i3++;
            }
        }
        int i5 = bitmap.getWidth();
        int width22 = i5 - 1;
        while (true) {
            if (width22 < 0) {
                width = width2;
                break;
            } else if (Color.alpha(bitmap.getPixel(width22, bitmap.getHeight() / 2)) > 0) {
                int width3 = width22;
                width = width3;
                break;
            } else {
                width22--;
            }
        }
        int width4 = bitmap.getHeight();
        int height2 = width4 - 1;
        while (true) {
            if (height2 < 0) {
                break;
            } else if (Color.alpha(bitmap.getPixel(bitmap.getWidth() / 2, height2)) > 0) {
                height = height2;
                break;
            } else {
                height2--;
            }
        }
        if (width < i2 || height < i) {
            return null;
        }
        return Bitmap.createBitmap(bitmap, i2, i, width - i2, height - i);
    }

    public static String getWifiName(Context context) {
        WifiInfo connectionInfo;
        NetworkInfo.DetailedState detailedStateOf;
        try {
            WifiManager wifiManager = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifiManager.isWifiEnabled() && (connectionInfo = wifiManager.getConnectionInfo()) != null && ((detailedStateOf = WifiInfo.getDetailedStateOf(connectionInfo.getSupplicantState())) == NetworkInfo.DetailedState.CONNECTED || detailedStateOf == NetworkInfo.DetailedState.OBTAINING_IPADDR)) {
                return connectionInfo.getSSID();
            }
        } catch (Exception e) {
        }
        return context.getString(R.string.on);
    }

    public static String longToTime(long j, boolean z) {
        long j2 = j / 1000;
        StringBuilder sb = new StringBuilder();
        if (z) {
            sb.append("-");
        }
        sb.append(j2 / 60);
        sb.append(":");
        long j3 = j2 % 60;
        if (j3 < 10) {
            sb.append("0");
        }
        sb.append(j3);
        return sb.toString();
    }

    public static ItemStatusBattery getItemStatusBattery(Context context) {
        Intent registerReceiver = context.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
        int i = 100;
        boolean z = false;
        if (registerReceiver != null) {
            int intExtra = registerReceiver.getIntExtra(NotificationCompat.CATEGORY_STATUS, -1);
            if (intExtra == 2 || intExtra != 5) {
            }
            z = true;
            i = (registerReceiver.getIntExtra("level", -1) * 100) / registerReceiver.getIntExtra("scale", -1);
        }
        return new ItemStatusBattery(z, i);
    }

    public static Bitmap drawableToBitmap(Context context, Drawable drawable) {
        Bitmap createBitmap;
        if (drawable == null) {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 4;
            options.inDither = false;
            options.inPurgeable = true;
            return BitmapFactory.decodeResource(context.getResources(), R.drawable.img_bg_def, options);
        }
        if (drawable instanceof BitmapDrawable) {
            BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;
            if (bitmapDrawable.getBitmap() != null) {
                return bitmapDrawable.getBitmap();
            }
        }
        if (drawable.getIntrinsicWidth() <= 0 || drawable.getIntrinsicHeight() <= 0) {
            createBitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        } else {
            createBitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        }
        Canvas canvas = new Canvas(createBitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return createBitmap;
    }

    public static Bitmap fastBlur(Bitmap bitmap, float f, int i) {
        int i54;
        int i11;
        int[] iArr14;
        int i112;
        int i2;
        int[] iArr;
        int i22 = i;
        Bitmap createScaledBitmap = Bitmap.createScaledBitmap(bitmap, Math.round(bitmap.getWidth() * f), Math.round(bitmap.getHeight() * f), false);
        Bitmap copy = createScaledBitmap.copy(createScaledBitmap.getConfig(), true);
        if (i22 < 1) {
            return null;
        }
        int width = copy.getWidth();
        int height = copy.getHeight();
        int i3 = width * height;
        int[] iArr2 = new int[i3];
        int[] iArr22 = iArr2;
        copy.getPixels(iArr2, 0, width, 0, 0, width, height);
        int i39 = width - 1;
        int i5 = height - 1;
        int i6 = i22 + i22 + 1;
        int[] iArr3 = new int[i3];
        int[] iArr4 = new int[i3];
        int[] iArr5 = new int[i3];
        int[] iArr6 = new int[Math.max(width, height)];
        int i7 = (i6 + 1) >> 1;
        int abs = i7 * i7;
        int i9 = abs * 256;
        Bitmap copy2 = copy;
        int[] iArr7 = new int[i9];
        for (int i32 = 0; i32 < i9; i32++) {
            iArr7[i32] = i32 / abs;
        }
        int[] iArr72 = iArr7;
        int[][] iArr8 = new int[i6][3];
        int i61 = i22 + 1;
        int i13 = 0;
        int i14 = 0;
        int i12 = 0;
        while (i12 < height) {
            Bitmap bitmap2 = copy2;
            int i15 = height;
            int i16 = 0;
            int i17 = 0;
            int i18 = 0;
            int i19 = 0;
            int i20 = 0;
            int i21 = 0;
            int i222 = 0;
            int i23 = 0;
            int i24 = -i22;
            int i25 = 0;
            while (i24 <= i22) {
                int i26 = i5;
                int[] iArr9 = iArr6;
                int i8 = abs;
                int i72 = i7;
                int i27 = iArr22[i13 + Math.min(i39, Math.max(i24, 0))];
                int[] iArr10 = iArr8[i24 + i22];
                iArr10[0] = (i27 & 16711680) >> 16;
                iArr10[1] = (i27 & MotionEventCompat.ACTION_POINTER_INDEX_MASK) >> 8;
                iArr10[2] = i27 & 255;
                int abs2 = i61 - Math.abs(i24);
                i25 += iArr10[0] * abs2;
                i16 += iArr10[1] * abs2;
                i17 += iArr10[2] * abs2;
                if (i24 > 0) {
                    i21 += iArr10[0];
                    i222 += iArr10[1];
                    i23 += iArr10[2];
                } else {
                    i18 += iArr10[0];
                    i19 += iArr10[1];
                    i20 += iArr10[2];
                }
                i24++;
                i5 = i26;
                iArr6 = iArr9;
                abs = i8;
                i7 = i72;
            }
            int i82 = abs;
            int i73 = i7;
            int i83 = i5;
            int[] iArr11 = iArr6;
            int i29 = i22;
            int i30 = i25;
            int i242 = 0;
            while (i242 < width) {
                iArr3[i13] = iArr72[i30];
                iArr4[i13] = iArr72[i16];
                iArr5[i13] = iArr72[i17];
                int i322 = i30 - i18;
                int i33 = i16 - i19;
                int i34 = i17 - i20;
                int[] iArr12 = iArr8[((i29 - i22) + i6) % i6];
                int i35 = i18 - iArr12[0];
                int i36 = i19 - iArr12[1];
                int i37 = i20 - iArr12[2];
                if (i12 == 0) {
                    iArr = iArr72;
                    i2 = i22;
                    iArr11[i242] = Math.min(i242 + i22 + 1, i39);
                } else {
                    i2 = i22;
                    iArr = iArr72;
                }
                int i38 = iArr22[i14 + iArr11[i242]];
                iArr12[0] = (i38 & 16711680) >> 16;
                iArr12[1] = (i38 & MotionEventCompat.ACTION_POINTER_INDEX_MASK) >> 8;
                int i4 = i39;
                int i42 = i38 & 255;
                iArr12[2] = i42;
                int i392 = i21 + iArr12[0];
                int i40 = i222 + iArr12[1];
                int i41 = i23 + iArr12[2];
                i30 = i322 + i392;
                i16 = i33 + i40;
                i17 = i34 + i41;
                i29 = (i29 + 1) % i6;
                int[] iArr13 = iArr8[i29 % i6];
                i18 = i35 + iArr13[0];
                i19 = i36 + iArr13[1];
                i20 = i37 + iArr13[2];
                i21 = i392 - iArr13[0];
                i222 = i40 - iArr13[1];
                i23 = i41 - iArr13[2];
                i13++;
                i242++;
                iArr72 = iArr;
                i39 = i4;
                i22 = i2;
            }
            i14 += width;
            i12++;
            copy2 = bitmap2;
            height = i15;
            i5 = i83;
            iArr6 = iArr11;
            abs = i82;
            i7 = i73;
        }
        int i28 = i22;
        Bitmap bitmap3 = copy2;
        int[] iArr142 = iArr72;
        int i422 = i5;
        int[] iArr15 = iArr6;
        int i43 = height;
        int width2 = width;
        int i52 = 0;
        int i432 = i43;
        int i59 = i6;
        int i65 = i422;
        int i210 = i28;
        while (i52 < width2) {
            int i423 = i65;
            int i424 = -i210;
            int i46 = i59;
            int[] iArr16 = iArr22;
            int i47 = 0;
            int i48 = 0;
            int i49 = 0;
            int i50 = 0;
            int i51 = 0;
            int i522 = 0;
            int i53 = 0;
            int i55 = i424 * width2;
            int i56 = 0;
            int i57 = 0;
            int i45 = i424;
            int[] iArr62 = iArr6;
            int i552 = i55;
            while (i45 <= i210) {
                int i58 = width2;
                int i62 = i59;
                int max = Math.max(0, i552) + i52;
                int[] iArr17 = iArr8[i45 + i210];
                iArr17[0] = iArr3[max];
                iArr17[1] = iArr4[max];
                iArr17[2] = iArr5[max];
                int abs22 = i61 - Math.abs(i45);
                i56 += iArr3[max] * abs22;
                i57 += iArr4[max] * abs22;
                i47 += iArr5[max] * abs22;
                if (i45 > 0) {
                    i51 += iArr17[0];
                    i522 += iArr17[1];
                    i53 += iArr17[2];
                } else {
                    i48 += iArr17[0];
                    i49 += iArr17[1];
                    i50 += iArr17[2];
                }
                int i592 = i423;
                if (i45 < i592) {
                    i552 += i58;
                }
                i45++;
                i423 = i592;
                width2 = i58;
                i59 = i62;
            }
            int i63 = width2;
            int i75 = i423;
            int i622 = i210;
            int i632 = i52;
            int i64 = i47;
            int i652 = i432;
            int i66 = i57;
            int width3 = 0;
            while (true) {
                int i542 = i45;
                i54 = i652;
                if (width3 < i54) {
                    iArr16[i632] = (iArr16[i632] & ViewCompat.MEASURED_STATE_MASK) | (iArr142[i56] << 16) | (iArr142[i66] << 8) | iArr142[i64];
                    int i68 = i56 - i48;
                    int i69 = i66 - i49;
                    int i70 = i64 - i50;
                    int[] iArr18 = iArr8[((i622 - i210) + i46) % i46];
                    int i71 = i48 - iArr18[0];
                    int i722 = i49 - iArr18[1];
                    int i732 = i50 - iArr18[2];
                    if (i52 != 0) {
                        i11 = i61;
                        iArr14 = iArr142;
                        i112 = i75;
                    } else {
                        iArr14 = iArr142;
                        int i10 = width3 + i61;
                        i11 = i61;
                        i112 = i75;
                        iArr15[width3] = Math.min(i10, i112) * i63;
                    }
                    int i74 = iArr15[width3] + i52;
                    iArr18[0] = iArr3[i74];
                    iArr18[1] = iArr4[i74];
                    iArr18[2] = iArr5[i74];
                    int i752 = i51 + iArr18[0];
                    int i76 = i522 + iArr18[1];
                    int i77 = i53 + iArr18[2];
                    i56 = i68 + i752;
                    i66 = i69 + i76;
                    i64 = i70 + i77;
                    i622 = (i622 + 1) % i46;
                    int[] iArr19 = iArr8[i622];
                    i48 = i71 + iArr19[0];
                    i49 = i722 + iArr19[1];
                    i50 = i732 + iArr19[2];
                    i51 = i752 - iArr19[0];
                    i522 = i76 - iArr19[1];
                    i53 = i77 - iArr19[2];
                    i632 += i63;
                    width3++;
                    i210 = i;
                    i75 = i112;
                    i652 = i54;
                    i45 = i542;
                    iArr142 = iArr14;
                    i61 = i11;
                }
            }
        }
        int i78 = width2;
        bitmap3.setPixels(iArr22, 0, i78, 0, 0, i78, i432);
        return bitmap3;
    }




    public static String getStore(Context context) {
        if (Build.VERSION.SDK_INT >= 29) {
            File externalFilesDir = context.getExternalFilesDir(null);
            if (externalFilesDir != null) {
                return externalFilesDir.getAbsolutePath();
            }
            return "/storage/emulated/0/Android/data/" + context.getPackageName();
        }
        return Environment.getExternalStorageDirectory() + "/Android/data/" + context.getPackageName();
    }

    public static String makePathWallpaper(Context context) {
        String str = getStore(context) + "/wallpaper";
        File file = new File(str);
        if (!file.exists()) {
            file.mkdirs();
        }
        return str;
    }

    public static void clearWallpaper(final Context context, final String str) {
        new Thread(new Runnable() { // from class: com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils.1
            @Override 
            public final void run() {
                OtherUtils.lambda$clearWallpaper$0(context, str);
            }
        }).start();
    }

    public static void lambda$clearWallpaper$0(Context context, String str) {
        File[] listFiles;
        File file = new File(makePathWallpaper(context));
        if (!file.exists() || (listFiles = file.listFiles()) == null || listFiles.length <= 0) {
            return;
        }
        for (File file2 : listFiles) {
            if (!file2.getPath().contains(str)) {
                file2.delete();
            }
        }
    }

    public static void openLink(Context context, String str) {
        try {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse(str.replace("HTTPS", "https")));
            context.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(context, context.getString(R.string.no_browser), Toast.LENGTH_SHORT).show();
        }
    }
}
