package com.controlcenter.allphone.ioscontrolcenter.item;


public class ItemStrengthMobile {
    private int level = -1;
    private int type = 0;

    public void setLevel(int i) {
        this.level = i;
    }

    public void setMobile(int i) {
        this.type = i;
    }

    public int getLevel() {
        return this.level;
    }

    public int getType() {
        return this.type;
    }
}
