package com.controlcenter.allphone.ioscontrolcenter;

import android.os.Bundle;

import com.controlcenter.allphone.ioscontrolcenter.custom.ViewCustom;


public class ActivityCustom extends BaseActivity {
    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(new ViewCustom(this));

    }
}
