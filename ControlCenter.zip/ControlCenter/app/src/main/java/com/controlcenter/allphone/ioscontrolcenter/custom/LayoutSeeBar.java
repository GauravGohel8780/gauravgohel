package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.widget.LinearLayout;

import androidx.core.view.ViewCompat;


public class LayoutSeeBar extends LinearLayout implements ViewSeekbar.OnSeekBarChange {
    private SeeBarResult onSeekBarChange;
    private final TextB tv;
    private final ViewSeekbar viewSeekbar;

    
    public interface SeeBarResult {
        void onChange(View view, int i);
    }

    @Override
    public void onChangeProgress(View view, long j) {
    }

    public void setSv(MyScrollView myScrollView) {
        this.viewSeekbar.setMyScrollView(myScrollView);
    }

    public void setOnSeekBarChange(SeeBarResult seeBarResult) {
        this.onSeekBarChange = seeBarResult;
    }

    public LayoutSeeBar(Context context) {
        super(context);
        setOrientation(LinearLayout.VERTICAL);
        int i = getResources().getDisplayMetrics().widthPixels;
        int i2 = i / 20;
        View view = new View(getContext());
        view.setBackgroundColor(Color.parseColor("#3aaaaaaa"));
        addView(view, -1, 2);
        TextB textB = new TextB(getContext());
        this.tv = textB;
        textB.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        textB.setTextSize(0, (i * 3.5f) / 100.0f);
        LayoutParams layoutParams = new LayoutParams(-2, -2);
        layoutParams.setMargins(i2, i2 / 2, i2 / 8, 0);
        addView(textB, layoutParams);
        ViewSeekbar viewSeekbar = new ViewSeekbar(getContext());
        this.viewSeekbar = viewSeekbar;
        viewSeekbar.setMax(100L);
        viewSeekbar.setOnSeekBarChange(this);
        LayoutParams layoutParams2 = new LayoutParams(-1, (i * 12) / 100);
        layoutParams2.setMargins(i2, 0, i2, 0);
        addView(viewSeekbar, layoutParams2);
    }

    public void setData(int i, boolean z) {
        setId(i);
        this.tv.setText(i);
        if (z) {
            this.viewSeekbar.setModeColor();
        } else {
            this.viewSeekbar.setModeVolume();
        }
    }

    public void setColor(int i) {
        this.viewSeekbar.setColorSeekbar(i);
    }

    public void setProgress(int i) {
        this.viewSeekbar.setProgress(i);
    }

    @Override
    public void onUp(View view) {
        this.onSeekBarChange.onChange(this, (int) this.viewSeekbar.getProgress());
    }
}
