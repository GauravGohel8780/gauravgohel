package com.controlcenter.allphone.ioscontrolcenter.dialog;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.core.view.ViewCompat;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.custom.TextB;
import com.controlcenter.allphone.ioscontrolcenter.custom.TextM;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class DialogRequestLocation extends BaseDialog {
    private final DialogResult dialogResult;

    public DialogRequestLocation(Context context, DialogResult dialogResult) {
        super(context);
        this.dialogResult = dialogResult;
    }

    @Override 
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        int i = getContext().getResources().getDisplayMetrics().widthPixels;
        LinearLayout linearLayout = new LinearLayout(getContext());
        linearLayout.setGravity(17);
        LinearLayout linearLayout2 = new LinearLayout(getContext());
        linearLayout2.setOrientation(LinearLayout.VERTICAL);
        linearLayout2.setGravity(1);
        linearLayout.addView(linearLayout2, (i * 72) / 100, -2);
        setContentView(linearLayout);
        int i2 = i / 25;
        linearLayout2.setBackground(OtherUtils.bgLayout(getContext(), Color.parseColor("#eaffffff")));
        TextB textB = new TextB(getContext());
        textB.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        float f = i;
        float f2 = (4.3f * f) / 100.0f;
        textB.setTextSize(0, f2);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        int i3 = (i2 * 4) / 3;
        layoutParams.setMargins(i2, i3, i2, i2 / 6);
        linearLayout2.addView(textB, layoutParams);
        textB.setText(R.string.location);
        textB.setSingleLine();
        textB.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        textB.setSelected(true);
        TextM textM = new TextM(getContext());
        textM.setText(R.string.content_strength);
        textM.setGravity(1);
        textM.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        textM.setEllipsize(TextUtils.TruncateAt.END);
        textM.setTextSize(0, (3.3f * f) / 100.0f);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.setMargins(i2, 0, i2, i3);
        linearLayout2.addView(textM, layoutParams2);
        ImageView imageView = new ImageView(getContext());
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setAdjustViewBounds(true);
        imageView.setImageResource(R.drawable.img_mobile);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams((i * 15) / 100, -2);
        layoutParams3.setMargins(0, 0, 0, i2);
        linearLayout2.addView(imageView, layoutParams3);
        linearLayout2.addView(vDivider(), -1, 1);
        TextB textB2 = new TextB(getContext());
        textB2.setId(123);
        textB2.setTextColor(Color.parseColor("#3478f6"));
        textB2.setTextSize(0, f2);
        textB2.setText(R.string.allow);
        textB2.setOnClickListener(new View.OnClickListener() {
            @Override 
            public final void onClick(View view) {
                DialogRequestLocation.this.onClick(view);
            }
        });
        textB2.setGravity(17);
        int i4 = (int) ((11.5f * f) / 100.0f);
        linearLayout2.addView(textB2, -1, i4);
        linearLayout2.addView(vDivider(), -1, 1);
        TextM textM2 = new TextM(getContext());
        textM2.setId(124);
        textM2.setTextColor(Color.parseColor("#3478f6"));
        textM2.setTextSize(0, f2);
        textM2.setText(R.string.cancel);
        textM2.setOnClickListener(new View.OnClickListener() {
            @Override 
            public final void onClick(View view) {
                DialogRequestLocation.this.onClick(view);
            }
        });
        textM2.setGravity(17);
        linearLayout2.addView(textM2, -1, i4);
    }

    public void onClick(View view) {
        if (this.dialogResult != null) {
            if (view.getId() == 123) {
                this.dialogResult.onAction();
            } else {
                this.dialogResult.onCancel();
            }
        }
        cancel();
    }

    private View vDivider() {
        View view = new View(getContext());
        view.setBackgroundColor(Color.parseColor("#30000000"));
        return view;
    }
}
