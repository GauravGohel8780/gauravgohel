package com.controlcenter.allphone.ioscontrolcenter.controlcenter.custom;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.controlcenter.allphone.ioscontrolcenter.R;


public class ViewBgControl extends RelativeLayout {
    private final ImageView imBlur;

    public ViewBgControl(Context context) {
        super(context);
        ImageView imageView = new ImageView(context);
        this.imBlur = imageView;
        imageView.setImageResource(R.drawable.img_bg_def);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        addView(imageView, -1, -1);
        View view = new View(context);
        view.setBackgroundColor(Color.parseColor("#50000000"));
        addView(view, -1, -1);
    }

    public void setBgBlur(Bitmap bitmap) {
        this.imBlur.setVisibility(View.VISIBLE);
        this.imBlur.setImageBitmap(bitmap);
    }

    public void clearBg() {
        this.imBlur.setImageResource(0);
        this.imBlur.setVisibility(View.GONE);
    }
}
