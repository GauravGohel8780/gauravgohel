package com.controlcenter.allphone.ioscontrolcenter.custom;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import android.widget.LinearLayout;

import androidx.core.view.ViewCompat;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.util.MyShare;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;
import com.flask.colorpicker.ColorPickerView;
import com.flask.colorpicker.OnColorSelectedListener;
import com.flask.colorpicker.builder.ColorPickerClickListener;
import com.flask.colorpicker.builder.ColorPickerDialogBuilder;


public class LayoutColor extends LinearLayout {
    private ColorResult colorResult;
    private final ViewChangeColor viewChangeColor;

    
    public interface ColorResult {
        void onColorChange(int i);
    }

    public static void lambda$changeColor$0(int i) {
    }

    public static void lambda$changeColor$2(DialogInterface dialogInterface, int i) {
    }

    public void setColorResult(ColorResult colorResult) {
        this.colorResult = colorResult;
    }

    public LayoutColor(Context context) {
        super(context);
        setOrientation(LinearLayout.HORIZONTAL);
        setGravity(16);
        int i = getResources().getDisplayMetrics().widthPixels;
        TextB textB = new TextB(getContext());
        textB.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        textB.setText(R.string.color);
        textB.setTextSize(0, (i * 3.5f) / 100.0f);
        LayoutParams layoutParams = new LayoutParams(0, -2, 1.0f);
        layoutParams.setMargins(i / 20, 0, 0, 0);
        addView(textB, layoutParams);
        ViewChangeColor viewChangeColor = new ViewChangeColor(context);
        this.viewChangeColor = viewChangeColor;
        viewChangeColor.setColor(MyShare.getColorNotification(context));
        int i2 = (i * 14) / 100;
        addView(viewChangeColor, i2, i2);
        viewChangeColor.setOnClickListener(new OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                LayoutColor.this.changeColor(view);
            }
        });
    }

    public void changeColor(View view) {
        ColorPickerDialogBuilder.with(getContext()).setTitle(getContext().getString(R.string.choose_color)).wheelType(ColorPickerView.WHEEL_TYPE.FLOWER).density(12).setOnColorSelectedListener(new OnColorSelectedListener() { // from class: com.controlcenter.allphone.ioscontrolcenter.custom.LayoutColor.4
            @Override 
            public final void onColorSelected(int i) {
                LayoutColor.lambda$changeColor$0(i);
            }
        }).setPositiveButton(getContext().getString(R.string.ok_pre), new ColorPickerClickListener() { 
            @Override
            public final void onClick(DialogInterface dialogInterface, int i, Integer[] numArr) {
                LayoutColor.this.m61xba4c508c(dialogInterface, i, numArr);
            }
        }).setNegativeButton(getContext().getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public final void onClick(DialogInterface dialogInterface, int i) {
                LayoutColor.lambda$changeColor$2(dialogInterface, i);
            }
        }).build().show();
    }

    public void m61xba4c508c(DialogInterface dialogInterface, int i, Integer[] numArr) {
        this.viewChangeColor.setColor(i);
        this.colorResult.onColorChange(i);
    }

    
    public class ViewChangeColor extends View {
        private final Paint paint;

        public ViewChangeColor(Context context) {
            super(context);
            int i = getResources().getDisplayMetrics().widthPixels;
            Paint paint = new Paint(1);
            this.paint = paint;
            paint.setShadowLayer((i * 1.4f) / 100.0f, 0.0f, 0.0f, Color.parseColor("#aaaaaa"));
            paint.setStyle(Paint.Style.FILL);
        }

        @Override 
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.drawCircle(getWidth() / 2.0f, getHeight() / 2.0f, OtherUtils.getWidthScreen(getContext()) / 25.0f, this.paint);
        }

        public void setColor(int i) {
            this.paint.setColor(i);
            this.paint.setAlpha(255);
            invalidate();
        }
    }
}
