package com.controlcenter.allphone.ioscontrolcenter.dialog;


public interface DialogResult {
    void onAction();

    void onCancel();
}
