package com.controlcenter.allphone.ioscontrolcenter.view;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;
import static com.iten.tenoku.utils.MyApplication.sharedPreferencesHelper;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.BaseRequestOptions;
import com.bumptech.glide.request.RequestOptions;
import com.controlcenter.allphone.ioscontrolcenter.ActivityCustom;
import com.controlcenter.allphone.ioscontrolcenter.ActivitySetupVideo;
import com.controlcenter.allphone.ioscontrolcenter.MainActivity;
import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.custom.BaseSetting;
import com.controlcenter.allphone.ioscontrolcenter.custom.ViewItem;
import com.controlcenter.allphone.ioscontrolcenter.custom.ViewNightShiftSetting;
import com.controlcenter.allphone.ioscontrolcenter.dialog.DialogChangeBg;
import com.controlcenter.allphone.ioscontrolcenter.dialog.DialogRequestLocation;
import com.controlcenter.allphone.ioscontrolcenter.dialog.DialogResult;
import com.controlcenter.allphone.ioscontrolcenter.dialog.DialogWallpaperResult;
import com.controlcenter.allphone.ioscontrolcenter.dialog.RateDialog;
import com.controlcenter.allphone.ioscontrolcenter.util.MyConst;
import com.controlcenter.allphone.ioscontrolcenter.util.MyShare;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.yalantis.ucrop.view.CropImageView;

import java.util.List;


public class ViewControlCenterUi extends BaseSetting {
    private static final int ID_VIEW_BG = 3;
    private static final int ID_VIEW_CUSTOM = 1;
    private static final int ID_VIEW_POSITION = 5;
    private static final int ID_VIEW_SIZE = 4;
    private static final int ID_VIEW_TOUCH = 6;
    private static final int ID_VIEW_VIDEO = 2;
    private MainActivity activity;
    private int idViewClick;
    private final LinearLayout llBot;
    private final LinearLayout llOther;
    private final LinearLayout llTop;
    private String pkgAds;
    private RelativeLayout rlMain;
    private final int[] sizeScreen;
    private ViewItem vPremium, viads1, viads2;
    private final ViewNightShiftSetting viewNightShift;

    public void setActivity(MainActivity mainActivity, RelativeLayout relativeLayout) {
        this.activity = mainActivity;
        this.rlMain = relativeLayout;
    }

    public ViewControlCenterUi(Context context) {
        super(context);
        this.sizeScreen = MyShare.getSizes(context);
        setTitle(R.string.control_center);
        int i = getResources().getDisplayMetrics().widthPixels;
        int i2 = i / 7;
        ImageView imageView = new ImageView(context);
        imageView.setAdjustViewBounds(true);
        LayoutParams layoutParams = new LayoutParams(-1, -2);
        int i3 = i / 25;
        layoutParams.setMargins(i3, i / 30, i3, i / 20);
        addView(imageView, layoutParams);
        int i4 = i - ((i * 2) / 25);
        Glide.with(imageView).load("file:///android_asset/img_header.jpg").apply((BaseRequestOptions<?>) new RequestOptions().override(i4, (i4 * CropImageView.DEFAULT_IMAGE_TO_CROP_BOUNDS_ANIM_DURATION) / 1024).transform(new RoundedCorners((int) getResources().getDimension(R.dimen.border_layout_setting)))).into(imageView);
        checkPer();
        if (!this.permissionDone) {
            addLayoutPer();
        }

        LinearLayout llads0 = makeL(4);
        viads1 = new ViewItem(context);
        llads0.addView(viads1, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));

        getInstance((Activity) getContext()).ShowNativeAd(llads0, AdUtils.NativeType.NATIVE_MEDIUM);

        LinearLayout makeL2 = makeL(4);
        this.llTop = makeL2;
        LinearLayout makeL3 = makeL(4);
        this.llBot = makeL3;
        LinearLayout makeL4 = makeL(4);
        this.llOther = makeL4;
        checkPer();


        ViewItem viewItem2 = new ViewItem(context);
        viewItem2.setId(1);
        viewItem2.addSwitch(new ViewItem.SwitchListener() {
            @Override
            public final void onSwitchChange(ViewItem viewItem3, boolean z) {
                ViewControlCenterUi.this.onSwitchEnable(viewItem3, z);
            }
        }, MyShare.enableControlCenter(context));
        viewItem2.setItem(R.drawable.ic_control_center, R.string.enable_control_center);
        makeL2.addView(viewItem2, -1, i2);
        ViewItem viewItem3 = new ViewItem(context);
        viewItem3.addNext();
        viewItem3.setOnClickListener(new OnClickListener() {
            @Override
            public final void onClick(View view) {
                getInstance((Activity) getContext()).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        ViewControlCenterUi.this.positionClick(view);
                    }
                }, MAIN_CLICK);
            }
        });
        viewItem3.setItem(R.drawable.ic_resize, R.string.resize);
        makeL2.addView(viewItem3, -1, i2);
        ViewItem viewItem4 = new ViewItem(context);
        viewItem4.addNext();
        viewItem4.setOnClickListener(new OnClickListener() {
            @Override
            public final void onClick(View view) {
                getInstance((Activity) getContext()).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        ViewControlCenterUi.this.positionClick(view);
                    }
                }, MAIN_CLICK);
            }
        });
        viewItem4.setItem(R.drawable.ic_color_setting, R.string.color);
        makeL2.addView(viewItem4, -1, i2);
        ViewItem viewItem5 = new ViewItem(context);
        viewItem5.addNext();
        viewItem5.setOnClickListener(new OnClickListener() {
            @Override
            public final void onClick(View view) {
                getInstance((Activity) getContext()).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        ViewControlCenterUi.this.positionClick(view);
                    }
                }, MAIN_CLICK);
            }
        });
        viewItem5.setItem(R.drawable.ic_orientation, R.string.orientation);
        makeL2.addView(viewItem5, -1, i2);
        ViewItem viewItem6 = new ViewItem(context);
        viewItem6.addNext();
        viewItem6.setOnClickListener(new OnClickListener() {
            @Override
            public final void onClick(View view) {
                ViewControlCenterUi.this.touchClick(view);
            }
        });
        viewItem6.setItem(R.drawable.ic_single_tap, R.string.touch);
        makeL2.addView(viewItem6, -1, i2);
        ViewItem viewItem7 = new ViewItem(context);
        viewItem7.addNext();
        viewItem7.setOnClickListener(new OnClickListener() {
            @Override
            public final void onClick(View view) {
                getInstance((Activity) getContext()).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        ViewControlCenterUi.this.changeBg(view);
                    }
                }, MAIN_CLICK);
            }
        });
        viewItem7.setItem(R.drawable.ic_bg, R.string.bg);
        makeL2.addView(viewItem7, -1, i2);
        ViewItem viewItem8 = new ViewItem(context);
        viewItem8.setId(2);
        viewItem8.goneDivider();
        viewItem8.addSwitch(new ViewItem.SwitchListener() {
            @Override
            public final void onSwitchChange(ViewItem viewItem9, boolean z) {
                ViewControlCenterUi.this.onSwitchBlur(viewItem9, z);
            }
        }, MyShare.enableBlur(context));
        viewItem8.setItem(R.drawable.ic_blur, R.string.enable_blur);
        makeL2.addView(viewItem8, -1, i2);
        ViewItem viewItem10 = new ViewItem(context);
        viewItem10.addNext();
        viewItem10.setOnClickListener(new OnClickListener() {
            @Override
            public final void onClick(View view) {
                ViewControlCenterUi.this.openNightShift(view);
            }
        });
        viewItem10.setItem(R.drawable.ic_nightshift_setting, R.string.night_shift);
        makeL3.addView(viewItem10, -1, i2);
        ViewItem viewItem11 = new ViewItem(context);
        viewItem11.addSwitch(new ViewItem.SwitchListener() {
            @Override
            public final void onSwitchChange(ViewItem viewItem12, boolean z) {
                getInstance((Activity) getContext()).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        ViewControlCenterUi.this.clickMyshare(viewItem12, z);
                    }
                }, MAIN_CLICK);
            }
        }, MyShare.vibrationControl(context));
        viewItem11.setItem(R.drawable.ic_vibration, R.string.vibration);
        makeL3.addView(viewItem11, -1, i2);
        ViewItem viewItem12 = new ViewItem(context);
        viewItem12.addNext();
        viewItem12.setOnClickListener(new OnClickListener() {
            @Override
            public final void onClick(View view) {
                getInstance((Activity) getContext()).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        ViewControlCenterUi.this.openCustom(view);
                    }
                }, MAIN_CLICK);
            }
        });
        viewItem12.setItem(R.drawable.ic_favorite, R.string.custom_controls);
        makeL3.addView(viewItem12, -1, i2);
        ViewItem viewItem13 = new ViewItem(context);
        viewItem13.addNext();
        viewItem13.goneDivider();
        viewItem13.setOnClickListener(new OnClickListener() {
            @Override
            public final void onClick(View view) {
                getInstance((Activity) getContext()).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        ViewControlCenterUi.this.openSetupRecord(view);
                    }
                }, MAIN_CLICK);
            }
        });
        viewItem13.setItem(R.drawable.ic_record_item, R.string.setup_the_record);
        makeL3.addView(viewItem13, -1, i2);
        ViewNightShiftSetting viewNightShiftSetting = new ViewNightShiftSetting(context);
        this.viewNightShift = viewNightShiftSetting;
        viewNightShiftSetting.setNightShiftSettingResult(new ViewNightShiftSetting.NightShiftSettingResult() {
            @Override
            public final void onChange() {
                ViewControlCenterUi.this.clicksendData();
            }
        });

        LinearLayout llads1 = makeL(4);
        viads2 = new ViewItem(context);
        llads1.addView(viads2, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));

        getInstance((Activity) getContext()).ShowNativeAd(llads1, AdUtils.NativeType.NATIVE_MEDIUM);

        ViewItem viewItem16 = new ViewItem(context);
        viewItem16.setItem(R.drawable.ic_star, R.string.rate_star);
        viewItem16.setOnClickListener(new OnClickListener() {
            @Override
            public final void onClick(View view) {
                ViewControlCenterUi.this.rate(view);
            }
        });
        viewItem16.addNext();
        makeL4.addView(viewItem16, -1, i2);
        ViewItem viewItem17 = new ViewItem(context);
        viewItem17.setItem(R.drawable.ic_policy, R.string.policy);
        viewItem17.setOnClickListener(new OnClickListener() {
            @Override
            public final void onClick(View view) {
                ViewControlCenterUi.this.policy(view);
            }
        });
        viewItem17.addNext();
        viewItem17.goneDivider();
        makeL4.addView(viewItem17, -1, i2);
    }

    public void clickMyshare(ViewItem viewItem, boolean z) {
        MyShare.putVibrationControl(getContext(), z);
    }

    public void clicksendData() {
        this.activity.sentDataToService(makeIntent(13));
    }

    public void onSwitchEnable(ViewItem viewItem, boolean z) {
        if (this.sizeScreen[2] == 0) {
            int[] iArr = new int[2];
            getLocationInWindow(iArr);
            if (iArr[1] > 0) {
                this.sizeScreen[2] = iArr[1];
                MyShare.putSize(getContext(), this.sizeScreen);
            }
        }
        if (!this.permissionDone) {
            viewItem.setStatus(false);
            if (MyShare.enableControlCenter(getContext())) {
                MyShare.putEnableControlCenter(getContext(), false);
                return;
            }
            return;
        }
        MyShare.putEnableControlCenter(getContext(), z);
        this.activity.sentDataToService(makeIntent(11));
        if (z) {
            return;
        }
        MyShare.putScheduled(getContext(), false);
        MyShare.putEnaNightShift(getContext(), false);
        updateNightShift();
    }

    public void onSwitchBlur(ViewItem viewItem, boolean z) {
        MyShare.putEnableBlur(getContext(), z);
        this.activity.sentDataToService(makeIntent(17));
    }

    public void openNightShift(View view) {
        if (this.permissionDone) {
            if (!MyShare.enableControlCenter(getContext())) {
                Toast.makeText(getContext(), (int) R.string.please_ena_control, Toast.LENGTH_SHORT).show();
            } else {
                this.viewNightShift.showView(this.rlMain);
            }
        }
    }

    public void positionClick(View view) {
        if (this.permissionDone) {
            if (!MyShare.enableControlCenter(getContext())) {
                Toast.makeText(getContext(), (int) R.string.please_ena_control, Toast.LENGTH_SHORT).show();
                return;
            }
            this.idViewClick = 5;
            showAction();
        }
    }

    public void touchClick(View view) {
        if (this.permissionDone) {
            if (!MyShare.enableControlCenter(getContext())) {
                Toast.makeText(getContext(), (int) R.string.please_ena_control, Toast.LENGTH_SHORT).show();
                return;
            }
            this.idViewClick = 6;
            showAction();
        }
    }

    public void changeBg(View view) {
        this.idViewClick = 3;
        showAction();
    }

    public void openCustom(View view) {
        if (this.permissionDone) {
            if (!MyShare.enableControlCenter(getContext())) {
                Toast.makeText(getContext(), (int) R.string.please_ena_control, Toast.LENGTH_SHORT).show();
                return;
            }
            this.idViewClick = 1;
            showAction();
        }
    }

    public void openSetupRecord(View view) {
        if (this.permissionDone) {
            if (!MyShare.enableControlCenter(getContext())) {
                Toast.makeText(getContext(), (int) R.string.please_ena_control, Toast.LENGTH_SHORT).show();
                return;
            }
            this.idViewClick = 2;
            showAction();
        }
    }

    @Override
    public void checkPer() {
        super.checkPer();
        LinearLayout linearLayout = this.llPer;
        if (linearLayout != null) {
            if (this.permissionDone) {
                if (linearLayout.getVisibility() == View.VISIBLE) {
                    this.llPer.setVisibility(View.GONE);
                }
                this.llTop.setAlpha(1.0f);
                this.llBot.setAlpha(1.0f);
                this.llOther.setAlpha(1.0f);
                return;
            }
            if (linearLayout.getVisibility() == View.GONE) {
                this.llPer.setVisibility(View.VISIBLE);
            }
            this.llTop.setAlpha(0.5f);
            this.llBot.setAlpha(0.5f);
            this.llOther.setAlpha(0.5f);
        }
    }

    public boolean checkBack() {
        if (this.rlMain.indexOfChild(this.viewNightShift) != -1) {
            this.viewNightShift.hideView();
            return true;
        }
        return false;
    }

    public void updateNightShift() {
        this.viewNightShift.updateNightShift();
    }

    public void goneViewPremium() {
        ViewItem viewItem = this.vPremium;
        if (viewItem != null) {
            viewItem.setVisibility(View.GONE);
        }
    }

    public void rate(View view) {
        new RateDialog(getContext()).show();
    }

    public void policy(View view) {
        OtherUtils.openLink(view.getContext(), sharedPreferencesHelper.getPrivacyPolicy());
    }

 
    public void showAction() {
        int i = this.idViewClick;
        if (i == 1) {
            getContext().startActivity(new Intent(getContext(), ActivityCustom.class));
        } else if (i == 2) {
            getContext().startActivity(new Intent(getContext(), ActivitySetupVideo.class));
        } else if (i == 4 || i == 5) {
            this.activity.startPositionActivity();
        } else if (i == 6) {
            this.activity.startTouchActivity();
        } else {
            new DialogChangeBg(getContext(), new DialogWallpaperResult() {
                @Override
                public final void onChangeWallpaper(int i2) {
                    click(i2);
                }
            }).show();
        }
    }

    public void click(int i) {
        if (i == 3) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public final void run() {
                    activity.pickPhoto();
                }
            }, 100L);
        } else if (MyShare.getStatusWallpaper(getContext()) != i) {
            MyShare.putStatusWallpaper(getContext(), i);
            this.activity.sentDataToService(makeIntent(16));
        }
    }
}
