package com.controlcenter.allphone.ioscontrolcenter.dialog;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.adapter.AdapterVideoConfig;
import com.controlcenter.allphone.ioscontrolcenter.item.ItemInt;

import java.util.ArrayList;


public class DialogVideo extends Dialog {
    private final ArrayList<ItemInt> arr;
    private final String title;
    private final int value;
    private final VideoResult videoResult;


    public interface VideoResult {
        void onResultInt(int i);
    }

    public DialogVideo(Context context, int i, String str, ArrayList<ItemInt> arrayList, VideoResult videoResult) {
        super(context);
        this.value = i;
        this.title = str;
        this.arr = arrayList;
        this.videoResult = videoResult;
    }

    @Override 
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.dialog_video);
        ((TextView) findViewById(R.id.tv_title)).setText(this.title);
        findViewById(R.id.tv_cancel).setOnClickListener(new View.OnClickListener() {
            @Override 
            public final void onClick(View view) {
                cancel();
            }
        });
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.rv);
        recyclerView.setAdapter(new AdapterVideoConfig(this.value, this.arr, new AdapterVideoConfig.AdapterVideoResult() {
            @Override
            public final void onItemClick(int i) {
                videoResult.onResultInt(i);
                cancel();
            }
        }));
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
    }
}
