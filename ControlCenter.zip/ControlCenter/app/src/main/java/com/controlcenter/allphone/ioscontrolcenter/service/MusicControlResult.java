package com.controlcenter.allphone.ioscontrolcenter.service;


public interface MusicControlResult {
    void onControlMedia(String str);

    void onSeekTo(long j);
}
