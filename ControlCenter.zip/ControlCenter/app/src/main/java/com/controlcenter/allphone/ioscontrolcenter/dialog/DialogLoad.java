package com.controlcenter.allphone.ioscontrolcenter.dialog;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.controlcenter.allphone.ioscontrolcenter.R;
import com.controlcenter.allphone.ioscontrolcenter.util.OtherUtils;


public class DialogLoad extends BaseDialog {
    private ImageView im;
    private String title;
    private TextView tvTitle;

    public DialogLoad(Context context) {
        super(context);
    }

    public DialogLoad(Context context, String str) {
        super(context);
        this.title = str;
    }

    @Override 
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.dialog_load);
        initView();
    }

    private void initView() {
        ((LinearLayout) findViewById(R.id.ll)).setBackground(OtherUtils.bgLayout(getContext(), Color.parseColor("#eaffffff")));
        this.tvTitle = (TextView) findViewById(R.id.tv_loading);
        ImageView imageView = (ImageView) findViewById(R.id.img_load);
        this.im = imageView;
        anim(imageView);
        String str = this.title;
        if (str != null) {
            this.tvTitle.setText(str);
        }
    }

    public void onShowDialog(int i) {
        ImageView imageView = this.im;
        if (imageView != null) {
            anim(imageView);
        }
        TextView textView = this.tvTitle;
        if (textView != null) {
            textView.setText(i);
        } else {
            this.title = getContext().getString(i);
        }
        if (isShowing()) {
            return;
        }
        show();
    }

    public void setText(int i) {
        if (this.tvTitle == null || !isShowing()) {
            return;
        }
        TextView textView = this.tvTitle;
        textView.setText(i + "%");
    }

    public void setText(String str) {
        if (this.tvTitle == null || !isShowing()) {
            return;
        }
        this.tvTitle.setText(str);
    }

    private void anim(ImageView imageView) {
        RotateAnimation rotateAnimation = new RotateAnimation(0.0f, 360.0f, 1, 0.5f, 1, 0.5f);
        rotateAnimation.setInterpolator(new LinearInterpolator());
        rotateAnimation.setDuration(2000L);
        rotateAnimation.setRepeatCount(-1);
        imageView.startAnimation(rotateAnimation);
    }
}
