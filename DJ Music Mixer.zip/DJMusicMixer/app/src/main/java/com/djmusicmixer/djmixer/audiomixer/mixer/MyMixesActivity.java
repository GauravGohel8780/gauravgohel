package com.djmusicmixer.djmixer.audiomixer.mixer;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;
import com.djmusicmixer.djmixer.audiomixer.mixer.Adapter.MyMixesAdapter;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

public class MyMixesActivity extends BaseActivity implements View.OnClickListener {
    public static Activity activity;
    public EditText et_search_mixes;
    String[] extensions = {"mp3"};
    protected ImageView iv_back;
    private ImageView iv_search;
    private MediaPlayer mediaPlayer;
    public ArrayList<String> mixesList = new ArrayList<>();
    public MyMixesAdapter myMixesAdapter;
    private RelativeLayout rl_search_mixes;
    public RecyclerView rv_my_mixes;
    public ArrayList<String> searchMixesList = new ArrayList<>();
    private TextView tv_no_mixes;
    private TextView tv_title;


    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        setContentView(R.layout.activity_rkappzia_my_mixes);
        init();
        bindView();
    }

    private void init() {
        this.iv_back = (ImageView) findViewById(R.id.iv_back);
        this.tv_title = (TextView) findViewById(R.id.tv_title_rkappzia);
        this.rl_search_mixes = (RelativeLayout) findViewById(R.id.rl_search_mixes_rkappzia);
        this.et_search_mixes = (EditText) findViewById(R.id.et_search_mixes_rkappzia);
        this.iv_search = (ImageView) findViewById(R.id.iv_search_rkappzia);
        this.rv_my_mixes = (RecyclerView) findViewById(R.id.rv_my_mixes);
        this.tv_no_mixes = (TextView) findViewById(R.id.tv_no_mixes);
    }

    private void bindView() {
        this.et_search_mixes.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable editable) {
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                MyMixesActivity.this.searchMixesList.clear();
                if (MyMixesActivity.this.et_search_mixes != null || MyMixesActivity.this.et_search_mixes.getText().toString().length() > 0 || !MyMixesActivity.this.et_search_mixes.getText().toString().equals("")) {
                    for (int i4 = 0; i4 < MyMixesActivity.this.mixesList.size(); i4++) {
                        String str = MyMixesActivity.this.mixesList.get(i4);
                        if (str.substring(str.lastIndexOf("/") + 1).toLowerCase().contains(MyMixesActivity.this.et_search_mixes.getText().toString())) {
                            MyMixesActivity.this.searchMixesList.add(MyMixesActivity.this.mixesList.get(i4));
                        }
                    }
                } else {
                    MyMixesActivity myMixesActivity = MyMixesActivity.this;
                    myMixesActivity.searchMixesList = myMixesActivity.mixesList;
                }
                MyMixesActivity.this.rv_my_mixes.setHasFixedSize(true);
                MyMixesActivity.this.rv_my_mixes.setLayoutManager(new LinearLayoutManager(MyMixesActivity.this, RecyclerView.VERTICAL, false));
                MyMixesActivity myMixesActivity2 = MyMixesActivity.this;
                myMixesActivity2.myMixesAdapter = new MyMixesAdapter(myMixesActivity2, myMixesActivity2.searchMixesList);
                MyMixesActivity.this.rv_my_mixes.setAdapter(MyMixesActivity.this.myMixesAdapter);
                MyMixesActivity.this.myMixesAdapter.notifyDataSetChanged();
                MyMixesActivity.this.myMixesAdapter.setOnItemClickListener(new MyMixesAdapter.OnItemClickListener() {
                    @Override
                    public void onClick(int i) {
                        if (Objects.equals(MyMixesActivity.this.getIntent().getStringExtra("TAG"), "MusicMixerActivity")) {
                            MyMixesActivity.this.showAlert(i, true);
                        }
                    }
                });
            }
        });
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.iv_back) {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    onBackPressed();
                }
            }, BACK_CLICK);

        } else if (id != R.id.iv_search_rkappzia) {
        } else {
            if (this.tv_title.getVisibility() == View.VISIBLE) {
                this.tv_title.setVisibility(View.GONE);
                this.rl_search_mixes.setVisibility(View.VISIBLE);
                this.iv_search.setImageResource(R.drawable.ic_done);
                return;
            }
            this.et_search_mixes.setText("");
            this.tv_title.setVisibility(View.VISIBLE);
            this.rl_search_mixes.setVisibility(View.GONE);
            this.iv_search.setImageResource(R.drawable.ic_search);
        }
    }

    private void setMixesAdapter() {
        this.mixesList.clear();
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC).toString() + File.separator + getResources().getString(R.string.app_name));
        if (!file.exists()) {
            file.mkdir();
        }
        loadMixesAudio(file.getPath());
        if (this.mixesList.size() > 0) {
            this.rv_my_mixes.setVisibility(View.VISIBLE);
            this.tv_no_mixes.setVisibility(View.GONE);
            this.rv_my_mixes.setHasFixedSize(true);
            this.rv_my_mixes.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
            MyMixesAdapter myMixesAdapter2 = new MyMixesAdapter(this, this.mixesList);
            this.myMixesAdapter = myMixesAdapter2;
            this.rv_my_mixes.setAdapter(myMixesAdapter2);
            this.myMixesAdapter.notifyDataSetChanged();
            return;
        }
        this.rv_my_mixes.setVisibility(View.GONE);
        this.tv_no_mixes.setVisibility(View.VISIBLE);
    }

    private void loadMixesAudio(String str) {
        File[] listFiles;
        File file = new File(str);
        if (file.isDirectory() && (listFiles = file.listFiles()) != null && listFiles.length > 0) {
            for (File file2 : listFiles) {
                if (file2.isDirectory()) {
                    loadMixesAudio(file2.getAbsolutePath());
                } else {
                    for (String str2 : this.extensions) {
                        if (file2.getAbsolutePath().endsWith(str2)) {
                            this.mixesList.add(file2.getAbsolutePath());
                        }
                    }
                }
            }
        }
    }

    public void showAlert(int i, final boolean z) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Select Disk For Play this Song");
        builder.setNegativeButton("Disk A", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                MixerActivity.disk_index = 0;
                MixerActivity.isLoadMusicA = true;
                MyMixesActivity.this.setMixesIntent(i, z);
            }
        });
        builder.setPositiveButton("Disk B", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                MixerActivity.disk_index = 1;
                MixerActivity.isLoadMusicB = true;
                MyMixesActivity.this.setMixesIntent(i, z);
            }
        });
        builder.show();
    }

    public void setMixesIntent(int i, boolean z) {
        if (!z) {
            String str = this.mixesList.get(i);
            String substring = str.substring(str.lastIndexOf("/") + 1);
            Intent intent = new Intent();
            intent.putExtra("selected_music_path", str);
            intent.putExtra("selected_music_name", substring);
            intent.putExtra("selected_music_album", "thumb");
            setResult(-1, intent);
            finish();
            return;
        }
        String str2 = this.searchMixesList.get(i);
        String substring2 = str2.substring(str2.lastIndexOf("/") + 1);
        Intent intent2 = new Intent();
        intent2.putExtra("selected_music_path", str2);
        intent2.putExtra("selected_music_name", substring2);
        intent2.putExtra("selected_music_album", "thumb");
        setResult(-1, intent2);
        finish();
    }

    public void playMixes(String str) {
        try {
            MediaPlayer mediaPlayer2 = this.mediaPlayer;
            if (mediaPlayer2 != null && mediaPlayer2.isPlaying()) {
                this.mediaPlayer.stop();
                this.mediaPlayer.release();
            }
            MediaPlayer mediaPlayer3 = new MediaPlayer();
            this.mediaPlayer = mediaPlayer3;
            mediaPlayer3.setDataSource(str);
            this.mediaPlayer.setAudioStreamType(3);
            this.mediaPlayer.prepare();
            this.mediaPlayer.start();
            this.mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                public void onCompletion(MediaPlayer mediaPlayer) {
                    MyMixesActivity.this.myMixesAdapter.selectedMixes = -1;
                    MyMixesActivity.this.pauseMixes();
                    MyMixesActivity.this.myMixesAdapter.notifyDataSetChanged();
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void pauseMixes() {
        MediaPlayer mediaPlayer2 = this.mediaPlayer;
        if (mediaPlayer2 != null && mediaPlayer2.isPlaying()) {
            this.mediaPlayer.stop();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        this.mediaPlayer = new MediaPlayer();
        this.et_search_mixes.setText("");
        setMixesAdapter();
    }

    @Override
    public void onPause() {
        super.onPause();
        MediaPlayer mediaPlayer2 = this.mediaPlayer;
        if (mediaPlayer2 != null && mediaPlayer2.isPlaying()) {
            this.mediaPlayer.stop();
            this.mediaPlayer.release();
        }
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        exitActivity();
    }

    private void exitActivity() {
        finish();
    }
}
