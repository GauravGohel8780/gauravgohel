package com.djmusicmixer.djmixer.audiomixer.piyano;

import android.annotation.SuppressLint;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.djmusicmixer.djmixer.audiomixer.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PianoMainActivity extends AppCompatActivity {
    public boolean boolOne = false;
    ImageView imge_s31btn;
    ImageView imge_s32btn;
    ImageView imge_s33btn;
    ImageView imge_s34btn;
    ImageView imge_s35btn;
    ImageView imge_s36btn;
    ImageView imge_s37btn;
    ImageView imge_s38btn;
    ImageView imge_s39btn;
    ImageView imge_s40btn;
    ImageView imge_s41btn;
    ImageView imge_s42btn;
    ImageView imge_s43btn;
    ImageView imge_s44btn;
    ImageView imge_s45btn;
    ImageView imge_s46btn;
    ImageView imge_s47btn;
    ImageView imge_s48btn;
    ImageView imge_s49btn;
    ImageView imge_s50btn;
    ImageView imge_s51btn;
    ImageView imge_s52btn;
    ImageView imge_s53btn;
    ImageView imge_s54btn;
    ImageView imge_s55btn;
    ImageView imge_s56btn;
    ImageView imge_s57btn;
    ImageView imge_s58btn;
    ImageView imge_s59btn;
    ImageView imge_s60btn;
    ImageView imge_s61btn;
    ImageView imge_s62btn;
    ImageView imge_s63btn;
    ImageView imge_s64btn;
    ImageView imge_s65btn;
    LinearLayout linearLayout;
    public Map<Integer, Integer> mapOne = new HashMap();
    public Map<Long, List<MapModel>> mapThree = new HashMap();
    public Map<Integer, Integer> mapTwo = new HashMap();
    RadioButton radio_0btn;
    RadioButton radio_10btn;
    RadioButton radio_11btn;
    RadioButton radio_1btn;
    RadioButton radio_2btn;
    RadioButton radio_3btn;
    RadioButton radio_4btn;
    RadioButton radio_5btn;
    RadioButton radio_6btn;
    RadioButton radio_7btn;
    RadioButton radio_8btn;
    RadioButton radio_9btn;
    RadioGroup radio_tunes;
    RelativeLayout rootView;
    public SoundPool soundPool;
    TextView text_s32;
    TextView text_s33;
    TextView text_s34;
    TextView text_s35;
    TextView text_s37;
    TextView text_s39;
    TextView text_s40;
    TextView text_s42;
    TextView text_s44;
    TextView text_s45;
    TextView text_s47;
    TextView text_s49;
    TextView text_s51;
    TextView text_s52;
    TextView text_s54;
    TextView text_s56;
    TextView text_s57;
    TextView text_s59;
    TextView text_s61;
    TextView text_s63;
    TextView text_s64;
    public int valueOne = 0;
    public long valueTwo = 0;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_piano_main);
        this.imge_s31btn = (ImageView) findViewById(R.id.img_s31btn);
        this.imge_s32btn = (ImageView) findViewById(R.id.img_s32btn);
        this.text_s32 = (TextView) findViewById(R.id.txt_s32);
        this.imge_s33btn = (ImageView) findViewById(R.id.img_s33btn);
        this.text_s33 = (TextView) findViewById(R.id.txt_s33);
        this.imge_s34btn = (ImageView) findViewById(R.id.img_s34btn);
        this.imge_s35btn = (ImageView) findViewById(R.id.img_s35btn);
        this.text_s35 = (TextView) findViewById(R.id.txt_s35);
        this.imge_s36btn = (ImageView) findViewById(R.id.img_s36btn);
        this.imge_s37btn = (ImageView) findViewById(R.id.img_s37btn);
        this.text_s37 = (TextView) findViewById(R.id.txt_s37);
        this.imge_s38btn = (ImageView) findViewById(R.id.img_s38btn);
        this.imge_s39btn = (ImageView) findViewById(R.id.img_s39btn);
        this.text_s39 = (TextView) findViewById(R.id.txt_s39);
        this.imge_s40btn = (ImageView) findViewById(R.id.img_s40btn);
        this.text_s40 = (TextView) findViewById(R.id.txt_s40);
        this.imge_s41btn = (ImageView) findViewById(R.id.img_s41btn);
        this.imge_s42btn = (ImageView) findViewById(R.id.img_s42btn);
        this.text_s42 = (TextView) findViewById(R.id.txt_s42);
        this.imge_s43btn = (ImageView) findViewById(R.id.img_s43btn);
        this.imge_s44btn = (ImageView) findViewById(R.id.img_s44btn);
        this.text_s44 = (TextView) findViewById(R.id.txt_s44);
        this.imge_s45btn = (ImageView) findViewById(R.id.img_s45btn);
        this.text_s45 = (TextView) findViewById(R.id.txt_s45);
        this.imge_s46btn = (ImageView) findViewById(R.id.img_s46btn);
        this.imge_s47btn = (ImageView) findViewById(R.id.img_s47btn);
        this.text_s47 = (TextView) findViewById(R.id.txt_s47);
        this.imge_s48btn = (ImageView) findViewById(R.id.img_s48btn);
        this.imge_s49btn = (ImageView) findViewById(R.id.img_s49btn);
        this.text_s49 = (TextView) findViewById(R.id.txt_s49);
        this.imge_s50btn = (ImageView) findViewById(R.id.img_s50btn);
        this.imge_s51btn = (ImageView) findViewById(R.id.img_s51btn);
        this.text_s51 = (TextView) findViewById(R.id.txt_s51);
        this.imge_s52btn = (ImageView) findViewById(R.id.img_s52btn);
        this.text_s52 = (TextView) findViewById(R.id.txt_s52);
        this.imge_s53btn = (ImageView) findViewById(R.id.img_s53btn);
        this.imge_s54btn = (ImageView) findViewById(R.id.img_s54btn);
        this.text_s54 = (TextView) findViewById(R.id.txt_s54);
        this.imge_s55btn = (ImageView) findViewById(R.id.img_s55btn);
        this.imge_s56btn = (ImageView) findViewById(R.id.img_s56btn);
        this.text_s56 = (TextView) findViewById(R.id.txt_s56);
        this.imge_s57btn = (ImageView) findViewById(R.id.img_s57btn);
        this.text_s57 = (TextView) findViewById(R.id.txt_s57);
        this.imge_s58btn = (ImageView) findViewById(R.id.img_s58btn);
        this.imge_s59btn = (ImageView) findViewById(R.id.img_s59btn);
        this.text_s59 = (TextView) findViewById(R.id.txt_s59);
        this.imge_s60btn = (ImageView) findViewById(R.id.img_s60btn);
        this.imge_s61btn = (ImageView) findViewById(R.id.img_s61btn);
        this.text_s61 = (TextView) findViewById(R.id.txt_s61);
        this.imge_s62btn = (ImageView) findViewById(R.id.img_s62btn);
        this.imge_s63btn = (ImageView) findViewById(R.id.img_s63btn);
        this.text_s63 = (TextView) findViewById(R.id.txt_s63);
        this.imge_s64btn = (ImageView) findViewById(R.id.img_s64btn);
        this.text_s64 = (TextView) findViewById(R.id.txt_s64);
        this.imge_s65btn = (ImageView) findViewById(R.id.img_s65btn);
        this.radio_0btn = (RadioButton) findViewById(R.id.radi_0btn);
        this.radio_1btn = (RadioButton) findViewById(R.id.radi_1btn);
        this.radio_2btn = (RadioButton) findViewById(R.id.radi_2btn);
        this.radio_3btn = (RadioButton) findViewById(R.id.radi_3btn);
        this.radio_4btn = (RadioButton) findViewById(R.id.radi_4btn);
        this.radio_5btn = (RadioButton) findViewById(R.id.radi_5btn);
        this.radio_6btn = (RadioButton) findViewById(R.id.radi_6btn);
        this.radio_7btn = (RadioButton) findViewById(R.id.radi_7btn);
        this.radio_8btn = (RadioButton) findViewById(R.id.radi_8btn);
        this.radio_9btn = (RadioButton) findViewById(R.id.radi_9btn);
        this.radio_10btn = (RadioButton) findViewById(R.id.radi_10btn);
        this.radio_11btn = (RadioButton) findViewById(R.id.radi_11btn);
        this.radio_tunes = (RadioGroup) findViewById(R.id.readi_tunes);
        this.soundPool = new SoundPool(5, 3, 0);
        this.mapOne.put(Integer.valueOf(this.radio_0btn.getId()), 0);
        this.mapOne.put(Integer.valueOf(this.radio_1btn.getId()), 1);
        this.mapOne.put(Integer.valueOf(this.radio_2btn.getId()), 2);
        this.mapOne.put(Integer.valueOf(this.radio_3btn.getId()), 3);
        this.mapOne.put(Integer.valueOf(this.radio_4btn.getId()), 4);
        this.mapOne.put(Integer.valueOf(this.radio_5btn.getId()), 5);
        this.mapOne.put(Integer.valueOf(this.radio_6btn.getId()), 6);
        this.mapOne.put(Integer.valueOf(this.radio_7btn.getId()), 7);
        this.mapOne.put(Integer.valueOf(this.radio_8btn.getId()), 8);
        this.mapOne.put(Integer.valueOf(this.radio_9btn.getId()), 9);
        this.mapOne.put(Integer.valueOf(this.radio_10btn.getId()), 10);
        this.mapOne.put(Integer.valueOf(this.radio_11btn.getId()), 11);
        this.radio_tunes.setOnCheckedChangeListener(new RadioGroupCCL(this));
        new Handler().postDelayed(new LoadData(this), 100);
        buttonOneClick();
    }

    @SuppressLint("ClickableViewAccessibility")
    public void buttonOneClick() {
        this.imge_s31btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                
                return PianoMainActivity.this.playSound((TextView) null, 31, motionEvent, view);
            }
        });
        this.imge_s32btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                PianoMainActivity pianoMainActivity = PianoMainActivity.this;
                return pianoMainActivity.playSound(pianoMainActivity.text_s32, 32, motionEvent, view);
            }
        });
        this.imge_s33btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                PianoMainActivity pianoMainActivity = PianoMainActivity.this;
                return pianoMainActivity.playSound(pianoMainActivity.text_s33, 33, motionEvent, view);
            }
        });
        this.imge_s34btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                
                return PianoMainActivity.this.playSound((TextView) null, 34, motionEvent, view);
            }
        });
        this.imge_s35btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                PianoMainActivity pianoMainActivity = PianoMainActivity.this;
                return pianoMainActivity.playSound(pianoMainActivity.text_s35, 35, motionEvent, view);
            }
        });
        this.imge_s36btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                
                return PianoMainActivity.this.playSound((TextView) null, 36, motionEvent, view);
            }
        });
        this.imge_s37btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                PianoMainActivity pianoMainActivity = PianoMainActivity.this;
                return pianoMainActivity.playSound(pianoMainActivity.text_s37, 37, motionEvent, view);
            }
        });
        this.imge_s38btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                
                return PianoMainActivity.this.playSound((TextView) null, 38, motionEvent, view);
            }
        });
        this.imge_s39btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                PianoMainActivity pianoMainActivity = PianoMainActivity.this;
                return pianoMainActivity.playSound(pianoMainActivity.text_s39, 39, motionEvent, view);
            }
        });
        this.imge_s40btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                
                return PianoMainActivity.this.playSound((TextView) null, 40, motionEvent, view);
            }
        });
        this.imge_s41btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                
                return PianoMainActivity.this.playSound((TextView) null, 41, motionEvent, view);
            }
        });
        this.imge_s42btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                PianoMainActivity pianoMainActivity = PianoMainActivity.this;
                return pianoMainActivity.playSound(pianoMainActivity.text_s42, 42, motionEvent, view);
            }
        });
        this.imge_s43btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                
                return PianoMainActivity.this.playSound((TextView) null, 43, motionEvent, view);
            }
        });
        this.imge_s44btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                PianoMainActivity pianoMainActivity = PianoMainActivity.this;
                return pianoMainActivity.playSound(pianoMainActivity.text_s44, 44, motionEvent, view);
            }
        });
        this.imge_s46btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                PianoMainActivity pianoMainActivity = PianoMainActivity.this;
                return pianoMainActivity.playSound(pianoMainActivity.text_s45, 45, motionEvent, view);
            }
        });
        this.imge_s45btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                
                return PianoMainActivity.this.playSound((TextView) null, 46, motionEvent, view);
            }
        });
        this.imge_s47btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                PianoMainActivity pianoMainActivity = PianoMainActivity.this;
                return pianoMainActivity.playSound(pianoMainActivity.text_s47, 47, motionEvent, view);
            }
        });
        this.imge_s48btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                
                return PianoMainActivity.this.playSound((TextView) null, 48, motionEvent, view);
            }
        });
        this.imge_s49btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                PianoMainActivity pianoMainActivity = PianoMainActivity.this;
                return pianoMainActivity.playSound(pianoMainActivity.text_s49, 49, motionEvent, view);
            }
        });
        this.imge_s50btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                
                return PianoMainActivity.this.playSound((TextView) null, 50, motionEvent, view);
            }
        });
        this.imge_s51btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                PianoMainActivity pianoMainActivity = PianoMainActivity.this;
                return pianoMainActivity.playSound(pianoMainActivity.text_s51, 51, motionEvent, view);
            }
        });
        this.imge_s52btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                PianoMainActivity pianoMainActivity = PianoMainActivity.this;
                return pianoMainActivity.playSound(pianoMainActivity.text_s52, 52, motionEvent, view);
            }
        });
        this.imge_s53btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                
                return PianoMainActivity.this.playSound((TextView) null, 53, motionEvent, view);
            }
        });
        this.imge_s54btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                PianoMainActivity pianoMainActivity = PianoMainActivity.this;
                return pianoMainActivity.playSound(pianoMainActivity.text_s54, 54, motionEvent, view);
            }
        });
        this.imge_s55btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                
                return PianoMainActivity.this.playSound((TextView) null, 55, motionEvent, view);
            }
        });
        this.imge_s56btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                PianoMainActivity pianoMainActivity = PianoMainActivity.this;
                return pianoMainActivity.playSound(pianoMainActivity.text_s56, 56, motionEvent, view);
            }
        });
        this.imge_s57btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                PianoMainActivity pianoMainActivity = PianoMainActivity.this;
                return pianoMainActivity.playSound(pianoMainActivity.text_s57, 57, motionEvent, view);
            }
        });
        this.imge_s58btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                
                return PianoMainActivity.this.playSound((TextView) null, 58, motionEvent, view);
            }
        });
        this.imge_s59btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                PianoMainActivity pianoMainActivity = PianoMainActivity.this;
                return pianoMainActivity.playSound(pianoMainActivity.text_s59, 59, motionEvent, view);
            }
        });
        this.imge_s60btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                
                return PianoMainActivity.this.playSound((TextView) null, 60, motionEvent, view);
            }
        });
        this.imge_s61btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                PianoMainActivity pianoMainActivity = PianoMainActivity.this;
                return pianoMainActivity.playSound(pianoMainActivity.text_s61, 61, motionEvent, view);
            }
        });
        this.imge_s62btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                
                return PianoMainActivity.this.playSound((TextView) null, 62, motionEvent, view);
            }
        });
        this.imge_s63btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                PianoMainActivity pianoMainActivity = PianoMainActivity.this;
                return pianoMainActivity.playSound(pianoMainActivity.text_s63, 63, motionEvent, view);
            }
        });
        this.imge_s64btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                PianoMainActivity pianoMainActivity = PianoMainActivity.this;
                return pianoMainActivity.playSound(pianoMainActivity.text_s64, 64, motionEvent, view);
            }
        });
        this.imge_s65btn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                
                return PianoMainActivity.this.playSound((TextView) null, 65, motionEvent, view);
            }
        });
    }

    public boolean playSound(TextView textView, int i, MotionEvent motionEvent, View view) {
        if (textView != null && motionEvent.getAction() == 1) {
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 81;
            layoutParams.setMargins(0, 0, 0, (int) ((getResources().getDisplayMetrics().density * 30.0f) + 0.5f));
            textView.setLayoutParams(layoutParams);
        }
        if (motionEvent != null && motionEvent.getAction() != 0) {
            return false;
        }
        if (textView != null) {
            FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(-2, -2);
            layoutParams2.gravity = 81;
            layoutParams2.setMargins(0, 0, 0, (int) ((getResources().getDisplayMetrics().density * 20.0f) + 0.5f));
            textView.setLayoutParams(layoutParams2);
        }
        this.soundPool.play(this.mapTwo.get(Integer.valueOf(this.valueOne + i)).intValue(), 1.0f, 1.0f, 0, 0, 1.0f);
        if (!this.boolOne) {
            return false;
        }
        long currentTimeMillis = (System.currentTimeMillis() - this.valueTwo) / 25;
        MapModel mapModel = new MapModel(i, view);
        if (this.mapThree.containsKey(Long.valueOf(currentTimeMillis))) {
            this.mapThree.get(Long.valueOf(currentTimeMillis)).add(mapModel);
            return false;
        }
        ArrayList arrayList = new ArrayList();
        arrayList.add(mapModel);
        this.mapThree.put(Long.valueOf(currentTimeMillis), arrayList);
        return false;
    }

    @SuppressLint("MissingSuperCall")
    public void onBackPressed() {
                finish();
    }
}
