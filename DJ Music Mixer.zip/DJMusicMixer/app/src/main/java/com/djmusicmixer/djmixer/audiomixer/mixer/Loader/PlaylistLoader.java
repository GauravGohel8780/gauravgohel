package com.djmusicmixer.djmixer.audiomixer.mixer.Loader;

import android.content.Context;
import android.database.Cursor;
import android.provider.MediaStore;

import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Playlist;

import java.util.ArrayList;

public class PlaylistLoader {
    public static final String NAME = "name";

    public static ArrayList<Playlist> getAllPlaylists(Context context) {
        return getAllPlaylists(makePlaylistCursor(context, null, null));
    }

    public static ArrayList<Playlist> getAllPlaylists(Cursor cursor) {
        ArrayList<Playlist> arrayList = new ArrayList<>();
        if (cursor == null || !cursor.moveToFirst()) {
            if (cursor != null) {
                cursor.close();
            }
            return arrayList;
        }
        do {
            arrayList.add(getPlaylistFromCursor(cursor));
        } while (cursor.moveToNext());
        return arrayList;
    }

    private static Playlist getPlaylistFromCursor(Cursor cursor) {
        return new Playlist(cursor.getLong(0), cursor.getString(1));
    }

    public static Cursor makePlaylistCursor(Context context, String str, String[] strArr) {
        try {
            return context.getContentResolver().query(MediaStore.Audio.Playlists.EXTERNAL_CONTENT_URI, new String[]{"_id", "name"}, str, strArr, "name");
        } catch (SecurityException unused) {
            return null;
        }
    }
}
