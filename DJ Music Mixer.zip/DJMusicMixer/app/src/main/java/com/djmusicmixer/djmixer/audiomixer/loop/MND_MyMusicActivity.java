package com.djmusicmixer.djmixer.audiomixer.loop;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.activites.Home_Activity;
import com.djmusicmixer.djmixer.audiomixer.base.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.dialog.DialogChooseOptionToCreateRecord;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;
import com.djmusicmixer.djmixer.audiomixer.mixer.MixerActivity;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Map;

public class MND_MyMusicActivity extends BaseActivity {
    AlertDialog alertDialog;
    boolean checkPer = false;
    private DialogChooseOptionToCreateRecord dialogChooseOptionToCreateRecord;
    File file;
    ArrayList<String> filePath = new ArrayList<>();
    ArrayList<String> filename = new ArrayList<>();
    private ImageView imgAdd;
    boolean isResume = false;
    private File[] listFile;
    LinearLayout llNoMusic;
    MediaPlayer mediaPlayer;
    MusicAdapter musicAdapter;
    private ActivityResultLauncher<String[]> permissionsResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
        public void onActivityResult(Map<String, Boolean> map) {
            if (Build.VERSION.SDK_INT < 24) {
                MND_MyMusicActivity.this.run();
            } else if (map.values().stream().allMatch(Boolean::booleanValue)) {
                MND_MyMusicActivity.this.run();
            } else {
                MND_MyMusicActivity.this.dialogPermission();
            }
        }
    });
    int playPos = -1;
    private String readMediaPermission = "android.permission.READ_MEDIA_VIDEO";
    private String readMediaPermission2 = "android.permission.READ_MEDIA_IMAGES";
    private String readMediaPermission3 = "android.permission.READ_MEDIA_AUDIO";
    private String readMediaPermission4 = "android.permission.RECORD_AUDIO";
    RecyclerView recyclerView;
    private String storagePermission = "android.permission.READ_EXTERNAL_STORAGE";

    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        getWindow().addFlags(128);
        super.onCreate(bundle);
        setContentView(R.layout.activity_my_music);

        this.llNoMusic = (LinearLayout) findViewById(R.id.ll_no_music);
        this.imgAdd = (ImageView) findViewById(R.id.img_add);
        this.alertDialog = new AlertDialog.Builder(this, R.style.AlertDialogCustom).create();
        this.recyclerView = (RecyclerView) findViewById(R.id.rv_music);
        if (Build.VERSION.SDK_INT >= 33) {
            if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_VIDEO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_IMAGES") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_AUDIO") == 0) {
                run();
            } else {
                requestStorage();
            }
        } else if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0) {
            run();
        } else {
            requestStorage();
        }
        this.dialogChooseOptionToCreateRecord = new DialogChooseOptionToCreateRecord(this, new DialogChooseOptionToCreateRecord.IOnClickDialogChooseOptionToCreateRecord() {
            @Override
            public void onClickPositive() {
                Toast.makeText(MND_MyMusicActivity.this, "hehe", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onClickDJMixer() {
                getInstance(MND_MyMusicActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        MND_MyMusicActivity.this.startActivity(new Intent(MND_MyMusicActivity.this, MixerActivity.class));
                        MND_MyMusicActivity.this.finish();
                    }
                }, MAIN_CLICK);
            }

            @Override
            public void onClickPlayInstrument() {
                getInstance(MND_MyMusicActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        MND_MyMusicActivity.this.startActivity(new Intent(MND_MyMusicActivity.this, Home_Activity.class));
                        MND_MyMusicActivity.this.finish();
                    }
                }, MAIN_CLICK);
            }

            @Override
            public void onClickBeatMaker() {
                getInstance(MND_MyMusicActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        MND_MyMusicActivity.this.startActivity(new Intent(MND_MyMusicActivity.this, MND_LoopPadActivity.class));
                        MND_MyMusicActivity.this.finish();
                    }
                }, MAIN_CLICK);
            }
        });
        this.imgAdd.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(MND_MyMusicActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        MND_MyMusicActivity.this.dialogChooseOptionToCreateRecord.show();
                    }
                }, MAIN_CLICK);
            }
        });
        if (this.filePath.size() > 0) {
            this.llNoMusic.setVisibility(View.GONE);
        } else {
            this.llNoMusic.setVisibility(View.VISIBLE);
        }
        this.musicAdapter = new MusicAdapter(this, this.filePath, this.filename);
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        this.recyclerView.setAdapter(this.musicAdapter);
        this.musicAdapter.notifyDataSetChanged();
        ((ImageView) findViewById(R.id.back)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(MND_MyMusicActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        MND_MyMusicActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

    }


    private void run() {
        if (!Environment.getExternalStorageState().equals("mounted")) {
            Toast.makeText(this, "Error! No SDCARD Found!", Toast.LENGTH_LONG).show();
        } else {
            File file2 = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC) + File.separator + getResources().getString(R.string.app_name));
            this.file = file2;
            if (!file2.exists()) {
                this.file.mkdirs();
            }
        }
        this.filePath.clear();
        this.filename.clear();
        if (this.file.isDirectory()) {
            File[] listFiles = this.file.listFiles();
            this.listFile = listFiles;
            if (listFiles != null && listFiles.length > 1) {
                Arrays.sort(listFiles, new Comparator<File>() {
                    public int compare(File file, File file2) {
                        return file2.getName().compareTo(file.getName());
                    }
                });
            }
            File[] fileArr = this.listFile;
            for (File file3 : fileArr) {
                this.filePath.add(file3.getAbsolutePath());
                this.filename.add(file3.getName());
            }
        }
    }

    public class MusicAdapter extends RecyclerView.Adapter<MusicAdapter.CustomViewHolder> {
        File file;
        ArrayList<String> filename;
        ArrayList<String> filepath;
        public Context mContext;

        public class CustomViewHolder extends RecyclerView.ViewHolder {
            ImageView img_play;
            ImageView img_share;
            TextView txt_musicName;

            public CustomViewHolder(View view) {
                super(view);
                this.txt_musicName = (TextView) view.findViewById(R.id.txt_musicName);
                this.img_play = (ImageView) view.findViewById(R.id.img_play);
                this.img_share = (ImageView) view.findViewById(R.id.img_share);
            }
        }

        public MusicAdapter(Context context, ArrayList<String> arrayList, ArrayList<String> arrayList2) {
            this.filepath = arrayList;
            this.filename = arrayList2;
            this.mContext = context;
        }

        @Override 
        public CustomViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            return new CustomViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_music, (ViewGroup) null));
        }

        public void onBindViewHolder(CustomViewHolder customViewHolder, final int i) {
            if (MND_MyMusicActivity.this.playPos == i) {
                customViewHolder.img_play.setImageResource(R.drawable.ic_recordpause);
            } else {
                customViewHolder.img_play.setImageResource(R.drawable.ic_record_play);
            }
            this.file = new File(this.filepath.get(i));
            customViewHolder.txt_musicName.setText(this.filename.get(i));
            customViewHolder.img_play.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    if (MND_MyMusicActivity.this.playPos != i) {
                        try {
                            MND_MyMusicActivity.this.stopVoice();
                            MND_MyMusicActivity.this.mediaPlayer = new MediaPlayer();
                            try {
                                MND_MyMusicActivity.this.mediaPlayer.setDataSource(MND_MyMusicActivity.this.filePath.get(i));
                                MND_MyMusicActivity.this.mediaPlayer.prepare();
                                MND_MyMusicActivity.this.mediaPlayer.start();
                                MND_MyMusicActivity.this.mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                                    public void onCompletion(MediaPlayer mediaPlayer) {
                                        MND_MyMusicActivity.this.playPos = -1;
                                        MusicAdapter.this.notifyDataSetChanged();
                                    }
                                });
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            MND_MyMusicActivity.this.playPos = i;
                        } catch (Exception e2) {
                            Log.e("Ss", "donilePlay: ", e2);
                        }
                    } else {
                        MND_MyMusicActivity.this.mediaPlayer.pause();
                        MND_MyMusicActivity.this.playPos = -1;
                    }
                    MusicAdapter.this.notifyDataSetChanged();
                }
            });
            customViewHolder.img_share.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    MND_MyMusicActivity.this.isResume = true;
                    Uri uriForFile = FileProvider.getUriForFile(MusicAdapter.this.mContext, "com.djmusicmixer.djmixer.audiomixer.provider", new File(MND_MyMusicActivity.this.filePath.get(i)));
                    Intent intent = new Intent("android.intent.action.SEND");
                    intent.setType("audio/*");
                    intent.putExtra("android.intent.extra.STREAM", uriForFile);
                    MND_MyMusicActivity.this.startActivity(Intent.createChooser(intent, "Share Sound File"));
                }
            });
        }

        @Override
        public int getItemCount() {
            return this.filepath.size();
        }
    }

    private void requestStorage() {
        if (Build.VERSION.SDK_INT >= 33) {
            this.permissionsResult.launch(new String[]{this.readMediaPermission, this.readMediaPermission2, this.readMediaPermission3, this.readMediaPermission4});
            return;
        }
        this.permissionsResult.launch(new String[]{this.storagePermission, this.readMediaPermission4});
    }

    private void dialogPermission() {
        this.alertDialog.setTitle(getString(R.string.Grant_Permission));
        this.alertDialog.setCancelable(false);
        this.alertDialog.setMessage(getString(R.string.Please_grant_all_permissions));
        this.alertDialog.setButton(-1, getString(R.string.Go_to_setting), new DialogInterface.OnClickListener() {
            public final void onClick(DialogInterface dialogInterface, int i) {
                MND_MyMusicActivity.this.lambda$dialogPermission$0$MND_MyMusicActivity(dialogInterface, i);
            }
        });
        this.alertDialog.show();
    }

    public void lambda$dialogPermission$0$MND_MyMusicActivity(DialogInterface dialogInterface, int i) {
        this.checkPer = true;
        this.alertDialog.dismiss();
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
        intent.setData(Uri.fromParts("package", getApplicationContext().getPackageName(), null));
        startActivity(intent);
        this.alertDialog.dismiss();
    }

    
    @Override 
    public void onResume() {
        super.onResume();
        if (this.checkPer) {
            this.checkPer = false;
            if (Build.VERSION.SDK_INT >= 33) {
                if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_VIDEO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_IMAGES") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_AUDIO") == 0) {
                    run();
                } else {
                    dialogPermission();
                }
            } else if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0) {
                run();
            } else {
                dialogPermission();
            }
        }
    }

    public void stopVoice() {
        this.playPos = -1;
        try {
            MediaPlayer mediaPlayer2 = this.mediaPlayer;
            if (mediaPlayer2 != null) {
                mediaPlayer2.reset();
                this.mediaPlayer.stop();
                this.mediaPlayer.release();
                this.mediaPlayer = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override 
    public void onPause() {
        super.onPause();
        this.playPos = -1;
        try {
            MediaPlayer mediaPlayer2 = this.mediaPlayer;
            if (mediaPlayer2 != null && mediaPlayer2.isPlaying()) {
                this.mediaPlayer.stop();
                this.mediaPlayer.reset();
            }
            this.musicAdapter.notifyDataSetChanged();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        stopVoice();
        finish();
    }
}
