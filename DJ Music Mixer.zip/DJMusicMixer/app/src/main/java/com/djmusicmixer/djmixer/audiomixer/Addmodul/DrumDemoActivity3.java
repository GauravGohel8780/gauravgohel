package com.djmusicmixer.djmixer.audiomixer.Addmodul;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.djmusicmixer.djmixer.audiomixer.Help;
import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.base.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;

public class DrumDemoActivity3 extends BaseActivity {
    Context context;
    ImageView f139A;
    ImageView f140B;
    ImageView f141C;
    LinearLayout f142D;
    MediaPlayer.OnCompletionListener f143E = new MediaPlayer.OnCompletionListener() {
        public void onCompletion(MediaPlayer mediaPlayer) {
            DrumDemoActivity3.this.f145G.setImageResource(R.drawable.ic_record_play);
            DrumDemoActivity3.this.f162X = false;
        }
    };
    MediaPlayer.OnPreparedListener f144F = new MediaPlayer.OnPreparedListener() {
        public void onPrepared(MediaPlayer mediaPlayer) {
            DrumDemoActivity3.this.f162X = true;
        }
    };
    ImageView f145G;
    MediaPlayer f146H;
    MediaPlayer f147I;
    MediaPlayer f148J;
    MediaPlayer f149K;
    MediaPlayer f150L;
    MediaPlayer f151M;
    MediaPlayer f152N;
    MediaPlayer f153O;
    MediaPlayer f154P;
    MediaPlayer f155Q;
    MediaPlayer f156R1;
    MediaPlayer f157S;
    MediaPlayer f158T;
    MediaPlayer f159U;
    MediaPlayer f160V;
    MediaPlayer f161W;
    public boolean f162X = false;
    public MediaPlayer f163Y = new MediaPlayer();
    ImageView f164k;
    float f165l = 1.0f;
    MediaPlayer.OnErrorListener f166m = new MediaPlayer.OnErrorListener() {
        public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
            DrumDemoActivity3.this.f145G.setImageResource(R.drawable.ic_play_music_drums);
            DrumDemoActivity3.this.f162X = false;
            return false;
        }
    };
    ImageView f167n;
    ImageView f168o;
    ImageView f169p;
    ImageView f170q;
    ImageView f171r;
    ImageView f172s;
    ImageView f173t;
    ImageView f174u;
    ImageView f175v;
    ImageView f176w;
    ImageView f177x;
    ImageView f178y;
    ImageView f179z;

    private void m45p() {
        findViewById(R.id.lbltitle1).setSelected(true);
        this.f146H = MediaPlayer.create(this, (int) R.raw.acymbal1);
        this.f154P = MediaPlayer.create(this, (int) R.raw.acymbal2);
        this.f155Q = MediaPlayer.create(this, (int) R.raw.aride1);
        this.f156R1 = MediaPlayer.create(this, (int) R.raw.aride2);
        this.f157S = MediaPlayer.create(this, (int) R.raw.atom1);
        this.f158T = MediaPlayer.create(this, (int) R.raw.atom2);
        this.f159U = MediaPlayer.create(this, (int) R.raw.atom3);
        this.f160V = MediaPlayer.create(this, (int) R.raw.ahhatpedal);
        this.f161W = MediaPlayer.create(this, (int) R.raw.apercussion2);
        this.f147I = MediaPlayer.create(this, (int) R.raw.apercussion1);
        this.f148J = MediaPlayer.create(this, (int) R.raw.ahhatopen);
        this.f149K = MediaPlayer.create(this, (int) R.raw.ahhatclose);
        this.f150L = MediaPlayer.create(this, (int) R.raw.akick1);
        this.f151M = MediaPlayer.create(this, (int) R.raw.akick2);
        this.f152N = MediaPlayer.create(this, (int) R.raw.asnare1);
        this.f153O = MediaPlayer.create(this, (int) R.raw.asnare2);
        this.f167n = (ImageView) findViewById(R.id.lbl1);
        this.f175v = (ImageView) findViewById(R.id.lbl2);
        this.f176w = (ImageView) findViewById(R.id.lbl3);
        this.f177x = (ImageView) findViewById(R.id.lbl4);
        this.f178y = (ImageView) findViewById(R.id.lbl5);
        this.f179z = (ImageView) findViewById(R.id.lbl6);
        this.f139A = (ImageView) findViewById(R.id.lbl7);
        this.f140B = (ImageView) findViewById(R.id.lbl8);
        this.f141C = (ImageView) findViewById(R.id.lbl9);
        this.f168o = (ImageView) findViewById(R.id.lbl10);
        this.f169p = (ImageView) findViewById(R.id.lbl11);
        this.f170q = (ImageView) findViewById(R.id.lbl12);
        this.f171r = (ImageView) findViewById(R.id.lbl13);
        this.f172s = (ImageView) findViewById(R.id.lbl14);
        this.f173t = (ImageView) findViewById(R.id.lbl15);
        this.f174u = (ImageView) findViewById(R.id.lbl16);
        this.f167n.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity3.this.f146H != null) {
                    DrumDemoActivity3.this.f146H.stop();
                    DrumDemoActivity3.this.f146H.release();
                }
                DrumDemoActivity3 cNX_DrumDemoActivity3 = DrumDemoActivity3.this;
                cNX_DrumDemoActivity3.f146H = MediaPlayer.create(cNX_DrumDemoActivity3, (int) R.raw.acymbal1);
                DrumDemoActivity3.this.f146H.setVolume(DrumDemoActivity3.this.f165l, DrumDemoActivity3.this.f165l);
                DrumDemoActivity3.this.f146H.start();
            }
        });
        this.f175v.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity3.this.f154P != null) {
                    DrumDemoActivity3.this.f154P.stop();
                    DrumDemoActivity3.this.f154P.release();
                }
                DrumDemoActivity3 cNX_DrumDemoActivity3 = DrumDemoActivity3.this;
                cNX_DrumDemoActivity3.f154P = MediaPlayer.create(cNX_DrumDemoActivity3, (int) R.raw.acymbal2);
                DrumDemoActivity3.this.f154P.setVolume(DrumDemoActivity3.this.f165l, DrumDemoActivity3.this.f165l);
                DrumDemoActivity3.this.f154P.start();
            }
        });
        this.f176w.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity3.this.f155Q != null) {
                    DrumDemoActivity3.this.f155Q.stop();
                    DrumDemoActivity3.this.f155Q.release();
                }
                DrumDemoActivity3 cNX_DrumDemoActivity3 = DrumDemoActivity3.this;
                cNX_DrumDemoActivity3.f155Q = MediaPlayer.create(cNX_DrumDemoActivity3, (int) R.raw.aride1);
                DrumDemoActivity3.this.f155Q.setVolume(DrumDemoActivity3.this.f165l, DrumDemoActivity3.this.f165l);
                DrumDemoActivity3.this.f155Q.start();
            }
        });
        this.f177x.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity3.this.f156R1 != null) {
                    DrumDemoActivity3.this.f156R1.stop();
                    DrumDemoActivity3.this.f156R1.release();
                }
                DrumDemoActivity3 cNX_DrumDemoActivity3 = DrumDemoActivity3.this;
                cNX_DrumDemoActivity3.f156R1 = MediaPlayer.create(cNX_DrumDemoActivity3, (int) R.raw.aride2);
                DrumDemoActivity3.this.f156R1.setVolume(DrumDemoActivity3.this.f165l, DrumDemoActivity3.this.f165l);
                DrumDemoActivity3.this.f156R1.start();
            }
        });
        this.f178y.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity3.this.f157S != null) {
                    DrumDemoActivity3.this.f157S.stop();
                    DrumDemoActivity3.this.f157S.release();
                }
                DrumDemoActivity3 cNX_DrumDemoActivity3 = DrumDemoActivity3.this;
                cNX_DrumDemoActivity3.f157S = MediaPlayer.create(cNX_DrumDemoActivity3, (int) R.raw.atom1);
                DrumDemoActivity3.this.f157S.setVolume(DrumDemoActivity3.this.f165l, DrumDemoActivity3.this.f165l);
                DrumDemoActivity3.this.f157S.start();
            }
        });
        this.f179z.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity3.this.f158T != null) {
                    DrumDemoActivity3.this.f158T.stop();
                    DrumDemoActivity3.this.f158T.release();
                }
                DrumDemoActivity3 cNX_DrumDemoActivity3 = DrumDemoActivity3.this;
                cNX_DrumDemoActivity3.f158T = MediaPlayer.create(cNX_DrumDemoActivity3, (int) R.raw.atom2);
                DrumDemoActivity3.this.f158T.setVolume(DrumDemoActivity3.this.f165l, DrumDemoActivity3.this.f165l);
                DrumDemoActivity3.this.f158T.start();
            }
        });
        this.f139A.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity3.this.f159U != null) {
                    DrumDemoActivity3.this.f159U.stop();
                    DrumDemoActivity3.this.f159U.release();
                }
                DrumDemoActivity3 cNX_DrumDemoActivity3 = DrumDemoActivity3.this;
                cNX_DrumDemoActivity3.f159U = MediaPlayer.create(cNX_DrumDemoActivity3, (int) R.raw.atom3);
                DrumDemoActivity3.this.f159U.setVolume(DrumDemoActivity3.this.f165l, DrumDemoActivity3.this.f165l);
                DrumDemoActivity3.this.f159U.start();
            }
        });
        this.f140B.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity3.this.f160V != null) {
                    DrumDemoActivity3.this.f160V.stop();
                    DrumDemoActivity3.this.f160V.release();
                }
                DrumDemoActivity3 cNX_DrumDemoActivity3 = DrumDemoActivity3.this;
                cNX_DrumDemoActivity3.f160V = MediaPlayer.create(cNX_DrumDemoActivity3, (int) R.raw.ahhatpedal);
                DrumDemoActivity3.this.f160V.setVolume(DrumDemoActivity3.this.f165l, DrumDemoActivity3.this.f165l);
                DrumDemoActivity3.this.f160V.start();
            }
        });
        this.f141C.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity3.this.f161W != null) {
                    DrumDemoActivity3.this.f161W.stop();
                    DrumDemoActivity3.this.f161W.release();
                }
                DrumDemoActivity3 cNX_DrumDemoActivity3 = DrumDemoActivity3.this;
                cNX_DrumDemoActivity3.f161W = MediaPlayer.create(cNX_DrumDemoActivity3, (int) R.raw.apercussion2);
                DrumDemoActivity3.this.f161W.setVolume(DrumDemoActivity3.this.f165l, DrumDemoActivity3.this.f165l);
                DrumDemoActivity3.this.f161W.start();
            }
        });
        this.f168o.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity3.this.f147I != null) {
                    DrumDemoActivity3.this.f147I.stop();
                    DrumDemoActivity3.this.f147I.release();
                }
                DrumDemoActivity3 cNX_DrumDemoActivity3 = DrumDemoActivity3.this;
                cNX_DrumDemoActivity3.f147I = MediaPlayer.create(cNX_DrumDemoActivity3, (int) R.raw.apercussion1);
                DrumDemoActivity3.this.f147I.setVolume(DrumDemoActivity3.this.f165l, DrumDemoActivity3.this.f165l);
                DrumDemoActivity3.this.f147I.start();
            }
        });
        this.f169p.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity3.this.f148J != null) {
                    DrumDemoActivity3.this.f148J.stop();
                    DrumDemoActivity3.this.f148J.release();
                }
                DrumDemoActivity3 cNX_DrumDemoActivity3 = DrumDemoActivity3.this;
                cNX_DrumDemoActivity3.f148J = MediaPlayer.create(cNX_DrumDemoActivity3, (int) R.raw.ahhatopen);
                DrumDemoActivity3.this.f148J.setVolume(DrumDemoActivity3.this.f165l, DrumDemoActivity3.this.f165l);
                DrumDemoActivity3.this.f148J.start();
            }
        });
        this.f170q.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity3.this.f149K != null) {
                    DrumDemoActivity3.this.f149K.stop();
                    DrumDemoActivity3.this.f149K.release();
                }
                DrumDemoActivity3 cNX_DrumDemoActivity3 = DrumDemoActivity3.this;
                cNX_DrumDemoActivity3.f149K = MediaPlayer.create(cNX_DrumDemoActivity3, (int) R.raw.ahhatclose);
                DrumDemoActivity3.this.f149K.setVolume(DrumDemoActivity3.this.f165l, DrumDemoActivity3.this.f165l);
                DrumDemoActivity3.this.f149K.start();
            }
        });
        this.f171r.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity3.this.f150L != null) {
                    DrumDemoActivity3.this.f150L.stop();
                    DrumDemoActivity3.this.f150L.release();
                }
                DrumDemoActivity3 cNX_DrumDemoActivity3 = DrumDemoActivity3.this;
                cNX_DrumDemoActivity3.f150L = MediaPlayer.create(cNX_DrumDemoActivity3, (int) R.raw.akick1);
                DrumDemoActivity3.this.f150L.setVolume(DrumDemoActivity3.this.f165l, DrumDemoActivity3.this.f165l);
                DrumDemoActivity3.this.f150L.start();
            }
        });
        this.f172s.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity3.this.f151M != null) {
                    DrumDemoActivity3.this.f151M.stop();
                    DrumDemoActivity3.this.f151M.release();
                }
                DrumDemoActivity3 cNX_DrumDemoActivity3 = DrumDemoActivity3.this;
                cNX_DrumDemoActivity3.f151M = MediaPlayer.create(cNX_DrumDemoActivity3, (int) R.raw.akick2);
                DrumDemoActivity3.this.f151M.setVolume(DrumDemoActivity3.this.f165l, DrumDemoActivity3.this.f165l);
                DrumDemoActivity3.this.f151M.start();
            }
        });
        this.f173t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity3.this.f152N != null) {
                    DrumDemoActivity3.this.f152N.stop();
                    DrumDemoActivity3.this.f152N.release();
                }
                DrumDemoActivity3 cNX_DrumDemoActivity3 = DrumDemoActivity3.this;
                cNX_DrumDemoActivity3.f152N = MediaPlayer.create(cNX_DrumDemoActivity3, (int) R.raw.asnare1);
                DrumDemoActivity3.this.f152N.setVolume(DrumDemoActivity3.this.f165l, DrumDemoActivity3.this.f165l);
                DrumDemoActivity3.this.f152N.start();
            }
        });
        this.f174u.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity3.this.f153O != null) {
                    DrumDemoActivity3.this.f153O.stop();
                    DrumDemoActivity3.this.f153O.release();
                }
                DrumDemoActivity3 cNX_DrumDemoActivity3 = DrumDemoActivity3.this;
                cNX_DrumDemoActivity3.f153O = MediaPlayer.create(cNX_DrumDemoActivity3, (int) R.raw.asnare2);
                DrumDemoActivity3.this.f153O.setVolume(DrumDemoActivity3.this.f165l, DrumDemoActivity3.this.f165l);
                DrumDemoActivity3.this.f153O.start();
            }
        });
    }

    public void mo17318a(String str) {
        mo17320l();
        try {
            this.f163Y.setDataSource(str);
            this.f163Y.prepare();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void mo17319k() {
        if (this.f162X) {
            this.f163Y.start();
            this.f145G.setImageResource(R.drawable.ic_pause_music_drums);
            return;
        }
        Toast.makeText(this, (int) R.string.Please_Select_Spark_Song, Toast.LENGTH_SHORT).show();
    }

    public void mo17320l() {
        this.f162X = false;
        if (this.f163Y.isPlaying()) {
            this.f163Y.stop();
        }
        this.f163Y.reset();
    }

    public void mo17321m() {
        this.f163Y.pause();
        this.f145G.setImageResource(R.drawable.ic_play_music_drums);
    }

    public void mo17322n() {
        this.f163Y.stop();
        this.f145G.setImageResource(R.drawable.ic_play_music_drums);
    }

    public void mo17323o() {
        if (this.f163Y.isPlaying()) {
            this.f163Y.stop();
        }
        this.f163Y.reset();
        this.f163Y.release();
    }

    @Override
    public void onDestroy() {
        mo17323o();
        super.onDestroy();
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 0 && i2 == -1) {
            mo17318a(intent.getStringExtra("song_uri"));
        }
    }

    @Override
    public void onBackPressed() {
        MediaPlayer mediaPlayer = this.f146H;
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            this.f146H.release();
            this.f146H = null;
        }
        MediaPlayer mediaPlayer2 = this.f154P;
        if (mediaPlayer2 != null) {
            mediaPlayer2.stop();
            this.f154P.release();
            this.f154P = null;
        }
        MediaPlayer mediaPlayer3 = this.f155Q;
        if (mediaPlayer3 != null) {
            mediaPlayer3.stop();
            this.f155Q.release();
            this.f155Q = null;
        }
        MediaPlayer mediaPlayer4 = this.f156R1;
        if (mediaPlayer4 != null) {
            mediaPlayer4.stop();
            this.f156R1.release();
            this.f156R1 = null;
        }
        MediaPlayer mediaPlayer5 = this.f157S;
        if (mediaPlayer5 != null) {
            mediaPlayer5.stop();
            this.f157S.release();
            this.f157S = null;
        }
        MediaPlayer mediaPlayer6 = this.f158T;
        if (mediaPlayer6 != null) {
            mediaPlayer6.stop();
            this.f158T.release();
            this.f158T = null;
        }
        MediaPlayer mediaPlayer7 = this.f159U;
        if (mediaPlayer7 != null) {
            mediaPlayer7.stop();
            this.f159U.release();
            this.f159U = null;
        }
        MediaPlayer mediaPlayer8 = this.f160V;
        if (mediaPlayer8 != null) {
            mediaPlayer8.stop();
            this.f160V.release();
            this.f160V = null;
        }
        MediaPlayer mediaPlayer9 = this.f161W;
        if (mediaPlayer9 != null) {
            mediaPlayer9.stop();
            this.f161W.release();
            this.f161W = null;
        }
        MediaPlayer mediaPlayer10 = this.f147I;
        if (mediaPlayer10 != null) {
            mediaPlayer10.stop();
            this.f147I.release();
            this.f147I = null;
        }
        MediaPlayer mediaPlayer11 = this.f148J;
        if (mediaPlayer11 != null) {
            mediaPlayer11.stop();
            this.f148J.release();
            this.f148J = null;
        }
        MediaPlayer mediaPlayer12 = this.f149K;
        if (mediaPlayer12 != null) {
            mediaPlayer12.stop();
            this.f149K.release();
            this.f149K = null;
        }
        MediaPlayer mediaPlayer13 = this.f150L;
        if (mediaPlayer13 != null) {
            mediaPlayer13.stop();
            this.f150L.release();
            this.f150L = null;
        }
        MediaPlayer mediaPlayer14 = this.f151M;
        if (mediaPlayer14 != null) {
            mediaPlayer14.stop();
            this.f151M.release();
            this.f151M = null;
        }
        MediaPlayer mediaPlayer15 = this.f152N;
        if (mediaPlayer15 != null) {
            mediaPlayer15.stop();
            this.f152N.release();
            this.f152N = null;
        }
        MediaPlayer mediaPlayer16 = this.f153O;
        if (mediaPlayer16 != null) {
            mediaPlayer16.stop();
            this.f153O.release();
            this.f153O = null;
        }
        if (this.f163Y.isPlaying()) {
            mo17322n();
        }
        finish();
        super.onBackPressed();
    }

    public void CallIntent() {
        if (this.f163Y.isPlaying()) {
            mo17322n();
        } else {
            startActivityForResult(new Intent(this, SongPickerActivity.class), 0);
        }
    }

    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        getWindow().addFlags(128);
        setContentView(R.layout.activity_drum_demo3);


        this.context = this;
        Help.width = getResources().getDisplayMetrics().widthPixels;
        Help.height = getResources().getDisplayMetrics().heightPixels;
        ImageView imageView = (ImageView) findViewById(R.id.back3);
        this.f164k = imageView;
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumDemoActivity3.this.onBackPressed();
            }
        });
        m45p();
        this.f163Y.setOnPreparedListener(this.f144F);
        this.f163Y.setOnErrorListener(this.f166m);
        this.f163Y.setOnCompletionListener(this.f143E);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.load_song);
        this.f142D = linearLayout;
        linearLayout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumDemoActivity3.this.CallIntent();
            }
        });
        ImageView imageView2 = (ImageView) findViewById(R.id.play_song);
        this.f145G = imageView2;
        imageView2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity3.this.f163Y.isPlaying()) {
                    DrumDemoActivity3.this.mo17321m();
                } else {
                    DrumDemoActivity3.this.mo17319k();
                }
            }
        });
    }
}
