package com.djmusicmixer.djmixer.audiomixer.mixer.Loader;

import android.content.Context;

import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Album;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Songs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

public class AlbumLoader {
    public static String getSongLoaderSortOrder() {
        return "album_key, track, title_key";
    }

    public static ArrayList<Album> getAllAlbums(Context context) {
        return splitIntoAlbums(SongsLoader.getSongs(SongsLoader.makeSongCursor(context, null, null, getSongLoaderSortOrder())));
    }

    public static ArrayList<Album> getAlbums(Context context, String str) {
        return splitIntoAlbums(SongsLoader.getSongs(SongsLoader.makeSongCursor(context, "album LIKE ?", new String[]{"%" + str + "%"}, getSongLoaderSortOrder())));
    }

    public static ArrayList<Album> splitIntoAlbums(ArrayList<Songs> arrayList) {
        ArrayList<Album> arrayList2 = new ArrayList<>();
        if (arrayList != null) {
            Iterator<Songs> it = arrayList.iterator();
            while (it.hasNext()) {
                Songs next = it.next();
                getOrCreateAlbum(arrayList2, next.albumId).songs.add(next);
            }
        }
        Iterator<Album> it2 = arrayList2.iterator();
        while (it2.hasNext()) {
            sortSongsBySongNumber(it2.next());
        }
        return arrayList2;
    }

    private static Album getOrCreateAlbum(ArrayList<Album> arrayList, long j) {
        Iterator<Album> it = arrayList.iterator();
        while (it.hasNext()) {
            Album next = it.next();
            if (!next.songs.isEmpty() && next.songs.get(0).albumId == j) {
                return next;
            }
        }
        Album album = new Album();
        arrayList.add(album);
        return album;
    }

    private static void sortSongsBySongNumber(Album album) {
        Collections.sort(album.songs, new Comparator<Songs>() {
            public int compare(Songs songs, Songs songs2) {
                return songs.songNumber - songs2.songNumber;
            }
        });
    }

    public static Album getAlbum(Context context, long j) {
        Album album = new Album(SongsLoader.getSongs(SongsLoader.makeSongCursor(context, "album_id=?", new String[]{String.valueOf(j)}, getSongLoaderSortOrder())));
        sortSongsBySongNumber(album);
        return album;
    }
}
