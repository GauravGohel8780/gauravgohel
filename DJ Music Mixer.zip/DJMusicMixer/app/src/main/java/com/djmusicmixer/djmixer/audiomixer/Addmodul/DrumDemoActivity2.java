package com.djmusicmixer.djmixer.audiomixer.Addmodul;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.base.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;

public class DrumDemoActivity2 extends BaseActivity {
    float f126k = 1.0f;
    MediaPlayer f127l;
    MediaPlayer f128m;
    MediaPlayer f129n;
    MediaPlayer f130o;
    MediaPlayer f131p;
    MediaPlayer f132q;
    MediaPlayer f133r;
    MediaPlayer f134s;
    MediaPlayer f135t;
    MediaPlayer f136u;
    MediaPlayer f137v;
    MediaPlayer f138w;

    private void m44k() {
        ((ImageView) findViewById(R.id.img1)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity2.this.f127l != null) {
                    DrumDemoActivity2.this.f127l.stop();
                    DrumDemoActivity2.this.f127l.release();
                    DrumDemoActivity2.this.f127l = null;
                }
                DrumDemoActivity2 cNX_DrumDemoActivity2 = DrumDemoActivity2.this;
                cNX_DrumDemoActivity2.f127l = MediaPlayer.create(cNX_DrumDemoActivity2, (int) R.raw.tom01);
                DrumDemoActivity2.this.f127l.setVolume(DrumDemoActivity2.this.f126k, DrumDemoActivity2.this.f126k);
                DrumDemoActivity2.this.f127l.start();
            }
        });
        ((ImageView) findViewById(R.id.img2)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity2.this.f131p != null) {
                    DrumDemoActivity2.this.f131p.stop();
                    DrumDemoActivity2.this.f131p.release();
                    DrumDemoActivity2.this.f131p = null;
                }
                DrumDemoActivity2 cNX_DrumDemoActivity2 = DrumDemoActivity2.this;
                cNX_DrumDemoActivity2.f131p = MediaPlayer.create(cNX_DrumDemoActivity2, (int) R.raw.tom02);
                DrumDemoActivity2.this.f131p.setVolume(DrumDemoActivity2.this.f126k, DrumDemoActivity2.this.f126k);
                DrumDemoActivity2.this.f131p.start();
            }
        });
        ((ImageView) findViewById(R.id.img3)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity2.this.f132q != null) {
                    DrumDemoActivity2.this.f132q.stop();
                    DrumDemoActivity2.this.f132q.release();
                    DrumDemoActivity2.this.f132q = null;
                }
                DrumDemoActivity2 cNX_DrumDemoActivity2 = DrumDemoActivity2.this;
                cNX_DrumDemoActivity2.f132q = MediaPlayer.create(cNX_DrumDemoActivity2, (int) R.raw.crash01);
                DrumDemoActivity2.this.f132q.setVolume(DrumDemoActivity2.this.f126k, DrumDemoActivity2.this.f126k);
                DrumDemoActivity2.this.f132q.start();
            }
        });
        ((ImageView) findViewById(R.id.img4)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity2.this.f133r != null) {
                    DrumDemoActivity2.this.f133r.stop();
                    DrumDemoActivity2.this.f133r.release();
                    DrumDemoActivity2.this.f133r = null;
                }
                DrumDemoActivity2 cNX_DrumDemoActivity2 = DrumDemoActivity2.this;
                cNX_DrumDemoActivity2.f133r = MediaPlayer.create(cNX_DrumDemoActivity2, (int) R.raw.ride02);
                DrumDemoActivity2.this.f133r.setVolume(DrumDemoActivity2.this.f126k, DrumDemoActivity2.this.f126k);
                DrumDemoActivity2.this.f133r.start();
            }
        });
        ((ImageView) findViewById(R.id.img5)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity2.this.f134s != null) {
                    DrumDemoActivity2.this.f134s.stop();
                    DrumDemoActivity2.this.f134s.release();
                    DrumDemoActivity2.this.f134s = null;
                }
                DrumDemoActivity2 cNX_DrumDemoActivity2 = DrumDemoActivity2.this;
                cNX_DrumDemoActivity2.f134s = MediaPlayer.create(cNX_DrumDemoActivity2, (int) R.raw.snare);
                DrumDemoActivity2.this.f134s.setVolume(DrumDemoActivity2.this.f126k, DrumDemoActivity2.this.f126k);
                DrumDemoActivity2.this.f134s.start();
            }
        });
        ((ImageView) findViewById(R.id.img6)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity2.this.f135t != null) {
                    DrumDemoActivity2.this.f135t.stop();
                    DrumDemoActivity2.this.f135t.release();
                    DrumDemoActivity2.this.f135t = null;
                }
                DrumDemoActivity2 cNX_DrumDemoActivity2 = DrumDemoActivity2.this;
                cNX_DrumDemoActivity2.f135t = MediaPlayer.create(cNX_DrumDemoActivity2, (int) R.raw.floor_tom);
                DrumDemoActivity2.this.f135t.setVolume(DrumDemoActivity2.this.f126k, DrumDemoActivity2.this.f126k);
                DrumDemoActivity2.this.f135t.start();
            }
        });
        ((ImageView) findViewById(R.id.img7)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity2.this.f136u != null) {
                    DrumDemoActivity2.this.f136u.stop();
                    DrumDemoActivity2.this.f136u.release();
                    DrumDemoActivity2.this.f136u = null;
                }
                DrumDemoActivity2 cNX_DrumDemoActivity2 = DrumDemoActivity2.this;
                cNX_DrumDemoActivity2.f136u = MediaPlayer.create(cNX_DrumDemoActivity2, (int) R.raw.clap);
                DrumDemoActivity2.this.f136u.setVolume(DrumDemoActivity2.this.f126k, DrumDemoActivity2.this.f126k);
                DrumDemoActivity2.this.f136u.start();
            }
        });
        ((ImageView) findViewById(R.id.img8)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity2.this.f137v != null) {
                    DrumDemoActivity2.this.f137v.stop();
                    DrumDemoActivity2.this.f137v.release();
                    DrumDemoActivity2.this.f137v = null;
                }
                DrumDemoActivity2 cNX_DrumDemoActivity2 = DrumDemoActivity2.this;
                cNX_DrumDemoActivity2.f137v = MediaPlayer.create(cNX_DrumDemoActivity2, (int) R.raw.hi_hato);
                DrumDemoActivity2.this.f137v.setVolume(DrumDemoActivity2.this.f126k, DrumDemoActivity2.this.f126k);
                DrumDemoActivity2.this.f137v.start();
            }
        });
        ((ImageView) findViewById(R.id.img9)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity2.this.f138w != null) {
                    DrumDemoActivity2.this.f138w.stop();
                    DrumDemoActivity2.this.f138w.release();
                    DrumDemoActivity2.this.f138w = null;
                }
                DrumDemoActivity2 cNX_DrumDemoActivity2 = DrumDemoActivity2.this;
                cNX_DrumDemoActivity2.f138w = MediaPlayer.create(cNX_DrumDemoActivity2, (int) R.raw.kick);
                DrumDemoActivity2.this.f138w.setVolume(DrumDemoActivity2.this.f126k, DrumDemoActivity2.this.f126k);
                DrumDemoActivity2.this.f138w.start();
            }
        });
        ((ImageView) findViewById(R.id.img10)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity2.this.f128m != null) {
                    DrumDemoActivity2.this.f128m.stop();
                    DrumDemoActivity2.this.f128m.release();
                    DrumDemoActivity2.this.f128m = null;
                }
                DrumDemoActivity2 cNX_DrumDemoActivity2 = DrumDemoActivity2.this;
                cNX_DrumDemoActivity2.f128m = MediaPlayer.create(cNX_DrumDemoActivity2, (int) R.raw.rim);
                DrumDemoActivity2.this.f128m.setVolume(DrumDemoActivity2.this.f126k, DrumDemoActivity2.this.f126k);
                DrumDemoActivity2.this.f128m.start();
            }
        });
        ((ImageView) findViewById(R.id.img11)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity2.this.f129n != null) {
                    DrumDemoActivity2.this.f129n.stop();
                    DrumDemoActivity2.this.f129n.release();
                    DrumDemoActivity2.this.f129n = null;
                }
                DrumDemoActivity2 cNX_DrumDemoActivity2 = DrumDemoActivity2.this;
                cNX_DrumDemoActivity2.f129n = MediaPlayer.create(cNX_DrumDemoActivity2, (int) R.raw.crash02);
                DrumDemoActivity2.this.f129n.setVolume(DrumDemoActivity2.this.f126k, DrumDemoActivity2.this.f126k);
                DrumDemoActivity2.this.f129n.start();
            }
        });

        ((ImageView) findViewById(R.id.img12)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity2.this.f130o != null) {
                    DrumDemoActivity2.this.f130o.stop();
                    DrumDemoActivity2.this.f130o.release();
                    DrumDemoActivity2.this.f130o = null;
                }
                DrumDemoActivity2 cNX_DrumDemoActivity2 = DrumDemoActivity2.this;
                cNX_DrumDemoActivity2.f130o = MediaPlayer.create(cNX_DrumDemoActivity2, (int) R.raw.hi_hatc);
                DrumDemoActivity2.this.f130o.setVolume(DrumDemoActivity2.this.f126k, DrumDemoActivity2.this.f126k);
                DrumDemoActivity2.this.f130o.start();
            }
        });
    }

    @Override
    public void onBackPressed() {
        MediaPlayer mediaPlayer = this.f127l;
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            this.f127l.release();
            this.f127l = null;
        }
        MediaPlayer mediaPlayer2 = this.f131p;
        if (mediaPlayer2 != null) {
            mediaPlayer2.stop();
            this.f131p.release();
            this.f131p = null;
        }
        MediaPlayer mediaPlayer3 = this.f132q;
        if (mediaPlayer3 != null) {
            mediaPlayer3.stop();
            this.f132q.release();
            this.f132q = null;
        }
        MediaPlayer mediaPlayer4 = this.f133r;
        if (mediaPlayer4 != null) {
            mediaPlayer4.stop();
            this.f133r.release();
            this.f133r = null;
        }
        MediaPlayer mediaPlayer5 = this.f134s;
        if (mediaPlayer5 != null) {
            mediaPlayer5.stop();
            this.f134s.release();
            this.f134s = null;
        }
        MediaPlayer mediaPlayer6 = this.f135t;
        if (mediaPlayer6 != null) {
            mediaPlayer6.stop();
            this.f135t.release();
            this.f135t = null;
        }
        MediaPlayer mediaPlayer7 = this.f136u;
        if (mediaPlayer7 != null) {
            mediaPlayer7.stop();
            this.f136u.release();
            this.f136u = null;
        }
        MediaPlayer mediaPlayer8 = this.f137v;
        if (mediaPlayer8 != null) {
            mediaPlayer8.stop();
            this.f137v.release();
            this.f137v = null;
        }
        MediaPlayer mediaPlayer9 = this.f138w;
        if (mediaPlayer9 != null) {
            mediaPlayer9.stop();
            this.f138w.release();
            this.f138w = null;
        }
        MediaPlayer mediaPlayer10 = this.f128m;
        if (mediaPlayer10 != null) {
            mediaPlayer10.stop();
            this.f128m.release();
            this.f128m = null;
        }
        MediaPlayer mediaPlayer11 = this.f129n;
        if (mediaPlayer11 != null) {
            mediaPlayer11.stop();
            this.f129n.release();
            this.f129n = null;
        }
        MediaPlayer mediaPlayer12 = this.f130o;
        if (mediaPlayer12 != null) {
            mediaPlayer12.stop();
            this.f130o.release();
            this.f130o = null;
        }
        super.onBackPressed();
    }

    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        requestWindowFeature(1);
        getWindow().addFlags(128);
        setContentView(R.layout.activity_drum_demo2);
        m44k();
        this.f127l = MediaPlayer.create(this, (int) R.raw.tom01);
        this.f131p = MediaPlayer.create(this, (int) R.raw.tom02);
        this.f132q = MediaPlayer.create(this, (int) R.raw.crash01);
        this.f133r = MediaPlayer.create(this, (int) R.raw.ride02);
        this.f134s = MediaPlayer.create(this, (int) R.raw.snare);
        this.f135t = MediaPlayer.create(this, (int) R.raw.floor_tom);
        this.f136u = MediaPlayer.create(this, (int) R.raw.clap);
        this.f137v = MediaPlayer.create(this, (int) R.raw.hi_hato);
        this.f138w = MediaPlayer.create(this, (int) R.raw.kick);
        this.f128m = MediaPlayer.create(this, (int) R.raw.rim);
        this.f129n = MediaPlayer.create(this, (int) R.raw.crash02);
        this.f130o = MediaPlayer.create(this, (int) R.raw.hi_hatc);
    }
}
