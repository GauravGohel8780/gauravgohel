package com.djmusicmixer.djmixer.audiomixer.mixer.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class Playlist implements Parcelable {
    public static final Creator<Playlist> CREATOR = new Creator<Playlist>() {
        @Override 
        public Playlist createFromParcel(Parcel parcel) {
            return new Playlist(parcel);
        }

        @Override 
        public Playlist[] newArray(int i) {
            return new Playlist[i];
        }
    };
    public final long f188id;
    public final String name;

    public int describeContents() {
        return 0;
    }

    public Playlist(long j, String str) {
        this.f188id = j;
        this.name = str;
    }

    public Playlist() {
        this.f188id = -1;
        this.name = "";
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass()) {
            Playlist playlist = (Playlist) obj;
            if (this.f188id != playlist.f188id) {
                return false;
            }
            String str = this.name;
            String str2 = playlist.name;
            if (str != null) {
                return str.equals(str2);
            }
            if (str2 == null) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        int i = ((int) this.f188id) * 31;
        String str = this.name;
        return i + (str != null ? str.hashCode() : 0);
    }

    public String toString() {
        return "Playlist{id=" + this.f188id + ", name='" + this.name + '\'' + '}';
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeLong(this.f188id);
        parcel.writeString(this.name);
    }

    protected Playlist(Parcel parcel) {
        this.f188id = parcel.readLong();
        this.name = parcel.readString();
    }
}
