package com.djmusicmixer.djmixer.audiomixer.activites;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.res.AssetManager;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.Toast;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.base.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;

import java.io.IOException;

public class GameActivity extends BaseActivity implements View.OnTouchListener {
    ImageView close;
    ImageView crash1;
    ImageView crash2;
    int f100F;
    Animation f101H;
    int f102I;
    Animation f103K;
    int f104L;
    Animation f105N;
    int f106O;
    int f107P;
    Animation f108b;
    int f109c;
    Animation f110e;
    int f111f;
    Animation f112h;
    int f113i;
    float f114j;
    Animation f115m;
    int f116n;
    Animation f117p;
    int f118q;
    AssetManager f119r;
    Animation f120t;
    int f121u;
    float f122v;
    float f123w;
    Animation f124y;
    int f125z;
    Animation f97B;
    int f98C;
    Animation f99E;
    ImageView floor;
    ImageView kick1;
    ImageView open;
    ImageView ride;
    ImageView snare;
    SoundPool soundpoolk;
    ImageView splash;
    ImageView tom1;
    ImageView tom2;
    ImageView tom3;

    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        setContentView(R.layout.activity_game);
        getWindow().setFlags(1024, 1024);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        int i = Build.VERSION.SDK_INT;
        this.f107P = i;
        if (i >= 19) {
            getWindow().getDecorView().setSystemUiVisibility(5894);
            final View decorView = getWindow().getDecorView();
            decorView.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
                public void onSystemUiVisibilityChange(int i) {
                    if ((i & 4) == 0) {
                        decorView.setSystemUiVisibility(5894);
                    }
                }
            });
        }
        ImageView imageView = (ImageView) findViewById(R.id.crash1);
        this.crash1 = imageView;
        imageView.setOnTouchListener(this);
        ImageView imageView2 = (ImageView) findViewById(R.id.crash2);
        this.crash2 = imageView2;
        imageView2.setOnTouchListener(this);
        ImageView imageView3 = (ImageView) findViewById(R.id.splash);
        this.splash = imageView3;
        imageView3.setOnTouchListener(this);
        ImageView imageView4 = (ImageView) findViewById(R.id.ride);
        this.ride = imageView4;
        imageView4.setOnTouchListener(this);
        ImageView imageView5 = (ImageView) findViewById(R.id.close);
        this.close = imageView5;
        imageView5.setOnTouchListener(this);
        ImageView imageView6 = (ImageView) findViewById(R.id.open);
        this.open = imageView6;
        imageView6.setOnTouchListener(this);
        ImageView imageView7 = (ImageView) findViewById(R.id.floor);
        this.floor = imageView7;
        imageView7.setOnTouchListener(this);
        ImageView imageView8 = (ImageView) findViewById(R.id.tom1);
        this.tom1 = imageView8;
        imageView8.setOnTouchListener(this);
        ImageView imageView9 = (ImageView) findViewById(R.id.tom2);
        this.tom2 = imageView9;
        imageView9.setOnTouchListener(this);
        ImageView imageView10 = (ImageView) findViewById(R.id.tom3);
        this.tom3 = imageView10;
        imageView10.setOnTouchListener(this);
        ImageView imageView11 = (ImageView) findViewById(R.id.snare);
        this.snare = imageView11;
        imageView11.setOnTouchListener(this);
        ImageView imageView12 = (ImageView) findViewById(R.id.kick1);
        this.kick1 = imageView12;
        imageView12.setOnTouchListener(this);
        this.f110e = AnimationUtils.loadAnimation(this, R.anim.touched_crash1);
        this.f112h = AnimationUtils.loadAnimation(this, R.anim.touched_crash2);
        this.f99E = AnimationUtils.loadAnimation(this, R.anim.touched_splash);
        this.f124y = AnimationUtils.loadAnimation(this, R.anim.touched_ride);
        this.f108b = AnimationUtils.loadAnimation(this, R.anim.touched_close);
        this.f120t = AnimationUtils.loadAnimation(this, R.anim.touched_open);
        this.f115m = AnimationUtils.loadAnimation(this, R.anim.touched_floor);
        this.f101H = AnimationUtils.loadAnimation(this, R.anim.touched_tom1);
        this.f103K = AnimationUtils.loadAnimation(this, R.anim.touched_tom2);
        this.f105N = AnimationUtils.loadAnimation(this, R.anim.touched_tom3);
        this.f97B = AnimationUtils.loadAnimation(this, R.anim.touched_snare);
        this.f117p = AnimationUtils.loadAnimation(this, R.anim.touched_kick);
        this.soundpoolk = new SoundPool(6, 3, 0);
        this.f119r = getAssets();
        this.f111f = listassesta("crash1.ogg");
        this.f113i = listassesta("crash2.ogg");
        this.f100F = listassesta("splash.ogg");
        this.f125z = listassesta("ride.ogg");
        this.f109c = listassesta("closehh.ogg");
        this.f121u = listassesta("openhh.ogg");
        this.f116n = listassesta("floor.ogg");
        this.f102I = listassesta("tom1.ogg");
        this.f104L = listassesta("tom2.ogg");
        this.f106O = listassesta("tom3.ogg");
        this.f98C = listassesta("snare.ogg");
        this.f118q = listassesta("kick.ogg");
        Display defaultDisplay = getWindowManager().getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        defaultDisplay.getMetrics(displayMetrics);
        this.f114j = (float) displayMetrics.densityDpi;
        this.f122v = (float) displayMetrics.heightPixels;
        this.f123w = (float) displayMetrics.widthPixels;
        Log.d("DPI:", Float.toString(this.f114j));
        double d = (double) (this.f114j / this.f122v);
        Double.isNaN(d);
        Double.isNaN(d);
        Double.isNaN(d);
        double d2 = d * 2.5d;
        float f = (float) ((int) (195.0d / d2));
        float f2 = (float) ((int) (165.0d / d2));
        int applyDimension = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, f2, getResources().getDisplayMetrics());
        float f3 = (float) ((int) (125.0d / d2));
        int applyDimension2 = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, f3, getResources().getDisplayMetrics());
        float f4 = (float) ((int) (140.0d / d2));
        int applyDimension3 = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, f4, getResources().getDisplayMetrics());
        int applyDimension4 = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, f3, getResources().getDisplayMetrics());
        ViewGroup.LayoutParams layoutParams = this.crash1.getLayoutParams();
        int applyDimension5 = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (float) ((int) (155.0d / d2)), getResources().getDisplayMetrics());
        layoutParams.width = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (float) ((int) (175.0d / d2)), getResources().getDisplayMetrics());
        this.crash1.getLayoutParams().height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, f, getResources().getDisplayMetrics());
        this.crash2.getLayoutParams().width = applyDimension;
        this.crash2.getLayoutParams().height = applyDimension;
        this.splash.getLayoutParams().width = applyDimension2;
        this.splash.getLayoutParams().height = applyDimension2;
        this.ride.getLayoutParams().width = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (float) ((int) (210.0d / d2)), getResources().getDisplayMetrics());
        this.ride.getLayoutParams().height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (float) ((int) (215.0d / d2)), getResources().getDisplayMetrics());
        this.close.getLayoutParams().width = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, f4, getResources().getDisplayMetrics());
        this.close.getLayoutParams().height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, f2, getResources().getDisplayMetrics());
        this.open.getLayoutParams().width = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (float) ((int) (120.0d / d2)), getResources().getDisplayMetrics());
        this.open.getLayoutParams().height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (float) ((int) (135.0d / d2)), getResources().getDisplayMetrics());
        this.floor.getLayoutParams().width = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (float) ((int) (150.0d / d2)), getResources().getDisplayMetrics());
        this.floor.getLayoutParams().height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (float) ((int) (205.0d / d2)), getResources().getDisplayMetrics());
        this.tom1.getLayoutParams().width = applyDimension4;
        this.tom1.getLayoutParams().height = applyDimension4;
        this.tom2.getLayoutParams().width = applyDimension3;
        this.tom2.getLayoutParams().height = applyDimension3;
        this.tom3.getLayoutParams().width = applyDimension5;
        this.tom3.getLayoutParams().height = applyDimension5;
        this.kick1.getLayoutParams().width = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (float) ((int) (265.0d / d2)), getResources().getDisplayMetrics());
        this.kick1.getLayoutParams().height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (float) ((int) (172.0d / d2)), getResources().getDisplayMetrics());
        this.snare.getLayoutParams().width = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, f, getResources().getDisplayMetrics());
        this.snare.getLayoutParams().height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (float) ((int) (180.0d / d2)), getResources().getDisplayMetrics());
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        int action = motionEvent.getAction() & 255;
        if (action != 0 && action != 5) {
            return true;
        }
        switch (view.getId()) {
            case R.id.close:
                this.close.startAnimation(this.f108b);
                this.soundpoolk.play(this.f109c, 1.0f, 1.0f, 1, 0, 1.0f);
                return true;
            case R.id.crash1:
                this.crash1.startAnimation(this.f110e);
                this.soundpoolk.play(this.f111f, 1.0f, 1.0f, 1, 0, 1.0f);
                return true;
            case R.id.crash2:
                this.crash2.startAnimation(this.f112h);
                this.soundpoolk.play(this.f113i, 1.0f, 1.0f, 1, 0, 1.0f);
                return true;
            case R.id.floor:
                this.floor.startAnimation(this.f115m);
                this.soundpoolk.play(this.f116n, 1.0f, 1.0f, 1, 0, 1.0f);
                return true;
            case R.id.kick1:
                this.kick1.startAnimation(this.f117p);
                this.soundpoolk.play(this.f118q, 1.0f, 1.0f, 1, 0, 1.0f);
                return true;
            case R.id.open:
                this.open.startAnimation(this.f120t);
                this.soundpoolk.play(this.f121u, 1.0f, 1.0f, 1, 0, 1.0f);
                return true;
            case R.id.ride:
                this.ride.startAnimation(this.f124y);
                this.soundpoolk.play(this.f125z, 1.0f, 1.0f, 1, 0, 1.0f);
                return true;
            case R.id.snare:
                this.snare.startAnimation(this.f97B);
                this.soundpoolk.play(this.f98C, 1.0f, 1.0f, 1, 0, 1.0f);
                return true;
            case R.id.splash:
                this.splash.startAnimation(this.f99E);
                this.soundpoolk.play(this.f100F, 1.0f, 1.0f, 1, 0, 1.0f);
                return true;
            case R.id.tom1:
                this.tom1.startAnimation(this.f101H);
                this.soundpoolk.play(this.f102I, 1.0f, 1.0f, 1, 0, 1.0f);
                return true;
            case R.id.tom2:
                this.tom2.startAnimation(this.f103K);
                this.soundpoolk.play(this.f104L, 1.0f, 1.0f, 1, 0, 1.0f);
                return true;
            case R.id.tom3:
                this.tom3.startAnimation(this.f105N);
                this.soundpoolk.play(this.f106O, 1.0f, 1.0f, 1, 0, 1.0f);
                return true;
            default:
                return true;
        }
    }

    private int listassesta(String str) {
        try {
            return this.soundpoolk.load(this.f119r.openFd(str), 1);
        } catch (IOException e) {
            e.printStackTrace();
            Context applicationContext = getApplicationContext();
            Toast.makeText(applicationContext, "Load failed " + str, Toast.LENGTH_SHORT).show();
            Log.d("FAILED", "Load failed " + str);
            return -1;
        }
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        finish();
    }
}
