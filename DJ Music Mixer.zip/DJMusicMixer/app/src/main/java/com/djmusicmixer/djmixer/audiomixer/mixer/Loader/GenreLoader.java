package com.djmusicmixer.djmixer.audiomixer.mixer.Loader;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;

import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Genres;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Songs;

import java.util.ArrayList;

public class GenreLoader {
    public static final String NAME = "name";

    public static ArrayList<Genres> getAllGenres(Context context) {
        return getGenresFromCursor(context, makeGenreCursor(context));
    }

    public static ArrayList<Songs> getSongs(Context context, long j) {
        return SongsLoader.getSongs(makeGenreSongCursor(context, j));
    }

    private static ArrayList<Genres> getGenresFromCursor(Context context, Cursor cursor) {
        ArrayList<Genres> arrayList = new ArrayList<>();
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    Genres genreFromCursor = getGenreFromCursor(context, cursor);
                    if (genreFromCursor.songCount > 0) {
                        arrayList.add(genreFromCursor);
                    } else {
                        try {
                            ContentResolver contentResolver = context.getContentResolver();
                            Uri uri = MediaStore.Audio.Genres.EXTERNAL_CONTENT_URI;
                            contentResolver.delete(uri, "_id == " + genreFromCursor.f187id, null);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                } while (cursor.moveToNext());
            }
            cursor.close();
        }
        return arrayList;
    }

    private static Genres getGenreFromCursor(Context context, Cursor cursor) {
        long j = cursor.getLong(0);
        return new Genres(j, cursor.getString(1), getSongs(context, j).size());
    }

    private static Cursor makeGenreSongCursor(Context context, long j) {
        try {
            return context.getContentResolver().query(MediaStore.Audio.Genres.Members.getContentUri("external", j), SongsLoader.projection, "is_music=1 AND title != ''", null, "title_key");
        } catch (SecurityException unused) {
            return null;
        }
    }

    private static Cursor makeGenreCursor(Context context) {
        try {
            return context.getContentResolver().query(MediaStore.Audio.Genres.EXTERNAL_CONTENT_URI, new String[]{"_id", "name"}, null, null, "name");
        } catch (SecurityException unused) {
            return null;
        }
    }
}
