package com.djmusicmixer.djmixer.audiomixer.Drums;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.util.AttributeSet;

import com.djmusicmixer.djmixer.audiomixer.R;

public class Drum extends androidx.appcompat.widget.AppCompatImageView {
    public static final int[] CNX_Drum = {R.attr.name, R.attr.sound, R.attr.sound2};
    private int f348h;
    private int f349w;
    private int f350x;
    private int f351y;
    public int lastSoundIndex = 0;
    public int soundId1;
    public int soundId2;
    public int soundResId1;
    public int soundResId2;
    public int streamId;
    private RectF touchArea;

    public Drum(Context context) {
        super(context);
    }

    public Drum(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(attributeSet);
    }
    @SuppressLint("ResourceType")
    private void init(AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, CNX_Drum);
        this.soundResId1 = obtainStyledAttributes.getResourceId(1, -1);
        this.soundResId2 = obtainStyledAttributes.getResourceId(2, -1);
        obtainStyledAttributes.recycle();
    }

    public boolean isTouched(int i, int i2) {
        return this.touchArea.contains((float) i, (float) i2);
    }

    public void doMeasure() {
        this.f350x = getLeft() + 0;
        this.f351y = getTop() + 0;
        this.f349w = getWidth();
        this.f348h = getHeight();
        int i = this.f350x;
        int i2 = this.f351y;
        this.touchArea = new RectF((float) i, (float) i2, (float) (i + this.f349w), (float) (i2 + this.f348h));
    }

    public int getSoundId(int i, int i2) {
        if (this.soundResId2 == -1) {
            this.lastSoundIndex = 0;
            return this.soundId1;
        }
        double d = (double) this.f348h;
        Double.isNaN(d);
        Double.isNaN(d);
        Double.isNaN(d);
        if (((double) (i2 - this.f351y)) > d * 0.6d) {
            this.lastSoundIndex = 1;
            return this.soundId2;
        }
        this.lastSoundIndex = 0;
        return this.soundId1;
    }

    public int getSoundId(int i) {
        return i == 0 ? this.soundId1 : this.soundId2;
    }
}
