package com.djmusicmixer.djmixer.audiomixer.mixer.Loader;

import android.content.Context;
import android.database.Cursor;
import android.provider.MediaStore;

import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Songs;

import java.util.ArrayList;

public class SongsLoader {
    protected static final String base_selection = "is_music=1 AND title != ''";
    protected static final String[] projection = {"_id", "title", "track", "year", "duration", "_data", "date_modified", "album_id", "album", "artist_id", "artist"};

    public static ArrayList<Songs> getAllSongs(Context context) {
        return getSongs(makeSongCursor(context, null, null));
    }

    public static ArrayList<Songs> getSongs(Context context, String str) {
        return getSongs(makeSongCursor(context, "title LIKE ?", new String[]{"%" + str + "%"}));
    }

    public static Cursor makeSongCursor(Context context, String str, String[] strArr) {
        return makeSongCursor(context, str, strArr, "title_key");
    }

    public static Cursor makeSongCursor(Context context, String str, String[] strArr, String str2) {
        String str3;
        if (str == null || str.trim().equals("")) {
            str3 = base_selection;
        } else {
            str3 = "is_music=1 AND title != '' AND " + str;
        }
        try {
            return context.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, str3, strArr, str2);
        } catch (SecurityException unused) {
            return null;
        }
    }

    public static ArrayList<Songs> getSongs(Cursor cursor) {
        ArrayList<Songs> arrayList = new ArrayList<>();
        if (cursor == null || !cursor.moveToFirst()) {
            if (cursor != null) {
                cursor.close();
            }
            return arrayList;
        }
        do {
            arrayList.add(getSongFromCursor(cursor));
        } while (cursor.moveToNext());
        return arrayList;
    }

    private static Songs getSongFromCursor(Cursor cursor) {
        return new Songs(cursor.getLong(0), cursor.getString(1), cursor.getInt(2), cursor.getInt(3), cursor.getLong(4), cursor.getString(5), cursor.getLong(6), cursor.getLong(7), cursor.getString(8), cursor.getLong(9), cursor.getString(10));
    }
}
