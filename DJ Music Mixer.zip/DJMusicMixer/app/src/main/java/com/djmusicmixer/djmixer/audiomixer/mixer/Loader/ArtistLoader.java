package com.djmusicmixer.djmixer.audiomixer.mixer.Loader;

import android.content.Context;

import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Album;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Artist;

import java.util.ArrayList;
import java.util.Iterator;

public class ArtistLoader {
    public static String getSongLoaderSortOrder() {
        return "artist_key, year DESC, track, title_key";
    }

    public static ArrayList<Artist> getAllArtists(Context context) {
        return splitIntoArtists(AlbumLoader.splitIntoAlbums(SongsLoader.getSongs(SongsLoader.makeSongCursor(context, null, null, getSongLoaderSortOrder()))));
    }

    public static ArrayList<Artist> getArtists(Context context, String str) {
        return splitIntoArtists(AlbumLoader.splitIntoAlbums(SongsLoader.getSongs(SongsLoader.makeSongCursor(context, "artist LIKE ?", new String[]{"%" + str + "%"}, getSongLoaderSortOrder()))));
    }

    public static ArrayList<Artist> splitIntoArtists(ArrayList<Album> arrayList) {
        ArrayList<Artist> arrayList2 = new ArrayList<>();
        if (arrayList != null) {
            Iterator<Album> it = arrayList.iterator();
            while (it.hasNext()) {
                Album next = it.next();
                getOrCreateArtist(arrayList2, next.getArtistId()).albums.add(next);
            }
        }
        return arrayList2;
    }

    private static Artist getOrCreateArtist(ArrayList<Artist> arrayList, long j) {
        Iterator<Artist> it = arrayList.iterator();
        while (it.hasNext()) {
            Artist next = it.next();
            if (!next.albums.isEmpty() && !next.albums.get(0).songs.isEmpty() && next.albums.get(0).songs.get(0).artistId == j) {
                return next;
            }
        }
        Artist artist = new Artist();
        arrayList.add(artist);
        return artist;
    }

    public static Artist getArtist(Context context, long j) {
        return new Artist(AlbumLoader.splitIntoAlbums(SongsLoader.getSongs(SongsLoader.makeSongCursor(context, "artist_id=?", new String[]{String.valueOf(j)}, getSongLoaderSortOrder()))));
    }
}
