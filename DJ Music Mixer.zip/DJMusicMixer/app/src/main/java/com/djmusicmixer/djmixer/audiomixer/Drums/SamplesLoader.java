package com.djmusicmixer.djmixer.audiomixer.Drums;

import android.content.Context;
import android.os.Environment;

import com.djmusicmixer.djmixer.audiomixer.R;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SamplesLoader {
    private static final String SAMPLES_FOLDER = "drumset";
    public static String audioFile;
    public static String filePath1;

    public static String saveSample(String str, List<SampleSlot> list, Context context) throws IOException {
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC) + File.separator + context.getResources().getString(R.string.app_name));
        file.mkdirs();
        String format = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        audioFile = "drum" + format;
        filePath1 = file.getAbsolutePath() + File.separator + audioFile;
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(new FileOutputStream(filePath1));
        BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);
        for (int i = 0; i < list.size(); i++) {
            bufferedWriter.write(list.get(i).getSerializableString());
            bufferedWriter.newLine();
            bufferedWriter.flush();
        }
        outputStreamWriter.close();
        return filePath1;
    }

    public static List<SampleSlot> loadSample(File file) throws IOException {
        ArrayList arrayList = new ArrayList();
        InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(file));
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
        while (true) {
            String readLine = bufferedReader.readLine();
            if (readLine != null) {
                arrayList.add(SampleSlot.createFromSerializableString(readLine));
            } else {
                inputStreamReader.close();
                return arrayList;
            }
        }
    }

    public static File[] getSamples(String str) {
        return new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) + File.separator + SAMPLES_FOLDER).listFiles(new FilenameFilter() {
            public boolean accept(File file, String str) {
                return str.startsWith(str);
            }
        });
    }

    private static String constructFileName(String str, String str2) {
        return str + "_" + str2;
    }

    public static String parseLayoutName(String str) {
        String[] split = str.split("/");
        return split[split.length - 1];
    }
}
