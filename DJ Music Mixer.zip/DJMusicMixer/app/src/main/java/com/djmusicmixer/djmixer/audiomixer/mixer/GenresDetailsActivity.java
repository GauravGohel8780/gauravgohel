package com.djmusicmixer.djmixer.audiomixer.mixer;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;
import com.djmusicmixer.djmixer.audiomixer.mixer.Fragment.LibSongsAdapter;
import com.djmusicmixer.djmixer.audiomixer.mixer.Loader.GenreLoader;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Genres;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Songs;
import com.djmusicmixer.djmixer.audiomixer.mixer.Utils.MusicUtil;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.util.ArrayList;
import java.util.Objects;

public class GenresDetailsActivity extends BaseActivity {
    public static Activity activity;
    private Genres genres;
    private RecyclerView recyclerView;
    protected LibSongsAdapter songsAdapter;
    protected ArrayList<Songs> songsList = new ArrayList<>();
    private TextView tv_empty;
    protected TextView tv_title;


    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        
        super.onCreate(bundle);
        setContentView(R.layout.activity_rkappzia_music_details);
        init();
        bindView();
    }

    private void init() {
        this.tv_title = (TextView) findViewById(R.id.tv_title_rkappzia);
        this.recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        this.tv_empty = (TextView) findViewById(R.id.tv_empty);
        Bundle extras = getIntent().getExtras();
        Objects.requireNonNull(extras);
        Genres genres2 = (Genres) extras.getParcelable("genres");
        this.genres = genres2;
        if (genres2 != null) {
            this.tv_title.setText(genres2.name);
        }
        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(GenresDetailsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        GenresDetailsActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
    }

    private void bindView() {
        ArrayList<Songs> songs = GenreLoader.getSongs(this, this.genres.f187id);
        this.songsList = songs;
        this.tv_empty.setVisibility(songs.size() > 0 ? View.GONE : View.VISIBLE);
        if (this.songsList.size() > 0) {
            this.recyclerView.setHasFixedSize(true);
            this.recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
            LibSongsAdapter libSongsAdapter = new LibSongsAdapter(this, this.songsList, "genres");
            this.songsAdapter = libSongsAdapter;
            this.recyclerView.setAdapter(libSongsAdapter);
        }
    }

    public void onGenresSongsClick(final int i, View view, String str, boolean z) {
        if (str.equals("more")) {
            PopupMenu popupMenu = new PopupMenu(new ContextThemeWrapper(this, (int) R.style.PopupDialogTheme), view);
            popupMenu.getMenuInflater().inflate(R.menu.menu_music_item_more_rk, popupMenu.getMenu());
            popupMenu.show();
            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                public boolean onMenuItemClick(MenuItem menuItem) {
                    if (menuItem.getItemId() != R.id.add_to_playlist) {
                        return true;
                    }
                    GenresDetailsActivity genresDetailsActivity = GenresDetailsActivity.this;
                    BaseActivity.addToPlaylistDialog(genresDetailsActivity, genresDetailsActivity.songsList.get(i));
                    return true;
                }
            });
            return;
        }
        Uri albumCoverUri = MusicUtil.getAlbumCoverUri(this.songsList.get(i).albumId);
        Intent intent = new Intent();
        intent.putExtra("selected_music_path", this.songsList.get(i).data);
        intent.putExtra("selected_music_name", this.songsList.get(i).title);
        intent.putExtra("selected_music_album", albumCoverUri.toString());
        setResult(-1, intent);
        finish();
    }
}
