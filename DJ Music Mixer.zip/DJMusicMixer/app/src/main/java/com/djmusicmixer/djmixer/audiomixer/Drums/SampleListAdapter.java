package com.djmusicmixer.djmixer.audiomixer.Drums;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.djmusicmixer.djmixer.audiomixer.R;

import java.io.File;

public class SampleListAdapter extends BaseAdapter {
    private View.OnClickListener deleteListener;
    private File[] files = new File[0];
    private LayoutInflater inflater;

    public long getItemId(int i) {
        return (long) i;
    }

    public SampleListAdapter(LayoutInflater layoutInflater) {
        this.inflater = layoutInflater;
    }

    public void setDeleteListener(View.OnClickListener onClickListener) {
        this.deleteListener = onClickListener;
    }

    public File[] getFiles() {
        return this.files;
    }

    public void setFiles(File[] fileArr) {
        this.files = fileArr;
    }

    public int getCount() {
        File[] fileArr = this.files;
        if (fileArr.length > 0) {
            return fileArr.length;
        }
        return 0;
    }

    public Object getItem(int i) {
        return this.files[i];
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.inflater.inflate(R.layout.file_row, (ViewGroup) null);
        }
        ImageView imageView = (ImageView) view.findViewById(R.id.btn_delete);
        imageView.setFocusable(false);
        File file = this.files[i];
        ((TextView) view.findViewById(R.id.filename)).setText(file.getName());
        imageView.setTag(file);
        imageView.setOnClickListener(this.deleteListener);
        view.setTag(file);
        return view;
    }
}
