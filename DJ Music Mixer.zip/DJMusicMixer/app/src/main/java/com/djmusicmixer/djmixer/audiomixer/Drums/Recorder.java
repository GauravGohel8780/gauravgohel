package com.djmusicmixer.djmixer.audiomixer.Drums;

import java.util.ArrayList;
import java.util.List;

public class Recorder {
    private boolean isRecording = false;
    public List<SampleSlot> sampleFinal;
    public List<SampleSlot> sampleTmp;
    public SampleSlot slots;

    public boolean isReadyForSave() {
        List<SampleSlot> list = this.sampleFinal;
        return list != null && list.size() > 0;
    }

    public boolean isRecording() {
        return this.isRecording;
    }

    public void startRecord() {
        this.sampleTmp = new ArrayList();
        this.sampleFinal = new ArrayList();
        this.isRecording = true;
    }

    public void add(int i, int i2, long j) {
        SampleSlot cNX_SampleSlot = new SampleSlot();
        cNX_SampleSlot.drumId = i;
        cNX_SampleSlot.soundIndex = i2;
        cNX_SampleSlot.playNextAfterMs = j;
        this.sampleTmp.add(cNX_SampleSlot);
    }

    public void stopRecording() {
        int i = 0;
        this.isRecording = false;
        while (i < this.sampleTmp.size()) {
            SampleSlot cNX_SampleSlot = this.sampleTmp.get(i);
            if (i == this.sampleTmp.size() - 1) {
                SampleSlot cNX_SampleSlot2 = new SampleSlot();
                this.slots = cNX_SampleSlot2;
                cNX_SampleSlot2.drumId = cNX_SampleSlot.drumId;
                this.slots.soundIndex = cNX_SampleSlot.soundIndex;
                SampleSlot cNX_SampleSlot3 = this.slots;
                cNX_SampleSlot3.playNextAfterMs = -1;
                this.sampleFinal.add(cNX_SampleSlot3);
                return;
            }
            i++;
            SampleSlot cNX_SampleSlot4 = new SampleSlot();
            this.slots = cNX_SampleSlot4;
            cNX_SampleSlot4.drumId = cNX_SampleSlot.drumId;
            this.slots.soundIndex = cNX_SampleSlot.soundIndex;
            this.slots.playNextAfterMs = this.sampleTmp.get(i).playNextAfterMs - cNX_SampleSlot.playNextAfterMs;
            this.sampleFinal.add(this.slots);
        }
    }

    public List<SampleSlot> getSample() {
        return this.sampleFinal;
    }
}
