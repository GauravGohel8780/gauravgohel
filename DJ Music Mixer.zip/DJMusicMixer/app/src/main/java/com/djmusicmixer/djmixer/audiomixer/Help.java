package com.djmusicmixer.djmixer.audiomixer;

import android.content.Context;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;


public class Help {
    public static int height;
    public static int width;
    public static int m35w(int i) {
        return (width * i) / 1080;
    }
    public static int m36h(int i) {
        int i2 = height;
        if (i2 <= 1280 || i2 >= 1920) {
            return (i2 * i) / 1920;
        }
        return (i2 * i) / 1280;
    }

    public static void Toast(Context context, String str) {
        Toast.makeText(context, str, Toast.LENGTH_SHORT).show();
    }


    public static void setSize(View view, int i, int i2, boolean z) {
        view.getLayoutParams().width = m35w(i);
        if (z) {
            view.getLayoutParams().height = m36h(i2);
            return;
        }
        view.getLayoutParams().height = m35w(i2);
    }

    public static void gone(View view) {
        view.setVisibility(View.GONE);
    }

    public static void visible(View view) {
        view.setVisibility(View.VISIBLE);
    }

    public static void invisible(View view) {
        view.setVisibility(View.INVISIBLE);
    }

    public static void setCenter(View view) {
        ((RelativeLayout.LayoutParams) view.getLayoutParams()).addRule(13);
    }

    public static String getString(Context context, int i) {
        return context.getResources().getString(i);
    }

    public static int getColor(Context context, int i) {
        return context.getResources().getColor(i);
    }
}
