package com.djmusicmixer.djmixer.audiomixer.mixer.Fragment;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.mixer.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.mixer.Loader.SongsLoader;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Songs;
import com.djmusicmixer.djmixer.audiomixer.mixer.Utils.MusicUtil;

import java.util.ArrayList;
import java.util.Objects;

public class LibSongsFragment extends Fragment {
    private RecyclerView recyclerView;
    private LibSongsAdapter songsAdapter;
    public ArrayList<Songs> songsList = new ArrayList<>();
    private TextView tv_empty;

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_rkappzia_music_library, viewGroup, false);
        init(inflate);
        return inflate;
    }

    private void init(View view) {
        this.recyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        this.tv_empty = (TextView) view.findViewById(R.id.tv_empty);
        FragmentActivity activity = getActivity();
        Objects.requireNonNull(activity);
        activity.runOnUiThread(new Runnable() {
            public void run() {
                LibSongsFragment libSongsFragment = LibSongsFragment.this;
                Context context = libSongsFragment.getContext();
                Objects.requireNonNull(context);
                libSongsFragment.songsList = SongsLoader.getAllSongs(context);
            }
        });
    }

    @Override
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        ArrayList<Songs> arrayList = this.songsList;
        if (arrayList != null) {
            this.tv_empty.setVisibility(arrayList.size() > 0 ? View.GONE : View.VISIBLE);
            if (this.songsList.size() > 0) {
                this.recyclerView.setHasFixedSize(true);
                this.recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), RecyclerView.VERTICAL, false));
                LibSongsAdapter libSongsAdapter = new LibSongsAdapter(getActivity(), this.songsList, "songs");
                this.songsAdapter = libSongsAdapter;
                this.recyclerView.setAdapter(libSongsAdapter);
                this.songsAdapter.setOnItemClickListener(new LibSongsAdapter.OnItemClickListener() {
                    @Override
                    public void onClick(final int i, View view, String str, boolean z) {
                        if (str.equals("more")) {
                            PopupMenu popupMenu = new PopupMenu(new ContextThemeWrapper(LibSongsFragment.this.getActivity(), (int) R.style.PopupDialogTheme), view);
                            popupMenu.getMenuInflater().inflate(R.menu.menu_music_item_more_rk, popupMenu.getMenu());
                            popupMenu.show();
                            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                                public boolean onMenuItemClick(MenuItem menuItem) {
                                    if (menuItem.getItemId() != R.id.add_to_playlist) {
                                        return true;
                                    }
                                    BaseActivity.addToPlaylistDialog(LibSongsFragment.this.getActivity(), LibSongsFragment.this.songsList.get(i));
                                    return true;
                                }
                            });
                            return;
                        }
                        Uri albumCoverUri = MusicUtil.getAlbumCoverUri(LibSongsFragment.this.songsList.get(i).albumId);
                        Intent intent = new Intent();
                        intent.setFlags(268468224);
                        intent.putExtra("selected_music_path", LibSongsFragment.this.songsList.get(i).data);
                        intent.putExtra("selected_music_name", LibSongsFragment.this.songsList.get(i).title);
                        intent.putExtra("selected_music_album", albumCoverUri.toString());
                        FragmentActivity activity = LibSongsFragment.this.getActivity();
                        Objects.requireNonNull(activity);
                        activity.setResult(-1, intent);
                        LibSongsFragment.this.getActivity().finish();
                    }
                });
            }
        }
    }

    @Override
    public void onResume() {
        LibSongsAdapter libSongsAdapter = this.songsAdapter;
        if (libSongsAdapter != null) {
            libSongsAdapter.notifyDataSetChanged();
        }
        super.onResume();
    }
}
