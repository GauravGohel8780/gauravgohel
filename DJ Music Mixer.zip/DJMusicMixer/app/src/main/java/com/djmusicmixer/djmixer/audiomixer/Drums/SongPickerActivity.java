package com.djmusicmixer.djmixer.audiomixer.Drums;



import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.app.ActivityCompat;

import com.djmusicmixer.djmixer.audiomixer.Help;
import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.base.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.util.ArrayList;
import java.util.Map;

public class SongPickerActivity extends BaseActivity {
    SongListAdapter adapter;
    AlertDialog alertDialog;
    boolean checkPer = false;
    AdapterView.OnItemClickListener listener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
            getInstance(SongPickerActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    Intent intent = new Intent();
                    intent.putExtra("song_uri", ((Song) view.getTag()).data);
                    SongPickerActivity.this.setResult(-1, intent);
                    SongPickerActivity cNX_SongPickerActivity = SongPickerActivity.this;
                    Toast.makeText(cNX_SongPickerActivity, cNX_SongPickerActivity.getString(R.string.Song_is_Loaded), Toast.LENGTH_SHORT).show();
                    SongPickerActivity.this.finish();
                }
            }, MAIN_CLICK);
        }
    };
    LinearLayout llNoMusic;
    private ActivityResultLauncher<String[]> permissionsResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
        public void onActivityResult(Map<String, Boolean> map) {
            if (Build.VERSION.SDK_INT < 24) {
                SongPickerActivity.this.run();
            } else if (map.values().stream().allMatch(Boolean::booleanValue)) {
                SongPickerActivity.this.run();
            } else {
                SongPickerActivity.this.dialogPermission();
            }
        }
    });
    private String readMediaPermission = "android.permission.READ_MEDIA_VIDEO";
    private String readMediaPermission2 = "android.permission.READ_MEDIA_IMAGES";
    private String readMediaPermission3 = "android.permission.READ_MEDIA_AUDIO";
    private String readMediaPermission4 = "android.permission.RECORD_AUDIO";
    private String storagePermission = "android.permission.READ_EXTERNAL_STORAGE";

    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        requestWindowFeature(1);
        getWindow().addFlags(128);
        setContentView(R.layout.activity_song_picker);


        getWindow().setFlags(1024, 1024);
        Help.width = getResources().getDisplayMetrics().widthPixels;
        Help.height = getResources().getDisplayMetrics().heightPixels;
        this.llNoMusic = (LinearLayout) findViewById(R.id.ll_no_music);
        if (Build.VERSION.SDK_INT >= 33) {
            if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_VIDEO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_IMAGES") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_AUDIO") == 0) {
                run();
            } else {
                requestStorage();
            }
        } else if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0) {
            run();
        } else {
            requestStorage();
        }
    }

    private void run() {
        Cursor query = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, new String[]{"_id", "artist", "title", "_data", "_display_name", "duration"}, "is_music != 0", null, null);
        ArrayList arrayList = new ArrayList();
        while (query.moveToNext()) {
            Song cNX_Song = new Song();
            cNX_Song.artist = query.getString(1);
            cNX_Song.title = query.getString(2);
            cNX_Song.data = query.getString(3);
            arrayList.add(cNX_Song);
        }
        SongListAdapter cNX_SongListAdapter = new SongListAdapter(this);
        this.adapter = cNX_SongListAdapter;
        cNX_SongListAdapter.setSongs(arrayList);
        if (arrayList.size() > 0) {
            this.llNoMusic.setVisibility(View.GONE);
        } else {
            this.llNoMusic.setVisibility(View.VISIBLE);
        }
        ListView listView = (ListView) findViewById(R.id.song_list_view);
        listView.setAdapter((ListAdapter) this.adapter);
        listView.setOnItemClickListener(this.listener);
        ((ImageView) findViewById(R.id.back)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(SongPickerActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        SongPickerActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
    }

    private void requestStorage() {
        if (Build.VERSION.SDK_INT >= 33) {
            this.permissionsResult.launch(new String[]{this.readMediaPermission, this.readMediaPermission2, this.readMediaPermission3, this.readMediaPermission4});
            return;
        }
        this.permissionsResult.launch(new String[]{this.storagePermission, this.readMediaPermission4});
    }

    private void dialogPermission() {
        this.alertDialog.setTitle(getString(R.string.Grant_Permission));
        this.alertDialog.setCancelable(false);
        this.alertDialog.setMessage(getString(R.string.Please_grant_all_permissions));
        this.alertDialog.setButton(-1, getString(R.string.Go_to_setting), new DialogInterface.OnClickListener() {
            public final void onClick(DialogInterface dialogInterface, int i) {
                SongPickerActivity.this.lambda$dialogPermission$0$CNX_SongPickerActivity(dialogInterface, i);
            }
        });
        this.alertDialog.show();
    }

    public void lambda$dialogPermission$0$CNX_SongPickerActivity(DialogInterface dialogInterface, int i) {
        this.checkPer = true;
        this.alertDialog.dismiss();
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
        intent.setData(Uri.fromParts("package", getApplicationContext().getPackageName(), null));
        startActivity(intent);
        this.alertDialog.dismiss();
    }

    
    @Override 
    public void onResume() {
        super.onResume();
        if (this.checkPer) {
            this.checkPer = false;
            if (Build.VERSION.SDK_INT >= 33) {
                if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_VIDEO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_IMAGES") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_AUDIO") == 0) {
                    run();
                } else {
                    dialogPermission();
                }
            } else if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0) {
                run();
            } else {
                dialogPermission();
            }
        }
    }
}
