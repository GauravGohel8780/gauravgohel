package com.djmusicmixer.djmixer.audiomixer.language;

public class LanguageModel {
    int image;
    boolean isCheck;
    String isoLanguage;
    String languageName;

    public LanguageModel(String str, String str2, int i, boolean z) {
        this.languageName = str;
        this.isoLanguage = str2;
        this.image = i;
        this.isCheck = z;
    }

    public String getLanguageName() {
        return this.languageName;
    }

    public void setLanguageName(String str) {
        this.languageName = str;
    }

    public String getIsoLanguage() {
        return this.isoLanguage;
    }

    public void setIsoLanguage(String str) {
        this.isoLanguage = str;
    }
    public int getImage() {
        return this.image;
    }
    public void setImage(int i) {
        this.image = i;
    }
    public boolean isCheck() {
        return this.isCheck;
    }
    public void setCheck(boolean z) {
        this.isCheck = z;
    }
}
