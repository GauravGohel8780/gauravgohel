package com.djmusicmixer.djmixer.audiomixer.loop;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.VideoView;

public class MND_ScalableVideoView extends VideoView {
    private DisplayMode displayMode;
    private int mVideoHeight;
    private int mVideoWidth;

    public enum DisplayMode {
        ORIGINAL,
        FULL_SCREEN,
        ZOOM
    }

    public MND_ScalableVideoView(Context context) {
        super(context);
        this.displayMode = DisplayMode.FULL_SCREEN;
    }

    public MND_ScalableVideoView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.displayMode = DisplayMode.FULL_SCREEN;
    }

    public MND_ScalableVideoView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.displayMode = DisplayMode.FULL_SCREEN;
        this.mVideoWidth = 0;
        this.mVideoHeight = 0;
    }

    public void onMeasure(int i, int i2) {
        int i3;
        int i4;
        int i5;
        int defaultSize = getDefaultSize(0, i);
        int defaultSize2 = getDefaultSize(this.mVideoHeight, i2);
        if (this.displayMode == DisplayMode.ORIGINAL) {
            int i6 = this.mVideoWidth;
            if (i6 > 0 && (i5 = this.mVideoHeight) > 0) {
                int i7 = i6 * defaultSize2;
                int i8 = defaultSize * i5;
                if (i7 > i8) {
                    defaultSize2 = i8 / i6;
                } else if (i7 < i8) {
                    defaultSize = i7 / i5;
                }
            }
        } else if (this.displayMode != DisplayMode.FULL_SCREEN && this.displayMode == DisplayMode.ZOOM && (i3 = this.mVideoWidth) > 0 && (i4 = this.mVideoHeight) > 0 && i3 < defaultSize) {
            defaultSize2 = (i4 * defaultSize) / i3;
        }
        setMeasuredDimension(defaultSize, defaultSize2);
    }

    public void changeVideoSize(int i, int i2) {
        this.mVideoWidth = i;
        this.mVideoHeight = i2;
        getHolder().setFixedSize(i, i2);
        requestLayout();
        invalidate();
    }

    public void setDisplayMode(DisplayMode displayMode2) {
        this.displayMode = displayMode2;
    }
}
