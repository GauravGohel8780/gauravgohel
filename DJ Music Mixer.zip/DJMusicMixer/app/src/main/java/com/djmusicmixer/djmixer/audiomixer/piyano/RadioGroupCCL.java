package com.djmusicmixer.djmixer.audiomixer.piyano;

import android.view.View;
import android.widget.RadioGroup;

import java.util.ArrayList;

public class RadioGroupCCL implements RadioGroup.OnCheckedChangeListener {
    public final PianoMainActivity activity;

    public RadioGroupCCL(PianoMainActivity pianoMainActivity) {
        this.activity = pianoMainActivity;
    }

    public void onCheckedChanged(RadioGroup radioGroup, int i) {
        PianoMainActivity pianoMainActivity = this.activity;
        pianoMainActivity.valueOne = pianoMainActivity.mapOne.get(Integer.valueOf(i)).intValue();
        if (this.activity.boolOne) {
            long currentTimeMillis = System.currentTimeMillis();
            PianoMainActivity pianoMainActivity2 = this.activity;
            View view = null;
            MapModel mapModel = new MapModel(pianoMainActivity2.valueOne + 1000, (View) null);
            ArrayList arrayList = new ArrayList();
            arrayList.add(mapModel);
            this.activity.mapThree.put(Long.valueOf((currentTimeMillis - pianoMainActivity2.valueTwo) / 25), arrayList);
        }
    }
}
