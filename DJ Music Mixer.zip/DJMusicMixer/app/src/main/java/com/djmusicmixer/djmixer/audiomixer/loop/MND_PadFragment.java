package com.djmusicmixer.djmixer.audiomixer.loop;

import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;

public class MND_PadFragment extends Fragment {
    public static int padPos = 1;
    ImageView img_next;
    ImageView img_prev;
    LinearLayout l_Pluck;
    LinearLayout l_Synth;
    LinearLayout l_Vocal;
    LinearLayout l_drumKit;
    LinearLayout llA1Pluck;
    LinearLayout llA1Vocal;
    LinearLayout llA2Pluck;
    LinearLayout llA2Vocal;
    LinearLayout llA3Pluck;
    LinearLayout llA3Vocal;
    LinearLayout llC1Pluck;
    LinearLayout llC1Vocal;
    LinearLayout llC2Pluck;
    LinearLayout llC2Vocal;
    LinearLayout llC3Pluck;
    LinearLayout llC3Vocal;
    LinearLayout llClap1;
    LinearLayout llClap1Drumkit;
    LinearLayout llClap2;
    LinearLayout llClap2Drumkit;
    LinearLayout llClap3;
    LinearLayout llClap3Drumkit;
    LinearLayout llD1Pluck;
    LinearLayout llD1Vocal;
    LinearLayout llD2Pluck;
    LinearLayout llD2Vocal;
    LinearLayout llD3Pluck;
    LinearLayout llD3Vocal;
    LinearLayout llDjembe1;
    LinearLayout llDjembe1Drumkit;
    LinearLayout llDjembe2;
    LinearLayout llDjembe2Drumkit;
    LinearLayout llDjembe3;
    LinearLayout llDjembe3Drumkit;
    LinearLayout llF1Pluck;
    LinearLayout llF1Vocal;
    LinearLayout llF2Pluck;
    LinearLayout llF2Vocal;
    LinearLayout llF3Pluck;
    LinearLayout llF3Vocal;
    LinearLayout llHat1;
    LinearLayout llHat1Drumkit;
    LinearLayout llHat2;
    LinearLayout llHat2Drumkit;
    LinearLayout llHat3;
    LinearLayout llHat3DrumKit;
    LinearLayout llKick1;
    LinearLayout llKick1Drumkit;
    LinearLayout llKick2;
    LinearLayout llKick2Drumkit;
    LinearLayout llKick3;
    LinearLayout llKick3Drumkit;
    MND_LoopPadActivity loopPadActivity;
    MediaPlayer mediaPlayer;
    TextView txt_padName;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        SystemUtils.setLocale(getActivity());
        View inflate = layoutInflater.inflate(R.layout.fragment_pad, viewGroup, false);
        this.loopPadActivity = MND_LoopPadActivity.getInstance1();
        this.l_drumKit = (LinearLayout) inflate.findViewById(R.id.l_drumKit);
        this.l_Pluck = (LinearLayout) inflate.findViewById(R.id.l_Pluck);
        this.l_Vocal = (LinearLayout) inflate.findViewById(R.id.l_Vocal);
        this.l_Synth = (LinearLayout) inflate.findViewById(R.id.l_Synth);
        this.img_prev = (ImageView) inflate.findViewById(R.id.img_prev);
        this.img_next = (ImageView) inflate.findViewById(R.id.img_next);
        this.txt_padName = (TextView) inflate.findViewById(R.id.txt_padName);
        this.llDjembe1 = (LinearLayout) inflate.findViewById(R.id.ll_djembe1);
        this.llDjembe2 = (LinearLayout) inflate.findViewById(R.id.ll_djembe2);
        this.llDjembe3 = (LinearLayout) inflate.findViewById(R.id.ll_djembe3);
        this.llHat1 = (LinearLayout) inflate.findViewById(R.id.ll_hat1);
        this.llHat2 = (LinearLayout) inflate.findViewById(R.id.ll_hat2);
        this.llHat3 = (LinearLayout) inflate.findViewById(R.id.ll_hat3);
        this.llClap1 = (LinearLayout) inflate.findViewById(R.id.ll_clap1);
        this.llClap2 = (LinearLayout) inflate.findViewById(R.id.ll_clap2);
        this.llClap3 = (LinearLayout) inflate.findViewById(R.id.ll_clap3);
        this.llKick1 = (LinearLayout) inflate.findViewById(R.id.ll_kick1);
        this.llKick2 = (LinearLayout) inflate.findViewById(R.id.ll_kick2);
        this.llKick3 = (LinearLayout) inflate.findViewById(R.id.ll_kick3);
        this.llDjembe1Drumkit = (LinearLayout) inflate.findViewById(R.id.ll_djembe1_drumkit);
        this.llDjembe2Drumkit = (LinearLayout) inflate.findViewById(R.id.ll_djembe2_drumkit);
        this.llDjembe3Drumkit = (LinearLayout) inflate.findViewById(R.id.ll_djembe3_drumkit);
        this.llHat1Drumkit = (LinearLayout) inflate.findViewById(R.id.ll_hat1_drumkit);
        this.llHat2Drumkit = (LinearLayout) inflate.findViewById(R.id.ll_hat2_drumkit);
        this.llHat3DrumKit = (LinearLayout) inflate.findViewById(R.id.ll_hat3_drumkit);
        this.llClap1Drumkit = (LinearLayout) inflate.findViewById(R.id.ll_clap1_drumkit);
        this.llClap2Drumkit = (LinearLayout) inflate.findViewById(R.id.ll_clap2_drumkit);
        this.llClap3Drumkit = (LinearLayout) inflate.findViewById(R.id.ll_clap3_drumkit);
        this.llKick1Drumkit = (LinearLayout) inflate.findViewById(R.id.ll_kick1_drumkit);
        this.llKick2Drumkit = (LinearLayout) inflate.findViewById(R.id.ll_kick2_drumkit);
        this.llKick3Drumkit = (LinearLayout) inflate.findViewById(R.id.ll_kick3_drumkit);
        this.llC1Vocal = (LinearLayout) inflate.findViewById(R.id.ll_c1_vocal);
        this.llC2Vocal = (LinearLayout) inflate.findViewById(R.id.ll_c2_vocal);
        this.llC3Vocal = (LinearLayout) inflate.findViewById(R.id.ll_c3_vocal);
        this.llD1Vocal = (LinearLayout) inflate.findViewById(R.id.ll_d1_vocal);
        this.llD2Vocal = (LinearLayout) inflate.findViewById(R.id.ll_d2_vocal);
        this.llD3Vocal = (LinearLayout) inflate.findViewById(R.id.ll_d3_vocal);
        this.llA1Vocal = (LinearLayout) inflate.findViewById(R.id.ll_a1_vocal);
        this.llA2Vocal = (LinearLayout) inflate.findViewById(R.id.ll_a2_vocal);
        this.llA3Vocal = (LinearLayout) inflate.findViewById(R.id.ll_a3_vocal);
        this.llF1Vocal = (LinearLayout) inflate.findViewById(R.id.ll_f1_vocal);
        this.llF2Vocal = (LinearLayout) inflate.findViewById(R.id.ll_f2_vocal);
        this.llF3Vocal = (LinearLayout) inflate.findViewById(R.id.ll_f3_vocal);
        this.llC1Pluck = (LinearLayout) inflate.findViewById(R.id.ll_c1_pluck);
        this.llC2Pluck = (LinearLayout) inflate.findViewById(R.id.ll_c2_pluck);
        this.llC3Pluck = (LinearLayout) inflate.findViewById(R.id.ll_c3_pluck);
        this.llD1Pluck = (LinearLayout) inflate.findViewById(R.id.ll_d1_pluck);
        this.llD2Pluck = (LinearLayout) inflate.findViewById(R.id.ll_d2_pluck);
        this.llD3Pluck = (LinearLayout) inflate.findViewById(R.id.ll_d3_pluck);
        this.llF1Pluck = (LinearLayout) inflate.findViewById(R.id.ll_f1_pluck);
        this.llF2Pluck = (LinearLayout) inflate.findViewById(R.id.ll_f2_pluck);
        this.llF3Pluck = (LinearLayout) inflate.findViewById(R.id.ll_f3_pluck);
        this.llA1Pluck = (LinearLayout) inflate.findViewById(R.id.ll_a1_pluck);
        this.llA2Pluck = (LinearLayout) inflate.findViewById(R.id.ll_a2_pluck);
        this.llA3Pluck = (LinearLayout) inflate.findViewById(R.id.ll_a3_pluck);
        this.mediaPlayer = new MediaPlayer();
        allPadGone();
        this.l_drumKit.setVisibility(View.VISIBLE);
        this.txt_padName.setText(getActivity().getResources().getString(R.string.drum_kit));
        this.img_prev.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (MND_PadFragment.padPos == 1) {
                    MND_PadFragment.padPos = 4;
                } else {
                    MND_PadFragment.padPos--;
                }
                MND_PadFragment.this.allPadGone();
                if (MND_PadFragment.padPos == 1) {
                    MND_PadFragment.this.l_drumKit.setVisibility(View.VISIBLE);
                    MND_PadFragment.this.txt_padName.setText(MND_PadFragment.this.getActivity().getResources().getString(R.string.drum_kit));
                } else if (MND_PadFragment.padPos == 2) {
                    MND_PadFragment.this.l_Pluck.setVisibility(View.VISIBLE);
                    MND_PadFragment.this.txt_padName.setText(MND_PadFragment.this.getActivity().getResources().getString(R.string.Pluck_BeatMaker));
                } else if (MND_PadFragment.padPos == 3) {
                    MND_PadFragment.this.l_Vocal.setVisibility(View.VISIBLE);
                    MND_PadFragment.this.txt_padName.setText(MND_PadFragment.this.getActivity().getResources().getString(R.string.Vocal_BeatMaker));
                } else if (MND_PadFragment.padPos == 4) {
                    MND_PadFragment.this.l_Synth.setVisibility(View.VISIBLE);
                    MND_PadFragment.this.txt_padName.setText(MND_PadFragment.this.getActivity().getResources().getString(R.string.Synth_BeatMaker));
                }
            }
        });
        this.img_next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (MND_PadFragment.padPos == 4) {
                    MND_PadFragment.padPos = 1;
                } else {
                    MND_PadFragment.padPos++;
                }
                MND_PadFragment.this.allPadGone();
                if (MND_PadFragment.padPos == 1) {
                    MND_PadFragment.this.l_drumKit.setVisibility(View.VISIBLE);
                    MND_PadFragment.this.txt_padName.setText(MND_PadFragment.this.getActivity().getResources().getString(R.string.drum_kit));
                } else if (MND_PadFragment.padPos == 2) {
                    MND_PadFragment.this.l_Pluck.setVisibility(View.VISIBLE);
                    MND_PadFragment.this.txt_padName.setText(MND_PadFragment.this.getActivity().getResources().getString(R.string.Pluck_BeatMaker));
                } else if (MND_PadFragment.padPos == 3) {
                    MND_PadFragment.this.l_Vocal.setVisibility(View.VISIBLE);
                    MND_PadFragment.this.txt_padName.setText(MND_PadFragment.this.getActivity().getResources().getString(R.string.Vocal_BeatMaker));
                } else if (MND_PadFragment.padPos == 4) {
                    MND_PadFragment.this.l_Synth.setVisibility(View.VISIBLE);
                    MND_PadFragment.this.txt_padName.setText(MND_PadFragment.this.getActivity().getResources().getString(R.string.Synth_BeatMaker));
                }
            }
        });
        this.llDjembe1Drumkit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("drumkit/djembe1.ogg");
            }
        });
        this.llDjembe2Drumkit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("drumkit/djembe2.ogg");
            }
        });
        this.llDjembe3Drumkit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("drumkit/Djembe3.ogg");
            }
        });
        this.llHat1Drumkit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("drumkit/HiHat1.ogg");
            }
        });
        this.llHat2Drumkit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("drumkit/Cymbal.ogg");
            }
        });
        this.llHat3DrumKit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("drumkit/HiHat2.ogg");
            }
        });
        this.llClap1Drumkit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("drumkit/Clap1.ogg");
            }
        });
        this.llClap2Drumkit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("drumkit/Clap2.ogg");
            }
        });
        this.llClap3Drumkit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("drumkit/Snare1.ogg");
            }
        });
        this.llKick1Drumkit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("drumkit/Kick1.ogg");
            }
        });
        this.llKick2Drumkit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("drumkit/Kick2.ogg");
            }
        });
        this.llKick3Drumkit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("drumkit/Snare2.ogg");
            }
        });
        this.llC1Pluck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("PluckFoldr/Pluck_C.ogg");
            }
        });
        this.llC2Pluck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("PluckFoldr/Pluck_C#.ogg");
            }
        });
        this.llC3Pluck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("PluckFoldr/Pluck_D.ogg");
            }
        });
        this.llD1Pluck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("PluckFoldr/Pluck_D#.ogg");
            }
        });
        this.llD2Pluck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("PluckFoldr/Pluck_E.ogg");
            }
        });
        this.llD3Pluck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("PluckFoldr/Pluck_F.ogg");
            }
        });
        this.llF1Pluck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("PluckFoldr/Pluck_F#.ogg");
            }
        });
        this.llF2Pluck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("PluckFoldr/Pluck_G.ogg");
            }
        });
        this.llF3Pluck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("PluckFoldr/Pluck_G#.ogg");
            }
        });
        this.llA1Pluck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("PluckFoldr/Pluck_A.ogg");
            }
        });
        this.llA2Pluck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("PluckFoldr/Pluck_A#.ogg");
            }
        });
        this.llA3Pluck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("PluckFoldr/Pluck_E.ogg");
            }
        });
        this.llC1Vocal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("VocalFoldr/Vocal_C.ogg");
            }
        });
        this.llC2Vocal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("VocalFoldr/Vocal_C#.ogg");
            }
        });
        this.llC3Vocal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("VocalFoldr/Vocal_D.ogg");
            }
        });
        this.llD1Vocal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("VocalFoldr/Vocal_D#.ogg");
            }
        });
        this.llD2Vocal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("VocalFoldr/Vocal_E.ogg");
            }
        });
        this.llD3Vocal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("VocalFoldr/Vocal_F.ogg");
            }
        });
        this.llA1Vocal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("VocalFoldr/Vocal_F#.ogg");
            }
        });
        this.llA2Vocal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("VocalFoldr/Vocal_G.ogg");
            }
        });
        this.llA3Vocal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("VocalFoldr/Vocal_G#.ogg");
            }
        });
        this.llF1Vocal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("VocalFoldr/Vocal_A.ogg");
            }
        });
        this.llF2Vocal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("VocalFoldr/Vocal_A#.ogg");
            }
        });
        this.llF3Vocal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("VocalFoldr/Vocal_B.ogg");
            }
        });
        this.llDjembe1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("SynthFoldr/Syn_C.ogg");
            }
        });
        this.llDjembe2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("SynthFoldr/Syn_C#.ogg");
            }
        });
        this.llDjembe3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("SynthFoldr/Syn_D.ogg");
            }
        });
        this.llHat1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("SynthFoldr/Syn_D#.ogg");
            }
        });
        this.llHat2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("SynthFoldr/Syn_E.ogg");
            }
        });
        this.llHat3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("SynthFoldr/Syn_F.ogg");
            }
        });
        this.llClap1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("SynthFoldr/Syn_F#.ogg");
            }
        });
        this.llClap2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("SynthFoldr/Syn_G.ogg");
            }
        });
        this.llClap3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("SynthFoldr/Syn_G#.ogg");
            }
        });
        this.llKick1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("SynthFoldr/Syn_A.ogg");
            }
        });
        this.llKick2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("SynthFoldr/Syn_A#.ogg");
            }
        });
        this.llKick3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_PadFragment.this.playBeep("SynthFoldr/Syn_B.ogg");
            }
        });
        return inflate;
    }

    public void playBeep(String str) {
        try {
            if (this.mediaPlayer.isPlaying()) {
                this.mediaPlayer.stop();
                this.mediaPlayer.reset();
                this.mediaPlayer = new MediaPlayer();
            }
            this.mediaPlayer = new MediaPlayer();
            AssetFileDescriptor openFd = this.loopPadActivity.getAssets().openFd(str);
            this.mediaPlayer.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
            openFd.close();
            this.mediaPlayer.prepare();
            this.mediaPlayer.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void allPadGone() {
        this.l_drumKit.setVisibility(View.GONE);
        this.l_Pluck.setVisibility(View.GONE);
        this.l_Vocal.setVisibility(View.GONE);
        this.l_Synth.setVisibility(View.GONE);
    }
}
