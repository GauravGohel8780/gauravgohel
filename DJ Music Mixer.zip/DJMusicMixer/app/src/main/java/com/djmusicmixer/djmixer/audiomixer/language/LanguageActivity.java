package com.djmusicmixer.djmixer.audiomixer.language;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.djmusicmixer.djmixer.audiomixer.ExtraPage.QuestionActivity;
import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.base.BaseActivity;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.util.ArrayList;
import java.util.List;

public class LanguageActivity extends BaseActivity implements IClickLanguage {
    private LanguageAdapter adapter;
    private LanguageModel model;
    private RecyclerView recyclerView;
    private SharedPreferences sharedPreferences;

    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        setContentView(R.layout.activity_language);

        this.sharedPreferences = getSharedPreferences("MY_PRE", 0);
        this.recyclerView = (RecyclerView) findViewById(R.id.rcl_language);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getApplicationContext(), 2);
        recyclerView.setLayoutManager(gridLayoutManager);
        this.adapter = new LanguageAdapter(this, setLanguageDefault(), this);
        this.recyclerView.setHasFixedSize(true);
        this.recyclerView.setAdapter(this.adapter);

        findViewById(R.id.iv_done2).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                LanguageActivity.this.startMain();
            }
        });
    }

    @Override
    public void onClick(LanguageModel languageModel) {
        this.adapter.setSelectLanguage(languageModel);
        this.model = languageModel;
    }

    private List<LanguageModel> setLanguageDefault() {
        ArrayList arrayList = new ArrayList();
        String preLanguage = SystemUtils.getPreLanguage(this);
        arrayList.add(new LanguageModel("Deep House", "en", R.drawable.ic_deep_house, false));
        arrayList.add(new LanguageModel("Dubstep", "de", R.drawable.ic_dubstep_music_style, false));
        arrayList.add(new LanguageModel("EDM", "hi", R.drawable.ic_edm, false));
        arrayList.add(new LanguageModel("Electro", "fr", R.drawable.ic_electro, false));
        arrayList.add(new LanguageModel("Funk - Disco", "es", R.drawable.ic_funk_disco, false));
        arrayList.add(new LanguageModel("Hip Hop", "pt", R.drawable.ic_hip_hop, false));
        arrayList.add(new LanguageModel("House", "pt", R.drawable.ic_house, false));
        arrayList.add(new LanguageModel("Reggaeton", "pt", R.drawable.ic_reggaeton, false));
        int i = 0;
        while (true) {
            if (i >= arrayList.size()) {
                break;
            }
            if (!this.sharedPreferences.getBoolean("nativeLanguage", false)) {
                if (preLanguage.equals(((LanguageModel) arrayList.get(i)).getIsoLanguage())) {
                    LanguageModel languageModel = (LanguageModel) arrayList.get(i);
                    languageModel.setCheck(true);
                    arrayList.remove(arrayList.get(i));
                    arrayList.add(0, languageModel);
                    break;
                }
            } else if (preLanguage.equals(((LanguageModel) arrayList.get(i)).getIsoLanguage())) {
                ((LanguageModel) arrayList.get(i)).setCheck(true);
            }
            i++;
        }
        return arrayList;
    }


    private void startMain() {
        getInstance(this).ShowAd(new HandleClick() {
            @Override
            public void Show(boolean adShow) {
                Intent intent = new Intent(LanguageActivity.this, QuestionActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        }, MAIN_CLICK);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
