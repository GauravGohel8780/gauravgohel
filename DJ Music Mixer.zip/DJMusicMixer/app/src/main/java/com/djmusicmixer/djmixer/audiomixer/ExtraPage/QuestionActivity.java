package com.djmusicmixer.djmixer.audiomixer.ExtraPage;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.bumptech.glide.Glide;
import com.djmusicmixer.djmixer.audiomixer.Ads_Common.AdsBaseActivity;
import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.SharePrefUtils;
import com.djmusicmixer.djmixer.audiomixer.drummain.Drum_Main_Screen;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class QuestionActivity extends AdsBaseActivity {
    ImageView img1, img2, img3, img4;
    LinearLayout btn_next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);

        img1 = findViewById(R.id.img1);
        img2 = findViewById(R.id.img2);
        img3 = findViewById(R.id.img3);
        img4 = findViewById(R.id.img4);
        btn_next = findViewById(R.id.btn_next);

        findViewById(R.id.cd1).setOnClickListener(view -> {
            Glide.with(QuestionActivity.this).load(R.drawable.ic_switch_off).into(img1);
            Glide.with(QuestionActivity.this).load(R.drawable.ic_radio_selector).into(img2);
            Glide.with(QuestionActivity.this).load(R.drawable.ic_radio_selector).into(img3);
            Glide.with(QuestionActivity.this).load(R.drawable.ic_radio_selector).into(img4);
            btn_next.setVisibility(View.VISIBLE);
        });
        findViewById(R.id.cd2).setOnClickListener(view -> {
            Glide.with(QuestionActivity.this).load(R.drawable.ic_radio_selector).into(img1);
            Glide.with(QuestionActivity.this).load(R.drawable.ic_switch_off).into(img2);
            Glide.with(QuestionActivity.this).load(R.drawable.ic_radio_selector).into(img3);
            Glide.with(QuestionActivity.this).load(R.drawable.ic_radio_selector).into(img4);
            btn_next.setVisibility(View.VISIBLE);
        });
        findViewById(R.id.cd3).setOnClickListener(view -> {
            Glide.with(QuestionActivity.this).load(R.drawable.ic_radio_selector).into(img1);
            Glide.with(QuestionActivity.this).load(R.drawable.ic_radio_selector).into(img2);
            Glide.with(QuestionActivity.this).load(R.drawable.ic_switch_off).into(img3);
            Glide.with(QuestionActivity.this).load(R.drawable.ic_radio_selector).into(img4);
            btn_next.setVisibility(View.VISIBLE);
        });
        findViewById(R.id.cd4).setOnClickListener(view -> {
            Glide.with(QuestionActivity.this).load(R.drawable.ic_radio_selector).into(img1);
            Glide.with(QuestionActivity.this).load(R.drawable.ic_radio_selector).into(img2);
            Glide.with(QuestionActivity.this).load(R.drawable.ic_radio_selector).into(img3);
            Glide.with(QuestionActivity.this).load(R.drawable.ic_switch_off).into(img4);
            btn_next.setVisibility(View.VISIBLE);
        });
        findViewById(R.id.btn_next).setOnClickListener(view -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    SharePrefUtils.setFistTimeEnter(QuestionActivity.this,true);
                    Intent intent = new Intent(QuestionActivity.this, Drum_Main_Screen.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }
            }, MAIN_CLICK);
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }


    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BIG);
    }
}