package com.djmusicmixer.djmixer.audiomixer.mixer;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;
import com.djmusicmixer.djmixer.audiomixer.mixer.Fragment.LibSongsAdapter;
import com.djmusicmixer.djmixer.audiomixer.mixer.Loader.ArtistLoader;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Artist;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Songs;
import com.djmusicmixer.djmixer.audiomixer.mixer.Utils.MusicUtil;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.util.ArrayList;

public class ArtistDetailsActivity extends BaseActivity {
    public static Activity activity;
    private Artist artist;
    private RecyclerView recyclerView;
    protected LibSongsAdapter songsAdapter;
    protected ArrayList<Songs> songsList = new ArrayList<>();
    private TextView tv_empty;
    protected TextView tv_title;

    public Bundle getNonPersonalizedAdsBundle() {
        Bundle bundle = new Bundle();
        bundle.putString("npa", "1");
        return bundle;
    }

    @Override
    public void onCreate(Bundle bundle) {
        
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        setContentView(R.layout.activity_rkappzia_music_details);
        init();
        bindView();
    }

    private void init() {
        this.tv_title = (TextView) findViewById(R.id.tv_title_rkappzia);
        this.recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        this.tv_empty = (TextView) findViewById(R.id.tv_empty);
        Artist artist2 = ArtistLoader.getArtist(this, getIntent().getLongExtra("artistId", 0));
        this.artist = artist2;
        this.tv_title.setText(artist2.getName());
        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(ArtistDetailsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        ArtistDetailsActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
    }

    private void bindView() {
        ArrayList<Songs> songs = this.artist.getSongs();
        this.songsList = songs;
        if (songs != null) {
            this.tv_empty.setVisibility(songs.size() > 0 ? View.GONE : View.VISIBLE);
            if (this.songsList.size() > 0) {
                this.recyclerView.setHasFixedSize(true);
                this.recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
                LibSongsAdapter libSongsAdapter = new LibSongsAdapter(this, this.songsList, "artist");
                this.songsAdapter = libSongsAdapter;
                this.recyclerView.setAdapter(libSongsAdapter);
            }
        }
    }

    public void onArtistSongsClick(final int i, View view, String str, boolean z) {
        if (str.equals("more")) {
            PopupMenu popupMenu = new PopupMenu(new ContextThemeWrapper(this, (int) R.style.PopupDialogTheme), view);
            popupMenu.getMenuInflater().inflate(R.menu.menu_music_item_more_rk, popupMenu.getMenu());
            popupMenu.show();
            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                public boolean onMenuItemClick(MenuItem menuItem) {
                    if (menuItem.getItemId() != R.id.add_to_playlist) {
                        return true;
                    }
                    ArtistDetailsActivity artistDetailsActivity = ArtistDetailsActivity.this;
                    BaseActivity.addToPlaylistDialog(artistDetailsActivity, artistDetailsActivity.songsList.get(i));
                    return true;
                }
            });
            return;
        }
        Uri albumCoverUri = MusicUtil.getAlbumCoverUri(this.songsList.get(i).albumId);
        Intent intent = new Intent();
        intent.putExtra("selected_music_path", this.songsList.get(i).data);
        intent.putExtra("selected_music_name", this.songsList.get(i).title);
        intent.putExtra("selected_music_album", albumCoverUri.toString());
        setResult(-1, intent);
        finish();
    }
}
