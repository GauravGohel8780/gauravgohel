package com.djmusicmixer.djmixer.audiomixer.activites;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.app.ActivityCompat;

import com.djmusicmixer.djmixer.audiomixer.Drums.Drum;
import com.djmusicmixer.djmixer.audiomixer.Drums.Player;
import com.djmusicmixer.djmixer.audiomixer.Drums.Recorder;
import com.djmusicmixer.djmixer.audiomixer.Drums.SampleSelectDialog;
import com.djmusicmixer.djmixer.audiomixer.Drums.SamplesLoader;
import com.djmusicmixer.djmixer.audiomixer.Drums.SongPlayer;
import com.djmusicmixer.djmixer.audiomixer.Drums.SoundBoard;
import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.base.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;

import java.io.File;
import java.io.IOException;
import java.util.Map;

public class StageActivity extends BaseActivity  {
    public static int SETUP_ID;
    PlayerInterface animatedPlayer = new PlayerInterface() {
        @Override
        public void play(int i, int i2) {
            StageActivity.this.playWithAnimation(i, i2);
        }
    };
    private String currentSetupName;
    private Animation drumAnimation;
    public Drum[] drums;
    private RelativeLayout helping_layer;
    private ImageView imageView1;
    private ImageView imageView3;
    private ImageView imageView4;
    boolean isAnimated = false;
    boolean loaded = false;
    public int loadedSoundsCount = 0;
    private ActivityResultLauncher<String[]> permissionsResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
        public void onActivityResult(Map<String, Boolean> map) {
            if (Build.VERSION.SDK_INT < 24) {
                StageActivity.this.run();
            } else if (map.values().stream().allMatch(Boolean::booleanValue)) {
                StageActivity.this.run();
            } else {
                StageActivity.this.dialogPermission();
            }
        }
    });
    ImageView playControl;
    private ImageView play_control;
    public Player player;
    public PlayerInterface playerInterface;
    private Player.StateListener playerStateListener = new Player.StateListener() {

        @Override
        public void onStopped() {
            StageActivity.this.playControl.setImageResource(R.drawable.ic_play_drums);
        }

        @Override
        public void onStarted() {
            StageActivity.this.playControl.setImageResource(R.drawable.ic_pause_drums);
        }
    };
    private String readMediaPermission = "android.permission.READ_MEDIA_VIDEO";
    private String readMediaPermission2 = "android.permission.READ_MEDIA_IMAGES";
    private String readMediaPermission3 = "android.permission.READ_MEDIA_AUDIO";
    private String readMediaPermission4 = "android.permission.RECORD_AUDIO";
    PlayerInterface recordPlayer = new PlayerInterface() {
        @Override
        public void play(int i, int i2) {
            StageActivity.this.record(i, i2);
        }
    };
    private Recorder recorder;
    View.OnClickListener recordingDeleteListener = new View.OnClickListener() {
        public void onClick(View view) {
            StageActivity.this.dismissDialog(2);
            if (((File) view.getTag()).delete()) {
                StageActivity cNX_StageActivity = StageActivity.this;
                Toast.makeText(cNX_StageActivity, cNX_StageActivity.getResources().getString(R.string.toast_file_deleted), Toast.LENGTH_LONG).show();
                return;
            }
            StageActivity cNX_StageActivity2 = StageActivity.this;
            Toast.makeText(cNX_StageActivity2, cNX_StageActivity2.getResources().getString(R.string.toast_file_not_deleted), Toast.LENGTH_LONG).show();
        }
    };
    AdapterView.OnItemClickListener recordingItemClickListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
            StageActivity.this.dismissDialog(2);
            try {
                StageActivity.this.player.setSample(SamplesLoader.loadSample((File) view.getTag()));
                StageActivity cNX_StageActivity = StageActivity.this;
                Toast.makeText(cNX_StageActivity, cNX_StageActivity.getResources().getString(R.string.toast_sample_loaded), Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                e.printStackTrace();
                StageActivity cNX_StageActivity2 = StageActivity.this;
                Toast.makeText(cNX_StageActivity2, cNX_StageActivity2.getResources().getString(R.string.toast_sample_not_loaded), Toast.LENGTH_SHORT).show();
            }
        }
    };
    private File[] recordings;
    String savedMessage;
    private int setupId;
    PlayerInterface simplePlayer = new PlayerInterface() {
        @Override 
        public void play(int i, int i2) {
            StageActivity.this.play(i, i2);
        }
    };
    private SongPlayer songPlayer;
    SoundBoard.SoundLoadListener soundLoadListener = new SoundBoard.SoundLoadListener() {
        @Override 
        public void OnSoundLoaded() {
            StageActivity.this.loadedSoundsCount++;
            if (StageActivity.this.loadedSoundsCount == StageActivity.this.totalSoundSamplesCount - 1) {
                ((RelativeLayout) StageActivity.this.findViewById(R.id.touch_view)).setOnTouchListener(StageActivity.this.touchListener);
                StageActivity.this.player.setDrums(StageActivity.this.drums);
                StageActivity.this.loaded = true;
            }
        }
    };
    private SoundBoard soundPlayer;
    boolean startrec;
    boolean stoprec;
    private String storagePermission = "android.permission.READ_EXTERNAL_STORAGE";
    ImageView togglebuttons;
    RelativeLayout toggsbtn;
    public int totalSoundSamplesCount = 0;
    public View.OnTouchListener touchListener = new View.OnTouchListener() {
        public boolean onTouch(View view, MotionEvent motionEvent) {
            int x = (int) motionEvent.getX(0);
            int y = (int) motionEvent.getY(0);
            int action = motionEvent.getAction() & 255;
            if (action == 0) {
                StageActivity.this.playerInterface.play(x, y);
            } else if (action == 5) {
                int pointerCount = motionEvent.getPointerCount();
                for (int i = 1; i < pointerCount; i++) {
                    StageActivity.this.playerInterface.play((int) motionEvent.getX(i), (int) motionEvent.getY(i));
                }
            }
            return true;
        }
    };


    public interface PlayerInterface {
        void play(int i, int i2);
    }

    private class AsyncDrumLoader extends AsyncTask<Void, Void, Void> {
        public void onPostExecute(Void r1) {
        }

        private AsyncDrumLoader() {
        }

        public void onPreExecute() {
            StageActivity.this.loaded = false;
            super.onPreExecute();
        }

        public Void doInBackground(Void... voidArr) {
            StageActivity cNX_StageActivity = StageActivity.this;
            cNX_StageActivity.drums = cNX_StageActivity.getMeasuredDrums();
            return null;
        }
    }

    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        requestWindowFeature(1);
        getWindow().addFlags(128);
        setVolumeControlStream(3);
        SoundBoard cNX_SoundBoard = new SoundBoard(this);
        this.soundPlayer = cNX_SoundBoard;
        cNX_SoundBoard.setLoadListener(this.soundLoadListener);
        this.recorder = new Recorder();
        Player cNX_Player = new Player();
        this.player = cNX_Player;
        cNX_Player.setSoundPlayer(this.soundPlayer);
        this.player.setStateListener(this.playerStateListener);
        this.playerInterface = this.simplePlayer;
        this.drumAnimation = AnimationUtils.loadAnimation(this, R.anim.drum_animation);
        this.currentSetupName = SamplesLoader.parseLayoutName(getResources().getResourceName(getSetupId()));
        setContentView(getSetupId());
        this.songPlayer = SongPlayer.createInstance(this, findViewById(R.id.song_player_controls));
        this.imageView1 = (ImageView) findViewById(R.id.imageView1);
        this.play_control = (ImageView) findViewById(R.id.play_control);
        this.imageView3 = (ImageView) findViewById(R.id.imageView3);
        this.imageView4 = (ImageView) findViewById(R.id.imageView4);
        this.helping_layer = (RelativeLayout) findViewById(R.id.helping_layer);
        this.toggsbtn = (RelativeLayout) findViewById(R.id.toggsbtn);
        this.togglebuttons = (ImageView) findViewById(R.id.togglebuttons);
        this.toggsbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                StageActivity.this.toggleAnimation();
            }
        });
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams((getResources().getDisplayMetrics().widthPixels * 159) / 1920, (getResources().getDisplayMetrics().heightPixels * 174) / 1080);
        this.imageView1.setLayoutParams(layoutParams);
        this.play_control.setLayoutParams(layoutParams);
        this.imageView3.setLayoutParams(layoutParams);
        this.imageView4.setLayoutParams(layoutParams);
        this.togglebuttons.setLayoutParams(layoutParams);
        findViewById(R.id.rec).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                StageActivity.this.onRecordClicked(view);
            }
        });
    }

    public int getSetupId() {
        int i = getIntent().getExtras().getInt(String.valueOf(SETUP_ID));
        if (i == 0) {
            return R.layout.drum_basic;
        }
        if (i == 1) {
            return R.layout.drum_concert;
        }
        if (i == 2) {
            return R.layout.drum_doublebass;
        }
        if (i == 3) {
            return R.layout.drum_electric;
        }
        if (i == 4) {
            return R.layout.drum_jazz;
        }
        return i == 5 ? R.layout.drum_africa : R.layout.drum_basic;
    }

    public Drum[] getMeasuredDrums() {
        RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.drum_holder);
        int childCount = relativeLayout.getChildCount();
        this.totalSoundSamplesCount = childCount;
        Drum[] cNX_DrumArr = new Drum[childCount];
        for (int i = 0; i < childCount; i++) {
            cNX_DrumArr[i] = (Drum) relativeLayout.getChildAt(i);
            cNX_DrumArr[i].doMeasure();
            cNX_DrumArr[i].soundId1 = this.soundPlayer.registerSound(cNX_DrumArr[i].soundResId1);
            if (cNX_DrumArr[i].soundResId2 != -1) {
                cNX_DrumArr[i].soundId2 = this.soundPlayer.registerSound(cNX_DrumArr[i].soundResId2);
                this.totalSoundSamplesCount++;
            }
        }
        return cNX_DrumArr;
    }

    @Override
    public void onWindowFocusChanged(boolean z) {
        if (!this.loaded) {
            new AsyncDrumLoader().execute(new Void[0]);
        }
        super.onWindowFocusChanged(z);
    }

    public void play(int i, int i2) {
        int length = this.drums.length;
        do {
            length--;
            if (length <= -1) {
                this.soundPlayer.playSound(this.drums[0].getSoundId(i, i2));
                return;
            }
        } while (!this.drums[length].isTouched(i, i2));
        this.soundPlayer.stop(this.drums[length].streamId);
        Drum[] cNX_DrumArr = this.drums;
        cNX_DrumArr[length].streamId = this.soundPlayer.playSound(cNX_DrumArr[length].getSoundId(i, i2));
    }

    public void playWithAnimation(int i, int i2) {
        int length = this.drums.length;
        do {
            length--;
            if (length <= -1) {
                this.soundPlayer.stop(this.drums[0].streamId);
                Drum[] cNX_DrumArr = this.drums;
                cNX_DrumArr[0].streamId = this.soundPlayer.playSound(cNX_DrumArr[0].getSoundId(i, i2));
                this.drums[0].startAnimation(this.drumAnimation);
                return;
            }
        } while (!this.drums[length].isTouched(i, i2));
        this.soundPlayer.stop(this.drums[length].streamId);
        Drum[] cNX_DrumArr2 = this.drums;
        cNX_DrumArr2[length].streamId = this.soundPlayer.playSound(cNX_DrumArr2[length].getSoundId(i, i2));
        this.drums[length].startAnimation(this.drumAnimation);
    }

    public void record(int i, int i2) {
        int length = this.drums.length;
        do {
            length--;
            if (length <= -1) {
                this.recorder.add(0, this.drums[0].lastSoundIndex, System.currentTimeMillis());
                this.soundPlayer.stop(this.drums[0].streamId);
                Drum[] cNX_DrumArr = this.drums;
                cNX_DrumArr[0].streamId = this.soundPlayer.playSound(cNX_DrumArr[0].getSoundId(i, i2));
                return;
            }
        } while (!this.drums[length].isTouched(i, i2));
        this.soundPlayer.stop(this.drums[length].streamId);
        Drum[] cNX_DrumArr2 = this.drums;
        cNX_DrumArr2[length].streamId = this.soundPlayer.playSound(cNX_DrumArr2[length].getSoundId(i, i2));
        this.recorder.add(length, this.drums[length].lastSoundIndex, System.currentTimeMillis());
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity
    public void onDestroy() {
        SoundBoard cNX_SoundBoard = this.soundPlayer;
        if (cNX_SoundBoard != null) {
            cNX_SoundBoard.release();
        }
        this.songPlayer.destroy();
        super.onDestroy();
    }

    public void toggleAnimation() {
        if (this.isAnimated) {
            this.playerInterface = this.simplePlayer;
            this.togglebuttons.setImageResource(R.drawable.ic_off_animation);
            this.isAnimated = false;
            return;
        }
        this.playerInterface = this.animatedPlayer;
        this.isAnimated = true;
        this.togglebuttons.setImageResource(R.drawable.ic_on_animation);
    }

    public void onListFilesClicked(View view) {
        File[] samples = SamplesLoader.getSamples(this.currentSetupName);
        if (samples == null) {
            Toast.makeText(this, getResources().getString(R.string.toast_no_records_found), Toast.LENGTH_SHORT).show();
        } else if (samples.length < 1) {
            Toast.makeText(this, getResources().getString(R.string.toast_no_records_found), Toast.LENGTH_SHORT).show();
        } else {
            this.recordings = samples;
            showDialog(2);
        }
    }

    public void letgo(View view) {
        this.helping_layer.setVisibility(View.GONE);
    }

    public void onRecordClicked(View view) {
        if (Build.VERSION.SDK_INT >= 33) {
            if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_VIDEO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_IMAGES") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_AUDIO") == 0) {
                run();
            } else {
                requestStorage();
            }
        } else if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0) {
            run();
        } else {
            requestStorage();
        }
    }

    private void requestStorage() {
        if (Build.VERSION.SDK_INT >= 33) {
            this.permissionsResult.launch(new String[]{this.readMediaPermission, this.readMediaPermission2, this.readMediaPermission3, this.readMediaPermission4});
            return;
        }
        this.permissionsResult.launch(new String[]{this.storagePermission, this.readMediaPermission4});
    }

    private void dialogPermission() {
        AlertDialog create = new AlertDialog.Builder(this, R.style.AlertDialogCustom).create();
        create.setTitle(getString(R.string.Grant_Permission));
        create.setCancelable(false);
        create.setMessage(getString(R.string.Please_grant_all_permissions));
        create.setButton(-1, getString(R.string.Go_to_setting), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                create.dismiss();
                Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
                intent.setData(Uri.fromParts("package", getApplicationContext().getPackageName(), null));
                startActivity(intent);
                create.dismiss();
            }
        });
        create.show();
    }

    public void run() {
        if (this.recorder.isRecording()) {
            stopRecording();
            this.imageView1.setImageResource(R.drawable.ic_record_drum);
            Toast.makeText(this, getResources().getString(R.string.Recoding_Stop), Toast.LENGTH_SHORT).show();
            this.imageView1.clearAnimation();
        } else if (this.player.isPlaying()) {
            Toast.makeText(this, getResources().getString(R.string.toast_player_is_active), Toast.LENGTH_SHORT).show();
        } else {
            run2();
        }
    }

    public void run2() {
        startRecording();
        this.imageView1.setImageResource(R.drawable.ic_record_drum);
        Toast.makeText(this, getResources().getString(R.string.Recoding_Start), Toast.LENGTH_SHORT).show();
        this.imageView1.startAnimation(AnimationUtils.loadAnimation(this, R.anim.blink));
    }

    private void startRecording() {
        this.startrec = true;
        this.playerInterface = this.recordPlayer;
        this.recorder.startRecord();
    }

    private void stopRecording() {
        this.stoprec = true;
        this.playerInterface = this.simplePlayer;
        this.recorder.stopRecording();
        this.player.setSample(this.recorder.getSample());
    }

    public void onPlayClicked(View view) {
        this.playControl = (ImageView) view;
        if (this.player.isPlaying()) {
            this.player.stop();
            this.playControl.setImageResource(R.drawable.ic_play_drums);
        } else if (!this.player.isReady()) {
            Toast.makeText(this, getResources().getString(R.string.toast_no_sample), Toast.LENGTH_SHORT).show();
        } else if (this.recorder.isRecording()) {
            Toast.makeText(this, getResources().getString(R.string.toast_record_is_active), Toast.LENGTH_SHORT).show();
        } else {
            this.player.play();
            this.playControl.setImageResource(R.drawable.ic_pause_drums);
        }
    }

    public void onSaveClicked(View view) {
        boolean z = this.startrec;
        if (!z || !this.stoprec) {
            if (z && !this.stoprec) {
                Toast.makeText(this, getResources().getString(R.string.Please_Stop_Recording), Toast.LENGTH_LONG).show();
            } else if (!z && !this.stoprec) {
                Toast.makeText(this, getResources().getString(R.string.toast_save_not_ready), Toast.LENGTH_SHORT).show();
            }
        } else if (this.recorder.isReadyForSave()) {
            try {
                this.savedMessage = SamplesLoader.saveSample(this.currentSetupName, this.recorder.getSample(), this);
                showDialog(0);
            } catch (IOException e) {
                e.printStackTrace();
                this.savedMessage = getString(R.string.confirm_sample_not_saved);
                showDialog(0);
            }
        } else {
            Toast.makeText(this, getResources().getString(R.string.toast_save_not_ready), Toast.LENGTH_SHORT).show();
        }
    }

    public Dialog onCreateDialog(int i) {
        if (i == 0) {
            final Dialog dialog = new Dialog(this, R.style.MaterialDialogSheet);
            dialog.setContentView(R.layout.save_dialog);
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams((getResources().getDisplayMetrics().widthPixels * 767) / 1920, (getResources().getDisplayMetrics().heightPixels * 440) / 1080);
            layoutParams.gravity = 17;
            ((LinearLayout) dialog.findViewById(R.id.layout)).setLayoutParams(layoutParams);
            ((TextView) dialog.findViewById(R.id.textView)).setText(this.savedMessage);
            ((TextView) dialog.findViewById(R.id.ok)).setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    dialog.dismiss();
                }
            });
            dialog.show();
            return dialog;
        } else if (i != 2) {
            return super.onCreateDialog(i);
        } else {
            SampleSelectDialog cNX_SampleSelectDialog = new SampleSelectDialog(this);
            cNX_SampleSelectDialog.setDeleteListener(this.recordingDeleteListener);
            cNX_SampleSelectDialog.setonItemListener(this.recordingItemClickListener);
            return cNX_SampleSelectDialog;
        }
    }

    public void onPrepareDialog(int i, Dialog dialog) {
        if (i == 2) {
            ((SampleSelectDialog) dialog).setFiles(this.recordings);
        }
        super.onPrepareDialog(i, dialog);
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 0 && i2 == -1) {
            this.songPlayer.prepare(intent.getStringExtra("song_uri"));
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
