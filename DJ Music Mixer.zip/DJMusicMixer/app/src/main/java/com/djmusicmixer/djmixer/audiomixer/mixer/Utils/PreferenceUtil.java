package com.djmusicmixer.djmixer.audiomixer.mixer.Utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class PreferenceUtil {
    private static PreferenceUtil preferenceUtil;
    private String last_page = "last_page";
    private final SharedPreferences preferences;
    private String remember_last_tab = "remember_last_tab";

    private PreferenceUtil(Context context) {
        this.preferences = PreferenceManager.getDefaultSharedPreferences(context);
    }

    public static PreferenceUtil getInstance(Context context) {
        if (preferenceUtil == null) {
            preferenceUtil = new PreferenceUtil(context.getApplicationContext());
        }
        return preferenceUtil;
    }

    public void setLastPage(int i) {
        SharedPreferences.Editor edit = this.preferences.edit();
        edit.putInt(this.last_page, i);
        edit.apply();
    }

    public final int getLastPage() {
        return this.preferences.getInt(this.last_page, 1);
    }

    public final boolean rememberLastTab() {
        return this.preferences.getBoolean(this.remember_last_tab, true);
    }
}
