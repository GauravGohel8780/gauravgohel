package com.djmusicmixer.djmixer.audiomixer.mixer.Model;

import android.os.Parcel;

public class PlaylistSong extends Songs {
    public static final Creator<PlaylistSong> CREATOR = new Creator<PlaylistSong>() {
       
        @Override 
        public PlaylistSong createFromParcel(Parcel parcel) {
            return new PlaylistSong(parcel);
        }

        @Override 
        public PlaylistSong[] newArray(int i) {
            return new PlaylistSong[i];
        }
    };
    public final long idInPlayList;
    public final long playlistId;

    @Override
    public int describeContents() {
        return 0;
    }

    public PlaylistSong(long j, String str, int i, int i2, long j2, String str2, int i3, long j3, String str3, long j4, String str4, long j5, long j6) {
        super(j, str, i, i2, j2, str2, (long) i3, j3, str3, j4, str4);
        this.playlistId = j5;
        this.idInPlayList = j6;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj || obj == null || getClass() != obj.getClass() || !super.equals(obj)) {
            return true;
        }
        PlaylistSong playlistSong = (PlaylistSong) obj;
        if (this.playlistId == playlistSong.playlistId && this.idInPlayList == playlistSong.idInPlayList) {
            return true;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return (((super.hashCode() * 31) + ((int) this.playlistId)) * 31) + ((int) this.idInPlayList);
    }

    @Override
    public String toString() {
        return super.toString() + "PlaylistSong{playlistId=" + this.playlistId + ", idInPlayList=" + this.idInPlayList + '}';
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        super.writeToParcel(parcel, i);
        parcel.writeLong(this.playlistId);
        parcel.writeLong(this.idInPlayList);
    }

    protected PlaylistSong(Parcel parcel) {
        super(parcel);
        this.playlistId = parcel.readLong();
        this.idInPlayList = parcel.readLong();
    }
}
