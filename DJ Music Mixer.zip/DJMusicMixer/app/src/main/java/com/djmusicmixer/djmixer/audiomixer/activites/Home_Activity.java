package com.djmusicmixer.djmixer.audiomixer.activites;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.djmusicmixer.djmixer.audiomixer.Addmodul.SecondActivity;
import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.base.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class Home_Activity extends BaseActivity {
    LinearLayout all_elctric_drum;
    Context context;
    LinearLayout electric_drum;
    LinearLayout ludwig_drum;
    LinearLayout multi_drum;

    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(R.layout.home_activity);

        this.context = this;
        ((ImageView) findViewById(R.id.ic_back)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Home_Activity.this.onBackPressed();
            }
        });
        LinearLayout relativeLayout2 = (LinearLayout) findViewById(R.id.electric_drum);
        this.electric_drum = relativeLayout2;
        relativeLayout2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Home_Activity.this.CallIntent(1);
            }
        });
        LinearLayout relativeLayout3 = (LinearLayout) findViewById(R.id.ludwig_drum);
        this.ludwig_drum = relativeLayout3;
        relativeLayout3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Home_Activity.this.CallIntent(2);
            }
        });
        LinearLayout relativeLayout4 = (LinearLayout) findViewById(R.id.all_elctric_drum);
        this.all_elctric_drum = relativeLayout4;
        relativeLayout4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Home_Activity.this.CallIntent(3);
            }
        });
        LinearLayout relativeLayout5 = (LinearLayout) findViewById(R.id.multi_drum);
        this.multi_drum = relativeLayout5;
        relativeLayout5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Home_Activity.this.CallIntent(4);
            }
        });
    }

    public void CallIntent(int i) {
        getInstance(Home_Activity.this).ShowAd(new HandleClick() {
            @Override
            public void Show(boolean adShow) {
                if (i == 1) {
                    startActivity(new Intent(Home_Activity.this, DrumDemoActivity.class));
                } else if (i == 2) {
                    startActivity(new Intent(Home_Activity.this, GameActivity.class));
                } else if (i == 3) {
                    startActivity(new Intent(Home_Activity.this, DrumsActivity.class));
                } else if (i == 4) {
                    startActivity(new Intent(Home_Activity.this, SecondActivity.class));
                }
            }
        }, MAIN_CLICK);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BIG);
    }
}
