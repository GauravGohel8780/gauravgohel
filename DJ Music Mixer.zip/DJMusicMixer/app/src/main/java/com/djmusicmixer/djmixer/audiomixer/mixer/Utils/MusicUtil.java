package com.djmusicmixer.djmixer.audiomixer.mixer.Utils;

import android.content.ContentUris;
import android.net.Uri;
import android.text.TextUtils;

import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Artist;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Genres;

import java.util.Locale;

public class MusicUtil {
    public static Uri getAlbumCoverUri(long j) {
        return ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), j);
    }

    public static boolean isArtistNameUnknown(String str) {
        if (TextUtils.isEmpty(str)) {
            return false;
        }
        if (str.equals(Artist.UNKNOWN_ARTIST_NAME)) {
            return true;
        }
        String lowerCase = str.trim().toLowerCase();
        if (lowerCase.equals("unknown") || lowerCase.equals("<unknown>")) {
            return true;
        }
        return false;
    }

    public static String getArtistInfo(Artist artist) {
        return buildInfoString(getAlbumCount(artist.getAlbumCount()), getSongCount(artist.getSongCount()));
    }

    public static String getSongCount(int i) {
        String str = i == 1 ? "song" : "songs";
        return i + " " + str;
    }

    public static String getAlbumCount(int i) {
        String str = i == 1 ? "album" : "albums";
        return i + " " + str;
    }

    public static String buildInfoString(String str, String str2) {
        if (TextUtils.isEmpty(str)) {
            if (TextUtils.isEmpty(str2)) {
                return "";
            }
            return str2;
        } else if (!TextUtils.isEmpty(str2)) {
            return str + " • " + str2;
        } else if (TextUtils.isEmpty(str)) {
            return "";
        } else {
            return str;
        }
    }

    public static String getGenreInfo(Genres genres) {
        return getSongCount(genres.songCount);
    }

    public static String getReadableDuration(long j) {
        long j2 = j / 1000;
        long j3 = j2 / 60;
        long j4 = j2 % 60;
        if (j3 < 60) {
            return String.format(Locale.getDefault(), "%01d:%02d", Long.valueOf(j3), Long.valueOf(j4));
        }
        return String.format(Locale.getDefault(), "%d:%02d:%02d", Long.valueOf(j3 / 60), Long.valueOf(j3 % 60), Long.valueOf(j4));
    }
}
