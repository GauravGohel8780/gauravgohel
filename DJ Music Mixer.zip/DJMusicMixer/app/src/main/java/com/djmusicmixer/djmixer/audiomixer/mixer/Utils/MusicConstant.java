package com.djmusicmixer.djmixer.audiomixer.mixer.Utils;

public class MusicConstant {
    public static String ActivityFlag = "ActivityFlag";
}
