package com.djmusicmixer.djmixer.audiomixer.mixer.Fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.mixer.Adapter.LibArtistAdapter;
import com.djmusicmixer.djmixer.audiomixer.mixer.ArtistDetailsActivity;
import com.djmusicmixer.djmixer.audiomixer.mixer.Listener.OnClickLibraryItem;
import com.djmusicmixer.djmixer.audiomixer.mixer.Loader.ArtistLoader;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Artist;
import com.djmusicmixer.djmixer.audiomixer.mixer.Utils.MusicConstant;

import java.util.ArrayList;
import java.util.Objects;

public class LibArtistsFragment extends Fragment {
    private LibArtistAdapter artistAdapter;
    public ArrayList<Artist> artistList = new ArrayList<>();
    private RecyclerView recyclerView;
    public long selected_artist_id;
    private TextView tv_empty;

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_rkappzia_music_library, viewGroup, false);
        init(inflate);
        return inflate;
    }

    private void init(View view) {
        this.recyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        this.tv_empty = (TextView) view.findViewById(R.id.tv_empty);
        FragmentActivity activity = getActivity();
        Objects.requireNonNull(activity);
        activity.runOnUiThread(new Runnable() {
            public void run() {
                LibArtistsFragment libArtistsFragment = LibArtistsFragment.this;
                Context context = libArtistsFragment.getContext();
                Objects.requireNonNull(context);
                libArtistsFragment.artistList = ArtistLoader.getAllArtists(context);
            }
        });
    }

    @Override
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        ArrayList<Artist> arrayList = this.artistList;
        if (arrayList != null) {
            this.tv_empty.setVisibility(arrayList.size() > 0 ? View.GONE : View.VISIBLE);
            if (this.artistList.size() > 0) {
                this.recyclerView.setHasFixedSize(true);
                this.recyclerView.setLayoutManager(new GridLayoutManager((Context) getActivity(), 3, RecyclerView.VERTICAL, false));
                LibArtistAdapter libArtistAdapter = new LibArtistAdapter(getActivity(), this.artistList);
                this.artistAdapter = libArtistAdapter;
                this.recyclerView.setAdapter(libArtistAdapter);
                this.artistAdapter.setOnItemClickListener(new OnClickLibraryItem() {
                    @Override
                    public void onClickSongsItem(long j) {
                        LibArtistsFragment.this.selected_artist_id = j;
                        Intent intent = new Intent(LibArtistsFragment.this.getActivity(), ArtistDetailsActivity.class);
                        intent.putExtra("artistId", LibArtistsFragment.this.selected_artist_id);
                        FragmentActivity activity = LibArtistsFragment.this.getActivity();
                        Objects.requireNonNull(activity);
                        activity.startActivityForResult(intent, 1);
                        MusicConstant.ActivityFlag = "";
                    }
                });
            }
        }
    }
}
