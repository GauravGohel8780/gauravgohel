package com.djmusicmixer.djmixer.audiomixer.Addmodul;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.djmusicmixer.djmixer.audiomixer.Help;
import com.djmusicmixer.djmixer.audiomixer.R;

import java.util.List;

public class song_list extends BaseAdapter {
    private List<song_model> cnx_song_models;
    private Context context;

    public long getItemId(int i) {
        return (long) i;
    }

    public song_list(Context context2) {
        this.context = context2;
    }

    public song_model getItem(int i) {
        return this.cnx_song_models.get(i);
    }

    public void song_list(List<song_model> list) {
        this.cnx_song_models = list;
    }

    public int getCount() {
        return this.cnx_song_models.size();
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = LayoutInflater.from(this.context).inflate(R.layout.cnxx_song_list_row, (ViewGroup) null);
        }
        song_model cNX_song_model = this.cnx_song_models.get(i);
        ((TextView) view.findViewById(R.id.song_title)).setText(cNX_song_model.f347c);
        Help.setSize((ImageView) view.findViewById(R.id.img), 168, 168, true);
        view.findViewById(R.id.song_title).setSelected(true);
        view.setTag(cNX_song_model);
        return view;
    }
}
