package com.djmusicmixer.djmixer.audiomixer.loop.MyCustom;

import android.content.Context;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.SurfaceView;

import com.djmusicmixer.djmixer.audiomixer.R;

public class AudioWaveformView extends SurfaceView {
    private static final float MAX_AMPLITUDE_TO_DRAW = 100.0f;
    public static boolean isWaveDrawn = false;
    private final Paint mPaint;

    public AudioWaveformView(Context context) {
        this(context, null, 0);
    }

    public AudioWaveformView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public AudioWaveformView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Paint paint = new Paint();
        this.mPaint = paint;
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(getResources().getColor(R.color.bgBlue));
        paint.setStrokeWidth(0.0f);
        paint.setAntiAlias(true);
    }
}
