package com.djmusicmixer.djmixer.audiomixer.piyano;

import android.view.View;

public class MapModel {
    public int f177j;

    public MapModel(int i, View view) {
        this.f177j = i;
    }

    public String toString() {
        StringBuilder m1027a = m1027a("{tunes=");
        m1027a.append(this.f177j);
        m1027a.append("}");
        return m1027a.toString();
    }

    public static StringBuilder m1027a(String str) {
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        return sb;
    }
}
