package com.djmusicmixer.djmixer.audiomixer.mixer.Fragment;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.mixer.AlbumDetailsActivity;
import com.djmusicmixer.djmixer.audiomixer.mixer.ArtistDetailsActivity;
import com.djmusicmixer.djmixer.audiomixer.mixer.GenresDetailsActivity;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Songs;
import com.djmusicmixer.djmixer.audiomixer.mixer.PlaylistDetailsActivity;
import com.djmusicmixer.djmixer.audiomixer.mixer.Utils.MusicUtil;

import java.util.ArrayList;

public class LibSongsAdapter extends RecyclerView.Adapter<LibSongsAdapter.ViewHolder> {
    public Activity activity;
    private ArrayList<Songs> arrayList;
    public String from;
    public OnItemClickListener onItemClickListener;

    public interface OnItemClickListener {
        void onClick(int i, View view, String str, boolean z);
    }

    public LibSongsAdapter(Activity activity2, ArrayList<Songs> arrayList2, String str) {
        this.activity = activity2;
        this.arrayList = arrayList2;
        this.from = str;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.libsongs_rkappzia_list_item, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        ((RequestBuilder) Glide.with(this.activity).load(MusicUtil.getAlbumCoverUri(this.arrayList.get(i).albumId)).placeholder((int) R.drawable.ic_music_empty_dj)).into(viewHolder.iv_thumb);
        viewHolder.tv_song_name.setText(String.valueOf(this.arrayList.get(i).title));
        if (this.from.equals("artist")) {
            viewHolder.tv_artist_name.setText(this.arrayList.get(i).albumName);
        } else {
            viewHolder.tv_artist_name.setText(this.arrayList.get(i).artistName);
        }
        viewHolder.tv_duration.setText(MusicUtil.getReadableDuration(this.arrayList.get(i).duration));
        viewHolder.iv_more.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String str = LibSongsAdapter.this.from;
                str.hashCode();
                str.hashCode();
                char c = 65535;
                switch (str.hashCode()) {
                    case -1409097913:
                        if (str.equals("artist")) {
                            c = 0;
                            break;
                        }
                        break;
                    case -1249499312:
                        if (str.equals("genres")) {
                            c = 1;
                            break;
                        }
                        break;
                    case 92896879:
                        if (str.equals("album")) {
                            c = 2;
                            break;
                        }
                        break;
                    case 109620734:
                        if (str.equals("songs")) {
                            c = 3;
                            break;
                        }
                        break;
                    case 1879474642:
                        if (str.equals("playlist")) {
                            c = 4;
                            break;
                        }
                        break;
                }
                switch (c) {
                    case 0:
                        ((ArtistDetailsActivity) LibSongsAdapter.this.activity).onArtistSongsClick(i, view, "more", false);
                        return;
                    case 1:
                        ((GenresDetailsActivity) LibSongsAdapter.this.activity).onGenresSongsClick(i, view, "more", false);
                        return;
                    case 2:
                        ((AlbumDetailsActivity) LibSongsAdapter.this.activity).onAlbumSongsClick(i, view, "more", false);
                        return;
                    case 3:
                        LibSongsAdapter.this.onItemClickListener.onClick(i, view, "more", false);
                        return;
                    case 4:
                        ((PlaylistDetailsActivity) LibSongsAdapter.this.activity).onPlaylistSongsClick(i, view, "more", false);
                        return;
                    default:
                        return;
                }
            }
        });
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String str = LibSongsAdapter.this.from;
                str.hashCode();
                str.hashCode();
                char c = 65535;
                switch (str.hashCode()) {
                    case -1409097913:
                        if (str.equals("artist")) {
                            c = 0;
                            break;
                        }
                        break;
                    case -1249499312:
                        if (str.equals("genres")) {
                            c = 1;
                            break;
                        }
                        break;
                    case 92896879:
                        if (str.equals("album")) {
                            c = 2;
                            break;
                        }
                        break;
                    case 109620734:
                        if (str.equals("songs")) {
                            c = 3;
                            break;
                        }
                        break;
                    case 1879474642:
                        if (str.equals("playlist")) {
                            c = 4;
                            break;
                        }
                        break;
                }
                switch (c) {
                    case 0:
                        ((ArtistDetailsActivity) LibSongsAdapter.this.activity).onArtistSongsClick(i, view, "play_pause", false);
                        break;
                    case 1:
                        ((GenresDetailsActivity) LibSongsAdapter.this.activity).onGenresSongsClick(i, view, "play_pause", false);
                        break;
                    case 2:
                        ((AlbumDetailsActivity) LibSongsAdapter.this.activity).onAlbumSongsClick(i, view, "play_pause", false);
                        break;
                    case 3:
                        LibSongsAdapter.this.onItemClickListener.onClick(i, view, "play_pause", false);
                        break;
                    case 4:
                        ((PlaylistDetailsActivity) LibSongsAdapter.this.activity).onPlaylistSongsClick(i, view, "play_pause", false);
                        break;
                }
                LibSongsAdapter.this.notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.arrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView iv_more;
        ImageView iv_play_pause;
        ImageView iv_thumb;
        LinearLayout ly_play_pause;
        TextView tv_artist_name;
        TextView tv_duration;
        TextView tv_song_name;

        ViewHolder(View view) {
            super(view);
            this.iv_thumb = (ImageView) view.findViewById(R.id.iv_thumb);
            this.tv_song_name = (TextView) view.findViewById(R.id.tv_song_name);
            this.tv_artist_name = (TextView) view.findViewById(R.id.tv_artist_name);
            this.ly_play_pause = (LinearLayout) view.findViewById(R.id.ly_play_pause);
            this.iv_play_pause = (ImageView) view.findViewById(R.id.iv_play_pause);
            this.tv_duration = (TextView) view.findViewById(R.id.tv_duration);
            this.iv_more = (ImageView) view.findViewById(R.id.iv_more);
        }
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener2) {
        this.onItemClickListener = onItemClickListener2;
    }
}
