package com.djmusicmixer.djmixer.audiomixer.Addmodul;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.base.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;

public class DrumDemoActivity7 extends BaseActivity implements View.OnClickListener {
    Context context;
    ImageView f301A;
    ImageView f302B;
    LinearLayout f303C;
    MediaPlayer.OnCompletionListener f304D = new MediaPlayer.OnCompletionListener() {
        public void onCompletion(MediaPlayer mediaPlayer) {
            DrumDemoActivity7.this.f306F.setImageResource(R.drawable.ic_play_music_drums);
            DrumDemoActivity7.this.f323W = false;
        }
    };
    MediaPlayer.OnPreparedListener f305E = new MediaPlayer.OnPreparedListener() {
        public void onPrepared(MediaPlayer mediaPlayer) {
            DrumDemoActivity7.this.f323W = true;
        }
    };
    ImageView f306F;
    MediaPlayer f307G;
    MediaPlayer f308H;
    MediaPlayer f309I;
    MediaPlayer f310J;
    MediaPlayer f311K;
    MediaPlayer f312L;
    MediaPlayer f313M;
    MediaPlayer f314N;
    MediaPlayer f315O;
    MediaPlayer f316P;
    MediaPlayer f317Q;
    MediaPlayer f318R1;
    MediaPlayer f319S;
    MediaPlayer f320T;
    MediaPlayer f321U;
    MediaPlayer f322V;
    public boolean f323W = false;
    public MediaPlayer f324X = new MediaPlayer();
    float f325k = 1.0f;
    MediaPlayer.OnErrorListener f326l = new MediaPlayer.OnErrorListener() {
        public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
            DrumDemoActivity7.this.f306F.setImageResource(R.drawable.ic_play_music_drums);
            DrumDemoActivity7.this.f323W = false;
            return false;
        }
    };
    ImageView f327m;
    ImageView f328n;
    ImageView f329o;
    ImageView f330p;
    ImageView f331q;
    ImageView f332r;
    ImageView f333s;
    ImageView f334t;
    ImageView f335u;
    ImageView f336v;
    ImageView f337w;
    ImageView f338x;
    ImageView f339y;
    ImageView f340z;

    public void mo17385a(String str) {
        mo17387l();
        try {
            this.f324X.setDataSource(str);
            this.f324X.prepare();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void mo17386k() {
        if (this.f323W) {
            this.f324X.start();
            this.f306F.setImageResource(R.drawable.ic_pause_music_drums);
            return;
        }
        Toast.makeText(this, (int) R.string.Please_Select_Spark_Song, Toast.LENGTH_SHORT).show();
    }

    public void mo17387l() {
        this.f323W = false;
        if (this.f324X.isPlaying()) {
            this.f324X.stop();
        }
        this.f324X.reset();
    }

    public void mo17388m() {
        this.f324X.pause();
        this.f306F.setImageResource(R.drawable.ic_play_music_drums);
    }

    public void mo17389n() {
        this.f324X.stop();
        this.f306F.setImageResource(R.drawable.ic_play_music_drums);
    }

    public void mo17390o() {
        if (this.f324X.isPlaying()) {
            this.f324X.stop();
        }
        this.f324X.reset();
        this.f324X.release();
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 0 && i2 == -1) {
            mo17385a(intent.getStringExtra("song_uri"));
        }
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        try {
            MediaPlayer mediaPlayer = this.f307G;
            if (mediaPlayer != null) {
                mediaPlayer.stop();
                this.f307G.release();
            }
            MediaPlayer mediaPlayer2 = this.f315O;
            if (mediaPlayer2 != null) {
                mediaPlayer2.stop();
                this.f315O.release();
            }
            MediaPlayer mediaPlayer3 = this.f316P;
            if (mediaPlayer3 != null) {
                mediaPlayer3.stop();
                this.f316P.release();
            }
            MediaPlayer mediaPlayer4 = this.f317Q;
            if (mediaPlayer4 != null) {
                mediaPlayer4.stop();
                this.f317Q.release();
            }
            MediaPlayer mediaPlayer5 = this.f318R1;
            if (mediaPlayer5 != null) {
                mediaPlayer5.stop();
                this.f318R1.release();
            }
            MediaPlayer mediaPlayer6 = this.f319S;
            if (mediaPlayer6 != null) {
                mediaPlayer6.stop();
                this.f319S.release();
            }
            MediaPlayer mediaPlayer7 = this.f320T;
            if (mediaPlayer7 != null) {
                mediaPlayer7.stop();
                this.f320T.release();
            }
            MediaPlayer mediaPlayer8 = this.f321U;
            if (mediaPlayer8 != null) {
                mediaPlayer8.stop();
                this.f321U.release();
            }
            MediaPlayer mediaPlayer9 = this.f322V;
            if (mediaPlayer9 != null) {
                mediaPlayer9.stop();
                this.f322V.release();
            }
            MediaPlayer mediaPlayer10 = this.f308H;
            if (mediaPlayer10 != null) {
                mediaPlayer10.stop();
                this.f308H.release();
            }
            MediaPlayer mediaPlayer11 = this.f309I;
            if (mediaPlayer11 != null) {
                mediaPlayer11.stop();
                this.f309I.release();
            }
            MediaPlayer mediaPlayer12 = this.f310J;
            if (mediaPlayer12 != null) {
                mediaPlayer12.stop();
                this.f310J.release();
            }
            MediaPlayer mediaPlayer13 = this.f311K;
            if (mediaPlayer13 != null) {
                mediaPlayer13.stop();
                this.f311K.release();
            }
            MediaPlayer mediaPlayer14 = this.f312L;
            if (mediaPlayer14 != null) {
                mediaPlayer14.stop();
                this.f312L.release();
            }
            MediaPlayer mediaPlayer15 = this.f313M;
            if (mediaPlayer15 != null) {
                mediaPlayer15.stop();
                this.f313M.release();
            }
            MediaPlayer mediaPlayer16 = this.f314N;
            if (mediaPlayer16 != null) {
                mediaPlayer16.stop();
                this.f314N.release();
            }
        } catch (IllegalStateException unused) {
        }
        finish();
    }

    public void onClick(View view) {
        MediaPlayer mediaPlayer;
        switch (view.getId()) {
            case R.id.lbl1:
                MediaPlayer mediaPlayer2 = this.f307G;
                if (mediaPlayer2 != null) {
                    mediaPlayer2.stop();
                    this.f307G.release();
                    this.f307G = null;
                }
                MediaPlayer create = MediaPlayer.create(this, (int) R.raw.pm1);
                this.f307G = create;
                float f = this.f325k;
                create.setVolume(f, f);
                mediaPlayer = this.f307G;
                break;
            case R.id.lbl10:
                MediaPlayer mediaPlayer3 = this.f308H;
                if (mediaPlayer3 != null) {
                    mediaPlayer3.stop();
                    this.f308H.release();
                    this.f308H = null;
                }
                MediaPlayer create2 = MediaPlayer.create(this, (int) R.raw.pm10);
                this.f308H = create2;
                float f2 = this.f325k;
                create2.setVolume(f2, f2);
                mediaPlayer = this.f308H;
                break;
            case R.id.lbl11:
                MediaPlayer mediaPlayer4 = this.f309I;
                if (mediaPlayer4 != null) {
                    mediaPlayer4.stop();
                    this.f309I.release();
                    this.f309I = null;
                }
                MediaPlayer create3 = MediaPlayer.create(this, (int) R.raw.pm11);
                this.f309I = create3;
                float f3 = this.f325k;
                create3.setVolume(f3, f3);
                mediaPlayer = this.f309I;
                break;
            case R.id.lbl12:
                MediaPlayer mediaPlayer5 = this.f310J;
                if (mediaPlayer5 != null) {
                    mediaPlayer5.stop();
                    this.f310J.release();
                    this.f310J = null;
                }
                MediaPlayer create4 = MediaPlayer.create(this, (int) R.raw.pm12);
                this.f310J = create4;
                float f4 = this.f325k;
                create4.setVolume(f4, f4);
                mediaPlayer = this.f310J;
                break;
            case R.id.lbl13:
                MediaPlayer mediaPlayer6 = this.f311K;
                if (mediaPlayer6 != null) {
                    mediaPlayer6.stop();
                    this.f311K.release();
                    this.f311K = null;
                }
                MediaPlayer create5 = MediaPlayer.create(this, (int) R.raw.pm13);
                this.f311K = create5;
                float f5 = this.f325k;
                create5.setVolume(f5, f5);
                mediaPlayer = this.f311K;
                break;
            case R.id.lbl14:
                MediaPlayer mediaPlayer7 = this.f312L;
                if (mediaPlayer7 != null) {
                    mediaPlayer7.stop();
                    this.f312L.release();
                    this.f312L = null;
                }
                MediaPlayer create6 = MediaPlayer.create(this, (int) R.raw.pm14);
                this.f312L = create6;
                float f6 = this.f325k;
                create6.setVolume(f6, f6);
                mediaPlayer = this.f312L;
                break;
            case R.id.lbl15:
                MediaPlayer mediaPlayer8 = this.f313M;
                if (mediaPlayer8 != null) {
                    mediaPlayer8.stop();
                    this.f313M.release();
                    this.f313M = null;
                }
                MediaPlayer create7 = MediaPlayer.create(this, (int) R.raw.pm15);
                this.f313M = create7;
                float f7 = this.f325k;
                create7.setVolume(f7, f7);
                mediaPlayer = this.f313M;
                break;
            case R.id.lbl16:
                MediaPlayer mediaPlayer9 = this.f314N;
                if (mediaPlayer9 != null) {
                    mediaPlayer9.stop();
                    this.f314N.release();
                    this.f314N = null;
                }
                MediaPlayer create8 = MediaPlayer.create(this, (int) R.raw.pm16);
                this.f314N = create8;
                float f8 = this.f325k;
                create8.setVolume(f8, f8);
                mediaPlayer = this.f314N;
                break;
            case R.id.lbl2:
                MediaPlayer mediaPlayer10 = this.f315O;
                if (mediaPlayer10 != null) {
                    mediaPlayer10.stop();
                    this.f315O.release();
                    this.f315O = null;
                }
                MediaPlayer create9 = MediaPlayer.create(this, (int) R.raw.pm2);
                this.f315O = create9;
                float f9 = this.f325k;
                create9.setVolume(f9, f9);
                mediaPlayer = this.f315O;
                break;
            case R.id.lbl3:
                MediaPlayer mediaPlayer11 = this.f316P;
                if (mediaPlayer11 != null) {
                    mediaPlayer11.stop();
                    this.f316P.release();
                    this.f316P = null;
                }
                MediaPlayer create10 = MediaPlayer.create(this, (int) R.raw.pm3);
                this.f316P = create10;
                float f10 = this.f325k;
                create10.setVolume(f10, f10);
                mediaPlayer = this.f316P;
                break;
            case R.id.lbl4:
                MediaPlayer mediaPlayer12 = this.f317Q;
                if (mediaPlayer12 != null) {
                    mediaPlayer12.stop();
                    this.f317Q.release();
                    this.f317Q = null;
                }
                MediaPlayer create11 = MediaPlayer.create(this, (int) R.raw.pm4);
                this.f317Q = create11;
                float f11 = this.f325k;
                create11.setVolume(f11, f11);
                mediaPlayer = this.f317Q;
                break;
            case R.id.lbl5:
                MediaPlayer mediaPlayer13 = this.f318R1;
                if (mediaPlayer13 != null) {
                    mediaPlayer13.stop();
                    this.f318R1.release();
                    this.f318R1 = null;
                }
                MediaPlayer create12 = MediaPlayer.create(this, (int) R.raw.pm5);
                this.f318R1 = create12;
                float f12 = this.f325k;
                create12.setVolume(f12, f12);
                mediaPlayer = this.f318R1;
                break;
            case R.id.lbl6:
                MediaPlayer mediaPlayer14 = this.f319S;
                if (mediaPlayer14 != null) {
                    mediaPlayer14.stop();
                    this.f319S.release();
                    this.f319S = null;
                }
                MediaPlayer create13 = MediaPlayer.create(this, (int) R.raw.pm6);
                this.f319S = create13;
                float f13 = this.f325k;
                create13.setVolume(f13, f13);
                mediaPlayer = this.f319S;
                break;
            case R.id.lbl7:
                MediaPlayer mediaPlayer15 = this.f320T;
                if (mediaPlayer15 != null) {
                    mediaPlayer15.stop();
                    this.f320T.release();
                    this.f320T = null;
                }
                MediaPlayer create14 = MediaPlayer.create(this, (int) R.raw.pm7);
                this.f320T = create14;
                float f14 = this.f325k;
                create14.setVolume(f14, f14);
                mediaPlayer = this.f320T;
                break;
            case R.id.lbl8:
                MediaPlayer mediaPlayer16 = this.f321U;
                if (mediaPlayer16 != null) {
                    mediaPlayer16.stop();
                    this.f321U.release();
                    this.f321U = null;
                }
                MediaPlayer create15 = MediaPlayer.create(this, (int) R.raw.pm8);
                this.f321U = create15;
                float f15 = this.f325k;
                create15.setVolume(f15, f15);
                mediaPlayer = this.f321U;
                break;
            case R.id.lbl9:
                MediaPlayer mediaPlayer17 = this.f322V;
                if (mediaPlayer17 != null) {
                    mediaPlayer17.stop();
                    this.f322V.release();
                    this.f322V = null;
                }
                MediaPlayer create16 = MediaPlayer.create(this, (int) R.raw.pm9);
                this.f322V = create16;
                float f16 = this.f325k;
                create16.setVolume(f16, f16);
                mediaPlayer = this.f322V;
                break;
            default:
                return;
        }
        mediaPlayer.start();
    }

    @Override
    public void onCreate(Bundle bundle) {
        
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        getWindow().addFlags(128);
        setContentView(R.layout.activity_drum_demo7);

        this.context = this;
        findViewById(R.id.lbltitle1).setSelected(true);
        findViewById(R.id.back4).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumDemoActivity7.this.onBackPressed();
            }
        });
        this.f327m = (ImageView) findViewById(R.id.lbl1);
        this.f335u = (ImageView) findViewById(R.id.lbl2);
        this.f336v = (ImageView) findViewById(R.id.lbl3);
        this.f337w = (ImageView) findViewById(R.id.lbl4);
        this.f338x = (ImageView) findViewById(R.id.lbl5);
        this.f339y = (ImageView) findViewById(R.id.lbl6);
        this.f340z = (ImageView) findViewById(R.id.lbl7);
        this.f301A = (ImageView) findViewById(R.id.lbl8);
        this.f302B = (ImageView) findViewById(R.id.lbl9);
        this.f328n = (ImageView) findViewById(R.id.lbl10);
        this.f329o = (ImageView) findViewById(R.id.lbl11);
        this.f330p = (ImageView) findViewById(R.id.lbl12);
        this.f331q = (ImageView) findViewById(R.id.lbl13);
        this.f332r = (ImageView) findViewById(R.id.lbl14);
        this.f333s = (ImageView) findViewById(R.id.lbl15);
        this.f334t = (ImageView) findViewById(R.id.lbl16);
        this.f327m.setOnClickListener(this);
        this.f335u.setOnClickListener(this);
        this.f336v.setOnClickListener(this);
        this.f337w.setOnClickListener(this);
        this.f338x.setOnClickListener(this);
        this.f339y.setOnClickListener(this);
        this.f340z.setOnClickListener(this);
        this.f301A.setOnClickListener(this);
        this.f302B.setOnClickListener(this);
        this.f328n.setOnClickListener(this);
        this.f329o.setOnClickListener(this);
        this.f330p.setOnClickListener(this);
        this.f331q.setOnClickListener(this);
        this.f332r.setOnClickListener(this);
        this.f333s.setOnClickListener(this);
        this.f334t.setOnClickListener(this);
        this.f307G = MediaPlayer.create(this, (int) R.raw.pm1);
        this.f315O = MediaPlayer.create(this, (int) R.raw.pm2);
        this.f316P = MediaPlayer.create(this, (int) R.raw.pm3);
        this.f317Q = MediaPlayer.create(this, (int) R.raw.pm4);
        this.f318R1 = MediaPlayer.create(this, (int) R.raw.pm5);
        this.f319S = MediaPlayer.create(this, (int) R.raw.pm6);
        this.f320T = MediaPlayer.create(this, (int) R.raw.pm7);
        this.f321U = MediaPlayer.create(this, (int) R.raw.pm8);
        this.f322V = MediaPlayer.create(this, (int) R.raw.pm9);
        this.f308H = MediaPlayer.create(this, (int) R.raw.pm10);
        this.f309I = MediaPlayer.create(this, (int) R.raw.pm11);
        this.f310J = MediaPlayer.create(this, (int) R.raw.pm12);
        this.f311K = MediaPlayer.create(this, (int) R.raw.pm13);
        this.f312L = MediaPlayer.create(this, (int) R.raw.pm14);
        this.f313M = MediaPlayer.create(this, (int) R.raw.pm15);
        this.f314N = MediaPlayer.create(this, (int) R.raw.pm16);
        this.f324X.setOnPreparedListener(this.f305E);
        this.f324X.setOnErrorListener(this.f326l);
        this.f324X.setOnCompletionListener(this.f304D);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.load_song);
        this.f303C = linearLayout;
        linearLayout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumDemoActivity7.this.CallIntent(1);
            }
        });
        ImageView imageView = (ImageView) findViewById(R.id.play_song);
        this.f306F = imageView;
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity7.this.f324X.isPlaying()) {
                    DrumDemoActivity7.this.mo17388m();
                } else {
                    DrumDemoActivity7.this.mo17386k();
                }
            }
        });
        ((ImageView) findViewById(R.id.back4)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumDemoActivity7.this.onBackPressed();
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mo17390o();
    }

    public void CallIntent(int i) {
        if (i == 1) {
            if (this.f324X.isPlaying()) {
                mo17389n();
            } else {
                startActivityForResult(new Intent(this, SongPickerActivity.class), 0);
            }
        }
    }
}
