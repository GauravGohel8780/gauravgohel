package com.djmusicmixer.djmixer.audiomixer.loop.BeatWithMusic;

import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.core.view.ViewCompat;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.resource.gif.GifDrawable;
import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.loop.MND_Help;
import com.djmusicmixer.djmixer.audiomixer.loop.MyCustom.MyUtil;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MND_MyLoopFragment extends Fragment {
    String audioFile;
    int blinkNo1 = 0;
    int blinkNo10 = 0;
    int blinkNo11 = 0;
    int blinkNo12 = 0;
    int blinkNo13 = 0;
    int blinkNo14 = 0;
    int blinkNo15 = 0;
    int blinkNo16 = 0;
    int blinkNo17 = 0;
    int blinkNo18 = 0;
    int blinkNo19 = 0;
    int blinkNo2 = 0;
    int blinkNo20 = 0;
    int blinkNo3 = 0;
    int blinkNo4 = 0;
    int blinkNo5 = 0;
    int blinkNo6 = 0;
    int blinkNo7 = 0;
    int blinkNo8 = 0;
    int blinkNo9 = 0;
    int checkSection1 = 0;
    int checkSection2 = 0;
    int checkSection3 = 0;
    int checkSection4 = 0;
    int checkSection5 = 0;
    ImageView gif10_1;
    ImageView gif10_10;
    ImageView gif10_11;
    ImageView gif10_12;
    ImageView gif10_13;
    ImageView gif10_14;
    ImageView gif10_15;
    ImageView gif10_16;
    ImageView gif10_17;
    ImageView gif10_18;
    ImageView gif10_19;
    ImageView gif10_2;
    ImageView gif10_20;
    ImageView gif10_3;
    ImageView gif10_4;
    ImageView gif10_5;
    ImageView gif10_6;
    ImageView gif10_7;
    ImageView gif10_8;
    ImageView gif10_9;
    ImageView gif1_1;
    ImageView gif1_10;
    ImageView gif1_11;
    ImageView gif1_12;
    ImageView gif1_13;
    ImageView gif1_14;
    ImageView gif1_15;
    ImageView gif1_16;
    ImageView gif1_17;
    ImageView gif1_18;
    ImageView gif1_19;
    ImageView gif1_2;
    ImageView gif1_20;
    ImageView gif1_3;
    ImageView gif1_4;
    ImageView gif1_5;
    ImageView gif1_6;
    ImageView gif1_7;
    ImageView gif1_8;
    ImageView gif1_9;
    ImageView gif2_1;
    ImageView gif2_10;
    ImageView gif2_11;
    ImageView gif2_12;
    ImageView gif2_13;
    ImageView gif2_14;
    ImageView gif2_15;
    ImageView gif2_16;
    ImageView gif2_17;
    ImageView gif2_18;
    ImageView gif2_19;
    ImageView gif2_2;
    ImageView gif2_20;
    ImageView gif2_3;
    ImageView gif2_4;
    ImageView gif2_5;
    ImageView gif2_6;
    ImageView gif2_7;
    ImageView gif2_8;
    ImageView gif2_9;
    ImageView gif3_1;
    ImageView gif3_10;
    ImageView gif3_11;
    ImageView gif3_12;
    ImageView gif3_13;
    ImageView gif3_14;
    ImageView gif3_15;
    ImageView gif3_16;
    ImageView gif3_17;
    ImageView gif3_18;
    ImageView gif3_19;
    ImageView gif3_2;
    ImageView gif3_20;
    ImageView gif3_3;
    ImageView gif3_4;
    ImageView gif3_5;
    ImageView gif3_6;
    ImageView gif3_7;
    ImageView gif3_8;
    ImageView gif3_9;
    ImageView gif4_1;
    ImageView gif4_10;
    ImageView gif4_11;
    ImageView gif4_12;
    ImageView gif4_13;
    ImageView gif4_14;
    ImageView gif4_15;
    ImageView gif4_16;
    ImageView gif4_17;
    ImageView gif4_18;
    ImageView gif4_19;
    ImageView gif4_2;
    ImageView gif4_20;
    ImageView gif4_3;
    ImageView gif4_4;
    ImageView gif4_5;
    ImageView gif4_6;
    ImageView gif4_7;
    ImageView gif4_8;
    ImageView gif4_9;
    ImageView gif5_1;
    ImageView gif5_10;
    ImageView gif5_11;
    ImageView gif5_12;
    ImageView gif5_13;
    ImageView gif5_14;
    ImageView gif5_15;
    ImageView gif5_16;
    ImageView gif5_17;
    ImageView gif5_18;
    ImageView gif5_19;
    ImageView gif5_2;
    ImageView gif5_20;
    ImageView gif5_3;
    ImageView gif5_4;
    ImageView gif5_5;
    ImageView gif5_6;
    ImageView gif5_7;
    ImageView gif5_8;
    ImageView gif5_9;
    ImageView gif6_1;
    ImageView gif6_10;
    ImageView gif6_11;
    ImageView gif6_12;
    ImageView gif6_13;
    ImageView gif6_14;
    ImageView gif6_15;
    ImageView gif6_16;
    ImageView gif6_17;
    ImageView gif6_18;
    ImageView gif6_19;
    ImageView gif6_2;
    ImageView gif6_20;
    ImageView gif6_3;
    ImageView gif6_4;
    ImageView gif6_5;
    ImageView gif6_6;
    ImageView gif6_7;
    ImageView gif6_8;
    ImageView gif6_9;
    ImageView gif7_1;
    ImageView gif7_10;
    ImageView gif7_11;
    ImageView gif7_12;
    ImageView gif7_13;
    ImageView gif7_14;
    ImageView gif7_15;
    ImageView gif7_16;
    ImageView gif7_17;
    ImageView gif7_18;
    ImageView gif7_19;
    ImageView gif7_2;
    ImageView gif7_20;
    ImageView gif7_3;
    ImageView gif7_4;
    ImageView gif7_5;
    ImageView gif7_6;
    ImageView gif7_7;
    ImageView gif7_8;
    ImageView gif7_9;
    ImageView gif8_1;
    ImageView gif8_10;
    ImageView gif8_11;
    ImageView gif8_12;
    ImageView gif8_13;
    ImageView gif8_14;
    ImageView gif8_15;
    ImageView gif8_16;
    ImageView gif8_17;
    ImageView gif8_18;
    ImageView gif8_19;
    ImageView gif8_2;
    ImageView gif8_20;
    ImageView gif8_3;
    ImageView gif8_4;
    ImageView gif8_5;
    ImageView gif8_6;
    ImageView gif8_7;
    ImageView gif8_8;
    ImageView gif8_9;
    ImageView gif9_1;
    ImageView gif9_10;
    ImageView gif9_11;
    ImageView gif9_12;
    ImageView gif9_13;
    ImageView gif9_14;
    ImageView gif9_15;
    ImageView gif9_16;
    ImageView gif9_17;
    ImageView gif9_18;
    ImageView gif9_19;
    ImageView gif9_2;
    ImageView gif9_20;
    ImageView gif9_3;
    ImageView gif9_4;
    ImageView gif9_5;
    ImageView gif9_6;
    ImageView gif9_7;
    ImageView gif9_8;
    ImageView gif9_9;
    Handler handler1;
    Handler handler10;
    Handler handler11;
    Handler handler12;
    Handler handler13;
    Handler handler14;
    Handler handler15;
    Handler handler16;
    Handler handler17;
    Handler handler18;
    Handler handler19;
    Handler handler2;
    Handler handler20;
    Handler handler3;
    Handler handler4;
    Handler handler5;
    Handler handler6;
    Handler handler7;
    Handler handler8;
    Handler handler9;
    private boolean isRecording = false;
    LinearLayout l_f10_loop1;
    LinearLayout l_f10_loop10;
    LinearLayout l_f10_loop11;
    LinearLayout l_f10_loop12;
    LinearLayout l_f10_loop13;
    LinearLayout l_f10_loop14;
    LinearLayout l_f10_loop15;
    LinearLayout l_f10_loop16;
    LinearLayout l_f10_loop17;
    LinearLayout l_f10_loop18;
    LinearLayout l_f10_loop19;
    LinearLayout l_f10_loop2;
    LinearLayout l_f10_loop20;
    LinearLayout l_f10_loop3;
    LinearLayout l_f10_loop4;
    LinearLayout l_f10_loop5;
    LinearLayout l_f10_loop6;
    LinearLayout l_f10_loop7;
    LinearLayout l_f10_loop8;
    LinearLayout l_f10_loop9;
    LinearLayout l_f1_loop1;
    LinearLayout l_f1_loop10;
    LinearLayout l_f1_loop11;
    LinearLayout l_f1_loop12;
    LinearLayout l_f1_loop13;
    LinearLayout l_f1_loop14;
    LinearLayout l_f1_loop15;
    LinearLayout l_f1_loop16;
    LinearLayout l_f1_loop17;
    LinearLayout l_f1_loop18;
    LinearLayout l_f1_loop19;
    LinearLayout l_f1_loop2;
    LinearLayout l_f1_loop20;
    LinearLayout l_f1_loop3;
    LinearLayout l_f1_loop4;
    LinearLayout l_f1_loop5;
    LinearLayout l_f1_loop6;
    LinearLayout l_f1_loop7;
    LinearLayout l_f1_loop8;
    LinearLayout l_f1_loop9;
    LinearLayout l_f2_loop1;
    LinearLayout l_f2_loop10;
    LinearLayout l_f2_loop11;
    LinearLayout l_f2_loop12;
    LinearLayout l_f2_loop13;
    LinearLayout l_f2_loop14;
    LinearLayout l_f2_loop15;
    LinearLayout l_f2_loop16;
    LinearLayout l_f2_loop17;
    LinearLayout l_f2_loop18;
    LinearLayout l_f2_loop19;
    LinearLayout l_f2_loop2;
    LinearLayout l_f2_loop20;
    LinearLayout l_f2_loop3;
    LinearLayout l_f2_loop4;
    LinearLayout l_f2_loop5;
    LinearLayout l_f2_loop6;
    LinearLayout l_f2_loop7;
    LinearLayout l_f2_loop8;
    LinearLayout l_f2_loop9;
    LinearLayout l_f3_loop1;
    LinearLayout l_f3_loop10;
    LinearLayout l_f3_loop11;
    LinearLayout l_f3_loop12;
    LinearLayout l_f3_loop13;
    LinearLayout l_f3_loop14;
    LinearLayout l_f3_loop15;
    LinearLayout l_f3_loop16;
    LinearLayout l_f3_loop17;
    LinearLayout l_f3_loop18;
    LinearLayout l_f3_loop19;
    LinearLayout l_f3_loop2;
    LinearLayout l_f3_loop20;
    LinearLayout l_f3_loop3;
    LinearLayout l_f3_loop4;
    LinearLayout l_f3_loop5;
    LinearLayout l_f3_loop6;
    LinearLayout l_f3_loop7;
    LinearLayout l_f3_loop8;
    LinearLayout l_f3_loop9;
    LinearLayout l_f4_loop1;
    LinearLayout l_f4_loop10;
    LinearLayout l_f4_loop11;
    LinearLayout l_f4_loop12;
    LinearLayout l_f4_loop13;
    LinearLayout l_f4_loop14;
    LinearLayout l_f4_loop15;
    LinearLayout l_f4_loop16;
    LinearLayout l_f4_loop17;
    LinearLayout l_f4_loop18;
    LinearLayout l_f4_loop19;
    LinearLayout l_f4_loop2;
    LinearLayout l_f4_loop20;
    LinearLayout l_f4_loop3;
    LinearLayout l_f4_loop4;
    LinearLayout l_f4_loop5;
    LinearLayout l_f4_loop6;
    LinearLayout l_f4_loop7;
    LinearLayout l_f4_loop8;
    LinearLayout l_f4_loop9;
    LinearLayout l_f5_loop1;
    LinearLayout l_f5_loop10;
    LinearLayout l_f5_loop11;
    LinearLayout l_f5_loop12;
    LinearLayout l_f5_loop13;
    LinearLayout l_f5_loop14;
    LinearLayout l_f5_loop15;
    LinearLayout l_f5_loop16;
    LinearLayout l_f5_loop17;
    LinearLayout l_f5_loop18;
    LinearLayout l_f5_loop19;
    LinearLayout l_f5_loop2;
    LinearLayout l_f5_loop20;
    LinearLayout l_f5_loop3;
    LinearLayout l_f5_loop4;
    LinearLayout l_f5_loop5;
    LinearLayout l_f5_loop6;
    LinearLayout l_f5_loop7;
    LinearLayout l_f5_loop8;
    LinearLayout l_f5_loop9;
    LinearLayout l_f6_loop1;
    LinearLayout l_f6_loop10;
    LinearLayout l_f6_loop11;
    LinearLayout l_f6_loop12;
    LinearLayout l_f6_loop13;
    LinearLayout l_f6_loop14;
    LinearLayout l_f6_loop15;
    LinearLayout l_f6_loop16;
    LinearLayout l_f6_loop17;
    LinearLayout l_f6_loop18;
    LinearLayout l_f6_loop19;
    LinearLayout l_f6_loop2;
    LinearLayout l_f6_loop20;
    LinearLayout l_f6_loop3;
    LinearLayout l_f6_loop4;
    LinearLayout l_f6_loop5;
    LinearLayout l_f6_loop6;
    LinearLayout l_f6_loop7;
    LinearLayout l_f6_loop8;
    LinearLayout l_f6_loop9;
    LinearLayout l_f7_loop1;
    LinearLayout l_f7_loop10;
    LinearLayout l_f7_loop11;
    LinearLayout l_f7_loop12;
    LinearLayout l_f7_loop13;
    LinearLayout l_f7_loop14;
    LinearLayout l_f7_loop15;
    LinearLayout l_f7_loop16;
    LinearLayout l_f7_loop17;
    LinearLayout l_f7_loop18;
    LinearLayout l_f7_loop19;
    LinearLayout l_f7_loop2;
    LinearLayout l_f7_loop20;
    LinearLayout l_f7_loop3;
    LinearLayout l_f7_loop4;
    LinearLayout l_f7_loop5;
    LinearLayout l_f7_loop6;
    LinearLayout l_f7_loop7;
    LinearLayout l_f7_loop8;
    LinearLayout l_f7_loop9;
    LinearLayout l_f8_loop1;
    LinearLayout l_f8_loop10;
    LinearLayout l_f8_loop11;
    LinearLayout l_f8_loop12;
    LinearLayout l_f8_loop13;
    LinearLayout l_f8_loop14;
    LinearLayout l_f8_loop15;
    LinearLayout l_f8_loop16;
    LinearLayout l_f8_loop17;
    LinearLayout l_f8_loop18;
    LinearLayout l_f8_loop19;
    LinearLayout l_f8_loop2;
    LinearLayout l_f8_loop20;
    LinearLayout l_f8_loop3;
    LinearLayout l_f8_loop4;
    LinearLayout l_f8_loop5;
    LinearLayout l_f8_loop6;
    LinearLayout l_f8_loop7;
    LinearLayout l_f8_loop8;
    LinearLayout l_f8_loop9;
    LinearLayout l_f9_loop1;
    LinearLayout l_f9_loop10;
    LinearLayout l_f9_loop11;
    LinearLayout l_f9_loop12;
    LinearLayout l_f9_loop13;
    LinearLayout l_f9_loop14;
    LinearLayout l_f9_loop15;
    LinearLayout l_f9_loop16;
    LinearLayout l_f9_loop17;
    LinearLayout l_f9_loop18;
    LinearLayout l_f9_loop19;
    LinearLayout l_f9_loop2;
    LinearLayout l_f9_loop20;
    LinearLayout l_f9_loop3;
    LinearLayout l_f9_loop4;
    LinearLayout l_f9_loop5;
    LinearLayout l_f9_loop6;
    LinearLayout l_f9_loop7;
    LinearLayout l_f9_loop8;
    LinearLayout l_f9_loop9;
    LinearLayout l_feature1;
    LinearLayout l_feature10;
    LinearLayout l_feature2;
    LinearLayout l_feature3;
    LinearLayout l_feature4;
    LinearLayout l_feature5;
    LinearLayout l_feature6;
    LinearLayout l_feature7;
    LinearLayout l_feature8;
    LinearLayout l_feature9;
    MediaPlayer mediaPlayer1;
    MediaPlayer mediaPlayer13;
    MediaPlayer mediaPlayer17;
    MediaPlayer mediaPlayer5;
    MediaPlayer mediaPlayer9;
    MediaRecorder mediaRecorder = new MediaRecorder();
    String outputFile;
    Runnable runnable1;
    Runnable runnable10;
    Runnable runnable11;
    Runnable runnable12;
    Runnable runnable13;
    Runnable runnable14;
    Runnable runnable15;
    Runnable runnable16;
    Runnable runnable17;
    Runnable runnable18;
    Runnable runnable19;
    Runnable runnable2;
    Runnable runnable20;
    Runnable runnable3;
    Runnable runnable4;
    Runnable runnable5;
    Runnable runnable6;
    Runnable runnable7;
    Runnable runnable8;
    Runnable runnable9;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_myloop, viewGroup, false);
        this.l_feature1 = (LinearLayout) inflate.findViewById(R.id.l_feature1);
        this.l_feature2 = (LinearLayout) inflate.findViewById(R.id.l_feature2);
        this.l_feature3 = (LinearLayout) inflate.findViewById(R.id.l_feature3);
        this.l_feature4 = (LinearLayout) inflate.findViewById(R.id.l_feature4);
        this.l_feature5 = (LinearLayout) inflate.findViewById(R.id.l_feature5);
        this.l_feature6 = (LinearLayout) inflate.findViewById(R.id.l_feature6);
        this.l_feature7 = (LinearLayout) inflate.findViewById(R.id.l_feature7);
        this.l_feature8 = (LinearLayout) inflate.findViewById(R.id.l_feature8);
        this.l_feature9 = (LinearLayout) inflate.findViewById(R.id.l_feature9);
        this.l_feature10 = (LinearLayout) inflate.findViewById(R.id.l_feature10);
        initLoopBind(inflate);
        this.mediaPlayer1 = new MediaPlayer();
        this.mediaPlayer5 = new MediaPlayer();
        this.mediaPlayer9 = new MediaPlayer();
        this.mediaPlayer13 = new MediaPlayer();
        this.mediaPlayer17 = new MediaPlayer();
        this.l_feature1.setVisibility(View.GONE);
        if (MyUtil.featureNumber == 1) {
            this.l_feature1.setVisibility(View.VISIBLE);
            this.l_feature2.setVisibility(View.INVISIBLE);
            this.l_feature3.setVisibility(View.INVISIBLE);
            this.l_feature4.setVisibility(View.INVISIBLE);
            this.l_feature5.setVisibility(View.INVISIBLE);
            this.l_feature6.setVisibility(View.INVISIBLE);
            this.l_feature7.setVisibility(View.INVISIBLE);
            this.l_feature8.setVisibility(View.INVISIBLE);
            this.l_feature9.setVisibility(View.INVISIBLE);
            this.l_feature10.setVisibility(View.INVISIBLE);
        } else if (MyUtil.featureNumber == 2) {
            this.l_feature2.setVisibility(View.VISIBLE);
            this.l_feature1.setVisibility(View.INVISIBLE);
            this.l_feature3.setVisibility(View.INVISIBLE);
            this.l_feature4.setVisibility(View.INVISIBLE);
            this.l_feature5.setVisibility(View.INVISIBLE);
            this.l_feature6.setVisibility(View.INVISIBLE);
            this.l_feature7.setVisibility(View.INVISIBLE);
            this.l_feature8.setVisibility(View.INVISIBLE);
            this.l_feature9.setVisibility(View.INVISIBLE);
            this.l_feature10.setVisibility(View.INVISIBLE);
        } else if (MyUtil.featureNumber == 3) {
            this.l_feature3.setVisibility(View.VISIBLE);
            this.l_feature1.setVisibility(View.INVISIBLE);
            this.l_feature2.setVisibility(View.INVISIBLE);
            this.l_feature4.setVisibility(View.INVISIBLE);
            this.l_feature5.setVisibility(View.INVISIBLE);
            this.l_feature6.setVisibility(View.INVISIBLE);
            this.l_feature7.setVisibility(View.INVISIBLE);
            this.l_feature8.setVisibility(View.INVISIBLE);
            this.l_feature9.setVisibility(View.INVISIBLE);
            this.l_feature10.setVisibility(View.INVISIBLE);
        } else if (MyUtil.featureNumber == 4) {
            this.l_feature4.setVisibility(View.VISIBLE);
            this.l_feature1.setVisibility(View.INVISIBLE);
            this.l_feature2.setVisibility(View.INVISIBLE);
            this.l_feature3.setVisibility(View.INVISIBLE);
            this.l_feature5.setVisibility(View.INVISIBLE);
            this.l_feature6.setVisibility(View.INVISIBLE);
            this.l_feature7.setVisibility(View.INVISIBLE);
            this.l_feature8.setVisibility(View.INVISIBLE);
            this.l_feature9.setVisibility(View.INVISIBLE);
            this.l_feature10.setVisibility(View.INVISIBLE);
        } else if (MyUtil.featureNumber == 5) {
            this.l_feature5.setVisibility(View.VISIBLE);
            this.l_feature1.setVisibility(View.INVISIBLE);
            this.l_feature2.setVisibility(View.INVISIBLE);
            this.l_feature3.setVisibility(View.INVISIBLE);
            this.l_feature4.setVisibility(View.INVISIBLE);
            this.l_feature6.setVisibility(View.INVISIBLE);
            this.l_feature7.setVisibility(View.INVISIBLE);
            this.l_feature8.setVisibility(View.INVISIBLE);
            this.l_feature9.setVisibility(View.INVISIBLE);
            this.l_feature10.setVisibility(View.INVISIBLE);
        } else if (MyUtil.featureNumber == 6) {
            this.l_feature6.setVisibility(View.VISIBLE);
            this.l_feature1.setVisibility(View.INVISIBLE);
            this.l_feature2.setVisibility(View.INVISIBLE);
            this.l_feature3.setVisibility(View.INVISIBLE);
            this.l_feature4.setVisibility(View.INVISIBLE);
            this.l_feature5.setVisibility(View.INVISIBLE);
            this.l_feature7.setVisibility(View.INVISIBLE);
            this.l_feature8.setVisibility(View.INVISIBLE);
            this.l_feature9.setVisibility(View.INVISIBLE);
            this.l_feature10.setVisibility(View.INVISIBLE);
        } else if (MyUtil.featureNumber == 7) {
            this.l_feature7.setVisibility(View.VISIBLE);
            this.l_feature1.setVisibility(View.INVISIBLE);
            this.l_feature2.setVisibility(View.INVISIBLE);
            this.l_feature3.setVisibility(View.INVISIBLE);
            this.l_feature4.setVisibility(View.INVISIBLE);
            this.l_feature5.setVisibility(View.INVISIBLE);
            this.l_feature6.setVisibility(View.INVISIBLE);
            this.l_feature8.setVisibility(View.INVISIBLE);
            this.l_feature9.setVisibility(View.INVISIBLE);
            this.l_feature10.setVisibility(View.INVISIBLE);
        } else if (MyUtil.featureNumber == 8) {
            this.l_feature8.setVisibility(View.VISIBLE);
            this.l_feature1.setVisibility(View.INVISIBLE);
            this.l_feature2.setVisibility(View.INVISIBLE);
            this.l_feature3.setVisibility(View.INVISIBLE);
            this.l_feature4.setVisibility(View.INVISIBLE);
            this.l_feature5.setVisibility(View.INVISIBLE);
            this.l_feature6.setVisibility(View.INVISIBLE);
            this.l_feature7.setVisibility(View.INVISIBLE);
            this.l_feature9.setVisibility(View.INVISIBLE);
            this.l_feature10.setVisibility(View.INVISIBLE);
        } else if (MyUtil.featureNumber == 9) {
            this.l_feature9.setVisibility(View.VISIBLE);
            this.l_feature1.setVisibility(View.INVISIBLE);
            this.l_feature2.setVisibility(View.INVISIBLE);
            this.l_feature3.setVisibility(View.INVISIBLE);
            this.l_feature4.setVisibility(View.INVISIBLE);
            this.l_feature5.setVisibility(View.INVISIBLE);
            this.l_feature6.setVisibility(View.INVISIBLE);
            this.l_feature7.setVisibility(View.INVISIBLE);
            this.l_feature8.setVisibility(View.INVISIBLE);
            this.l_feature10.setVisibility(View.INVISIBLE);
        } else if (MyUtil.featureNumber == 10) {
            this.l_feature10.setVisibility(View.VISIBLE);
            this.l_feature1.setVisibility(View.INVISIBLE);
            this.l_feature2.setVisibility(View.INVISIBLE);
            this.l_feature3.setVisibility(View.INVISIBLE);
            this.l_feature4.setVisibility(View.INVISIBLE);
            this.l_feature5.setVisibility(View.INVISIBLE);
            this.l_feature6.setVisibility(View.INVISIBLE);
            this.l_feature7.setVisibility(View.INVISIBLE);
            this.l_feature8.setVisibility(View.INVISIBLE);
            this.l_feature9.setVisibility(View.INVISIBLE);
        }
        clickFeatured1();
        clickFeatured2();
        clickFeatured3();
        clickFeatured4();
        clickFeatured5();
        clickFeatured6();
        clickFeatured7();
        clickFeatured8();
        clickFeatured9();
        clickFeatured10();
        this.outputFile = MyUtil.geOutputPath();
        inflate.setFocusableInTouchMode(true);
        inflate.requestFocus();
        inflate.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if (i != 4) {
                    return false;
                }
                MND_MyLoopFragment.this.stopRecordIfRunning();
                return false;
            }
        });
        return inflate;
    }

    public void startRecording() {
        if (!this.isRecording) {
            this.isRecording = true;
            Log.d("Dd", "startReddcording: start");
            try {
                File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) + File.separator + "/LoopPadMusic");
                if (!file.exists()) {
                    file.mkdirs();
                }
                this.audioFile = "REC" + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
                MediaRecorder mediaRecorder2 = new MediaRecorder();
                this.mediaRecorder = mediaRecorder2;
                mediaRecorder2.setAudioSource(MediaRecorder.AudioSource.MIC);
                this.mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
                this.mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
                MediaRecorder mediaRecorder3 = this.mediaRecorder;
                mediaRecorder3.setOutputFile(file.getAbsolutePath() + File.separator + this.audioFile + ".m4a");
                this.mediaRecorder.prepare();
                this.mediaRecorder.start();
                return;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        this.mediaRecorder.stop();
        this.mediaRecorder.release();
        this.mediaRecorder = null;
        this.isRecording = false;
        stopAllPads();
    }

    public void stopRecordIfRunning() {
        MediaRecorder mediaRecorder2;
        try {
            if (this.isRecording && (mediaRecorder2 = this.mediaRecorder) != null) {
                mediaRecorder2.stop();
                this.mediaRecorder.release();
                this.mediaRecorder = null;
                this.isRecording = false;
            }
        } catch (Exception unused) {
        }
        stopAllPads();
        this.mediaPlayer1 = null;
        this.mediaPlayer5 = null;
        this.mediaPlayer9 = null;
        this.mediaPlayer13 = null;
        this.mediaPlayer17 = null;
    }

    public void stopAllPads() {
        clearMedia1();
        clearMedia5();
        clearMedia9();
        clearMedia13();
        clearMedia17();
        disableAllPad();
        Invisible_gif1_1();
        Invisible_gif1_2();
        Invisible_gif1_3();
        Invisible_gif1_4();
        Invisible_gif1_5();
    }

    public void disableAllPad() {
        ViewCompat.setBackground(this.l_f1_loop1, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f1_loop2, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f1_loop3, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f1_loop4, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f1_loop5, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f1_loop6, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f1_loop7, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f1_loop8, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f1_loop9, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f1_loop10, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f1_loop11, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f1_loop12, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f1_loop13, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f1_loop14, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f1_loop15, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f1_loop16, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f1_loop17, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f1_loop18, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f1_loop19, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f1_loop20, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f2_loop1, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f2_loop2, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f2_loop3, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f2_loop4, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f2_loop5, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f2_loop6, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f2_loop7, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f2_loop8, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f2_loop9, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f2_loop10, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f2_loop11, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f2_loop12, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f2_loop13, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f2_loop14, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f2_loop15, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f2_loop16, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f2_loop17, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f2_loop18, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f2_loop19, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f2_loop20, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f3_loop1, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f3_loop2, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f3_loop3, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f3_loop4, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f3_loop5, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f3_loop6, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f3_loop7, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f3_loop8, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f3_loop9, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f3_loop10, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f3_loop11, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f3_loop12, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f3_loop13, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f3_loop14, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f3_loop15, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f3_loop16, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f3_loop17, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f3_loop18, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f3_loop19, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f3_loop20, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f4_loop1, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f4_loop2, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f4_loop3, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f4_loop4, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f4_loop5, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f4_loop6, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f4_loop7, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f4_loop8, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f4_loop9, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f4_loop10, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f4_loop11, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f4_loop12, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f4_loop13, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f4_loop14, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f4_loop15, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f4_loop16, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f4_loop17, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f4_loop18, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f4_loop19, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f4_loop20, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f5_loop1, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f5_loop2, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f5_loop3, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f5_loop4, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f5_loop5, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f5_loop6, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f5_loop7, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f5_loop8, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f5_loop9, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f5_loop10, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f5_loop11, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f5_loop12, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f5_loop13, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f5_loop14, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f5_loop15, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f5_loop16, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f5_loop17, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f5_loop18, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f5_loop19, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f5_loop20, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f6_loop1, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f6_loop2, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f6_loop3, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f6_loop4, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f6_loop5, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f6_loop6, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f6_loop7, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f6_loop8, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f6_loop9, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f6_loop10, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f6_loop11, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f6_loop12, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f6_loop13, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f6_loop14, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f6_loop15, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f6_loop16, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f6_loop17, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f6_loop18, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f6_loop19, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f6_loop20, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f7_loop1, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f7_loop2, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f7_loop3, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f7_loop4, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f7_loop5, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f7_loop6, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f7_loop7, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f7_loop8, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f7_loop9, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f7_loop10, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f7_loop11, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f7_loop12, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f7_loop13, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f7_loop14, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f7_loop15, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f7_loop16, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f7_loop17, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f7_loop18, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f7_loop19, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f7_loop20, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f8_loop1, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f8_loop2, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f8_loop3, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f8_loop4, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f8_loop5, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f8_loop6, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f8_loop7, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f8_loop8, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f8_loop9, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f8_loop10, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f8_loop11, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f8_loop12, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f8_loop13, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f8_loop14, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f8_loop15, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f8_loop16, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f8_loop17, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f8_loop18, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f8_loop19, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f8_loop20, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f9_loop1, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f9_loop2, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f9_loop3, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f9_loop4, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f9_loop5, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f9_loop6, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f9_loop7, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f9_loop8, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f9_loop9, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f9_loop10, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f9_loop11, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f9_loop12, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f9_loop13, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f9_loop14, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f9_loop15, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f9_loop16, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f9_loop17, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f9_loop18, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f9_loop19, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f9_loop20, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f10_loop1, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f10_loop2, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f10_loop3, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f10_loop4, getResources().getDrawable(R.drawable.ic_btn1_unpress));
        ViewCompat.setBackground(this.l_f10_loop5, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f10_loop6, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f10_loop7, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f10_loop8, getResources().getDrawable(R.drawable.ic_btn2_unpress));
        ViewCompat.setBackground(this.l_f10_loop9, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f10_loop10, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f10_loop11, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f10_loop12, getResources().getDrawable(R.drawable.ic_btn3_unpress));
        ViewCompat.setBackground(this.l_f10_loop13, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f10_loop14, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f10_loop15, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f10_loop16, getResources().getDrawable(R.drawable.ic_btn4_unpress));
        ViewCompat.setBackground(this.l_f10_loop17, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f10_loop18, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f10_loop19, getResources().getDrawable(R.drawable.ic_btn5_unpress));
        ViewCompat.setBackground(this.l_f10_loop20, getResources().getDrawable(R.drawable.ic_btn5_unpress));
    }

    public void Invisible_gif1_1() {
        this.gif1_1.setVisibility(View.GONE);
        this.gif1_2.setVisibility(View.GONE);
        this.gif1_3.setVisibility(View.GONE);
        this.gif1_4.setVisibility(View.GONE);
        this.gif2_1.setVisibility(View.GONE);
        this.gif2_2.setVisibility(View.GONE);
        this.gif2_3.setVisibility(View.GONE);
        this.gif2_4.setVisibility(View.GONE);
        this.gif3_1.setVisibility(View.GONE);
        this.gif3_2.setVisibility(View.GONE);
        this.gif3_3.setVisibility(View.GONE);
        this.gif3_4.setVisibility(View.GONE);
        this.gif4_1.setVisibility(View.GONE);
        this.gif4_2.setVisibility(View.GONE);
        this.gif4_3.setVisibility(View.GONE);
        this.gif4_4.setVisibility(View.GONE);
        this.gif5_1.setVisibility(View.GONE);
        this.gif5_2.setVisibility(View.GONE);
        this.gif5_3.setVisibility(View.GONE);
        this.gif5_4.setVisibility(View.GONE);
        this.gif6_1.setVisibility(View.GONE);
        this.gif6_2.setVisibility(View.GONE);
        this.gif6_3.setVisibility(View.GONE);
        this.gif6_4.setVisibility(View.GONE);
        this.gif7_1.setVisibility(View.GONE);
        this.gif7_2.setVisibility(View.GONE);
        this.gif7_3.setVisibility(View.GONE);
        this.gif7_4.setVisibility(View.GONE);
        this.gif8_1.setVisibility(View.GONE);
        this.gif8_2.setVisibility(View.GONE);
        this.gif8_3.setVisibility(View.GONE);
        this.gif8_4.setVisibility(View.GONE);
        this.gif9_1.setVisibility(View.GONE);
        this.gif9_2.setVisibility(View.GONE);
        this.gif9_3.setVisibility(View.GONE);
        this.gif9_4.setVisibility(View.GONE);
        this.gif10_1.setVisibility(View.GONE);
        this.gif10_2.setVisibility(View.GONE);
        this.gif10_3.setVisibility(View.GONE);
        this.gif10_4.setVisibility(View.GONE);
    }

    public void Invisible_gif1_2() {
        this.gif1_5.setVisibility(View.GONE);
        this.gif1_6.setVisibility(View.GONE);
        this.gif1_7.setVisibility(View.GONE);
        this.gif1_8.setVisibility(View.GONE);
        this.gif2_5.setVisibility(View.GONE);
        this.gif2_6.setVisibility(View.GONE);
        this.gif2_7.setVisibility(View.GONE);
        this.gif2_8.setVisibility(View.GONE);
        this.gif3_5.setVisibility(View.GONE);
        this.gif3_6.setVisibility(View.GONE);
        this.gif3_7.setVisibility(View.GONE);
        this.gif3_8.setVisibility(View.GONE);
        this.gif4_5.setVisibility(View.GONE);
        this.gif4_6.setVisibility(View.GONE);
        this.gif4_7.setVisibility(View.GONE);
        this.gif4_8.setVisibility(View.GONE);
        this.gif5_5.setVisibility(View.GONE);
        this.gif5_6.setVisibility(View.GONE);
        this.gif5_7.setVisibility(View.GONE);
        this.gif5_8.setVisibility(View.GONE);
        this.gif6_5.setVisibility(View.GONE);
        this.gif6_6.setVisibility(View.GONE);
        this.gif6_7.setVisibility(View.GONE);
        this.gif6_8.setVisibility(View.GONE);
        this.gif7_5.setVisibility(View.GONE);
        this.gif7_6.setVisibility(View.GONE);
        this.gif7_7.setVisibility(View.GONE);
        this.gif7_8.setVisibility(View.GONE);
        this.gif8_5.setVisibility(View.GONE);
        this.gif8_6.setVisibility(View.GONE);
        this.gif8_7.setVisibility(View.GONE);
        this.gif8_8.setVisibility(View.GONE);
        this.gif9_5.setVisibility(View.GONE);
        this.gif9_6.setVisibility(View.GONE);
        this.gif9_7.setVisibility(View.GONE);
        this.gif9_8.setVisibility(View.GONE);
        this.gif10_5.setVisibility(View.GONE);
        this.gif10_6.setVisibility(View.GONE);
        this.gif10_7.setVisibility(View.GONE);
        this.gif10_8.setVisibility(View.GONE);
    }

    public void Invisible_gif1_3() {
        this.gif1_9.setVisibility(View.GONE);
        this.gif1_10.setVisibility(View.GONE);
        this.gif1_11.setVisibility(View.GONE);
        this.gif1_12.setVisibility(View.GONE);
        this.gif4_9.setVisibility(View.GONE);
        this.gif4_10.setVisibility(View.GONE);
        this.gif4_11.setVisibility(View.GONE);
        this.gif4_12.setVisibility(View.GONE);
        this.gif3_9.setVisibility(View.GONE);
        this.gif3_10.setVisibility(View.GONE);
        this.gif3_11.setVisibility(View.GONE);
        this.gif3_12.setVisibility(View.GONE);
        this.gif2_9.setVisibility(View.GONE);
        this.gif2_10.setVisibility(View.GONE);
        this.gif2_11.setVisibility(View.GONE);
        this.gif2_12.setVisibility(View.GONE);
        this.gif5_9.setVisibility(View.GONE);
        this.gif5_10.setVisibility(View.GONE);
        this.gif5_11.setVisibility(View.GONE);
        this.gif5_12.setVisibility(View.GONE);
        this.gif8_9.setVisibility(View.GONE);
        this.gif8_10.setVisibility(View.GONE);
        this.gif8_11.setVisibility(View.GONE);
        this.gif8_12.setVisibility(View.GONE);
        this.gif7_9.setVisibility(View.GONE);
        this.gif7_10.setVisibility(View.GONE);
        this.gif7_11.setVisibility(View.GONE);
        this.gif7_12.setVisibility(View.GONE);
        this.gif6_9.setVisibility(View.GONE);
        this.gif6_10.setVisibility(View.GONE);
        this.gif6_11.setVisibility(View.GONE);
        this.gif6_12.setVisibility(View.GONE);
        this.gif9_9.setVisibility(View.GONE);
        this.gif9_10.setVisibility(View.GONE);
        this.gif9_11.setVisibility(View.GONE);
        this.gif9_12.setVisibility(View.GONE);
        this.gif10_9.setVisibility(View.GONE);
        this.gif10_10.setVisibility(View.GONE);
        this.gif10_11.setVisibility(View.GONE);
        this.gif10_12.setVisibility(View.GONE);
    }

    public void Invisible_gif1_4() {
        this.gif1_13.setVisibility(View.GONE);
        this.gif1_14.setVisibility(View.GONE);
        this.gif1_15.setVisibility(View.GONE);
        this.gif1_16.setVisibility(View.GONE);
        this.gif2_13.setVisibility(View.GONE);
        this.gif2_14.setVisibility(View.GONE);
        this.gif2_15.setVisibility(View.GONE);
        this.gif2_16.setVisibility(View.GONE);
        this.gif3_13.setVisibility(View.GONE);
        this.gif3_14.setVisibility(View.GONE);
        this.gif3_15.setVisibility(View.GONE);
        this.gif3_16.setVisibility(View.GONE);
        this.gif4_13.setVisibility(View.GONE);
        this.gif4_14.setVisibility(View.GONE);
        this.gif4_15.setVisibility(View.GONE);
        this.gif4_16.setVisibility(View.GONE);
        this.gif5_13.setVisibility(View.GONE);
        this.gif5_14.setVisibility(View.GONE);
        this.gif5_15.setVisibility(View.GONE);
        this.gif5_16.setVisibility(View.GONE);
        this.gif6_13.setVisibility(View.GONE);
        this.gif6_14.setVisibility(View.GONE);
        this.gif6_15.setVisibility(View.GONE);
        this.gif6_16.setVisibility(View.GONE);
        this.gif7_13.setVisibility(View.GONE);
        this.gif7_14.setVisibility(View.GONE);
        this.gif7_15.setVisibility(View.GONE);
        this.gif7_16.setVisibility(View.GONE);
        this.gif8_13.setVisibility(View.GONE);
        this.gif8_14.setVisibility(View.GONE);
        this.gif8_15.setVisibility(View.GONE);
        this.gif8_16.setVisibility(View.GONE);
        this.gif9_13.setVisibility(View.GONE);
        this.gif9_14.setVisibility(View.GONE);
        this.gif9_15.setVisibility(View.GONE);
        this.gif9_16.setVisibility(View.GONE);
        this.gif10_13.setVisibility(View.GONE);
        this.gif10_14.setVisibility(View.GONE);
        this.gif10_15.setVisibility(View.GONE);
        this.gif10_16.setVisibility(View.GONE);
    }

    public void Invisible_gif1_5() {
        this.gif1_17.setVisibility(View.GONE);
        this.gif1_18.setVisibility(View.GONE);
        this.gif1_19.setVisibility(View.GONE);
        this.gif1_20.setVisibility(View.GONE);
        this.gif4_17.setVisibility(View.GONE);
        this.gif4_18.setVisibility(View.GONE);
        this.gif4_19.setVisibility(View.GONE);
        this.gif4_20.setVisibility(View.GONE);
        this.gif3_17.setVisibility(View.GONE);
        this.gif3_18.setVisibility(View.GONE);
        this.gif3_19.setVisibility(View.GONE);
        this.gif3_20.setVisibility(View.GONE);
        this.gif2_17.setVisibility(View.GONE);
        this.gif2_18.setVisibility(View.GONE);
        this.gif2_19.setVisibility(View.GONE);
        this.gif2_20.setVisibility(View.GONE);
        this.gif5_17.setVisibility(View.GONE);
        this.gif5_18.setVisibility(View.GONE);
        this.gif5_19.setVisibility(View.GONE);
        this.gif5_20.setVisibility(View.GONE);
        this.gif8_17.setVisibility(View.GONE);
        this.gif8_18.setVisibility(View.GONE);
        this.gif8_19.setVisibility(View.GONE);
        this.gif8_20.setVisibility(View.GONE);
        this.gif7_17.setVisibility(View.GONE);
        this.gif7_18.setVisibility(View.GONE);
        this.gif7_19.setVisibility(View.GONE);
        this.gif7_20.setVisibility(View.GONE);
        this.gif6_17.setVisibility(View.GONE);
        this.gif6_18.setVisibility(View.GONE);
        this.gif6_19.setVisibility(View.GONE);
        this.gif6_20.setVisibility(View.GONE);
        this.gif9_17.setVisibility(View.GONE);
        this.gif9_18.setVisibility(View.GONE);
        this.gif9_19.setVisibility(View.GONE);
        this.gif9_20.setVisibility(View.GONE);
        this.gif10_17.setVisibility(View.GONE);
        this.gif10_18.setVisibility(View.GONE);
        this.gif10_19.setVisibility(View.GONE);
        this.gif10_20.setVisibility(View.GONE);
    }

    private void clickFeatured1() {
        this.l_f1_loop1.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat1(mND_MyLoopFragment.l_f1_loop1, "MyLoopMusic/r_loop1.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif1_1.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f1_loop2.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat2(mND_MyLoopFragment.l_f1_loop2, "MyLoopMusic/r_loop2.mp3");
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif1_2.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop3.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat3(mND_MyLoopFragment.l_f1_loop3, "MyLoopMusic/r_loop3.mp3");
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif1_3.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop4.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat4(mND_MyLoopFragment.l_f1_loop4, "MyLoopMusic/r_loop4.mp3");
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif1_4.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop5.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat5(mND_MyLoopFragment.l_f1_loop5, "MyLoopMusic/r_loop5.mp3");
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif1_5.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop6.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat6(mND_MyLoopFragment.l_f1_loop6, "MyLoopMusic/r_loop6.mp3");
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif1_6.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop7.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat7(mND_MyLoopFragment.l_f1_loop7, "MyLoopMusic/r_loop7.mp3");
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif1_7.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop8.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat8(mND_MyLoopFragment.l_f1_loop8, "MyLoopMusic/r_loop8.mp3");
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif1_8.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop9.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat9(mND_MyLoopFragment.l_f1_loop9, "MyLoopMusic/r_loop9.mp3");
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif1_9.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop10.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat10(mND_MyLoopFragment.l_f1_loop10, "MyLoopMusic/r_loop10.mp3");
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif1_10.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop11.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat11(mND_MyLoopFragment.l_f1_loop11, "MyLoopMusic/r_loop11.mp3");
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif1_11.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop12.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat12(mND_MyLoopFragment.l_f1_loop12, "MyLoopMusic/r_loop12.mp3");
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif1_12.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop13.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat13(mND_MyLoopFragment.l_f1_loop13, "MyLoopMusic/r_loop13.mp3");
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif1_13.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop14.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat14(mND_MyLoopFragment.l_f1_loop14, "MyLoopMusic/r_loop14.mp3");
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif1_14.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop15.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat15(mND_MyLoopFragment.l_f1_loop15, "MyLoopMusic/r_loop15.mp3");
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif1_15.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop16.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat16(mND_MyLoopFragment.l_f1_loop16, "MyLoopMusic/r_loop16.mp3");
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif1_16.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop17.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat17(mND_MyLoopFragment.l_f1_loop17, "MyLoopMusic/r_loop17.mp3");
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif1_17.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop18.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat18(mND_MyLoopFragment.l_f1_loop18, "MyLoopMusic/r_loop18.mp3");
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif1_18.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop19.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat19(mND_MyLoopFragment.l_f1_loop19, "MyLoopMusic/r_loop19.mp3");
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif1_19.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop20.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat20(mND_MyLoopFragment.l_f1_loop20, "MyLoopMusic/r_loop20.mp3");
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f1_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif1_20.setVisibility(View.VISIBLE);
            }
        });
    }

    private void clickFeatured2() {
        this.l_f2_loop1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat1(mND_MyLoopFragment.l_f2_loop1, "MyLoopMusic/r_loop21.mp3");
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif2_1.setVisibility(View.VISIBLE);
            }
        });
        this.l_f2_loop2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat2(mND_MyLoopFragment.l_f2_loop2, "MyLoopMusic/r_loop22.mp3");
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif2_2.setVisibility(View.VISIBLE);
            }
        });
        this.l_f2_loop3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat3(mND_MyLoopFragment.l_f2_loop3, "MyLoopMusic/r_loop23.mp3");
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif2_3.setVisibility(View.VISIBLE);
            }
        });
        this.l_f2_loop4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat4(mND_MyLoopFragment.l_f2_loop4, "MyLoopMusic/r_loop24.mp3");
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif2_4.setVisibility(View.VISIBLE);
            }
        });
        this.l_f2_loop5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat5(mND_MyLoopFragment.l_f2_loop5, "MyLoopMusic/r_loop25.mp3");
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif2_5.setVisibility(View.VISIBLE);
            }
        });
        this.l_f2_loop6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat6(mND_MyLoopFragment.l_f2_loop6, "MyLoopMusic/r_loop26.mp3");
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif2_6.setVisibility(View.VISIBLE);
            }
        });
        this.l_f2_loop7.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat7(mND_MyLoopFragment.l_f2_loop7, "MyLoopMusic/r_loop27.mp3");
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif2_7.setVisibility(View.VISIBLE);
            }
        });
        this.l_f2_loop8.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat8(mND_MyLoopFragment.l_f2_loop8, "MyLoopMusic/r_loop28.mp3");
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif2_8.setVisibility(View.VISIBLE);
            }
        });
        this.l_f2_loop9.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat9(mND_MyLoopFragment.l_f2_loop9, "MyLoopMusic/r_loop29.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif2_9.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop10.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat10(mND_MyLoopFragment.l_f2_loop10, "MyLoopMusic/r_loop30.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif2_10.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop11.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat11(mND_MyLoopFragment.l_f2_loop11, "MyLoopMusic/r_loop31.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif2_11.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop12.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat12(mND_MyLoopFragment.l_f2_loop12, "MyLoopMusic/r_loop32.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif2_12.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop13.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat13(mND_MyLoopFragment.l_f2_loop13, "MyLoopMusic/r_loop33.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif2_13.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop14.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat14(mND_MyLoopFragment.l_f2_loop14, "MyLoopMusic/r_loop34.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif2_14.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop15.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat15(mND_MyLoopFragment.l_f2_loop15, "MyLoopMusic/r_loop35.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif2_15.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop16.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat16(mND_MyLoopFragment.l_f2_loop16, "MyLoopMusic/r_loop36.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif2_16.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop17.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat17(mND_MyLoopFragment.l_f2_loop17, "MyLoopMusic/r_loop37.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif2_17.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop18.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat18(mND_MyLoopFragment.l_f2_loop18, "MyLoopMusic/r_loop38.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif2_18.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop19.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat19(mND_MyLoopFragment.l_f2_loop19, "MyLoopMusic/r_loop39.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif2_19.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop20.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat20(mND_MyLoopFragment.l_f2_loop20, "MyLoopMusic/r_loop40.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif2_20.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f2_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
    }

    private void clickFeatured3() {
        this.l_f3_loop1.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat1(mND_MyLoopFragment.l_f3_loop1, "MyLoopMusic/r_loop1.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif3_1.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop2.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat2(mND_MyLoopFragment.l_f3_loop2, "MyLoopMusic/r_loop2.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif3_2.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop3.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat3(mND_MyLoopFragment.l_f3_loop3, "MyLoopMusic/r_loop3.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif3_3.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop4.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat4(mND_MyLoopFragment.l_f3_loop4, "MyLoopMusic/r_loop4.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif3_4.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop5.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat5(mND_MyLoopFragment.l_f3_loop5, "MyLoopMusic/r_loop5.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif3_5.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop6.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat6(mND_MyLoopFragment.l_f3_loop6, "MyLoopMusic/r_loop6.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif3_6.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop7.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat7(mND_MyLoopFragment.l_f3_loop7, "MyLoopMusic/r_loop7.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif3_7.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop8.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat8(mND_MyLoopFragment.l_f3_loop8, "MyLoopMusic/r_loop8.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif3_8.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop9.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat9(mND_MyLoopFragment.l_f3_loop9, "MyLoopMusic/r_loop9.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif3_9.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop10.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat10(mND_MyLoopFragment.l_f3_loop10, "MyLoopMusic/r_loop10.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif3_10.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop11.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat11(mND_MyLoopFragment.l_f3_loop11, "MyLoopMusic/r_loop11.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif3_11.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop12.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat12(mND_MyLoopFragment.l_f3_loop12, "MyLoopMusic/r_loop12.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif3_12.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop13.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat13(mND_MyLoopFragment.l_f3_loop13, "MyLoopMusic/r_loop13.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif3_13.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop14.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat14(mND_MyLoopFragment.l_f3_loop14, "MyLoopMusic/r_loop14.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif3_14.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop15.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat15(mND_MyLoopFragment.l_f3_loop15, "MyLoopMusic/r_loop15.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif3_15.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop16.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat16(mND_MyLoopFragment.l_f3_loop16, "MyLoopMusic/r_loop16.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif3_16.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop17.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat17(mND_MyLoopFragment.l_f3_loop17, "MyLoopMusic/r_loop17.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif3_17.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop18.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat18(mND_MyLoopFragment.l_f3_loop18, "MyLoopMusic/r_loop18.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif3_18.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop19.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat19(mND_MyLoopFragment.l_f3_loop19, "MyLoopMusic/r_loop19.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif3_19.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop20.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat20(mND_MyLoopFragment.l_f3_loop20, "MyLoopMusic/r_loop20.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif3_20.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f3_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
    }

    private void clickFeatured4() {
        this.l_f4_loop1.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat1(mND_MyLoopFragment.l_f4_loop1, "MyLoopMusic/r_loop1.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif4_1.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop2.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat2(mND_MyLoopFragment.l_f4_loop2, "MyLoopMusic/r_loop2.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif4_2.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop3.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat3(mND_MyLoopFragment.l_f4_loop3, "MyLoopMusic/r_loop3.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif4_3.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop4.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat4(mND_MyLoopFragment.l_f4_loop4, "MyLoopMusic/r_loop4.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif4_4.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop5.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat5(mND_MyLoopFragment.l_f4_loop5, "MyLoopMusic/r_loop5.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif4_5.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop6.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat6(mND_MyLoopFragment.l_f4_loop6, "MyLoopMusic/r_loop6.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif4_6.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop7.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat7(mND_MyLoopFragment.l_f4_loop7, "MyLoopMusic/r_loop7.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif4_7.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop8.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat8(mND_MyLoopFragment.l_f4_loop8, "MyLoopMusic/r_loop8.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif4_8.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop9.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat9(mND_MyLoopFragment.l_f4_loop9, "MyLoopMusic/r_loop9.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif4_9.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop10.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat10(mND_MyLoopFragment.l_f4_loop10, "MyLoopMusic/r_loop10.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif4_10.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop11.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat11(mND_MyLoopFragment.l_f4_loop11, "MyLoopMusic/r_loop11.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif4_11.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop12.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat12(mND_MyLoopFragment.l_f4_loop12, "MyLoopMusic/r_loop12.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif4_12.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop13.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat13(mND_MyLoopFragment.l_f4_loop13, "MyLoopMusic/r_loop13.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif4_13.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop14.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat14(mND_MyLoopFragment.l_f4_loop14, "MyLoopMusic/r_loop14.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif4_14.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop15.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat15(mND_MyLoopFragment.l_f4_loop15, "MyLoopMusic/r_loop15.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif4_15.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop16.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat16(mND_MyLoopFragment.l_f4_loop16, "MyLoopMusic/r_loop16.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif4_16.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop17.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat17(mND_MyLoopFragment.l_f4_loop17, "MyLoopMusic/r_loop17.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif4_17.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop18.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat18(mND_MyLoopFragment.l_f4_loop18, "MyLoopMusic/r_loop18.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif4_18.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop19.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat19(mND_MyLoopFragment.l_f4_loop19, "MyLoopMusic/r_loop19.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif4_19.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop20.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat20(mND_MyLoopFragment.l_f4_loop20, "MyLoopMusic/r_loop20.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif4_20.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f4_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
    }

    private void clickFeatured5() {
        this.l_f5_loop1.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat1(mND_MyLoopFragment.l_f5_loop1, "MyLoopMusic/r_loop1.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif5_1.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop2.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat2(mND_MyLoopFragment.l_f5_loop2, "MyLoopMusic/r_loop2.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif5_2.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop3.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat3(mND_MyLoopFragment.l_f5_loop3, "MyLoopMusic/r_loop3.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif5_3.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop4.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat4(mND_MyLoopFragment.l_f5_loop4, "MyLoopMusic/r_loop4.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif5_4.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop5.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat5(mND_MyLoopFragment.l_f5_loop5, "MyLoopMusic/r_loop5.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif5_5.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop6.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat6(mND_MyLoopFragment.l_f5_loop6, "MyLoopMusic/r_loop6.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif5_6.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop7.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat7(mND_MyLoopFragment.l_f5_loop7, "MyLoopMusic/r_loop7.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif5_7.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop8.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat8(mND_MyLoopFragment.l_f5_loop8, "MyLoopMusic/r_loop8.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif5_8.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop9.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat9(mND_MyLoopFragment.l_f5_loop9, "MyLoopMusic/r_loop9.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif5_9.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop10.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat10(mND_MyLoopFragment.l_f5_loop10, "MyLoopMusic/r_loop10.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif5_10.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop11.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat11(mND_MyLoopFragment.l_f5_loop11, "MyLoopMusic/r_loop11.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif5_11.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop12.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat12(mND_MyLoopFragment.l_f5_loop12, "MyLoopMusic/r_loop12.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif5_12.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop13.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat13(mND_MyLoopFragment.l_f5_loop13, "MyLoopMusic/r_loop13.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif5_13.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop14.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat14(mND_MyLoopFragment.l_f5_loop14, "MyLoopMusic/r_loop14.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif5_14.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop15.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat15(mND_MyLoopFragment.l_f5_loop15, "MyLoopMusic/r_loop15.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif5_15.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop16.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat16(mND_MyLoopFragment.l_f5_loop16, "MyLoopMusic/r_loop16.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif5_16.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop17.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat17(mND_MyLoopFragment.l_f5_loop17, "MyLoopMusic/r_loop17.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif5_17.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop18.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat18(mND_MyLoopFragment.l_f5_loop18, "MyLoopMusic/r_loop18.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif5_18.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop19.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat19(mND_MyLoopFragment.l_f5_loop19, "MyLoopMusic/r_loop19.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif5_19.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop20.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat20(mND_MyLoopFragment.l_f5_loop20, "MyLoopMusic/r_loop20.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif5_20.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f5_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
    }

    private void clickFeatured6() {
        this.l_f6_loop1.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat1(mND_MyLoopFragment.l_f6_loop1, "MyLoopMusic/r_loop1.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif6_1.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop2.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat2(mND_MyLoopFragment.l_f6_loop2, "MyLoopMusic/r_loop2.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif6_2.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop3.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat3(mND_MyLoopFragment.l_f6_loop3, "MyLoopMusic/r_loop3.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif6_3.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop4.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat4(mND_MyLoopFragment.l_f6_loop4, "MyLoopMusic/r_loop4.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif6_4.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop5.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat5(mND_MyLoopFragment.l_f6_loop5, "MyLoopMusic/r_loop5.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif6_5.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop6.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat6(mND_MyLoopFragment.l_f6_loop6, "MyLoopMusic/r_loop6.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif6_6.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop7.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat7(mND_MyLoopFragment.l_f6_loop7, "MyLoopMusic/r_loop7.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif6_7.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop8.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat8(mND_MyLoopFragment.l_f6_loop8, "MyLoopMusic/r_loop8.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif6_8.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop9.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat9(mND_MyLoopFragment.l_f6_loop9, "MyLoopMusic/r_loop9.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif6_9.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop10.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat10(mND_MyLoopFragment.l_f6_loop10, "MyLoopMusic/r_loop10.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif6_10.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop11.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat11(mND_MyLoopFragment.l_f6_loop11, "MyLoopMusic/r_loop11.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif6_11.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop12.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat12(mND_MyLoopFragment.l_f6_loop12, "MyLoopMusic/r_loop12.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif6_12.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop13.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat13(mND_MyLoopFragment.l_f6_loop13, "MyLoopMusic/r_loop13.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif6_13.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop14.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat14(mND_MyLoopFragment.l_f6_loop14, "MyLoopMusic/r_loop14.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif6_14.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop15.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat15(mND_MyLoopFragment.l_f6_loop15, "MyLoopMusic/r_loop15.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif6_15.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop16.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat16(mND_MyLoopFragment.l_f6_loop16, "MyLoopMusic/r_loop16.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif6_16.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop17.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat17(mND_MyLoopFragment.l_f6_loop17, "MyLoopMusic/r_loop17.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif6_17.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop18.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat18(mND_MyLoopFragment.l_f6_loop18, "MyLoopMusic/r_loop18.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif6_18.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop19.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat19(mND_MyLoopFragment.l_f6_loop19, "MyLoopMusic/r_loop19.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif6_19.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop20.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat20(mND_MyLoopFragment.l_f6_loop20, "MyLoopMusic/r_loop20.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif6_20.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f6_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
    }

    private void clickFeatured7() {
        this.l_f7_loop1.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat1(mND_MyLoopFragment.l_f7_loop1, "MyLoopMusic/r_loop1.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif7_1.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop2.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat2(mND_MyLoopFragment.l_f7_loop2, "MyLoopMusic/r_loop2.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif7_2.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop3.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat3(mND_MyLoopFragment.l_f7_loop3, "MyLoopMusic/r_loop3.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif7_3.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop4.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat4(mND_MyLoopFragment.l_f7_loop4, "MyLoopMusic/r_loop4.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif7_4.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop5.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat5(mND_MyLoopFragment.l_f7_loop5, "MyLoopMusic/r_loop5.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif7_5.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop6.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat6(mND_MyLoopFragment.l_f7_loop6, "MyLoopMusic/r_loop6.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif7_6.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop7.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat7(mND_MyLoopFragment.l_f7_loop7, "MyLoopMusic/r_loop7.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif7_7.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop8.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat8(mND_MyLoopFragment.l_f7_loop8, "MyLoopMusic/r_loop8.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif7_8.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop9.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat9(mND_MyLoopFragment.l_f7_loop9, "MyLoopMusic/r_loop9.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif7_9.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop10.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat10(mND_MyLoopFragment.l_f7_loop10, "MyLoopMusic/r_loop10.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif7_10.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop11.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat11(mND_MyLoopFragment.l_f7_loop11, "MyLoopMusic/r_loop11.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif7_11.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop12.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat12(mND_MyLoopFragment.l_f7_loop12, "MyLoopMusic/r_loop12.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif7_12.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop13.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat13(mND_MyLoopFragment.l_f7_loop13, "MyLoopMusic/r_loop13.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif7_13.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop14.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat14(mND_MyLoopFragment.l_f7_loop14, "MyLoopMusic/r_loop14.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif7_14.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop15.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat15(mND_MyLoopFragment.l_f7_loop15, "MyLoopMusic/r_loop15.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif7_15.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop16.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat16(mND_MyLoopFragment.l_f7_loop16, "MyLoopMusic/r_loop16.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif7_16.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop17.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat17(mND_MyLoopFragment.l_f7_loop17, "MyLoopMusic/r_loop17.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif7_17.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop18.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat18(mND_MyLoopFragment.l_f7_loop18, "MyLoopMusic/r_loop18.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif7_18.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop19.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat19(mND_MyLoopFragment.l_f7_loop19, "MyLoopMusic/r_loop19.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif7_19.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop20.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat20(mND_MyLoopFragment.l_f7_loop20, "MyLoopMusic/r_loop20.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif7_20.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f7_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
    }

    private void clickFeatured8() {
        this.l_f8_loop1.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat1(mND_MyLoopFragment.l_f8_loop1, "MyLoopMusic/r_loop1.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif8_1.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop2.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat2(mND_MyLoopFragment.l_f8_loop2, "MyLoopMusic/r_loop2.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif8_2.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop3.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat3(mND_MyLoopFragment.l_f8_loop3, "MyLoopMusic/r_loop3.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif8_3.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop4.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat4(mND_MyLoopFragment.l_f8_loop4, "MyLoopMusic/r_loop4.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif8_4.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop5.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat5(mND_MyLoopFragment.l_f8_loop5, "MyLoopMusic/r_loop5.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif8_5.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop6.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat6(mND_MyLoopFragment.l_f8_loop6, "MyLoopMusic/r_loop6.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif8_6.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop7.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat7(mND_MyLoopFragment.l_f8_loop7, "MyLoopMusic/r_loop7.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif8_7.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop8.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat8(mND_MyLoopFragment.l_f8_loop8, "MyLoopMusic/r_loop8.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif8_8.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop9.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat9(mND_MyLoopFragment.l_f8_loop9, "MyLoopMusic/r_loop9.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif8_9.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop10.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat10(mND_MyLoopFragment.l_f8_loop10, "MyLoopMusic/r_loop10.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif8_10.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop11.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat11(mND_MyLoopFragment.l_f8_loop11, "MyLoopMusic/r_loop11.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif8_11.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop12.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat12(mND_MyLoopFragment.l_f8_loop12, "MyLoopMusic/r_loop12.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif8_12.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop13.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat13(mND_MyLoopFragment.l_f8_loop13, "MyLoopMusic/r_loop13.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif8_13.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop14.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat14(mND_MyLoopFragment.l_f8_loop14, "MyLoopMusic/r_loop14.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif8_14.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop15.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat15(mND_MyLoopFragment.l_f8_loop15, "MyLoopMusic/r_loop15.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif8_15.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop16.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat16(mND_MyLoopFragment.l_f8_loop16, "MyLoopMusic/r_loop16.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif8_16.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop17.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat17(mND_MyLoopFragment.l_f8_loop17, "MyLoopMusic/r_loop17.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif8_17.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop18.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat18(mND_MyLoopFragment.l_f8_loop18, "MyLoopMusic/r_loop18.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif8_18.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop19.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat19(mND_MyLoopFragment.l_f8_loop19, "MyLoopMusic/r_loop19.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif8_19.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop20.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat20(mND_MyLoopFragment.l_f8_loop20, "MyLoopMusic/r_loop20.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif8_20.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f8_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
    }

    private void clickFeatured9() {
        this.l_f9_loop1.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat1(mND_MyLoopFragment.l_f9_loop1, "MyLoopMusic/r_loop1.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif9_1.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop2.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat2(mND_MyLoopFragment.l_f9_loop2, "MyLoopMusic/r_loop2.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif9_2.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop3.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat3(mND_MyLoopFragment.l_f9_loop3, "MyLoopMusic/r_loop3.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif9_3.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop4.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat4(mND_MyLoopFragment.l_f9_loop4, "MyLoopMusic/r_loop4.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif9_4.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop5.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat5(mND_MyLoopFragment.l_f9_loop5, "MyLoopMusic/r_loop5.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif9_5.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop6.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat6(mND_MyLoopFragment.l_f9_loop6, "MyLoopMusic/r_loop6.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif9_6.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop7.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat7(mND_MyLoopFragment.l_f9_loop7, "MyLoopMusic/r_loop7.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif9_7.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop8.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat8(mND_MyLoopFragment.l_f9_loop8, "MyLoopMusic/r_loop8.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif9_8.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop9.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat9(mND_MyLoopFragment.l_f9_loop9, "MyLoopMusic/r_loop9.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif9_9.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop10.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat10(mND_MyLoopFragment.l_f9_loop10, "MyLoopMusic/r_loop10.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif9_10.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop11.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat11(mND_MyLoopFragment.l_f9_loop11, "MyLoopMusic/r_loop11.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif9_11.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop12.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat12(mND_MyLoopFragment.l_f9_loop12, "MyLoopMusic/r_loop12.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif9_12.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop13.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat13(mND_MyLoopFragment.l_f9_loop13, "MyLoopMusic/r_loop13.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif9_13.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop14.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat14(mND_MyLoopFragment.l_f9_loop14, "MyLoopMusic/r_loop14.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif9_14.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop15.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat15(mND_MyLoopFragment.l_f9_loop15, "MyLoopMusic/r_loop15.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif9_15.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop16.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat16(mND_MyLoopFragment.l_f9_loop16, "MyLoopMusic/r_loop16.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif9_16.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop17.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat17(mND_MyLoopFragment.l_f9_loop17, "MyLoopMusic/r_loop17.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif9_17.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop18.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat18(mND_MyLoopFragment.l_f9_loop18, "MyLoopMusic/r_loop18.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif9_18.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop19.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat19(mND_MyLoopFragment.l_f9_loop19, "MyLoopMusic/r_loop19.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif9_19.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop20.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat20(mND_MyLoopFragment.l_f9_loop20, "MyLoopMusic/r_loop20.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif9_20.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f9_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
    }

    private void clickFeatured10() {
        this.l_f10_loop1.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat1(mND_MyLoopFragment.l_f10_loop1, "MyLoopMusic/r_loop1.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif10_1.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop2.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat2(mND_MyLoopFragment.l_f10_loop2, "MyLoopMusic/r_loop2.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif10_2.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop3.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat3(mND_MyLoopFragment.l_f10_loop3, "MyLoopMusic/r_loop3.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif10_3.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop4, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop4.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat4(mND_MyLoopFragment.l_f10_loop4, "MyLoopMusic/r_loop4.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_1();
                MND_MyLoopFragment.this.gif10_4.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop1, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop2, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop3, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop5.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat5(mND_MyLoopFragment.l_f10_loop5, "MyLoopMusic/r_loop5.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif10_5.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop6.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat6(mND_MyLoopFragment.l_f10_loop6, "MyLoopMusic/r_loop6.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif10_6.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop7.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat7(mND_MyLoopFragment.l_f10_loop7, "MyLoopMusic/r_loop7.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif10_7.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop8, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop8.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat8(mND_MyLoopFragment.l_f10_loop8, "MyLoopMusic/r_loop8.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_2();
                MND_MyLoopFragment.this.gif10_8.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop5, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop6, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop7, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop9.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat9(mND_MyLoopFragment.l_f10_loop9, "MyLoopMusic/r_loop9.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif10_9.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop10.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat10(mND_MyLoopFragment.l_f10_loop10, "MyLoopMusic/r_loop10.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif10_10.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop11.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat11(mND_MyLoopFragment.l_f10_loop11, "MyLoopMusic/r_loop11.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif10_11.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop12, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop12.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat12(mND_MyLoopFragment.l_f10_loop12, "MyLoopMusic/r_loop12.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_3();
                MND_MyLoopFragment.this.gif10_12.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop9, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop10, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop11, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop13.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat13(mND_MyLoopFragment.l_f10_loop13, "MyLoopMusic/r_loop13.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif10_13.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop14.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat14(mND_MyLoopFragment.l_f10_loop14, "MyLoopMusic/r_loop14.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif10_14.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop15.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat15(mND_MyLoopFragment.l_f10_loop15, "MyLoopMusic/r_loop15.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif10_15.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop16, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop16.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat16(mND_MyLoopFragment.l_f10_loop16, "MyLoopMusic/r_loop16.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_4();
                MND_MyLoopFragment.this.gif10_16.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop13, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop14, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop15, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop17.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat17(mND_MyLoopFragment.l_f10_loop17, "MyLoopMusic/r_loop17.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif10_17.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop18.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat18(mND_MyLoopFragment.l_f10_loop18, "MyLoopMusic/r_loop18.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif10_18.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop19.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat19(mND_MyLoopFragment.l_f10_loop19, "MyLoopMusic/r_loop19.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif10_19.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop20, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop20.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.performF1Beat20(mND_MyLoopFragment.l_f10_loop20, "MyLoopMusic/r_loop20.mp3");
                MND_MyLoopFragment.this.Invisible_gif1_5();
                MND_MyLoopFragment.this.gif10_20.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    public void run() {
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop17, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop18, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_MyLoopFragment.this.l_f10_loop19, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
    }

    public void clearMedia1() {
        MediaPlayer mediaPlayer = this.mediaPlayer1;
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            try {
                this.mediaPlayer1.stop();
                this.mediaPlayer1.reset();
            } catch (Exception unused) {
            }
        }
    }

    public void clearMedia5() {
        MediaPlayer mediaPlayer = this.mediaPlayer5;
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            try {
                this.mediaPlayer5.stop();
                this.mediaPlayer5.reset();
            } catch (Exception unused) {
            }
        }
    }

    public void clearMedia9() {
        MediaPlayer mediaPlayer = this.mediaPlayer9;
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            try {
                this.mediaPlayer9.stop();
                this.mediaPlayer9.reset();
            } catch (Exception unused) {
            }
        }
    }

    public void clearMedia13() {
        MediaPlayer mediaPlayer = this.mediaPlayer13;
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            try {
                this.mediaPlayer13.stop();
                this.mediaPlayer13.reset();
            } catch (Exception unused) {
            }
        }
    }

    public void clearMedia17() {
        MediaPlayer mediaPlayer = this.mediaPlayer17;
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            try {
                this.mediaPlayer17.stop();
                this.mediaPlayer17.reset();
            } catch (Exception unused) {
            }
        }
    }

    public void performF1Beat1(final LinearLayout linearLayout, final String str) {
        this.handler1 = new Handler();
        if (this.checkSection1 != 1) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo1++;
                    if (MND_MyLoopFragment.this.blinkNo1 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo1 < 5) {
                        MND_MyLoopFragment.this.handler1.postDelayed(MND_MyLoopFragment.this.runnable1, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo1 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn1_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer1.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer1.stop();
                            MND_MyLoopFragment.this.mediaPlayer1.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer1 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer1.prepare();
                        MND_MyLoopFragment.this.mediaPlayer1.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer1.start();
                        MND_MyLoopFragment.this.checkSection1 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable1 = r0;
            this.handler1.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer1;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo1++;
                    if (MND_MyLoopFragment.this.blinkNo1 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo1 < 5) {
                        MND_MyLoopFragment.this.handler1.postDelayed(MND_MyLoopFragment.this.runnable1, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo1 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn1_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer1.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer1.stop();
                            MND_MyLoopFragment.this.mediaPlayer1.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer1 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer1.prepare();
                        MND_MyLoopFragment.this.mediaPlayer1.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer1.start();
                        MND_MyLoopFragment.this.checkSection1 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable1 = r02;
            this.handler1.postDelayed(r02, 300);
            return;
        }
        Log.d("Dd", "ddgdrun: no null");
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {

            public void run() {
                MND_MyLoopFragment.this.blinkNo1++;
                if (MND_MyLoopFragment.this.blinkNo1 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo1 < 5) {
                    MND_MyLoopFragment.this.handler1.postDelayed(MND_MyLoopFragment.this.runnable1, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo1 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_1();
                try {
                    MND_MyLoopFragment.this.mediaPlayer1.stop();
                    MND_MyLoopFragment.this.mediaPlayer1.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable1 = r7;
        this.handler1.postDelayed(r7, 300);
    }

    public void performF1Beat2(final LinearLayout linearLayout, final String str) {
        this.handler2 = new Handler();
        if (this.checkSection1 != 2) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo2++;
                    if (MND_MyLoopFragment.this.blinkNo2 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo2 < 5) {
                        MND_MyLoopFragment.this.handler2.postDelayed(MND_MyLoopFragment.this.runnable2, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo2 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn1_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer1.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer1.stop();
                            MND_MyLoopFragment.this.mediaPlayer1.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer1 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer1.prepare();
                        MND_MyLoopFragment.this.mediaPlayer1.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer1.start();
                        MND_MyLoopFragment.this.checkSection1 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable2 = r0;
            this.handler2.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer1;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo2++;
                    if (MND_MyLoopFragment.this.blinkNo2 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo2 < 5) {
                        MND_MyLoopFragment.this.handler2.postDelayed(MND_MyLoopFragment.this.runnable2, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo2 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn1_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer1.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer1.stop();
                            MND_MyLoopFragment.this.mediaPlayer1.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer1 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer1.prepare();
                        MND_MyLoopFragment.this.mediaPlayer1.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer1.start();
                        MND_MyLoopFragment.this.checkSection1 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable2 = r02;
            this.handler2.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {

            public void run() {
                MND_MyLoopFragment.this.blinkNo2++;
                if (MND_MyLoopFragment.this.blinkNo2 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo2 < 5) {
                    MND_MyLoopFragment.this.handler2.postDelayed(MND_MyLoopFragment.this.runnable2, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo2 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_1();
                try {
                    MND_MyLoopFragment.this.mediaPlayer1.stop();
                    MND_MyLoopFragment.this.mediaPlayer1.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable2 = r7;
        this.handler2.postDelayed(r7, 300);
    }

    public void performF1Beat3(final LinearLayout linearLayout, final String str) {
        this.handler3 = new Handler();
        if (this.checkSection1 != 3) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo3++;
                    if (MND_MyLoopFragment.this.blinkNo3 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo3 < 5) {
                        MND_MyLoopFragment.this.handler3.postDelayed(MND_MyLoopFragment.this.runnable3, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo3 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn1_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer1.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer1.stop();
                            MND_MyLoopFragment.this.mediaPlayer1.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer1 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer1.prepare();
                        MND_MyLoopFragment.this.mediaPlayer1.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer1.start();
                        MND_MyLoopFragment.this.checkSection1 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable3 = r0;
            this.handler3.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer1;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo3++;
                    if (MND_MyLoopFragment.this.blinkNo3 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo3 < 5) {
                        MND_MyLoopFragment.this.handler3.postDelayed(MND_MyLoopFragment.this.runnable3, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo3 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn1_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer1.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer1.stop();
                            MND_MyLoopFragment.this.mediaPlayer1.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer1 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer1.prepare();
                        MND_MyLoopFragment.this.mediaPlayer1.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer1.start();
                        MND_MyLoopFragment.this.checkSection1 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable3 = r02;
            this.handler3.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {

            public void run() {
                MND_MyLoopFragment.this.blinkNo3++;
                if (MND_MyLoopFragment.this.blinkNo3 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo3 < 5) {
                    MND_MyLoopFragment.this.handler3.postDelayed(MND_MyLoopFragment.this.runnable3, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo3 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_1();
                try {
                    MND_MyLoopFragment.this.mediaPlayer1.stop();
                    MND_MyLoopFragment.this.mediaPlayer1.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable3 = r7;
        this.handler3.postDelayed(r7, 300);
    }

    public void performF1Beat4(final LinearLayout linearLayout, final String str) {
        this.handler4 = new Handler();
        if (this.checkSection1 != 4) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo4++;
                    if (MND_MyLoopFragment.this.blinkNo4 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo4 < 5) {
                        MND_MyLoopFragment.this.handler4.postDelayed(MND_MyLoopFragment.this.runnable4, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo4 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn1_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer1.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer1.stop();
                            MND_MyLoopFragment.this.mediaPlayer1.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer1 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer1.prepare();
                        MND_MyLoopFragment.this.mediaPlayer1.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer1.start();
                        MND_MyLoopFragment.this.checkSection1 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable4 = r0;
            this.handler4.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer1;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo4++;
                    if (MND_MyLoopFragment.this.blinkNo4 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo4 < 5) {
                        MND_MyLoopFragment.this.handler4.postDelayed(MND_MyLoopFragment.this.runnable4, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo4 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn1_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer1.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer1.stop();
                            MND_MyLoopFragment.this.mediaPlayer1.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer1 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer1.prepare();
                        MND_MyLoopFragment.this.mediaPlayer1.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer1.start();
                        MND_MyLoopFragment.this.checkSection1 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable4 = r02;
            this.handler4.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {

            public void run() {
                MND_MyLoopFragment.this.blinkNo4++;
                if (MND_MyLoopFragment.this.blinkNo4 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo4 < 5) {
                    MND_MyLoopFragment.this.handler4.postDelayed(MND_MyLoopFragment.this.runnable4, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo4 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_1();
                try {
                    MND_MyLoopFragment.this.mediaPlayer1.stop();
                    MND_MyLoopFragment.this.mediaPlayer1.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable4 = r7;
        this.handler4.postDelayed(r7, 300);
    }

    public void performF1Beat5(final LinearLayout linearLayout, final String str) {
        this.handler5 = new Handler();
        if (this.checkSection2 != 1) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo5++;
                    if (MND_MyLoopFragment.this.blinkNo5 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo5 < 5) {
                        MND_MyLoopFragment.this.handler5.postDelayed(MND_MyLoopFragment.this.runnable5, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo5 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn2_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer5.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer5.stop();
                            MND_MyLoopFragment.this.mediaPlayer5.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer5 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer5.prepare();
                        MND_MyLoopFragment.this.mediaPlayer5.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer5.start();
                        MND_MyLoopFragment.this.checkSection2 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable5 = r0;
            this.handler5.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer5;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo5++;
                    if (MND_MyLoopFragment.this.blinkNo5 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo5 < 5) {
                        MND_MyLoopFragment.this.handler5.postDelayed(MND_MyLoopFragment.this.runnable5, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo5 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn2_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer5.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer5.stop();
                            MND_MyLoopFragment.this.mediaPlayer5.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer5 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer5.prepare();
                        MND_MyLoopFragment.this.mediaPlayer5.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer5.start();
                        MND_MyLoopFragment.this.checkSection2 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable5 = r02;
            this.handler5.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {

            public void run() {
                MND_MyLoopFragment.this.blinkNo5++;
                if (MND_MyLoopFragment.this.blinkNo5 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo5 < 5) {
                    MND_MyLoopFragment.this.handler5.postDelayed(MND_MyLoopFragment.this.runnable5, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo5 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_2();
                try {
                    MND_MyLoopFragment.this.mediaPlayer5.stop();
                    MND_MyLoopFragment.this.mediaPlayer5.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable5 = r7;
        this.handler5.postDelayed(r7, 300);
    }

    public void performF1Beat6(final LinearLayout linearLayout, final String str) {
        this.handler6 = new Handler();
        if (this.checkSection2 != 2) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo6++;
                    if (MND_MyLoopFragment.this.blinkNo6 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo6 < 5) {
                        MND_MyLoopFragment.this.handler6.postDelayed(MND_MyLoopFragment.this.runnable6, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo6 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn2_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer5.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer5.stop();
                            MND_MyLoopFragment.this.mediaPlayer5.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer5 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer5.prepare();
                        MND_MyLoopFragment.this.mediaPlayer5.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer5.start();
                        MND_MyLoopFragment.this.checkSection2 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable6 = r0;
            this.handler6.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer5;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo6++;
                    if (MND_MyLoopFragment.this.blinkNo6 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo6 < 5) {
                        MND_MyLoopFragment.this.handler6.postDelayed(MND_MyLoopFragment.this.runnable6, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo6 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn2_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer5.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer5.stop();
                            MND_MyLoopFragment.this.mediaPlayer5.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer5 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer5.prepare();
                        MND_MyLoopFragment.this.mediaPlayer5.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer5.start();
                        MND_MyLoopFragment.this.checkSection2 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable6 = r02;
            this.handler6.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {

            public void run() {
                MND_MyLoopFragment.this.blinkNo6++;
                if (MND_MyLoopFragment.this.blinkNo6 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo6 < 5) {
                    MND_MyLoopFragment.this.handler6.postDelayed(MND_MyLoopFragment.this.runnable6, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo6 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_2();
                try {
                    MND_MyLoopFragment.this.mediaPlayer5.stop();
                    MND_MyLoopFragment.this.mediaPlayer5.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable6 = r7;
        this.handler6.postDelayed(r7, 300);
    }

    public void performF1Beat7(final LinearLayout linearLayout, final String str) {
        this.handler7 = new Handler();
        if (this.checkSection2 != 3) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo7++;
                    if (MND_MyLoopFragment.this.blinkNo7 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo7 < 5) {
                        MND_MyLoopFragment.this.handler7.postDelayed(MND_MyLoopFragment.this.runnable7, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo7 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn2_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer5.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer5.stop();
                            MND_MyLoopFragment.this.mediaPlayer5.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer5 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer5.prepare();
                        MND_MyLoopFragment.this.mediaPlayer5.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer5.start();
                        MND_MyLoopFragment.this.checkSection2 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable7 = r0;
            this.handler7.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer5;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo7++;
                    if (MND_MyLoopFragment.this.blinkNo7 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo7 < 5) {
                        MND_MyLoopFragment.this.handler7.postDelayed(MND_MyLoopFragment.this.runnable7, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo7 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn2_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer5.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer5.stop();
                            MND_MyLoopFragment.this.mediaPlayer5.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer5 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer5.prepare();
                        MND_MyLoopFragment.this.mediaPlayer5.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer5.start();
                        MND_MyLoopFragment.this.checkSection2 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable7 = r02;
            this.handler7.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {

            public void run() {
                MND_MyLoopFragment.this.blinkNo7++;
                if (MND_MyLoopFragment.this.blinkNo7 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo7 < 5) {
                    MND_MyLoopFragment.this.handler7.postDelayed(MND_MyLoopFragment.this.runnable7, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo7 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_2();
                try {
                    MND_MyLoopFragment.this.mediaPlayer5.stop();
                    MND_MyLoopFragment.this.mediaPlayer5.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable7 = r7;
        this.handler7.postDelayed(r7, 300);
    }

    public void performF1Beat8(final LinearLayout linearLayout, final String str) {
        this.handler8 = new Handler();
        if (this.checkSection2 != 4) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo8++;
                    if (MND_MyLoopFragment.this.blinkNo8 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo8 < 5) {
                        MND_MyLoopFragment.this.handler8.postDelayed(MND_MyLoopFragment.this.runnable8, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo8 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn2_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer5.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer5.stop();
                            MND_MyLoopFragment.this.mediaPlayer5.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer5 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer5.prepare();
                        MND_MyLoopFragment.this.mediaPlayer5.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer5.start();
                        MND_MyLoopFragment.this.checkSection2 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable8 = r0;
            this.handler8.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer5;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo8++;
                    if (MND_MyLoopFragment.this.blinkNo8 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo8 < 5) {
                        MND_MyLoopFragment.this.handler8.postDelayed(MND_MyLoopFragment.this.runnable8, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo8 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn2_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer5.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer5.stop();
                            MND_MyLoopFragment.this.mediaPlayer5.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer5 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer5.prepare();
                        MND_MyLoopFragment.this.mediaPlayer5.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer5.start();
                        MND_MyLoopFragment.this.checkSection2 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable8 = r02;
            this.handler8.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {

            public void run() {
                MND_MyLoopFragment.this.blinkNo8++;
                if (MND_MyLoopFragment.this.blinkNo8 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo8 < 5) {
                    MND_MyLoopFragment.this.handler8.postDelayed(MND_MyLoopFragment.this.runnable8, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo8 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_2();
                try {
                    MND_MyLoopFragment.this.mediaPlayer5.stop();
                    MND_MyLoopFragment.this.mediaPlayer5.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable8 = r7;
        this.handler8.postDelayed(r7, 300);
    }

    public void performF1Beat9(final LinearLayout linearLayout, final String str) {
        this.handler9 = new Handler();
        if (this.checkSection3 != 1) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo9++;
                    if (MND_MyLoopFragment.this.blinkNo9 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo9 < 5) {
                        MND_MyLoopFragment.this.handler9.postDelayed(MND_MyLoopFragment.this.runnable9, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo9 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn3_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer9.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer9.stop();
                            MND_MyLoopFragment.this.mediaPlayer9.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer9 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer9.prepare();
                        MND_MyLoopFragment.this.mediaPlayer9.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer9.start();
                        MND_MyLoopFragment.this.checkSection3 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable9 = r0;
            this.handler9.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer9;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo9++;
                    if (MND_MyLoopFragment.this.blinkNo9 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo9 < 5) {
                        MND_MyLoopFragment.this.handler9.postDelayed(MND_MyLoopFragment.this.runnable9, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo9 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn3_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer9.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer9.stop();
                            MND_MyLoopFragment.this.mediaPlayer9.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer9 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer9.prepare();
                        MND_MyLoopFragment.this.mediaPlayer9.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer9.start();
                        MND_MyLoopFragment.this.checkSection3 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable9 = r02;
            this.handler9.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {

            public void run() {
                MND_MyLoopFragment.this.blinkNo9++;
                if (MND_MyLoopFragment.this.blinkNo9 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo9 < 5) {
                    MND_MyLoopFragment.this.handler9.postDelayed(MND_MyLoopFragment.this.runnable9, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo9 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_3();
                try {
                    MND_MyLoopFragment.this.mediaPlayer9.stop();
                    MND_MyLoopFragment.this.mediaPlayer9.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable9 = r7;
        this.handler9.postDelayed(r7, 300);
    }

    public void performF1Beat10(final LinearLayout linearLayout, final String str) {
        this.handler10 = new Handler();
        if (this.checkSection3 != 2) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo10++;
                    if (MND_MyLoopFragment.this.blinkNo10 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo10 < 5) {
                        MND_MyLoopFragment.this.handler10.postDelayed(MND_MyLoopFragment.this.runnable10, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo10 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn3_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer9.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer9.stop();
                            MND_MyLoopFragment.this.mediaPlayer9.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer9 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer9.prepare();
                        MND_MyLoopFragment.this.mediaPlayer9.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer9.start();
                        MND_MyLoopFragment.this.checkSection3 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable10 = r0;
            this.handler10.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer9;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo10++;
                    if (MND_MyLoopFragment.this.blinkNo10 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo10 < 5) {
                        MND_MyLoopFragment.this.handler10.postDelayed(MND_MyLoopFragment.this.runnable10, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo10 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn3_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer9.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer9.stop();
                            MND_MyLoopFragment.this.mediaPlayer9.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer9 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer9.prepare();
                        MND_MyLoopFragment.this.mediaPlayer9.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer9.start();
                        MND_MyLoopFragment.this.checkSection3 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable10 = r02;
            this.handler10.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {

            public void run() {
                MND_MyLoopFragment.this.blinkNo10++;
                if (MND_MyLoopFragment.this.blinkNo10 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo10 < 5) {
                    MND_MyLoopFragment.this.handler10.postDelayed(MND_MyLoopFragment.this.runnable10, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo10 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_3();
                try {
                    MND_MyLoopFragment.this.mediaPlayer9.stop();
                    MND_MyLoopFragment.this.mediaPlayer9.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable10 = r7;
        this.handler10.postDelayed(r7, 300);
    }

    public void performF1Beat11(final LinearLayout linearLayout, final String str) {
        this.handler11 = new Handler();
        if (this.checkSection3 != 3) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo11++;
                    if (MND_MyLoopFragment.this.blinkNo11 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo11 < 5) {
                        MND_MyLoopFragment.this.handler11.postDelayed(MND_MyLoopFragment.this.runnable11, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo11 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn3_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer9.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer9.stop();
                            MND_MyLoopFragment.this.mediaPlayer9.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer9 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer9.prepare();
                        MND_MyLoopFragment.this.mediaPlayer9.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer9.start();
                        MND_MyLoopFragment.this.checkSection3 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable11 = r0;
            this.handler11.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer9;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo11++;
                    if (MND_MyLoopFragment.this.blinkNo11 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo11 < 5) {
                        MND_MyLoopFragment.this.handler11.postDelayed(MND_MyLoopFragment.this.runnable11, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo11 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn3_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer9.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer9.stop();
                            MND_MyLoopFragment.this.mediaPlayer9.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer9 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer9.prepare();
                        MND_MyLoopFragment.this.mediaPlayer9.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer9.start();
                        MND_MyLoopFragment.this.checkSection3 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable11 = r02;
            this.handler11.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {

            public void run() {
                MND_MyLoopFragment.this.blinkNo11++;
                if (MND_MyLoopFragment.this.blinkNo11 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo11 < 5) {
                    MND_MyLoopFragment.this.handler11.postDelayed(MND_MyLoopFragment.this.runnable11, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo11 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_3();
                try {
                    MND_MyLoopFragment.this.mediaPlayer9.stop();
                    MND_MyLoopFragment.this.mediaPlayer9.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable11 = r7;
        this.handler11.postDelayed(r7, 300);
    }

    public void performF1Beat12(final LinearLayout linearLayout, final String str) {
        this.handler12 = new Handler();
        if (this.checkSection3 != 4) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo12++;
                    if (MND_MyLoopFragment.this.blinkNo12 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo12 < 5) {
                        MND_MyLoopFragment.this.handler12.postDelayed(MND_MyLoopFragment.this.runnable12, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo12 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn3_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer9.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer9.stop();
                            MND_MyLoopFragment.this.mediaPlayer9.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer9 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer9.prepare();
                        MND_MyLoopFragment.this.mediaPlayer9.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer9.start();
                        MND_MyLoopFragment.this.checkSection3 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable12 = r0;
            this.handler12.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer9;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo12++;
                    if (MND_MyLoopFragment.this.blinkNo12 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo12 < 5) {
                        MND_MyLoopFragment.this.handler12.postDelayed(MND_MyLoopFragment.this.runnable12, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo12 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn3_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer9.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer9.stop();
                            MND_MyLoopFragment.this.mediaPlayer9.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer9 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer9.prepare();
                        MND_MyLoopFragment.this.mediaPlayer9.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer9.start();
                        MND_MyLoopFragment.this.checkSection3 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable12 = r02;
            this.handler12.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {

            public void run() {
                MND_MyLoopFragment.this.blinkNo12++;
                if (MND_MyLoopFragment.this.blinkNo12 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo12 < 5) {
                    MND_MyLoopFragment.this.handler12.postDelayed(MND_MyLoopFragment.this.runnable12, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo12 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_3();
                try {
                    MND_MyLoopFragment.this.mediaPlayer9.stop();
                    MND_MyLoopFragment.this.mediaPlayer9.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable12 = r7;
        this.handler12.postDelayed(r7, 300);
    }

    public void performF1Beat13(final LinearLayout linearLayout, final String str) {
        this.handler13 = new Handler();
        if (this.checkSection4 != 1) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo13++;
                    if (MND_MyLoopFragment.this.blinkNo13 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo13 < 5) {
                        MND_MyLoopFragment.this.handler13.postDelayed(MND_MyLoopFragment.this.runnable13, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo13 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn4_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer13.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer13.stop();
                            MND_MyLoopFragment.this.mediaPlayer13.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer13 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer13.prepare();
                        MND_MyLoopFragment.this.mediaPlayer13.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer13.start();
                        MND_MyLoopFragment.this.checkSection4 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable13 = r0;
            this.handler13.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer13;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo13++;
                    if (MND_MyLoopFragment.this.blinkNo13 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo13 < 5) {
                        MND_MyLoopFragment.this.handler13.postDelayed(MND_MyLoopFragment.this.runnable13, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo13 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn4_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer13.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer13.stop();
                            MND_MyLoopFragment.this.mediaPlayer13.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer13 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer13.prepare();
                        MND_MyLoopFragment.this.mediaPlayer13.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer13.start();
                        MND_MyLoopFragment.this.checkSection4 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable13 = r02;
            this.handler13.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {

            public void run() {
                MND_MyLoopFragment.this.blinkNo13++;
                if (MND_MyLoopFragment.this.blinkNo13 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo13 < 5) {
                    MND_MyLoopFragment.this.handler13.postDelayed(MND_MyLoopFragment.this.runnable13, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo13 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_4();
                try {
                    MND_MyLoopFragment.this.mediaPlayer13.stop();
                    MND_MyLoopFragment.this.mediaPlayer13.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable13 = r7;
        this.handler13.postDelayed(r7, 300);
    }

    public void performF1Beat14(final LinearLayout linearLayout, final String str) {
        this.handler14 = new Handler();
        if (this.checkSection4 != 2) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo14++;
                    if (MND_MyLoopFragment.this.blinkNo14 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo14 < 5) {
                        MND_MyLoopFragment.this.handler14.postDelayed(MND_MyLoopFragment.this.runnable14, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo14 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn4_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer13.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer13.stop();
                            MND_MyLoopFragment.this.mediaPlayer13.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer13 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer13.prepare();
                        MND_MyLoopFragment.this.mediaPlayer13.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer13.start();
                        MND_MyLoopFragment.this.checkSection4 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable14 = r0;
            this.handler14.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer13;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo14++;
                    if (MND_MyLoopFragment.this.blinkNo14 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo14 < 5) {
                        MND_MyLoopFragment.this.handler14.postDelayed(MND_MyLoopFragment.this.runnable14, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo14 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn4_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer13.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer13.stop();
                            MND_MyLoopFragment.this.mediaPlayer13.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer13 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer13.prepare();
                        MND_MyLoopFragment.this.mediaPlayer13.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer13.start();
                        MND_MyLoopFragment.this.checkSection4 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable14 = r02;
            this.handler14.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {

            public void run() {
                MND_MyLoopFragment.this.blinkNo14++;
                if (MND_MyLoopFragment.this.blinkNo14 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo14 < 5) {
                    MND_MyLoopFragment.this.handler14.postDelayed(MND_MyLoopFragment.this.runnable14, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo14 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_4();
                try {
                    MND_MyLoopFragment.this.mediaPlayer13.stop();
                    MND_MyLoopFragment.this.mediaPlayer13.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable14 = r7;
        this.handler14.postDelayed(r7, 300);
    }

    public void performF1Beat15(final LinearLayout linearLayout, final String str) {
        this.handler15 = new Handler();
        if (this.checkSection4 != 3) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo15++;
                    if (MND_MyLoopFragment.this.blinkNo15 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo15 < 5) {
                        MND_MyLoopFragment.this.handler15.postDelayed(MND_MyLoopFragment.this.runnable15, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo15 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn4_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer13.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer13.stop();
                            MND_MyLoopFragment.this.mediaPlayer13.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer13 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer13.prepare();
                        MND_MyLoopFragment.this.mediaPlayer13.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer13.start();
                        MND_MyLoopFragment.this.checkSection4 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable15 = r0;
            this.handler15.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer13;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo15++;
                    if (MND_MyLoopFragment.this.blinkNo15 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo15 < 5) {
                        MND_MyLoopFragment.this.handler15.postDelayed(MND_MyLoopFragment.this.runnable15, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo15 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn4_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer13.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer13.stop();
                            MND_MyLoopFragment.this.mediaPlayer13.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer13 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer13.prepare();
                        MND_MyLoopFragment.this.mediaPlayer13.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer13.start();
                        MND_MyLoopFragment.this.checkSection4 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable15 = r02;
            this.handler15.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {

            public void run() {
                MND_MyLoopFragment.this.blinkNo15++;
                if (MND_MyLoopFragment.this.blinkNo15 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo15 < 5) {
                    MND_MyLoopFragment.this.handler15.postDelayed(MND_MyLoopFragment.this.runnable15, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo15 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_4();
                try {
                    MND_MyLoopFragment.this.mediaPlayer13.stop();
                    MND_MyLoopFragment.this.mediaPlayer13.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable15 = r7;
        this.handler15.postDelayed(r7, 300);
    }

    public void performF1Beat16(final LinearLayout linearLayout, final String str) {
        this.handler16 = new Handler();
        if (this.checkSection4 != 4) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo16++;
                    if (MND_MyLoopFragment.this.blinkNo16 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo16 < 5) {
                        MND_MyLoopFragment.this.handler16.postDelayed(MND_MyLoopFragment.this.runnable16, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo16 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn4_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer13.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer13.stop();
                            MND_MyLoopFragment.this.mediaPlayer13.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer13 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer13.prepare();
                        MND_MyLoopFragment.this.mediaPlayer13.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer13.start();
                        MND_MyLoopFragment.this.checkSection4 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable16 = r0;
            this.handler16.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer13;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo16++;
                    if (MND_MyLoopFragment.this.blinkNo16 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo16 < 5) {
                        MND_MyLoopFragment.this.handler16.postDelayed(MND_MyLoopFragment.this.runnable16, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo16 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn4_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer13.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer13.stop();
                            MND_MyLoopFragment.this.mediaPlayer13.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer13 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer13.prepare();
                        MND_MyLoopFragment.this.mediaPlayer13.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer13.start();
                        MND_MyLoopFragment.this.checkSection4 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable16 = r02;
            this.handler16.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {

            public void run() {
                MND_MyLoopFragment.this.blinkNo16++;
                if (MND_MyLoopFragment.this.blinkNo16 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo16 < 5) {
                    MND_MyLoopFragment.this.handler16.postDelayed(MND_MyLoopFragment.this.runnable16, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo16 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_4();
                try {
                    MND_MyLoopFragment.this.mediaPlayer13.stop();
                    MND_MyLoopFragment.this.mediaPlayer13.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable16 = r7;
        this.handler16.postDelayed(r7, 300);
    }

    public void performF1Beat17(final LinearLayout linearLayout, final String str) {
        this.handler17 = new Handler();
        if (this.checkSection5 != 1) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo17++;
                    if (MND_MyLoopFragment.this.blinkNo17 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo17 < 5) {
                        MND_MyLoopFragment.this.handler17.postDelayed(MND_MyLoopFragment.this.runnable17, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo17 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn5_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer17.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer17.stop();
                            MND_MyLoopFragment.this.mediaPlayer17.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer17 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer17.prepare();
                        MND_MyLoopFragment.this.mediaPlayer17.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer17.start();
                        MND_MyLoopFragment.this.checkSection5 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable17 = r0;
            this.handler17.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer17;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo17++;
                    if (MND_MyLoopFragment.this.blinkNo17 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo17 < 5) {
                        MND_MyLoopFragment.this.handler17.postDelayed(MND_MyLoopFragment.this.runnable17, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo17 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn5_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer17.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer17.stop();
                            MND_MyLoopFragment.this.mediaPlayer17.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer17 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer17.prepare();
                        MND_MyLoopFragment.this.mediaPlayer17.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer17.start();
                        MND_MyLoopFragment.this.checkSection5 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable17 = r02;
            this.handler17.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {

            public void run() {
                MND_MyLoopFragment.this.blinkNo17++;
                if (MND_MyLoopFragment.this.blinkNo17 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo17 < 5) {
                    MND_MyLoopFragment.this.handler17.postDelayed(MND_MyLoopFragment.this.runnable17, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo17 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_5();
                try {
                    MND_MyLoopFragment.this.mediaPlayer17.stop();
                    MND_MyLoopFragment.this.mediaPlayer17.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable17 = r7;
        this.handler17.postDelayed(r7, 300);
    }

    public void performF1Beat18(final LinearLayout linearLayout, final String str) {
        this.handler18 = new Handler();
        if (this.checkSection5 != 2) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo18++;
                    if (MND_MyLoopFragment.this.blinkNo18 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo18 < 5) {
                        MND_MyLoopFragment.this.handler18.postDelayed(MND_MyLoopFragment.this.runnable18, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo18 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn5_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer17.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer17.stop();
                            MND_MyLoopFragment.this.mediaPlayer17.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer17 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer17.prepare();
                        MND_MyLoopFragment.this.mediaPlayer17.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer17.start();
                        MND_MyLoopFragment.this.checkSection5 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable18 = r0;
            this.handler18.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer17;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo18++;
                    if (MND_MyLoopFragment.this.blinkNo18 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo18 < 5) {
                        MND_MyLoopFragment.this.handler18.postDelayed(MND_MyLoopFragment.this.runnable18, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo18 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn5_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer17.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer17.stop();
                            MND_MyLoopFragment.this.mediaPlayer17.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer17 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer17.prepare();
                        MND_MyLoopFragment.this.mediaPlayer17.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer17.start();
                        MND_MyLoopFragment.this.checkSection5 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable18 = r02;
            this.handler18.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {

            public void run() {
                MND_MyLoopFragment.this.blinkNo18++;
                if (MND_MyLoopFragment.this.blinkNo18 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo18 < 5) {
                    MND_MyLoopFragment.this.handler18.postDelayed(MND_MyLoopFragment.this.runnable18, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo18 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_5();
                try {
                    MND_MyLoopFragment.this.mediaPlayer17.stop();
                    MND_MyLoopFragment.this.mediaPlayer17.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable18 = r7;
        this.handler18.postDelayed(r7, 300);
    }

    public void performF1Beat19(final LinearLayout linearLayout, final String str) {
        this.handler19 = new Handler();
        if (this.checkSection5 != 3) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo19++;
                    if (MND_MyLoopFragment.this.blinkNo19 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo19 < 5) {
                        MND_MyLoopFragment.this.handler19.postDelayed(MND_MyLoopFragment.this.runnable19, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo19 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn5_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer17.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer17.stop();
                            MND_MyLoopFragment.this.mediaPlayer17.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer17 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer17.prepare();
                        MND_MyLoopFragment.this.mediaPlayer17.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer17.start();
                        MND_MyLoopFragment.this.checkSection5 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable19 = r0;
            this.handler19.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer17;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo19++;
                    if (MND_MyLoopFragment.this.blinkNo19 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo19 < 5) {
                        MND_MyLoopFragment.this.handler19.postDelayed(MND_MyLoopFragment.this.runnable19, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo19 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn5_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer17.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer17.stop();
                            MND_MyLoopFragment.this.mediaPlayer17.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer17 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer17.prepare();
                        MND_MyLoopFragment.this.mediaPlayer17.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer17.start();
                        MND_MyLoopFragment.this.checkSection5 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable19 = r02;
            this.handler19.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {

            public void run() {
                MND_MyLoopFragment.this.blinkNo19++;
                if (MND_MyLoopFragment.this.blinkNo19 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo19 < 5) {
                    MND_MyLoopFragment.this.handler19.postDelayed(MND_MyLoopFragment.this.runnable19, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo19 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_5();
                try {
                    MND_MyLoopFragment.this.mediaPlayer17.stop();
                    MND_MyLoopFragment.this.mediaPlayer17.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable19 = r7;
        this.handler19.postDelayed(r7, 300);
    }

    public void performF1Beat20(final LinearLayout linearLayout, final String str) {
        this.handler20 = new Handler();
        if (this.checkSection5 != 4) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo20++;
                    if (MND_MyLoopFragment.this.blinkNo20 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo20 < 5) {
                        MND_MyLoopFragment.this.handler20.postDelayed(MND_MyLoopFragment.this.runnable20, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo20 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn5_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer17.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer17.stop();
                            MND_MyLoopFragment.this.mediaPlayer17.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer17 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer17.prepare();
                        MND_MyLoopFragment.this.mediaPlayer17.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer17.start();
                        MND_MyLoopFragment.this.checkSection5 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable20 = r0;
            this.handler20.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer17;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {

                public void run() {
                    MND_MyLoopFragment.this.blinkNo20++;
                    if (MND_MyLoopFragment.this.blinkNo20 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_press_blink));
                    }
                    if (MND_MyLoopFragment.this.blinkNo20 < 5) {
                        MND_MyLoopFragment.this.handler20.postDelayed(MND_MyLoopFragment.this.runnable20, 300);
                        return;
                    }
                    MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                    mND_MyLoopFragment.blinkNo20 = 0;
                    ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn5_press));
                    try {
                        if (MND_MyLoopFragment.this.mediaPlayer17.isPlaying()) {
                            MND_MyLoopFragment.this.mediaPlayer17.stop();
                            MND_MyLoopFragment.this.mediaPlayer17.reset();
                        }
                        MND_MyLoopFragment.this.mediaPlayer17 = new MediaPlayer();
                        MND_MyLoopFragment.this.mediaPlayer17.prepare();
                        MND_MyLoopFragment.this.mediaPlayer17.setLooping(true);
                        MND_MyLoopFragment.this.mediaPlayer17.start();
                        MND_MyLoopFragment.this.checkSection5 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable20 = r02;
            this.handler20.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            public void run() {
                MND_MyLoopFragment.this.blinkNo20++;
                if (MND_MyLoopFragment.this.blinkNo20 % 3 == 1) {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_press_blink));
                } else {
                    ViewCompat.setBackground(linearLayout, MND_MyLoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                }
                if (MND_MyLoopFragment.this.blinkNo20 < 5) {
                    MND_MyLoopFragment.this.handler20.postDelayed(MND_MyLoopFragment.this.runnable20, 300);
                    return;
                }
                MND_MyLoopFragment mND_MyLoopFragment = MND_MyLoopFragment.this;
                mND_MyLoopFragment.blinkNo20 = 0;
                ViewCompat.setBackground(linearLayout, mND_MyLoopFragment.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                MND_MyLoopFragment.this.Invisible_gif1_5();
                try {
                    MND_MyLoopFragment.this.mediaPlayer17.stop();
                    MND_MyLoopFragment.this.mediaPlayer17.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable20 = r7;
        this.handler20.postDelayed(r7, 300);
    }

    private void initLoopBind(View view) {
        this.l_f1_loop1 = (LinearLayout) view.findViewById(R.id.l_f1_loop1);
        this.l_f1_loop2 = (LinearLayout) view.findViewById(R.id.l_f1_loop2);
        this.l_f1_loop3 = (LinearLayout) view.findViewById(R.id.l_f1_loop3);
        this.l_f1_loop4 = (LinearLayout) view.findViewById(R.id.l_f1_loop4);
        this.l_f1_loop5 = (LinearLayout) view.findViewById(R.id.l_f1_loop5);
        this.l_f1_loop6 = (LinearLayout) view.findViewById(R.id.l_f1_loop6);
        this.l_f1_loop7 = (LinearLayout) view.findViewById(R.id.l_f1_loop7);
        this.l_f1_loop8 = (LinearLayout) view.findViewById(R.id.l_f1_loop8);
        this.l_f1_loop9 = (LinearLayout) view.findViewById(R.id.l_f1_loop9);
        this.l_f1_loop10 = (LinearLayout) view.findViewById(R.id.l_f1_loop10);
        this.l_f1_loop11 = (LinearLayout) view.findViewById(R.id.l_f1_loop11);
        this.l_f1_loop12 = (LinearLayout) view.findViewById(R.id.l_f1_loop12);
        this.l_f1_loop13 = (LinearLayout) view.findViewById(R.id.l_f1_loop13);
        this.l_f1_loop14 = (LinearLayout) view.findViewById(R.id.l_f1_loop14);
        this.l_f1_loop15 = (LinearLayout) view.findViewById(R.id.l_f1_loop15);
        this.l_f1_loop16 = (LinearLayout) view.findViewById(R.id.l_f1_loop16);
        this.l_f1_loop17 = (LinearLayout) view.findViewById(R.id.l_f1_loop17);
        this.l_f1_loop18 = (LinearLayout) view.findViewById(R.id.l_f1_loop18);
        this.l_f1_loop19 = (LinearLayout) view.findViewById(R.id.l_f1_loop19);
        this.l_f1_loop20 = (LinearLayout) view.findViewById(R.id.l_f1_loop20);
        this.l_f2_loop1 = (LinearLayout) view.findViewById(R.id.l_f2_loop1);
        this.l_f2_loop2 = (LinearLayout) view.findViewById(R.id.l_f2_loop2);
        this.l_f2_loop3 = (LinearLayout) view.findViewById(R.id.l_f2_loop3);
        this.l_f2_loop4 = (LinearLayout) view.findViewById(R.id.l_f2_loop4);
        this.l_f2_loop5 = (LinearLayout) view.findViewById(R.id.l_f2_loop5);
        this.l_f2_loop6 = (LinearLayout) view.findViewById(R.id.l_f2_loop6);
        this.l_f2_loop7 = (LinearLayout) view.findViewById(R.id.l_f2_loop7);
        this.l_f2_loop8 = (LinearLayout) view.findViewById(R.id.l_f2_loop8);
        this.l_f2_loop9 = (LinearLayout) view.findViewById(R.id.l_f2_loop9);
        this.l_f2_loop10 = (LinearLayout) view.findViewById(R.id.l_f2_loop10);
        this.l_f2_loop11 = (LinearLayout) view.findViewById(R.id.l_f2_loop11);
        this.l_f2_loop12 = (LinearLayout) view.findViewById(R.id.l_f2_loop12);
        this.l_f2_loop13 = (LinearLayout) view.findViewById(R.id.l_f2_loop13);
        this.l_f2_loop14 = (LinearLayout) view.findViewById(R.id.l_f2_loop14);
        this.l_f2_loop15 = (LinearLayout) view.findViewById(R.id.l_f2_loop15);
        this.l_f2_loop16 = (LinearLayout) view.findViewById(R.id.l_f2_loop16);
        this.l_f2_loop17 = (LinearLayout) view.findViewById(R.id.l_f2_loop17);
        this.l_f2_loop18 = (LinearLayout) view.findViewById(R.id.l_f2_loop18);
        this.l_f2_loop19 = (LinearLayout) view.findViewById(R.id.l_f2_loop19);
        this.l_f2_loop20 = (LinearLayout) view.findViewById(R.id.l_f2_loop20);
        this.l_f3_loop1 = (LinearLayout) view.findViewById(R.id.l_f3_loop1);
        this.l_f3_loop2 = (LinearLayout) view.findViewById(R.id.l_f3_loop2);
        this.l_f3_loop3 = (LinearLayout) view.findViewById(R.id.l_f3_loop3);
        this.l_f3_loop4 = (LinearLayout) view.findViewById(R.id.l_f3_loop4);
        this.l_f3_loop5 = (LinearLayout) view.findViewById(R.id.l_f3_loop5);
        this.l_f3_loop6 = (LinearLayout) view.findViewById(R.id.l_f3_loop6);
        this.l_f3_loop7 = (LinearLayout) view.findViewById(R.id.l_f3_loop7);
        this.l_f3_loop8 = (LinearLayout) view.findViewById(R.id.l_f3_loop8);
        this.l_f3_loop9 = (LinearLayout) view.findViewById(R.id.l_f3_loop9);
        this.l_f3_loop10 = (LinearLayout) view.findViewById(R.id.l_f3_loop10);
        this.l_f3_loop11 = (LinearLayout) view.findViewById(R.id.l_f3_loop11);
        this.l_f3_loop12 = (LinearLayout) view.findViewById(R.id.l_f3_loop12);
        this.l_f3_loop13 = (LinearLayout) view.findViewById(R.id.l_f3_loop13);
        this.l_f3_loop14 = (LinearLayout) view.findViewById(R.id.l_f3_loop14);
        this.l_f3_loop15 = (LinearLayout) view.findViewById(R.id.l_f3_loop15);
        this.l_f3_loop16 = (LinearLayout) view.findViewById(R.id.l_f3_loop16);
        this.l_f3_loop17 = (LinearLayout) view.findViewById(R.id.l_f3_loop17);
        this.l_f3_loop18 = (LinearLayout) view.findViewById(R.id.l_f3_loop18);
        this.l_f3_loop19 = (LinearLayout) view.findViewById(R.id.l_f3_loop19);
        this.l_f3_loop20 = (LinearLayout) view.findViewById(R.id.l_f3_loop20);
        this.l_f4_loop1 = (LinearLayout) view.findViewById(R.id.l_f4_loop1);
        this.l_f4_loop2 = (LinearLayout) view.findViewById(R.id.l_f4_loop2);
        this.l_f4_loop3 = (LinearLayout) view.findViewById(R.id.l_f4_loop3);
        this.l_f4_loop4 = (LinearLayout) view.findViewById(R.id.l_f4_loop4);
        this.l_f4_loop5 = (LinearLayout) view.findViewById(R.id.l_f4_loop5);
        this.l_f4_loop6 = (LinearLayout) view.findViewById(R.id.l_f4_loop6);
        this.l_f4_loop7 = (LinearLayout) view.findViewById(R.id.l_f4_loop7);
        this.l_f4_loop8 = (LinearLayout) view.findViewById(R.id.l_f4_loop8);
        this.l_f4_loop9 = (LinearLayout) view.findViewById(R.id.l_f4_loop9);
        this.l_f4_loop10 = (LinearLayout) view.findViewById(R.id.l_f4_loop10);
        this.l_f4_loop11 = (LinearLayout) view.findViewById(R.id.l_f4_loop11);
        this.l_f4_loop12 = (LinearLayout) view.findViewById(R.id.l_f4_loop12);
        this.l_f4_loop13 = (LinearLayout) view.findViewById(R.id.l_f4_loop13);
        this.l_f4_loop14 = (LinearLayout) view.findViewById(R.id.l_f4_loop14);
        this.l_f4_loop15 = (LinearLayout) view.findViewById(R.id.l_f4_loop15);
        this.l_f4_loop16 = (LinearLayout) view.findViewById(R.id.l_f4_loop16);
        this.l_f4_loop17 = (LinearLayout) view.findViewById(R.id.l_f4_loop17);
        this.l_f4_loop18 = (LinearLayout) view.findViewById(R.id.l_f4_loop18);
        this.l_f4_loop19 = (LinearLayout) view.findViewById(R.id.l_f4_loop19);
        this.l_f4_loop20 = (LinearLayout) view.findViewById(R.id.l_f4_loop20);
        this.l_f5_loop1 = (LinearLayout) view.findViewById(R.id.l_f5_loop1);
        this.l_f5_loop2 = (LinearLayout) view.findViewById(R.id.l_f5_loop2);
        this.l_f5_loop3 = (LinearLayout) view.findViewById(R.id.l_f5_loop3);
        this.l_f5_loop4 = (LinearLayout) view.findViewById(R.id.l_f5_loop4);
        this.l_f5_loop5 = (LinearLayout) view.findViewById(R.id.l_f5_loop5);
        this.l_f5_loop6 = (LinearLayout) view.findViewById(R.id.l_f5_loop6);
        this.l_f5_loop7 = (LinearLayout) view.findViewById(R.id.l_f5_loop7);
        this.l_f5_loop8 = (LinearLayout) view.findViewById(R.id.l_f5_loop8);
        this.l_f5_loop9 = (LinearLayout) view.findViewById(R.id.l_f5_loop9);
        this.l_f5_loop10 = (LinearLayout) view.findViewById(R.id.l_f5_loop10);
        this.l_f5_loop11 = (LinearLayout) view.findViewById(R.id.l_f5_loop11);
        this.l_f5_loop12 = (LinearLayout) view.findViewById(R.id.l_f5_loop12);
        this.l_f5_loop13 = (LinearLayout) view.findViewById(R.id.l_f5_loop13);
        this.l_f5_loop14 = (LinearLayout) view.findViewById(R.id.l_f5_loop14);
        this.l_f5_loop15 = (LinearLayout) view.findViewById(R.id.l_f5_loop15);
        this.l_f5_loop16 = (LinearLayout) view.findViewById(R.id.l_f5_loop16);
        this.l_f5_loop17 = (LinearLayout) view.findViewById(R.id.l_f5_loop17);
        this.l_f5_loop18 = (LinearLayout) view.findViewById(R.id.l_f5_loop18);
        this.l_f5_loop19 = (LinearLayout) view.findViewById(R.id.l_f5_loop19);
        this.l_f5_loop20 = (LinearLayout) view.findViewById(R.id.l_f5_loop20);
        this.l_f6_loop1 = (LinearLayout) view.findViewById(R.id.l_f6_loop1);
        this.l_f6_loop2 = (LinearLayout) view.findViewById(R.id.l_f6_loop2);
        this.l_f6_loop3 = (LinearLayout) view.findViewById(R.id.l_f6_loop3);
        this.l_f6_loop4 = (LinearLayout) view.findViewById(R.id.l_f6_loop4);
        this.l_f6_loop5 = (LinearLayout) view.findViewById(R.id.l_f6_loop5);
        this.l_f6_loop6 = (LinearLayout) view.findViewById(R.id.l_f6_loop6);
        this.l_f6_loop7 = (LinearLayout) view.findViewById(R.id.l_f6_loop7);
        this.l_f6_loop8 = (LinearLayout) view.findViewById(R.id.l_f6_loop8);
        this.l_f6_loop9 = (LinearLayout) view.findViewById(R.id.l_f6_loop9);
        this.l_f6_loop10 = (LinearLayout) view.findViewById(R.id.l_f6_loop10);
        this.l_f6_loop11 = (LinearLayout) view.findViewById(R.id.l_f6_loop11);
        this.l_f6_loop12 = (LinearLayout) view.findViewById(R.id.l_f6_loop12);
        this.l_f6_loop13 = (LinearLayout) view.findViewById(R.id.l_f6_loop13);
        this.l_f6_loop14 = (LinearLayout) view.findViewById(R.id.l_f6_loop14);
        this.l_f6_loop15 = (LinearLayout) view.findViewById(R.id.l_f6_loop15);
        this.l_f6_loop16 = (LinearLayout) view.findViewById(R.id.l_f6_loop16);
        this.l_f6_loop17 = (LinearLayout) view.findViewById(R.id.l_f6_loop17);
        this.l_f6_loop18 = (LinearLayout) view.findViewById(R.id.l_f6_loop18);
        this.l_f6_loop19 = (LinearLayout) view.findViewById(R.id.l_f6_loop19);
        this.l_f6_loop20 = (LinearLayout) view.findViewById(R.id.l_f6_loop20);
        this.l_f7_loop1 = (LinearLayout) view.findViewById(R.id.l_f7_loop1);
        this.l_f7_loop2 = (LinearLayout) view.findViewById(R.id.l_f7_loop2);
        this.l_f7_loop3 = (LinearLayout) view.findViewById(R.id.l_f7_loop3);
        this.l_f7_loop4 = (LinearLayout) view.findViewById(R.id.l_f7_loop4);
        this.l_f7_loop5 = (LinearLayout) view.findViewById(R.id.l_f7_loop5);
        this.l_f7_loop6 = (LinearLayout) view.findViewById(R.id.l_f7_loop6);
        this.l_f7_loop7 = (LinearLayout) view.findViewById(R.id.l_f7_loop7);
        this.l_f7_loop8 = (LinearLayout) view.findViewById(R.id.l_f7_loop8);
        this.l_f7_loop9 = (LinearLayout) view.findViewById(R.id.l_f7_loop9);
        this.l_f7_loop10 = (LinearLayout) view.findViewById(R.id.l_f7_loop10);
        this.l_f7_loop11 = (LinearLayout) view.findViewById(R.id.l_f7_loop11);
        this.l_f7_loop12 = (LinearLayout) view.findViewById(R.id.l_f7_loop12);
        this.l_f7_loop13 = (LinearLayout) view.findViewById(R.id.l_f7_loop13);
        this.l_f7_loop14 = (LinearLayout) view.findViewById(R.id.l_f7_loop14);
        this.l_f7_loop15 = (LinearLayout) view.findViewById(R.id.l_f7_loop15);
        this.l_f7_loop16 = (LinearLayout) view.findViewById(R.id.l_f7_loop16);
        this.l_f7_loop17 = (LinearLayout) view.findViewById(R.id.l_f7_loop17);
        this.l_f7_loop18 = (LinearLayout) view.findViewById(R.id.l_f7_loop18);
        this.l_f7_loop19 = (LinearLayout) view.findViewById(R.id.l_f7_loop19);
        this.l_f7_loop20 = (LinearLayout) view.findViewById(R.id.l_f7_loop20);
        this.l_f8_loop1 = (LinearLayout) view.findViewById(R.id.l_f8_loop1);
        this.l_f8_loop2 = (LinearLayout) view.findViewById(R.id.l_f8_loop2);
        this.l_f8_loop3 = (LinearLayout) view.findViewById(R.id.l_f8_loop3);
        this.l_f8_loop4 = (LinearLayout) view.findViewById(R.id.l_f8_loop4);
        this.l_f8_loop5 = (LinearLayout) view.findViewById(R.id.l_f8_loop5);
        this.l_f8_loop6 = (LinearLayout) view.findViewById(R.id.l_f8_loop6);
        this.l_f8_loop7 = (LinearLayout) view.findViewById(R.id.l_f8_loop7);
        this.l_f8_loop8 = (LinearLayout) view.findViewById(R.id.l_f8_loop8);
        this.l_f8_loop9 = (LinearLayout) view.findViewById(R.id.l_f8_loop9);
        this.l_f8_loop10 = (LinearLayout) view.findViewById(R.id.l_f8_loop10);
        this.l_f8_loop11 = (LinearLayout) view.findViewById(R.id.l_f8_loop11);
        this.l_f8_loop12 = (LinearLayout) view.findViewById(R.id.l_f8_loop12);
        this.l_f8_loop13 = (LinearLayout) view.findViewById(R.id.l_f8_loop13);
        this.l_f8_loop14 = (LinearLayout) view.findViewById(R.id.l_f8_loop14);
        this.l_f8_loop15 = (LinearLayout) view.findViewById(R.id.l_f8_loop15);
        this.l_f8_loop16 = (LinearLayout) view.findViewById(R.id.l_f8_loop16);
        this.l_f8_loop17 = (LinearLayout) view.findViewById(R.id.l_f8_loop17);
        this.l_f8_loop18 = (LinearLayout) view.findViewById(R.id.l_f8_loop18);
        this.l_f8_loop19 = (LinearLayout) view.findViewById(R.id.l_f8_loop19);
        this.l_f8_loop20 = (LinearLayout) view.findViewById(R.id.l_f8_loop20);
        this.l_f9_loop1 = (LinearLayout) view.findViewById(R.id.l_f9_loop1);
        this.l_f9_loop2 = (LinearLayout) view.findViewById(R.id.l_f9_loop2);
        this.l_f9_loop3 = (LinearLayout) view.findViewById(R.id.l_f9_loop3);
        this.l_f9_loop4 = (LinearLayout) view.findViewById(R.id.l_f9_loop4);
        this.l_f9_loop5 = (LinearLayout) view.findViewById(R.id.l_f9_loop5);
        this.l_f9_loop6 = (LinearLayout) view.findViewById(R.id.l_f9_loop6);
        this.l_f9_loop7 = (LinearLayout) view.findViewById(R.id.l_f9_loop7);
        this.l_f9_loop8 = (LinearLayout) view.findViewById(R.id.l_f9_loop8);
        this.l_f9_loop9 = (LinearLayout) view.findViewById(R.id.l_f9_loop9);
        this.l_f9_loop10 = (LinearLayout) view.findViewById(R.id.l_f9_loop10);
        this.l_f9_loop11 = (LinearLayout) view.findViewById(R.id.l_f9_loop11);
        this.l_f9_loop12 = (LinearLayout) view.findViewById(R.id.l_f9_loop12);
        this.l_f9_loop13 = (LinearLayout) view.findViewById(R.id.l_f9_loop13);
        this.l_f9_loop14 = (LinearLayout) view.findViewById(R.id.l_f9_loop14);
        this.l_f9_loop15 = (LinearLayout) view.findViewById(R.id.l_f9_loop15);
        this.l_f9_loop16 = (LinearLayout) view.findViewById(R.id.l_f9_loop16);
        this.l_f9_loop17 = (LinearLayout) view.findViewById(R.id.l_f9_loop17);
        this.l_f9_loop18 = (LinearLayout) view.findViewById(R.id.l_f9_loop18);
        this.l_f9_loop19 = (LinearLayout) view.findViewById(R.id.l_f9_loop19);
        this.l_f9_loop20 = (LinearLayout) view.findViewById(R.id.l_f9_loop20);
        this.l_f10_loop1 = (LinearLayout) view.findViewById(R.id.l_f10_loop1);
        this.l_f10_loop2 = (LinearLayout) view.findViewById(R.id.l_f10_loop2);
        this.l_f10_loop3 = (LinearLayout) view.findViewById(R.id.l_f10_loop3);
        this.l_f10_loop4 = (LinearLayout) view.findViewById(R.id.l_f10_loop4);
        this.l_f10_loop5 = (LinearLayout) view.findViewById(R.id.l_f10_loop5);
        this.l_f10_loop6 = (LinearLayout) view.findViewById(R.id.l_f10_loop6);
        this.l_f10_loop7 = (LinearLayout) view.findViewById(R.id.l_f10_loop7);
        this.l_f10_loop8 = (LinearLayout) view.findViewById(R.id.l_f10_loop8);
        this.l_f10_loop9 = (LinearLayout) view.findViewById(R.id.l_f10_loop9);
        this.l_f10_loop10 = (LinearLayout) view.findViewById(R.id.l_f10_loop10);
        this.l_f10_loop11 = (LinearLayout) view.findViewById(R.id.l_f10_loop11);
        this.l_f10_loop12 = (LinearLayout) view.findViewById(R.id.l_f10_loop12);
        this.l_f10_loop13 = (LinearLayout) view.findViewById(R.id.l_f10_loop13);
        this.l_f10_loop14 = (LinearLayout) view.findViewById(R.id.l_f10_loop14);
        this.l_f10_loop15 = (LinearLayout) view.findViewById(R.id.l_f10_loop15);
        this.l_f10_loop16 = (LinearLayout) view.findViewById(R.id.l_f10_loop16);
        this.l_f10_loop17 = (LinearLayout) view.findViewById(R.id.l_f10_loop17);
        this.l_f10_loop18 = (LinearLayout) view.findViewById(R.id.l_f10_loop18);
        this.l_f10_loop19 = (LinearLayout) view.findViewById(R.id.l_f10_loop19);
        this.l_f10_loop20 = (LinearLayout) view.findViewById(R.id.l_f10_loop20);
        this.gif1_1 = (ImageView) view.findViewById(R.id.gif1_1);
        this.gif1_2 = (ImageView) view.findViewById(R.id.gif1_2);
        this.gif1_3 = (ImageView) view.findViewById(R.id.gif1_3);
        this.gif1_4 = (ImageView) view.findViewById(R.id.gif1_4);
        this.gif1_5 = (ImageView) view.findViewById(R.id.gif1_5);
        this.gif1_6 = (ImageView) view.findViewById(R.id.gif1_6);
        this.gif1_7 = (ImageView) view.findViewById(R.id.gif1_7);
        this.gif1_8 = (ImageView) view.findViewById(R.id.gif1_8);
        this.gif1_9 = (ImageView) view.findViewById(R.id.gif1_9);
        this.gif1_10 = (ImageView) view.findViewById(R.id.gif1_10);
        this.gif1_11 = (ImageView) view.findViewById(R.id.gif1_11);
        this.gif1_12 = (ImageView) view.findViewById(R.id.gif1_12);
        this.gif1_13 = (ImageView) view.findViewById(R.id.gif1_13);
        this.gif1_14 = (ImageView) view.findViewById(R.id.gif1_14);
        this.gif1_15 = (ImageView) view.findViewById(R.id.gif1_15);
        this.gif1_16 = (ImageView) view.findViewById(R.id.gif1_16);
        this.gif1_17 = (ImageView) view.findViewById(R.id.gif1_17);
        this.gif1_18 = (ImageView) view.findViewById(R.id.gif1_18);
        this.gif1_19 = (ImageView) view.findViewById(R.id.gif1_19);
        this.gif1_20 = (ImageView) view.findViewById(R.id.gif1_20);
        this.gif2_1 = (ImageView) view.findViewById(R.id.gif2_1);
        this.gif2_2 = (ImageView) view.findViewById(R.id.gif2_2);
        this.gif2_3 = (ImageView) view.findViewById(R.id.gif2_3);
        this.gif2_4 = (ImageView) view.findViewById(R.id.gif2_4);
        this.gif2_5 = (ImageView) view.findViewById(R.id.gif2_5);
        this.gif2_6 = (ImageView) view.findViewById(R.id.gif2_6);
        this.gif2_7 = (ImageView) view.findViewById(R.id.gif2_7);
        this.gif2_8 = (ImageView) view.findViewById(R.id.gif2_8);
        this.gif2_9 = (ImageView) view.findViewById(R.id.gif2_9);
        this.gif2_10 = (ImageView) view.findViewById(R.id.gif2_10);
        this.gif2_11 = (ImageView) view.findViewById(R.id.gif2_11);
        this.gif2_12 = (ImageView) view.findViewById(R.id.gif2_12);
        this.gif2_13 = (ImageView) view.findViewById(R.id.gif2_13);
        this.gif2_14 = (ImageView) view.findViewById(R.id.gif2_14);
        this.gif2_15 = (ImageView) view.findViewById(R.id.gif2_15);
        this.gif2_16 = (ImageView) view.findViewById(R.id.gif2_16);
        this.gif2_17 = (ImageView) view.findViewById(R.id.gif2_17);
        this.gif2_18 = (ImageView) view.findViewById(R.id.gif2_18);
        this.gif2_19 = (ImageView) view.findViewById(R.id.gif2_19);
        this.gif2_20 = (ImageView) view.findViewById(R.id.gif2_20);
        this.gif3_1 = (ImageView) view.findViewById(R.id.gif3_1);
        this.gif3_2 = (ImageView) view.findViewById(R.id.gif3_2);
        this.gif3_3 = (ImageView) view.findViewById(R.id.gif3_3);
        this.gif3_4 = (ImageView) view.findViewById(R.id.gif3_4);
        this.gif3_5 = (ImageView) view.findViewById(R.id.gif3_5);
        this.gif3_6 = (ImageView) view.findViewById(R.id.gif3_6);
        this.gif3_7 = (ImageView) view.findViewById(R.id.gif3_7);
        this.gif3_8 = (ImageView) view.findViewById(R.id.gif3_8);
        this.gif3_9 = (ImageView) view.findViewById(R.id.gif3_9);
        this.gif3_10 = (ImageView) view.findViewById(R.id.gif3_10);
        this.gif3_11 = (ImageView) view.findViewById(R.id.gif3_11);
        this.gif3_12 = (ImageView) view.findViewById(R.id.gif3_12);
        this.gif3_13 = (ImageView) view.findViewById(R.id.gif3_13);
        this.gif3_14 = (ImageView) view.findViewById(R.id.gif3_14);
        this.gif3_15 = (ImageView) view.findViewById(R.id.gif3_15);
        this.gif3_16 = (ImageView) view.findViewById(R.id.gif3_16);
        this.gif3_17 = (ImageView) view.findViewById(R.id.gif3_17);
        this.gif3_18 = (ImageView) view.findViewById(R.id.gif3_18);
        this.gif3_19 = (ImageView) view.findViewById(R.id.gif3_19);
        this.gif3_20 = (ImageView) view.findViewById(R.id.gif3_20);
        this.gif4_1 = (ImageView) view.findViewById(R.id.gif4_1);
        this.gif4_2 = (ImageView) view.findViewById(R.id.gif4_2);
        this.gif4_3 = (ImageView) view.findViewById(R.id.gif4_3);
        this.gif4_4 = (ImageView) view.findViewById(R.id.gif4_4);
        this.gif4_5 = (ImageView) view.findViewById(R.id.gif4_5);
        this.gif4_6 = (ImageView) view.findViewById(R.id.gif4_6);
        this.gif4_7 = (ImageView) view.findViewById(R.id.gif4_7);
        this.gif4_8 = (ImageView) view.findViewById(R.id.gif4_8);
        this.gif4_9 = (ImageView) view.findViewById(R.id.gif4_9);
        this.gif4_10 = (ImageView) view.findViewById(R.id.gif4_10);
        this.gif4_11 = (ImageView) view.findViewById(R.id.gif4_11);
        this.gif4_12 = (ImageView) view.findViewById(R.id.gif4_12);
        this.gif4_13 = (ImageView) view.findViewById(R.id.gif4_13);
        this.gif4_14 = (ImageView) view.findViewById(R.id.gif4_14);
        this.gif4_15 = (ImageView) view.findViewById(R.id.gif4_15);
        this.gif4_16 = (ImageView) view.findViewById(R.id.gif4_16);
        this.gif4_17 = (ImageView) view.findViewById(R.id.gif4_17);
        this.gif4_18 = (ImageView) view.findViewById(R.id.gif4_18);
        this.gif4_19 = (ImageView) view.findViewById(R.id.gif4_19);
        this.gif4_20 = (ImageView) view.findViewById(R.id.gif4_20);
        this.gif5_1 = (ImageView) view.findViewById(R.id.gif5_1);
        this.gif5_2 = (ImageView) view.findViewById(R.id.gif5_2);
        this.gif5_3 = (ImageView) view.findViewById(R.id.gif5_3);
        this.gif5_4 = (ImageView) view.findViewById(R.id.gif5_4);
        this.gif5_5 = (ImageView) view.findViewById(R.id.gif5_5);
        this.gif5_6 = (ImageView) view.findViewById(R.id.gif5_6);
        this.gif5_7 = (ImageView) view.findViewById(R.id.gif5_7);
        this.gif5_8 = (ImageView) view.findViewById(R.id.gif5_8);
        this.gif5_9 = (ImageView) view.findViewById(R.id.gif5_9);
        this.gif5_10 = (ImageView) view.findViewById(R.id.gif5_10);
        this.gif5_11 = (ImageView) view.findViewById(R.id.gif5_11);
        this.gif5_12 = (ImageView) view.findViewById(R.id.gif5_12);
        this.gif5_13 = (ImageView) view.findViewById(R.id.gif5_13);
        this.gif5_14 = (ImageView) view.findViewById(R.id.gif5_14);
        this.gif5_15 = (ImageView) view.findViewById(R.id.gif5_15);
        this.gif5_16 = (ImageView) view.findViewById(R.id.gif5_16);
        this.gif5_17 = (ImageView) view.findViewById(R.id.gif5_17);
        this.gif5_18 = (ImageView) view.findViewById(R.id.gif5_18);
        this.gif5_19 = (ImageView) view.findViewById(R.id.gif5_19);
        this.gif5_20 = (ImageView) view.findViewById(R.id.gif5_20);
        this.gif6_1 = (ImageView) view.findViewById(R.id.gif6_1);
        this.gif6_2 = (ImageView) view.findViewById(R.id.gif6_2);
        this.gif6_3 = (ImageView) view.findViewById(R.id.gif6_3);
        this.gif6_4 = (ImageView) view.findViewById(R.id.gif6_4);
        this.gif6_5 = (ImageView) view.findViewById(R.id.gif6_5);
        this.gif6_6 = (ImageView) view.findViewById(R.id.gif6_6);
        this.gif6_7 = (ImageView) view.findViewById(R.id.gif6_7);
        this.gif6_8 = (ImageView) view.findViewById(R.id.gif6_8);
        this.gif6_9 = (ImageView) view.findViewById(R.id.gif6_9);
        this.gif6_10 = (ImageView) view.findViewById(R.id.gif6_10);
        this.gif6_11 = (ImageView) view.findViewById(R.id.gif6_11);
        this.gif6_12 = (ImageView) view.findViewById(R.id.gif6_12);
        this.gif6_13 = (ImageView) view.findViewById(R.id.gif6_13);
        this.gif6_14 = (ImageView) view.findViewById(R.id.gif6_14);
        this.gif6_15 = (ImageView) view.findViewById(R.id.gif6_15);
        this.gif6_16 = (ImageView) view.findViewById(R.id.gif6_16);
        this.gif6_17 = (ImageView) view.findViewById(R.id.gif6_17);
        this.gif6_18 = (ImageView) view.findViewById(R.id.gif6_18);
        this.gif6_19 = (ImageView) view.findViewById(R.id.gif6_19);
        this.gif6_20 = (ImageView) view.findViewById(R.id.gif6_20);
        this.gif7_1 = (ImageView) view.findViewById(R.id.gif7_1);
        this.gif7_2 = (ImageView) view.findViewById(R.id.gif7_2);
        this.gif7_3 = (ImageView) view.findViewById(R.id.gif7_3);
        this.gif7_4 = (ImageView) view.findViewById(R.id.gif7_4);
        this.gif7_5 = (ImageView) view.findViewById(R.id.gif7_5);
        this.gif7_6 = (ImageView) view.findViewById(R.id.gif7_6);
        this.gif7_7 = (ImageView) view.findViewById(R.id.gif7_7);
        this.gif7_8 = (ImageView) view.findViewById(R.id.gif7_8);
        this.gif7_9 = (ImageView) view.findViewById(R.id.gif7_9);
        this.gif7_10 = (ImageView) view.findViewById(R.id.gif7_10);
        this.gif7_11 = (ImageView) view.findViewById(R.id.gif7_11);
        this.gif7_12 = (ImageView) view.findViewById(R.id.gif7_12);
        this.gif7_13 = (ImageView) view.findViewById(R.id.gif7_13);
        this.gif7_14 = (ImageView) view.findViewById(R.id.gif7_14);
        this.gif7_15 = (ImageView) view.findViewById(R.id.gif7_15);
        this.gif7_16 = (ImageView) view.findViewById(R.id.gif7_16);
        this.gif7_17 = (ImageView) view.findViewById(R.id.gif7_17);
        this.gif7_18 = (ImageView) view.findViewById(R.id.gif7_18);
        this.gif7_19 = (ImageView) view.findViewById(R.id.gif7_19);
        this.gif7_20 = (ImageView) view.findViewById(R.id.gif7_20);
        this.gif8_1 = (ImageView) view.findViewById(R.id.gif8_1);
        this.gif8_2 = (ImageView) view.findViewById(R.id.gif8_2);
        this.gif8_3 = (ImageView) view.findViewById(R.id.gif8_3);
        this.gif8_4 = (ImageView) view.findViewById(R.id.gif8_4);
        this.gif8_5 = (ImageView) view.findViewById(R.id.gif8_5);
        this.gif8_6 = (ImageView) view.findViewById(R.id.gif8_6);
        this.gif8_7 = (ImageView) view.findViewById(R.id.gif8_7);
        this.gif8_8 = (ImageView) view.findViewById(R.id.gif8_8);
        this.gif8_9 = (ImageView) view.findViewById(R.id.gif8_9);
        this.gif8_10 = (ImageView) view.findViewById(R.id.gif8_10);
        this.gif8_11 = (ImageView) view.findViewById(R.id.gif8_11);
        this.gif8_12 = (ImageView) view.findViewById(R.id.gif8_12);
        this.gif8_13 = (ImageView) view.findViewById(R.id.gif8_13);
        this.gif8_14 = (ImageView) view.findViewById(R.id.gif8_14);
        this.gif8_15 = (ImageView) view.findViewById(R.id.gif8_15);
        this.gif8_16 = (ImageView) view.findViewById(R.id.gif8_16);
        this.gif8_17 = (ImageView) view.findViewById(R.id.gif8_17);
        this.gif8_18 = (ImageView) view.findViewById(R.id.gif8_18);
        this.gif8_19 = (ImageView) view.findViewById(R.id.gif8_19);
        this.gif8_20 = (ImageView) view.findViewById(R.id.gif8_20);
        this.gif9_1 = (ImageView) view.findViewById(R.id.gif9_1);
        this.gif9_2 = (ImageView) view.findViewById(R.id.gif9_2);
        this.gif9_3 = (ImageView) view.findViewById(R.id.gif9_3);
        this.gif9_4 = (ImageView) view.findViewById(R.id.gif9_4);
        this.gif9_5 = (ImageView) view.findViewById(R.id.gif9_5);
        this.gif9_6 = (ImageView) view.findViewById(R.id.gif9_6);
        this.gif9_7 = (ImageView) view.findViewById(R.id.gif9_7);
        this.gif9_8 = (ImageView) view.findViewById(R.id.gif9_8);
        this.gif9_9 = (ImageView) view.findViewById(R.id.gif9_9);
        this.gif9_10 = (ImageView) view.findViewById(R.id.gif9_10);
        this.gif9_11 = (ImageView) view.findViewById(R.id.gif9_11);
        this.gif9_12 = (ImageView) view.findViewById(R.id.gif9_12);
        this.gif9_13 = (ImageView) view.findViewById(R.id.gif9_13);
        this.gif9_14 = (ImageView) view.findViewById(R.id.gif9_14);
        this.gif9_15 = (ImageView) view.findViewById(R.id.gif9_15);
        this.gif9_16 = (ImageView) view.findViewById(R.id.gif9_16);
        this.gif9_17 = (ImageView) view.findViewById(R.id.gif9_17);
        this.gif9_18 = (ImageView) view.findViewById(R.id.gif9_18);
        this.gif9_19 = (ImageView) view.findViewById(R.id.gif9_19);
        this.gif9_20 = (ImageView) view.findViewById(R.id.gif9_20);
        this.gif10_1 = (ImageView) view.findViewById(R.id.gif10_1);
        this.gif10_2 = (ImageView) view.findViewById(R.id.gif10_2);
        this.gif10_3 = (ImageView) view.findViewById(R.id.gif10_3);
        this.gif10_4 = (ImageView) view.findViewById(R.id.gif10_4);
        this.gif10_5 = (ImageView) view.findViewById(R.id.gif10_5);
        this.gif10_6 = (ImageView) view.findViewById(R.id.gif10_6);
        this.gif10_7 = (ImageView) view.findViewById(R.id.gif10_7);
        this.gif10_8 = (ImageView) view.findViewById(R.id.gif10_8);
        this.gif10_9 = (ImageView) view.findViewById(R.id.gif10_9);
        this.gif10_10 = (ImageView) view.findViewById(R.id.gif10_10);
        this.gif10_11 = (ImageView) view.findViewById(R.id.gif10_11);
        this.gif10_12 = (ImageView) view.findViewById(R.id.gif10_12);
        this.gif10_13 = (ImageView) view.findViewById(R.id.gif10_13);
        this.gif10_14 = (ImageView) view.findViewById(R.id.gif10_14);
        this.gif10_15 = (ImageView) view.findViewById(R.id.gif10_15);
        this.gif10_16 = (ImageView) view.findViewById(R.id.gif10_16);
        this.gif10_17 = (ImageView) view.findViewById(R.id.gif10_17);
        this.gif10_18 = (ImageView) view.findViewById(R.id.gif10_18);
        this.gif10_19 = (ImageView) view.findViewById(R.id.gif10_19);
        this.gif10_20 = (ImageView) view.findViewById(R.id.gif10_20);
        RequestBuilder<GifDrawable> asGif = Glide.with(this).asGif();
        Integer valueOf = Integer.valueOf((int) R.drawable.ic_beat1);
        asGif.load(valueOf).into(this.gif1_1);
        Glide.with(this).asGif().load(valueOf).into(this.gif1_2);
        Glide.with(this).asGif().load(valueOf).into(this.gif1_3);
        Glide.with(this).asGif().load(valueOf).into(this.gif1_4);
        RequestBuilder<GifDrawable> asGif2 = Glide.with(this).asGif();
        Integer valueOf2 = Integer.valueOf((int) R.drawable.ic_beat2);
        asGif2.load(valueOf2).into(this.gif1_5);
        Glide.with(this).asGif().load(valueOf2).into(this.gif1_6);
        Glide.with(this).asGif().load(valueOf2).into(this.gif1_7);
        Glide.with(this).asGif().load(valueOf2).into(this.gif1_8);
        RequestBuilder<GifDrawable> asGif3 = Glide.with(this).asGif();
        Integer valueOf3 = Integer.valueOf((int) R.drawable.ic_beat3);
        asGif3.load(valueOf3).into(this.gif1_9);
        Glide.with(this).asGif().load(valueOf3).into(this.gif1_10);
        Glide.with(this).asGif().load(valueOf3).into(this.gif1_11);
        Glide.with(this).asGif().load(valueOf3).into(this.gif1_12);
        RequestBuilder<GifDrawable> asGif4 = Glide.with(this).asGif();
        Integer valueOf4 = Integer.valueOf((int) R.drawable.ic_beat4);
        asGif4.load(valueOf4).into(this.gif1_13);
        Glide.with(this).asGif().load(valueOf4).into(this.gif1_14);
        Glide.with(this).asGif().load(valueOf4).into(this.gif1_15);
        Glide.with(this).asGif().load(valueOf4).into(this.gif1_16);
        RequestBuilder<GifDrawable> asGif5 = Glide.with(this).asGif();
        Integer valueOf5 = Integer.valueOf((int) R.drawable.ic_beat5);
        asGif5.load(valueOf5).into(this.gif1_17);
        Glide.with(this).asGif().load(valueOf5).into(this.gif1_18);
        Glide.with(this).asGif().load(valueOf5).into(this.gif1_19);
        Glide.with(this).asGif().load(valueOf5).into(this.gif1_20);
        Glide.with(this).asGif().load(valueOf).into(this.gif2_1);
        Glide.with(this).asGif().load(valueOf).into(this.gif2_2);
        Glide.with(this).asGif().load(valueOf).into(this.gif2_3);
        Glide.with(this).asGif().load(valueOf).into(this.gif2_4);
        Glide.with(this).asGif().load(valueOf2).into(this.gif2_5);
        Glide.with(this).asGif().load(valueOf2).into(this.gif2_6);
        Glide.with(this).asGif().load(valueOf2).into(this.gif2_7);
        Glide.with(this).asGif().load(valueOf2).into(this.gif2_8);
        Glide.with(this).asGif().load(valueOf3).into(this.gif2_9);
        Glide.with(this).asGif().load(valueOf3).into(this.gif2_10);
        Glide.with(this).asGif().load(valueOf3).into(this.gif2_11);
        Glide.with(this).asGif().load(valueOf3).into(this.gif2_12);
        Glide.with(this).asGif().load(valueOf4).into(this.gif2_13);
        Glide.with(this).asGif().load(valueOf4).into(this.gif2_14);
        Glide.with(this).asGif().load(valueOf4).into(this.gif2_15);
        Glide.with(this).asGif().load(valueOf4).into(this.gif2_16);
        Glide.with(this).asGif().load(valueOf5).into(this.gif2_17);
        Glide.with(this).asGif().load(valueOf5).into(this.gif2_18);
        Glide.with(this).asGif().load(valueOf5).into(this.gif2_19);
        Glide.with(this).asGif().load(valueOf5).into(this.gif2_20);
        Glide.with(this).asGif().load(valueOf).into(this.gif3_1);
        Glide.with(this).asGif().load(valueOf).into(this.gif3_2);
        Glide.with(this).asGif().load(valueOf).into(this.gif3_3);
        Glide.with(this).asGif().load(valueOf).into(this.gif3_4);
        Glide.with(this).asGif().load(valueOf2).into(this.gif3_5);
        Glide.with(this).asGif().load(valueOf2).into(this.gif3_6);
        Glide.with(this).asGif().load(valueOf2).into(this.gif3_7);
        Glide.with(this).asGif().load(valueOf2).into(this.gif3_8);
        Glide.with(this).asGif().load(valueOf3).into(this.gif3_9);
        Glide.with(this).asGif().load(valueOf3).into(this.gif3_10);
        Glide.with(this).asGif().load(valueOf3).into(this.gif3_11);
        Glide.with(this).asGif().load(valueOf3).into(this.gif3_12);
        Glide.with(this).asGif().load(valueOf4).into(this.gif3_13);
        Glide.with(this).asGif().load(valueOf4).into(this.gif3_14);
        Glide.with(this).asGif().load(valueOf4).into(this.gif3_15);
        Glide.with(this).asGif().load(valueOf4).into(this.gif3_16);
        Glide.with(this).asGif().load(valueOf5).into(this.gif3_17);
        Glide.with(this).asGif().load(valueOf5).into(this.gif3_18);
        Glide.with(this).asGif().load(valueOf5).into(this.gif3_19);
        Glide.with(this).asGif().load(valueOf5).into(this.gif3_20);
        Glide.with(this).asGif().load(valueOf).into(this.gif5_1);
        Glide.with(this).asGif().load(valueOf).into(this.gif5_2);
        Glide.with(this).asGif().load(valueOf).into(this.gif5_3);
        Glide.with(this).asGif().load(valueOf).into(this.gif5_4);
        Glide.with(this).asGif().load(valueOf2).into(this.gif5_5);
        Glide.with(this).asGif().load(valueOf2).into(this.gif5_6);
        Glide.with(this).asGif().load(valueOf2).into(this.gif5_7);
        Glide.with(this).asGif().load(valueOf2).into(this.gif5_8);
        Glide.with(this).asGif().load(valueOf3).into(this.gif5_9);
        Glide.with(this).asGif().load(valueOf3).into(this.gif5_10);
        Glide.with(this).asGif().load(valueOf3).into(this.gif5_11);
        Glide.with(this).asGif().load(valueOf3).into(this.gif5_12);
        Glide.with(this).asGif().load(valueOf4).into(this.gif5_13);
        Glide.with(this).asGif().load(valueOf4).into(this.gif5_14);
        Glide.with(this).asGif().load(valueOf4).into(this.gif5_15);
        Glide.with(this).asGif().load(valueOf4).into(this.gif5_16);
        Glide.with(this).asGif().load(valueOf5).into(this.gif5_17);
        Glide.with(this).asGif().load(valueOf5).into(this.gif5_18);
        Glide.with(this).asGif().load(valueOf5).into(this.gif5_19);
        Glide.with(this).asGif().load(valueOf5).into(this.gif5_20);
        Glide.with(this).asGif().load(valueOf).into(this.gif6_1);
        Glide.with(this).asGif().load(valueOf).into(this.gif6_2);
        Glide.with(this).asGif().load(valueOf).into(this.gif6_3);
        Glide.with(this).asGif().load(valueOf).into(this.gif6_4);
        Glide.with(this).asGif().load(valueOf2).into(this.gif6_5);
        Glide.with(this).asGif().load(valueOf2).into(this.gif6_6);
        Glide.with(this).asGif().load(valueOf2).into(this.gif6_7);
        Glide.with(this).asGif().load(valueOf2).into(this.gif6_8);
        Glide.with(this).asGif().load(valueOf3).into(this.gif6_9);
        Glide.with(this).asGif().load(valueOf3).into(this.gif6_10);
        Glide.with(this).asGif().load(valueOf3).into(this.gif6_11);
        Glide.with(this).asGif().load(valueOf3).into(this.gif6_12);
        Glide.with(this).asGif().load(valueOf4).into(this.gif6_13);
        Glide.with(this).asGif().load(valueOf4).into(this.gif6_14);
        Glide.with(this).asGif().load(valueOf4).into(this.gif6_15);
        Glide.with(this).asGif().load(valueOf4).into(this.gif6_16);
        Glide.with(this).asGif().load(valueOf5).into(this.gif6_17);
        Glide.with(this).asGif().load(valueOf5).into(this.gif6_18);
        Glide.with(this).asGif().load(valueOf5).into(this.gif6_19);
        Glide.with(this).asGif().load(valueOf5).into(this.gif6_20);
        Glide.with(this).asGif().load(valueOf).into(this.gif7_1);
        Glide.with(this).asGif().load(valueOf).into(this.gif7_2);
        Glide.with(this).asGif().load(valueOf).into(this.gif7_3);
        Glide.with(this).asGif().load(valueOf).into(this.gif7_4);
        Glide.with(this).asGif().load(valueOf2).into(this.gif7_5);
        Glide.with(this).asGif().load(valueOf2).into(this.gif7_6);
        Glide.with(this).asGif().load(valueOf2).into(this.gif7_7);
        Glide.with(this).asGif().load(valueOf2).into(this.gif7_8);
        Glide.with(this).asGif().load(valueOf3).into(this.gif7_9);
        Glide.with(this).asGif().load(valueOf3).into(this.gif7_10);
        Glide.with(this).asGif().load(valueOf3).into(this.gif7_11);
        Glide.with(this).asGif().load(valueOf3).into(this.gif7_12);
        Glide.with(this).asGif().load(valueOf4).into(this.gif7_13);
        Glide.with(this).asGif().load(valueOf4).into(this.gif7_14);
        Glide.with(this).asGif().load(valueOf4).into(this.gif7_15);
        Glide.with(this).asGif().load(valueOf4).into(this.gif7_16);
        Glide.with(this).asGif().load(valueOf5).into(this.gif7_17);
        Glide.with(this).asGif().load(valueOf5).into(this.gif7_18);
        Glide.with(this).asGif().load(valueOf5).into(this.gif7_19);
        Glide.with(this).asGif().load(valueOf5).into(this.gif7_20);
        Glide.with(this).asGif().load(valueOf).into(this.gif8_1);
        Glide.with(this).asGif().load(valueOf).into(this.gif8_2);
        Glide.with(this).asGif().load(valueOf).into(this.gif8_3);
        Glide.with(this).asGif().load(valueOf).into(this.gif8_4);
        Glide.with(this).asGif().load(valueOf2).into(this.gif8_5);
        Glide.with(this).asGif().load(valueOf2).into(this.gif8_6);
        Glide.with(this).asGif().load(valueOf2).into(this.gif8_7);
        Glide.with(this).asGif().load(valueOf2).into(this.gif8_8);
        Glide.with(this).asGif().load(valueOf3).into(this.gif8_9);
        Glide.with(this).asGif().load(valueOf3).into(this.gif8_10);
        Glide.with(this).asGif().load(valueOf3).into(this.gif8_11);
        Glide.with(this).asGif().load(valueOf3).into(this.gif8_12);
        Glide.with(this).asGif().load(valueOf4).into(this.gif8_13);
        Glide.with(this).asGif().load(valueOf4).into(this.gif8_14);
        Glide.with(this).asGif().load(valueOf4).into(this.gif8_15);
        Glide.with(this).asGif().load(valueOf4).into(this.gif8_16);
        Glide.with(this).asGif().load(valueOf5).into(this.gif8_17);
        Glide.with(this).asGif().load(valueOf5).into(this.gif8_18);
        Glide.with(this).asGif().load(valueOf5).into(this.gif8_19);
        Glide.with(this).asGif().load(valueOf5).into(this.gif8_20);
        Glide.with(this).asGif().load(valueOf).into(this.gif9_1);
        Glide.with(this).asGif().load(valueOf).into(this.gif9_2);
        Glide.with(this).asGif().load(valueOf).into(this.gif9_3);
        Glide.with(this).asGif().load(valueOf).into(this.gif9_4);
        Glide.with(this).asGif().load(valueOf2).into(this.gif9_5);
        Glide.with(this).asGif().load(valueOf2).into(this.gif9_6);
        Glide.with(this).asGif().load(valueOf2).into(this.gif9_7);
        Glide.with(this).asGif().load(valueOf2).into(this.gif9_8);
        Glide.with(this).asGif().load(valueOf3).into(this.gif9_9);
        Glide.with(this).asGif().load(valueOf3).into(this.gif9_10);
        Glide.with(this).asGif().load(valueOf3).into(this.gif9_11);
        Glide.with(this).asGif().load(valueOf3).into(this.gif9_12);
        Glide.with(this).asGif().load(valueOf4).into(this.gif9_13);
        Glide.with(this).asGif().load(valueOf4).into(this.gif9_14);
        Glide.with(this).asGif().load(valueOf4).into(this.gif9_15);
        Glide.with(this).asGif().load(valueOf4).into(this.gif9_16);
        Glide.with(this).asGif().load(valueOf5).into(this.gif9_17);
        Glide.with(this).asGif().load(valueOf5).into(this.gif9_18);
        Glide.with(this).asGif().load(valueOf5).into(this.gif9_19);
        Glide.with(this).asGif().load(valueOf5).into(this.gif9_20);
        Glide.with(this).asGif().load(valueOf).into(this.gif10_1);
        Glide.with(this).asGif().load(valueOf).into(this.gif10_2);
        Glide.with(this).asGif().load(valueOf).into(this.gif10_3);
        Glide.with(this).asGif().load(valueOf).into(this.gif10_4);
        Glide.with(this).asGif().load(valueOf2).into(this.gif10_5);
        Glide.with(this).asGif().load(valueOf2).into(this.gif10_6);
        Glide.with(this).asGif().load(valueOf2).into(this.gif10_7);
        Glide.with(this).asGif().load(valueOf2).into(this.gif10_8);
        Glide.with(this).asGif().load(valueOf3).into(this.gif10_9);
        Glide.with(this).asGif().load(valueOf3).into(this.gif10_10);
        Glide.with(this).asGif().load(valueOf3).into(this.gif10_11);
        Glide.with(this).asGif().load(valueOf3).into(this.gif10_12);
        Glide.with(this).asGif().load(valueOf4).into(this.gif10_13);
        Glide.with(this).asGif().load(valueOf4).into(this.gif10_14);
        Glide.with(this).asGif().load(valueOf4).into(this.gif10_15);
        Glide.with(this).asGif().load(valueOf4).into(this.gif10_16);
        Glide.with(this).asGif().load(valueOf5).into(this.gif10_17);
        Glide.with(this).asGif().load(valueOf5).into(this.gif10_18);
        Glide.with(this).asGif().load(valueOf5).into(this.gif10_19);
        Glide.with(this).asGif().load(valueOf5).into(this.gif10_20);
        Glide.with(this).asGif().load(valueOf).into(this.gif4_1);
        Glide.with(this).asGif().load(valueOf).into(this.gif4_2);
        Glide.with(this).asGif().load(valueOf).into(this.gif4_3);
        Glide.with(this).asGif().load(valueOf).into(this.gif4_4);
        Glide.with(this).asGif().load(valueOf2).into(this.gif4_5);
        Glide.with(this).asGif().load(valueOf2).into(this.gif4_6);
        Glide.with(this).asGif().load(valueOf2).into(this.gif4_7);
        Glide.with(this).asGif().load(valueOf2).into(this.gif4_8);
        Glide.with(this).asGif().load(valueOf3).into(this.gif4_9);
        Glide.with(this).asGif().load(valueOf3).into(this.gif4_10);
        Glide.with(this).asGif().load(valueOf3).into(this.gif4_11);
        Glide.with(this).asGif().load(valueOf3).into(this.gif4_12);
        Glide.with(this).asGif().load(valueOf4).into(this.gif4_13);
        Glide.with(this).asGif().load(valueOf4).into(this.gif4_14);
        Glide.with(this).asGif().load(valueOf4).into(this.gif4_15);
        Glide.with(this).asGif().load(valueOf4).into(this.gif4_16);
        Glide.with(this).asGif().load(valueOf5).into(this.gif4_17);
        Glide.with(this).asGif().load(valueOf5).into(this.gif4_18);
        Glide.with(this).asGif().load(valueOf5).into(this.gif4_19);
        Glide.with(this).asGif().load(valueOf5).into(this.gif4_20);
        MND_Help.setSize(this.l_f1_loop1, 219, 217, true);
        MND_Help.setSize(this.l_f1_loop2, 219, 217, true);
        MND_Help.setSize(this.l_f1_loop3, 219, 217, true);
        MND_Help.setSize(this.l_f1_loop4, 219, 217, true);
        MND_Help.setSize(this.l_f1_loop5, 219, 217, true);
        MND_Help.setSize(this.l_f1_loop6, 219, 217, true);
        MND_Help.setSize(this.l_f1_loop7, 219, 217, true);
        MND_Help.setSize(this.l_f1_loop8, 219, 217, true);
        MND_Help.setSize(this.l_f1_loop9, 219, 217, true);
        MND_Help.setSize(this.l_f1_loop10, 219, 217, true);
        MND_Help.setSize(this.l_f1_loop11, 219, 217, true);
        MND_Help.setSize(this.l_f1_loop12, 219, 217, true);
        MND_Help.setSize(this.l_f1_loop13, 219, 217, true);
        MND_Help.setSize(this.l_f1_loop14, 219, 217, true);
        MND_Help.setSize(this.l_f1_loop15, 219, 217, true);
        MND_Help.setSize(this.l_f1_loop16, 219, 217, true);
        MND_Help.setSize(this.l_f1_loop17, 219, 217, true);
        MND_Help.setSize(this.l_f1_loop18, 219, 217, true);
        MND_Help.setSize(this.l_f1_loop19, 219, 217, true);
        MND_Help.setSize(this.l_f1_loop20, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop1, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop2, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop3, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop4, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop5, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop6, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop7, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop8, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop9, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop10, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop11, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop12, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop13, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop14, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop15, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop16, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop17, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop18, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop19, 219, 217, true);
        MND_Help.setSize(this.l_f2_loop20, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop1, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop2, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop3, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop4, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop5, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop6, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop7, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop8, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop9, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop10, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop11, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop12, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop13, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop14, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop15, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop16, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop17, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop18, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop19, 219, 217, true);
        MND_Help.setSize(this.l_f3_loop20, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop1, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop2, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop3, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop4, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop5, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop6, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop7, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop8, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop9, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop10, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop11, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop12, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop13, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop14, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop15, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop16, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop17, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop18, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop19, 219, 217, true);
        MND_Help.setSize(this.l_f4_loop20, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop1, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop2, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop3, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop4, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop5, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop6, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop7, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop8, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop9, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop10, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop11, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop12, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop13, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop14, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop15, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop16, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop17, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop18, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop19, 219, 217, true);
        MND_Help.setSize(this.l_f5_loop20, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop1, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop2, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop3, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop4, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop5, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop6, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop7, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop8, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop9, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop10, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop11, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop12, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop13, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop14, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop15, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop16, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop17, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop18, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop19, 219, 217, true);
        MND_Help.setSize(this.l_f6_loop20, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop1, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop2, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop3, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop4, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop5, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop6, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop7, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop8, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop9, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop10, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop11, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop12, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop13, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop14, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop15, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop16, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop17, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop18, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop19, 219, 217, true);
        MND_Help.setSize(this.l_f7_loop20, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop1, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop2, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop3, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop4, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop5, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop6, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop7, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop8, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop9, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop10, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop11, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop12, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop13, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop14, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop15, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop16, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop17, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop18, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop19, 219, 217, true);
        MND_Help.setSize(this.l_f8_loop20, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop1, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop2, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop3, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop4, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop5, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop6, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop7, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop8, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop9, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop10, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop11, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop12, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop13, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop14, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop15, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop16, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop17, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop18, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop19, 219, 217, true);
        MND_Help.setSize(this.l_f9_loop20, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop1, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop2, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop3, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop4, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop5, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop6, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop7, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop8, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop9, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop10, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop11, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop12, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop13, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop14, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop15, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop16, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop17, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop18, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop19, 219, 217, true);
        MND_Help.setSize(this.l_f10_loop20, 219, 217, true);
    }

    public void updateVolumeMedia1(float f) {
        MediaPlayer mediaPlayer = this.mediaPlayer1;
        if (mediaPlayer != null) {
            mediaPlayer.setVolume(f, f);
        }
    }

    public void updateVolumeMedia2(float f) {
        MediaPlayer mediaPlayer = this.mediaPlayer5;
        if (mediaPlayer != null) {
            mediaPlayer.setVolume(f, f);
        }
    }

    public void updateVolumeMedia3(float f) {
        MediaPlayer mediaPlayer = this.mediaPlayer9;
        if (mediaPlayer != null) {
            mediaPlayer.setVolume(f, f);
        }
    }

    public void updateVolumeMedia4(float f) {
        MediaPlayer mediaPlayer = this.mediaPlayer13;
        if (mediaPlayer != null) {
            mediaPlayer.setVolume(f, f);
        }
    }

    public void updateVolumeMedia5(float f) {
        MediaPlayer mediaPlayer = this.mediaPlayer17;
        if (mediaPlayer != null) {
            mediaPlayer.setVolume(f, f);
        }
    }
}
