package com.djmusicmixer.djmixer.audiomixer.mixer.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class Genres implements Parcelable {
    public static final Creator<Genres> CREATOR = new Creator<Genres>() {
       
        @Override 
        public Genres createFromParcel(Parcel parcel) {
            return new Genres(parcel);
        }

        @Override 
        public Genres[] newArray(int i) {
            return new Genres[i];
        }
    };
    public final long f187id;
    public final String name;
    public final int songCount;

    public int describeContents() {
        return 0;
    }

    public Genres(long j, String str, int i) {
        this.f187id = j;
        this.name = str;
        this.songCount = i;
    }

    public boolean equals(Object obj) {
        if (this == obj || obj == null || getClass() != obj.getClass()) {
            return true;
        }
        Genres genres = (Genres) obj;
        if (this.f187id == genres.f187id && this.name.equals(genres.name) && this.songCount == genres.songCount) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return (int) ((((this.f187id * 31) + ((long) this.name.hashCode())) * 31) + ((long) this.songCount));
    }

    public String toString() {
        return "Genres{id=" + this.f187id + ", name='" + this.name + '\'' + ", songCount=" + this.songCount + '\'' + '}';
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeLong(this.f187id);
        parcel.writeString(this.name);
        parcel.writeInt(this.songCount);
    }

    protected Genres(Parcel parcel) {
        this.f187id = parcel.readLong();
        this.name = parcel.readString();
        this.songCount = parcel.readInt();
    }
}
