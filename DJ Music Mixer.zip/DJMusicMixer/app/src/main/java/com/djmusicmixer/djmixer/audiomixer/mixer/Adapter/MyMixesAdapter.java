package com.djmusicmixer.djmixer.audiomixer.mixer.Adapter;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaMetadataRetriever;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.mixer.MyMixesActivity;
import com.djmusicmixer.djmixer.audiomixer.mixer.Utils.MusicUtil;

import java.io.File;
import java.util.ArrayList;

public class MyMixesAdapter extends RecyclerView.Adapter<MyMixesAdapter.Viewholder> {
    public Activity activity;
    public ArrayList<String> arrayList;
    public OnItemClickListener onItemClickListener;
    public int selectedMixes = -1;

    public interface OnItemClickListener {
        void onClick(int i);
    }

    public MyMixesAdapter(Activity activity2, ArrayList<String> arrayList2) {
        this.activity = activity2;
        this.arrayList = arrayList2;
    }

    @Override 
    public Viewholder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Viewholder(LayoutInflater.from(this.activity).inflate(R.layout.my_mixes_list_rkappzia_item, viewGroup, false));
    }

    public void onBindViewHolder(Viewholder viewholder, final int i) {
        final String str = this.arrayList.get(i);
        final String substring = str.substring(str.lastIndexOf("/") + 1);
        viewholder.tv_mixes_name.setText(substring);
        MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
        try {
            mediaMetadataRetriever.setDataSource(this.arrayList.get(i));
            String extractMetadata = mediaMetadataRetriever.extractMetadata(9);
            if (extractMetadata != null) {
                viewholder.tv_mixes_duration.setText(MusicUtil.getReadableDuration(Long.parseLong(extractMetadata)));
            }
            mediaMetadataRetriever.release();
        } catch (Exception unused) {
        }
        viewholder.iv_edit_mixes_name.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                final Dialog dialog = new Dialog(MyMixesAdapter.this.activity, R.style.DialogTheme2);
                dialog.requestWindowFeature(1);
                dialog.setContentView(R.layout.enter_name_dialog);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                dialog.setCancelable(false);
                dialog.setCanceledOnTouchOutside(false);
                final EditText editText = (EditText) dialog.findViewById(R.id.et_name);
                editText.setText(substring.replace(".mp3", ""));
                editText.setSelection(substring.replace(".mp3", "").length());
                ((TextView) dialog.findViewById(R.id.tv_save_rkappzia)).setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        File file = new File(str);
                        String str = substring;
                        file.renameTo(new File(str.replace(str, editText.getText().toString() + ".mp3")));
                        CharSequence charSequence = substring;
                        String replace = str.replace(charSequence, editText.getText().toString() + ".mp3");
                        ArrayList arrayList = null;
                        arrayList.set(0, replace);
                        Toast.makeText(MyMixesAdapter.this.activity, "Renamed Successfully", Toast.LENGTH_LONG).show();
                        MyMixesAdapter.this.notifyDataSetChanged();
                        dialog.dismiss();
                    }
                });
                ((TextView) dialog.findViewById(R.id.tv_cancel_rkappzia)).setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        });
        viewholder.iv_play_pause_mixes.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                int i = MyMixesAdapter.this.selectedMixes;
                int i2 = i;
                if (i == i2) {
                    MyMixesAdapter.this.selectedMixes = -1;
                    MyMixesAdapter.this.notifyDataSetChanged();
                    ((MyMixesActivity) MyMixesAdapter.this.activity).pauseMixes();
                    return;
                }
                MyMixesAdapter.this.selectedMixes = i2;
                MyMixesAdapter.this.notifyDataSetChanged();
                ((MyMixesActivity) MyMixesAdapter.this.activity).playMixes(MyMixesAdapter.this.arrayList.get(i));
            }
        });
        if (this.selectedMixes == i) {
            viewholder.iv_play_pause_mixes.setImageResource(R.drawable.ic_playerpause);
        } else {
            viewholder.iv_play_pause_mixes.setImageResource(R.drawable.ic_play1);
        }
    }

    @Override 
    public int getItemCount() {
        return this.arrayList.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {
        public ImageView iv_edit_mixes_name;
        public ImageView iv_play_pause_mixes;
        public TextView tv_mixes_duration;
        public TextView tv_mixes_name;

        Viewholder(View view) {
            super(view);
            this.tv_mixes_name = (TextView) view.findViewById(R.id.tv_mixes_name);
            this.tv_mixes_duration = (TextView) view.findViewById(R.id.tv_mixes_duration);
            this.iv_edit_mixes_name = (ImageView) view.findViewById(R.id.iv_edit_mixes_name);
            this.iv_play_pause_mixes = (ImageView) view.findViewById(R.id.iv_play_pause_mixes);
        }
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener2) {
        this.onItemClickListener = onItemClickListener2;
    }
}
