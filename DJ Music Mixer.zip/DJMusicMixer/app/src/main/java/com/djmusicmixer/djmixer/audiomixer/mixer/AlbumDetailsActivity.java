package com.djmusicmixer.djmixer.audiomixer.mixer;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;
import com.djmusicmixer.djmixer.audiomixer.mixer.Fragment.LibSongsAdapter;
import com.djmusicmixer.djmixer.audiomixer.mixer.Loader.AlbumLoader;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Album;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Songs;
import com.djmusicmixer.djmixer.audiomixer.mixer.Utils.MusicUtil;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.util.ArrayList;
import java.util.Map;

public class AlbumDetailsActivity extends BaseActivity {
    public static Activity activity;
    private Album album;
    AlertDialog alertDialog;
    boolean checkPer = false;
    private ActivityResultLauncher<String[]> permissionsResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
        public void onActivityResult(Map<String, Boolean> map) {
            if (Build.VERSION.SDK_INT < 24) {
                AlbumDetailsActivity.this.run();
            } else if (map.values().stream().allMatch(Boolean::booleanValue)) {
                AlbumDetailsActivity.this.run();
            } else {
                AlbumDetailsActivity.this.dialogPermission();
            }
        }
    });
    private String readMediaPermission = "android.permission.READ_MEDIA_VIDEO";
    private String readMediaPermission2 = "android.permission.READ_MEDIA_IMAGES";
    private String readMediaPermission3 = "android.permission.READ_MEDIA_AUDIO";
    private String readMediaPermission4 = "android.permission.RECORD_AUDIO";
    private RecyclerView recyclerView;
    protected LibSongsAdapter songsAdapter;
    protected ArrayList<Songs> songsList = new ArrayList<>();
    private String storagePermission = "android.permission.READ_EXTERNAL_STORAGE";
    private TextView tv_empty;
    protected TextView tv_title;


    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        
        super.onCreate(bundle);
        setContentView(R.layout.activity_rkappzia_music_details);
        init();
        if (Build.VERSION.SDK_INT >= 33) {
            if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_VIDEO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_IMAGES") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_AUDIO") == 0) {
                run();
            } else {
                requestStorage();
            }
        } else if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0) {
            run();
        } else {
            requestStorage();
        }
    }

    private void requestStorage() {
        if (Build.VERSION.SDK_INT >= 33) {
            this.permissionsResult.launch(new String[]{this.readMediaPermission, this.readMediaPermission2, this.readMediaPermission3, this.readMediaPermission4});
            return;
        }
        this.permissionsResult.launch(new String[]{this.storagePermission, this.readMediaPermission4});
    }

    private void dialogPermission() {
        this.alertDialog.setTitle(getString(R.string.Grant_Permission));
        this.alertDialog.setCancelable(false);
        this.alertDialog.setMessage(getString(R.string.Please_grant_all_permissions));
        this.alertDialog.setButton(-1, getString(R.string.Go_to_setting), new DialogInterface.OnClickListener() {
            public final void onClick(DialogInterface dialogInterface, int i) {
                checkPer = true;
                alertDialog.dismiss();
                Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
                intent.setData(Uri.fromParts("package", getApplicationContext().getPackageName(), null));
                startActivity(intent);
                alertDialog.dismiss();
            }
        });
        this.alertDialog.show();
    }
    
    @Override 
    public void onResume() {
        super.onResume();
        if (this.checkPer) {
            this.checkPer = false;
            if (Build.VERSION.SDK_INT >= 33) {
                if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_VIDEO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_IMAGES") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_AUDIO") == 0) {
                    run();
                } else {
                    dialogPermission();
                }
            } else if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0) {
                run();
            } else {
                dialogPermission();
            }
        }
    }

    private void init() {
        this.tv_title = (TextView) findViewById(R.id.tv_title_rkappzia);
        this.recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        this.tv_empty = (TextView) findViewById(R.id.tv_empty);
        Album album2 = AlbumLoader.getAlbum(this, getIntent().getLongExtra("albumId", 0));
        this.album = album2;
        this.tv_title.setText(album2.getTitle());
        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(AlbumDetailsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        AlbumDetailsActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);

            }
        });
    }

    private void run() {
        ArrayList<Songs> arrayList = this.album.songs;
        this.songsList = arrayList;
        if (arrayList != null) {
            this.tv_empty.setVisibility(arrayList.size() > 0 ? View.GONE : View.VISIBLE);
            if (this.songsList.size() > 0) {
                this.recyclerView.setHasFixedSize(true);
                this.recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
                LibSongsAdapter libSongsAdapter = new LibSongsAdapter(this, this.songsList, "album");
                this.songsAdapter = libSongsAdapter;
                this.recyclerView.setAdapter(libSongsAdapter);
            }
        }
    }

    public void onAlbumSongsClick(final int i, View view, String str, boolean z) {
        if (str.equals("more")) {
            PopupMenu popupMenu = new PopupMenu(new ContextThemeWrapper(this, (int) R.style.PopupDialogTheme), view);
            popupMenu.getMenuInflater().inflate(R.menu.menu_music_item_more_rk, popupMenu.getMenu());
            popupMenu.show();
            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                public boolean onMenuItemClick(MenuItem menuItem) {
                    if (menuItem.getItemId() != R.id.add_to_playlist) {
                        return true;
                    }
                    AlbumDetailsActivity albumDetailsActivity = AlbumDetailsActivity.this;
                    BaseActivity.addToPlaylistDialog(albumDetailsActivity, albumDetailsActivity.songsList.get(i));
                    return true;
                }
            });
            return;
        }
        Uri albumCoverUri = MusicUtil.getAlbumCoverUri(this.songsList.get(i).albumId);
        Intent intent = new Intent();
        intent.putExtra("selected_music_path", this.songsList.get(i).data);
        intent.putExtra("selected_music_name", this.songsList.get(i).title);
        intent.putExtra("selected_music_album", albumCoverUri.toString());
        setResult(-1, intent);
        finish();
    }
}
