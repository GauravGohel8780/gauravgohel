package com.djmusicmixer.djmixer.audiomixer.custom_view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.core.view.ViewCompat;

import com.djmusicmixer.djmixer.audiomixer.R;

import java.lang.reflect.Array;
import java.util.Random;

public class VuMeterView extends View {
    private int mBlockNumber;
    private int mBlockPass;
    private float mBlockSpacing;
    private float[][] mBlockValues;
    private int mBlockWidth;
    private int mColor;
    private int mContentHeight;
    private int mContentWidth;
    private Dynamics[] mDestinationValues;
    private int mDrawPass;
    private int mLeft;
    private int mPaddingBottom;
    private int mPaddingLeft;
    private int mPaddingRight;
    private int mPaddingTop;
    private Paint mPaint = new Paint();
    private Random mRandom = new Random();
    private int mRight;
    private int mSpeed;
    private int mState;
    private float mStopSize;
    private int mTop;

        int[] vumeter_VuMeterView = {R.attr.vumeter_backgroundColor, R.attr.vumeter_blockNumber, R.attr.vumeter_blockSpacing, R.attr.vumeter_speed, R.attr.vumeter_startOff, R.attr.vumeter_stopSize};

    public VuMeterView(Context context) {
        super(context);
        init(null, 0);
    }

    public VuMeterView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(attributeSet, 0);
    }

    public VuMeterView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(attributeSet, i);
    }

    @SuppressLint("ResourceType")
    private void init(AttributeSet attributeSet, int i) {
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, vumeter_VuMeterView, i, 0);
        this.mColor = obtainStyledAttributes.getColor(0, ViewCompat.MEASURED_STATE_MASK);
        this.mBlockNumber = obtainStyledAttributes.getInt(1, 3);
        this.mBlockSpacing = obtainStyledAttributes.getDimension(2, 20.0f);
        this.mSpeed = obtainStyledAttributes.getInt(3, 10);
        this.mStopSize = obtainStyledAttributes.getDimension(5, 30.0f);
        boolean z = obtainStyledAttributes.getBoolean(4, false);
        obtainStyledAttributes.recycle();
        initialiseCollections();
        this.mPaint.setColor(this.mColor);
        if (z) {
            this.mState = 0;
        } else {
            this.mState = 2;
        }
        this.mRight = 0;
        this.mPaddingBottom = 0;
        this.mPaddingRight = 0;
        this.mTop = 0;
        this.mLeft = 0;
        this.mPaddingTop = 0;
        this.mPaddingLeft = 0;
        this.mContentWidth = 0;
        this.mContentHeight = 0;
        this.mBlockPass = 0;
        this.mDrawPass = 0;
    }

    
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.mPaddingLeft = getPaddingLeft();
        this.mPaddingTop = getPaddingTop();
        this.mPaddingRight = getPaddingRight();
        this.mPaddingBottom = getPaddingBottom();
        this.mContentWidth = (getWidth() - this.mPaddingLeft) - this.mPaddingRight;
        int height = (getHeight() - this.mPaddingTop) - this.mPaddingBottom;
        this.mContentHeight = height;
        if (this.mBlockWidth == 0) {
            int i = this.mBlockNumber;
            this.mBlockWidth = (int) ((((float) this.mContentWidth) - (((float) (i - 1)) * this.mBlockSpacing)) / ((float) i));
            if (this.mState == 0) {
                int i2 = (int) (((float) height) - this.mStopSize);
                for (int i3 = 0; i3 < this.mBlockNumber; i3++) {
                    this.mDestinationValues[i3] = new Dynamics(this.mSpeed, (float) i2);
                    this.mDestinationValues[i3].setAtRest(true);
                }
            }
        }
        this.mBlockPass = 0;
        while (true) {
            int i4 = this.mBlockPass;
            if (i4 < this.mBlockNumber) {
                int i5 = this.mPaddingLeft;
                int i6 = this.mBlockWidth;
                int i7 = i5 + (i4 * i6);
                this.mLeft = i7;
                int i8 = (int) (((float) i7) + (this.mBlockSpacing * ((float) i4)));
                this.mLeft = i8;
                this.mRight = i8 + i6;
                if (this.mDestinationValues[i4] == null) {
                    int i9 = this.mContentHeight;
                    pickNewDynamics(i9, ((float) i9) * this.mBlockValues[i4][this.mDrawPass]);
                }
                if (this.mDestinationValues[this.mBlockPass].isAtRest() && this.mState == 2) {
                    int i10 = this.mBlockPass;
                    changeDynamicsTarget(i10, ((float) this.mContentHeight) * this.mBlockValues[i10][this.mDrawPass]);
                } else if (this.mState != 0) {
                    this.mDestinationValues[this.mBlockPass].update();
                }
                int position = this.mPaddingTop + ((int) this.mDestinationValues[this.mBlockPass].getPosition());
                this.mTop = position;
                canvas.drawRect((float) this.mLeft, (float) position, (float) this.mRight, (float) this.mContentHeight, this.mPaint);
                this.mBlockPass++;
            } else {
                postInvalidateDelayed(16);
                return;
            }
        }
    }

    private void updateRandomValues() {
        for (int i = 0; i < this.mBlockNumber; i++) {
            for (int i2 = 0; i2 < 10; i2++) {
                this.mBlockValues[i][i2] = this.mRandom.nextFloat();
                float[][] fArr = this.mBlockValues;
                if (((double) fArr[i][i2]) < 0.1d) {
                    fArr[i][i2] = 0.1f;
                }
            }
        }
    }

    private void pickNewDynamics(int i, float f) {
        this.mDestinationValues[this.mBlockPass] = new Dynamics(this.mSpeed, f);
        incrementAndGetDrawPass();
        Dynamics[] dynamicsArr = this.mDestinationValues;
        int i2 = this.mBlockPass;
        dynamicsArr[i2].setTargetPosition(((float) i) * this.mBlockValues[i2][this.mDrawPass]);
    }

    private void changeDynamicsTarget(int i, float f) {
        incrementAndGetDrawPass();
        this.mDestinationValues[i].setTargetPosition(f);
    }

    private int incrementAndGetDrawPass() {
        int i = this.mDrawPass + 1;
        this.mDrawPass = i;
        if (i >= 10) {
            this.mDrawPass = 0;
        }
        return this.mDrawPass;
    }

    private void initialiseCollections() {
        int i = this.mBlockNumber;
        int[] iArr = new int[2];
        iArr[1] = 10;
        iArr[0] = i;
        this.mBlockValues = (float[][]) Array.newInstance(float.class, iArr);
        this.mDestinationValues = new Dynamics[this.mBlockNumber];
        updateRandomValues();
    }

    public int getColor() {
        return this.mColor;
    }

    public void setColor(int i) {
        this.mColor = i;
        this.mPaint.setColor(i);
    }

   

    public void pause() {
        this.mState = 0;
    }

    public void stop(boolean z) {
        if (this.mDestinationValues == null) {
            initialiseCollections();
        }
        this.mState = 1;
        int i = (int) (((float) this.mContentHeight) - this.mStopSize);
        if (this.mDestinationValues.length > 0) {
            for (int i2 = 0; i2 < this.mBlockNumber; i2++) {
                Dynamics[] dynamicsArr = this.mDestinationValues;
                if (dynamicsArr[i2] != null) {
                    if (z) {
                        dynamicsArr[i2].setTargetPosition((float) i);
                    } else {
                        dynamicsArr[i2].setPosition((float) i);
                    }
                }
            }
        }
    }

    public void resume(boolean z) {
        if (this.mState == 0) {
            this.mState = 2;
            return;
        }
        this.mState = 2;
        if (!z) {
            for (int i = 0; i < this.mBlockNumber; i++) {
                this.mDestinationValues[i].setPosition(((float) this.mContentHeight) * this.mBlockValues[i][this.mDrawPass]);
                changeDynamicsTarget(i, ((float) this.mContentHeight) * this.mBlockValues[i][this.mDrawPass]);
            }
        }
    }
}
