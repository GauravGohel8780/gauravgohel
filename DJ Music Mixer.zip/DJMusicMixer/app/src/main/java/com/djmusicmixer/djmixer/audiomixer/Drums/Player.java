package com.djmusicmixer.djmixer.audiomixer.Drums;

import android.os.Handler;
import android.os.Message;

import java.util.List;

public class Player {
    private Drum[] drums;
    private Handler handler = new Handler() {
        public void handleMessage(Message message) {
            Player.this.playCurrent();
        }
    };
    private boolean isPlaying = false;
    int playCounter = 0;
    private List<SampleSlot> sample;
    private SoundBoard soundPlayer;
    private StateListener stateListener;

    public interface StateListener {
        void onStarted();

        void onStopped();
    }

    public boolean isPlaying() {
        return this.isPlaying;
    }

    public void setStateListener(StateListener stateListener2) {
        this.stateListener = stateListener2;
    }

    public void setSample(List<SampleSlot> list) {
        this.sample = list;
    }

    public void setSoundPlayer(SoundBoard cNX_SoundBoard) {
        this.soundPlayer = cNX_SoundBoard;
    }

    public void setDrums(Drum[] cNX_DrumArr) {
        this.drums = cNX_DrumArr;
    }

    public boolean isReady() {
        List<SampleSlot> list = this.sample;
        return list != null && list.size() > 0;
    }

    public void playCurrent() {
        SampleSlot cNX_SampleSlot;
        try {
            cNX_SampleSlot = this.sample.get(this.playCounter);
        } catch (Exception e) {
            e.printStackTrace();
            cNX_SampleSlot = null;
        }
        try {
            this.soundPlayer.stop(this.drums[cNX_SampleSlot.drumId].streamId);
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        try {
            this.drums[cNX_SampleSlot.drumId].streamId = this.soundPlayer.playSound(this.drums[cNX_SampleSlot.drumId].getSoundId(cNX_SampleSlot.soundIndex));
        } catch (Exception e3) {
            e3.printStackTrace();
        }
        if (cNX_SampleSlot.playNextAfterMs == -1) {
            stop();
            return;
        }
        this.handler.sendEmptyMessageDelayed(0, cNX_SampleSlot.playNextAfterMs);
        this.playCounter++;
    }

    public void play() {
        StateListener stateListener2;
        this.playCounter = 0;
        this.isPlaying = true;
        try {
            stateListener2 = this.stateListener;
        } catch (Exception e) {
            e.printStackTrace();
            stateListener2 = null;
        }
        if (stateListener2 != null) {
            stateListener2.onStarted();
        }
        playCurrent();
    }

    public void stop() {
        this.handler.removeMessages(0);
        this.playCounter = 0;
        this.isPlaying = false;
        StateListener stateListener2 = this.stateListener;
        if (stateListener2 != null) {
            stateListener2.onStopped();
        }
    }
}
