package com.djmusicmixer.djmixer.audiomixer.loop;

import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.view.ViewCompat;
import androidx.fragment.app.Fragment;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.loop.MyCustom.MyUtil;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MND_LoopFragment extends Fragment {
    String audioFile;
    int blinkNo1 = 0;
    int blinkNo10 = 0;
    int blinkNo11 = 0;
    int blinkNo12 = 0;
    int blinkNo13 = 0;
    int blinkNo14 = 0;
    int blinkNo15 = 0;
    int blinkNo16 = 0;
    int blinkNo17 = 0;
    int blinkNo18 = 0;
    int blinkNo19 = 0;
    int blinkNo2 = 0;
    int blinkNo20 = 0;
    int blinkNo3 = 0;
    int blinkNo4 = 0;
    int blinkNo5 = 0;
    int blinkNo6 = 0;
    int blinkNo7 = 0;
    int blinkNo8 = 0;
    int blinkNo9 = 0;
    int checkSection1 = 0;
    int checkSection2 = 0;
    int checkSection3 = 0;
    int checkSection4 = 0;
    int checkSection5 = 0;
    ImageView gif10_1;
    ImageView gif10_10;
    ImageView gif10_11;
    ImageView gif10_12;
    ImageView gif10_13;
    ImageView gif10_14;
    ImageView gif10_15;
    ImageView gif10_16;
    ImageView gif10_17;
    ImageView gif10_18;
    ImageView gif10_19;
    ImageView gif10_2;
    ImageView gif10_20;
    ImageView gif10_3;
    ImageView gif10_4;
    ImageView gif10_5;
    ImageView gif10_6;
    ImageView gif10_7;
    ImageView gif10_8;
    ImageView gif10_9;
    ImageView gif1_1;
    ImageView gif1_10;
    ImageView gif1_11;
    ImageView gif1_12;
    ImageView gif1_13;
    ImageView gif1_14;
    ImageView gif1_15;
    ImageView gif1_16;
    ImageView gif1_17;
    ImageView gif1_18;
    ImageView gif1_19;
    ImageView gif1_2;
    ImageView gif1_20;
    ImageView gif1_3;
    ImageView gif1_4;
    ImageView gif1_5;
    ImageView gif1_6;
    ImageView gif1_7;
    ImageView gif1_8;
    ImageView gif1_9;
    ImageView gif2_1;
    ImageView gif2_10;
    ImageView gif2_11;
    ImageView gif2_12;
    ImageView gif2_13;
    ImageView gif2_14;
    ImageView gif2_15;
    ImageView gif2_16;
    ImageView gif2_17;
    ImageView gif2_18;
    ImageView gif2_19;
    ImageView gif2_2;
    ImageView gif2_20;
    ImageView gif2_3;
    ImageView gif2_4;
    ImageView gif2_5;
    ImageView gif2_6;
    ImageView gif2_7;
    ImageView gif2_8;
    ImageView gif2_9;
    ImageView gif3_1;
    ImageView gif3_10;
    ImageView gif3_11;
    ImageView gif3_12;
    ImageView gif3_13;
    ImageView gif3_14;
    ImageView gif3_15;
    ImageView gif3_16;
    ImageView gif3_17;
    ImageView gif3_18;
    ImageView gif3_19;
    ImageView gif3_2;
    ImageView gif3_20;
    ImageView gif3_3;
    ImageView gif3_4;
    ImageView gif3_5;
    ImageView gif3_6;
    ImageView gif3_7;
    ImageView gif3_8;
    ImageView gif3_9;
    ImageView gif4_1;
    ImageView gif4_10;
    ImageView gif4_11;
    ImageView gif4_12;
    ImageView gif4_13;
    ImageView gif4_14;
    ImageView gif4_15;
    ImageView gif4_16;
    ImageView gif4_17;
    ImageView gif4_18;
    ImageView gif4_19;
    ImageView gif4_2;
    ImageView gif4_20;
    ImageView gif4_3;
    ImageView gif4_4;
    ImageView gif4_5;
    ImageView gif4_6;
    ImageView gif4_7;
    ImageView gif4_8;
    ImageView gif4_9;
    ImageView gif5_1;
    ImageView gif5_10;
    ImageView gif5_11;
    ImageView gif5_12;
    ImageView gif5_13;
    ImageView gif5_14;
    ImageView gif5_15;
    ImageView gif5_16;
    ImageView gif5_17;
    ImageView gif5_18;
    ImageView gif5_19;
    ImageView gif5_2;
    ImageView gif5_20;
    ImageView gif5_3;
    ImageView gif5_4;
    ImageView gif5_5;
    ImageView gif5_6;
    ImageView gif5_7;
    ImageView gif5_8;
    ImageView gif5_9;
    ImageView gif6_1;
    ImageView gif6_10;
    ImageView gif6_11;
    ImageView gif6_12;
    ImageView gif6_13;
    ImageView gif6_14;
    ImageView gif6_15;
    ImageView gif6_16;
    ImageView gif6_17;
    ImageView gif6_18;
    ImageView gif6_19;
    ImageView gif6_2;
    ImageView gif6_20;
    ImageView gif6_3;
    ImageView gif6_4;
    ImageView gif6_5;
    ImageView gif6_6;
    ImageView gif6_7;
    ImageView gif6_8;
    ImageView gif6_9;
    ImageView gif7_1;
    ImageView gif7_10;
    ImageView gif7_11;
    ImageView gif7_12;
    ImageView gif7_13;
    ImageView gif7_14;
    ImageView gif7_15;
    ImageView gif7_16;
    ImageView gif7_17;
    ImageView gif7_18;
    ImageView gif7_19;
    ImageView gif7_2;
    ImageView gif7_20;
    ImageView gif7_3;
    ImageView gif7_4;
    ImageView gif7_5;
    ImageView gif7_6;
    ImageView gif7_7;
    ImageView gif7_8;
    ImageView gif7_9;
    ImageView gif8_1;
    ImageView gif8_10;
    ImageView gif8_11;
    ImageView gif8_12;
    ImageView gif8_13;
    ImageView gif8_14;
    ImageView gif8_15;
    ImageView gif8_16;
    ImageView gif8_17;
    ImageView gif8_18;
    ImageView gif8_19;
    ImageView gif8_2;
    ImageView gif8_20;
    ImageView gif8_3;
    ImageView gif8_4;
    ImageView gif8_5;
    ImageView gif8_6;
    ImageView gif8_7;
    ImageView gif8_8;
    ImageView gif8_9;
    ImageView gif9_1;
    ImageView gif9_10;
    ImageView gif9_11;
    ImageView gif9_12;
    ImageView gif9_13;
    ImageView gif9_14;
    ImageView gif9_15;
    ImageView gif9_16;
    ImageView gif9_17;
    ImageView gif9_18;
    ImageView gif9_19;
    ImageView gif9_2;
    ImageView gif9_20;
    ImageView gif9_3;
    ImageView gif9_4;
    ImageView gif9_5;
    ImageView gif9_6;
    ImageView gif9_7;
    ImageView gif9_8;
    ImageView gif9_9;
    Handler handler1;
    Handler handler10;
    Handler handler11;
    Handler handler12;
    Handler handler13;
    Handler handler14;
    Handler handler15;
    Handler handler16;
    Handler handler17;
    Handler handler18;
    Handler handler19;
    Handler handler2;
    Handler handler20;
    Handler handler3;
    Handler handler4;
    Handler handler5;
    Handler handler6;
    Handler handler7;
    Handler handler8;
    Handler handler9;
    private boolean isRecording = false;
    LinearLayout l_f10_loop1;
    LinearLayout l_f10_loop10;
    LinearLayout l_f10_loop11;
    LinearLayout l_f10_loop12;
    LinearLayout l_f10_loop13;
    LinearLayout l_f10_loop14;
    LinearLayout l_f10_loop15;
    LinearLayout l_f10_loop16;
    LinearLayout l_f10_loop17;
    LinearLayout l_f10_loop18;
    LinearLayout l_f10_loop19;
    LinearLayout l_f10_loop2;
    LinearLayout l_f10_loop20;
    LinearLayout l_f10_loop3;
    LinearLayout l_f10_loop4;
    LinearLayout l_f10_loop5;
    LinearLayout l_f10_loop6;
    LinearLayout l_f10_loop7;
    LinearLayout l_f10_loop8;
    LinearLayout l_f10_loop9;
    LinearLayout l_f1_loop1;
    LinearLayout l_f1_loop10;
    LinearLayout l_f1_loop11;
    LinearLayout l_f1_loop12;
    LinearLayout l_f1_loop13;
    LinearLayout l_f1_loop14;
    LinearLayout l_f1_loop15;
    LinearLayout l_f1_loop16;
    LinearLayout l_f1_loop17;
    LinearLayout l_f1_loop18;
    LinearLayout l_f1_loop19;
    LinearLayout l_f1_loop2;
    LinearLayout l_f1_loop20;
    LinearLayout l_f1_loop3;
    LinearLayout l_f1_loop4;
    LinearLayout l_f1_loop5;
    LinearLayout l_f1_loop6;
    LinearLayout l_f1_loop7;
    LinearLayout l_f1_loop8;
    LinearLayout l_f1_loop9;
    LinearLayout l_f2_loop1;
    LinearLayout l_f2_loop10;
    LinearLayout l_f2_loop11;
    LinearLayout l_f2_loop12;
    LinearLayout l_f2_loop13;
    LinearLayout l_f2_loop14;
    LinearLayout l_f2_loop15;
    LinearLayout l_f2_loop16;
    LinearLayout l_f2_loop17;
    LinearLayout l_f2_loop18;
    LinearLayout l_f2_loop19;
    LinearLayout l_f2_loop2;
    LinearLayout l_f2_loop20;
    LinearLayout l_f2_loop3;
    LinearLayout l_f2_loop4;
    LinearLayout l_f2_loop5;
    LinearLayout l_f2_loop6;
    LinearLayout l_f2_loop7;
    LinearLayout l_f2_loop8;
    LinearLayout l_f2_loop9;
    LinearLayout l_f3_loop1;
    LinearLayout l_f3_loop10;
    LinearLayout l_f3_loop11;
    LinearLayout l_f3_loop12;
    LinearLayout l_f3_loop13;
    LinearLayout l_f3_loop14;
    LinearLayout l_f3_loop15;
    LinearLayout l_f3_loop16;
    LinearLayout l_f3_loop17;
    LinearLayout l_f3_loop18;
    LinearLayout l_f3_loop19;
    LinearLayout l_f3_loop2;
    LinearLayout l_f3_loop20;
    LinearLayout l_f3_loop3;
    LinearLayout l_f3_loop4;
    LinearLayout l_f3_loop5;
    LinearLayout l_f3_loop6;
    LinearLayout l_f3_loop7;
    LinearLayout l_f3_loop8;
    LinearLayout l_f3_loop9;
    LinearLayout l_f4_loop1;
    LinearLayout l_f4_loop10;
    LinearLayout l_f4_loop11;
    LinearLayout l_f4_loop12;
    LinearLayout l_f4_loop13;
    LinearLayout l_f4_loop14;
    LinearLayout l_f4_loop15;
    LinearLayout l_f4_loop16;
    LinearLayout l_f4_loop17;
    LinearLayout l_f4_loop18;
    LinearLayout l_f4_loop19;
    LinearLayout l_f4_loop2;
    LinearLayout l_f4_loop20;
    LinearLayout l_f4_loop3;
    LinearLayout l_f4_loop4;
    LinearLayout l_f4_loop5;
    LinearLayout l_f4_loop6;
    LinearLayout l_f4_loop7;
    LinearLayout l_f4_loop8;
    LinearLayout l_f4_loop9;
    LinearLayout l_f5_loop1;
    LinearLayout l_f5_loop10;
    LinearLayout l_f5_loop11;
    LinearLayout l_f5_loop12;
    LinearLayout l_f5_loop13;
    LinearLayout l_f5_loop14;
    LinearLayout l_f5_loop15;
    LinearLayout l_f5_loop16;
    LinearLayout l_f5_loop17;
    LinearLayout l_f5_loop18;
    LinearLayout l_f5_loop19;
    LinearLayout l_f5_loop2;
    LinearLayout l_f5_loop20;
    LinearLayout l_f5_loop3;
    LinearLayout l_f5_loop4;
    LinearLayout l_f5_loop5;
    LinearLayout l_f5_loop6;
    LinearLayout l_f5_loop7;
    LinearLayout l_f5_loop8;
    LinearLayout l_f5_loop9;
    LinearLayout l_f6_loop1;
    LinearLayout l_f6_loop10;
    LinearLayout l_f6_loop11;
    LinearLayout l_f6_loop12;
    LinearLayout l_f6_loop13;
    LinearLayout l_f6_loop14;
    LinearLayout l_f6_loop15;
    LinearLayout l_f6_loop16;
    LinearLayout l_f6_loop17;
    LinearLayout l_f6_loop18;
    LinearLayout l_f6_loop19;
    LinearLayout l_f6_loop2;
    LinearLayout l_f6_loop20;
    LinearLayout l_f6_loop3;
    LinearLayout l_f6_loop4;
    LinearLayout l_f6_loop5;
    LinearLayout l_f6_loop6;
    LinearLayout l_f6_loop7;
    LinearLayout l_f6_loop8;
    LinearLayout l_f6_loop9;
    LinearLayout l_f7_loop1;
    LinearLayout l_f7_loop10;
    LinearLayout l_f7_loop11;
    LinearLayout l_f7_loop12;
    LinearLayout l_f7_loop13;
    LinearLayout l_f7_loop14;
    LinearLayout l_f7_loop15;
    LinearLayout l_f7_loop16;
    LinearLayout l_f7_loop17;
    LinearLayout l_f7_loop18;
    LinearLayout l_f7_loop19;
    LinearLayout l_f7_loop2;
    LinearLayout l_f7_loop20;
    LinearLayout l_f7_loop3;
    LinearLayout l_f7_loop4;
    LinearLayout l_f7_loop5;
    LinearLayout l_f7_loop6;
    LinearLayout l_f7_loop7;
    LinearLayout l_f7_loop8;
    LinearLayout l_f7_loop9;
    LinearLayout l_f8_loop1;
    LinearLayout l_f8_loop10;
    LinearLayout l_f8_loop11;
    LinearLayout l_f8_loop12;
    LinearLayout l_f8_loop13;
    LinearLayout l_f8_loop14;
    LinearLayout l_f8_loop15;
    LinearLayout l_f8_loop16;
    LinearLayout l_f8_loop17;
    LinearLayout l_f8_loop18;
    LinearLayout l_f8_loop19;
    LinearLayout l_f8_loop2;
    LinearLayout l_f8_loop20;
    LinearLayout l_f8_loop3;
    LinearLayout l_f8_loop4;
    LinearLayout l_f8_loop5;
    LinearLayout l_f8_loop6;
    LinearLayout l_f8_loop7;
    LinearLayout l_f8_loop8;
    LinearLayout l_f8_loop9;
    LinearLayout l_f9_loop1;
    LinearLayout l_f9_loop10;
    LinearLayout l_f9_loop11;
    LinearLayout l_f9_loop12;
    LinearLayout l_f9_loop13;
    LinearLayout l_f9_loop14;
    LinearLayout l_f9_loop15;
    LinearLayout l_f9_loop16;
    LinearLayout l_f9_loop17;
    LinearLayout l_f9_loop18;
    LinearLayout l_f9_loop19;
    LinearLayout l_f9_loop2;
    LinearLayout l_f9_loop20;
    LinearLayout l_f9_loop3;
    LinearLayout l_f9_loop4;
    LinearLayout l_f9_loop5;
    LinearLayout l_f9_loop6;
    LinearLayout l_f9_loop7;
    LinearLayout l_f9_loop8;
    LinearLayout l_f9_loop9;
    LinearLayout l_feature1;
    LinearLayout l_feature10;
    LinearLayout l_feature2;
    LinearLayout l_feature3;
    LinearLayout l_feature4;
    LinearLayout l_feature5;
    LinearLayout l_feature6;
    LinearLayout l_feature7;
    LinearLayout l_feature8;
    LinearLayout l_feature9;
    MND_LoopPadActivity loopPadActivity;
    MediaPlayer mediaPlayer1;
    MediaPlayer mediaPlayer13;
    MediaPlayer mediaPlayer17;
    MediaPlayer mediaPlayer5;
    MediaPlayer mediaPlayer9;
    MediaRecorder mediaRecorder = new MediaRecorder();
    String outputFile;
    Runnable runnable1;
    Runnable runnable10;
    Runnable runnable11;
    Runnable runnable12;
    Runnable runnable13;
    Runnable runnable14;
    Runnable runnable15;
    Runnable runnable16;
    Runnable runnable17;
    Runnable runnable18;
    Runnable runnable19;
    Runnable runnable2;
    Runnable runnable20;
    Runnable runnable3;
    Runnable runnable4;
    Runnable runnable5;
    Runnable runnable6;
    Runnable runnable7;
    Runnable runnable8;
    Runnable runnable9;
    private TextView tvBeat11;
    private TextView tvBeat110;
    private TextView tvBeat111;
    private TextView tvBeat112;
    private TextView tvBeat113;
    private TextView tvBeat114;
    private TextView tvBeat115;
    private TextView tvBeat116;
    private TextView tvBeat117;
    private TextView tvBeat118;
    private TextView tvBeat119;
    private TextView tvBeat12;
    private TextView tvBeat120;
    private TextView tvBeat13;
    private TextView tvBeat14;
    private TextView tvBeat15;
    private TextView tvBeat16;
    private TextView tvBeat17;
    private TextView tvBeat18;
    private TextView tvBeat19;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_loop, viewGroup, false);
        this.tvBeat11 = (TextView) inflate.findViewById(R.id.tv_Beat1_1);
        this.tvBeat12 = (TextView) inflate.findViewById(R.id.tv_Beat1_2);
        this.tvBeat13 = (TextView) inflate.findViewById(R.id.tv_Beat1_3);
        this.tvBeat14 = (TextView) inflate.findViewById(R.id.tv_Beat1_4);
        this.tvBeat15 = (TextView) inflate.findViewById(R.id.tv_beat1_5);
        this.tvBeat16 = (TextView) inflate.findViewById(R.id.tv_beat1_6);
        this.tvBeat17 = (TextView) inflate.findViewById(R.id.tv_beat1_7);
        this.tvBeat18 = (TextView) inflate.findViewById(R.id.tv_beat1_8);
        this.tvBeat19 = (TextView) inflate.findViewById(R.id.tv_beat1_9);
        this.tvBeat110 = (TextView) inflate.findViewById(R.id.tv_beat1_10);
        this.tvBeat111 = (TextView) inflate.findViewById(R.id.tv_beat1_11);
        this.tvBeat112 = (TextView) inflate.findViewById(R.id.tv_beat1_12);
        this.tvBeat113 = (TextView) inflate.findViewById(R.id.tv_beat1_13);
        this.tvBeat114 = (TextView) inflate.findViewById(R.id.tv_beat1_14);
        this.tvBeat115 = (TextView) inflate.findViewById(R.id.tv_beat1_15);
        this.tvBeat116 = (TextView) inflate.findViewById(R.id.tv_beat1_16);
        this.tvBeat117 = (TextView) inflate.findViewById(R.id.tv_beat1_17);
        this.tvBeat118 = (TextView) inflate.findViewById(R.id.tv_beat1_18);
        this.tvBeat119 = (TextView) inflate.findViewById(R.id.tv_beat1_19);
        this.tvBeat120 = (TextView) inflate.findViewById(R.id.tv_beat1_20);
        this.loopPadActivity = MND_LoopPadActivity.getInstance1();
        this.l_feature1 = (LinearLayout) inflate.findViewById(R.id.l_feature1);
        this.l_feature2 = (LinearLayout) inflate.findViewById(R.id.l_feature2);
        this.l_feature3 = (LinearLayout) inflate.findViewById(R.id.l_feature3);
        this.l_feature4 = (LinearLayout) inflate.findViewById(R.id.l_feature4);
        this.l_feature5 = (LinearLayout) inflate.findViewById(R.id.l_feature5);
        this.l_feature6 = (LinearLayout) inflate.findViewById(R.id.l_feature6);
        this.l_feature7 = (LinearLayout) inflate.findViewById(R.id.l_feature7);
        this.l_feature8 = (LinearLayout) inflate.findViewById(R.id.l_feature8);
        this.l_feature9 = (LinearLayout) inflate.findViewById(R.id.l_feature9);
        this.l_feature10 = (LinearLayout) inflate.findViewById(R.id.l_feature10);
        initLoopBind(inflate);
        this.mediaPlayer1 = new MediaPlayer();
        this.mediaPlayer5 = new MediaPlayer();
        this.mediaPlayer9 = new MediaPlayer();
        this.mediaPlayer13 = new MediaPlayer();
        this.mediaPlayer17 = new MediaPlayer();
        this.l_feature1.setVisibility(View.GONE);
        if (MyUtil.featureNumber == 1) {
            this.l_feature1.setVisibility(View.VISIBLE);
            this.l_feature2.setVisibility(View.INVISIBLE);
            this.l_feature3.setVisibility(View.INVISIBLE);
            this.l_feature4.setVisibility(View.INVISIBLE);
            this.l_feature5.setVisibility(View.INVISIBLE);
            this.l_feature6.setVisibility(View.INVISIBLE);
            this.l_feature7.setVisibility(View.INVISIBLE);
            this.l_feature8.setVisibility(View.INVISIBLE);
            this.l_feature9.setVisibility(View.INVISIBLE);
            this.l_feature10.setVisibility(View.INVISIBLE);
        } else if (MyUtil.featureNumber == 2) {
            this.l_feature2.setVisibility(View.VISIBLE);
            this.l_feature1.setVisibility(View.INVISIBLE);
            this.l_feature3.setVisibility(View.INVISIBLE);
            this.l_feature4.setVisibility(View.INVISIBLE);
            this.l_feature5.setVisibility(View.INVISIBLE);
            this.l_feature6.setVisibility(View.INVISIBLE);
            this.l_feature7.setVisibility(View.INVISIBLE);
            this.l_feature8.setVisibility(View.INVISIBLE);
            this.l_feature9.setVisibility(View.INVISIBLE);
            this.l_feature10.setVisibility(View.INVISIBLE);
        } else if (MyUtil.featureNumber == 3) {
            this.l_feature3.setVisibility(View.VISIBLE);
            this.l_feature2.setVisibility(View.INVISIBLE);
            this.l_feature1.setVisibility(View.INVISIBLE);
            this.l_feature4.setVisibility(View.INVISIBLE);
            this.l_feature5.setVisibility(View.INVISIBLE);
            this.l_feature6.setVisibility(View.INVISIBLE);
            this.l_feature7.setVisibility(View.INVISIBLE);
            this.l_feature8.setVisibility(View.INVISIBLE);
            this.l_feature9.setVisibility(View.INVISIBLE);
            this.l_feature10.setVisibility(View.INVISIBLE);
        } else if (MyUtil.featureNumber == 4) {
            this.l_feature4.setVisibility(View.VISIBLE);
            this.l_feature2.setVisibility(View.INVISIBLE);
            this.l_feature1.setVisibility(View.INVISIBLE);
            this.l_feature3.setVisibility(View.INVISIBLE);
            this.l_feature5.setVisibility(View.INVISIBLE);
            this.l_feature6.setVisibility(View.INVISIBLE);
            this.l_feature7.setVisibility(View.INVISIBLE);
            this.l_feature8.setVisibility(View.INVISIBLE);
            this.l_feature9.setVisibility(View.INVISIBLE);
            this.l_feature10.setVisibility(View.INVISIBLE);
        } else if (MyUtil.featureNumber == 5) {
            this.l_feature5.setVisibility(View.VISIBLE);
            this.l_feature2.setVisibility(View.INVISIBLE);
            this.l_feature1.setVisibility(View.INVISIBLE);
            this.l_feature3.setVisibility(View.INVISIBLE);
            this.l_feature4.setVisibility(View.INVISIBLE);
            this.l_feature6.setVisibility(View.INVISIBLE);
            this.l_feature7.setVisibility(View.INVISIBLE);
            this.l_feature8.setVisibility(View.INVISIBLE);
            this.l_feature9.setVisibility(View.INVISIBLE);
            this.l_feature10.setVisibility(View.INVISIBLE);
        } else if (MyUtil.featureNumber == 6) {
            this.l_feature6.setVisibility(View.VISIBLE);
            this.l_feature2.setVisibility(View.INVISIBLE);
            this.l_feature1.setVisibility(View.INVISIBLE);
            this.l_feature3.setVisibility(View.INVISIBLE);
            this.l_feature4.setVisibility(View.INVISIBLE);
            this.l_feature5.setVisibility(View.INVISIBLE);
            this.l_feature7.setVisibility(View.INVISIBLE);
            this.l_feature8.setVisibility(View.INVISIBLE);
            this.l_feature9.setVisibility(View.INVISIBLE);
            this.l_feature10.setVisibility(View.INVISIBLE);
        } else if (MyUtil.featureNumber == 7) {
            this.l_feature7.setVisibility(View.VISIBLE);
            this.l_feature2.setVisibility(View.INVISIBLE);
            this.l_feature1.setVisibility(View.INVISIBLE);
            this.l_feature3.setVisibility(View.INVISIBLE);
            this.l_feature4.setVisibility(View.INVISIBLE);
            this.l_feature5.setVisibility(View.INVISIBLE);
            this.l_feature6.setVisibility(View.INVISIBLE);
            this.l_feature8.setVisibility(View.INVISIBLE);
            this.l_feature9.setVisibility(View.INVISIBLE);
            this.l_feature10.setVisibility(View.INVISIBLE);
        } else if (MyUtil.featureNumber == 8) {
            this.l_feature8.setVisibility(View.VISIBLE);
            this.l_feature2.setVisibility(View.INVISIBLE);
            this.l_feature1.setVisibility(View.INVISIBLE);
            this.l_feature3.setVisibility(View.INVISIBLE);
            this.l_feature4.setVisibility(View.INVISIBLE);
            this.l_feature5.setVisibility(View.INVISIBLE);
            this.l_feature6.setVisibility(View.INVISIBLE);
            this.l_feature7.setVisibility(View.INVISIBLE);
            this.l_feature9.setVisibility(View.INVISIBLE);
            this.l_feature10.setVisibility(View.INVISIBLE);
        } else if (MyUtil.featureNumber == 9) {
            this.l_feature9.setVisibility(View.VISIBLE);
            this.l_feature2.setVisibility(View.INVISIBLE);
            this.l_feature1.setVisibility(View.INVISIBLE);
            this.l_feature3.setVisibility(View.INVISIBLE);
            this.l_feature4.setVisibility(View.INVISIBLE);
            this.l_feature5.setVisibility(View.INVISIBLE);
            this.l_feature6.setVisibility(View.INVISIBLE);
            this.l_feature7.setVisibility(View.INVISIBLE);
            this.l_feature8.setVisibility(View.INVISIBLE);
            this.l_feature10.setVisibility(View.INVISIBLE);
        } else if (MyUtil.featureNumber == 10) {
            this.l_feature10.setVisibility(View.VISIBLE);
            this.l_feature2.setVisibility(View.INVISIBLE);
            this.l_feature1.setVisibility(View.INVISIBLE);
            this.l_feature3.setVisibility(View.INVISIBLE);
            this.l_feature4.setVisibility(View.INVISIBLE);
            this.l_feature5.setVisibility(View.INVISIBLE);
            this.l_feature6.setVisibility(View.INVISIBLE);
            this.l_feature7.setVisibility(View.INVISIBLE);
            this.l_feature8.setVisibility(View.INVISIBLE);
            this.l_feature9.setVisibility(View.INVISIBLE);
        }
        clickFeatured1();
        clickFeatured2();
        clickFeatured3();
        clickFeatured4();
        clickFeatured5();
        clickFeatured6();
        clickFeatured7();
        clickFeatured8();
        clickFeatured9();
        clickFeatured10();
        this.outputFile = MyUtil.geOutputPath();
        inflate.setFocusableInTouchMode(true);
        inflate.requestFocus();
        inflate.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if (i != 4) {
                    return false;
                }
                MND_LoopFragment.this.stopRecordIfRunning();
                return false;
            }
        });
        return inflate;
    }

    public void startRecording() {
        if (!this.isRecording) {
            this.isRecording = true;
            Log.d("Dd", "startReddcording: start");
            try {
                File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC) + File.separator + getResources().getString(R.string.app_name));
                if (!file.exists()) {
                    file.mkdirs();
                }
                this.audioFile = "REC" + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
                MediaRecorder mediaRecorder2 = new MediaRecorder();
                this.mediaRecorder = mediaRecorder2;
                mediaRecorder2.setAudioSource(MediaRecorder.AudioSource.MIC);
                this.mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
                this.mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
                MediaRecorder mediaRecorder3 = this.mediaRecorder;
                mediaRecorder3.setOutputFile(file.getAbsolutePath() + File.separator + this.audioFile + ".m4a");
                this.mediaRecorder.prepare();
                this.mediaRecorder.start();
                return;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try {
            this.mediaRecorder.stop();
            this.mediaRecorder.release();
            this.mediaRecorder = null;
        } catch (Exception unused) {
        }
        this.isRecording = false;
        stopAllPads();
        Toast.makeText(this.loopPadActivity, getActivity().getString(R.string.Recording_saved_successfully), Toast.LENGTH_SHORT).show();
    }

    public void stopRecordIfRunning() {
        MediaRecorder mediaRecorder2;
        try {
            if (this.isRecording && (mediaRecorder2 = this.mediaRecorder) != null) {
                mediaRecorder2.stop();
                this.mediaRecorder.release();
                this.mediaRecorder = null;
                this.isRecording = false;
            }
        } catch (Exception unused) {
        }
        stopAllPads();
        this.mediaPlayer1 = null;
        this.mediaPlayer5 = null;
        this.mediaPlayer9 = null;
        this.mediaPlayer13 = null;
        this.mediaPlayer17 = null;
    }

    public void stopAllPads() {
        clearMedia1();
        clearMedia5();
        clearMedia9();
        clearMedia13();
        clearMedia17();
        disableAllPad();
        Invisible_gif1_1();
        Invisible_gif1_2();
        Invisible_gif1_3();
        Invisible_gif1_4();
        Invisible_gif1_5();
        hideColorText();
        if (this.isRecording) {
            this.mediaRecorder.stop();
            this.mediaRecorder.release();
            this.mediaRecorder = null;
            this.isRecording = false;
        }
    }

    private void hideColorText() {
        try {
            this.tvBeat11.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
            this.tvBeat12.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
            this.tvBeat13.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
            this.tvBeat14.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
            this.tvBeat15.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
            this.tvBeat16.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
            this.tvBeat17.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
            this.tvBeat18.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
            this.tvBeat19.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
            this.tvBeat110.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
            this.tvBeat111.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
            this.tvBeat112.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
            this.tvBeat113.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
            this.tvBeat114.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
            this.tvBeat115.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
            this.tvBeat116.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
            this.tvBeat117.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
            this.tvBeat118.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
            this.tvBeat119.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
            this.tvBeat120.setTextColor(getActivity().getResources().getColor(R.color.color_9FA7A9));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void disableAllPad() {
        try {
            this.l_f1_loop1.setBackground(getResources().getDrawable(R.drawable.ic_beat_not_select));
            this.l_f1_loop2.setBackground(getResources().getDrawable(R.drawable.ic_beat_not_select));
            this.l_f1_loop3.setBackground(getResources().getDrawable(R.drawable.ic_beat_not_select));
            this.l_f1_loop4.setBackground(getResources().getDrawable(R.drawable.ic_beat_not_select));
            this.l_f1_loop5.setBackground(getResources().getDrawable(R.drawable.ic_bass_not_select));
            this.l_f1_loop6.setBackground(getResources().getDrawable(R.drawable.ic_bass_not_select));
            this.l_f1_loop7.setBackground(getResources().getDrawable(R.drawable.ic_bass_not_select));
            this.l_f1_loop8.setBackground(getResources().getDrawable(R.drawable.ic_bass_not_select));
            this.l_f1_loop9.setBackground(getResources().getDrawable(R.drawable.ic_padd_not_select));
            this.l_f1_loop10.setBackground(getResources().getDrawable(R.drawable.ic_padd_not_select));
            this.l_f1_loop11.setBackground(getResources().getDrawable(R.drawable.ic_padd_not_select));
            this.l_f1_loop12.setBackground(getResources().getDrawable(R.drawable.ic_padd_not_select));
            this.l_f1_loop13.setBackground(getResources().getDrawable(R.drawable.ic_lead_not_select));
            this.l_f1_loop14.setBackground(getResources().getDrawable(R.drawable.ic_lead_not_select));
            this.l_f1_loop15.setBackground(getResources().getDrawable(R.drawable.ic_lead_not_select));
            this.l_f1_loop16.setBackground(getResources().getDrawable(R.drawable.ic_lead_not_select));
            this.l_f1_loop17.setBackground(getResources().getDrawable(R.drawable.ic_arp_not_select));
            this.l_f1_loop18.setBackground(getResources().getDrawable(R.drawable.ic_arp_not_select));
            this.l_f1_loop19.setBackground(getResources().getDrawable(R.drawable.ic_arp_not_select));
            this.l_f1_loop20.setBackground(getResources().getDrawable(R.drawable.ic_arp_not_select));
            this.l_f2_loop1.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f2_loop2.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f2_loop3.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f2_loop4.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f2_loop5.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f2_loop6.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f2_loop7.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f2_loop8.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f2_loop9.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f2_loop10.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f2_loop11.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f2_loop12.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f2_loop13.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f2_loop14.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f2_loop15.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f2_loop16.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f2_loop17.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f2_loop18.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f2_loop19.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f2_loop20.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f3_loop1.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f3_loop2.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f3_loop3.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f3_loop4.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f3_loop5.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f3_loop6.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f3_loop7.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f3_loop8.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f3_loop9.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f3_loop10.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f3_loop11.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f3_loop12.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f3_loop13.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f3_loop14.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f3_loop15.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f3_loop16.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f3_loop17.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f3_loop18.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f3_loop19.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f3_loop20.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f4_loop1.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f4_loop2.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f4_loop3.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f4_loop4.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f4_loop5.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f4_loop6.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f4_loop7.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f4_loop8.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f4_loop9.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f4_loop10.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f4_loop11.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f4_loop12.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f4_loop13.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f4_loop14.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f4_loop15.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f4_loop16.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f4_loop17.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f4_loop18.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f4_loop19.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f4_loop20.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f5_loop1.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f5_loop2.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f5_loop3.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f5_loop4.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f5_loop5.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f5_loop6.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f5_loop7.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f5_loop8.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f5_loop9.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f5_loop10.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f5_loop11.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f5_loop12.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f5_loop13.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f5_loop14.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f5_loop15.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f5_loop16.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f5_loop17.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f5_loop18.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f5_loop19.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f5_loop20.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f6_loop1.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f6_loop2.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f6_loop3.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f6_loop4.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f6_loop5.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f6_loop6.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f6_loop7.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f6_loop8.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f6_loop9.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f6_loop10.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f6_loop11.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f6_loop12.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f6_loop13.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f6_loop14.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f6_loop15.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f6_loop16.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f6_loop17.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f6_loop18.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f6_loop19.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f6_loop20.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f7_loop1.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f7_loop2.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f7_loop3.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f7_loop4.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f7_loop5.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f7_loop6.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f7_loop7.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f7_loop8.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f7_loop9.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f7_loop10.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f7_loop11.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f7_loop12.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f7_loop13.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f7_loop14.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f7_loop15.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f7_loop16.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f7_loop17.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f7_loop18.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f7_loop19.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f7_loop20.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f8_loop1.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f8_loop2.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f8_loop3.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f8_loop4.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f8_loop5.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f8_loop6.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f8_loop7.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f8_loop8.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f8_loop9.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f8_loop10.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f8_loop11.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f8_loop12.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f8_loop13.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f8_loop14.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f8_loop15.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f8_loop16.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f8_loop17.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f8_loop18.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f8_loop19.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f8_loop20.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f9_loop1.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f9_loop2.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f9_loop3.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f9_loop4.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f9_loop5.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f9_loop6.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f9_loop7.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f9_loop8.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f9_loop9.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f9_loop10.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f9_loop11.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f9_loop12.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f9_loop13.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f9_loop14.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f9_loop15.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f9_loop16.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f9_loop17.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f9_loop18.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f9_loop19.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f9_loop20.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f10_loop1.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f10_loop2.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f10_loop3.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f10_loop4.setBackground(getResources().getDrawable(R.drawable.ic_btn1_unpress));
            this.l_f10_loop5.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f10_loop6.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f10_loop7.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f10_loop8.setBackground(getResources().getDrawable(R.drawable.ic_btn2_unpress));
            this.l_f10_loop9.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f10_loop10.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f10_loop11.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f10_loop12.setBackground(getResources().getDrawable(R.drawable.ic_btn3_unpress));
            this.l_f10_loop13.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f10_loop14.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f10_loop15.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f10_loop16.setBackground(getResources().getDrawable(R.drawable.ic_btn4_unpress));
            this.l_f10_loop17.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f10_loop18.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f10_loop19.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
            this.l_f10_loop20.setBackground(getResources().getDrawable(R.drawable.ic_btn5_unpress));
        } catch (IllegalStateException unused) {
        }
    }

    public void Invisible_gif1_1() {
        try {
            this.gif1_1.setVisibility(View.GONE);
            this.gif1_2.setVisibility(View.GONE);
            this.gif1_3.setVisibility(View.GONE);
            this.gif1_4.setVisibility(View.GONE);
            this.gif2_1.setVisibility(View.GONE);
            this.gif2_2.setVisibility(View.GONE);
            this.gif2_3.setVisibility(View.GONE);
            this.gif2_4.setVisibility(View.GONE);
            this.gif3_1.setVisibility(View.GONE);
            this.gif3_2.setVisibility(View.GONE);
            this.gif3_3.setVisibility(View.GONE);
            this.gif3_4.setVisibility(View.GONE);
            this.gif4_1.setVisibility(View.GONE);
            this.gif4_2.setVisibility(View.GONE);
            this.gif4_3.setVisibility(View.GONE);
            this.gif4_4.setVisibility(View.GONE);
            this.gif5_1.setVisibility(View.GONE);
            this.gif5_2.setVisibility(View.GONE);
            this.gif5_3.setVisibility(View.GONE);
            this.gif5_4.setVisibility(View.GONE);
            this.gif6_1.setVisibility(View.GONE);
            this.gif6_2.setVisibility(View.GONE);
            this.gif6_3.setVisibility(View.GONE);
            this.gif6_4.setVisibility(View.GONE);
            this.gif7_1.setVisibility(View.GONE);
            this.gif7_2.setVisibility(View.GONE);
            this.gif7_3.setVisibility(View.GONE);
            this.gif7_4.setVisibility(View.GONE);
            this.gif8_1.setVisibility(View.GONE);
            this.gif8_2.setVisibility(View.GONE);
            this.gif8_3.setVisibility(View.GONE);
            this.gif8_4.setVisibility(View.GONE);
            this.gif9_1.setVisibility(View.GONE);
            this.gif9_2.setVisibility(View.GONE);
            this.gif9_3.setVisibility(View.GONE);
            this.gif9_4.setVisibility(View.GONE);
            this.gif10_1.setVisibility(View.GONE);
            this.gif10_2.setVisibility(View.GONE);
            this.gif10_3.setVisibility(View.GONE);
            this.gif10_4.setVisibility(View.GONE);
        } catch (NullPointerException unused) {
        }
    }

    public void Invisible_gif1_2() {
        try {
            this.gif1_5.setVisibility(View.GONE);
            this.gif1_6.setVisibility(View.GONE);
            this.gif1_7.setVisibility(View.GONE);
            this.gif1_8.setVisibility(View.GONE);
            this.gif2_5.setVisibility(View.GONE);
            this.gif2_6.setVisibility(View.GONE);
            this.gif2_7.setVisibility(View.GONE);
            this.gif2_8.setVisibility(View.GONE);
            this.gif3_5.setVisibility(View.GONE);
            this.gif3_6.setVisibility(View.GONE);
            this.gif3_7.setVisibility(View.GONE);
            this.gif3_8.setVisibility(View.GONE);
            this.gif4_5.setVisibility(View.GONE);
            this.gif4_6.setVisibility(View.GONE);
            this.gif4_7.setVisibility(View.GONE);
            this.gif4_8.setVisibility(View.GONE);
            this.gif5_5.setVisibility(View.GONE);
            this.gif5_6.setVisibility(View.GONE);
            this.gif5_7.setVisibility(View.GONE);
            this.gif5_8.setVisibility(View.GONE);
            this.gif6_5.setVisibility(View.GONE);
            this.gif6_6.setVisibility(View.GONE);
            this.gif6_7.setVisibility(View.GONE);
            this.gif6_8.setVisibility(View.GONE);
            this.gif7_5.setVisibility(View.GONE);
            this.gif7_6.setVisibility(View.GONE);
            this.gif7_7.setVisibility(View.GONE);
            this.gif7_8.setVisibility(View.GONE);
            this.gif8_5.setVisibility(View.GONE);
            this.gif8_6.setVisibility(View.GONE);
            this.gif8_7.setVisibility(View.GONE);
            this.gif8_8.setVisibility(View.GONE);
            this.gif9_5.setVisibility(View.GONE);
            this.gif9_6.setVisibility(View.GONE);
            this.gif9_7.setVisibility(View.GONE);
            this.gif9_8.setVisibility(View.GONE);
            this.gif10_5.setVisibility(View.GONE);
            this.gif10_6.setVisibility(View.GONE);
            this.gif10_7.setVisibility(View.GONE);
            this.gif10_8.setVisibility(View.GONE);
        } catch (NullPointerException unused) {
        }
    }

    public void Invisible_gif1_3() {
        try {
            this.gif1_9.setVisibility(View.GONE);
            this.gif1_10.setVisibility(View.GONE);
            this.gif1_11.setVisibility(View.GONE);
            this.gif1_12.setVisibility(View.GONE);
            this.gif4_9.setVisibility(View.GONE);
            this.gif4_10.setVisibility(View.GONE);
            this.gif4_11.setVisibility(View.GONE);
            this.gif4_12.setVisibility(View.GONE);
            this.gif3_9.setVisibility(View.GONE);
            this.gif3_10.setVisibility(View.GONE);
            this.gif3_11.setVisibility(View.GONE);
            this.gif3_12.setVisibility(View.GONE);
            this.gif2_9.setVisibility(View.GONE);
            this.gif2_10.setVisibility(View.GONE);
            this.gif2_11.setVisibility(View.GONE);
            this.gif2_12.setVisibility(View.GONE);
            this.gif5_9.setVisibility(View.GONE);
            this.gif5_10.setVisibility(View.GONE);
            this.gif5_11.setVisibility(View.GONE);
            this.gif5_12.setVisibility(View.GONE);
            this.gif8_9.setVisibility(View.GONE);
            this.gif8_10.setVisibility(View.GONE);
            this.gif8_11.setVisibility(View.GONE);
            this.gif8_12.setVisibility(View.GONE);
            this.gif7_9.setVisibility(View.GONE);
            this.gif7_10.setVisibility(View.GONE);
            this.gif7_11.setVisibility(View.GONE);
            this.gif7_12.setVisibility(View.GONE);
            this.gif6_9.setVisibility(View.GONE);
            this.gif6_10.setVisibility(View.GONE);
            this.gif6_11.setVisibility(View.GONE);
            this.gif6_12.setVisibility(View.GONE);
            this.gif9_9.setVisibility(View.GONE);
            this.gif9_10.setVisibility(View.GONE);
            this.gif9_11.setVisibility(View.GONE);
            this.gif9_12.setVisibility(View.GONE);
            this.gif10_9.setVisibility(View.GONE);
            this.gif10_10.setVisibility(View.GONE);
            this.gif10_11.setVisibility(View.GONE);
            this.gif10_12.setVisibility(View.GONE);
        } catch (NullPointerException unused) {
        }
    }

    public void Invisible_gif1_4() {
        try {
            this.gif1_13.setVisibility(View.GONE);
            this.gif1_14.setVisibility(View.GONE);
            this.gif1_15.setVisibility(View.GONE);
            this.gif1_16.setVisibility(View.GONE);
            this.gif2_13.setVisibility(View.GONE);
            this.gif2_14.setVisibility(View.GONE);
            this.gif2_15.setVisibility(View.GONE);
            this.gif2_16.setVisibility(View.GONE);
            this.gif3_13.setVisibility(View.GONE);
            this.gif3_14.setVisibility(View.GONE);
            this.gif3_15.setVisibility(View.GONE);
            this.gif3_16.setVisibility(View.GONE);
            this.gif4_13.setVisibility(View.GONE);
            this.gif4_14.setVisibility(View.GONE);
            this.gif4_15.setVisibility(View.GONE);
            this.gif4_16.setVisibility(View.GONE);
            this.gif5_13.setVisibility(View.GONE);
            this.gif5_14.setVisibility(View.GONE);
            this.gif5_15.setVisibility(View.GONE);
            this.gif5_16.setVisibility(View.GONE);
            this.gif6_13.setVisibility(View.GONE);
            this.gif6_14.setVisibility(View.GONE);
            this.gif6_15.setVisibility(View.GONE);
            this.gif6_16.setVisibility(View.GONE);
            this.gif7_13.setVisibility(View.GONE);
            this.gif7_14.setVisibility(View.GONE);
            this.gif7_15.setVisibility(View.GONE);
            this.gif7_16.setVisibility(View.GONE);
            this.gif8_13.setVisibility(View.GONE);
            this.gif8_14.setVisibility(View.GONE);
            this.gif8_15.setVisibility(View.GONE);
            this.gif8_16.setVisibility(View.GONE);
            this.gif9_13.setVisibility(View.GONE);
            this.gif9_14.setVisibility(View.GONE);
            this.gif9_15.setVisibility(View.GONE);
            this.gif9_16.setVisibility(View.GONE);
            this.gif10_13.setVisibility(View.GONE);
            this.gif10_14.setVisibility(View.GONE);
            this.gif10_15.setVisibility(View.GONE);
            this.gif10_16.setVisibility(View.GONE);
        } catch (NullPointerException unused) {
        }
    }

    public void Invisible_gif1_5() {
        try {
            this.gif1_17.setVisibility(View.GONE);
            this.gif1_18.setVisibility(View.GONE);
            this.gif1_19.setVisibility(View.GONE);
            this.gif1_20.setVisibility(View.GONE);
            this.gif4_17.setVisibility(View.GONE);
            this.gif4_18.setVisibility(View.GONE);
            this.gif4_19.setVisibility(View.GONE);
            this.gif4_20.setVisibility(View.GONE);
            this.gif3_17.setVisibility(View.GONE);
            this.gif3_18.setVisibility(View.GONE);
            this.gif3_19.setVisibility(View.GONE);
            this.gif3_20.setVisibility(View.GONE);
            this.gif2_17.setVisibility(View.GONE);
            this.gif2_18.setVisibility(View.GONE);
            this.gif2_19.setVisibility(View.GONE);
            this.gif2_20.setVisibility(View.GONE);
            this.gif5_17.setVisibility(View.GONE);
            this.gif5_18.setVisibility(View.GONE);
            this.gif5_19.setVisibility(View.GONE);
            this.gif5_20.setVisibility(View.GONE);
            this.gif8_17.setVisibility(View.GONE);
            this.gif8_18.setVisibility(View.GONE);
            this.gif8_19.setVisibility(View.GONE);
            this.gif8_20.setVisibility(View.GONE);
            this.gif7_17.setVisibility(View.GONE);
            this.gif7_18.setVisibility(View.GONE);
            this.gif7_19.setVisibility(View.GONE);
            this.gif7_20.setVisibility(View.GONE);
            this.gif6_17.setVisibility(View.GONE);
            this.gif6_18.setVisibility(View.GONE);
            this.gif6_19.setVisibility(View.GONE);
            this.gif6_20.setVisibility(View.GONE);
            this.gif9_17.setVisibility(View.GONE);
            this.gif9_18.setVisibility(View.GONE);
            this.gif9_19.setVisibility(View.GONE);
            this.gif9_20.setVisibility(View.GONE);
            this.gif10_17.setVisibility(View.GONE);
            this.gif10_18.setVisibility(View.GONE);
            this.gif10_19.setVisibility(View.GONE);
            this.gif10_20.setVisibility(View.GONE);
        } catch (NullPointerException unused) {
        }
    }

    private void clickFeatured1() {
        this.l_f1_loop1.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass2 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat1(mND_LoopFragment.l_f1_loop1, "MyLoopMusic/r_loop1.mp3");
                MND_LoopFragment.this.tvBeat11.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif1_1.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass2.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat12.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat13.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat14.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_beat_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_beat_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_beat_not_select));
                    }
                }, 300);
            }
        });
        this.l_f1_loop2.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass3 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat2(mND_LoopFragment.l_f1_loop2, "MyLoopMusic/r_loop2.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass3.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat11.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat13.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat14.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_beat_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_beat_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_beat_not_select));
                    }
                }, 300);
                MND_LoopFragment.this.tvBeat12.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif1_2.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop3.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass4 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat3(mND_LoopFragment.l_f1_loop3, "MyLoopMusic/r_loop3.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass4.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat12.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat11.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat14.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_beat_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_beat_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_beat_not_select));
                    }
                }, 300);
                MND_LoopFragment.this.tvBeat13.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif1_3.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop4.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass5 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat4(mND_LoopFragment.l_f1_loop4, "MyLoopMusic/r_loop4.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass5.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat12.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat11.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat13.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_beat_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_beat_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_beat_not_select));
                    }
                }, 300);
                MND_LoopFragment.this.tvBeat14.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif1_4.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop5.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass6 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat5(mND_LoopFragment.l_f1_loop5, "MyLoopMusic/r_loop5.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass6.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat16.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat17.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat18.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_bass_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_bass_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_bass_not_select));
                    }
                }, 300);
                MND_LoopFragment.this.tvBeat15.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif1_5.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop6.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass7 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat6(mND_LoopFragment.l_f1_loop6, "MyLoopMusic/r_loop6.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass7.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat15.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat17.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat18.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_bass_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_bass_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_bass_not_select));
                    }
                }, 300);
                MND_LoopFragment.this.tvBeat16.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif1_6.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop7.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass8 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat7(mND_LoopFragment.l_f1_loop7, "MyLoopMusic/r_loop7.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass8.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat15.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat16.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat18.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_bass_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_bass_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_bass_not_select));
                    }
                }, 300);
                MND_LoopFragment.this.tvBeat17.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif1_7.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop8.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass9 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat8(mND_LoopFragment.l_f1_loop8, "MyLoopMusic/r_loop8.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass9.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat15.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat16.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat17.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_bass_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_bass_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_bass_not_select));
                    }
                }, 300);
                MND_LoopFragment.this.tvBeat18.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif1_8.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop9.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass10 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat9(mND_LoopFragment.l_f1_loop9, "MyLoopMusic/r_loop9.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass10.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat110.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat111.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat112.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_padd_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_padd_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_padd_not_select));
                    }
                }, 300);
                MND_LoopFragment.this.tvBeat19.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif1_9.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop10.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass11 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat10(mND_LoopFragment.l_f1_loop10, "MyLoopMusic/r_loop10.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass11.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat19.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat111.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat112.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_padd_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_padd_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_padd_not_select));
                    }
                }, 300);
                MND_LoopFragment.this.tvBeat110.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif1_10.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop11.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass12 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat11(mND_LoopFragment.l_f1_loop11, "MyLoopMusic/r_loop11.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass12.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat19.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat110.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat112.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_padd_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_padd_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_padd_not_select));
                    }
                }, 300);
                MND_LoopFragment.this.tvBeat111.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif1_11.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop12.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass13 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat12(mND_LoopFragment.l_f1_loop12, "MyLoopMusic/r_loop12.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass13.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat19.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat110.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat111.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_padd_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_padd_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_padd_not_select));
                    }
                }, 300);
                MND_LoopFragment.this.tvBeat112.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif1_12.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop13.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass14 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat13(mND_LoopFragment.l_f1_loop13, "MyLoopMusic/r_loop13.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass14.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat114.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat115.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat116.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_lead_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_lead_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_lead_not_select));
                    }
                }, 300);
                MND_LoopFragment.this.tvBeat113.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif1_13.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop14.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass15 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat14(mND_LoopFragment.l_f1_loop14, "MyLoopMusic/r_loop14.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass15.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat113.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat115.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat116.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_lead_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_lead_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_lead_not_select));
                    }
                }, 300);
                MND_LoopFragment.this.tvBeat114.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif1_14.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop15.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass16 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat15(mND_LoopFragment.l_f1_loop15, "MyLoopMusic/r_loop15.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass16.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat113.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat114.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat116.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_lead_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_lead_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_lead_not_select));
                    }
                }, 300);
                MND_LoopFragment.this.tvBeat115.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif1_15.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop16.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass17 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat16(mND_LoopFragment.l_f1_loop16, "MyLoopMusic/r_loop16.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass17.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat113.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat114.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat115.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_lead_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_lead_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_lead_not_select));
                    }
                }, 300);
                MND_LoopFragment.this.tvBeat116.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif1_16.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop17.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass18 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat17(mND_LoopFragment.l_f1_loop17, "MyLoopMusic/r_loop17.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass18.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat118.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat119.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat120.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_arp_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_arp_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_arp_not_select));
                    }
                }, 300);
                MND_LoopFragment.this.tvBeat117.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif1_17.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop18.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass19 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat18(mND_LoopFragment.l_f1_loop18, "MyLoopMusic/r_loop18.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass19.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat117.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat119.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat120.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_arp_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_arp_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_arp_not_select));
                    }
                }, 300);
                MND_LoopFragment.this.tvBeat118.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif1_18.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop19.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass20 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat19(mND_LoopFragment.l_f1_loop19, "MyLoopMusic/r_loop19.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass20.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat117.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat118.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat120.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_arp_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_arp_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_arp_not_select));
                    }
                }, 300);
                MND_LoopFragment.this.tvBeat119.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif1_19.setVisibility(View.VISIBLE);
            }
        });
        this.l_f1_loop20.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass21 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat20(mND_LoopFragment.l_f1_loop20, "MyLoopMusic/r_loop20.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass21.AnonymousClass1 */

                    public void run() {
                        MND_LoopFragment.this.tvBeat117.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat118.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        MND_LoopFragment.this.tvBeat119.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.color_9FA7A9));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_arp_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_arp_not_select));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f1_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_arp_not_select));
                    }
                }, 300);
                MND_LoopFragment.this.tvBeat120.setTextColor(MND_LoopFragment.this.getResources().getColor(R.color.white));
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif1_20.setVisibility(View.VISIBLE);
            }
        });
    }

    private void clickFeatured2() {
        this.l_f2_loop1.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass22 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat1(mND_LoopFragment.l_f2_loop1, "MyLoopMusic/r_loop21.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass22.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif2_1.setVisibility(View.VISIBLE);
            }
        });
        this.l_f2_loop2.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass23 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat2(mND_LoopFragment.l_f2_loop2, "MyLoopMusic/r_loop22.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass23.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif2_2.setVisibility(View.VISIBLE);
            }
        });
        this.l_f2_loop3.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass24 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat3(mND_LoopFragment.l_f2_loop3, "MyLoopMusic/r_loop23.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass24.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif2_3.setVisibility(View.VISIBLE);
            }
        });
        this.l_f2_loop4.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass25 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat4(mND_LoopFragment.l_f2_loop4, "MyLoopMusic/r_loop24.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass25.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif2_4.setVisibility(View.VISIBLE);
            }
        });
        this.l_f2_loop5.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass26 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat5(mND_LoopFragment.l_f2_loop5, "MyLoopMusic/r_loop25.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass26.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif2_5.setVisibility(View.VISIBLE);
            }
        });
        this.l_f2_loop6.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass27 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat6(mND_LoopFragment.l_f2_loop6, "MyLoopMusic/r_loop26.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass27.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif2_6.setVisibility(View.VISIBLE);
            }
        });
        this.l_f2_loop7.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass28 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat7(mND_LoopFragment.l_f2_loop7, "MyLoopMusic/r_loop27.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass28.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif2_7.setVisibility(View.VISIBLE);
            }
        });
        this.l_f2_loop8.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass29 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat8(mND_LoopFragment.l_f2_loop8, "MyLoopMusic/r_loop28.mp3");
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass29.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif2_8.setVisibility(View.VISIBLE);
            }
        });
        this.l_f2_loop9.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass30 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat9(mND_LoopFragment.l_f2_loop9, "MyLoopMusic/r_loop29.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif2_9.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass30.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop10.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass31 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat10(mND_LoopFragment.l_f2_loop10, "MyLoopMusic/r_loop30.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif2_10.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass31.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop11.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass32 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat11(mND_LoopFragment.l_f2_loop11, "MyLoopMusic/r_loop31.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif2_11.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass32.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop12.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass33 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat12(mND_LoopFragment.l_f2_loop12, "MyLoopMusic/r_loop32.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif2_12.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass33.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop13.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass34 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat13(mND_LoopFragment.l_f2_loop13, "MyLoopMusic/r_loop33.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif2_13.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass34.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop14.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass35 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat14(mND_LoopFragment.l_f2_loop14, "MyLoopMusic/r_loop34.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif2_14.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass35.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop15.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass36 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat15(mND_LoopFragment.l_f2_loop15, "MyLoopMusic/r_loop35.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif2_15.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass36.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop16.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass37 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat16(mND_LoopFragment.l_f2_loop16, "MyLoopMusic/r_loop36.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif2_16.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass37.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop17.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass38 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat17(mND_LoopFragment.l_f2_loop17, "MyLoopMusic/r_loop37.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif2_17.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass38.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop18.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass39 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat18(mND_LoopFragment.l_f2_loop18, "MyLoopMusic/r_loop38.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif2_18.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass39.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop19.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass40 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat19(mND_LoopFragment.l_f2_loop19, "MyLoopMusic/r_loop39.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif2_19.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass40.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f2_loop20.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass41 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat20(mND_LoopFragment.l_f2_loop20, "MyLoopMusic/r_loop40.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif2_20.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass41.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f2_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
    }

    private void clickFeatured3() {
        this.l_f3_loop1.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass42 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat1(mND_LoopFragment.l_f3_loop1, "MyLoopMusic/r_loop1.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif3_1.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass42.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop2.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass43 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat2(mND_LoopFragment.l_f3_loop2, "MyLoopMusic/r_loop2.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif3_2.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass43.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop3.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass44 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat3(mND_LoopFragment.l_f3_loop3, "MyLoopMusic/r_loop3.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif3_3.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass44.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop4.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass45 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat4(mND_LoopFragment.l_f3_loop4, "MyLoopMusic/r_loop4.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif3_4.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass45.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop5.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass46 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat5(mND_LoopFragment.l_f3_loop5, "MyLoopMusic/r_loop5.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif3_5.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass46.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop6.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass47 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat6(mND_LoopFragment.l_f3_loop6, "MyLoopMusic/r_loop6.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif3_6.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass47.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop7.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass48 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat7(mND_LoopFragment.l_f3_loop7, "MyLoopMusic/r_loop7.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif3_7.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass48.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop8.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass49 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat8(mND_LoopFragment.l_f3_loop8, "MyLoopMusic/r_loop8.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif3_8.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass49.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop9.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass50 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat9(mND_LoopFragment.l_f3_loop9, "MyLoopMusic/r_loop9.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif3_9.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass50.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop10.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass51 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat10(mND_LoopFragment.l_f3_loop10, "MyLoopMusic/r_loop10.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif3_10.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass51.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop11.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass52 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat11(mND_LoopFragment.l_f3_loop11, "MyLoopMusic/r_loop11.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif3_11.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass52.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop12.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass53 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat12(mND_LoopFragment.l_f3_loop12, "MyLoopMusic/r_loop12.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif3_12.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass53.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop13.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass54 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat13(mND_LoopFragment.l_f3_loop13, "MyLoopMusic/r_loop13.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif3_13.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass54.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop14.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass55 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat14(mND_LoopFragment.l_f3_loop14, "MyLoopMusic/r_loop14.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif3_14.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass55.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop15.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass56 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat15(mND_LoopFragment.l_f3_loop15, "MyLoopMusic/r_loop15.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif3_15.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass56.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop16.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass57 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat16(mND_LoopFragment.l_f3_loop16, "MyLoopMusic/r_loop16.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif3_16.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass57.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop17.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass58 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat17(mND_LoopFragment.l_f3_loop17, "MyLoopMusic/r_loop17.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif3_17.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass58.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop18.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass59 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat18(mND_LoopFragment.l_f3_loop18, "MyLoopMusic/r_loop18.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif3_18.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass59.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop19.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass60 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat19(mND_LoopFragment.l_f3_loop19, "MyLoopMusic/r_loop19.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif3_19.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass60.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f3_loop20.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass61 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat20(mND_LoopFragment.l_f3_loop20, "MyLoopMusic/r_loop20.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif3_20.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass61.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f3_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
    }

    private void clickFeatured4() {
        this.l_f4_loop1.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass62 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat1(mND_LoopFragment.l_f4_loop1, "MyLoopMusic/r_loop1.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif4_1.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass62.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop2.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass63 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat2(mND_LoopFragment.l_f4_loop2, "MyLoopMusic/r_loop2.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif4_2.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass63.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop3.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass64 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat3(mND_LoopFragment.l_f4_loop3, "MyLoopMusic/r_loop3.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif4_3.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass64.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop4.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass65 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat4(mND_LoopFragment.l_f4_loop4, "MyLoopMusic/r_loop4.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif4_4.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass65.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop5.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass66 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat5(mND_LoopFragment.l_f4_loop5, "MyLoopMusic/r_loop5.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif4_5.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass66.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop6.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass67 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat6(mND_LoopFragment.l_f4_loop6, "MyLoopMusic/r_loop6.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif4_6.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass67.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop7.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass68 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat7(mND_LoopFragment.l_f4_loop7, "MyLoopMusic/r_loop7.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif4_7.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass68.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop8.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass69 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat8(mND_LoopFragment.l_f4_loop8, "MyLoopMusic/r_loop8.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif4_8.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass69.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop9.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass70 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat9(mND_LoopFragment.l_f4_loop9, "MyLoopMusic/r_loop9.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif4_9.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass70.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop10.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass71 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat10(mND_LoopFragment.l_f4_loop10, "MyLoopMusic/r_loop10.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif4_10.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass71.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop11.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass72 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat11(mND_LoopFragment.l_f4_loop11, "MyLoopMusic/r_loop11.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif4_11.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass72.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop12.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass73 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat12(mND_LoopFragment.l_f4_loop12, "MyLoopMusic/r_loop12.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif4_12.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass73.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop13.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass74 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat13(mND_LoopFragment.l_f4_loop13, "MyLoopMusic/r_loop13.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif4_13.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass74.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop14.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass75 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat14(mND_LoopFragment.l_f4_loop14, "MyLoopMusic/r_loop14.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif4_14.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass75.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop15.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass76 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat15(mND_LoopFragment.l_f4_loop15, "MyLoopMusic/r_loop15.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif4_15.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass76.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop16.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass77 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat16(mND_LoopFragment.l_f4_loop16, "MyLoopMusic/r_loop16.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif4_16.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass77.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop17.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass78 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat17(mND_LoopFragment.l_f4_loop17, "MyLoopMusic/r_loop17.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif4_17.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass78.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop18.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass79 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat18(mND_LoopFragment.l_f4_loop18, "MyLoopMusic/r_loop18.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif4_18.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass79.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop19.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass80 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat19(mND_LoopFragment.l_f4_loop19, "MyLoopMusic/r_loop19.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif4_19.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass80.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f4_loop20.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass81 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat20(mND_LoopFragment.l_f4_loop20, "MyLoopMusic/r_loop20.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif4_20.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass81.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f4_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
    }

    private void clickFeatured5() {
        this.l_f5_loop1.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass82 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat1(mND_LoopFragment.l_f5_loop1, "MyLoopMusic/r_loop1.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif5_1.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass82.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop2.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass83 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat2(mND_LoopFragment.l_f5_loop2, "MyLoopMusic/r_loop2.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif5_2.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass83.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop3.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass84 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat3(mND_LoopFragment.l_f5_loop3, "MyLoopMusic/r_loop3.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif5_3.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass84.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop4.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass85 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat4(mND_LoopFragment.l_f5_loop4, "MyLoopMusic/r_loop4.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif5_4.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass85.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop5.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass86 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat5(mND_LoopFragment.l_f5_loop5, "MyLoopMusic/r_loop5.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif5_5.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass86.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop6.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass87 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat6(mND_LoopFragment.l_f5_loop6, "MyLoopMusic/r_loop6.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif5_6.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass87.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop7.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass88 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat7(mND_LoopFragment.l_f5_loop7, "MyLoopMusic/r_loop7.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif5_7.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass88.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop8.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass89 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat8(mND_LoopFragment.l_f5_loop8, "MyLoopMusic/r_loop8.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif5_8.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass89.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop9.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass90 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat9(mND_LoopFragment.l_f5_loop9, "MyLoopMusic/r_loop9.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif5_9.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass90.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop10.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass91 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat10(mND_LoopFragment.l_f5_loop10, "MyLoopMusic/r_loop10.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif5_10.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass91.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop11.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass92 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat11(mND_LoopFragment.l_f5_loop11, "MyLoopMusic/r_loop11.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif5_11.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass92.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop12.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass93 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat12(mND_LoopFragment.l_f5_loop12, "MyLoopMusic/r_loop12.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif5_12.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass93.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop13.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass94 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat13(mND_LoopFragment.l_f5_loop13, "MyLoopMusic/r_loop13.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif5_13.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass94.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop14.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass95 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat14(mND_LoopFragment.l_f5_loop14, "MyLoopMusic/r_loop14.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif5_14.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass95.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop15.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass96 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat15(mND_LoopFragment.l_f5_loop15, "MyLoopMusic/r_loop15.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif5_15.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass96.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop16.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass97 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat16(mND_LoopFragment.l_f5_loop16, "MyLoopMusic/r_loop16.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif5_16.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass97.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop17.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass98 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat17(mND_LoopFragment.l_f5_loop17, "MyLoopMusic/r_loop17.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif5_17.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass98.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop18.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass99 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat18(mND_LoopFragment.l_f5_loop18, "MyLoopMusic/r_loop18.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif5_18.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass99.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop19.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass100 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat19(mND_LoopFragment.l_f5_loop19, "MyLoopMusic/r_loop19.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif5_19.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass100.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f5_loop20.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass101 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat20(mND_LoopFragment.l_f5_loop20, "MyLoopMusic/r_loop20.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif5_20.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass101.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f5_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
    }

    private void clickFeatured6() {
        this.l_f6_loop1.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass102 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat1(mND_LoopFragment.l_f6_loop1, "MyLoopMusic/r_loop1.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif6_1.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass102.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop2.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass103 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat2(mND_LoopFragment.l_f6_loop2, "MyLoopMusic/r_loop2.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif6_2.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass103.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop3.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass104 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat3(mND_LoopFragment.l_f6_loop3, "MyLoopMusic/r_loop3.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif6_3.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass104.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop4.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass105 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat4(mND_LoopFragment.l_f6_loop4, "MyLoopMusic/r_loop4.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif6_4.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass105.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop5.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass106 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat5(mND_LoopFragment.l_f6_loop5, "MyLoopMusic/r_loop5.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif6_5.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass106.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop6.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass107 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat6(mND_LoopFragment.l_f6_loop6, "MyLoopMusic/r_loop6.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif6_6.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass107.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop7.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass108 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat7(mND_LoopFragment.l_f6_loop7, "MyLoopMusic/r_loop7.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif6_7.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass108.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop8.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass109 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat8(mND_LoopFragment.l_f6_loop8, "MyLoopMusic/r_loop8.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif6_8.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass109.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop9.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass110 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat9(mND_LoopFragment.l_f6_loop9, "MyLoopMusic/r_loop9.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif6_9.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass110.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop10.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass111 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat10(mND_LoopFragment.l_f6_loop10, "MyLoopMusic/r_loop10.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif6_10.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass111.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop11.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass112 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat11(mND_LoopFragment.l_f6_loop11, "MyLoopMusic/r_loop11.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif6_11.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass112.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop12.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass113 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat12(mND_LoopFragment.l_f6_loop12, "MyLoopMusic/r_loop12.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif6_12.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass113.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop13.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass114 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat13(mND_LoopFragment.l_f6_loop13, "MyLoopMusic/r_loop13.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif6_13.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass114.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop14.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass115 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat14(mND_LoopFragment.l_f6_loop14, "MyLoopMusic/r_loop14.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif6_14.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass115.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop15.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass116 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat15(mND_LoopFragment.l_f6_loop15, "MyLoopMusic/r_loop15.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif6_15.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass116.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop16.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass117 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat16(mND_LoopFragment.l_f6_loop16, "MyLoopMusic/r_loop16.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif6_16.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass117.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop17.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass118 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat17(mND_LoopFragment.l_f6_loop17, "MyLoopMusic/r_loop17.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif6_17.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass118.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop18.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass119 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat18(mND_LoopFragment.l_f6_loop18, "MyLoopMusic/r_loop18.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif6_18.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass119.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop19.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass120 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat19(mND_LoopFragment.l_f6_loop19, "MyLoopMusic/r_loop19.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif6_19.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass120.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f6_loop20.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass121 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat20(mND_LoopFragment.l_f6_loop20, "MyLoopMusic/r_loop20.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif6_20.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass121.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f6_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
    }

    private void clickFeatured7() {
        this.l_f7_loop1.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass122 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat1(mND_LoopFragment.l_f7_loop1, "MyLoopMusic/r_loop1.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif7_1.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass122.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop2.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass123 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat2(mND_LoopFragment.l_f7_loop2, "MyLoopMusic/r_loop2.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif7_2.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass123.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop3.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass124 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat3(mND_LoopFragment.l_f7_loop3, "MyLoopMusic/r_loop3.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif7_3.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass124.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop4.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass125 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat4(mND_LoopFragment.l_f7_loop4, "MyLoopMusic/r_loop4.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif7_4.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass125.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop5.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass126 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat5(mND_LoopFragment.l_f7_loop5, "MyLoopMusic/r_loop5.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif7_5.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass126.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop6.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass127 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat6(mND_LoopFragment.l_f7_loop6, "MyLoopMusic/r_loop6.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif7_6.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass127.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop7.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass128 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat7(mND_LoopFragment.l_f7_loop7, "MyLoopMusic/r_loop7.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif7_7.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass128.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop8.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass129 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat8(mND_LoopFragment.l_f7_loop8, "MyLoopMusic/r_loop8.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif7_8.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass129.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop9.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass130 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat9(mND_LoopFragment.l_f7_loop9, "MyLoopMusic/r_loop9.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif7_9.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass130.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop10.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass131 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat10(mND_LoopFragment.l_f7_loop10, "MyLoopMusic/r_loop10.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif7_10.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass131.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop11.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass132 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat11(mND_LoopFragment.l_f7_loop11, "MyLoopMusic/r_loop11.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif7_11.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass132.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop12.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass133 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat12(mND_LoopFragment.l_f7_loop12, "MyLoopMusic/r_loop12.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif7_12.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass133.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop13.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass134 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat13(mND_LoopFragment.l_f7_loop13, "MyLoopMusic/r_loop13.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif7_13.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass134.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop14.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass135 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat14(mND_LoopFragment.l_f7_loop14, "MyLoopMusic/r_loop14.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif7_14.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass135.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop15.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass136 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat15(mND_LoopFragment.l_f7_loop15, "MyLoopMusic/r_loop15.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif7_15.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass136.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop16.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass137 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat16(mND_LoopFragment.l_f7_loop16, "MyLoopMusic/r_loop16.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif7_16.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass137.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop17.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass138 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat17(mND_LoopFragment.l_f7_loop17, "MyLoopMusic/r_loop17.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif7_17.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass138.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop18.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass139 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat18(mND_LoopFragment.l_f7_loop18, "MyLoopMusic/r_loop18.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif7_18.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass139.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop19.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass140 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat19(mND_LoopFragment.l_f7_loop19, "MyLoopMusic/r_loop19.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif7_19.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass140.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f7_loop20.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass141 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat20(mND_LoopFragment.l_f7_loop20, "MyLoopMusic/r_loop20.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif7_20.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass141.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f7_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
    }

    private void clickFeatured8() {
        this.l_f8_loop1.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass142 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat1(mND_LoopFragment.l_f8_loop1, "MyLoopMusic/r_loop1.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif8_1.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass142.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop2.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass143 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat2(mND_LoopFragment.l_f8_loop2, "MyLoopMusic/r_loop2.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif8_2.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass143.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop3.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass144 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat3(mND_LoopFragment.l_f8_loop3, "MyLoopMusic/r_loop3.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif8_3.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass144.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop4.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass145 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat4(mND_LoopFragment.l_f8_loop4, "MyLoopMusic/r_loop4.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif8_4.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass145.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop5.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass146 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat5(mND_LoopFragment.l_f8_loop5, "MyLoopMusic/r_loop5.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif8_5.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass146.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop6.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass147 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat6(mND_LoopFragment.l_f8_loop6, "MyLoopMusic/r_loop6.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif8_6.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass147.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop7.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass148 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat7(mND_LoopFragment.l_f8_loop7, "MyLoopMusic/r_loop7.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif8_7.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass148.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop8.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass149 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat8(mND_LoopFragment.l_f8_loop8, "MyLoopMusic/r_loop8.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif8_8.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass149.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop9.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass150 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat9(mND_LoopFragment.l_f8_loop9, "MyLoopMusic/r_loop9.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif8_9.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass150.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop10.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass151 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat10(mND_LoopFragment.l_f8_loop10, "MyLoopMusic/r_loop10.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif8_10.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass151.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop11.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass152 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat11(mND_LoopFragment.l_f8_loop11, "MyLoopMusic/r_loop11.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif8_11.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass152.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop12.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass153 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat12(mND_LoopFragment.l_f8_loop12, "MyLoopMusic/r_loop12.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif8_12.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass153.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop13.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass154 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat13(mND_LoopFragment.l_f8_loop13, "MyLoopMusic/r_loop13.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif8_13.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass154.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop14.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass155 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat14(mND_LoopFragment.l_f8_loop14, "MyLoopMusic/r_loop14.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif8_14.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass155.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop15.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass156 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat15(mND_LoopFragment.l_f8_loop15, "MyLoopMusic/r_loop15.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif8_15.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass156.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop16.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass157 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat16(mND_LoopFragment.l_f8_loop16, "MyLoopMusic/r_loop16.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif8_16.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass157.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop17.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass158 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat17(mND_LoopFragment.l_f8_loop17, "MyLoopMusic/r_loop17.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif8_17.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass158.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop18.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass159 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat18(mND_LoopFragment.l_f8_loop18, "MyLoopMusic/r_loop18.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif8_18.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass159.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop19.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass160 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat19(mND_LoopFragment.l_f8_loop19, "MyLoopMusic/r_loop19.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif8_19.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass160.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f8_loop20.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass161 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat20(mND_LoopFragment.l_f8_loop20, "MyLoopMusic/r_loop20.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif8_20.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass161.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f8_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
    }

    private void clickFeatured9() {
        this.l_f9_loop1.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass162 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat1(mND_LoopFragment.l_f9_loop1, "MyLoopMusic/r_loop1.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif9_1.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass162.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop2.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass163 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat2(mND_LoopFragment.l_f9_loop2, "MyLoopMusic/r_loop2.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif9_2.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass163.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop3.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass164 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat3(mND_LoopFragment.l_f9_loop3, "MyLoopMusic/r_loop3.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif9_3.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass164.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop4.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass165 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat4(mND_LoopFragment.l_f9_loop4, "MyLoopMusic/r_loop4.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif9_4.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass165.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop5.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass166 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat5(mND_LoopFragment.l_f9_loop5, "MyLoopMusic/r_loop5.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif9_5.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass166.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop6.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass167 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat6(mND_LoopFragment.l_f9_loop6, "MyLoopMusic/r_loop6.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif9_6.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass167.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop7.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass168 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat7(mND_LoopFragment.l_f9_loop7, "MyLoopMusic/r_loop7.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif9_7.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass168.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop8.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass169 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat8(mND_LoopFragment.l_f9_loop8, "MyLoopMusic/r_loop8.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif9_8.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass169.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop9.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass170 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat9(mND_LoopFragment.l_f9_loop9, "MyLoopMusic/r_loop9.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif9_9.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass170.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop10.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass171 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat10(mND_LoopFragment.l_f9_loop10, "MyLoopMusic/r_loop10.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif9_10.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass171.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop11.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass172 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat11(mND_LoopFragment.l_f9_loop11, "MyLoopMusic/r_loop11.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif9_11.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass172.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop12.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass173 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat12(mND_LoopFragment.l_f9_loop12, "MyLoopMusic/r_loop12.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif9_12.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass173.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop13.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass174 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat13(mND_LoopFragment.l_f9_loop13, "MyLoopMusic/r_loop13.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif9_13.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass174.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop14.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass175 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat14(mND_LoopFragment.l_f9_loop14, "MyLoopMusic/r_loop14.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif9_14.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass175.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop15.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass176 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat15(mND_LoopFragment.l_f9_loop15, "MyLoopMusic/r_loop15.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif9_15.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass176.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop16.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass177 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat16(mND_LoopFragment.l_f9_loop16, "MyLoopMusic/r_loop16.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif9_16.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass177.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop17.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass178 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat17(mND_LoopFragment.l_f9_loop17, "MyLoopMusic/r_loop17.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif9_17.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass178.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop18.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass179 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat18(mND_LoopFragment.l_f9_loop18, "MyLoopMusic/r_loop18.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif9_18.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass179.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop19.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass180 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat19(mND_LoopFragment.l_f9_loop19, "MyLoopMusic/r_loop19.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif9_19.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass180.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f9_loop20.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass181 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat20(mND_LoopFragment.l_f9_loop20, "MyLoopMusic/r_loop20.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif9_20.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass181.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f9_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
    }

    private void clickFeatured10() {
        this.l_f10_loop1.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass182 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat1(mND_LoopFragment.l_f10_loop1, "MyLoopMusic/r_loop1.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif10_1.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass182.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop2.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass183 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat2(mND_LoopFragment.l_f10_loop2, "MyLoopMusic/r_loop2.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif10_2.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass183.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop3.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass184 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat3(mND_LoopFragment.l_f10_loop3, "MyLoopMusic/r_loop3.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif10_3.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass184.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop4, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop4.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass185 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat4(mND_LoopFragment.l_f10_loop4, "MyLoopMusic/r_loop4.mp3");
                MND_LoopFragment.this.Invisible_gif1_1();
                MND_LoopFragment.this.gif10_4.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass185.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop1, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop2, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop3, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn1_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop5.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass186 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat5(mND_LoopFragment.l_f10_loop5, "MyLoopMusic/r_loop5.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif10_5.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass186.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop6.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass187 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat6(mND_LoopFragment.l_f10_loop6, "MyLoopMusic/r_loop6.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif10_6.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass187.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop7.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass188 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat7(mND_LoopFragment.l_f10_loop7, "MyLoopMusic/r_loop7.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif10_7.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass188.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop8, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop8.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass189 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat8(mND_LoopFragment.l_f10_loop8, "MyLoopMusic/r_loop8.mp3");
                MND_LoopFragment.this.Invisible_gif1_2();
                MND_LoopFragment.this.gif10_8.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass189.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop5, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop6, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop7, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn2_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop9.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass190 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat9(mND_LoopFragment.l_f10_loop9, "MyLoopMusic/r_loop9.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif10_9.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass190.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop10.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass191 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat10(mND_LoopFragment.l_f10_loop10, "MyLoopMusic/r_loop10.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif10_10.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass191.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop11.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass192 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat11(mND_LoopFragment.l_f10_loop11, "MyLoopMusic/r_loop11.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif10_11.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass192.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop12, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop12.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass193 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat12(mND_LoopFragment.l_f10_loop12, "MyLoopMusic/r_loop12.mp3");
                MND_LoopFragment.this.Invisible_gif1_3();
                MND_LoopFragment.this.gif10_12.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass193.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop9, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop10, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop11, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn3_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop13.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass194 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat13(mND_LoopFragment.l_f10_loop13, "MyLoopMusic/r_loop13.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif10_13.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass194.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop14.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass195 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat14(mND_LoopFragment.l_f10_loop14, "MyLoopMusic/r_loop14.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif10_14.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass195.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop15.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass196 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat15(mND_LoopFragment.l_f10_loop15, "MyLoopMusic/r_loop15.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif10_15.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass196.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop16, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop16.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass197 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat16(mND_LoopFragment.l_f10_loop16, "MyLoopMusic/r_loop16.mp3");
                MND_LoopFragment.this.Invisible_gif1_4();
                MND_LoopFragment.this.gif10_16.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass197.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop13, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop14, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop15, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn4_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop17.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass198 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat17(mND_LoopFragment.l_f10_loop17, "MyLoopMusic/r_loop17.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif10_17.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass198.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop18.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass199 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat18(mND_LoopFragment.l_f10_loop18, "MyLoopMusic/r_loop18.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif10_18.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass199.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop19.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass200 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat19(mND_LoopFragment.l_f10_loop19, "MyLoopMusic/r_loop19.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif10_19.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass200.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop20, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
        this.l_f10_loop20.setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass201 */

            public void onClick(View view) {
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.performF1Beat20(mND_LoopFragment.l_f10_loop20, "MyLoopMusic/r_loop20.mp3");
                MND_LoopFragment.this.Invisible_gif1_5();
                MND_LoopFragment.this.gif10_20.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass201.AnonymousClass1 */

                    public void run() {
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop17, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop18, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                        ViewCompat.setBackground(MND_LoopFragment.this.l_f10_loop19, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_btn5_unpress));
                    }
                }, 1500);
            }
        });
    }

    public void clearMedia1() {
        MediaPlayer mediaPlayer = this.mediaPlayer1;
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            try {
                this.mediaPlayer1.stop();
                this.mediaPlayer1.reset();
            } catch (Exception unused) {
            }
        }
    }

    public void clearMedia5() {
        MediaPlayer mediaPlayer = this.mediaPlayer5;
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            try {
                this.mediaPlayer5.stop();
                this.mediaPlayer5.reset();
            } catch (Exception unused) {
            }
        }
    }

    public void clearMedia9() {
        MediaPlayer mediaPlayer = this.mediaPlayer9;
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            try {
                this.mediaPlayer9.stop();
                this.mediaPlayer9.reset();
            } catch (Exception unused) {
            }
        }
    }

    public void clearMedia13() {
        MediaPlayer mediaPlayer = this.mediaPlayer13;
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            try {
                this.mediaPlayer13.stop();
                this.mediaPlayer13.reset();
            } catch (Exception unused) {
            }
        }
    }

    public void clearMedia17() {
        MediaPlayer mediaPlayer = this.mediaPlayer17;
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            try {
                this.mediaPlayer17.stop();
                this.mediaPlayer17.reset();
            } catch (Exception unused) {
            }
        }
    }

    public void performF1Beat1(final LinearLayout linearLayout, final String str) {
        this.handler1 = new Handler();
        if (this.checkSection1 != 1) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass202 */

                public void run() {
                    MND_LoopFragment.this.blinkNo1++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo1 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_beat_select));
                    Log.d("TAG", "run: 3 sang");
                    try {
                        if (MND_LoopFragment.this.mediaPlayer1.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer1.stop();
                            MND_LoopFragment.this.mediaPlayer1.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer1 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer1.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer1.prepare();
                        MND_LoopFragment.this.mediaPlayer1.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer1.start();
                        MND_LoopFragment.this.checkSection1 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable1 = r0;
            this.handler1.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer1;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass203 */

                public void run() {
                    MND_LoopFragment.this.blinkNo1++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo1 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_beat_not_select));
                    Log.d("TAG", "run: 6 toi");
                    try {
                        if (MND_LoopFragment.this.mediaPlayer1.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer1.stop();
                            MND_LoopFragment.this.mediaPlayer1.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer1 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer1.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer1.prepare();
                        MND_LoopFragment.this.mediaPlayer1.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer1.start();
                        MND_LoopFragment.this.checkSection1 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable1 = r02;
            this.handler1.postDelayed(r02, 300);
            return;
        }
        Log.d("Dd", "ddgdrun: no null");
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass204 */

            public void run() {
                MND_LoopFragment.this.blinkNo1++;
                MND_LoopFragment.this.blinkNo1 = 0;
                ViewCompat.setBackground(linearLayout, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_beat_not_select));
                Log.d("TAG", "run: 9 toi");
                try {
                    MND_LoopFragment.this.mediaPlayer1.stop();
                    MND_LoopFragment.this.mediaPlayer1.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable1 = r7;
        this.handler1.postDelayed(r7, 300);
    }

    public void performF1Beat2(final LinearLayout linearLayout, final String str) {
        this.handler2 = new Handler();
        if (this.checkSection1 != 2) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass205 */

                public void run() {
                    MND_LoopFragment.this.blinkNo2++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo2 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_beat_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer1.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer1.stop();
                            MND_LoopFragment.this.mediaPlayer1.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer1 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer1.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer1.prepare();
                        MND_LoopFragment.this.mediaPlayer1.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer1.start();
                        MND_LoopFragment.this.checkSection1 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable2 = r0;
            this.handler2.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer1;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass206 */

                public void run() {
                    MND_LoopFragment.this.blinkNo2++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo2 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_beat_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer1.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer1.stop();
                            MND_LoopFragment.this.mediaPlayer1.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer1 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer1.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer1.prepare();
                        MND_LoopFragment.this.mediaPlayer1.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer1.start();
                        MND_LoopFragment.this.checkSection1 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable2 = r02;
            this.handler2.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass207 */

            public void run() {
                MND_LoopFragment.this.blinkNo2++;
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.blinkNo2 = 0;
                ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_beat_not_select));
                try {
                    MND_LoopFragment.this.mediaPlayer1.stop();
                    MND_LoopFragment.this.mediaPlayer1.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable2 = r7;
        this.handler2.postDelayed(r7, 300);
    }

    public void performF1Beat3(final LinearLayout linearLayout, final String str) {
        this.handler3 = new Handler();
        if (this.checkSection1 != 3) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass208 */

                public void run() {
                    MND_LoopFragment.this.blinkNo3++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo3 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_beat_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer1.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer1.stop();
                            MND_LoopFragment.this.mediaPlayer1.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer1 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer1.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer1.prepare();
                        MND_LoopFragment.this.mediaPlayer1.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer1.start();
                        MND_LoopFragment.this.checkSection1 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable3 = r0;
            this.handler3.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer1;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass209 */

                public void run() {
                    MND_LoopFragment.this.blinkNo3++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo3 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_beat_not_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer1.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer1.stop();
                            MND_LoopFragment.this.mediaPlayer1.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer1 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer1.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer1.prepare();
                        MND_LoopFragment.this.mediaPlayer1.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer1.start();
                        MND_LoopFragment.this.checkSection1 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable3 = r02;
            this.handler3.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass210 */

            public void run() {
                MND_LoopFragment.this.blinkNo3++;
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.blinkNo3 = 0;
                ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_beat_not_select));
                try {
                    MND_LoopFragment.this.mediaPlayer1.stop();
                    MND_LoopFragment.this.mediaPlayer1.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable3 = r7;
        this.handler3.postDelayed(r7, 300);
    }

    public void performF1Beat4(final LinearLayout linearLayout, final String str) {
        this.handler4 = new Handler();
        if (this.checkSection1 != 4) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass211 */

                public void run() {
                    MND_LoopFragment.this.blinkNo4++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo4 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_beat_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer1.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer1.stop();
                            MND_LoopFragment.this.mediaPlayer1.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer1 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer1.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer1.prepare();
                        MND_LoopFragment.this.mediaPlayer1.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer1.start();
                        MND_LoopFragment.this.checkSection1 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable4 = r0;
            this.handler4.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer1;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass212 */

                public void run() {
                    MND_LoopFragment.this.blinkNo4++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo4 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_beat_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer1.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer1.stop();
                            MND_LoopFragment.this.mediaPlayer1.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer1 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer1.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer1.prepare();
                        MND_LoopFragment.this.mediaPlayer1.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer1.start();
                        MND_LoopFragment.this.checkSection1 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable4 = r02;
            this.handler4.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass213 */

            public void run() {
                MND_LoopFragment.this.blinkNo4++;
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.blinkNo4 = 0;
                ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_beat_not_select));
                try {
                    MND_LoopFragment.this.mediaPlayer1.stop();
                    MND_LoopFragment.this.mediaPlayer1.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable4 = r7;
        this.handler4.postDelayed(r7, 300);
    }

    public void performF1Beat5(final LinearLayout linearLayout, final String str) {
        this.handler5 = new Handler();
        if (this.checkSection2 != 1) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass214 */

                public void run() {
                    MND_LoopFragment.this.blinkNo5++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo5 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_bass_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer5.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer5.stop();
                            MND_LoopFragment.this.mediaPlayer5.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer5 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer5.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer5.prepare();
                        MND_LoopFragment.this.mediaPlayer5.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer5.start();
                        MND_LoopFragment.this.checkSection2 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable5 = r0;
            this.handler5.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer5;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass215 */

                public void run() {
                    MND_LoopFragment.this.blinkNo5++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo5 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_bass_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer5.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer5.stop();
                            MND_LoopFragment.this.mediaPlayer5.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer5 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer5.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer5.prepare();
                        MND_LoopFragment.this.mediaPlayer5.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer5.start();
                        MND_LoopFragment.this.checkSection2 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable5 = r02;
            this.handler5.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass216 */

            public void run() {
                MND_LoopFragment.this.blinkNo5++;
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.blinkNo5 = 0;
                ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_bass_not_select));
                MND_LoopFragment.this.Invisible_gif1_2();
                try {
                    MND_LoopFragment.this.mediaPlayer5.stop();
                    MND_LoopFragment.this.mediaPlayer5.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable5 = r7;
        this.handler5.postDelayed(r7, 300);
    }

    public void performF1Beat6(final LinearLayout linearLayout, final String str) {
        this.handler6 = new Handler();
        if (this.checkSection2 != 2) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass217 */

                public void run() {
                    MND_LoopFragment.this.blinkNo6++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo6 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_bass_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer5.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer5.stop();
                            MND_LoopFragment.this.mediaPlayer5.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer5 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer5.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer5.prepare();
                        MND_LoopFragment.this.mediaPlayer5.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer5.start();
                        MND_LoopFragment.this.checkSection2 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable6 = r0;
            this.handler6.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer5;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass218 */

                public void run() {
                    MND_LoopFragment.this.blinkNo6++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo6 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_bass_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer5.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer5.stop();
                            MND_LoopFragment.this.mediaPlayer5.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer5 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer5.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer5.prepare();
                        MND_LoopFragment.this.mediaPlayer5.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer5.start();
                        MND_LoopFragment.this.checkSection2 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable6 = r02;
            this.handler6.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass219 */

            public void run() {
                MND_LoopFragment.this.blinkNo6++;
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.blinkNo6 = 0;
                ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_bass_not_select));
                MND_LoopFragment.this.Invisible_gif1_2();
                try {
                    MND_LoopFragment.this.mediaPlayer5.stop();
                    MND_LoopFragment.this.mediaPlayer5.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable6 = r7;
        this.handler6.postDelayed(r7, 300);
    }

    public void performF1Beat7(final LinearLayout linearLayout, final String str) {
        this.handler7 = new Handler();
        if (this.checkSection2 != 3) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass220 */

                public void run() {
                    MND_LoopFragment.this.blinkNo7++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo7 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_bass_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer5.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer5.stop();
                            MND_LoopFragment.this.mediaPlayer5.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer5 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer5.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer5.prepare();
                        MND_LoopFragment.this.mediaPlayer5.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer5.start();
                        MND_LoopFragment.this.checkSection2 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable7 = r0;
            this.handler7.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer5;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass221 */

                public void run() {
                    MND_LoopFragment.this.blinkNo7++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo7 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_bass_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer5.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer5.stop();
                            MND_LoopFragment.this.mediaPlayer5.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer5 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer5.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer5.prepare();
                        MND_LoopFragment.this.mediaPlayer5.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer5.start();
                        MND_LoopFragment.this.checkSection2 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable7 = r02;
            this.handler7.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass222 */

            public void run() {
                MND_LoopFragment.this.blinkNo7++;
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.blinkNo7 = 0;
                ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_bass_not_select));
                MND_LoopFragment.this.Invisible_gif1_2();
                try {
                    MND_LoopFragment.this.mediaPlayer5.stop();
                    MND_LoopFragment.this.mediaPlayer5.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable7 = r7;
        this.handler7.postDelayed(r7, 300);
    }

    public void performF1Beat8(final LinearLayout linearLayout, final String str) {
        this.handler8 = new Handler();
        if (this.checkSection2 != 4) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass223 */

                public void run() {
                    MND_LoopFragment.this.blinkNo8++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo8 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_bass_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer5.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer5.stop();
                            MND_LoopFragment.this.mediaPlayer5.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer5 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer5.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer5.prepare();
                        MND_LoopFragment.this.mediaPlayer5.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer5.start();
                        MND_LoopFragment.this.checkSection2 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable8 = r0;
            this.handler8.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer5;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass224 */

                public void run() {
                    MND_LoopFragment.this.blinkNo8++;
                    if (MND_LoopFragment.this.blinkNo8 % 3 == 1) {
                        ViewCompat.setBackground(linearLayout, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_bass_not_select));
                    } else {
                        ViewCompat.setBackground(linearLayout, MND_LoopFragment.this.getResources().getDrawable(R.drawable.ic_bass_select));
                    }
                    if (MND_LoopFragment.this.blinkNo8 < 5) {
                        MND_LoopFragment.this.handler8.postDelayed(MND_LoopFragment.this.runnable8, 300);
                        return;
                    }
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo8 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_bass_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer5.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer5.stop();
                            MND_LoopFragment.this.mediaPlayer5.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer5 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer5.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer5.prepare();
                        MND_LoopFragment.this.mediaPlayer5.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer5.start();
                        MND_LoopFragment.this.checkSection2 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable8 = r02;
            this.handler8.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass225 */

            public void run() {
                MND_LoopFragment.this.blinkNo8++;
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.blinkNo8 = 0;
                ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_bass_not_select));
                MND_LoopFragment.this.Invisible_gif1_2();
                try {
                    MND_LoopFragment.this.mediaPlayer5.stop();
                    MND_LoopFragment.this.mediaPlayer5.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable8 = r7;
        this.handler8.postDelayed(r7, 300);
    }

    public void performF1Beat9(final LinearLayout linearLayout, final String str) {
        this.handler9 = new Handler();
        if (this.checkSection3 != 1) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass226 */

                public void run() {
                    MND_LoopFragment.this.blinkNo9++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo9 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_padd_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer9.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer9.stop();
                            MND_LoopFragment.this.mediaPlayer9.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer9 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer9.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer9.prepare();
                        MND_LoopFragment.this.mediaPlayer9.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer9.start();
                        MND_LoopFragment.this.checkSection3 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable9 = r0;
            this.handler9.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer9;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass227 */

                public void run() {
                    MND_LoopFragment.this.blinkNo9++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo9 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_padd_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer9.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer9.stop();
                            MND_LoopFragment.this.mediaPlayer9.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer9 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer9.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer9.prepare();
                        MND_LoopFragment.this.mediaPlayer9.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer9.start();
                        MND_LoopFragment.this.checkSection3 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable9 = r02;
            this.handler9.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass228 */

            public void run() {
                MND_LoopFragment.this.blinkNo9++;
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.blinkNo9 = 0;
                ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_padd_not_select));
                MND_LoopFragment.this.Invisible_gif1_3();
                try {
                    MND_LoopFragment.this.mediaPlayer9.stop();
                    MND_LoopFragment.this.mediaPlayer9.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable9 = r7;
        this.handler9.postDelayed(r7, 300);
    }

    public void performF1Beat10(final LinearLayout linearLayout, final String str) {
        this.handler10 = new Handler();
        if (this.checkSection3 != 2) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass229 */

                public void run() {
                    MND_LoopFragment.this.blinkNo10++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo10 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_padd_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer9.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer9.stop();
                            MND_LoopFragment.this.mediaPlayer9.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer9 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer9.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer9.prepare();
                        MND_LoopFragment.this.mediaPlayer9.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer9.start();
                        MND_LoopFragment.this.checkSection3 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable10 = r0;
            this.handler10.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer9;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass230 */

                public void run() {
                    MND_LoopFragment.this.blinkNo10++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo10 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_padd_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer9.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer9.stop();
                            MND_LoopFragment.this.mediaPlayer9.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer9 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer9.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer9.prepare();
                        MND_LoopFragment.this.mediaPlayer9.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer9.start();
                        MND_LoopFragment.this.checkSection3 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable10 = r02;
            this.handler10.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass231 */

            public void run() {
                MND_LoopFragment.this.blinkNo10++;
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.blinkNo10 = 0;
                ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_padd_not_select));
                MND_LoopFragment.this.Invisible_gif1_3();
                try {
                    MND_LoopFragment.this.mediaPlayer9.stop();
                    MND_LoopFragment.this.mediaPlayer9.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable10 = r7;
        this.handler10.postDelayed(r7, 300);
    }

    public void performF1Beat11(final LinearLayout linearLayout, final String str) {
        this.handler11 = new Handler();
        if (this.checkSection3 != 3) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass232 */

                public void run() {
                    MND_LoopFragment.this.blinkNo11++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo11 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_padd_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer9.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer9.stop();
                            MND_LoopFragment.this.mediaPlayer9.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer9 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer9.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer9.prepare();
                        MND_LoopFragment.this.mediaPlayer9.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer9.start();
                        MND_LoopFragment.this.checkSection3 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable11 = r0;
            this.handler11.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer9;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass233 */

                public void run() {
                    MND_LoopFragment.this.blinkNo11++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo11 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_padd_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer9.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer9.stop();
                            MND_LoopFragment.this.mediaPlayer9.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer9 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer9.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer9.prepare();
                        MND_LoopFragment.this.mediaPlayer9.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer9.start();
                        MND_LoopFragment.this.checkSection3 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable11 = r02;
            this.handler11.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass234 */

            public void run() {
                MND_LoopFragment.this.blinkNo11++;
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.blinkNo11 = 0;
                ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_padd_not_select));
                MND_LoopFragment.this.Invisible_gif1_3();
                try {
                    MND_LoopFragment.this.mediaPlayer9.stop();
                    MND_LoopFragment.this.mediaPlayer9.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable11 = r7;
        this.handler11.postDelayed(r7, 300);
    }

    public void performF1Beat12(final LinearLayout linearLayout, final String str) {
        this.handler12 = new Handler();
        if (this.checkSection3 != 4) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass235 */

                public void run() {
                    MND_LoopFragment.this.blinkNo12++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo12 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_padd_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer9.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer9.stop();
                            MND_LoopFragment.this.mediaPlayer9.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer9 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer9.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer9.prepare();
                        MND_LoopFragment.this.mediaPlayer9.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer9.start();
                        MND_LoopFragment.this.checkSection3 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable12 = r0;
            this.handler12.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer9;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass236 */

                public void run() {
                    MND_LoopFragment.this.blinkNo12++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo12 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_padd_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer9.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer9.stop();
                            MND_LoopFragment.this.mediaPlayer9.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer9 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer9.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer9.prepare();
                        MND_LoopFragment.this.mediaPlayer9.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer9.start();
                        MND_LoopFragment.this.checkSection3 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable12 = r02;
            this.handler12.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass237 */

            public void run() {
                MND_LoopFragment.this.blinkNo12++;
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.blinkNo12 = 0;
                ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_padd_not_select));
                MND_LoopFragment.this.Invisible_gif1_3();
                try {
                    MND_LoopFragment.this.mediaPlayer9.stop();
                    MND_LoopFragment.this.mediaPlayer9.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable12 = r7;
        this.handler12.postDelayed(r7, 300);
    }

    public void performF1Beat13(final LinearLayout linearLayout, final String str) {
        this.handler13 = new Handler();
        if (this.checkSection4 != 1) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass238 */

                public void run() {
                    MND_LoopFragment.this.blinkNo13++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo13 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_lead_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer13.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer13.stop();
                            MND_LoopFragment.this.mediaPlayer13.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer13 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer13.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer13.prepare();
                        MND_LoopFragment.this.mediaPlayer13.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer13.start();
                        MND_LoopFragment.this.checkSection4 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable13 = r0;
            this.handler13.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer13;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass239 */

                public void run() {
                    MND_LoopFragment.this.blinkNo13++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo13 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_lead_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer13.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer13.stop();
                            MND_LoopFragment.this.mediaPlayer13.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer13 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer13.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer13.prepare();
                        MND_LoopFragment.this.mediaPlayer13.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer13.start();
                        MND_LoopFragment.this.checkSection4 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable13 = r02;
            this.handler13.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass240 */

            public void run() {
                MND_LoopFragment.this.blinkNo13++;
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.blinkNo13 = 0;
                ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_lead_not_select));
                MND_LoopFragment.this.Invisible_gif1_3();
                try {
                    MND_LoopFragment.this.mediaPlayer13.stop();
                    MND_LoopFragment.this.mediaPlayer13.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable13 = r7;
        this.handler13.postDelayed(r7, 300);
    }

    public void performF1Beat14(final LinearLayout linearLayout, final String str) {
        this.handler14 = new Handler();
        if (this.checkSection4 != 2) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass241 */

                public void run() {
                    MND_LoopFragment.this.blinkNo14++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo14 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_lead_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer13.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer13.stop();
                            MND_LoopFragment.this.mediaPlayer13.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer13 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer13.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer13.prepare();
                        MND_LoopFragment.this.mediaPlayer13.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer13.start();
                        MND_LoopFragment.this.checkSection4 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable14 = r0;
            this.handler14.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer13;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass242 */

                public void run() {
                    MND_LoopFragment.this.blinkNo14++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo14 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_lead_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer13.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer13.stop();
                            MND_LoopFragment.this.mediaPlayer13.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer13 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer13.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer13.prepare();
                        MND_LoopFragment.this.mediaPlayer13.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer13.start();
                        MND_LoopFragment.this.checkSection4 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable14 = r02;
            this.handler14.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass243 */

            public void run() {
                MND_LoopFragment.this.blinkNo14++;
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.blinkNo14 = 0;
                ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_lead_not_select));
                MND_LoopFragment.this.Invisible_gif1_4();
                try {
                    MND_LoopFragment.this.mediaPlayer13.stop();
                    MND_LoopFragment.this.mediaPlayer13.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable14 = r7;
        this.handler14.postDelayed(r7, 300);
    }

    public void performF1Beat15(final LinearLayout linearLayout, final String str) {
        this.handler15 = new Handler();
        if (this.checkSection4 != 3) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass244 */

                public void run() {
                    MND_LoopFragment.this.blinkNo15++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo15 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_lead_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer13.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer13.stop();
                            MND_LoopFragment.this.mediaPlayer13.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer13 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer13.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer13.prepare();
                        MND_LoopFragment.this.mediaPlayer13.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer13.start();
                        MND_LoopFragment.this.checkSection4 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable15 = r0;
            this.handler15.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer13;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass245 */

                public void run() {
                    MND_LoopFragment.this.blinkNo15++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo15 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_lead_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer13.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer13.stop();
                            MND_LoopFragment.this.mediaPlayer13.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer13 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer13.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer13.prepare();
                        MND_LoopFragment.this.mediaPlayer13.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer13.start();
                        MND_LoopFragment.this.checkSection4 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable15 = r02;
            this.handler15.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass246 */

            public void run() {
                MND_LoopFragment.this.blinkNo15++;
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.blinkNo15 = 0;
                ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_lead_not_select));
                MND_LoopFragment.this.Invisible_gif1_4();
                try {
                    MND_LoopFragment.this.mediaPlayer13.stop();
                    MND_LoopFragment.this.mediaPlayer13.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable15 = r7;
        this.handler15.postDelayed(r7, 300);
    }

    public void performF1Beat16(final LinearLayout linearLayout, final String str) {
        this.handler16 = new Handler();
        if (this.checkSection4 != 4) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass247 */

                public void run() {
                    MND_LoopFragment.this.blinkNo16++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo16 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_lead_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer13.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer13.stop();
                            MND_LoopFragment.this.mediaPlayer13.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer13 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer13.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer13.prepare();
                        MND_LoopFragment.this.mediaPlayer13.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer13.start();
                        MND_LoopFragment.this.checkSection4 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable16 = r0;
            this.handler16.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer13;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass248 */

                public void run() {
                    MND_LoopFragment.this.blinkNo16++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo16 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_lead_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer13.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer13.stop();
                            MND_LoopFragment.this.mediaPlayer13.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer13 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer13.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer13.prepare();
                        MND_LoopFragment.this.mediaPlayer13.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer13.start();
                        MND_LoopFragment.this.checkSection4 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable16 = r02;
            this.handler16.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass249 */

            public void run() {
                MND_LoopFragment.this.blinkNo16++;
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.blinkNo16 = 0;
                ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_lead_not_select));
                MND_LoopFragment.this.Invisible_gif1_4();
                try {
                    MND_LoopFragment.this.mediaPlayer13.stop();
                    MND_LoopFragment.this.mediaPlayer13.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable16 = r7;
        this.handler16.postDelayed(r7, 300);
    }

    public void performF1Beat17(final LinearLayout linearLayout, final String str) {
        this.handler17 = new Handler();
        if (this.checkSection5 != 1) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass250 */

                public void run() {
                    MND_LoopFragment.this.blinkNo17++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo17 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_arp_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer17.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer17.stop();
                            MND_LoopFragment.this.mediaPlayer17.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer17 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer17.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer17.prepare();
                        MND_LoopFragment.this.mediaPlayer17.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer17.start();
                        MND_LoopFragment.this.checkSection5 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable17 = r0;
            this.handler17.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer17;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass251 */

                public void run() {
                    MND_LoopFragment.this.blinkNo17++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo17 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_arp_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer17.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer17.stop();
                            MND_LoopFragment.this.mediaPlayer17.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer17 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer17.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer17.prepare();
                        MND_LoopFragment.this.mediaPlayer17.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer17.start();
                        MND_LoopFragment.this.checkSection5 = 1;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable17 = r02;
            this.handler17.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass252 */

            public void run() {
                MND_LoopFragment.this.blinkNo17++;
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.blinkNo17 = 0;
                ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_arp_not_select));
                MND_LoopFragment.this.Invisible_gif1_4();
                try {
                    MND_LoopFragment.this.mediaPlayer17.stop();
                    MND_LoopFragment.this.mediaPlayer17.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable17 = r7;
        this.handler17.postDelayed(r7, 300);
    }

    public void performF1Beat18(final LinearLayout linearLayout, final String str) {
        this.handler18 = new Handler();
        if (this.checkSection5 != 2) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass253 */

                public void run() {
                    MND_LoopFragment.this.blinkNo18++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo18 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_arp_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer17.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer17.stop();
                            MND_LoopFragment.this.mediaPlayer17.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer17 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer17.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer17.prepare();
                        MND_LoopFragment.this.mediaPlayer17.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer17.start();
                        MND_LoopFragment.this.checkSection5 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable18 = r0;
            this.handler18.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer17;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass254 */

                public void run() {
                    MND_LoopFragment.this.blinkNo18++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo18 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_arp_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer17.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer17.stop();
                            MND_LoopFragment.this.mediaPlayer17.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer17 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer17.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer17.prepare();
                        MND_LoopFragment.this.mediaPlayer17.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer17.start();
                        MND_LoopFragment.this.checkSection5 = 2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable18 = r02;
            this.handler18.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass255 */

            public void run() {
                MND_LoopFragment.this.blinkNo18++;
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.blinkNo18 = 0;
                ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_arp_not_select));
                MND_LoopFragment.this.Invisible_gif1_5();
                try {
                    MND_LoopFragment.this.mediaPlayer17.stop();
                    MND_LoopFragment.this.mediaPlayer17.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable18 = r7;
        this.handler18.postDelayed(r7, 300);
    }

    public void performF1Beat19(final LinearLayout linearLayout, final String str) {
        this.handler19 = new Handler();
        if (this.checkSection5 != 3) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass256 */

                public void run() {
                    MND_LoopFragment.this.blinkNo19++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo19 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_arp_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer17.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer17.stop();
                            MND_LoopFragment.this.mediaPlayer17.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer17 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer17.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer17.prepare();
                        MND_LoopFragment.this.mediaPlayer17.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer17.start();
                        MND_LoopFragment.this.checkSection5 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable19 = r0;
            this.handler19.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer17;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass257 */

                public void run() {
                    MND_LoopFragment.this.blinkNo19++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo19 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_arp_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer17.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer17.stop();
                            MND_LoopFragment.this.mediaPlayer17.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer17 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer17.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer17.prepare();
                        MND_LoopFragment.this.mediaPlayer17.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer17.start();
                        MND_LoopFragment.this.checkSection5 = 3;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable19 = r02;
            this.handler19.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass258 */

            public void run() {
                MND_LoopFragment.this.blinkNo19++;
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.blinkNo19 = 0;
                ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_arp_not_select));
                MND_LoopFragment.this.Invisible_gif1_5();
                try {
                    MND_LoopFragment.this.mediaPlayer17.stop();
                    MND_LoopFragment.this.mediaPlayer17.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable19 = r7;
        this.handler19.postDelayed(r7, 300);
    }

    public void performF1Beat20(final LinearLayout linearLayout, final String str) {
        this.handler20 = new Handler();
        if (this.checkSection5 != 4) {
            linearLayout.setEnabled(false);
            Runnable r0 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass259 */

                public void run() {
                    MND_LoopFragment.this.blinkNo20++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo20 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_arp_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer17.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer17.stop();
                            MND_LoopFragment.this.mediaPlayer17.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer17 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer17.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer17.prepare();
                        MND_LoopFragment.this.mediaPlayer17.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer17.start();
                        MND_LoopFragment.this.checkSection5 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable20 = r0;
            this.handler20.postDelayed(r0, 300);
            return;
        }
        MediaPlayer mediaPlayer = this.mediaPlayer17;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            Log.d("Dd", "ddgdrun: null");
            linearLayout.setEnabled(false);
            Runnable r02 = new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass260 */

                public void run() {
                    MND_LoopFragment.this.blinkNo20++;
                    MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                    mND_LoopFragment.blinkNo20 = 0;
                    ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_arp_select));
                    try {
                        if (MND_LoopFragment.this.mediaPlayer17.isPlaying()) {
                            MND_LoopFragment.this.mediaPlayer17.stop();
                            MND_LoopFragment.this.mediaPlayer17.reset();
                        }
                        MND_LoopFragment.this.mediaPlayer17 = new MediaPlayer();
                        AssetFileDescriptor openFd = MND_LoopFragment.this.loopPadActivity.getAssets().openFd(str);
                        MND_LoopFragment.this.mediaPlayer17.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                        openFd.close();
                        MND_LoopFragment.this.mediaPlayer17.prepare();
                        MND_LoopFragment.this.mediaPlayer17.setLooping(true);
                        MND_LoopFragment.this.mediaPlayer17.start();
                        MND_LoopFragment.this.checkSection5 = 4;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    linearLayout.setEnabled(true);
                }
            };
            this.runnable20 = r02;
            this.handler20.postDelayed(r02, 300);
            return;
        }
        linearLayout.setEnabled(false);
        Runnable r7 = new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopFragment.AnonymousClass261 */

            public void run() {
                MND_LoopFragment.this.blinkNo20++;
                MND_LoopFragment mND_LoopFragment = MND_LoopFragment.this;
                mND_LoopFragment.blinkNo20 = 0;
                ViewCompat.setBackground(linearLayout, mND_LoopFragment.getResources().getDrawable(R.drawable.ic_arp_not_select));
                MND_LoopFragment.this.Invisible_gif1_5();
                try {
                    MND_LoopFragment.this.mediaPlayer17.stop();
                    MND_LoopFragment.this.mediaPlayer17.reset();
                } catch (Exception unused) {
                }
                linearLayout.setEnabled(true);
            }
        };
        this.runnable20 = r7;
        this.handler20.postDelayed(r7, 300);
    }

    private void initLoopBind(View view) {
        this.l_f1_loop1 = (LinearLayout) view.findViewById(R.id.l_f1_loop1);
        this.l_f1_loop2 = (LinearLayout) view.findViewById(R.id.l_f1_loop2);
        this.l_f1_loop3 = (LinearLayout) view.findViewById(R.id.l_f1_loop3);
        this.l_f1_loop4 = (LinearLayout) view.findViewById(R.id.l_f1_loop4);
        this.l_f1_loop5 = (LinearLayout) view.findViewById(R.id.l_f1_loop5);
        this.l_f1_loop6 = (LinearLayout) view.findViewById(R.id.l_f1_loop6);
        this.l_f1_loop7 = (LinearLayout) view.findViewById(R.id.l_f1_loop7);
        this.l_f1_loop8 = (LinearLayout) view.findViewById(R.id.l_f1_loop8);
        this.l_f1_loop9 = (LinearLayout) view.findViewById(R.id.l_f1_loop9);
        this.l_f1_loop10 = (LinearLayout) view.findViewById(R.id.l_f1_loop10);
        this.l_f1_loop11 = (LinearLayout) view.findViewById(R.id.l_f1_loop11);
        this.l_f1_loop12 = (LinearLayout) view.findViewById(R.id.l_f1_loop12);
        this.l_f1_loop13 = (LinearLayout) view.findViewById(R.id.l_f1_loop13);
        this.l_f1_loop14 = (LinearLayout) view.findViewById(R.id.l_f1_loop14);
        this.l_f1_loop15 = (LinearLayout) view.findViewById(R.id.l_f1_loop15);
        this.l_f1_loop16 = (LinearLayout) view.findViewById(R.id.l_f1_loop16);
        this.l_f1_loop17 = (LinearLayout) view.findViewById(R.id.l_f1_loop17);
        this.l_f1_loop18 = (LinearLayout) view.findViewById(R.id.l_f1_loop18);
        this.l_f1_loop19 = (LinearLayout) view.findViewById(R.id.l_f1_loop19);
        this.l_f1_loop20 = (LinearLayout) view.findViewById(R.id.l_f1_loop20);
        this.l_f2_loop1 = (LinearLayout) view.findViewById(R.id.l_f2_loop1);
        this.l_f2_loop2 = (LinearLayout) view.findViewById(R.id.l_f2_loop2);
        this.l_f2_loop3 = (LinearLayout) view.findViewById(R.id.l_f2_loop3);
        this.l_f2_loop4 = (LinearLayout) view.findViewById(R.id.l_f2_loop4);
        this.l_f2_loop5 = (LinearLayout) view.findViewById(R.id.l_f2_loop5);
        this.l_f2_loop6 = (LinearLayout) view.findViewById(R.id.l_f2_loop6);
        this.l_f2_loop7 = (LinearLayout) view.findViewById(R.id.l_f2_loop7);
        this.l_f2_loop8 = (LinearLayout) view.findViewById(R.id.l_f2_loop8);
        this.l_f2_loop9 = (LinearLayout) view.findViewById(R.id.l_f2_loop9);
        this.l_f2_loop10 = (LinearLayout) view.findViewById(R.id.l_f2_loop10);
        this.l_f2_loop11 = (LinearLayout) view.findViewById(R.id.l_f2_loop11);
        this.l_f2_loop12 = (LinearLayout) view.findViewById(R.id.l_f2_loop12);
        this.l_f2_loop13 = (LinearLayout) view.findViewById(R.id.l_f2_loop13);
        this.l_f2_loop14 = (LinearLayout) view.findViewById(R.id.l_f2_loop14);
        this.l_f2_loop15 = (LinearLayout) view.findViewById(R.id.l_f2_loop15);
        this.l_f2_loop16 = (LinearLayout) view.findViewById(R.id.l_f2_loop16);
        this.l_f2_loop17 = (LinearLayout) view.findViewById(R.id.l_f2_loop17);
        this.l_f2_loop18 = (LinearLayout) view.findViewById(R.id.l_f2_loop18);
        this.l_f2_loop19 = (LinearLayout) view.findViewById(R.id.l_f2_loop19);
        this.l_f2_loop20 = (LinearLayout) view.findViewById(R.id.l_f2_loop20);
        this.l_f3_loop1 = (LinearLayout) view.findViewById(R.id.l_f3_loop1);
        this.l_f3_loop2 = (LinearLayout) view.findViewById(R.id.l_f3_loop2);
        this.l_f3_loop3 = (LinearLayout) view.findViewById(R.id.l_f3_loop3);
        this.l_f3_loop4 = (LinearLayout) view.findViewById(R.id.l_f3_loop4);
        this.l_f3_loop5 = (LinearLayout) view.findViewById(R.id.l_f3_loop5);
        this.l_f3_loop6 = (LinearLayout) view.findViewById(R.id.l_f3_loop6);
        this.l_f3_loop7 = (LinearLayout) view.findViewById(R.id.l_f3_loop7);
        this.l_f3_loop8 = (LinearLayout) view.findViewById(R.id.l_f3_loop8);
        this.l_f3_loop9 = (LinearLayout) view.findViewById(R.id.l_f3_loop9);
        this.l_f3_loop10 = (LinearLayout) view.findViewById(R.id.l_f3_loop10);
        this.l_f3_loop11 = (LinearLayout) view.findViewById(R.id.l_f3_loop11);
        this.l_f3_loop12 = (LinearLayout) view.findViewById(R.id.l_f3_loop12);
        this.l_f3_loop13 = (LinearLayout) view.findViewById(R.id.l_f3_loop13);
        this.l_f3_loop14 = (LinearLayout) view.findViewById(R.id.l_f3_loop14);
        this.l_f3_loop15 = (LinearLayout) view.findViewById(R.id.l_f3_loop15);
        this.l_f3_loop16 = (LinearLayout) view.findViewById(R.id.l_f3_loop16);
        this.l_f3_loop17 = (LinearLayout) view.findViewById(R.id.l_f3_loop17);
        this.l_f3_loop18 = (LinearLayout) view.findViewById(R.id.l_f3_loop18);
        this.l_f3_loop19 = (LinearLayout) view.findViewById(R.id.l_f3_loop19);
        this.l_f3_loop20 = (LinearLayout) view.findViewById(R.id.l_f3_loop20);
        this.l_f4_loop1 = (LinearLayout) view.findViewById(R.id.l_f4_loop1);
        this.l_f4_loop2 = (LinearLayout) view.findViewById(R.id.l_f4_loop2);
        this.l_f4_loop3 = (LinearLayout) view.findViewById(R.id.l_f4_loop3);
        this.l_f4_loop4 = (LinearLayout) view.findViewById(R.id.l_f4_loop4);
        this.l_f4_loop5 = (LinearLayout) view.findViewById(R.id.l_f4_loop5);
        this.l_f4_loop6 = (LinearLayout) view.findViewById(R.id.l_f4_loop6);
        this.l_f4_loop7 = (LinearLayout) view.findViewById(R.id.l_f4_loop7);
        this.l_f4_loop8 = (LinearLayout) view.findViewById(R.id.l_f4_loop8);
        this.l_f4_loop9 = (LinearLayout) view.findViewById(R.id.l_f4_loop9);
        this.l_f4_loop10 = (LinearLayout) view.findViewById(R.id.l_f4_loop10);
        this.l_f4_loop11 = (LinearLayout) view.findViewById(R.id.l_f4_loop11);
        this.l_f4_loop12 = (LinearLayout) view.findViewById(R.id.l_f4_loop12);
        this.l_f4_loop13 = (LinearLayout) view.findViewById(R.id.l_f4_loop13);
        this.l_f4_loop14 = (LinearLayout) view.findViewById(R.id.l_f4_loop14);
        this.l_f4_loop15 = (LinearLayout) view.findViewById(R.id.l_f4_loop15);
        this.l_f4_loop16 = (LinearLayout) view.findViewById(R.id.l_f4_loop16);
        this.l_f4_loop17 = (LinearLayout) view.findViewById(R.id.l_f4_loop17);
        this.l_f4_loop18 = (LinearLayout) view.findViewById(R.id.l_f4_loop18);
        this.l_f4_loop19 = (LinearLayout) view.findViewById(R.id.l_f4_loop19);
        this.l_f4_loop20 = (LinearLayout) view.findViewById(R.id.l_f4_loop20);
        this.l_f5_loop1 = (LinearLayout) view.findViewById(R.id.l_f5_loop1);
        this.l_f5_loop2 = (LinearLayout) view.findViewById(R.id.l_f5_loop2);
        this.l_f5_loop3 = (LinearLayout) view.findViewById(R.id.l_f5_loop3);
        this.l_f5_loop4 = (LinearLayout) view.findViewById(R.id.l_f5_loop4);
        this.l_f5_loop5 = (LinearLayout) view.findViewById(R.id.l_f5_loop5);
        this.l_f5_loop6 = (LinearLayout) view.findViewById(R.id.l_f5_loop6);
        this.l_f5_loop7 = (LinearLayout) view.findViewById(R.id.l_f5_loop7);
        this.l_f5_loop8 = (LinearLayout) view.findViewById(R.id.l_f5_loop8);
        this.l_f5_loop9 = (LinearLayout) view.findViewById(R.id.l_f5_loop9);
        this.l_f5_loop10 = (LinearLayout) view.findViewById(R.id.l_f5_loop10);
        this.l_f5_loop11 = (LinearLayout) view.findViewById(R.id.l_f5_loop11);
        this.l_f5_loop12 = (LinearLayout) view.findViewById(R.id.l_f5_loop12);
        this.l_f5_loop13 = (LinearLayout) view.findViewById(R.id.l_f5_loop13);
        this.l_f5_loop14 = (LinearLayout) view.findViewById(R.id.l_f5_loop14);
        this.l_f5_loop15 = (LinearLayout) view.findViewById(R.id.l_f5_loop15);
        this.l_f5_loop16 = (LinearLayout) view.findViewById(R.id.l_f5_loop16);
        this.l_f5_loop17 = (LinearLayout) view.findViewById(R.id.l_f5_loop17);
        this.l_f5_loop18 = (LinearLayout) view.findViewById(R.id.l_f5_loop18);
        this.l_f5_loop19 = (LinearLayout) view.findViewById(R.id.l_f5_loop19);
        this.l_f5_loop20 = (LinearLayout) view.findViewById(R.id.l_f5_loop20);
        this.l_f6_loop1 = (LinearLayout) view.findViewById(R.id.l_f6_loop1);
        this.l_f6_loop2 = (LinearLayout) view.findViewById(R.id.l_f6_loop2);
        this.l_f6_loop3 = (LinearLayout) view.findViewById(R.id.l_f6_loop3);
        this.l_f6_loop4 = (LinearLayout) view.findViewById(R.id.l_f6_loop4);
        this.l_f6_loop5 = (LinearLayout) view.findViewById(R.id.l_f6_loop5);
        this.l_f6_loop6 = (LinearLayout) view.findViewById(R.id.l_f6_loop6);
        this.l_f6_loop7 = (LinearLayout) view.findViewById(R.id.l_f6_loop7);
        this.l_f6_loop8 = (LinearLayout) view.findViewById(R.id.l_f6_loop8);
        this.l_f6_loop9 = (LinearLayout) view.findViewById(R.id.l_f6_loop9);
        this.l_f6_loop10 = (LinearLayout) view.findViewById(R.id.l_f6_loop10);
        this.l_f6_loop11 = (LinearLayout) view.findViewById(R.id.l_f6_loop11);
        this.l_f6_loop12 = (LinearLayout) view.findViewById(R.id.l_f6_loop12);
        this.l_f6_loop13 = (LinearLayout) view.findViewById(R.id.l_f6_loop13);
        this.l_f6_loop14 = (LinearLayout) view.findViewById(R.id.l_f6_loop14);
        this.l_f6_loop15 = (LinearLayout) view.findViewById(R.id.l_f6_loop15);
        this.l_f6_loop16 = (LinearLayout) view.findViewById(R.id.l_f6_loop16);
        this.l_f6_loop17 = (LinearLayout) view.findViewById(R.id.l_f6_loop17);
        this.l_f6_loop18 = (LinearLayout) view.findViewById(R.id.l_f6_loop18);
        this.l_f6_loop19 = (LinearLayout) view.findViewById(R.id.l_f6_loop19);
        this.l_f6_loop20 = (LinearLayout) view.findViewById(R.id.l_f6_loop20);
        this.l_f7_loop1 = (LinearLayout) view.findViewById(R.id.l_f7_loop1);
        this.l_f7_loop2 = (LinearLayout) view.findViewById(R.id.l_f7_loop2);
        this.l_f7_loop3 = (LinearLayout) view.findViewById(R.id.l_f7_loop3);
        this.l_f7_loop4 = (LinearLayout) view.findViewById(R.id.l_f7_loop4);
        this.l_f7_loop5 = (LinearLayout) view.findViewById(R.id.l_f7_loop5);
        this.l_f7_loop6 = (LinearLayout) view.findViewById(R.id.l_f7_loop6);
        this.l_f7_loop7 = (LinearLayout) view.findViewById(R.id.l_f7_loop7);
        this.l_f7_loop8 = (LinearLayout) view.findViewById(R.id.l_f7_loop8);
        this.l_f7_loop9 = (LinearLayout) view.findViewById(R.id.l_f7_loop9);
        this.l_f7_loop10 = (LinearLayout) view.findViewById(R.id.l_f7_loop10);
        this.l_f7_loop11 = (LinearLayout) view.findViewById(R.id.l_f7_loop11);
        this.l_f7_loop12 = (LinearLayout) view.findViewById(R.id.l_f7_loop12);
        this.l_f7_loop13 = (LinearLayout) view.findViewById(R.id.l_f7_loop13);
        this.l_f7_loop14 = (LinearLayout) view.findViewById(R.id.l_f7_loop14);
        this.l_f7_loop15 = (LinearLayout) view.findViewById(R.id.l_f7_loop15);
        this.l_f7_loop16 = (LinearLayout) view.findViewById(R.id.l_f7_loop16);
        this.l_f7_loop17 = (LinearLayout) view.findViewById(R.id.l_f7_loop17);
        this.l_f7_loop18 = (LinearLayout) view.findViewById(R.id.l_f7_loop18);
        this.l_f7_loop19 = (LinearLayout) view.findViewById(R.id.l_f7_loop19);
        this.l_f7_loop20 = (LinearLayout) view.findViewById(R.id.l_f7_loop20);
        this.l_f8_loop1 = (LinearLayout) view.findViewById(R.id.l_f8_loop1);
        this.l_f8_loop2 = (LinearLayout) view.findViewById(R.id.l_f8_loop2);
        this.l_f8_loop3 = (LinearLayout) view.findViewById(R.id.l_f8_loop3);
        this.l_f8_loop4 = (LinearLayout) view.findViewById(R.id.l_f8_loop4);
        this.l_f8_loop5 = (LinearLayout) view.findViewById(R.id.l_f8_loop5);
        this.l_f8_loop6 = (LinearLayout) view.findViewById(R.id.l_f8_loop6);
        this.l_f8_loop7 = (LinearLayout) view.findViewById(R.id.l_f8_loop7);
        this.l_f8_loop8 = (LinearLayout) view.findViewById(R.id.l_f8_loop8);
        this.l_f8_loop9 = (LinearLayout) view.findViewById(R.id.l_f8_loop9);
        this.l_f8_loop10 = (LinearLayout) view.findViewById(R.id.l_f8_loop10);
        this.l_f8_loop11 = (LinearLayout) view.findViewById(R.id.l_f8_loop11);
        this.l_f8_loop12 = (LinearLayout) view.findViewById(R.id.l_f8_loop12);
        this.l_f8_loop13 = (LinearLayout) view.findViewById(R.id.l_f8_loop13);
        this.l_f8_loop14 = (LinearLayout) view.findViewById(R.id.l_f8_loop14);
        this.l_f8_loop15 = (LinearLayout) view.findViewById(R.id.l_f8_loop15);
        this.l_f8_loop16 = (LinearLayout) view.findViewById(R.id.l_f8_loop16);
        this.l_f8_loop17 = (LinearLayout) view.findViewById(R.id.l_f8_loop17);
        this.l_f8_loop18 = (LinearLayout) view.findViewById(R.id.l_f8_loop18);
        this.l_f8_loop19 = (LinearLayout) view.findViewById(R.id.l_f8_loop19);
        this.l_f8_loop20 = (LinearLayout) view.findViewById(R.id.l_f8_loop20);
        this.l_f9_loop1 = (LinearLayout) view.findViewById(R.id.l_f9_loop1);
        this.l_f9_loop2 = (LinearLayout) view.findViewById(R.id.l_f9_loop2);
        this.l_f9_loop3 = (LinearLayout) view.findViewById(R.id.l_f9_loop3);
        this.l_f9_loop4 = (LinearLayout) view.findViewById(R.id.l_f9_loop4);
        this.l_f9_loop5 = (LinearLayout) view.findViewById(R.id.l_f9_loop5);
        this.l_f9_loop6 = (LinearLayout) view.findViewById(R.id.l_f9_loop6);
        this.l_f9_loop7 = (LinearLayout) view.findViewById(R.id.l_f9_loop7);
        this.l_f9_loop8 = (LinearLayout) view.findViewById(R.id.l_f9_loop8);
        this.l_f9_loop9 = (LinearLayout) view.findViewById(R.id.l_f9_loop9);
        this.l_f9_loop10 = (LinearLayout) view.findViewById(R.id.l_f9_loop10);
        this.l_f9_loop11 = (LinearLayout) view.findViewById(R.id.l_f9_loop11);
        this.l_f9_loop12 = (LinearLayout) view.findViewById(R.id.l_f9_loop12);
        this.l_f9_loop13 = (LinearLayout) view.findViewById(R.id.l_f9_loop13);
        this.l_f9_loop14 = (LinearLayout) view.findViewById(R.id.l_f9_loop14);
        this.l_f9_loop15 = (LinearLayout) view.findViewById(R.id.l_f9_loop15);
        this.l_f9_loop16 = (LinearLayout) view.findViewById(R.id.l_f9_loop16);
        this.l_f9_loop17 = (LinearLayout) view.findViewById(R.id.l_f9_loop17);
        this.l_f9_loop18 = (LinearLayout) view.findViewById(R.id.l_f9_loop18);
        this.l_f9_loop19 = (LinearLayout) view.findViewById(R.id.l_f9_loop19);
        this.l_f9_loop20 = (LinearLayout) view.findViewById(R.id.l_f9_loop20);
        this.l_f10_loop1 = (LinearLayout) view.findViewById(R.id.l_f10_loop1);
        this.l_f10_loop2 = (LinearLayout) view.findViewById(R.id.l_f10_loop2);
        this.l_f10_loop3 = (LinearLayout) view.findViewById(R.id.l_f10_loop3);
        this.l_f10_loop4 = (LinearLayout) view.findViewById(R.id.l_f10_loop4);
        this.l_f10_loop5 = (LinearLayout) view.findViewById(R.id.l_f10_loop5);
        this.l_f10_loop6 = (LinearLayout) view.findViewById(R.id.l_f10_loop6);
        this.l_f10_loop7 = (LinearLayout) view.findViewById(R.id.l_f10_loop7);
        this.l_f10_loop8 = (LinearLayout) view.findViewById(R.id.l_f10_loop8);
        this.l_f10_loop9 = (LinearLayout) view.findViewById(R.id.l_f10_loop9);
        this.l_f10_loop10 = (LinearLayout) view.findViewById(R.id.l_f10_loop10);
        this.l_f10_loop11 = (LinearLayout) view.findViewById(R.id.l_f10_loop11);
        this.l_f10_loop12 = (LinearLayout) view.findViewById(R.id.l_f10_loop12);
        this.l_f10_loop13 = (LinearLayout) view.findViewById(R.id.l_f10_loop13);
        this.l_f10_loop14 = (LinearLayout) view.findViewById(R.id.l_f10_loop14);
        this.l_f10_loop15 = (LinearLayout) view.findViewById(R.id.l_f10_loop15);
        this.l_f10_loop16 = (LinearLayout) view.findViewById(R.id.l_f10_loop16);
        this.l_f10_loop17 = (LinearLayout) view.findViewById(R.id.l_f10_loop17);
        this.l_f10_loop18 = (LinearLayout) view.findViewById(R.id.l_f10_loop18);
        this.l_f10_loop19 = (LinearLayout) view.findViewById(R.id.l_f10_loop19);
        this.l_f10_loop20 = (LinearLayout) view.findViewById(R.id.l_f10_loop20);
        this.gif1_1 = (ImageView) view.findViewById(R.id.gif1_1);
        this.gif1_2 = (ImageView) view.findViewById(R.id.gif1_2);
        this.gif1_3 = (ImageView) view.findViewById(R.id.gif1_3);
        this.gif1_4 = (ImageView) view.findViewById(R.id.gif1_4);
        this.gif1_5 = (ImageView) view.findViewById(R.id.gif1_5);
        this.gif1_6 = (ImageView) view.findViewById(R.id.gif1_6);
        this.gif1_7 = (ImageView) view.findViewById(R.id.gif1_7);
        this.gif1_8 = (ImageView) view.findViewById(R.id.gif1_8);
        this.gif1_9 = (ImageView) view.findViewById(R.id.gif1_9);
        this.gif1_10 = (ImageView) view.findViewById(R.id.gif1_10);
        this.gif1_11 = (ImageView) view.findViewById(R.id.gif1_11);
        this.gif1_12 = (ImageView) view.findViewById(R.id.gif1_12);
        this.gif1_13 = (ImageView) view.findViewById(R.id.gif1_13);
        this.gif1_14 = (ImageView) view.findViewById(R.id.gif1_14);
        this.gif1_15 = (ImageView) view.findViewById(R.id.gif1_15);
        this.gif1_16 = (ImageView) view.findViewById(R.id.gif1_16);
        this.gif1_17 = (ImageView) view.findViewById(R.id.gif1_17);
        this.gif1_18 = (ImageView) view.findViewById(R.id.gif1_18);
        this.gif1_19 = (ImageView) view.findViewById(R.id.gif1_19);
        this.gif1_20 = (ImageView) view.findViewById(R.id.gif1_20);
        this.gif2_1 = (ImageView) view.findViewById(R.id.gif2_1);
        this.gif2_2 = (ImageView) view.findViewById(R.id.gif2_2);
        this.gif2_3 = (ImageView) view.findViewById(R.id.gif2_3);
        this.gif2_4 = (ImageView) view.findViewById(R.id.gif2_4);
        this.gif2_5 = (ImageView) view.findViewById(R.id.gif2_5);
        this.gif2_6 = (ImageView) view.findViewById(R.id.gif2_6);
        this.gif2_7 = (ImageView) view.findViewById(R.id.gif2_7);
        this.gif2_8 = (ImageView) view.findViewById(R.id.gif2_8);
        this.gif2_9 = (ImageView) view.findViewById(R.id.gif2_9);
        this.gif2_10 = (ImageView) view.findViewById(R.id.gif2_10);
        this.gif2_11 = (ImageView) view.findViewById(R.id.gif2_11);
        this.gif2_12 = (ImageView) view.findViewById(R.id.gif2_12);
        this.gif2_13 = (ImageView) view.findViewById(R.id.gif2_13);
        this.gif2_14 = (ImageView) view.findViewById(R.id.gif2_14);
        this.gif2_15 = (ImageView) view.findViewById(R.id.gif2_15);
        this.gif2_16 = (ImageView) view.findViewById(R.id.gif2_16);
        this.gif2_17 = (ImageView) view.findViewById(R.id.gif2_17);
        this.gif2_18 = (ImageView) view.findViewById(R.id.gif2_18);
        this.gif2_19 = (ImageView) view.findViewById(R.id.gif2_19);
        this.gif2_20 = (ImageView) view.findViewById(R.id.gif2_20);
        this.gif3_1 = (ImageView) view.findViewById(R.id.gif3_1);
        this.gif3_2 = (ImageView) view.findViewById(R.id.gif3_2);
        this.gif3_3 = (ImageView) view.findViewById(R.id.gif3_3);
        this.gif3_4 = (ImageView) view.findViewById(R.id.gif3_4);
        this.gif3_5 = (ImageView) view.findViewById(R.id.gif3_5);
        this.gif3_6 = (ImageView) view.findViewById(R.id.gif3_6);
        this.gif3_7 = (ImageView) view.findViewById(R.id.gif3_7);
        this.gif3_8 = (ImageView) view.findViewById(R.id.gif3_8);
        this.gif3_9 = (ImageView) view.findViewById(R.id.gif3_9);
        this.gif3_10 = (ImageView) view.findViewById(R.id.gif3_10);
        this.gif3_11 = (ImageView) view.findViewById(R.id.gif3_11);
        this.gif3_12 = (ImageView) view.findViewById(R.id.gif3_12);
        this.gif3_13 = (ImageView) view.findViewById(R.id.gif3_13);
        this.gif3_14 = (ImageView) view.findViewById(R.id.gif3_14);
        this.gif3_15 = (ImageView) view.findViewById(R.id.gif3_15);
        this.gif3_16 = (ImageView) view.findViewById(R.id.gif3_16);
        this.gif3_17 = (ImageView) view.findViewById(R.id.gif3_17);
        this.gif3_18 = (ImageView) view.findViewById(R.id.gif3_18);
        this.gif3_19 = (ImageView) view.findViewById(R.id.gif3_19);
        this.gif3_20 = (ImageView) view.findViewById(R.id.gif3_20);
        this.gif4_1 = (ImageView) view.findViewById(R.id.gif4_1);
        this.gif4_2 = (ImageView) view.findViewById(R.id.gif4_2);
        this.gif4_3 = (ImageView) view.findViewById(R.id.gif4_3);
        this.gif4_4 = (ImageView) view.findViewById(R.id.gif4_4);
        this.gif4_5 = (ImageView) view.findViewById(R.id.gif4_5);
        this.gif4_6 = (ImageView) view.findViewById(R.id.gif4_6);
        this.gif4_7 = (ImageView) view.findViewById(R.id.gif4_7);
        this.gif4_8 = (ImageView) view.findViewById(R.id.gif4_8);
        this.gif4_9 = (ImageView) view.findViewById(R.id.gif4_9);
        this.gif4_10 = (ImageView) view.findViewById(R.id.gif4_10);
        this.gif4_11 = (ImageView) view.findViewById(R.id.gif4_11);
        this.gif4_12 = (ImageView) view.findViewById(R.id.gif4_12);
        this.gif4_13 = (ImageView) view.findViewById(R.id.gif4_13);
        this.gif4_14 = (ImageView) view.findViewById(R.id.gif4_14);
        this.gif4_15 = (ImageView) view.findViewById(R.id.gif4_15);
        this.gif4_16 = (ImageView) view.findViewById(R.id.gif4_16);
        this.gif4_17 = (ImageView) view.findViewById(R.id.gif4_17);
        this.gif4_18 = (ImageView) view.findViewById(R.id.gif4_18);
        this.gif4_19 = (ImageView) view.findViewById(R.id.gif4_19);
        this.gif4_20 = (ImageView) view.findViewById(R.id.gif4_20);
        this.gif5_1 = (ImageView) view.findViewById(R.id.gif5_1);
        this.gif5_2 = (ImageView) view.findViewById(R.id.gif5_2);
        this.gif5_3 = (ImageView) view.findViewById(R.id.gif5_3);
        this.gif5_4 = (ImageView) view.findViewById(R.id.gif5_4);
        this.gif5_5 = (ImageView) view.findViewById(R.id.gif5_5);
        this.gif5_6 = (ImageView) view.findViewById(R.id.gif5_6);
        this.gif5_7 = (ImageView) view.findViewById(R.id.gif5_7);
        this.gif5_8 = (ImageView) view.findViewById(R.id.gif5_8);
        this.gif5_9 = (ImageView) view.findViewById(R.id.gif5_9);
        this.gif5_10 = (ImageView) view.findViewById(R.id.gif5_10);
        this.gif5_11 = (ImageView) view.findViewById(R.id.gif5_11);
        this.gif5_12 = (ImageView) view.findViewById(R.id.gif5_12);
        this.gif5_13 = (ImageView) view.findViewById(R.id.gif5_13);
        this.gif5_14 = (ImageView) view.findViewById(R.id.gif5_14);
        this.gif5_15 = (ImageView) view.findViewById(R.id.gif5_15);
        this.gif5_16 = (ImageView) view.findViewById(R.id.gif5_16);
        this.gif5_17 = (ImageView) view.findViewById(R.id.gif5_17);
        this.gif5_18 = (ImageView) view.findViewById(R.id.gif5_18);
        this.gif5_19 = (ImageView) view.findViewById(R.id.gif5_19);
        this.gif5_20 = (ImageView) view.findViewById(R.id.gif5_20);
        this.gif6_1 = (ImageView) view.findViewById(R.id.gif6_1);
        this.gif6_2 = (ImageView) view.findViewById(R.id.gif6_2);
        this.gif6_3 = (ImageView) view.findViewById(R.id.gif6_3);
        this.gif6_4 = (ImageView) view.findViewById(R.id.gif6_4);
        this.gif6_5 = (ImageView) view.findViewById(R.id.gif6_5);
        this.gif6_6 = (ImageView) view.findViewById(R.id.gif6_6);
        this.gif6_7 = (ImageView) view.findViewById(R.id.gif6_7);
        this.gif6_8 = (ImageView) view.findViewById(R.id.gif6_8);
        this.gif6_9 = (ImageView) view.findViewById(R.id.gif6_9);
        this.gif6_10 = (ImageView) view.findViewById(R.id.gif6_10);
        this.gif6_11 = (ImageView) view.findViewById(R.id.gif6_11);
        this.gif6_12 = (ImageView) view.findViewById(R.id.gif6_12);
        this.gif6_13 = (ImageView) view.findViewById(R.id.gif6_13);
        this.gif6_14 = (ImageView) view.findViewById(R.id.gif6_14);
        this.gif6_15 = (ImageView) view.findViewById(R.id.gif6_15);
        this.gif6_16 = (ImageView) view.findViewById(R.id.gif6_16);
        this.gif6_17 = (ImageView) view.findViewById(R.id.gif6_17);
        this.gif6_18 = (ImageView) view.findViewById(R.id.gif6_18);
        this.gif6_19 = (ImageView) view.findViewById(R.id.gif6_19);
        this.gif6_20 = (ImageView) view.findViewById(R.id.gif6_20);
        this.gif7_1 = (ImageView) view.findViewById(R.id.gif7_1);
        this.gif7_2 = (ImageView) view.findViewById(R.id.gif7_2);
        this.gif7_3 = (ImageView) view.findViewById(R.id.gif7_3);
        this.gif7_4 = (ImageView) view.findViewById(R.id.gif7_4);
        this.gif7_5 = (ImageView) view.findViewById(R.id.gif7_5);
        this.gif7_6 = (ImageView) view.findViewById(R.id.gif7_6);
        this.gif7_7 = (ImageView) view.findViewById(R.id.gif7_7);
        this.gif7_8 = (ImageView) view.findViewById(R.id.gif7_8);
        this.gif7_9 = (ImageView) view.findViewById(R.id.gif7_9);
        this.gif7_10 = (ImageView) view.findViewById(R.id.gif7_10);
        this.gif7_11 = (ImageView) view.findViewById(R.id.gif7_11);
        this.gif7_12 = (ImageView) view.findViewById(R.id.gif7_12);
        this.gif7_13 = (ImageView) view.findViewById(R.id.gif7_13);
        this.gif7_14 = (ImageView) view.findViewById(R.id.gif7_14);
        this.gif7_15 = (ImageView) view.findViewById(R.id.gif7_15);
        this.gif7_16 = (ImageView) view.findViewById(R.id.gif7_16);
        this.gif7_17 = (ImageView) view.findViewById(R.id.gif7_17);
        this.gif7_18 = (ImageView) view.findViewById(R.id.gif7_18);
        this.gif7_19 = (ImageView) view.findViewById(R.id.gif7_19);
        this.gif7_20 = (ImageView) view.findViewById(R.id.gif7_20);
        this.gif8_1 = (ImageView) view.findViewById(R.id.gif8_1);
        this.gif8_2 = (ImageView) view.findViewById(R.id.gif8_2);
        this.gif8_3 = (ImageView) view.findViewById(R.id.gif8_3);
        this.gif8_4 = (ImageView) view.findViewById(R.id.gif8_4);
        this.gif8_5 = (ImageView) view.findViewById(R.id.gif8_5);
        this.gif8_6 = (ImageView) view.findViewById(R.id.gif8_6);
        this.gif8_7 = (ImageView) view.findViewById(R.id.gif8_7);
        this.gif8_8 = (ImageView) view.findViewById(R.id.gif8_8);
        this.gif8_9 = (ImageView) view.findViewById(R.id.gif8_9);
        this.gif8_10 = (ImageView) view.findViewById(R.id.gif8_10);
        this.gif8_11 = (ImageView) view.findViewById(R.id.gif8_11);
        this.gif8_12 = (ImageView) view.findViewById(R.id.gif8_12);
        this.gif8_13 = (ImageView) view.findViewById(R.id.gif8_13);
        this.gif8_14 = (ImageView) view.findViewById(R.id.gif8_14);
        this.gif8_15 = (ImageView) view.findViewById(R.id.gif8_15);
        this.gif8_16 = (ImageView) view.findViewById(R.id.gif8_16);
        this.gif8_17 = (ImageView) view.findViewById(R.id.gif8_17);
        this.gif8_18 = (ImageView) view.findViewById(R.id.gif8_18);
        this.gif8_19 = (ImageView) view.findViewById(R.id.gif8_19);
        this.gif8_20 = (ImageView) view.findViewById(R.id.gif8_20);
        this.gif9_1 = (ImageView) view.findViewById(R.id.gif9_1);
        this.gif9_2 = (ImageView) view.findViewById(R.id.gif9_2);
        this.gif9_3 = (ImageView) view.findViewById(R.id.gif9_3);
        this.gif9_4 = (ImageView) view.findViewById(R.id.gif9_4);
        this.gif9_5 = (ImageView) view.findViewById(R.id.gif9_5);
        this.gif9_6 = (ImageView) view.findViewById(R.id.gif9_6);
        this.gif9_7 = (ImageView) view.findViewById(R.id.gif9_7);
        this.gif9_8 = (ImageView) view.findViewById(R.id.gif9_8);
        this.gif9_9 = (ImageView) view.findViewById(R.id.gif9_9);
        this.gif9_10 = (ImageView) view.findViewById(R.id.gif9_10);
        this.gif9_11 = (ImageView) view.findViewById(R.id.gif9_11);
        this.gif9_12 = (ImageView) view.findViewById(R.id.gif9_12);
        this.gif9_13 = (ImageView) view.findViewById(R.id.gif9_13);
        this.gif9_14 = (ImageView) view.findViewById(R.id.gif9_14);
        this.gif9_15 = (ImageView) view.findViewById(R.id.gif9_15);
        this.gif9_16 = (ImageView) view.findViewById(R.id.gif9_16);
        this.gif9_17 = (ImageView) view.findViewById(R.id.gif9_17);
        this.gif9_18 = (ImageView) view.findViewById(R.id.gif9_18);
        this.gif9_19 = (ImageView) view.findViewById(R.id.gif9_19);
        this.gif9_20 = (ImageView) view.findViewById(R.id.gif9_20);
        this.gif10_1 = (ImageView) view.findViewById(R.id.gif10_1);
        this.gif10_2 = (ImageView) view.findViewById(R.id.gif10_2);
        this.gif10_3 = (ImageView) view.findViewById(R.id.gif10_3);
        this.gif10_4 = (ImageView) view.findViewById(R.id.gif10_4);
        this.gif10_5 = (ImageView) view.findViewById(R.id.gif10_5);
        this.gif10_6 = (ImageView) view.findViewById(R.id.gif10_6);
        this.gif10_7 = (ImageView) view.findViewById(R.id.gif10_7);
        this.gif10_8 = (ImageView) view.findViewById(R.id.gif10_8);
        this.gif10_9 = (ImageView) view.findViewById(R.id.gif10_9);
        this.gif10_10 = (ImageView) view.findViewById(R.id.gif10_10);
        this.gif10_11 = (ImageView) view.findViewById(R.id.gif10_11);
        this.gif10_12 = (ImageView) view.findViewById(R.id.gif10_12);
        this.gif10_13 = (ImageView) view.findViewById(R.id.gif10_13);
        this.gif10_14 = (ImageView) view.findViewById(R.id.gif10_14);
        this.gif10_15 = (ImageView) view.findViewById(R.id.gif10_15);
        this.gif10_16 = (ImageView) view.findViewById(R.id.gif10_16);
        this.gif10_17 = (ImageView) view.findViewById(R.id.gif10_17);
        this.gif10_18 = (ImageView) view.findViewById(R.id.gif10_18);
        this.gif10_19 = (ImageView) view.findViewById(R.id.gif10_19);
        this.gif10_20 = (ImageView) view.findViewById(R.id.gif10_20);
    }

    public void updateVolumeMedia1(float f) {
        MediaPlayer mediaPlayer = this.mediaPlayer1;
        if (mediaPlayer != null) {
            mediaPlayer.setVolume(f, f);
        }
    }

    public void updateVolumeMedia2(float f) {
        MediaPlayer mediaPlayer = this.mediaPlayer5;
        if (mediaPlayer != null) {
            mediaPlayer.setVolume(f, f);
        }
    }

    public void updateVolumeMedia3(float f) {
        MediaPlayer mediaPlayer = this.mediaPlayer9;
        if (mediaPlayer != null) {
            mediaPlayer.setVolume(f, f);
        }
    }

    public void updateVolumeMedia4(float f) {
        MediaPlayer mediaPlayer = this.mediaPlayer13;
        if (mediaPlayer != null) {
            mediaPlayer.setVolume(f, f);
        }
    }

    public void updateVolumeMedia5(float f) {
        MediaPlayer mediaPlayer = this.mediaPlayer17;
        if (mediaPlayer != null) {
            mediaPlayer.setVolume(f, f);
        }
    }
}
