package com.djmusicmixer.djmixer.audiomixer.mixer;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.viewpager.widget.ViewPager;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;
import com.djmusicmixer.djmixer.audiomixer.mixer.Adapter.MusicLibraryPagerAdapter;
import com.djmusicmixer.djmixer.audiomixer.mixer.Utils.PreferenceUtil;
import com.google.android.material.tabs.TabLayout;

public class LibraryActivity extends BaseActivity implements TabLayout.OnTabSelectedListener, View.OnClickListener {
    public static Activity activity;
    public static MediaPlayer mediaPlayer;
    public static LibraryActivity musicLibraryActivity;
    protected ImageView iv_back;
    protected ImageView iv_search;
    private TabLayout library_tabs;
    protected MusicLibraryPagerAdapter musicLibraryPagerAdapter;
    private ViewPager viewPager;

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {

    }

    @Override
    public void onCreate(Bundle bundle) {
        
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        setContentView(R.layout.activity_rkappzia_music_library);

        musicLibraryActivity = this;
        mediaPlayer = new MediaPlayer();
        init();
        bindView();
    }

    private void init() {
        this.iv_back = (ImageView) findViewById(R.id.iv_back);
        this.iv_search = (ImageView) findViewById(R.id.iv_search_rkappzia);
        this.library_tabs = (TabLayout) findViewById(R.id.library_tabs);
        this.viewPager = (ViewPager) findViewById(R.id.viewPager);
    }

    private void bindView() {
        TabLayout tabLayout = this.library_tabs;
        tabLayout.addTab(tabLayout.newTab().setText(getResources().getString(R.string.Playlists)));
        MusicLibraryPagerAdapter musicLibraryPagerAdapter2 = new MusicLibraryPagerAdapter(getSupportFragmentManager(), this.library_tabs.getTabCount());
        this.musicLibraryPagerAdapter = musicLibraryPagerAdapter2;
        this.viewPager.setAdapter(musicLibraryPagerAdapter2);
        this.viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(this.library_tabs));
        if (PreferenceUtil.getInstance(this).rememberLastTab()) {
            this.viewPager.setCurrentItem(PreferenceUtil.getInstance(this).getLastPage());
            TabLayout tabLayout6 = this.library_tabs;
            tabLayout6.selectTab(tabLayout6.getTabAt(this.viewPager.getCurrentItem()));
        }
        this.library_tabs.addOnTabSelectedListener((TabLayout.OnTabSelectedListener) this);
    }

    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        this.viewPager.setCurrentItem(tab.getPosition());
        PreferenceUtil.getInstance(this).setLastPage(tab.getPosition());
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.iv_back) {
            onBackPressed();
        } else if (id == R.id.iv_search_rkappzia) {
            startActivityForResult(new Intent(this, SearchLibraryActivity.class), 1);
        }
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i2 == -1 && i == 1 && intent != null) {
            setResult(-1, intent);
            finish();
        }
    }
}
