package com.djmusicmixer.djmixer.audiomixer.mixer;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;
import com.djmusicmixer.djmixer.audiomixer.mixer.Fragment.LibSongsAdapter;
import com.djmusicmixer.djmixer.audiomixer.mixer.Loader.PlaylistSongLoader;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Playlist;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.PlaylistSong;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Songs;
import com.djmusicmixer.djmixer.audiomixer.mixer.Utils.MusicUtil;
import com.djmusicmixer.djmixer.audiomixer.mixer.Utils.PlaylistUtil;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;

public class PlaylistDetailsActivity extends BaseActivity {
    public static Activity activity;
    private LinearLayout adViewFB;
    public ProgressDialog ad_dialog;
    public Intent ad_intent;
    RelativeLayout adsLayout;
    LinearLayout linearAdsnative;
    private Playlist playlist;
    protected ArrayList<Songs> playlistSongs = new ArrayList<>();
    private RecyclerView recyclerView;
    protected LibSongsAdapter songsAdapter;
    protected ArrayList<Songs> songsList = new ArrayList<>();
    private TextView tv_empty;
    protected TextView tv_title;

    public Bundle getNonPersonalizedAdsBundle() {
        Bundle bundle = new Bundle();
        bundle.putString("npa", "1");
        return bundle;
    }

    @Override
    public void onCreate(Bundle bundle) {
        
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        setContentView(R.layout.activity_rkappzia_playlist_details);
        init();
    }

    private void init() {
        this.tv_title = (TextView) findViewById(R.id.tv_title_rkappzia);
        this.recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        this.tv_empty = (TextView) findViewById(R.id.tv_empty);
        Bundle extras = getIntent().getExtras();
        Objects.requireNonNull(extras);
        Playlist playlist2 = (Playlist) extras.getParcelable("playList");
        this.playlist = playlist2;
        if (playlist2 != null) {
            this.tv_title.setText(playlist2.name);
        }
        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            /* class com.djmusicmixer.djmixer.audiomixer.mixer.PlaylistDetailsActivity.AnonymousClass1 */

            public void onClick(View view) {
                getInstance(PlaylistDetailsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        PlaylistDetailsActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);

            }
        });
    }

    public void setAdapter() {
        ArrayList<Songs> playlistSongList = PlaylistSongLoader.getPlaylistSongList(getApplicationContext(), this.playlist.f188id);
        this.playlistSongs = playlistSongList;
        this.songsList = playlistSongList;
        int i = 8;
        this.tv_empty.setVisibility(playlistSongList.size() > 0 ? View.GONE : View.VISIBLE);
        if (this.songsList.size() > 0) {
            i = 0;
        }
        this.recyclerView.setVisibility(i);
        if (this.songsList.size() > 0) {
            this.recyclerView.setHasFixedSize(true);
            this.recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
            LibSongsAdapter libSongsAdapter = new LibSongsAdapter(this, this.songsList, "playlist");
            this.songsAdapter = libSongsAdapter;
            this.recyclerView.setAdapter(libSongsAdapter);
        }
    }

    public void onPlaylistSongsClick(final int i, View view, String str, boolean z) {
        if (str.equals("more")) {
            PopupMenu popupMenu = new PopupMenu(new ContextThemeWrapper(this, (int) R.style.PopupDialogTheme), view);
            popupMenu.getMenuInflater().inflate(R.menu.menu_playlist_item_more_rk, popupMenu.getMenu());
            popupMenu.show();
            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                public boolean onMenuItemClick(MenuItem menuItem) {
                    if (menuItem.getItemId() == R.id.remove_from_playlist) {
                        PlaylistDetailsActivity.this.removeFromPlaylistDialog(i);
                        return true;
                    } else if (menuItem.getItemId() != R.id.add_to_playlist) {
                        return true;
                    } else {
                        PlaylistDetailsActivity playlistDetailsActivity = PlaylistDetailsActivity.this;
                        BaseActivity.addToPlaylistDialog(playlistDetailsActivity, playlistDetailsActivity.songsList.get(i));
                        return true;
                    }
                }
            });
            return;
        }
        Uri albumCoverUri = MusicUtil.getAlbumCoverUri(this.songsList.get(i).albumId);
        Intent intent = new Intent();
        intent.putExtra("selected_music_path", this.songsList.get(i).data);
        intent.putExtra("selected_music_name", this.songsList.get(i).title);
        intent.putExtra("selected_music_album", albumCoverUri.toString());
        setResult(-1, intent);
        finish();
    }

    public void removeFromPlaylistDialog(final int i) {
        final Dialog dialog = new Dialog(this, R.style.DialogTheme2);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.remove_playlist_dialog);
        Window window = dialog.getWindow();
        Objects.requireNonNull(window);
        window.setBackgroundDrawable(new ColorDrawable(0));
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        ((TextView) dialog.findViewById(R.id.tv_title_rkappzia)).setText(this.songsList.get(i).title);
        ((TextView) dialog.findViewById(R.id.tv_des)).setText("remove this song from Playlist ?");
        dialog.findViewById(R.id.tv_delete_rkappzia).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                PlaylistUtil.removeFromPlaylist(PlaylistDetailsActivity.this, new ArrayList(Collections.singleton((PlaylistSong) PlaylistDetailsActivity.this.songsList.get(i))));
                PlaylistDetailsActivity.this.setAdapter();
                dialog.dismiss();
            }
        });
        dialog.findViewById(R.id.tv_cancel_rkappzia).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    @Override 
    public void onResume() {
        setAdapter();
        super.onResume();
    }
}
