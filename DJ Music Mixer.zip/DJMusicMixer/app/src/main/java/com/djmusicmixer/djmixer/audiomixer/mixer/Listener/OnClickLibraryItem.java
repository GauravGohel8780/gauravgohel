package com.djmusicmixer.djmixer.audiomixer.mixer.Listener;

public interface OnClickLibraryItem {
    void onClickSongsItem(long j);
}
