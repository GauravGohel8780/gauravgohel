package com.djmusicmixer.djmixer.audiomixer.mixer.Model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class Album implements Parcelable {
    public static final Creator<Album> CREATOR = new Creator<Album>() {
        @Override
        public Album createFromParcel(Parcel parcel) {
            return new Album(parcel);
        }

        @Override
        public Album[] newArray(int i) {
            return new Album[i];
        }
    };
    public final ArrayList<Songs> songs;

    public int describeContents() {
        return 0;
    }

    public Album(ArrayList<Songs> arrayList) {
        this.songs = arrayList;
    }

    public Album() {
        this.songs = new ArrayList<>();
    }

    public Songs getFirstSong() {
        return this.songs.isEmpty() ? Songs.empty_songs : this.songs.get(0);
    }

    public long getId() {
        return getFirstSong().albumId;
    }

    public String getTitle() {
        return getFirstSong().albumName;
    }

    public long getArtistId() {
        return getFirstSong().artistId;
    }

    public String getArtistName() {
        return getFirstSong().artistName;
    }

    public int getYear() {
        return getFirstSong().year;
    }

    public long getDateModified() {
        return getFirstSong().dateModified;
    }

    public int getSongCount() {
        return this.songs.size();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass()) {
            ArrayList<Songs> arrayList = this.songs;
            ArrayList<Songs> arrayList2 = ((Album) obj).songs;
            if (arrayList != null) {
                return arrayList.equals(arrayList2);
            }
            if (arrayList2 == null) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        ArrayList<Songs> arrayList = this.songs;
        if (arrayList != null) {
            return arrayList.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "Album{songs=" + this.songs + '}';
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeTypedList(this.songs);
    }

    protected Album(Parcel parcel) {
        this.songs = parcel.createTypedArrayList(Songs.CREATOR);
    }
}
