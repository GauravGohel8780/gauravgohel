package com.djmusicmixer.djmixer.audiomixer.Addmodul;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.base.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;

public class DrumDemoActivity5 extends BaseActivity implements View.OnClickListener {
    Context context;
    ImageView f221A;
    ImageView f222B;
    LinearLayout f223C;
    MediaPlayer.OnCompletionListener f224D = new MediaPlayer.OnCompletionListener() {
        public void onCompletion(MediaPlayer mediaPlayer) {
            DrumDemoActivity5.this.f226F.setImageResource(R.drawable.ic_play_music_drums);
            DrumDemoActivity5.this.f243W = false;
        }
    };
    MediaPlayer.OnPreparedListener f225E = new MediaPlayer.OnPreparedListener() {
        public void onPrepared(MediaPlayer mediaPlayer) {
            DrumDemoActivity5.this.f243W = true;
        }
    };
    ImageView f226F;
    MediaPlayer f227G;
    MediaPlayer f228H;
    MediaPlayer f229I;
    MediaPlayer f230J;
    MediaPlayer f231K;
    MediaPlayer f232L;
    MediaPlayer f233M;
    MediaPlayer f234N;
    MediaPlayer f235O;
    MediaPlayer f236P;
    MediaPlayer f237Q;
    MediaPlayer f238R1;
    MediaPlayer f239S;
    MediaPlayer f240T;
    MediaPlayer f241U;
    MediaPlayer f242V;
    public boolean f243W = false;
    public MediaPlayer f244X = new MediaPlayer();
    float f245k = 1.0f;
    MediaPlayer.OnErrorListener f246l = new MediaPlayer.OnErrorListener() {
        public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
            DrumDemoActivity5.this.f226F.setImageResource(R.drawable.ic_play_music_drums);
            DrumDemoActivity5.this.f243W = false;
            return false;
        }
    };
    ImageView f247m;
    ImageView f248n;
    ImageView f249o;
    ImageView f250p;
    ImageView f251q;
    ImageView f252r;
    ImageView f253s;
    ImageView f254t;
    ImageView f255u;
    ImageView f256v;
    ImageView f257w;
    ImageView f258x;
    ImageView f259y;
    ImageView f260z;

    public void mo17359a(String str) {
        mo17361l();
        try {
            this.f244X.setDataSource(str);
            this.f244X.prepare();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void mo17360k() {
        if (this.f243W) {
            this.f244X.start();
            this.f226F.setImageResource(R.drawable.ic_pause_music_drums);
            return;
        }
        Toast.makeText(this, (int) R.string.Please_Select_Spark_Song, Toast.LENGTH_SHORT).show();
    }

    public void mo17361l() {
        this.f243W = false;
        if (this.f244X.isPlaying()) {
            this.f244X.stop();
        }
        this.f244X.reset();
    }

    public void mo17362m() {
        this.f244X.pause();
        this.f226F.setImageResource(R.drawable.ic_play_music_drums);
    }

    public void mo17363n() {
        this.f244X.stop();
        this.f226F.setImageResource(R.drawable.ic_play_music_drums);
    }

    public void mo17364o() {
        if (this.f244X.isPlaying()) {
            this.f244X.stop();
        }
        this.f244X.reset();
        this.f244X.release();
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 0 && i2 == -1) {
            mo17359a(intent.getStringExtra("song_uri"));
        }
    }

    @Override
    public void onDestroy() {
        mo17364o();
        super.onDestroy();
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        MediaPlayer mediaPlayer = this.f227G;
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            this.f227G.release();
            this.f227G = null;
        }
        MediaPlayer mediaPlayer2 = this.f235O;
        if (mediaPlayer2 != null) {
            mediaPlayer2.stop();
            this.f235O.release();
            this.f235O = null;
        }
        MediaPlayer mediaPlayer3 = this.f236P;
        if (mediaPlayer3 != null) {
            mediaPlayer3.stop();
            this.f236P.release();
            this.f236P = null;
        }
        MediaPlayer mediaPlayer4 = this.f237Q;
        if (mediaPlayer4 != null) {
            mediaPlayer4.stop();
            this.f237Q.release();
            this.f237Q = null;
        }
        MediaPlayer mediaPlayer5 = this.f238R1;
        if (mediaPlayer5 != null) {
            mediaPlayer5.stop();
            this.f238R1.release();
            this.f238R1 = null;
        }
        MediaPlayer mediaPlayer6 = this.f239S;
        if (mediaPlayer6 != null) {
            mediaPlayer6.stop();
            this.f239S.release();
            this.f239S = null;
        }
        MediaPlayer mediaPlayer7 = this.f240T;
        if (mediaPlayer7 != null) {
            mediaPlayer7.stop();
            this.f240T.release();
            this.f240T = null;
        }
        MediaPlayer mediaPlayer8 = this.f241U;
        if (mediaPlayer8 != null) {
            mediaPlayer8.stop();
            this.f241U.release();
            this.f241U = null;
        }
        MediaPlayer mediaPlayer9 = this.f242V;
        if (mediaPlayer9 != null) {
            mediaPlayer9.stop();
            this.f242V.release();
            this.f242V = null;
        }
        MediaPlayer mediaPlayer10 = this.f228H;
        if (mediaPlayer10 != null) {
            mediaPlayer10.stop();
            this.f228H.release();
            this.f228H = null;
        }
        MediaPlayer mediaPlayer11 = this.f229I;
        if (mediaPlayer11 != null) {
            mediaPlayer11.stop();
            this.f229I.release();
            this.f229I = null;
        }
        MediaPlayer mediaPlayer12 = this.f230J;
        if (mediaPlayer12 != null) {
            mediaPlayer12.stop();
            this.f230J.release();
            this.f230J = null;
        }
        MediaPlayer mediaPlayer13 = this.f231K;
        if (mediaPlayer13 != null) {
            mediaPlayer13.stop();
            this.f231K.release();
            this.f231K = null;
        }
        MediaPlayer mediaPlayer14 = this.f232L;
        if (mediaPlayer14 != null) {
            mediaPlayer14.stop();
            this.f232L.release();
            this.f232L = null;
        }
        MediaPlayer mediaPlayer15 = this.f233M;
        if (mediaPlayer15 != null) {
            mediaPlayer15.stop();
            this.f233M.release();
            this.f233M = null;
        }
        MediaPlayer mediaPlayer16 = this.f234N;
        if (mediaPlayer16 != null) {
            mediaPlayer16.stop();
            this.f234N.release();
            this.f234N = null;
        }
        finish();
    }

    public void onClick(View view) {
        MediaPlayer mediaPlayer;
        switch (view.getId()) {
            case R.id.lbl1:
                MediaPlayer mediaPlayer2 = this.f227G;
                if (mediaPlayer2 != null) {
                    mediaPlayer2.stop();
                    this.f227G.release();
                }
                MediaPlayer create = MediaPlayer.create(this, (int) R.raw.hh1);
                this.f227G = create;
                float f = this.f245k;
                create.setVolume(f, f);
                mediaPlayer = this.f227G;
                break;
            case R.id.lbl10:
                MediaPlayer mediaPlayer3 = this.f228H;
                if (mediaPlayer3 != null) {
                    mediaPlayer3.stop();
                    this.f228H.release();
                }
                MediaPlayer create2 = MediaPlayer.create(this, (int) R.raw.hh10);
                this.f228H = create2;
                float f2 = this.f245k;
                create2.setVolume(f2, f2);
                mediaPlayer = this.f228H;
                break;
            case R.id.lbl11:
                MediaPlayer mediaPlayer4 = this.f229I;
                if (mediaPlayer4 != null) {
                    mediaPlayer4.stop();
                    this.f229I.release();
                }
                MediaPlayer create3 = MediaPlayer.create(this, (int) R.raw.hh11);
                this.f229I = create3;
                float f3 = this.f245k;
                create3.setVolume(f3, f3);
                mediaPlayer = this.f229I;
                break;
            case R.id.lbl12:
                MediaPlayer mediaPlayer5 = this.f230J;
                if (mediaPlayer5 != null) {
                    mediaPlayer5.stop();
                    this.f230J.release();
                }
                MediaPlayer create4 = MediaPlayer.create(this, (int) R.raw.hh12);
                this.f230J = create4;
                float f4 = this.f245k;
                create4.setVolume(f4, f4);
                mediaPlayer = this.f230J;
                break;
            case R.id.lbl13:
                MediaPlayer mediaPlayer6 = this.f231K;
                if (mediaPlayer6 != null) {
                    mediaPlayer6.stop();
                    this.f231K.release();
                }
                MediaPlayer create5 = MediaPlayer.create(this, (int) R.raw.hh13);
                this.f231K = create5;
                float f5 = this.f245k;
                create5.setVolume(f5, f5);
                mediaPlayer = this.f231K;
                break;
            case R.id.lbl14:
                MediaPlayer mediaPlayer7 = this.f232L;
                if (mediaPlayer7 != null) {
                    mediaPlayer7.stop();
                    this.f232L.release();
                }
                MediaPlayer create6 = MediaPlayer.create(this, (int) R.raw.hh14);
                this.f232L = create6;
                float f6 = this.f245k;
                create6.setVolume(f6, f6);
                mediaPlayer = this.f232L;
                break;
            case R.id.lbl15:
                MediaPlayer mediaPlayer8 = this.f233M;
                if (mediaPlayer8 != null) {
                    mediaPlayer8.stop();
                    this.f233M.release();
                }
                MediaPlayer create7 = MediaPlayer.create(this, (int) R.raw.hh15);
                this.f233M = create7;
                float f7 = this.f245k;
                create7.setVolume(f7, f7);
                mediaPlayer = this.f233M;
                break;
            case R.id.lbl16:
                MediaPlayer mediaPlayer9 = this.f234N;
                if (mediaPlayer9 != null) {
                    mediaPlayer9.stop();
                    this.f234N.release();
                }
                MediaPlayer create8 = MediaPlayer.create(this, (int) R.raw.hh16);
                this.f234N = create8;
                float f8 = this.f245k;
                create8.setVolume(f8, f8);
                mediaPlayer = this.f234N;
                break;
            case R.id.lbl2:
                MediaPlayer mediaPlayer10 = this.f235O;
                if (mediaPlayer10 != null) {
                    mediaPlayer10.stop();
                    this.f235O.release();
                }
                MediaPlayer create9 = MediaPlayer.create(this, (int) R.raw.hh2);
                this.f235O = create9;
                float f9 = this.f245k;
                create9.setVolume(f9, f9);
                mediaPlayer = this.f235O;
                break;
            case R.id.lbl3:
                MediaPlayer mediaPlayer11 = this.f236P;
                if (mediaPlayer11 != null) {
                    mediaPlayer11.stop();
                    this.f236P.release();
                }
                MediaPlayer create10 = MediaPlayer.create(this, (int) R.raw.hh3);
                this.f236P = create10;
                float f10 = this.f245k;
                create10.setVolume(f10, f10);
                mediaPlayer = this.f236P;
                break;
            case R.id.lbl4:
                MediaPlayer mediaPlayer12 = this.f237Q;
                if (mediaPlayer12 != null) {
                    mediaPlayer12.stop();
                    this.f237Q.release();
                }
                MediaPlayer create11 = MediaPlayer.create(this, (int) R.raw.hh4);
                this.f237Q = create11;
                float f11 = this.f245k;
                create11.setVolume(f11, f11);
                mediaPlayer = this.f237Q;
                break;
            case R.id.lbl5:
                MediaPlayer mediaPlayer13 = this.f238R1;
                if (mediaPlayer13 != null) {
                    mediaPlayer13.stop();
                    this.f238R1.release();
                }
                MediaPlayer create12 = MediaPlayer.create(this, (int) R.raw.hh5);
                this.f238R1 = create12;
                float f12 = this.f245k;
                create12.setVolume(f12, f12);
                mediaPlayer = this.f238R1;
                break;
            case R.id.lbl6:
                MediaPlayer mediaPlayer14 = this.f239S;
                if (mediaPlayer14 != null) {
                    mediaPlayer14.stop();
                    this.f239S.release();
                }
                MediaPlayer create13 = MediaPlayer.create(this, (int) R.raw.hh6);
                this.f239S = create13;
                float f13 = this.f245k;
                create13.setVolume(f13, f13);
                mediaPlayer = this.f239S;
                break;
            case R.id.lbl7:
                MediaPlayer mediaPlayer15 = this.f240T;
                if (mediaPlayer15 != null) {
                    mediaPlayer15.stop();
                    this.f240T.release();
                }
                MediaPlayer create14 = MediaPlayer.create(this, (int) R.raw.hh7);
                this.f240T = create14;
                float f14 = this.f245k;
                create14.setVolume(f14, f14);
                mediaPlayer = this.f240T;
                break;
            case R.id.lbl8:
                MediaPlayer mediaPlayer16 = this.f241U;
                if (mediaPlayer16 != null) {
                    mediaPlayer16.stop();
                    this.f241U.release();
                }
                MediaPlayer create15 = MediaPlayer.create(this, (int) R.raw.hh8);
                this.f241U = create15;
                float f15 = this.f245k;
                create15.setVolume(f15, f15);
                mediaPlayer = this.f241U;
                break;
            case R.id.lbl9:
                MediaPlayer mediaPlayer17 = this.f242V;
                if (mediaPlayer17 != null) {
                    mediaPlayer17.stop();
                    this.f242V.release();
                }
                MediaPlayer create16 = MediaPlayer.create(this, (int) R.raw.hh9);
                this.f242V = create16;
                float f16 = this.f245k;
                create16.setVolume(f16, f16);
                mediaPlayer = this.f242V;
                break;
            default:
                return;
        }
        mediaPlayer.start();
    }

    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        
        super.onCreate(bundle);
        setContentView(R.layout.activity_drum_demo5);


        this.context = this;
        findViewById(R.id.lbltitle1).setSelected(true);
        findViewById(R.id.back4).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumDemoActivity5.this.onBackPressed();
            }
        });
        this.f247m = (ImageView) findViewById(R.id.lbl1);
        this.f255u = (ImageView) findViewById(R.id.lbl2);
        this.f256v = (ImageView) findViewById(R.id.lbl3);
        this.f257w = (ImageView) findViewById(R.id.lbl4);
        this.f258x = (ImageView) findViewById(R.id.lbl5);
        this.f259y = (ImageView) findViewById(R.id.lbl6);
        this.f260z = (ImageView) findViewById(R.id.lbl7);
        this.f221A = (ImageView) findViewById(R.id.lbl8);
        this.f222B = (ImageView) findViewById(R.id.lbl9);
        this.f248n = (ImageView) findViewById(R.id.lbl10);
        this.f249o = (ImageView) findViewById(R.id.lbl11);
        this.f250p = (ImageView) findViewById(R.id.lbl12);
        this.f251q = (ImageView) findViewById(R.id.lbl13);
        this.f252r = (ImageView) findViewById(R.id.lbl14);
        this.f253s = (ImageView) findViewById(R.id.lbl15);
        this.f254t = (ImageView) findViewById(R.id.lbl16);
        this.f247m.setOnClickListener(this);
        this.f255u.setOnClickListener(this);
        this.f256v.setOnClickListener(this);
        this.f257w.setOnClickListener(this);
        this.f258x.setOnClickListener(this);
        this.f259y.setOnClickListener(this);
        this.f260z.setOnClickListener(this);
        this.f221A.setOnClickListener(this);
        this.f222B.setOnClickListener(this);
        this.f248n.setOnClickListener(this);
        this.f249o.setOnClickListener(this);
        this.f250p.setOnClickListener(this);
        this.f251q.setOnClickListener(this);
        this.f252r.setOnClickListener(this);
        this.f253s.setOnClickListener(this);
        this.f254t.setOnClickListener(this);
        this.f227G = MediaPlayer.create(this, (int) R.raw.hh1);
        this.f235O = MediaPlayer.create(this, (int) R.raw.hh2);
        this.f236P = MediaPlayer.create(this, (int) R.raw.hh3);
        this.f237Q = MediaPlayer.create(this, (int) R.raw.hh4);
        this.f238R1 = MediaPlayer.create(this, (int) R.raw.hh5);
        this.f239S = MediaPlayer.create(this, (int) R.raw.hh6);
        this.f240T = MediaPlayer.create(this, (int) R.raw.hh7);
        this.f241U = MediaPlayer.create(this, (int) R.raw.hh8);
        this.f242V = MediaPlayer.create(this, (int) R.raw.hh9);
        this.f228H = MediaPlayer.create(this, (int) R.raw.hh10);
        this.f229I = MediaPlayer.create(this, (int) R.raw.hh11);
        this.f230J = MediaPlayer.create(this, (int) R.raw.hh12);
        this.f231K = MediaPlayer.create(this, (int) R.raw.hh13);
        this.f232L = MediaPlayer.create(this, (int) R.raw.hh14);
        this.f233M = MediaPlayer.create(this, (int) R.raw.hh15);
        this.f234N = MediaPlayer.create(this, (int) R.raw.hh16);
        this.f244X.setOnPreparedListener(this.f225E);
        this.f244X.setOnErrorListener(this.f246l);
        this.f244X.setOnCompletionListener(this.f224D);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.load_song);
        this.f223C = linearLayout;
        linearLayout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumDemoActivity5.this.CallIntent(1);
            }
        });
        ImageView imageView = (ImageView) findViewById(R.id.play_song);
        this.f226F = imageView;
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity5.this.f244X.isPlaying()) {
                    DrumDemoActivity5.this.mo17362m();
                } else {
                    DrumDemoActivity5.this.mo17360k();
                }
            }
        });
        ((ImageView) findViewById(R.id.back4)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumDemoActivity5.this.onBackPressed();
            }
        });
    }

    public void CallIntent(int i) {
        if (i == 1) {
            if (this.f244X.isPlaying()) {
                mo17363n();
            } else {
                startActivityForResult(new Intent(this, SongPickerActivity.class), 0);
            }
        }
    }
}
