package com.djmusicmixer.djmixer.audiomixer.Drums;

public class SampleSlot {
    public static final String DELIMITER = "#";
    public int drumId;
    public long playNextAfterMs;
    public int soundIndex;

    public String toString() {
        return "SampleSlot [drumId=" + this.drumId + ", soundIndex=" + this.soundIndex + ", playNextAfterMs=" + this.playNextAfterMs + "]";
    }

    public String getSerializableString() {
        return this.drumId + DELIMITER + this.soundIndex + DELIMITER + this.playNextAfterMs;
    }

    public static SampleSlot createFromSerializableString(String str) {
        String[] split = str.split(DELIMITER);
        SampleSlot cNX_SampleSlot = new SampleSlot();
        cNX_SampleSlot.drumId = Integer.parseInt(split[0]);
        cNX_SampleSlot.soundIndex = Integer.parseInt(split[1]);
        cNX_SampleSlot.playNextAfterMs = Long.parseLong(split[2]);
        return cNX_SampleSlot;
    }
}
