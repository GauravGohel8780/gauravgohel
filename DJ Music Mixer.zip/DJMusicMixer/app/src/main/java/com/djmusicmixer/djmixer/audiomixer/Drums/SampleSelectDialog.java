package com.djmusicmixer.djmixer.audiomixer.Drums;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;

import java.io.File;

public class SampleSelectDialog extends Dialog {
    private SampleListAdapter adapter = new SampleListAdapter(getLayoutInflater());
    private ListView listView;

    public SampleSelectDialog(Context context) {
        super(context);
        SystemUtils.setLocale(context);
        setContentView(R.layout.dialog_sample_files_list);
        getWindow().setFlags(1024, 1024);
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams((getContext().getResources().getDisplayMetrics().widthPixels * 1039) / 1920, (getContext().getResources().getDisplayMetrics().heightPixels * 900) / 1080);
        layoutParams.gravity = 17;
        this.listView = (ListView) findViewById(R.id.listView);
        ((LinearLayout) findViewById(R.id.layout)).setLayoutParams(layoutParams);
        this.listView.setAdapter((ListAdapter) this.adapter);
    }

    public void setFiles(File[] fileArr) {
        this.adapter.setFiles(fileArr);
        this.adapter.notifyDataSetChanged();
    }

    public void setDeleteListener(View.OnClickListener onClickListener) {
        this.adapter.setDeleteListener(onClickListener);
    }

    public void setonItemListener(AdapterView.OnItemClickListener onItemClickListener) {
        this.listView.setOnItemClickListener(onItemClickListener);
    }
}
