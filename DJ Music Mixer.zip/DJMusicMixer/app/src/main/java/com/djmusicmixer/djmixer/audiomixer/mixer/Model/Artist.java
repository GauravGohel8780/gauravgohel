package com.djmusicmixer.djmixer.audiomixer.mixer.Model;

import android.os.Parcel;
import android.os.Parcelable;

import com.djmusicmixer.djmixer.audiomixer.mixer.Utils.MusicUtil;

import java.util.ArrayList;
import java.util.List;

public class Artist implements Parcelable {
    public static final Creator<Artist> CREATOR = new Creator<Artist>() {

        @Override
        public Artist createFromParcel(Parcel parcel) {
            return new Artist(parcel);
        }

        @Override
        public Artist[] newArray(int i) {
            return new Artist[i];
        }
    };
    public static final String UNKNOWN_ARTIST_NAME = "Unknown Artist";
    public final List<Album> albums;

    public int describeContents() {
        return 0;
    }

    public Artist(List<Album> list) {
        this.albums = list;
    }

    public Artist() {
        this.albums = new ArrayList();
    }

    public long getId() {
        return getFirstAlbum().getArtistId();
    }

    public String getName() {
        String artistName = getFirstAlbum().getArtistName();
        return MusicUtil.isArtistNameUnknown(artistName) ? UNKNOWN_ARTIST_NAME : artistName;
    }

    public int getSongCount() {
        int i = 0;
        for (Album album : this.albums) {
            i += album.getSongCount();
        }
        return i;
    }

    public int getAlbumCount() {
        return this.albums.size();
    }

    public ArrayList<Songs> getSongs() {
        ArrayList<Songs> arrayList = new ArrayList<>();
        for (Album album : this.albums) {
            arrayList.addAll(album.songs);
        }
        return arrayList;
    }

    public Album getFirstAlbum() {
        return this.albums.isEmpty() ? new Album() : this.albums.get(0);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass()) {
            List<Album> list = this.albums;
            List<Album> list2 = ((Artist) obj).albums;
            if (list != null) {
                return list.equals(list2);
            }
            if (list2 == null) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        List<Album> list = this.albums;
        if (list != null) {
            return list.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "Artist{albums=" + this.albums + '}';
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeTypedList(this.albums);
    }

    protected Artist(Parcel parcel) {
        this.albums = parcel.createTypedArrayList(Album.CREATOR);
    }
}
