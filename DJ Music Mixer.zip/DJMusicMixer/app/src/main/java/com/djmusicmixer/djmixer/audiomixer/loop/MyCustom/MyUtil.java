package com.djmusicmixer.djmixer.audiomixer.loop.MyCustom;

import android.os.Environment;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MyUtil {
    public static String featureNamm = "SynthWave";
    public static int featureNumber = 1;
    public static String outFileDir = (Environment.getExternalStorageDirectory() + "/LoopPadMusic");

    public static String geOutputPath() {
        String format = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        File file = new File(outFileDir);
        if (!file.exists() && !file.mkdirs()) {
            return null;
        }
        return file.getPath() + File.separator + "myAudio" + format + ".m4a";
    }
}
