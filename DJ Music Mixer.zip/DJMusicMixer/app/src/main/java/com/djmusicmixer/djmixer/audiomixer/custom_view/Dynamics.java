package com.djmusicmixer.djmixer.audiomixer.custom_view;

public class Dynamics {
    private boolean mIsToTarget = false;
    private float mPosition;
    private int mStep;
    private float mTargetPosition;

    public Dynamics(int i, float f) {
        this.mStep = i;
        this.mPosition = f;
    }

    public void setTargetPosition(float f) {
        this.mTargetPosition = f;
        this.mIsToTarget = false;
    }

    public void setPosition(float f) {
        this.mPosition = f;
        this.mIsToTarget = true;
    }

    public void update() {
        if (!this.mIsToTarget) {
            float f = this.mTargetPosition;
            float f2 = this.mPosition;
            if (f > f2) {
                float f3 = f2 + ((float) this.mStep);
                this.mPosition = f3;
                if (f3 >= f) {
                    this.mPosition = f;
                    this.mIsToTarget = true;
                    return;
                }
                return;
            }
            float f4 = f2 - ((float) this.mStep);
            this.mPosition = f4;
            if (f4 <= f) {
                this.mPosition = f;
                this.mIsToTarget = true;
            }
        }
    }

    public boolean isAtRest() {
        return this.mIsToTarget;
    }

    public void setAtRest(boolean z) {
        this.mIsToTarget = z;
    }

    public float getPosition() {
        return this.mPosition;
    }

    public float getTargetPos() {
        return this.mTargetPosition;
    }
}
