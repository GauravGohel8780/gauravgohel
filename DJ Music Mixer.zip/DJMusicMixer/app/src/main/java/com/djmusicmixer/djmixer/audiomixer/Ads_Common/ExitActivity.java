package com.djmusicmixer.djmixer.audiomixer.Ads_Common;

import static com.iten.tenoku.ad.AdShow.getInstance;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.iten.tenoku.ad.AdShow;
import com.iten.tenoku.utils.AdUtils;

public class ExitActivity extends AdsBaseActivity {

    Activity activity;
    Boolean aBoolean;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exit);
        activity = this;
        todo();
    }


    private void todo() {
        aBoolean = getIntent().getBooleanExtra("Under", false);
        findViewById(R.id.abExit).setOnClickListener(view -> {
                finishAffinity();
                System.exit(0);

        });

        findViewById(R.id.abCancel).setOnClickListener(view -> {
            if (Boolean.TRUE.equals(aBoolean)) {
                startActivity(new Intent(activity, UnderMaintenanceActivity.class));
            } else{
                super.onBackPressed();
            }
        });
    }



    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}