package com.djmusicmixer.djmixer.audiomixer.loop;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.base.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;
import com.getkeepsafe.taptargetview.TapTarget;
import com.getkeepsafe.taptargetview.TapTargetSequence;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.util.Map;

public class MND_LoopPadActivity extends BaseActivity {
    public static MND_LoopPadActivity activity;
    int countTimer = 0;
    private SharedPreferences.Editor editor;
    Handler handler3;
    public ImageView ic_back;
    public ImageView img_start_record;
    public ImageView img_stop_record;
    public ImageView img_tab1;
    public ImageView img_tab2;
    public ImageView img_tab3;
    boolean isRecording = false;
    LinearLayout l_tabLoop;
    LinearLayout l_tabMix;
    LinearLayout l_tabPad;
    LinearLayout llStartRecord;
    MND_LoopFragment loopFragment;
    MND_MixerFragment mixerFragment;
    private ActivityResultLauncher<String[]> permissionsResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
        public void onActivityResult(Map<String, Boolean> map) {
            if (Build.VERSION.SDK_INT < 24) {
                MND_LoopPadActivity.this.run();
            } else if (map.values().stream().allMatch(Boolean::booleanValue)) {
                MND_LoopPadActivity.this.run();
            } else {
                MND_LoopPadActivity.this.dialogPermission();
            }
        }
    });
    private String readMediaPermission = "android.permission.READ_MEDIA_VIDEO";
    private String readMediaPermission2 = "android.permission.READ_MEDIA_IMAGES";
    private String readMediaPermission3 = "android.permission.READ_MEDIA_AUDIO";
    private String readMediaPermission4 = "android.permission.RECORD_AUDIO";
    Runnable runnable3;
    private SharedPreferences sharedPreferences;
    private String storagePermission = "android.permission.READ_EXTERNAL_STORAGE";
    private TapTargetSequence tapTargetSequence;
    TextView txt_featureName;
    TextView txt_recordTimer;
    ViewPager viewPager;

    @Override

    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        setContentView(R.layout.activity_looppad);

        activity = this;
        this.llStartRecord = (LinearLayout) findViewById(R.id.ll_start_record);
        this.viewPager = (ViewPager) findViewById(R.id.viewPager);
        this.l_tabLoop = (LinearLayout) findViewById(R.id.l_tabLoop);
        this.l_tabMix = (LinearLayout) findViewById(R.id.l_tabMix);
        this.l_tabPad = (LinearLayout) findViewById(R.id.l_tabPad);
        this.img_tab1 = (ImageView) findViewById(R.id.img_tab1);
        ImageView imageView = (ImageView) findViewById(R.id.ic_back);
        this.ic_back = imageView;
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(MND_LoopPadActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        MND_LoopPadActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        this.img_tab2 = (ImageView) findViewById(R.id.img_tab2);
        this.img_tab3 = (ImageView) findViewById(R.id.img_tab3);
        this.txt_featureName = (TextView) findViewById(R.id.txt_featureName);
        this.img_start_record = (ImageView) findViewById(R.id.img_start_record);
        this.img_stop_record = (ImageView) findViewById(R.id.img_stop_record);
        this.txt_recordTimer = (TextView) findViewById(R.id.txt_recordTimer);
        this.loopFragment = new MND_LoopFragment();
        MND_MixerFragment mND_MixerFragment = new MND_MixerFragment();
        this.mixerFragment = mND_MixerFragment;
        mND_MixerFragment.setOnVolumeChangeListner(new MND_MixerFragment.VolumeChangeListner() {
            @Override
            public void onVolumeMedia1(float f) {
                MND_LoopPadActivity.this.loopFragment.updateVolumeMedia1(f);
            }

            @Override
            public void onVolumeMedia2(float f) {
                MND_LoopPadActivity.this.loopFragment.updateVolumeMedia2(f);
            }

            @Override
            public void onVolumeMedia3(float f) {
                MND_LoopPadActivity.this.loopFragment.updateVolumeMedia3(f);
            }

            @Override
            public void onVolumeMedia4(float f) {
                MND_LoopPadActivity.this.loopFragment.updateVolumeMedia4(f);
            }

            @Override
            public void onVolumeMedia5(float f) {
                MND_LoopPadActivity.this.loopFragment.updateVolumeMedia5(f);
            }
        });
        unselwctAll();
        this.viewPager.setOffscreenPageLimit(3);
        this.img_tab1.setImageResource(R.drawable.ic_loop_select);
        this.viewPager.setAdapter(new SectionRealAdapter(getSupportFragmentManager()));
        this.l_tabLoop.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(MND_LoopPadActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        MND_LoopPadActivity.this.viewPager.setCurrentItem(0, false);
                        MND_LoopPadActivity.this.unselwctAll();
                        MND_LoopPadActivity.this.img_tab1.setImageResource(R.drawable.ic_loop_select);
                    }
                }, MAIN_CLICK);
            }
        });
        this.l_tabMix.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(MND_LoopPadActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        MND_LoopPadActivity.this.viewPager.setCurrentItem(1, false);
                        MND_LoopPadActivity.this.unselwctAll();
                        MND_LoopPadActivity.this.img_tab2.setImageResource(R.drawable.ic_mix_select);
                    }
                }, MAIN_CLICK);
            }
        });
        this.l_tabPad.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                     getInstance(MND_LoopPadActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        MND_LoopPadActivity.this.viewPager.setCurrentItem(2, false);
                        MND_LoopPadActivity.this.unselwctAll();
                        MND_LoopPadActivity.this.img_tab3.setImageResource(R.drawable.ic_pad_select);
                    }
                }, MAIN_CLICK);
            }
        });
        this.llStartRecord.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= 33) {
                    if (ActivityCompat.checkSelfPermission(MND_LoopPadActivity.this, "android.permission.RECORD_AUDIO") == 0 && ActivityCompat.checkSelfPermission(MND_LoopPadActivity.this, "android.permission.READ_MEDIA_VIDEO") == 0 && ActivityCompat.checkSelfPermission(MND_LoopPadActivity.this, "android.permission.READ_MEDIA_IMAGES") == 0 && ActivityCompat.checkSelfPermission(MND_LoopPadActivity.this, "android.permission.READ_MEDIA_AUDIO") == 0) {
                        MND_LoopPadActivity.this.run();
                    } else {
                        MND_LoopPadActivity.this.requestStorage();
                    }
                } else if (ActivityCompat.checkSelfPermission(MND_LoopPadActivity.this, "android.permission.RECORD_AUDIO") == 0 && ActivityCompat.checkSelfPermission(MND_LoopPadActivity.this, "android.permission.READ_EXTERNAL_STORAGE") == 0) {
                    MND_LoopPadActivity.this.run();
                } else {
                    MND_LoopPadActivity.this.requestStorage();
                }
            }
        });
        this.img_stop_record.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MND_LoopPadActivity.this.loopFragment.stopAllPads();
                if (MND_LoopPadActivity.this.isRecording) {
                    MND_LoopPadActivity.this.txt_recordTimer.setText("00:00");
                    MND_LoopPadActivity.this.isRecording = false;
                    if (MND_LoopPadActivity.this.handler3 != null) {
                        MND_LoopPadActivity.this.handler3.removeCallbacks(MND_LoopPadActivity.this.runnable3);
                    }
                    MND_LoopPadActivity.this.img_start_record.clearAnimation();
                    MND_LoopPadActivity.this.CallIntent(1);
                }
            }
        });
        this.tapTargetSequence = new TapTargetSequence(this);
        SharedPreferences sharedPreferences2 = getSharedPreferences("MY_PRE", 0);
        this.sharedPreferences = sharedPreferences2;
        this.editor = sharedPreferences2.edit();
        if (!this.sharedPreferences.getBoolean("isGuideBeatMaker", false)) {
            tapTargetPromptRecord(this.llStartRecord);
            this.editor.putBoolean("isGuideBeatMaker", true);
            this.editor.apply();
        }
    }

    private void tapTargetPromptRecord(View view) {
        this.tapTargetSequence.targets(TapTarget.forView(view, getString(R.string.Step14), getString(R.string.Tap_here_to_record_music)).outerCircleColor(R.color.color_102227).outerCircleAlpha(0.97f).targetCircleColor(R.color.white).titleTextSize(25).titleTextColor(R.color.white).descriptionTextSize(17).descriptionTextColor(R.color.white).textColor(R.color.white).textTypeface(Typeface.SANS_SERIF).dimColor(R.color.black).drawShadow(true).cancelable(false).tintTarget(false).transparentTarget(true).targetRadius(35)).listener(new TapTargetSequence.Listener() {
            @Override
            public void onSequenceCanceled(TapTarget tapTarget) {
            }

            @Override
            public void onSequenceStep(TapTarget tapTarget, boolean z) {
            }

            @Override
            public void onSequenceFinish() {
                MND_LoopPadActivity mND_LoopPadActivity = MND_LoopPadActivity.this;
                mND_LoopPadActivity.tapTargetSequence = new TapTargetSequence(mND_LoopPadActivity);
                MND_LoopPadActivity mND_LoopPadActivity2 = MND_LoopPadActivity.this;
                mND_LoopPadActivity2.tapTargetPromptLoop(mND_LoopPadActivity2.l_tabLoop);
            }
        }).start();
    }

    private void tapTargetPromptLoop(View view) {
        this.tapTargetSequence.targets(TapTarget.forView(view, getString(R.string.Step24), getString(R.string.Make_a_record_with_loop)).outerCircleColor(R.color.color_102227).outerCircleAlpha(0.97f).targetCircleColor(R.color.white).titleTextSize(25).titleTextColor(R.color.white).descriptionTextSize(17).descriptionTextColor(R.color.white).textColor(R.color.white).textTypeface(Typeface.SANS_SERIF).dimColor(R.color.black).drawShadow(true).cancelable(false).tintTarget(false).transparentTarget(true).targetRadius(38)).listener(new TapTargetSequence.Listener() {

            @Override
            public void onSequenceCanceled(TapTarget tapTarget) {
            }

            @Override
            public void onSequenceStep(TapTarget tapTarget, boolean z) {
            }

            @Override
            public void onSequenceFinish() {
                MND_LoopPadActivity mND_LoopPadActivity = MND_LoopPadActivity.this;
                mND_LoopPadActivity.tapTargetSequence = new TapTargetSequence(mND_LoopPadActivity);
                MND_LoopPadActivity mND_LoopPadActivity2 = MND_LoopPadActivity.this;
                mND_LoopPadActivity2.tapTargetPromptMix(mND_LoopPadActivity2.l_tabMix);
            }
        }).start();
    }


    private void tapTargetPromptMix(View view) {
        this.tapTargetSequence.targets(TapTarget.forView(view, getString(R.string.Step34), getString(R.string.Great_sound_mixing_with_mix)).outerCircleColor(R.color.color_102227).outerCircleAlpha(0.97f).targetCircleColor(R.color.white).titleTextSize(25).titleTextColor(R.color.white).descriptionTextSize(17).descriptionTextColor(R.color.white).textColor(R.color.white).textTypeface(Typeface.SANS_SERIF).dimColor(R.color.black).drawShadow(true).cancelable(false).tintTarget(false).transparentTarget(true).targetRadius(38)).listener(new TapTargetSequence.Listener() {

            @Override
            public void onSequenceCanceled(TapTarget tapTarget) {
            }

            @Override
            public void onSequenceStep(TapTarget tapTarget, boolean z) {
            }

            @Override
            public void onSequenceFinish() {
                MND_LoopPadActivity mND_LoopPadActivity = MND_LoopPadActivity.this;
                mND_LoopPadActivity.tapTargetSequence = new TapTargetSequence(mND_LoopPadActivity);
                MND_LoopPadActivity mND_LoopPadActivity2 = MND_LoopPadActivity.this;
                mND_LoopPadActivity2.tapTargetPromptPad(mND_LoopPadActivity2.l_tabPad);
            }
        }).start();
    }

    private void tapTargetPromptPad(View view) {
        this.tapTargetSequence.targets(TapTarget.forView(view, getString(R.string.Step44), getString(R.string.Create_new_tracks_with_Pad)).outerCircleColor(R.color.color_102227).outerCircleAlpha(0.97f).targetCircleColor(R.color.white).titleTextSize(25).titleTextColor(R.color.white).descriptionTextSize(17).descriptionTextColor(R.color.white).textColor(R.color.white).textTypeface(Typeface.SANS_SERIF).dimColor(R.color.black).drawShadow(true).cancelable(false).tintTarget(false).transparentTarget(true).targetRadius(38)).listener(new TapTargetSequence.Listener() {

            @Override
            public void onSequenceCanceled(TapTarget tapTarget) {
            }

            @Override
            public void onSequenceFinish() {
            }

            @Override
            public void onSequenceStep(TapTarget tapTarget, boolean z) {
            }
        }).start();
    }


    public void CallIntent(int i) {
        if (i == 1) {
            startActivityForResult(new Intent(MND_LoopPadActivity.this, MND_MyMusicActivity.class), 126);

        }
    }

    public void run() {
        if (!this.isRecording) {
            this.isRecording = true;
            this.loopFragment.startRecording();
            this.img_start_record.setImageResource(R.drawable.ic_mic_beat_maker);
            this.img_start_record.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.blink));
            Handler handler = this.handler3;
            if (handler != null) {
                handler.removeCallbacks(this.runnable3);
            }
            this.handler3 = new Handler();
            this.txt_recordTimer.setText("00:00");
            Runnable r0 = new Runnable() {
                public void run() {
                    MND_LoopPadActivity.this.runOnUiThread(new Runnable() {
                        public void run() {
                            MND_LoopPadActivity.this.countTimer++;
                            MND_LoopPadActivity.this.txt_recordTimer.setText(MND_LoopPadActivity.this.settIMER(MND_LoopPadActivity.this.countTimer));
                        }
                    });
                    MND_LoopPadActivity.this.handler3.postDelayed(MND_LoopPadActivity.this.runnable3, 1000);
                }
            };
            this.runnable3 = r0;
            this.handler3.postDelayed(r0, 1000);
            return;
        }
        this.isRecording = false;
        this.loopFragment.startRecording();
        this.txt_recordTimer.setText("00:00");
        Handler handler2 = this.handler3;
        if (handler2 != null) {
            handler2.removeCallbacks(this.runnable3);
        }
        this.img_start_record.clearAnimation();
        CallIntent(1);
    }

    private void requestStorage() {
        if (Build.VERSION.SDK_INT >= 33) {
            this.permissionsResult.launch(new String[]{this.readMediaPermission, this.readMediaPermission2, this.readMediaPermission3, this.readMediaPermission4});
            return;
        }
        this.permissionsResult.launch(new String[]{this.storagePermission, this.readMediaPermission4});
    }

    private void dialogPermission() {
        AlertDialog create = new AlertDialog.Builder(this, R.style.AlertDialogCustom).create();
        create.setTitle(getString(R.string.Grant_Permission));
        create.setCancelable(false);
        create.setMessage(getString(R.string.Please_grant_all_permissions));
        create.setButton(-1, getString(R.string.Go_to_setting), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                create.dismiss();
                Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
                intent.setData(Uri.fromParts("package", getApplicationContext().getPackageName(), null));
                startActivity(intent);
                create.dismiss();
            }
        });
        create.show();
    }

    public String settIMER(int r15) {
        return null;
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        this.loopFragment.stopRecordIfRunning();
        Handler handler = this.handler3;
        if (handler != null) {
            handler.removeCallbacks(this.runnable3);
        }
        finish();
    }

    public class SectionRealAdapter extends FragmentPagerAdapter {
        @Override
        public int getCount() {
            return 3;
        }

        @Override
        public CharSequence getPageTitle(int i) {
            return i != 0 ? "Second Tab" : "First Tab";
        }

        public SectionRealAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        @Override
        public Fragment getItem(int i) {
            if (i == 0) {
                return MND_LoopPadActivity.this.loopFragment;
            }
            if (i != 1) {
                return new MND_PadFragment();
            }
            return MND_LoopPadActivity.this.mixerFragment;
        }
    }

    public static MND_LoopPadActivity getInstance1() {
        return activity;
    }

    public void unselwctAll() {
        this.img_tab1.setImageResource(R.drawable.ic_loop_not_select);
        this.img_tab2.setImageResource(R.drawable.ic_mix_not_select);
        this.img_tab3.setImageResource(R.drawable.ic_pad_not_select);
    }
    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
