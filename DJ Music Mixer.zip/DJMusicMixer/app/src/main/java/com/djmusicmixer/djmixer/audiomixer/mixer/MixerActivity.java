package com.djmusicmixer.djmixer.audiomixer.mixer;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.media.PlaybackParams;
import android.media.audiofx.Equalizer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.app.ActivityCompat;
import androidx.exifinterface.media.ExifInterface;
import androidx.fragment.app.FragmentActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.custom_view.VuMeterView;
import com.djmusicmixer.djmixer.audiomixer.drummain.Drum_Main_Screen;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;
import com.djmusicmixer.djmixer.audiomixer.loop.MND_MyMusicActivity;
import com.djmusicmixer.djmixer.audiomixer.mixer.Service.PlayerNotifyService;
import com.djmusicmixer.djmixer.audiomixer.mixer.Utils.MusicConstant;
import com.djmusicmixer.djmixer.audiomixer.mixer.Utils.MusicUtil;
import com.djmusicmixer.djmixer.audiomixer.mixer.View.CustomSeekbar;
import com.djmusicmixer.djmixer.audiomixer.mixer.View.VolumeSeekbar;
import com.getkeepsafe.taptargetview.TapTarget;
import com.getkeepsafe.taptargetview.TapTargetSequence;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class MixerActivity extends BaseActivity implements View.OnClickListener, View.OnTouchListener, SeekBar.OnSeekBarChangeListener {
    public static Activity activity = null;
    public static boolean[] disk_flag = new boolean[2];
    public static int disk_index = 0;
    public static MediaPlayer[] disk_player = new MediaPlayer[2];
    public static boolean isLoadMusicA = true;
    public static boolean isLoadMusicB = true;
    public static ImageView iv_handle1;
    public static ImageView iv_handle2;
    public static ImageView iv_play_musicA;
    public static ImageView iv_play_musicB;
    public static boolean[] other_sound_flag = new boolean[12];
    public static MediaPlayer[] other_sound_player = new MediaPlayer[12];
    public static RelativeLayout rl_diskA;
    public static RelativeLayout rl_diskB;
    public static Animation rotate_diskA;
    public static Animation rotate_diskB;
    public static TextView tv_musicA;
    public static TextView tv_musicB;
    public static VuMeterView vumeterA;
    public static VuMeterView vumeterB;
    protected AudioManager audioManager;
    protected int audio_session_idA;
    protected int audio_session_idB;
    short[] band_level_rangA = new short[2];
    short[] band_level_rangB = new short[2];
    protected RelativeLayout[] changing_disc_Arr = new RelativeLayout[2];
    final int[] changing_disk_Id = {R.id.rl_diskA, R.id.rl_diskB};
    protected CountDownTimer countDownTimer;
    private double current_angle = 0.0d;
    private float current_speedA = 1.0f;
    private float current_speedB = 1.0f;
    private int disk = -1;
    private int[] disk_raw_sounds = {R.raw.record1_beat, R.raw.record2_beat};
    private int disk_touch_count = 0;
    private SharedPreferences.Editor editor;
    private long elapsedTime;
    private Equalizer equalizerA;
    private Equalizer equalizerB;
    protected boolean goToMusicLib = false;
    public int[] intArr_sliptime = {15, 30, 60, 125, 250, 500, 1000, 1500, 2000, 3000, 6000, 12000, 24000, 48000};
    private boolean isClearSelectedA = false;
    private boolean isClearSelectedB = false;
    private boolean isPaused = false;
    private boolean isRecordMusic = false;
    private boolean isServiceRunning = false;
    public boolean isStaticSlipA = false;
    public boolean isStaticSlipB = false;
    private ImageView ivOther;
    protected ImageView iv_add_musicA;
    protected ImageView iv_add_musicB;
    protected ImageView iv_back;
    private ImageView iv_clearA;
    private ImageView iv_clearB;
    protected ImageView iv_closeloop_A1;
    protected ImageView iv_closeloop_A2;
    protected ImageView iv_closeloop_A3;
    protected ImageView iv_closeloop_A4;
    protected ImageView iv_closeloop_A5;
    protected ImageView iv_closeloop_A6;
    protected ImageView iv_closeloop_A7;
    protected ImageView iv_closeloop_A8;
    private ImageView[] iv_closeloop_Arr = {this.iv_closeloop_A1, this.iv_closeloop_A2, this.iv_closeloop_A3, this.iv_closeloop_A4, this.iv_closeloop_A5, this.iv_closeloop_A6, this.iv_closeloop_A7, this.iv_closeloop_A8, this.iv_closeloop_B1, this.iv_closeloop_B2, this.iv_closeloop_B3, this.iv_closeloop_B4, this.iv_closeloop_B5, this.iv_closeloop_B6, this.iv_closeloop_B7, this.iv_closeloop_B8};
    protected ImageView iv_closeloop_B1;
    protected ImageView iv_closeloop_B2;
    protected ImageView iv_closeloop_B3;
    protected ImageView iv_closeloop_B4;
    protected ImageView iv_closeloop_B5;
    protected ImageView iv_closeloop_B6;
    protected ImageView iv_closeloop_B7;
    protected ImageView iv_closeloop_B8;
    private int[] iv_closeloop_Id = {R.id.iv_closeloop_A1, R.id.iv_closeloop_A2, R.id.iv_closeloop_A3, R.id.iv_closeloop_A4, R.id.iv_closeloop_A5, R.id.iv_closeloop_A6, R.id.iv_closeloop_A7, R.id.iv_closeloop_A8, R.id.iv_closeloop_B1, R.id.iv_closeloop_B2, R.id.iv_closeloop_B3, R.id.iv_closeloop_B4, R.id.iv_closeloop_B5, R.id.iv_closeloop_B6, R.id.iv_closeloop_B7, R.id.iv_closeloop_B8};
    private ImageView iv_cues_sound;
    private ImageView iv_equalizer;
    private ImageView iv_loop_sound;
    protected ImageView iv_mixes_list;
    protected ImageView iv_nextA;
    protected ImageView iv_nextB;
    private ImageView iv_other_sound;
    private ImageView[] iv_other_soundArr = new ImageView[12];
    final int[] iv_other_soundId = {R.id.iv_soundV1, R.id.iv_soundV2, R.id.iv_soundV3, R.id.iv_soundV4, R.id.iv_soundV5, R.id.iv_soundV6, R.id.iv_soundD1, R.id.iv_soundD2, R.id.iv_soundD3, R.id.iv_soundD4, R.id.iv_soundD5, R.id.iv_soundD6};
    protected ImageView iv_prevA;
    protected ImageView iv_prevB;
    private ImageView iv_recording;
    protected ImageView iv_reset_volumeA;
    protected ImageView iv_reset_volumeB;
    private ImageView iv_slip_flipA;
    private ImageView iv_slip_flipB;
    private CircleImageView iv_thumbA;
    private CircleImageView iv_thumbB;
    private LinearLayout ly_cues_sound;
    private LinearLayout ly_equalizer;
    private LinearLayout ly_loop_sound;
    private LinearLayout ly_other_sound;
    private LinearLayout ly_slip_continueA;
    private LinearLayout ly_slip_continueB;
    protected int maxCrossVolume;
    private int maxVolume;
    private MediaRecorder mediaRecorder;
    int minute;
    private int num_of_bandsA;
    private int num_of_bandsB;
    final int[] other_raw_sounds = {R.raw.bust_dat_groove, R.raw.let_go, R.raw.oh_yeah, R.raw.wassup_all, R.raw.crowd, R.raw.ah_yeah, R.raw.vocal_wub, R.raw.dirty_wub, R.raw.drop, R.raw.dub_siren, R.raw.filth_wobble, R.raw.wobble};
    private ActivityResultLauncher<String[]> permissionsResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
        public void onActivityResult(Map<String, Boolean> map) {
            if (Build.VERSION.SDK_INT < 24) {
                MixerActivity.this.run();
            } else if (map.values().stream().allMatch(Boolean::booleanValue)) {
                MixerActivity.this.run();
            } else {
                MixerActivity.this.dialogPermission();
            }
        }
    });
    protected double prev_angle = 0.0d;
    private String readMediaPermission = "android.permission.READ_MEDIA_VIDEO";
    private String readMediaPermission2 = "android.permission.READ_MEDIA_IMAGES";
    private String readMediaPermission3 = "android.permission.READ_MEDIA_AUDIO";
    private String readMediaPermission4 = "android.permission.RECORD_AUDIO";
    protected RelativeLayout rl_breakpoint_A1;
    protected RelativeLayout rl_breakpoint_A2;
    protected RelativeLayout rl_breakpoint_A3;
    protected RelativeLayout rl_breakpoint_A4;
    protected RelativeLayout rl_breakpoint_A5;
    protected RelativeLayout rl_breakpoint_A6;
    protected RelativeLayout rl_breakpoint_A7;
    protected RelativeLayout rl_breakpoint_A8;
    private RelativeLayout[] rl_breakpoint_Arr = {this.rl_breakpoint_A1, this.rl_breakpoint_A2, this.rl_breakpoint_A3, this.rl_breakpoint_A4, this.rl_breakpoint_A5, this.rl_breakpoint_A6, this.rl_breakpoint_A7, this.rl_breakpoint_A8, this.rl_breakpoint_B1, this.rl_breakpoint_B2, this.rl_breakpoint_B3, this.rl_breakpoint_B4, this.rl_breakpoint_B5, this.rl_breakpoint_B6, this.rl_breakpoint_B7, this.rl_breakpoint_B8};
    protected RelativeLayout rl_breakpoint_B1;
    protected RelativeLayout rl_breakpoint_B2;
    protected RelativeLayout rl_breakpoint_B3;
    protected RelativeLayout rl_breakpoint_B4;
    protected RelativeLayout rl_breakpoint_B5;
    protected RelativeLayout rl_breakpoint_B6;
    protected RelativeLayout rl_breakpoint_B7;
    protected RelativeLayout rl_breakpoint_B8;
    private int[] rl_breakpoint_Id = {R.id.rl_breakpoint_A1, R.id.rl_breakpoint_A2, R.id.rl_breakpoint_A3, R.id.rl_breakpoint_A4, R.id.rl_breakpoint_A5, R.id.rl_breakpoint_A6, R.id.rl_breakpoint_A7, R.id.rl_breakpoint_A8, R.id.rl_breakpoint_B1, R.id.rl_breakpoint_B2, R.id.rl_breakpoint_B3, R.id.rl_breakpoint_B4, R.id.rl_breakpoint_B5, R.id.rl_breakpoint_B6, R.id.rl_breakpoint_B7, R.id.rl_breakpoint_B8};
    private RelativeLayout rl_disk;
    Runnable runnableA = new Runnable() {
        public void run() {
            int currentPosition = MixerActivity.disk_player[0].getCurrentPosition();
            int duration = MixerActivity.disk_player[0].getDuration();
            while (MixerActivity.disk_player[0] != null && currentPosition < duration) {
                try {
                    Thread.sleep(1000);
                    currentPosition = MixerActivity.disk_player[0].getCurrentPosition();
                    MixerActivity.this.sb_diskA.setProgress(currentPosition);
                } catch (Exception unused) {
                    return;
                }
            }
        }
    };
    Runnable runnableB = new Runnable() {
        public void run() {
            int currentPosition = MixerActivity.disk_player[1].getCurrentPosition();
            int duration = MixerActivity.disk_player[1].getDuration();
            while (MixerActivity.disk_player[1] != null && currentPosition < duration) {
                try {
                    Thread.sleep(1000);
                    currentPosition = MixerActivity.disk_player[1].getCurrentPosition();
                    MixerActivity.this.sb_diskB.setProgress(currentPosition);
                } catch (Exception unused) {
                    return;
                }
            }
        }
    };
    protected CustomSeekbar[] sb_bandA;
    protected CustomSeekbar[] sb_bandB;
    private SeekBar sb_both_disk_volume;
    public SeekBar sb_diskA;
    public SeekBar sb_diskB;
    final int[] sb_left_bandId = {R.id.vs_left_band1, R.id.vs_left_band2, R.id.vs_left_band3, R.id.vs_left_band4, R.id.vs_left_band5};
    final int[] sb_right_bandId = {R.id.vs_right_band1, R.id.vs_right_band2, R.id.vs_right_band3, R.id.vs_right_band4, R.id.vs_right_band5};
    int second = -1;
    protected String selected_music_path;
    private SharedPreferences sharedPreferences;
    public ArrayList<String> sliptimeList = new ArrayList<>();
    private long startTime;
    public int static_slip_current_posA = 0;
    public int static_slip_current_posB = 0;
    private String storagePermission = "android.permission.READ_EXTERNAL_STORAGE";
    private String[] strArr_slipValue = {"1/64", "1/32", "1/16", "1/8", "1/4", "1/2", "1", ExifInterface.GPS_MEASUREMENT_2D, "4", "8", "16", "32", "64", "128"};
    private TapTargetSequence tapTargetSequence;
    protected TextView tv_breakpoint_A1;
    protected TextView tv_breakpoint_A2;
    protected TextView tv_breakpoint_A3;
    protected TextView tv_breakpoint_A4;
    protected TextView tv_breakpoint_A5;
    protected TextView tv_breakpoint_A6;
    protected TextView tv_breakpoint_A7;
    protected TextView tv_breakpoint_A8;
    private TextView[] tv_breakpoint_Arr = {this.tv_breakpoint_A1, this.tv_breakpoint_A2, this.tv_breakpoint_A3, this.tv_breakpoint_A4, this.tv_breakpoint_A5, this.tv_breakpoint_A6, this.tv_breakpoint_A7, this.tv_breakpoint_A8, this.tv_breakpoint_B1, this.tv_breakpoint_B2, this.tv_breakpoint_B3, this.tv_breakpoint_B4, this.tv_breakpoint_B5, this.tv_breakpoint_B6, this.tv_breakpoint_B7, this.tv_breakpoint_B8};
    protected TextView tv_breakpoint_B1;
    protected TextView tv_breakpoint_B2;
    protected TextView tv_breakpoint_B3;
    protected TextView tv_breakpoint_B4;
    protected TextView tv_breakpoint_B5;
    protected TextView tv_breakpoint_B6;
    protected TextView tv_breakpoint_B7;
    protected TextView tv_breakpoint_B8;
    private int[] tv_breakpoint_Id = {R.id.tv_breakpoint_A1, R.id.tv_breakpoint_A2, R.id.tv_breakpoint_A3, R.id.tv_breakpoint_A4, R.id.tv_breakpoint_A5, R.id.tv_breakpoint_A6, R.id.tv_breakpoint_A7, R.id.tv_breakpoint_A8, R.id.tv_breakpoint_B1, R.id.tv_breakpoint_B2, R.id.tv_breakpoint_B3, R.id.tv_breakpoint_B4, R.id.tv_breakpoint_B5, R.id.tv_breakpoint_B6, R.id.tv_breakpoint_B7, R.id.tv_breakpoint_B8};
    protected TextView tv_breakpoint_timeA1;
    protected TextView tv_breakpoint_timeA2;
    protected TextView tv_breakpoint_timeA3;
    protected TextView tv_breakpoint_timeA4;
    protected TextView tv_breakpoint_timeA5;
    protected TextView tv_breakpoint_timeA6;
    protected TextView tv_breakpoint_timeA7;
    protected TextView tv_breakpoint_timeA8;
    protected TextView tv_breakpoint_timeB1;
    protected TextView tv_breakpoint_timeB2;
    protected TextView tv_breakpoint_timeB3;
    protected TextView tv_breakpoint_timeB4;
    protected TextView tv_breakpoint_timeB5;
    protected TextView tv_breakpoint_timeB6;
    protected TextView tv_breakpoint_timeB7;
    protected TextView tv_breakpoint_timeB8;
    private TextView[] tv_breakpoint_time_Arr = {this.tv_breakpoint_timeA1, this.tv_breakpoint_timeA2, this.tv_breakpoint_timeA3, this.tv_breakpoint_timeA4, this.tv_breakpoint_timeA5, this.tv_breakpoint_timeA6, this.tv_breakpoint_timeA7, this.tv_breakpoint_timeA8, this.tv_breakpoint_timeB1, this.tv_breakpoint_timeB2, this.tv_breakpoint_timeB3, this.tv_breakpoint_timeB4, this.tv_breakpoint_timeB5, this.tv_breakpoint_timeB6, this.tv_breakpoint_timeB7, this.tv_breakpoint_timeB8};
    private int[] tv_breakpoint_time_Id = {R.id.tv_breakpoint_timeA1, R.id.tv_breakpoint_timeA2, R.id.tv_breakpoint_timeA3, R.id.tv_breakpoint_timeA4, R.id.tv_breakpoint_timeA5, R.id.tv_breakpoint_timeA6, R.id.tv_breakpoint_timeA7, R.id.tv_breakpoint_timeA8, R.id.tv_breakpoint_timeB1, R.id.tv_breakpoint_timeB2, R.id.tv_breakpoint_timeB3, R.id.tv_breakpoint_timeB4, R.id.tv_breakpoint_timeB5, R.id.tv_breakpoint_timeB6, R.id.tv_breakpoint_timeB7, R.id.tv_breakpoint_timeB8};
    public TextView tv_current_sliptimeA;
    public TextView tv_current_sliptimeB;
    protected TextView tv_display_timeA1;
    protected TextView tv_display_timeA2;
    protected TextView tv_display_timeA3;
    protected TextView tv_display_timeA4;
    protected TextView tv_display_timeA5;
    protected TextView tv_display_timeA6;
    protected TextView tv_display_timeA7;
    protected TextView tv_display_timeA8;
    protected TextView tv_display_timeB1;
    protected TextView tv_display_timeB2;
    protected TextView tv_display_timeB3;
    protected TextView tv_display_timeB4;
    protected TextView tv_display_timeB5;
    protected TextView tv_display_timeB6;
    protected TextView tv_display_timeB7;
    protected TextView tv_display_timeB8;
    private TextView[] tv_display_time_Arr = {this.tv_display_timeA1, this.tv_display_timeA2, this.tv_display_timeA3, this.tv_display_timeA4, this.tv_display_timeA5, this.tv_display_timeA6, this.tv_display_timeA7, this.tv_display_timeA8, this.tv_display_timeB1, this.tv_display_timeB2, this.tv_display_timeB3, this.tv_display_timeB4, this.tv_display_timeB5, this.tv_display_timeB6, this.tv_display_timeB7, this.tv_display_timeB8};
    private int[] tv_display_time_Id = {R.id.tv_display_timeA1, R.id.tv_display_timeA2, R.id.tv_display_timeA3, R.id.tv_display_timeA4, R.id.tv_display_timeA5, R.id.tv_display_timeA6, R.id.tv_display_timeA7, R.id.tv_display_timeA8, R.id.tv_display_timeB1, R.id.tv_display_timeB2, R.id.tv_display_timeB3, R.id.tv_display_timeB4, R.id.tv_display_timeB5, R.id.tv_display_timeB6, R.id.tv_display_timeB7, R.id.tv_display_timeB8};
    public TextView tv_duration;
    protected TextView tv_inA;
    protected TextView tv_inB;
    private TextView tv_musicAA;
    private TextView tv_musicAAA;
    private TextView tv_musicAAAA;
    private TextView tv_musicBB;
    private TextView tv_musicBBB;
    private TextView tv_musicBBBB;
    private TextView tv_outA;
    private TextView tv_outB;
    protected TextView tv_slipA1;
    protected TextView tv_slipA2;
    protected TextView tv_slipA3;
    protected TextView tv_slipA4;
    protected TextView tv_slipA5;
    protected TextView tv_slipA6;
    protected TextView tv_slipB1;
    protected TextView tv_slipB2;
    protected TextView tv_slipB3;
    protected TextView tv_slipB4;
    protected TextView tv_slipB5;
    protected TextView tv_slipB6;
    private TextView[] tv_slip_Arr = {this.tv_slipA1, this.tv_slipA2, this.tv_slipA3, this.tv_slipA4, this.tv_slipA5, this.tv_slipA6, this.tv_slipB1, this.tv_slipB2, this.tv_slipB3, this.tv_slipB4, this.tv_slipB5, this.tv_slipB6};
    private int[] tv_slip_Id = {R.id.tv_slipA1, R.id.tv_slipA2, R.id.tv_slipA3, R.id.tv_slipA4, R.id.tv_slipA5, R.id.tv_slipA6, R.id.tv_slipB1, R.id.tv_slipB2, R.id.tv_slipB3, R.id.tv_slipB4, R.id.tv_slipB5, R.id.tv_slipB6};
    protected int visibility_countA = 0;
    protected int visibility_countB = 0;
    protected VolumeSeekbar vs_speedA;
    protected VolumeSeekbar vs_speedB;
    private VolumeSeekbar vs_volumeA;
    private VolumeSeekbar vs_volumeB;

    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
    }

    @Override
    public void onResume() {
        super.onResume();
        int i = 0;
        while (true) {
            MediaPlayer[] mediaPlayerArr = disk_player;
            if (i >= mediaPlayerArr.length) {
                break;
            }
            if (disk_flag[i]) {
                mediaPlayerArr[i].start();
                disk_flag[i] = false;
            }
            i++;
        }
        int i2 = 0;
        while (true) {
            MediaPlayer[] mediaPlayerArr2 = other_sound_player;
            if (i2 < mediaPlayerArr2.length) {
                if (other_sound_flag[i2]) {
                    mediaPlayerArr2[i2].start();
                    other_sound_flag[i2] = false;
                }
                i2++;
            } else {
                return;
            }
        }
    }

    private void releaseDJMixerPlayer() {
        int i = 0;
        int i2 = 0;
        while (true) {
            MediaPlayer[] mediaPlayerArr = disk_player;
            if (i2 >= mediaPlayerArr.length) {
                break;
            }
            if (mediaPlayerArr[i2] != null) {
                try {
                    mediaPlayerArr[i2].stop();
                    disk_player[i2].release();
                    disk_player[i2] = null;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            i2++;
        }
        while (true) {
            MediaPlayer[] mediaPlayerArr2 = other_sound_player;
            if (i < mediaPlayerArr2.length) {
                if (mediaPlayerArr2[i] != null) {
                    try {
                        mediaPlayerArr2[i].release();
                        other_sound_player[i] = null;
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                }
                i++;
            } else {
                return;
            }
        }
    }

    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        setContentView(R.layout.activity_rkappzia_music_mixer);
        this.startTime = System.currentTimeMillis();
        initDJMixer();
        this.tapTargetSequence = new TapTargetSequence(this);
        SharedPreferences sharedPreferences2 = getSharedPreferences("MY_PRE", 0);
        this.sharedPreferences = sharedPreferences2;
        this.editor = sharedPreferences2.edit();
        if (!this.sharedPreferences.getBoolean("isGuideDJMixer", false)) {
            tapTargetPromptRecord(this.iv_recording);
            this.editor.putBoolean("isGuideDJMixer", true);
            this.editor.apply();
        }
    }

    private void tapTargetPromptRecord(View view) {
        this.tapTargetSequence.targets(TapTarget.forView(view, getString(R.string.Step16), getString(R.string.Tap_here_to_record_music)).outerCircleColor(R.color.color_102227).outerCircleAlpha(0.97f).targetCircleColor(R.color.white).titleTextSize(25).titleTextColor(R.color.white).descriptionTextSize(17).descriptionTextColor(R.color.white).textColor(R.color.white).textTypeface(Typeface.SANS_SERIF).dimColor(R.color.black).drawShadow(true).cancelable(false).tintTarget(false).transparentTarget(true).targetRadius(35)).listener(new TapTargetSequence.Listener() {
            @Override
            public void onSequenceCanceled(TapTarget tapTarget) {
            }

            @Override
            public void onSequenceStep(TapTarget tapTarget, boolean z) {
            }

            @Override
            public void onSequenceFinish() {
                MixerActivity mixerActivity = MixerActivity.this;
                mixerActivity.tapTargetSequence = new TapTargetSequence(mixerActivity);
                MixerActivity mixerActivity2 = MixerActivity.this;
                mixerActivity2.tapTargetPromptCues(mixerActivity2.ivOther);
            }
        }).start();
    }

    private void tapTargetPromptCues(View view) {
        this.tapTargetSequence.targets(TapTarget.forView(view, getString(R.string.Step26), getString(R.string.Tap_here_to_set_cues_points)).outerCircleColor(R.color.color_102227).outerCircleAlpha(0.97f).targetCircleColor(R.color.white).titleTextSize(25).titleTextColor(R.color.white).descriptionTextSize(17).descriptionTextColor(R.color.white).textColor(R.color.white).textTypeface(Typeface.SANS_SERIF).dimColor(R.color.black).drawShadow(true).cancelable(false).tintTarget(false).transparentTarget(true).targetRadius(35)).listener(new TapTargetSequence.Listener() {
            @Override
            public void onSequenceCanceled(TapTarget tapTarget) {
            }

            @Override
            public void onSequenceStep(TapTarget tapTarget, boolean z) {
            }

            @Override
            public void onSequenceFinish() {
                MixerActivity mixerActivity = MixerActivity.this;
                mixerActivity.tapTargetSequence = new TapTargetSequence(mixerActivity);
                MixerActivity mixerActivity2 = MixerActivity.this;
                mixerActivity2.tapTargetPromptAddMusicDeckA(mixerActivity2.iv_add_musicA);
            }
        }).start();
    }

    private void tapTargetPromptAddMusicDeckA(View view) {
        this.tapTargetSequence.targets(TapTarget.forView(view, getString(R.string.Step36), getString(R.string.Tap_here_to_add_music_for_Deck_A)).outerCircleColor(R.color.color_102227).outerCircleAlpha(0.97f).targetCircleColor(R.color.white).titleTextSize(25).titleTextColor(R.color.white).descriptionTextSize(17).descriptionTextColor(R.color.white).textColor(R.color.white).textTypeface(Typeface.SANS_SERIF).dimColor(R.color.black).drawShadow(true).cancelable(false).tintTarget(false).transparentTarget(true).targetRadius(35)).listener(new TapTargetSequence.Listener() {
            @Override
            public void onSequenceCanceled(TapTarget tapTarget) {
            }

            @Override
            public void onSequenceStep(TapTarget tapTarget, boolean z) {
            }

            @Override
            public void onSequenceFinish() {
                MixerActivity mixerActivity = MixerActivity.this;
                mixerActivity.tapTargetSequence = new TapTargetSequence(mixerActivity);
                MixerActivity.this.tapTargetPromptPlayDeckA(MixerActivity.iv_play_musicA);
            }
        }).start();
    }

    private void tapTargetPromptPlayDeckA(View view) {
        this.tapTargetSequence.targets(TapTarget.forView(view, getString(R.string.Step46), getString(R.string.Tap_here_to_play_Deck_A)).outerCircleColor(R.color.color_102227).outerCircleAlpha(0.97f).targetCircleColor(R.color.white).titleTextSize(25).titleTextColor(R.color.white).descriptionTextSize(17).descriptionTextColor(R.color.white).textColor(R.color.white).textTypeface(Typeface.SANS_SERIF).dimColor(R.color.black).drawShadow(true).cancelable(false).tintTarget(false).transparentTarget(true).targetRadius(35)).listener(new TapTargetSequence.Listener() {
            @Override
            public void onSequenceCanceled(TapTarget tapTarget) {
            }

            @Override
            public void onSequenceStep(TapTarget tapTarget, boolean z) {
            }

            @Override
            public void onSequenceFinish() {
                MixerActivity mixerActivity = MixerActivity.this;
                mixerActivity.tapTargetSequence = new TapTargetSequence(mixerActivity);
                MixerActivity.this.tapTargetPromptPlayDeckB(MixerActivity.iv_play_musicB);
            }
        }).start();
    }

    private void tapTargetPromptPlayDeckB(View view) {
        this.tapTargetSequence.targets(TapTarget.forView(view, getString(R.string.Step56), getString(R.string.Tap_here_to_play_Deck_B)).outerCircleColor(R.color.color_102227).outerCircleAlpha(0.97f).targetCircleColor(R.color.white).titleTextSize(25).titleTextColor(R.color.white).descriptionTextSize(17).descriptionTextColor(R.color.white).textColor(R.color.white).textTypeface(Typeface.SANS_SERIF).dimColor(R.color.black).drawShadow(true).cancelable(false).tintTarget(false).transparentTarget(true).targetRadius(35)).listener(new TapTargetSequence.Listener() {
            @Override
            public void onSequenceCanceled(TapTarget tapTarget) {
            }

            @Override
            public void onSequenceStep(TapTarget tapTarget, boolean z) {
            }

            @Override
            public void onSequenceFinish() {
                MixerActivity mixerActivity = MixerActivity.this;
                mixerActivity.tapTargetSequence = new TapTargetSequence(mixerActivity);
                MixerActivity mixerActivity2 = MixerActivity.this;
                mixerActivity2.tapTargetPromptAddMusicDeckB(mixerActivity2.iv_add_musicB);
            }
        }).start();
    }

    private void tapTargetPromptAddMusicDeckB(View view) {
        this.tapTargetSequence.targets(TapTarget.forView(view, getString(R.string.Step66), getString(R.string.Tap_here_to_add_music_for_Deck_B)).outerCircleColor(R.color.color_102227).outerCircleAlpha(0.97f).targetCircleColor(R.color.white).titleTextSize(25).titleTextColor(R.color.white).descriptionTextSize(17).descriptionTextColor(R.color.white).textColor(R.color.white).textTypeface(Typeface.SANS_SERIF).dimColor(R.color.black).drawShadow(true).cancelable(false).tintTarget(false).transparentTarget(true).targetRadius(35)).listener(new TapTargetSequence.Listener() {
            @Override
            public void onSequenceCanceled(TapTarget tapTarget) {
            }

            @Override
            public void onSequenceStep(TapTarget tapTarget, boolean z) {
            }

            @Override
            public void onSequenceFinish() {
                MixerActivity mixerActivity = MixerActivity.this;
                mixerActivity.tapTargetSequence = new TapTargetSequence(mixerActivity);
            }
        }).start();
    }

    public void initDJMixer() {
        this.ivOther = (ImageView) findViewById(R.id.iv_other);
        this.iv_back = (ImageView) findViewById(R.id.iv_back);
        this.sb_diskA = (SeekBar) findViewById(R.id.sb_diskA);
        this.iv_recording = (ImageView) findViewById(R.id.iv_recording_rkappzia);
        this.tv_duration = (TextView) findViewById(R.id.tv_duration);
        this.iv_mixes_list = (ImageView) findViewById(R.id.iv_mixes_list_rkappzia);
        this.sb_diskB = (SeekBar) findViewById(R.id.sb_diskB_rkappzia);
        this.rl_disk = (RelativeLayout) findViewById(R.id.rl_disk);
        this.vs_speedA = (VolumeSeekbar) findViewById(R.id.vs_speedA_rkappzia);
        tv_musicA = (TextView) findViewById(R.id.tv_musicA);
        rl_diskA = (RelativeLayout) findViewById(R.id.rl_diskA);
        this.iv_thumbA = (CircleImageView) findViewById(R.id.iv_thumbA);
        iv_handle1 = (ImageView) findViewById(R.id.iv_handle1_rkappzia);
        tv_musicB = (TextView) findViewById(R.id.tv_musicB);
        rl_diskB = (RelativeLayout) findViewById(R.id.rl_diskB);
        this.iv_thumbB = (CircleImageView) findViewById(R.id.iv_thumbB);
        this.vs_speedB = (VolumeSeekbar) findViewById(R.id.vs_speedB_rkappzia);
        iv_handle2 = (ImageView) findViewById(R.id.iv_handle2);
        int i = 0;
        while (true) {
            RelativeLayout[] relativeLayoutArr = this.changing_disc_Arr;
            if (i >= relativeLayoutArr.length) {
                break;
            }
            relativeLayoutArr[i] = (RelativeLayout) findViewById(this.changing_disk_Id[i]);
            i++;
        }
        this.ly_equalizer = (LinearLayout) findViewById(R.id.ly_equalizer);
        this.vs_volumeA = (VolumeSeekbar) findViewById(R.id.vs_volumeA);
        this.tv_musicAA = (TextView) findViewById(R.id.tv_musicAA);
        this.sb_bandA = new CustomSeekbar[5];
        for (int i2 = 0; i2 < 5; i2++) {
            this.sb_bandA[i2] = (CustomSeekbar) findViewById(this.sb_left_bandId[i2]);
            this.sb_bandA[i2].setOnSeekBarChangeListener(this);
        }
        this.vs_volumeB = (VolumeSeekbar) findViewById(R.id.vs_volumeB);
        this.tv_musicBB = (TextView) findViewById(R.id.tv_musicBB);
        this.sb_bandB = new CustomSeekbar[5];
        for (int i3 = 0; i3 < 5; i3++) {
            this.sb_bandB[i3] = (CustomSeekbar) findViewById(this.sb_right_bandId[i3]);
            this.sb_bandB[i3].setOnSeekBarChangeListener(this);
        }
        this.ly_loop_sound = (LinearLayout) findViewById(R.id.ly_loop_sound);
        this.tv_musicAAA = (TextView) findViewById(R.id.tv_musicAAA);
        this.tv_musicBBB = (TextView) findViewById(R.id.tv_musicBBB);
        this.iv_prevA = (ImageView) findViewById(R.id.iv_prevA);
        this.iv_nextA = (ImageView) findViewById(R.id.iv_nextA);
        this.iv_prevB = (ImageView) findViewById(R.id.iv_prevB);
        this.iv_nextB = (ImageView) findViewById(R.id.iv_nextB);
        this.ly_slip_continueA = (LinearLayout) findViewById(R.id.ly_slip_continueA);
        this.ly_slip_continueB = (LinearLayout) findViewById(R.id.ly_slip_continueB);
        this.iv_slip_flipA = (ImageView) findViewById(R.id.iv_slip_flipA);
        this.iv_slip_flipB = (ImageView) findViewById(R.id.iv_slip_flipB);
        this.tv_current_sliptimeA = (TextView) findViewById(R.id.tv_current_sliptimeA);
        this.tv_current_sliptimeB = (TextView) findViewById(R.id.tv_current_sliptimeB);
        int i4 = 0;
        while (true) {
            TextView[] textViewArr = this.tv_slip_Arr;
            if (i4 >= textViewArr.length) {
                break;
            }
            textViewArr[i4] = (TextView) findViewById(this.tv_slip_Id[i4]);
            this.tv_slip_Arr[i4].setOnClickListener(this);
            i4++;
        }
        this.tv_inA = (TextView) findViewById(R.id.tv_inA);
        this.tv_inB = (TextView) findViewById(R.id.tv_inB);
        this.tv_outA = (TextView) findViewById(R.id.tv_outA);
        this.tv_outB = (TextView) findViewById(R.id.tv_outB);
        this.ly_cues_sound = (LinearLayout) findViewById(R.id.ly_cues_sound);
        this.tv_musicAAAA = (TextView) findViewById(R.id.tv_musicAAAA);
        this.tv_musicBBBB = (TextView) findViewById(R.id.tv_musicBBBB);
        this.iv_clearA = (ImageView) findViewById(R.id.iv_clearA);
        this.iv_clearB = (ImageView) findViewById(R.id.iv_clearB);
        int i5 = 0;
        while (true) {
            RelativeLayout[] relativeLayoutArr2 = this.rl_breakpoint_Arr;
            if (i5 >= relativeLayoutArr2.length) {
                break;
            }
            relativeLayoutArr2[i5] = (RelativeLayout) findViewById(this.rl_breakpoint_Id[i5]);
            this.rl_breakpoint_Arr[i5].setOnClickListener(this);
            i5++;
        }
        int i6 = 0;
        while (true) {
            TextView[] textViewArr2 = this.tv_breakpoint_Arr;
            if (i6 >= textViewArr2.length) {
                break;
            }
            textViewArr2[i6] = (TextView) findViewById(this.tv_breakpoint_Id[i6]);
            i6++;
        }
        int i7 = 0;
        while (true) {
            TextView[] textViewArr3 = this.tv_breakpoint_time_Arr;
            if (i7 >= textViewArr3.length) {
                break;
            }
            textViewArr3[i7] = (TextView) findViewById(this.tv_breakpoint_time_Id[i7]);
            i7++;
        }
        int i8 = 0;
        while (true) {
            TextView[] textViewArr4 = this.tv_display_time_Arr;
            if (i8 >= textViewArr4.length) {
                break;
            }
            textViewArr4[i8] = (TextView) findViewById(this.tv_display_time_Id[i8]);
            i8++;
        }
        int i9 = 0;
        while (true) {
            ImageView[] imageViewArr = this.iv_closeloop_Arr;
            if (i9 >= imageViewArr.length) {
                break;
            }
            imageViewArr[i9] = (ImageView) findViewById(this.iv_closeloop_Id[i9]);
            this.iv_closeloop_Arr[i9].setOnClickListener(this);
            i9++;
        }
        this.ly_other_sound = (LinearLayout) findViewById(R.id.ly_other_sound);
        int i10 = 0;
        while (true) {
            ImageView[] imageViewArr2 = this.iv_other_soundArr;
            if (i10 >= imageViewArr2.length) {
                break;
            }
            imageViewArr2[i10] = (ImageView) findViewById(this.iv_other_soundId[i10]);
            this.iv_other_soundArr[i10].setOnTouchListener(this);
            i10++;
        }
        this.iv_equalizer = (ImageView) findViewById(R.id.iv_equalizer);
        this.iv_cues_sound = (ImageView) findViewById(R.id.iv_cues_sound);
        this.iv_loop_sound = (ImageView) findViewById(R.id.iv_loop_sound);
        this.iv_other_sound = (ImageView) findViewById(R.id.iv_other_sound);
        vumeterA = (VuMeterView) findViewById(R.id.vumeterA);
        vumeterB = (VuMeterView) findViewById(R.id.vumeterB);
        vumeterA.pause();
        vumeterB.pause();
        this.iv_add_musicA = (ImageView) findViewById(R.id.iv_add_musicA_rkappzia);
        iv_play_musicA = (ImageView) findViewById(R.id.iv_play_musicA_rkappzia);
        this.iv_reset_volumeA = (ImageView) findViewById(R.id.iv_reset_volumeA_rkappzia);
        this.sb_both_disk_volume = (SeekBar) findViewById(R.id.sb_both_disk_volume);
        this.iv_reset_volumeB = (ImageView) findViewById(R.id.iv_reset_volumeB_rkappzia);
        iv_play_musicB = (ImageView) findViewById(R.id.iv_play_musicB_rkappzia);
        this.iv_add_musicB = (ImageView) findViewById(R.id.iv_add_musicB_rkappzia);
        setVolumeControlStream(3);
        releaseDJMixerPlayer();
        this.sliptimeList.addAll(Arrays.asList(this.strArr_slipValue));
        AudioManager audioManager2 = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        this.audioManager = audioManager2;
        this.maxVolume = audioManager2.getStreamMaxVolume(3);
        int i11 = 0;
        while (true) {
            MediaPlayer[] mediaPlayerArr = other_sound_player;
            if (i11 >= mediaPlayerArr.length) {
                break;
            }
            mediaPlayerArr[i11] = MediaPlayer.create(this, this.other_raw_sounds[i11]);
            other_sound_player[i11].setAudioStreamType(3);
            i11++;
        }
        Arrays.fill(other_sound_flag, false);
        int i12 = 0;
        while (true) {
            MediaPlayer[] mediaPlayerArr2 = disk_player;
            if (i12 < mediaPlayerArr2.length) {
                mediaPlayerArr2[i12] = MediaPlayer.create(this, this.disk_raw_sounds[i12]);
                disk_player[i12].setAudioStreamType(3);
                disk_player[i12].setLooping(true);
                if (i12 == 0) {
                    this.sb_diskA.setProgress(disk_player[0].getDuration());
                } else {
                    this.sb_diskB.setProgress(disk_player[1].getDuration());
                }
                i12++;
            } else {
                Arrays.fill(disk_flag, false);
                this.maxCrossVolume = (this.maxVolume * 2) + 1;
                rotate_diskA = AnimationUtils.loadAnimation(this, R.anim.rotate_disk_anim);
                rotate_diskB = AnimationUtils.loadAnimation(this, R.anim.rotate_disk_anim);
                tv_musicA.setSelected(true);
                this.tv_musicAA.setSelected(true);
                this.tv_musicAAA.setSelected(true);
                this.tv_musicAAAA.setSelected(true);
                tv_musicB.setSelected(true);
                this.tv_musicBB.setSelected(true);
                this.tv_musicBBB.setSelected(true);
                this.tv_musicBBBB.setSelected(true);
                this.vs_volumeA.setMax(this.maxVolume);
                this.vs_volumeB.setMax(this.maxVolume);
                this.vs_volumeA.setProgress((int) (((float) this.maxVolume) * 0.85f));
                this.vs_volumeB.setProgress((int) (((float) this.maxVolume) * 0.85f));
                this.sb_both_disk_volume.setMax(100);
                this.sb_both_disk_volume.setProgress(50);
                this.iv_recording.setOnTouchListener(this);
                this.iv_equalizer.setOnTouchListener(this);
                this.iv_cues_sound.setOnTouchListener(this);
                this.iv_loop_sound.setOnTouchListener(this);
                this.iv_other_sound.setOnTouchListener(this);
                rl_diskA.setOnTouchListener(this);
                rl_diskB.setOnTouchListener(this);
                this.iv_add_musicA.setOnTouchListener(this);
                this.iv_add_musicB.setOnTouchListener(this);
                iv_play_musicA.setOnTouchListener(this);
                iv_play_musicB.setOnTouchListener(this);
                this.iv_reset_volumeA.setOnTouchListener(this);
                this.iv_reset_volumeB.setOnTouchListener(this);
                this.sb_diskA.setOnSeekBarChangeListener(this);
                this.sb_diskB.setOnSeekBarChangeListener(this);
                this.vs_speedA.setOnSeekBarChangeListener(this);
                this.vs_speedB.setOnSeekBarChangeListener(this);
                this.vs_volumeA.setOnSeekBarChangeListener(this);
                this.vs_volumeB.setOnSeekBarChangeListener(this);
                this.sb_both_disk_volume.setOnSeekBarChangeListener(this);
                return;
            }
        }
    }

    private void bindDisk1() {
        int audioSessionId = disk_player[0].getAudioSessionId();
        this.audio_session_idA = audioSessionId;
        if (audioSessionId != -1) {
            try {
                Equalizer equalizer = new Equalizer(0, audioSessionId);
                this.equalizerA = equalizer;
                int numberOfBands = equalizer.getNumberOfBands();
                this.num_of_bandsA = numberOfBands;
                this.sb_bandA = new CustomSeekbar[numberOfBands];
                for (int i = 0; i < this.num_of_bandsA; i++) {
                    this.sb_bandA[i] = (CustomSeekbar) findViewById(this.sb_left_bandId[i]);
                    this.sb_bandA[i].setProgressAndThumb(this.equalizerA.getBandLevel((short) i) + 1500);
                    this.sb_bandA[i].setOnSeekBarChangeListener(this);
                }
                this.band_level_rangA = this.equalizerA.getBandLevelRange();
                this.equalizerA.setEnabled(true);
            } catch (Exception unused) {
            }
        }
    }

    private void bindDisk2() {
        int audioSessionId = disk_player[1].getAudioSessionId();
        this.audio_session_idB = audioSessionId;
        if (audioSessionId != -1) {
            try {
                Equalizer equalizer = new Equalizer(0, audioSessionId);
                this.equalizerB = equalizer;
                int numberOfBands = equalizer.getNumberOfBands();
                this.num_of_bandsB = numberOfBands;
                this.sb_bandB = new CustomSeekbar[numberOfBands];
                for (int i = 0; i < this.num_of_bandsB; i++) {
                    this.sb_bandB[i] = (CustomSeekbar) findViewById(this.sb_right_bandId[i]);
                    this.sb_bandB[i].setProgressAndThumb(this.equalizerB.getBandLevel((short) i) + 1500);
                    this.sb_bandB[i].setOnSeekBarChangeListener(this);
                }
                this.band_level_rangB = this.equalizerB.getBandLevelRange();
                this.equalizerB.setEnabled(true);
            } catch (Exception unused) {
            }
        }
    }

    public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        int id = seekBar.getId();
        switch (id) {
            case R.id.sb_both_disk_volume:
                controlBothVolume(i);
                break;
            case R.id.sb_diskA:
                if (z) {
                    seekMusic(i, 0);
                    break;
                }
                break;
            case R.id.sb_diskB_rkappzia:
                if (z) {
                    seekMusic(i, 1);
                    break;
                }
                break;
            default:
                switch (id) {
                    case R.id.vs_speedA_rkappzia:
                        float f = ((float) (i + 50)) * 0.01f;
                        this.current_speedA = f;
                        setMusicSpeedDiskA(f);
                        break;
                    case R.id.vs_speedB_rkappzia:
                        float f2 = ((float) (i + 50)) * 0.01f;
                        this.current_speedB = f2;
                        setMusicSpeedDiskB(f2);
                        break;
                    case R.id.vs_volumeA:
                        controlMusicVolume(i, 0);
                        break;
                    case R.id.vs_volumeB:
                        controlMusicVolume(i, 1);
                        break;
                }
        }
        for (int i2 = 0; i2 < this.num_of_bandsA; i2++) {
            if (seekBar.getId() == this.sb_left_bandId[i2]) {
                this.equalizerA.setBandLevel((short) i2, (short) (i - 1500));
            }
        }
        for (int i3 = 0; i3 < this.num_of_bandsB; i3++) {
            if (seekBar.getId() == this.sb_right_bandId[i3]) {
                this.equalizerB.setBandLevel((short) i3, (short) (i - 1500));
                return;
            }
        }
    }

    private void controlMusicVolume(int i, int i2) {
        float progress = ((float) this.sb_both_disk_volume.getProgress()) / 100.0f;
        if (disk_player[i2].isPlaying()) {
            disk_player[i2].pause();
            if (i2 == 0) {
                MediaPlayer mediaPlayer = disk_player[i2];
                float f = (((float) i) * (1.0f - progress)) / ((float) this.maxVolume);
                mediaPlayer.setVolume(f, f);
            } else if (i2 == 1) {
                MediaPlayer mediaPlayer2 = disk_player[i2];
                float f2 = (((float) i) * progress) / ((float) this.maxVolume);
                mediaPlayer2.setVolume(f2, f2);
            }
            disk_player[i2].start();
        } else if (i2 == 0) {
            MediaPlayer mediaPlayer3 = disk_player[i2];
            float f3 = (((float) i) * (1.0f - progress)) / ((float) this.maxVolume);
            mediaPlayer3.setVolume(f3, f3);
        } else if (i2 == 1) {
            MediaPlayer mediaPlayer4 = disk_player[i2];
            float f4 = (((float) i) * progress) / ((float) this.maxVolume);
            mediaPlayer4.setVolume(f4, f4);
        }
    }

    private void controlBothVolume(int i) {
        float progress = ((float) this.vs_volumeA.getProgress()) / ((float) this.maxVolume);
        float progress2 = ((float) this.vs_volumeB.getProgress()) / ((float) this.maxVolume);
        float f = ((float) i) / 100.0f;
        int i2 = 0;
        while (true) {
            MediaPlayer[] mediaPlayerArr = disk_player;
            if (i2 < mediaPlayerArr.length) {
                if (mediaPlayerArr[i2].isPlaying()) {
                    if (i2 == 0) {
                        float f2 = (1.0f - f) * progress;
                        disk_player[i2].setVolume(f2, f2);
                    } else if (i2 == 1) {
                        float f3 = progress2 * f;
                        disk_player[i2].setVolume(f3, f3);
                    }
                    disk_player[i2].start();
                } else if (i2 == 0) {
                    float f4 = (1.0f - f) * progress;
                    disk_player[i2].setVolume(f4, f4);
                } else if (i2 == 1) {
                    float f5 = progress2 * f;
                    disk_player[i2].setVolume(f5, f5);
                }
                i2++;
            } else {
                return;
            }
        }
    }

    private void seekMusic(int i, int i2) {
        disk_player[i2].seekTo(i);
    }

    private boolean setMusicSpeedDiskA(float f) {
        if (Build.VERSION.SDK_INT < 23) {
            return false;
        }
        try {
            PlaybackParams playbackParams = disk_player[0].getPlaybackParams();
            playbackParams.setSpeed(f);
            playbackParams.setPitch(f);
            disk_player[0].setPlaybackParams(playbackParams);
            iv_play_musicA.setImageResource(R.drawable.ic_mic_pause);
            return true;
        } catch (Exception unused) {
            return true;
        }
    }

    private boolean setMusicSpeedDiskB(float f) {
        if (Build.VERSION.SDK_INT < 23) {
            return false;
        }
        try {
            PlaybackParams playbackParams = disk_player[1].getPlaybackParams();
            playbackParams.setSpeed(f);
            playbackParams.setPitch(f);
            disk_player[1].setPlaybackParams(playbackParams);
            iv_play_musicB.setImageResource(R.drawable.ic_mic_pause);
        } catch (Exception unused) {
        }
        return true;
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            for (int i = 0; i < 12; i++) {
                if (view.getId() == this.iv_other_soundId[i]) {
                    if (other_sound_player[i].isPlaying()) {
                        if (other_sound_player[i].isPlaying()) {
                            other_sound_player[i].pause();
                            other_sound_player[i].seekTo(0);
                        }
                    } else if (!other_sound_player[i].isPlaying()) {
                        other_sound_player[i].start();
                    }
                }
            }
            switch (view.getId()) {
                case R.id.iv_add_musicA_rkappzia:
                    if (Build.VERSION.SDK_INT >= 33) {
                        if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") != 0 || ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_VIDEO") != 0 || ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_IMAGES") != 0 || ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_AUDIO") != 0) {
                            requestStorage();
                            break;
                        } else {
                            this.goToMusicLib = true;
                            startActivityForResult(new Intent(MixerActivity.this, LibraryActivity.class), 1);
                            disk_index = 0;
                            isLoadMusicA = true;
                            MusicConstant.ActivityFlag = "";
                            break;
                        }
                    } else if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") != 0 || ActivityCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") != 0) {
                        requestStorage();
                        break;
                    } else {
                        this.goToMusicLib = true;
                        startActivityForResult(new Intent(MixerActivity.this, LibraryActivity.class), 1);

                        disk_index = 0;
                        isLoadMusicA = true;
                        MusicConstant.ActivityFlag = "";
                        break;
                    }
                case R.id.iv_add_musicB_rkappzia:
                    if (Build.VERSION.SDK_INT >= 33) {
                        if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") != 0 || ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_VIDEO") != 0 || ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_IMAGES") != 0 || ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_AUDIO") != 0) {
                            requestStorage();
                            break;
                        } else {
                            this.goToMusicLib = true;
                            startActivityForResult(new Intent(MixerActivity.this, LibraryActivity.class), 1);
                            disk_index = 1;
                            isLoadMusicB = true;
                            MusicConstant.ActivityFlag = "";
                            break;
                        }
                    } else if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") != 0 || ActivityCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") != 0) {
                        requestStorage();
                        break;
                    } else {
                        this.goToMusicLib = true;
                        startActivityForResult(new Intent(MixerActivity.this, LibraryActivity.class), 1);
                        disk_index = 1;
                        isLoadMusicB = true;
                        MusicConstant.ActivityFlag = "";
                        break;
                    }
                case R.id.iv_cues_sound:
                    if (this.ly_cues_sound.getVisibility() == View.VISIBLE) {
                        this.iv_cues_sound.setImageResource(R.drawable.ic_cues);
                        this.rl_disk.setVisibility(View.VISIBLE);
                        this.ly_equalizer.setVisibility(View.GONE);
                        this.ly_cues_sound.setVisibility(View.GONE);
                        this.ly_loop_sound.setVisibility(View.GONE);
                        this.ly_other_sound.setVisibility(View.GONE);
                        break;
                    } else {
                        this.iv_equalizer.setImageResource(R.drawable.ic_equilizer);
                        this.iv_cues_sound.setImageResource(R.drawable.ic_cues_selected);
                        this.iv_loop_sound.setImageResource(R.drawable.ic_loop);
                        this.iv_other_sound.setImageResource(R.drawable.ic_other_sound);
                        this.rl_disk.setVisibility(View.GONE);
                        this.ly_equalizer.setVisibility(View.GONE);
                        this.ly_cues_sound.setVisibility(View.VISIBLE);
                        this.ly_loop_sound.setVisibility(View.GONE);
                        this.ly_other_sound.setVisibility(View.GONE);
                        break;
                    }
                case R.id.iv_equalizer:
                    if (this.ly_equalizer.getVisibility() == View.VISIBLE) {
                        this.iv_equalizer.setImageResource(R.drawable.ic_equilizer);
                        this.rl_disk.setVisibility(View.VISIBLE);
                        this.ly_equalizer.setVisibility(View.GONE);
                        this.ly_cues_sound.setVisibility(View.GONE);
                        this.ly_loop_sound.setVisibility(View.GONE);
                        this.ly_other_sound.setVisibility(View.GONE);
                        break;
                    } else {
                        this.iv_equalizer.setImageResource(R.drawable.ic_equilizer_selected);
                        this.iv_cues_sound.setImageResource(R.drawable.ic_cues);
                        this.iv_loop_sound.setImageResource(R.drawable.ic_loop);
                        this.iv_other_sound.setImageResource(R.drawable.ic_other_sound);
                        this.rl_disk.setVisibility(View.GONE);
                        this.ly_equalizer.setVisibility(View.VISIBLE);
                        this.ly_cues_sound.setVisibility(View.GONE);
                        this.ly_loop_sound.setVisibility(View.GONE);
                        this.ly_other_sound.setVisibility(View.GONE);
                        break;
                    }
                case R.id.iv_loop_sound:
                    if (this.ly_loop_sound.getVisibility() == View.VISIBLE) {
                        this.iv_loop_sound.setImageResource(R.drawable.ic_loop);
                        this.rl_disk.setVisibility(View.VISIBLE);
                        this.ly_equalizer.setVisibility(View.GONE);
                        this.ly_cues_sound.setVisibility(View.GONE);
                        this.ly_loop_sound.setVisibility(View.GONE);
                        this.ly_other_sound.setVisibility(View.GONE);
                        break;
                    } else {
                        this.iv_equalizer.setImageResource(R.drawable.ic_equilizer);
                        this.iv_cues_sound.setImageResource(R.drawable.ic_cues);
                        this.iv_loop_sound.setImageResource(R.drawable.ic_loop_selected);
                        this.iv_other_sound.setImageResource(R.drawable.ic_other_sound);
                        this.rl_disk.setVisibility(View.GONE);
                        this.ly_equalizer.setVisibility(View.GONE);
                        this.ly_cues_sound.setVisibility(View.GONE);
                        this.ly_loop_sound.setVisibility(View.VISIBLE);
                        this.ly_other_sound.setVisibility(View.GONE);
                        break;
                    }
                case R.id.iv_other_sound:
                    if (this.ly_other_sound.getVisibility() == View.VISIBLE) {
                        this.iv_other_sound.setImageResource(R.drawable.ic_other_sound);
                        this.rl_disk.setVisibility(View.VISIBLE);
                        this.ly_equalizer.setVisibility(View.GONE);
                        this.ly_cues_sound.setVisibility(View.GONE);
                        this.ly_loop_sound.setVisibility(View.GONE);
                        this.ly_other_sound.setVisibility(View.GONE);
                        break;
                    } else {
                        this.iv_equalizer.setImageResource(R.drawable.ic_equilizer);
                        this.iv_cues_sound.setImageResource(R.drawable.ic_cues);
                        this.iv_loop_sound.setImageResource(R.drawable.ic_loop);
                        this.iv_other_sound.setImageResource(R.drawable.ic_other_sound_select);
                        this.rl_disk.setVisibility(View.GONE);
                        this.ly_equalizer.setVisibility(View.GONE);
                        this.ly_cues_sound.setVisibility(View.GONE);
                        this.ly_loop_sound.setVisibility(View.GONE);
                        this.ly_other_sound.setVisibility(View.VISIBLE);
                        break;
                    }
                case R.id.iv_play_musicA_rkappzia:
                    if (!isLoadMusicA) {
                        if (Tool.isPermissionGranted(this)) {
                            MusicConstant.ActivityFlag = "MusicLibraryActivityA";
                            break;
                        }
                    } else {
                        controlPlayMusic(R.id.iv_play_musicA_rkappzia, 0);
                        break;
                    }
                    break;
                case R.id.iv_play_musicB_rkappzia:
                    if (!isLoadMusicB) {
                        if (Tool.isPermissionGranted(this)) {
                            this.goToMusicLib = true;
                            startActivityForResult(new Intent(MixerActivity.this, LibraryActivity.class), 1);
                            disk_index = 1;
                            isLoadMusicB = true;
                            MusicConstant.ActivityFlag = "";
                            break;
                        }
                    } else {
                        controlPlayMusic(R.id.iv_play_musicB_rkappzia, 1);
                        break;
                    }
                    break;
                case R.id.iv_recording_rkappzia:
                    if (Build.VERSION.SDK_INT >= 33) {
                        if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") != 0 || ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_VIDEO") != 0 || ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_IMAGES") != 0 || ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_AUDIO") != 0) {
                            requestStorage();
                            break;
                        } else {
                            run();
                            break;
                        }
                    } else if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") != 0 || ActivityCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") != 0) {
                        requestStorage();
                        break;
                    } else {
                        run();
                    }
                    break;
                case R.id.iv_reset_volumeA_rkappzia:
                    for (int i2 = 0; i2 < this.num_of_bandsA; i2++) {
                        if (i2 == 0 || i2 == 4) {
                            short s = (short) i2;
                            this.equalizerA.setBandLevel(s, (short) 300);
                            this.sb_bandA[i2].setProgressAndThumb(this.equalizerA.getBandLevel(s) + 1500);
                        } else {
                            short s2 = (short) i2;
                            this.equalizerA.setBandLevel(s2, (short) 0);
                            this.sb_bandA[i2].setProgressAndThumb(this.equalizerA.getBandLevel(s2) + 1500);
                        }
                    }
                    break;
                case R.id.iv_reset_volumeB_rkappzia:
                    for (int i3 = 0; i3 < this.num_of_bandsB; i3++) {
                        if (i3 == 0 || i3 == 4) {
                            short s3 = (short) i3;
                            this.equalizerB.setBandLevel(s3, (short) 300);
                            this.sb_bandB[i3].setProgressAndThumb(this.equalizerB.getBandLevel(s3) + 1500);
                        } else {
                            short s4 = (short) i3;
                            this.equalizerB.setBandLevel(s4, (short) 0);
                            this.sb_bandB[i3].setProgressAndThumb(this.equalizerB.getBandLevel(s4) + 1500);
                        }
                    }
                    break;
            }
        }
        if (view.getId() == R.id.rl_diskA) {
            float width = (float) (rl_diskA.getWidth() / 2);
            float height = (float) (rl_diskA.getHeight() / 2);
            float x = motionEvent.getX();
            float y = motionEvent.getY();
            int action = motionEvent.getAction();
            if (action == 0) {
                try {
                    setMusicSpeedDiskA(5.75f);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (disk_player[0].isPlaying()) {
                    disk_player[0].pause();
                }
                rl_diskA.clearAnimation();
                this.current_angle = Math.toDegrees(Math.atan2((double) (x - width), (double) (height - y)));
            } else if (action == 1) {
                this.current_angle = 0.0d;
                this.prev_angle = 0.0d;
                rl_diskA.startAnimation(rotate_diskA);
                iv_play_musicA.setImageResource(R.drawable.ic_mic_pause);
                vumeterA.resume(true);
                if (!disk_player[0].isPlaying()) {
                    startHandleAnimation(iv_handle1);
                }
                isLoadMusicA = true;
                disk_player[0].start();
                startServiceAction();
                try {
                    setMusicSpeedDiskA(this.current_speedA);
                } catch (IllegalStateException e2) {
                    e2.printStackTrace();
                }
                this.sb_diskA.setProgress(disk_player[0].getCurrentPosition());
            } else if (action == 2) {
                this.prev_angle = this.current_angle;
                this.current_angle = Math.toDegrees(Math.atan2((double) (x - width), (double) (height - y)));
                this.disk = 0;
                disk_player[0].start();
                double d = this.prev_angle;
                double d2 = this.current_angle;
                if (d < d2) {
                    animateDisk(d, d2, false, true);
                } else {
                    animateDisk(d, d2, false, false);
                }
            }
        }
        if (view.getId() == R.id.rl_diskB) {
            float width2 = (float) (rl_diskB.getWidth() / 2);
            float height2 = (float) (rl_diskB.getHeight() / 2);
            float x2 = motionEvent.getX();
            float y2 = motionEvent.getY();
            int action2 = motionEvent.getAction();
            if (action2 == 0) {
                try {
                    setMusicSpeedDiskB(5.75f);
                } catch (Exception e3) {
                    e3.printStackTrace();
                }
                if (disk_player[1].isPlaying()) {
                    disk_player[1].pause();
                }
                rl_diskB.clearAnimation();
                this.current_angle = Math.toDegrees(Math.atan2((double) (x2 - width2), (double) (height2 - y2)));
            } else if (action2 == 1) {
                this.current_angle = 0.0d;
                this.prev_angle = 0.0d;
                rl_diskB.startAnimation(rotate_diskB);
                iv_play_musicB.setImageResource(R.drawable.ic_mic_pause);
                vumeterB.resume(true);
                if (!disk_player[1].isPlaying()) {
                    startHandleAnimation(iv_handle2);
                }
                isLoadMusicB = true;
                disk_player[1].start();
                startServiceAction();
                try {
                    setMusicSpeedDiskB(this.current_speedB);
                } catch (IllegalStateException e4) {
                    e4.printStackTrace();
                }
                this.sb_diskB.setProgress(disk_player[1].getCurrentPosition());
            } else if (action2 == 2) {
                this.prev_angle = this.current_angle;
                this.current_angle = Math.toDegrees(Math.atan2((double) (x2 - width2), (double) (height2 - y2)));
                this.disk = 1;
                disk_player[1].start();
                double d3 = this.prev_angle;
                double d4 = this.current_angle;
                if (d3 < d4) {
                    animateDisk(d3, d4, true, true);
                } else {
                    animateDisk(d3, d4, true, false);
                }
            }
        }
        return true;
    }

    private void requestStorage() {
        if (Build.VERSION.SDK_INT >= 33) {
            this.permissionsResult.launch(new String[]{this.readMediaPermission, this.readMediaPermission2, this.readMediaPermission3, this.readMediaPermission4});
            return;
        }
        this.permissionsResult.launch(new String[]{this.storagePermission, this.readMediaPermission4});
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void dialogPermission() {
        AlertDialog create = new AlertDialog.Builder(this, R.style.AlertDialogCustom).create();
        create.setTitle(getString(R.string.Grant_Permission));
        create.setCancelable(false);
        create.setMessage(getString(R.string.Please_grant_all_permissions));
        create.setButton(-1, getString(R.string.Go_to_setting), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                create.dismiss();
                Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
                intent.setData(Uri.fromParts("package", getApplicationContext().getPackageName(), null));
                startActivity(intent);
                create.dismiss();
            }
        });
        create.show();
    }

    public void run() {
        MediaPlayer[] mediaPlayerArr = disk_player;
        if (mediaPlayerArr[0] == null || !mediaPlayerArr[0].isPlaying()) {
            MediaPlayer[] mediaPlayerArr2 = disk_player;
            if ((mediaPlayerArr2[1] == null || !mediaPlayerArr2[1].isPlaying()) && !this.isRecordMusic) {
                Toast.makeText(this, getString(R.string.Start_Playing_a_Song), Toast.LENGTH_SHORT).show();
            }
        }
        if (!this.isRecordMusic) {
            try {
                File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC).toString() + File.separator + getResources().getString(R.string.app_name));
                if (!file.exists()) {
                    file.mkdir();
                }
                String path = file.getPath();
                File file2 = new File(path, getResources().getString(R.string.app_name) + " " + new SimpleDateFormat("yyyy_MM_dd hh_mm_ss").format(new Date()) + ".mp3");
                MediaRecorder mediaRecorder2 = new MediaRecorder();
                this.mediaRecorder = mediaRecorder2;
                mediaRecorder2.reset();
                this.mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                this.mediaRecorder.setOutputFile(file2.getAbsolutePath());
                this.mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.DEFAULT);
                this.mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.DEFAULT);
                this.mediaRecorder.setAudioEncodingBitRate(128000);
                this.mediaRecorder.setAudioChannels(2);
                this.mediaRecorder.setAudioSamplingRate(44100);
                this.mediaRecorder.prepare();
                this.mediaRecorder.start();
                Toast.makeText(this, getString(R.string.Recording_Started_Mixer), Toast.LENGTH_LONG).show();
                startTimer();
                this.isRecordMusic = true;
                this.iv_recording.setImageResource(R.drawable.ic_recording_started);
                this.tv_duration.setVisibility(View.VISIBLE);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
                this.countDownTimer.cancel();
                this.second = -1;
                this.minute = 0;
                this.tv_duration.setText("00:00");
                this.isRecordMusic = false;
                this.mediaRecorder.stop();
                this.mediaRecorder.release();
                Toast.makeText(this, getString(R.string.Recording_Saved_mixer), Toast.LENGTH_LONG).show();
                this.iv_recording.setImageResource(R.drawable.ic_recording_stopped);
                this.tv_duration.setVisibility(View.GONE);
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    private void animateDisk(double d, double d2, boolean z, boolean z2) {
        RotateAnimation rotateAnimation = new RotateAnimation((float) d, (float) d2, 1, 0.5f, 1, 0.5f);
        rotateAnimation.setDuration(0);
        rotateAnimation.setFillEnabled(true);
        rotateAnimation.setFillAfter(true);
        if (z) {
            rl_diskB.startAnimation(rotateAnimation);
        } else {
            rl_diskA.startAnimation(rotateAnimation);
        }
        try {
            if (Build.VERSION.SDK_INT <= 23) {
                if (!z2) {
                    int i = this.disk_touch_count;
                    if (i == 3) {
                        this.disk_touch_count = 0;
                        MediaPlayer[] mediaPlayerArr = disk_player;
                        int i2 = this.disk;
                        mediaPlayerArr[i2].seekTo(mediaPlayerArr[i2].getCurrentPosition() - 800);
                        return;
                    }
                    this.disk_touch_count = i + 1;
                    return;
                }
                int i3 = this.disk_touch_count;
                if (i3 == 3) {
                    this.disk_touch_count = 0;
                    MediaPlayer[] mediaPlayerArr2 = disk_player;
                    int i4 = this.disk;
                    mediaPlayerArr2[i4].seekTo(mediaPlayerArr2[i4].getCurrentPosition() + 800);
                    return;
                }
                this.disk_touch_count = i3 + 1;
            } else if (!z2) {
                int i5 = this.disk_touch_count;
                if (i5 == 3) {
                    this.disk_touch_count = 0;
                    MediaPlayer[] mediaPlayerArr3 = disk_player;
                    int i6 = this.disk;
                    mediaPlayerArr3[i6].seekTo(mediaPlayerArr3[i6].getCurrentPosition() - 800);
                    return;
                }
                this.disk_touch_count = i5 + 1;
            } else {
                int i7 = this.disk_touch_count;
                if (i7 == 3) {
                    this.disk_touch_count = 0;
                    MediaPlayer[] mediaPlayerArr4 = disk_player;
                    int i8 = this.disk;
                    mediaPlayerArr4[i8].seekTo(mediaPlayerArr4[i8].getCurrentPosition() + 800);
                    return;
                }
                this.disk_touch_count = i7 + 1;
            }
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
    }

    private void startTimer() {
        CountDownTimer r6 = new CountDownTimer(Long.MAX_VALUE, 1000) {
            /* class com.djmusicmixer.djmixer.audiomixer.mixer.MixerActivity.AnonymousClass10 */

            public void onFinish() {
            }

            public void onTick(long j) {
                MixerActivity.this.second++;
                MixerActivity.this.tv_duration.setText(MixerActivity.this.recorderTime());
            }
        };
        this.countDownTimer = r6;
        r6.start();
    }

    public String recorderTime() {
        if (this.second == 60) {
            this.minute++;
            this.second = 0;
        }
        if (this.minute == 60) {
            this.minute = 0;
        }
        return String.format("%02d:%02d", Integer.valueOf(this.minute), Integer.valueOf(this.second));
    }

    private void controlPlayMusic(int i, int i2) {
        ImageView imageView = (ImageView) findViewById(i);
        if (disk_player[i2].isPlaying()) {
            disk_player[i2].pause();
            imageView.setImageResource(R.drawable.ic_mic_play);
            startServiceAction();
            if (i2 == 0) {
                vumeterA.pause();
                stopHandleAnimation(iv_handle1);
                rotate_diskA.cancel();
            } else if (i2 == 1) {
                vumeterB.pause();
                stopHandleAnimation(iv_handle2);
                rotate_diskB.cancel();
            }
        } else {
            disk_player[i2].start();
            imageView.setImageResource(R.drawable.ic_mic_pause);
            startServiceAction();
            if (i2 == 0) {
                vumeterA.resume(true);
                startHandleAnimation(iv_handle1);
                rl_diskA.startAnimation(rotate_diskA);
            } else if (i2 == 1) {
                vumeterB.resume(true);
                startHandleAnimation(iv_handle2);
                rl_diskB.startAnimation(rotate_diskB);
            }
        }
    }

    public void onClick(View view) {
        breakPointClick(view);
        int i = 6;
        int i2 = 0;
        switch (view.getId()) {
            case R.id.iv_back:
                onBackPressed();
                break;
            case R.id.iv_clearA:
                if (this.isClearSelectedA) {
                    this.isClearSelectedA = false;
                    this.iv_clearA.setImageResource(R.drawable.ic_clear);
                    for (int i3 = 0; i3 < 8; i3++) {
                        if (!this.tv_breakpoint_time_Arr[i3].getText().toString().equals("")) {
                            this.iv_closeloop_Arr[i3].setVisibility(View.GONE);
                            this.tv_breakpoint_Arr[i3].setVisibility(View.VISIBLE);
                            this.tv_display_time_Arr[i3].setVisibility(View.VISIBLE);
                        }
                    }
                    break;
                } else {
                    for (int i4 = 0; i4 < 8; i4++) {
                        if (!this.tv_breakpoint_time_Arr[i4].getText().toString().equals("")) {
                            this.isClearSelectedA = true;
                            this.iv_clearA.setImageResource(R.drawable.ic_clear_selecteda);
                            this.iv_closeloop_Arr[i4].setVisibility(View.VISIBLE);
                            this.tv_breakpoint_Arr[i4].setVisibility(View.GONE);
                            this.tv_display_time_Arr[i4].setVisibility(View.GONE);
                        }
                    }
                    break;
                }
            case R.id.iv_clearB:
                if (this.isClearSelectedB) {
                    this.isClearSelectedB = false;
                    this.iv_clearB.setImageResource(R.drawable.ic_clear);
                    for (int i5 = 8; i5 < 16; i5++) {
                        if (!this.tv_breakpoint_time_Arr[i5].getText().toString().equals("")) {
                            this.iv_closeloop_Arr[i5].setVisibility(View.GONE);
                            this.tv_breakpoint_Arr[i5].setVisibility(View.VISIBLE);
                            this.tv_display_time_Arr[i5].setVisibility(View.VISIBLE);
                        }
                    }
                    break;
                } else {
                    for (int i6 = 8; i6 < 16; i6++) {
                        if (!this.tv_breakpoint_time_Arr[i6].getText().toString().equals("")) {
                            this.isClearSelectedB = true;
                            this.iv_clearB.setImageResource(R.drawable.ic_clear_selectedb);
                            this.iv_closeloop_Arr[i6].setVisibility(View.VISIBLE);
                            this.tv_breakpoint_Arr[i6].setVisibility(View.GONE);
                            this.tv_display_time_Arr[i6].setVisibility(View.GONE);
                        }
                    }
                    break;
                }
            case R.id.iv_mixes_list_rkappzia:
                if (this.isRecordMusic) {
                    this.countDownTimer.cancel();
                    this.second = -1;
                    this.minute = 0;
                    this.tv_duration.setText("00:00");
                    this.isRecordMusic = false;
                    this.mediaRecorder.stop();
                    this.mediaRecorder.release();
                    Toast.makeText(this, getString(R.string.Recording_Saved_mixer), Toast.LENGTH_LONG).show();
                    this.iv_recording.setImageResource(R.drawable.ic_recording_stopped);
                    this.tv_duration.setVisibility(View.GONE);
                    Intent intent = new Intent(MixerActivity.this, MND_MyMusicActivity.class);
                    intent.putExtra("TAG", "MusicMixerActivity");
                    startActivityForResult(intent, 1);
                    MusicConstant.ActivityFlag = "";
                    break;
                } else {
                    Intent intent2 = new Intent(MixerActivity.this, MND_MyMusicActivity.class);
                    intent2.putExtra("TAG", "MusicMixerActivity");
                    startActivityForResult(intent2, 1);
                    MusicConstant.ActivityFlag = "";
                    break;
                }
            case R.id.iv_nextA:
                int indexOf = this.sliptimeList.indexOf(this.tv_current_sliptimeA.getText().toString()) + 1;
                if (indexOf <= this.sliptimeList.size() - 1) {
                    this.tv_current_sliptimeA.setText(this.sliptimeList.get(indexOf));
                }
                for (int i7 = 0; i7 < 6; i7++) {
                    if (this.isStaticSlipA) {
                        if (this.tv_current_sliptimeA.getText().toString().equals(this.tv_slip_Arr[i7].getText().toString())) {
                            this.tv_slip_Arr[i7].setBackgroundResource(R.drawable.ic_rect_selected);
                            this.tv_slip_Arr[i7].setTextColor(getResources().getColor(R.color.theme1_color));
                        } else {
                            this.tv_slip_Arr[i7].setBackgroundResource(R.drawable.ic_rect);
                            this.tv_slip_Arr[i7].setTextColor(getResources().getColor(R.color.txt_color));
                        }
                    }
                }
                break;
            case R.id.iv_nextB:
                int indexOf2 = this.sliptimeList.indexOf(this.tv_current_sliptimeB.getText().toString()) + 1;
                if (indexOf2 <= this.sliptimeList.size() - 1) {
                    this.tv_current_sliptimeB.setText(this.sliptimeList.get(indexOf2));
                }
                for (int i8 = 6; i8 < 12; i8++) {
                    if (this.isStaticSlipB) {
                        if (this.tv_current_sliptimeB.getText().toString().equals(this.tv_slip_Arr[i8].getText().toString())) {
                            this.tv_slip_Arr[i8].setBackgroundResource(R.drawable.ic_rect_selected);
                            this.tv_slip_Arr[i8].setTextColor(getResources().getColor(R.color.theme2_color));
                        } else {
                            this.tv_slip_Arr[i8].setBackgroundResource(R.drawable.ic_rect);
                            this.tv_slip_Arr[i8].setTextColor(getResources().getColor(R.color.txt_color));
                        }
                    }
                }
                break;
            case R.id.iv_prevA:
                int indexOf3 = this.sliptimeList.indexOf(this.tv_current_sliptimeA.getText().toString()) - 1;
                if (indexOf3 >= 0) {
                    this.tv_current_sliptimeA.setText(this.sliptimeList.get(indexOf3));
                }
                for (int i9 = 0; i9 < 6; i9++) {
                    if (this.isStaticSlipA) {
                        if (this.tv_current_sliptimeA.getText().toString().equals(this.tv_slip_Arr[i9].getText().toString())) {
                            this.tv_slip_Arr[i9].setBackgroundResource(R.drawable.ic_rect_selected);
                            this.tv_slip_Arr[i9].setTextColor(getResources().getColor(R.color.theme1_color));
                        } else {
                            this.tv_slip_Arr[i9].setBackgroundResource(R.drawable.ic_rect);
                            this.tv_slip_Arr[i9].setTextColor(getResources().getColor(R.color.txt_color));
                        }
                    }
                }
                break;
            case R.id.iv_prevB:
                int indexOf4 = this.sliptimeList.indexOf(this.tv_current_sliptimeB.getText().toString()) - 1;
                if (indexOf4 >= 0) {
                    this.tv_current_sliptimeB.setText(this.sliptimeList.get(indexOf4));
                }
                for (int i10 = 6; i10 < 12; i10++) {
                    if (this.isStaticSlipB) {
                        if (this.tv_current_sliptimeB.getText().toString().equals(this.tv_slip_Arr[i10].getText().toString())) {
                            this.tv_slip_Arr[i10].setBackgroundResource(R.drawable.ic_rect_selected);
                            this.tv_slip_Arr[i10].setTextColor(getResources().getColor(R.color.theme2_color));
                        } else {
                            this.tv_slip_Arr[i10].setBackgroundResource(R.drawable.ic_rect);
                            this.tv_slip_Arr[i10].setTextColor(getResources().getColor(R.color.txt_color));
                        }
                    }
                }
                break;
            case R.id.ly_slip_continueA:
                if (this.isStaticSlipA) {
                    this.isStaticSlipA = false;
                    this.ly_slip_continueA.setBackgroundResource(R.drawable.ic_current_loop_bg);
                    this.tv_current_sliptimeA.setTextColor(getResources().getColor(R.color.txt_color));
                    this.iv_slip_flipA.setColorFilter(getResources().getColor(R.color.txt_color));
                    this.tv_outA.setBackgroundResource(R.drawable.ic_rect);
                    this.tv_outA.setTextColor(getResources().getColor(R.color.txt_color));
                } else {
                    this.static_slip_current_posA = disk_player[0].getCurrentPosition();
                    this.isStaticSlipA = true;
                    this.ly_slip_continueA.setBackgroundResource(R.drawable.ic_current_loop_selected1);
                    this.tv_current_sliptimeA.setTextColor(getResources().getColor(R.color.white));
                    this.iv_slip_flipA.setColorFilter(getResources().getColor(R.color.white));
                    this.tv_outA.setBackgroundResource(R.drawable.ic_rect_selected);
                    this.tv_outA.setTextColor(getResources().getColor(R.color.theme1_color));
                }
                for (int i11 = 0; i11 < 6; i11++) {
                    if (!this.isStaticSlipA) {
                        this.tv_slip_Arr[i11].setBackgroundResource(R.drawable.ic_rect);
                        this.tv_slip_Arr[i11].setTextColor(getResources().getColor(R.color.txt_color));
                    } else if (this.tv_current_sliptimeA.getText().toString().equals(this.tv_slip_Arr[i11].getText().toString())) {
                        this.tv_slip_Arr[i11].setBackgroundResource(R.drawable.ic_rect_selected);
                        this.tv_slip_Arr[i11].setTextColor(getResources().getColor(R.color.theme1_color));
                    } else {
                        this.tv_slip_Arr[i11].setBackgroundResource(R.drawable.ic_rect);
                        this.tv_slip_Arr[i11].setTextColor(getResources().getColor(R.color.txt_color));
                    }
                }
                AsyncTask.execute(new Runnable() {
                    /* class com.djmusicmixer.djmixer.audiomixer.mixer.MixerActivity.AnonymousClass11 */

                    public void run() {
                        while (MixerActivity.this.isStaticSlipA) {
                            int indexOf = MixerActivity.this.sliptimeList.indexOf(MixerActivity.this.tv_current_sliptimeA.getText().toString());
                            if (indexOf >= 0 && MixerActivity.disk_player[0] != null && MixerActivity.this.static_slip_current_posA + MixerActivity.this.intArr_sliptime[indexOf] <= MixerActivity.disk_player[0].getCurrentPosition()) {
                                try {
                                    MixerActivity.disk_player[0].seekTo(MixerActivity.this.static_slip_current_posA - MixerActivity.this.intArr_sliptime[indexOf]);
                                } catch (IllegalStateException unused) {
                                }
                            }
                        }
                    }
                });
                break;
            case R.id.ly_slip_continueB:
                if (this.isStaticSlipB) {
                    this.isStaticSlipB = false;
                    this.ly_slip_continueB.setBackgroundResource(R.drawable.ic_current_loop_bg);
                    this.tv_current_sliptimeB.setTextColor(getResources().getColor(R.color.txt_color));
                    this.iv_slip_flipB.setColorFilter(getResources().getColor(R.color.txt_color));
                    this.tv_outB.setBackgroundResource(R.drawable.ic_rect);
                    this.tv_outB.setTextColor(getResources().getColor(R.color.txt_color));
                } else {
                    this.static_slip_current_posB = disk_player[1].getCurrentPosition();
                    this.isStaticSlipB = true;
                    this.ly_slip_continueB.setBackgroundResource(R.drawable.ic_current_loop_selected2);
                    this.tv_current_sliptimeB.setTextColor(getResources().getColor(R.color.white));
                    this.iv_slip_flipB.setColorFilter(getResources().getColor(R.color.white));
                    this.tv_outB.setBackgroundResource(R.drawable.ic_rect_selected);
                    this.tv_outB.setTextColor(getResources().getColor(R.color.theme2_color));
                }
                for (int i12 = 6; i12 < 12; i12++) {
                    if (!this.isStaticSlipB) {
                        this.tv_slip_Arr[i12].setBackgroundResource(R.drawable.ic_rect);
                        this.tv_slip_Arr[i12].setTextColor(getResources().getColor(R.color.txt_color));
                    } else if (this.tv_current_sliptimeB.getText().toString().equals(this.tv_slip_Arr[i12].getText().toString())) {
                        this.tv_slip_Arr[i12].setBackgroundResource(R.drawable.ic_rect_selected);
                        this.tv_slip_Arr[i12].setTextColor(getResources().getColor(R.color.theme2_color));
                    } else {
                        this.tv_slip_Arr[i12].setBackgroundResource(R.drawable.ic_rect);
                        this.tv_slip_Arr[i12].setTextColor(getResources().getColor(R.color.txt_color));
                    }
                }
                try {
                    AsyncTask.execute(new Runnable() {
                        /* class com.djmusicmixer.djmixer.audiomixer.mixer.MixerActivity.AnonymousClass12 */

                        public void run() {
                            while (MixerActivity.this.isStaticSlipB) {
                                try {
                                    int indexOf = MixerActivity.this.sliptimeList.indexOf(MixerActivity.this.tv_current_sliptimeB.getText().toString());
                                    if (indexOf >= 0 && MixerActivity.disk_player[1] != null && MixerActivity.this.static_slip_current_posB + MixerActivity.this.intArr_sliptime[indexOf] <= MixerActivity.disk_player[1].getCurrentPosition()) {
                                        MixerActivity.disk_player[1].seekTo(MixerActivity.this.static_slip_current_posB - MixerActivity.this.intArr_sliptime[indexOf]);
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    });
                    break;
                } catch (Exception e) {
                    e.printStackTrace();
                    break;
                }
            case R.id.tv_inA:
                if (this.isStaticSlipA) {
                    int indexOf5 = this.sliptimeList.indexOf(this.tv_current_sliptimeA.getText().toString()) - 1;
                    if (indexOf5 >= 0) {
                        this.tv_current_sliptimeA.setText(this.sliptimeList.get(indexOf5));
                        for (int i13 = 0; i13 < 6; i13++) {
                            if (this.isStaticSlipA) {
                                if (this.tv_current_sliptimeA.getText().toString().equals(this.tv_slip_Arr[i13].getText().toString())) {
                                    this.tv_slip_Arr[i13].setBackgroundResource(R.drawable.ic_rect_selected);
                                    this.tv_slip_Arr[i13].setTextColor(getResources().getColor(R.color.theme1_color));
                                } else {
                                    this.tv_slip_Arr[i13].setBackgroundResource(R.drawable.ic_rect);
                                    this.tv_slip_Arr[i13].setTextColor(getResources().getColor(R.color.txt_color));
                                }
                            }
                        }
                        break;
                    } else {
                        this.isStaticSlipA = false;
                        this.ly_slip_continueA.setBackgroundResource(R.drawable.ic_current_loop_bg);
                        this.tv_current_sliptimeA.setTextColor(getResources().getColor(R.color.txt_color));
                        this.iv_slip_flipA.setColorFilter(getResources().getColor(R.color.txt_color));
                        while (i2 < 6) {
                            this.tv_slip_Arr[i2].setBackgroundResource(R.drawable.ic_rect);
                            this.tv_slip_Arr[i2].setTextColor(getResources().getColor(R.color.txt_color));
                            i2++;
                        }
                        this.tv_outA.setBackgroundResource(R.drawable.ic_rect);
                        this.tv_outA.setTextColor(getResources().getColor(R.color.txt_color));
                        return;
                    }
                }
                break;
            case R.id.tv_inB:
                if (this.isStaticSlipB) {
                    int indexOf6 = this.sliptimeList.indexOf(this.tv_current_sliptimeB.getText().toString()) - 1;
                    if (indexOf6 >= 0) {
                        this.tv_current_sliptimeB.setText(this.sliptimeList.get(indexOf6));
                        for (int i14 = 6; i14 < 12; i14++) {
                            if (this.isStaticSlipB) {
                                if (this.tv_current_sliptimeB.getText().toString().equals(this.tv_slip_Arr[i14].getText().toString())) {
                                    this.tv_slip_Arr[i14].setBackgroundResource(R.drawable.ic_rect_selected);
                                    this.tv_slip_Arr[i14].setTextColor(getResources().getColor(R.color.theme2_color));
                                } else {
                                    this.tv_slip_Arr[i14].setBackgroundResource(R.drawable.ic_rect);
                                    this.tv_slip_Arr[i14].setTextColor(getResources().getColor(R.color.txt_color));
                                }
                            }
                        }
                        break;
                    } else {
                        this.isStaticSlipB = false;
                        this.ly_slip_continueB.setBackgroundResource(R.drawable.ic_current_loop_bg);
                        this.tv_current_sliptimeB.setTextColor(getResources().getColor(R.color.txt_color));
                        this.iv_slip_flipB.setColorFilter(getResources().getColor(R.color.txt_color));
                        while (i < 12) {
                            this.tv_slip_Arr[i].setBackgroundResource(R.drawable.ic_rect);
                            this.tv_slip_Arr[i].setTextColor(getResources().getColor(R.color.txt_color));
                            i++;
                        }
                        this.tv_outB.setBackgroundResource(R.drawable.ic_rect);
                        this.tv_outB.setTextColor(getResources().getColor(R.color.txt_color));
                        return;
                    }
                }
                break;
            case R.id.tv_outA:
                if (this.isStaticSlipA) {
                    this.isStaticSlipA = false;
                    this.ly_slip_continueA.setBackgroundResource(R.drawable.ic_current_loop_bg);
                    this.tv_current_sliptimeA.setTextColor(getResources().getColor(R.color.txt_color));
                    this.iv_slip_flipA.setColorFilter(getResources().getColor(R.color.txt_color));
                    for (int i15 = 0; i15 < 6; i15++) {
                        this.tv_slip_Arr[i15].setBackgroundResource(R.drawable.ic_rect);
                        this.tv_slip_Arr[i15].setTextColor(getResources().getColor(R.color.txt_color));
                    }
                    this.tv_outA.setBackgroundResource(R.drawable.ic_rect);
                    this.tv_outA.setTextColor(getResources().getColor(R.color.txt_color));
                    break;
                }
                break;
            case R.id.tv_outB:
                if (this.isStaticSlipB) {
                    this.isStaticSlipB = false;
                    this.ly_slip_continueB.setBackgroundResource(R.drawable.ic_current_loop_bg);
                    this.tv_current_sliptimeB.setTextColor(getResources().getColor(R.color.txt_color));
                    this.iv_slip_flipB.setColorFilter(getResources().getColor(R.color.txt_color));
                    for (int i16 = 6; i16 < 12; i16++) {
                        this.tv_slip_Arr[i16].setBackgroundResource(R.drawable.ic_rect);
                        this.tv_slip_Arr[i16].setTextColor(getResources().getColor(R.color.txt_color));
                    }
                    this.tv_outB.setBackgroundResource(R.drawable.ic_rect);
                    this.tv_outB.setTextColor(getResources().getColor(R.color.txt_color));
                    break;
                }
                break;
        }
        while (i2 < 6) {
            if (view.getId() == this.tv_slip_Id[i2]) {
                onClickSlipAText(this.tv_slip_Arr[i2].getText().toString());
            }
            i2++;
        }
        while (i < 12) {
            if (view.getId() == this.tv_slip_Id[i]) {
                onClickSlipBText(this.tv_slip_Arr[i].getText().toString());
            }
            i++;
        }
    }

    private void onClickSlipAText(String str) {
        if (!this.isStaticSlipA) {
            this.tv_current_sliptimeA.setText(str);
            this.static_slip_current_posA = disk_player[0].getCurrentPosition();
            this.isStaticSlipA = true;
            this.ly_slip_continueA.setBackgroundResource(R.drawable.ic_current_loop_selected1);
            this.tv_current_sliptimeA.setTextColor(getResources().getColor(R.color.white));
            this.iv_slip_flipA.setColorFilter(getResources().getColor(R.color.white));
            this.tv_outA.setBackgroundResource(R.drawable.ic_rect_selected);
            this.tv_outA.setTextColor(getResources().getColor(R.color.theme1_color));
        } else if (this.tv_current_sliptimeA.getText().toString().equals(str)) {
            this.isStaticSlipA = false;
            this.ly_slip_continueA.setBackgroundResource(R.drawable.ic_current_loop_bg);
            this.tv_current_sliptimeA.setTextColor(getResources().getColor(R.color.txt_color));
            this.iv_slip_flipA.setColorFilter(getResources().getColor(R.color.txt_color));
            this.tv_outA.setBackgroundResource(R.drawable.ic_rect);
            this.tv_outA.setTextColor(getResources().getColor(R.color.txt_color));
        } else {
            this.tv_current_sliptimeA.setText(str);
        }
        for (int i = 0; i < 6; i++) {
            if (!this.isStaticSlipA) {
                this.tv_slip_Arr[i].setBackgroundResource(R.drawable.ic_rect);
                this.tv_slip_Arr[i].setTextColor(getResources().getColor(R.color.txt_color));
            } else if (this.tv_current_sliptimeA.getText().toString().equals(this.tv_slip_Arr[i].getText().toString())) {
                this.tv_slip_Arr[i].setBackgroundResource(R.drawable.ic_rect_selected);
                this.tv_slip_Arr[i].setTextColor(getResources().getColor(R.color.theme1_color));
            } else {
                this.tv_slip_Arr[i].setBackgroundResource(R.drawable.ic_rect);
                this.tv_slip_Arr[i].setTextColor(getResources().getColor(R.color.txt_color));
            }
        }
        try {
            AsyncTask.execute(new Runnable() {
                /* class com.djmusicmixer.djmixer.audiomixer.mixer.MixerActivity.AnonymousClass13 */

                public void run() {
                    while (MixerActivity.this.isStaticSlipA) {
                        int indexOf = MixerActivity.this.sliptimeList.indexOf(MixerActivity.this.tv_current_sliptimeA.getText().toString());
                        if (indexOf >= 0 && MixerActivity.disk_player[0] != null && MixerActivity.this.static_slip_current_posA + MixerActivity.this.intArr_sliptime[indexOf] <= MixerActivity.disk_player[0].getCurrentPosition()) {
                            try {
                                MixerActivity.disk_player[0].seekTo(MixerActivity.this.static_slip_current_posA - MixerActivity.this.intArr_sliptime[indexOf]);
                            } catch (IllegalStateException unused) {
                            }
                        }
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void onClickSlipBText(String str) {
        if (!this.isStaticSlipB) {
            this.tv_current_sliptimeB.setText(str);
            this.static_slip_current_posB = disk_player[1].getCurrentPosition();
            this.isStaticSlipB = true;
            this.ly_slip_continueB.setBackgroundResource(R.drawable.ic_current_loop_selected2);
            this.tv_current_sliptimeB.setTextColor(getResources().getColor(R.color.white));
            this.iv_slip_flipB.setColorFilter(getResources().getColor(R.color.white));
            this.tv_outB.setBackgroundResource(R.drawable.ic_rect_selected);
            this.tv_outB.setTextColor(getResources().getColor(R.color.theme2_color));
        } else if (this.tv_current_sliptimeB.getText().toString().equals(str)) {
            this.isStaticSlipB = false;
            this.ly_slip_continueB.setBackgroundResource(R.drawable.ic_current_loop_bg);
            this.tv_current_sliptimeB.setTextColor(getResources().getColor(R.color.txt_color));
            this.iv_slip_flipB.setColorFilter(getResources().getColor(R.color.txt_color));
            this.tv_outB.setBackgroundResource(R.drawable.ic_rect);
            this.tv_outB.setTextColor(getResources().getColor(R.color.txt_color));
        } else {
            this.tv_current_sliptimeB.setText(str);
        }
        for (int i = 6; i < 12; i++) {
            if (!this.isStaticSlipB) {
                this.tv_slip_Arr[i].setBackgroundResource(R.drawable.ic_rect);
                this.tv_slip_Arr[i].setTextColor(getResources().getColor(R.color.txt_color));
            } else if (this.tv_current_sliptimeB.getText().toString().equals(this.tv_slip_Arr[i].getText().toString())) {
                this.tv_slip_Arr[i].setBackgroundResource(R.drawable.ic_rect_selected);
                this.tv_slip_Arr[i].setTextColor(getResources().getColor(R.color.theme2_color));
            } else {
                this.tv_slip_Arr[i].setBackgroundResource(R.drawable.ic_rect);
                this.tv_slip_Arr[i].setTextColor(getResources().getColor(R.color.txt_color));
            }
        }
        AsyncTask.execute(new Runnable() {
            /* class com.djmusicmixer.djmixer.audiomixer.mixer.MixerActivity.AnonymousClass14 */

            public void run() {
                while (MixerActivity.this.isStaticSlipB) {
                    int indexOf = MixerActivity.this.sliptimeList.indexOf(MixerActivity.this.tv_current_sliptimeB.getText().toString());
                    if (indexOf >= 0) {
                        try {
                            if (MixerActivity.disk_player[1] != null && MixerActivity.this.static_slip_current_posB + MixerActivity.this.intArr_sliptime[indexOf] <= MixerActivity.disk_player[1].getCurrentPosition()) {
                                Log.d("TAG", "checkpuk: " + MixerActivity.this.static_slip_current_posB + " ,indexof=  " + indexOf + " , sliptime= " + MixerActivity.this.intArr_sliptime[indexOf] + " , " + MixerActivity.disk_player[1].getCurrentPosition());
                                MixerActivity.disk_player[1].seekTo(MixerActivity.this.static_slip_current_posB - MixerActivity.this.intArr_sliptime[indexOf]);
                                StringBuilder sb = new StringBuilder();
                                sb.append("checkpuk: seekto= ");
                                sb.append(MixerActivity.this.static_slip_current_posB - MixerActivity.this.intArr_sliptime[indexOf]);
                                Log.d("TAG", sb.toString());
                            }
                        } catch (IllegalStateException unused) {
                        }
                    }
                }
            }
        });
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (intent == null) {
            this.goToMusicLib = false;
            return;
        }
        this.goToMusicLib = false;
        this.selected_music_path = intent.getStringExtra("selected_music_path");
        if (disk_index == 0) {
            String stringExtra = intent.getStringExtra("selected_music_name");
            Uri parse = Uri.parse(intent.getStringExtra("selected_music_album"));
            TextView textView = tv_musicA;
            if (textView != null) {
                textView.setText(stringExtra);
            }
            TextView textView2 = this.tv_musicAA;
            if (textView2 != null) {
                textView2.setText(stringExtra);
            }
            TextView textView3 = this.tv_musicAAA;
            if (textView3 != null) {
                textView3.setText(stringExtra);
            }
            TextView textView4 = this.tv_musicAAAA;
            if (textView4 != null) {
                textView4.setText(stringExtra);
            }
            ((RequestBuilder) Glide.with((FragmentActivity) this).load(parse).placeholder((int) R.color.transparent)).into(this.iv_thumbA);
        } else {
            String stringExtra2 = intent.getStringExtra("selected_music_name");
            Uri parse2 = Uri.parse(intent.getStringExtra("selected_music_album"));
            TextView textView5 = tv_musicB;
            if (textView5 != null) {
                textView5.setText(stringExtra2);
            }
            TextView textView6 = this.tv_musicBB;
            if (textView6 != null) {
                textView6.setText(stringExtra2);
            }
            TextView textView7 = this.tv_musicBBB;
            if (textView7 != null) {
                textView7.setText(stringExtra2);
            }
            TextView textView8 = this.tv_musicBBBB;
            if (textView8 != null) {
                textView8.setText(stringExtra2);
            }
            ((RequestBuilder) Glide.with((FragmentActivity) this).load(parse2).placeholder((int) R.color.transparent)).into(this.iv_thumbB);
        }
        boolean isPlaying = disk_player[disk_index].isPlaying();
        mixerPlayerRelease(disk_player[disk_index]);
        disk_player[disk_index] = new MediaPlayer();
        try {
            disk_player[disk_index].setDataSource(this.selected_music_path);
        } catch (IOException | IllegalArgumentException e) {
            e.printStackTrace();
        }
        disk_player[disk_index].setAudioStreamType(3);
        try {
            disk_player[disk_index].prepare();
        } catch (IOException | IllegalStateException e2) {
            e2.printStackTrace();
        }
        disk_player[disk_index].setLooping(true);
        if (isPlaying) {
            disk_player[disk_index].start();
            if (disk_index == 0) {
                vumeterA.resume(true);
                startHandleAnimation(iv_handle1);
            } else {
                vumeterB.resume(true);
                startHandleAnimation(iv_handle2);
            }
        }
        int i3 = disk_index;
        if (i3 == 0) {
            this.sb_diskA.setMax(disk_player[i3].getDuration());
            new Thread(this.runnableA).start();
            bindDisk1();
        } else {
            this.sb_diskB.setMax(disk_player[i3].getDuration());
            new Thread(this.runnableB).start();
            bindDisk2();
        }
        startServiceAction();
    }

    private void mixerPlayerRelease(MediaPlayer mediaPlayer) {
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.setLooping(false);
                }
                mediaPlayer.stop();
                mediaPlayer.release();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void breakPointClick(View view) {
        for (int i = 0; i < 8; i++) {
            if (view.getId() == this.rl_breakpoint_Id[i]) {
                MediaPlayer[] mediaPlayerArr = disk_player;
                if (mediaPlayerArr[0] != null && mediaPlayerArr[0].isPlaying() && !this.isClearSelectedA) {
                    if (this.tv_breakpoint_time_Arr[i].getText().toString().equals("")) {
                        this.rl_breakpoint_Arr[i].setBackgroundResource(R.drawable.ic_rect_selected);
                        this.tv_breakpoint_Arr[i].setTextColor(getResources().getColor(R.color.theme1_color));
                        this.tv_breakpoint_time_Arr[i].setText(String.valueOf(disk_player[0].getCurrentPosition()));
                        this.tv_display_time_Arr[i].setText(MusicUtil.getReadableDuration((long) disk_player[0].getCurrentPosition()));
                    } else {
                        disk_player[0].seekTo(Integer.parseInt(this.tv_breakpoint_time_Arr[i].getText().toString()));
                    }
                }
            }
        }
        for (int i2 = 8; i2 < 16; i2++) {
            if (view.getId() == this.rl_breakpoint_Id[i2]) {
                MediaPlayer[] mediaPlayerArr2 = disk_player;
                if (mediaPlayerArr2[1] != null && mediaPlayerArr2[1].isPlaying() && !this.isClearSelectedB) {
                    if (this.tv_breakpoint_time_Arr[i2].getText().toString().equals("")) {
                        this.rl_breakpoint_Arr[i2].setBackgroundResource(R.drawable.ic_rect_selected);
                        this.tv_breakpoint_Arr[i2].setTextColor(getResources().getColor(R.color.theme2_color));
                        this.tv_breakpoint_time_Arr[i2].setText(String.valueOf(disk_player[1].getCurrentPosition()));
                        this.tv_display_time_Arr[i2].setText(MusicUtil.getReadableDuration((long) disk_player[1].getCurrentPosition()));
                    } else {
                        disk_player[1].seekTo(Integer.parseInt(this.tv_breakpoint_time_Arr[i2].getText().toString()));
                    }
                }
            }
        }
        for (int i3 = 0; i3 < 8; i3++) {
            if (view.getId() == this.iv_closeloop_Id[i3]) {
                this.iv_closeloop_Arr[i3].setVisibility(View.GONE);
                this.tv_breakpoint_Arr[i3].setVisibility(View.VISIBLE);
                this.tv_display_time_Arr[i3].setVisibility(View.VISIBLE);
                this.tv_breakpoint_time_Arr[i3].setText("");
                this.tv_display_time_Arr[i3].setText("");
                this.tv_breakpoint_Arr[i3].setTextColor(getResources().getColor(R.color.txt_color));
                this.rl_breakpoint_Arr[i3].setBackgroundResource(R.drawable.ic_rect);
                this.visibility_countA = 0;
                for (int i4 = 0; i4 < 8; i4++) {
                    if (this.iv_closeloop_Arr[i4].getVisibility() == View.GONE) {
                        this.visibility_countA++;
                    }
                }
                if (this.visibility_countA == 8) {
                    this.visibility_countA = 0;
                    this.isClearSelectedA = false;
                    this.iv_clearA.setImageResource(R.drawable.ic_clear);
                }
            }
        }
        for (int i5 = 8; i5 < 16; i5++) {
            if (view.getId() == this.iv_closeloop_Id[i5]) {
                this.iv_closeloop_Arr[i5].setVisibility(View.GONE);
                this.tv_breakpoint_Arr[i5].setVisibility(View.VISIBLE);
                this.tv_display_time_Arr[i5].setVisibility(View.VISIBLE);
                this.tv_breakpoint_time_Arr[i5].setText("");
                this.tv_display_time_Arr[i5].setText("");
                this.tv_breakpoint_Arr[i5].setTextColor(getResources().getColor(R.color.txt_color));
                this.rl_breakpoint_Arr[i5].setBackgroundResource(R.drawable.ic_rect);
                this.visibility_countB = 0;
                for (int i6 = 8; i6 < 16; i6++) {
                    if (this.iv_closeloop_Arr[i6].getVisibility() == View.GONE) {
                        this.visibility_countB++;
                    }
                }
                if (this.visibility_countB == 8) {
                    this.visibility_countB = 0;
                    this.isClearSelectedB = false;
                    this.iv_clearB.setImageResource(R.drawable.ic_clear);
                }
            }
        }
    }

    private void startNotifyService() {

        Intent intent = new Intent(MixerActivity.this, PlayerNotifyService.class);
        intent.putExtra("start_service", "start");
        startService(intent);


    }

    private void changeNotifyService() {

        Intent intent = new Intent(MixerActivity.this, PlayerNotifyService.class);
        intent.putExtra("update_service", "update");
        startService(intent);
          
    }

    private void startServiceAction() {
        if (!this.isServiceRunning) {
            startNotifyService();
            this.isServiceRunning = true;
            return;
        }
        changeNotifyService();
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        this.elapsedTime = System.currentTimeMillis() - this.startTime;
        SystemUtils.setLocale(this);
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.exit);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.setCancelable(false);
        if (this.isRecordMusic) {
            dialog.show();
        } else {
            releaseMediaPlayer();
            finish();
        }
        ((LinearLayout) dialog.findViewById(R.id.btnno)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        ((LinearLayout) dialog.findViewById(R.id.btnyes)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MixerActivity.this.startActivity(new Intent(MixerActivity.this, Drum_Main_Screen.class));
                MixerActivity.this.releaseMediaPlayer();
                MixerActivity.this.finish();
            }
        });
    }

    private void releaseMediaPlayer() {
        int i = 0;
        int i2 = 0;
        while (true) {
            MediaPlayer[] mediaPlayerArr = disk_player;
            if (i2 >= mediaPlayerArr.length) {
                break;
            }
            if (mediaPlayerArr[i2] != null) {
                try {
                    mediaPlayerArr[i2].stop();
                    disk_player[i2].reset();
                    disk_player[i2].release();
                    disk_player[i2] = null;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            i2++;
        }
        while (true) {
            MediaPlayer[] mediaPlayerArr2 = other_sound_player;
            if (i < mediaPlayerArr2.length) {
                if (mediaPlayerArr2[i] != null) {
                    try {
                        mediaPlayerArr2[i].stop();
                        mediaPlayerArr2[i].release();
                        other_sound_player[i] = null;
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                }
                i++;
            } else {
                return;
            }
        }
    }
}
