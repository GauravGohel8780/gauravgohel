package com.djmusicmixer.djmixer.audiomixer.mixer.Adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Genres;
import com.djmusicmixer.djmixer.audiomixer.mixer.Utils.MusicUtil;

import java.util.ArrayList;

public class LibGenresAdapter extends RecyclerView.Adapter<LibGenresAdapter.ViewHolder> {
    private Activity activity;
    public ArrayList<Genres> arrayList;
    public OnGenresClickListener onGenresClickListener;

    public interface OnGenresClickListener {
        void onClick(Genres genres);
    }

    public LibGenresAdapter(Activity activity2, ArrayList<Genres> arrayList2) {
        this.activity = activity2;
        this.arrayList = arrayList2;
    }

    @Override 
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.libalbum_rkappzia_list_item, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        viewHolder.tv_title.setText(this.arrayList.get(i).name);
        viewHolder.tv_info.setText(MusicUtil.getGenreInfo(this.arrayList.get(i)));
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                LibGenresAdapter.this.onGenresClickListener.onClick(LibGenresAdapter.this.arrayList.get(i));
            }
        });
    }

    @Override 
    public int getItemCount() {
        return this.arrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv_info;
        TextView tv_title;

        ViewHolder(View view) {
            super(view);
            this.tv_title = (TextView) view.findViewById(R.id.tv_title_rkappzia);
            this.tv_info = (TextView) view.findViewById(R.id.tv_info);
        }
    }

    public void setOnItemClickListener(OnGenresClickListener onGenresClickListener2) {
        this.onGenresClickListener = onGenresClickListener2;
    }
}
