package com.djmusicmixer.djmixer.audiomixer.activites;

import android.content.Context;
import android.content.res.AssetManager;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Toast;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.base.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;
import com.h6ah4i.android.widget.verticalseekbar.VerticalSeekBar;

import java.io.IOException;

public class DrumDemoActivity extends BaseActivity implements View.OnTouchListener {
    int fc;
    int fd;
    int fe;
    int ff;
    int fg;
    int fh;
    int fi;
    int fj;
    int fk = 0;
    private ImageView img1;
    private ImageView img2;
    private ImageView img3;
    private ImageView img4;
    private ImageView img5;
    private ImageView img6;
    private ImageView img7;
    private ImageView img8;
    AssetManager massestmanager;
    public AudioManager maudiomanager;
    SoundPool msoundpool;
    private VerticalSeekBar seek_Volumn;
    private View view1;
    private View view2;
    private View view3;
    private View view4;
    private View view5;
    private View view6;
    private View view7;
    private View view8;
    public ImageView volumn_up_down;

    private void buttoncolor() {
    }

    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        requestWindowFeature(1);
        getWindow().addFlags(128);
        setContentView(R.layout.activity_drum_demo);
        bind();
    }

    private void bind() {
        this.img1 = (ImageView) findViewById(R.id.img1);
        this.img2 = (ImageView) findViewById(R.id.img2);
        this.img3 = (ImageView) findViewById(R.id.img3);
        this.img4 = (ImageView) findViewById(R.id.img4);
        this.img5 = (ImageView) findViewById(R.id.img5);
        this.img6 = (ImageView) findViewById(R.id.img6);
        this.img7 = (ImageView) findViewById(R.id.img7);
        this.img8 = (ImageView) findViewById(R.id.img8);
        ImageView imageView = this.img1;
        Integer valueOf = Integer.valueOf((int) R.drawable.ic_rimpal1);
        imageView.setTag(valueOf);
        this.img2.setTag(valueOf);
        this.img3.setTag(valueOf);
        this.img4.setTag(valueOf);
        this.img5.setTag(valueOf);
        this.img6.setTag(valueOf);
        this.img7.setTag(valueOf);
        this.img8.setTag(valueOf);
        this.img1.setOnTouchListener(this);
        this.img2.setOnTouchListener(this);
        this.img3.setOnTouchListener(this);
        this.img4.setOnTouchListener(this);
        this.img5.setOnTouchListener(this);
        this.img6.setOnTouchListener(this);
        this.img7.setOnTouchListener(this);
        this.img8.setOnTouchListener(this);
        this.view1 = findViewById(R.id.view1);
        this.view2 = findViewById(R.id.view2);
        this.view3 = findViewById(R.id.view3);
        this.view4 = findViewById(R.id.view4);
        this.view5 = findViewById(R.id.view5);
        this.view6 = findViewById(R.id.view6);
        this.view7 = findViewById(R.id.view7);
        this.view8 = findViewById(R.id.view8);
        ImageView imageView2 = (ImageView) findViewById(R.id.volumn_up_down);
        this.volumn_up_down = imageView2;
        imageView2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity.this.fk == 1) {
                    DrumDemoActivity cNX_DrumDemoActivity = DrumDemoActivity.this;
                    cNX_DrumDemoActivity.fk = 0;
                    cNX_DrumDemoActivity.volumn_up_down.setImageResource(R.drawable.ic_off_drum);
                    return;
                }
                DrumDemoActivity cNX_DrumDemoActivity2 = DrumDemoActivity.this;
                cNX_DrumDemoActivity2.fk = 1;
                cNX_DrumDemoActivity2.volumn_up_down.setImageResource(R.drawable.ic_on_drum);
            }
        });

        this.seek_Volumn = (VerticalSeekBar) findViewById(R.id.seek_Volumn);
        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        this.maudiomanager = audioManager;
        this.seek_Volumn.setMax(audioManager.getStreamMaxVolume(3));
        this.seek_Volumn.setProgress(this.maudiomanager.getStreamVolume(3));
        this.seek_Volumn.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                DrumDemoActivity.this.maudiomanager.setStreamVolume(3, i, 0);
            }
        });
        this.msoundpool = new SoundPool(6, 3, 0);
        this.massestmanager = getAssets();
        this.fc = m43a("crash1.ogg");
        this.fd = m43a("crash2.ogg");
        this.fi = m43a("splash.ogg");
        this.fh = m43a("ride.ogg");
        this.ff = m43a("closehh.ogg");
        this.fg = m43a("openhh.ogg");
        this.fe = m43a("floor.ogg");
        this.fj = m43a("tom1.ogg");
        this.volumn_up_down.setLayoutParams(new LinearLayout.LayoutParams((getResources().getDisplayMetrics().widthPixels * 188) / 1920, (getResources().getDisplayMetrics().heightPixels * 250) / 1080));
    }

    private int m43a(String str) {
        try {
            return this.msoundpool.load(this.massestmanager.openFd(str), 1);
        } catch (IOException e) {
            e.printStackTrace();
            Context applicationContext = getApplicationContext();
            Toast.makeText(applicationContext, R.string.Load_failed + str, Toast.LENGTH_SHORT).show();
            Log.d("FAILED", "Load failed " + str);
            return -1;
        }
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        Object tag = view.getTag();
        if (tag == null) {
            return false;
        }
        int intValue = ((Integer) tag).intValue();
        int action = motionEvent.getAction() & 255;
        if (action == 0 || action == 5) {
            int id = view.getId();
            if (id != R.id.img1) {
                switch (id) {
                    case R.id.img2:
                        buttoncolor();
                        if (this.fk == 1) {
                            this.msoundpool.play(this.fd, 1.0f, 1.0f, 1, 0, 1.0f);
                            this.view1.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view2.setBackgroundColor(getResources().getColor(R.color.btn_press));
                            this.view3.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view4.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view5.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view6.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view7.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view8.setBackgroundColor(getResources().getColor(R.color.white));
                            switch (intValue) {
                                case R.drawable.ic_rimpal:
                                    this.img2.setImageResource(R.drawable.ic_blue_electro_drum);
                                    this.img2.setTag(Integer.valueOf((int) R.drawable.ic_blue_electro_drum));
                                    break;
                                case R.drawable.ic_rimpal1:
                                    this.img2.setImageResource(R.drawable.ic_blue_electro_drum);
                                    this.img2.setTag(Integer.valueOf((int) R.drawable.ic_blue_electro_drum));
                                    break;
                            }
                        }
                        break;
                    case R.id.img3:
                        buttoncolor();
                        if (this.fk == 1) {
                            this.msoundpool.play(this.fe, 1.0f, 1.0f, 1, 0, 1.0f);
                            this.view1.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view2.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view3.setBackgroundColor(getResources().getColor(R.color.btn_press));
                            this.view4.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view5.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view6.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view7.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view8.setBackgroundColor(getResources().getColor(R.color.white));
                            switch (intValue) {
                                case R.drawable.ic_rimpal:
                                    this.img3.setImageResource(R.drawable.ic_green_electro_drum);
                                    this.img3.setTag(Integer.valueOf((int) R.drawable.ic_green_electro_drum));
                                    break;
                                case R.drawable.ic_rimpal1:
                                    this.img3.setImageResource(R.drawable.ic_green_electro_drum);
                                    this.img3.setTag(Integer.valueOf((int) R.drawable.ic_green_electro_drum));
                                    break;
                            }
                        }
                        break;
                    case R.id.img4:
                        buttoncolor();
                        if (this.fk == 1) {
                            this.msoundpool.play(this.ff, 1.0f, 1.0f, 1, 0, 1.0f);
                            this.view1.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view2.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view3.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view4.setBackgroundColor(getResources().getColor(R.color.btn_press));
                            this.view5.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view6.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view7.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view8.setBackgroundColor(getResources().getColor(R.color.white));
                            switch (intValue) {
                                case R.drawable.ic_rimpal:
                                    this.img4.setImageResource(R.drawable.ic_yellow_electro_drum);
                                    this.img4.setTag(Integer.valueOf((int) R.drawable.ic_yellow_electro_drum));
                                    break;
                                case R.drawable.ic_rimpal1:
                                    this.img4.setImageResource(R.drawable.ic_yellow_electro_drum);
                                    this.img4.setTag(Integer.valueOf((int) R.drawable.ic_yellow_electro_drum));
                                    break;
                            }
                        }
                        break;
                    case R.id.img5:
                        buttoncolor();
                        if (this.fk == 1) {
                            this.msoundpool.play(this.fg, 1.0f, 1.0f, 1, 0, 1.0f);
                            this.view1.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view2.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view3.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view4.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view5.setBackgroundColor(getResources().getColor(R.color.btn_press));
                            this.view6.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view7.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view8.setBackgroundColor(getResources().getColor(R.color.white));
                            switch (intValue) {
                                case R.drawable.ic_rimpal:
                                    this.img5.setImageResource(R.drawable.ic_green_electro_drum);
                                    this.img5.setTag(Integer.valueOf((int) R.drawable.ic_green_electro_drum));
                                    break;
                                case R.drawable.ic_rimpal1:
                                    this.img5.setImageResource(R.drawable.ic_green_electro_drum);
                                    this.img5.setTag(Integer.valueOf((int) R.drawable.ic_green_electro_drum));
                                    break;
                            }
                        }
                        break;
                    case R.id.img6:
                        buttoncolor();
                        if (this.fk == 1) {
                            this.msoundpool.play(this.fh, 1.0f, 1.0f, 1, 0, 1.0f);
                            this.view1.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view2.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view3.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view4.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view5.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view6.setBackgroundColor(getResources().getColor(R.color.btn_press));
                            this.view7.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view8.setBackgroundColor(getResources().getColor(R.color.white));
                            switch (intValue) {
                                case R.drawable.ic_rimpal:
                                    this.img6.setImageResource(R.drawable.ic_yellow_electro_drum);
                                    this.img6.setTag(Integer.valueOf((int) R.drawable.ic_yellow_electro_drum));
                                    break;
                                case R.drawable.ic_rimpal1:
                                    this.img6.setImageResource(R.drawable.ic_yellow_electro_drum);
                                    this.img6.setTag(Integer.valueOf((int) R.drawable.ic_yellow_electro_drum));
                                    break;
                            }
                        }
                        break;
                    case R.id.img7:
                        buttoncolor();
                        if (this.fk == 1) {
                            this.msoundpool.play(this.fi, 1.0f, 1.0f, 1, 0, 1.0f);
                            this.view1.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view2.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view3.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view4.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view5.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view6.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view7.setBackgroundColor(getResources().getColor(R.color.btn_press));
                            this.view8.setBackgroundColor(getResources().getColor(R.color.white));
                            switch (intValue) {
                                case R.drawable.ic_rimpal:
                                    this.img7.setImageResource(R.drawable.ic_violet_electro_drum);
                                    this.img7.setTag(Integer.valueOf((int) R.drawable.ic_violet_electro_drum));
                                    break;
                                case R.drawable.ic_rimpal1:
                                    this.img7.setImageResource(R.drawable.ic_violet_electro_drum);
                                    this.img7.setTag(Integer.valueOf((int) R.drawable.ic_violet_electro_drum));
                                    break;
                            }
                        }
                        break;
                    case R.id.img8:
                        buttoncolor();
                        if (this.fk == 1) {
                            this.msoundpool.play(this.fj, 1.0f, 1.0f, 1, 0, 1.0f);
                            this.view1.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view2.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view3.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view4.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view5.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view6.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view7.setBackgroundColor(getResources().getColor(R.color.white));
                            this.view8.setBackgroundColor(getResources().getColor(R.color.btn_press));
                            switch (intValue) {
                                case R.drawable.ic_rimpal:
                                    this.img8.setImageResource(R.drawable.ic_orange_electro_drum);
                                    this.img8.setTag(Integer.valueOf((int) R.drawable.ic_orange_electro_drum));
                                    break;
                                case R.drawable.ic_rimpal1:
                                    this.img8.setImageResource(R.drawable.ic_orange_electro_drum);
                                    this.img8.setTag(Integer.valueOf((int) R.drawable.ic_orange_electro_drum));
                                    break;
                            }
                        }
                        break;
                }
            } else {
                buttoncolor();
                if (this.fk == 1) {
                    this.msoundpool.play(this.fc, 1.0f, 1.0f, 1, 0, 1.0f);
                    this.view1.setBackgroundColor(getResources().getColor(R.color.btn_press));
                    this.view2.setBackgroundColor(getResources().getColor(R.color.white));
                    this.view3.setBackgroundColor(getResources().getColor(R.color.white));
                    this.view4.setBackgroundColor(getResources().getColor(R.color.white));
                    this.view5.setBackgroundColor(getResources().getColor(R.color.white));
                    this.view6.setBackgroundColor(getResources().getColor(R.color.white));
                    this.view7.setBackgroundColor(getResources().getColor(R.color.white));
                    this.view8.setBackgroundColor(getResources().getColor(R.color.white));
                    switch (intValue) {
                        case R.drawable.ic_rimpal:
                            this.img1.setImageResource(R.drawable.ic_orange_electro_drum);
                            this.img1.setTag(Integer.valueOf((int) R.drawable.ic_orange_electro_drum));
                            break;
                        case R.drawable.ic_rimpal1:
                            this.img1.setImageResource(R.drawable.ic_orange_electro_drum);
                            this.img1.setTag(Integer.valueOf((int) R.drawable.ic_orange_electro_drum));
                            break;
                    }
                }
            }
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
