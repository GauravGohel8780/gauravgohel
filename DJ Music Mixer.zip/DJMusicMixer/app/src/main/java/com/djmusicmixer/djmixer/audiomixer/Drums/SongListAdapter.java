package com.djmusicmixer.djmixer.audiomixer.Drums;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.djmusicmixer.djmixer.audiomixer.R;

import java.util.List;

public class SongListAdapter extends BaseAdapter {
    private Context context;
    private List<Song> songs;

    public long getItemId(int i) {
        return (long) i;
    }

    public SongListAdapter(Context context2) {
        this.context = context2;
    }

    public void setSongs(List<Song> list) {
        this.songs = list;
    }

    public int getCount() {
        return this.songs.size();
    }

    public Song getItem(int i) {
        return this.songs.get(i);
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = LayoutInflater.from(this.context).inflate(R.layout.song_list_row, (ViewGroup) null);
        }
        Song cNX_Song = this.songs.get(i);
        ((TextView) view.findViewById(R.id.song_title)).setText(cNX_Song.title);
        view.setTag(cNX_Song);
        return view;
    }
}
