package com.djmusicmixer.djmixer.audiomixer.mixer;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.ContextThemeWrapper;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;
import com.djmusicmixer.djmixer.audiomixer.mixer.Adapter.SearchLibraryAdapter;
import com.djmusicmixer.djmixer.audiomixer.mixer.Loader.AlbumLoader;
import com.djmusicmixer.djmixer.audiomixer.mixer.Loader.ArtistLoader;
import com.djmusicmixer.djmixer.audiomixer.mixer.Loader.SongsLoader;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Album;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Artist;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Songs;
import com.djmusicmixer.djmixer.audiomixer.mixer.Utils.MusicUtil;

import java.util.ArrayList;

public class SearchLibraryActivity extends BaseActivity {
    public static Activity activity;
    private LinearLayout adViewFB;
    public ProgressDialog ad_dialog;
    public Intent ad_intent;
    RelativeLayout adsLayout;
    private EditText et_search_music;
    LinearLayout linearAdsnative;
    public ArrayList<Object> objectArrayList = new ArrayList<>();
    public RecyclerView rv_search;
    public SearchLibraryAdapter searchLibraryAdapter;
    public TextView tv_empty;

    public Bundle getNonPersonalizedAdsBundle() {
        Bundle bundle = new Bundle();
        bundle.putString("npa", "1");
        return bundle;
    }

    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_rkappzia_search_library);
        init();
        bindView();
    }

    private void init() {
        this.et_search_music = (EditText) findViewById(R.id.et_search_music_rkappzia);
        this.rv_search = (RecyclerView) findViewById(R.id.rv_search);
        this.tv_empty = (TextView) findViewById(R.id.tv_empty);
        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                SearchLibraryActivity.this.onBackPressed();
            }
        });
    }

    private void bindView() {
        this.et_search_music.setText("");
        this.et_search_music.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void afterTextChanged(Editable editable) {
                ArrayList<Object> arrayList = new ArrayList<>();
                if (!TextUtils.isEmpty(editable.toString())) {
                    ArrayList<Songs> songs = SongsLoader.getSongs(SearchLibraryActivity.this, editable.toString().trim());
                    if (!songs.isEmpty()) {
                        arrayList.add("Songs");
                        arrayList.addAll(songs);
                    }
                    ArrayList<Album> albums = AlbumLoader.getAlbums(SearchLibraryActivity.this, editable.toString().trim());
                    if (!albums.isEmpty()) {
                        arrayList.add("Albums");
                        arrayList.addAll(albums);
                    }
                    ArrayList<Artist> artists = ArtistLoader.getArtists(SearchLibraryActivity.this, editable.toString().trim());
                    if (!artists.isEmpty()) {
                        arrayList.add("Artists");
                        arrayList.addAll(artists);
                    }
                }
                SearchLibraryActivity.this.objectArrayList = arrayList;
                SearchLibraryActivity.this.tv_empty.setVisibility(SearchLibraryActivity.this.objectArrayList.size() < 1 ? 0 : 8);
                SearchLibraryActivity.this.rv_search.setHasFixedSize(true);
                SearchLibraryActivity.this.rv_search.setLayoutManager(new LinearLayoutManager(SearchLibraryActivity.this, 1, false));
                SearchLibraryActivity searchLibraryActivity = SearchLibraryActivity.this;
                searchLibraryActivity.searchLibraryAdapter = new SearchLibraryAdapter(searchLibraryActivity, searchLibraryActivity.objectArrayList);
                SearchLibraryActivity.this.rv_search.setAdapter(SearchLibraryActivity.this.searchLibraryAdapter);
                SearchLibraryActivity.this.searchLibraryAdapter.notifyDataSetChanged();
            }
        });
    }

    public void onSongsMoreClick(int i, View view, String str, boolean z) {
        final Songs songs = (Songs) this.objectArrayList.get(i);
        if (str.equals("more")) {
            PopupMenu popupMenu = new PopupMenu(new ContextThemeWrapper(this, (int) R.style.PopupDialogTheme), view);
            popupMenu.getMenuInflater().inflate(R.menu.menu_music_item_more_rk, popupMenu.getMenu());
            popupMenu.show();
            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                public boolean onMenuItemClick(MenuItem menuItem) {
                    if (menuItem.getItemId() != R.id.add_to_playlist) {
                        return true;
                    }
                    BaseActivity.addToPlaylistDialog(SearchLibraryActivity.this, songs);
                    return true;
                }
            });
            return;
        }
        Uri albumCoverUri = MusicUtil.getAlbumCoverUri(songs.albumId);
        Intent intent = new Intent();
        intent.putExtra("selected_music_path", songs.data);
        intent.putExtra("selected_music_name", songs.title);
        intent.putExtra("selected_music_album", albumCoverUri.toString());
        setResult(-1, intent);
        finish();
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i2 == -1 && i == 1 && intent != null) {
            setResult(-1, intent);
            finish();
        }
    }

    @Override 
    public void onResume() {
        SearchLibraryAdapter searchLibraryAdapter2 = this.searchLibraryAdapter;
        if (searchLibraryAdapter2 != null) {
            searchLibraryAdapter2.notifyDataSetChanged();
        }
        super.onResume();
    }
}
