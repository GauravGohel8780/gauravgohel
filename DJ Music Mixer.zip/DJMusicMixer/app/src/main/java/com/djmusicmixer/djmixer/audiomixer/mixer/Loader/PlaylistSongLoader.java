package com.djmusicmixer.djmixer.audiomixer.mixer.Loader;

import android.content.Context;
import android.database.Cursor;
import android.provider.MediaStore;

import com.djmusicmixer.djmixer.audiomixer.mixer.Model.PlaylistSong;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Songs;

import java.util.ArrayList;

public class PlaylistSongLoader {
    public static ArrayList<Songs> getPlaylistSongList(Context context, long j) {
        ArrayList<Songs> arrayList = new ArrayList<>();
        Cursor makePlaylistSongCursor = makePlaylistSongCursor(context, j);
        if (makePlaylistSongCursor == null || !makePlaylistSongCursor.moveToFirst()) {
            if (makePlaylistSongCursor != null) {
                makePlaylistSongCursor.close();
            }
            return arrayList;
        }
        do {
            arrayList.add(getPlaylistSongFromCursor(makePlaylistSongCursor, j));
        } while (makePlaylistSongCursor.moveToNext());
        return arrayList;
    }

    private static PlaylistSong getPlaylistSongFromCursor(Cursor cursor, long j) {
        return new PlaylistSong(cursor.getLong(0), cursor.getString(1), cursor.getInt(2), cursor.getInt(3), cursor.getLong(4), cursor.getString(5), cursor.getInt(6), cursor.getLong(7), cursor.getString(8), cursor.getLong(9), cursor.getString(10), j, cursor.getLong(11));
    }

    public static Cursor makePlaylistSongCursor(Context context, long j) {
        try {
            return context.getContentResolver().query(MediaStore.Audio.Playlists.Members.getContentUri("external", j), new String[]{"audio_id", "title", "track", "year", "duration", "_data", "date_modified", "album_id", "album", "artist_id", "artist", "_id"}, "is_music=1 AND title != ''", null, "play_order");
        } catch (SecurityException unused) {
            return null;
        }
    }
}
