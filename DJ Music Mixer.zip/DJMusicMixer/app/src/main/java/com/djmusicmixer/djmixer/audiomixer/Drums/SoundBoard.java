package com.djmusicmixer.djmixer.audiomixer.Drums;

import android.content.Context;
import android.media.SoundPool;

public class SoundBoard {
    SoundPool.OnLoadCompleteListener completeListener = new SoundPool.OnLoadCompleteListener() {
        public void onLoadComplete(SoundPool soundPool, int i, int i2) {
            if (SoundBoard.this.soundLoadListener != null) {
                SoundBoard.this.soundLoadListener.OnSoundLoaded();
            }
        }
    };
    Context context;
    public SoundLoadListener soundLoadListener;
    private SoundPool soundPool;

    public interface SoundLoadListener {
        void OnSoundLoaded();
    }

    public SoundBoard(Context context2) {
        SoundPool soundPool2 = new SoundPool(4, 3, 0);
        this.soundPool = soundPool2;
        this.context = context2;
        soundPool2.setOnLoadCompleteListener(this.completeListener);
    }

    public void setLoadListener(SoundLoadListener soundLoadListener2) {
        this.soundLoadListener = soundLoadListener2;
    }

    public int registerSound(int i) {
        return this.soundPool.load(this.context, i, 7);
    }

    public int playSound(int i) {
        return this.soundPool.play(i, 0.8f, 0.8f, 1, 0, 1.0f);
    }

    public void stop(int i) {
        this.soundPool.stop(i);
    }

    public void release() {
        SoundPool soundPool2 = this.soundPool;
        if (soundPool2 != null) {
            soundPool2.release();
        }
    }
}
