package com.djmusicmixer.djmixer.audiomixer.activites;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.fragment.app.FragmentActivity;

import com.djmusicmixer.djmixer.audiomixer.Ads_Common.AdsBaseActivity;
import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class DrumsActivity extends AdsBaseActivity implements View.OnClickListener {
    Context context;
    RelativeLayout drum001;
    RelativeLayout drum002;
    RelativeLayout drum003;
    RelativeLayout drum004;
    RelativeLayout drum005;
    RelativeLayout drum006;
    RelativeLayout rlLuwdingDrums;

    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        getWindow().getDecorView().setSystemUiVisibility(5638);
        getWindow().addFlags(128);
        setContentView(R.layout.activity_main);

        bindview();
        this.context = this;
        ((ImageView) findViewById(R.id.ic_back)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(DrumsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        DrumsActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);

            }
        });

    }

    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
        getWindow().getDecorView().setSystemUiVisibility(5638);
    }


    private void bindview() {
        RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.rlDrum001);
        this.drum001 = relativeLayout;
        relativeLayout.setOnClickListener(this);
        RelativeLayout relativeLayout2 = (RelativeLayout) findViewById(R.id.rlDrum002);
        this.drum002 = relativeLayout2;
        relativeLayout2.setOnClickListener(this);
        RelativeLayout relativeLayout3 = (RelativeLayout) findViewById(R.id.rlDrum003);
        this.drum003 = relativeLayout3;
        relativeLayout3.setOnClickListener(this);
        RelativeLayout relativeLayout4 = (RelativeLayout) findViewById(R.id.rlDrum004);
        this.drum004 = relativeLayout4;
        relativeLayout4.setOnClickListener(this);
        RelativeLayout relativeLayout5 = (RelativeLayout) findViewById(R.id.rlDrum005);
        this.drum005 = relativeLayout5;
        relativeLayout5.setOnClickListener(this);
        RelativeLayout relativeLayout6 = (RelativeLayout) findViewById(R.id.rlDrum006);
        this.drum006 = relativeLayout6;
        relativeLayout6.setOnClickListener(this);
        RelativeLayout relativeLayout7 = (RelativeLayout) findViewById(R.id.rl_ludwing_drum);
        this.rlLuwdingDrums = relativeLayout7;
        relativeLayout7.setOnClickListener(this);
    }

    public void onClick(View view) {
        callintent(view);
    }

    public void callintent(View view) {
        int id = view.getId();
        if (id != R.id.rl_ludwing_drum) {
            switch (id) {
                case R.id.rlDrum001:
                    CallIntent(1);
                    return;
                case R.id.rlDrum002:
                    CallIntent(2);
                    return;
                case R.id.rlDrum003:
                    CallIntent(3);
                    return;
                case R.id.rlDrum004:
                    CallIntent(4);
                    return;
                case R.id.rlDrum005:
                    CallIntent(5);
                    return;
                case R.id.rlDrum006:
                    CallIntent(6);
                    return;
                default:
                    return;
            }
        } else {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    startActivity(new Intent(DrumsActivity.this, GameActivity.class));
                }
            }, MAIN_CLICK);
        }
    }

    public void CallIntent(int i) {
        getInstance(this).ShowAd(new HandleClick() {
            @Override
            public void Show(boolean adShow) {
                if (i == 1) {
                    StageActivity.SETUP_ID = 0;
                    Intent intent = new Intent(DrumsActivity.this, StageActivity.class);
                    intent.putExtra(String.valueOf(StageActivity.SETUP_ID), 0);
                    startActivityForResult(intent, 0);
                } else if (i == 2) {
                    StageActivity.SETUP_ID = 1;
                    Intent intent2 = new Intent(DrumsActivity.this, StageActivity.class);
                    intent2.putExtra(String.valueOf(StageActivity.SETUP_ID), 1);
                    startActivityForResult(intent2, 0);
                } else if (i == 3) {
                    StageActivity.SETUP_ID = 2;
                    Intent intent3 = new Intent(DrumsActivity.this, StageActivity.class);
                    intent3.putExtra(String.valueOf(StageActivity.SETUP_ID), 2);
                    startActivityForResult(intent3, 0);
                } else if (i == 4) {
                    StageActivity.SETUP_ID = 3;
                    Intent intent4 = new Intent(DrumsActivity.this, StageActivity.class);
                    intent4.putExtra(String.valueOf(StageActivity.SETUP_ID), 3);
                    startActivityForResult(intent4, 0);
                } else if (i == 5) {
                    StageActivity.SETUP_ID = 4;
                    Intent intent5 = new Intent(DrumsActivity.this, StageActivity.class);
                    intent5.putExtra(String.valueOf(StageActivity.SETUP_ID), 4);
                    startActivityForResult(intent5, 0);
                } else if (i == 6) {
                    StageActivity.SETUP_ID = 5;
                    Intent intent6 = new Intent(DrumsActivity.this, StageActivity.class);
                    intent6.putExtra(String.valueOf(StageActivity.SETUP_ID), 5);
                    startActivityForResult(intent6, 0);
                }
            }
        }, MAIN_CLICK);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall2).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}
