package com.djmusicmixer.djmixer.audiomixer.mixer.Utils;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.widget.Toast;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Playlist;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.PlaylistSong;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Songs;

import java.util.ArrayList;
import java.util.Objects;

public class PlaylistUtil {
    public static boolean isPlaylistExist(Context context, String str) {
        return isPlaylistExist(context, "name=?", new String[]{str});
    }

    private static boolean isPlaylistExist(Context context, String str, String[] strArr) {
        boolean z = false;
        Cursor query = context.getContentResolver().query(MediaStore.Audio.Playlists.EXTERNAL_CONTENT_URI, new String[0], str, strArr, null);
        if (query != null) {
            if (query.getCount() != 0) {
                z = true;
            }
            query.close();
        }
        return z;
    }

    public static long createPlaylist(Context context, String str) {
        if (str == null || str.length() <= 0) {
            return -1;
        }
        try {
            Cursor query = context.getContentResolver().query(MediaStore.Audio.Playlists.EXTERNAL_CONTENT_URI, new String[]{"_id"}, "name=?", new String[]{str}, null);
            if (query == null || query.getCount() < 1) {
                ContentValues contentValues = new ContentValues(1);
                contentValues.put("name", str);
                Uri insert = context.getContentResolver().insert(MediaStore.Audio.Playlists.EXTERNAL_CONTENT_URI, contentValues);
                if (insert == null) {
                    return -1;
                }
                context.getContentResolver().notifyChange(insert, null);
                Toast.makeText(context, context.getResources().getString(R.string.created_playlist_x, str), Toast.LENGTH_SHORT).show();
                String lastPathSegment = insert.getLastPathSegment();
                Objects.requireNonNull(lastPathSegment);
                return Long.parseLong(lastPathSegment);
            } else if (!query.moveToFirst()) {
                return -1;
            } else {
                @SuppressLint("Range") long j = query.getLong(query.getColumnIndex("_id"));
                if (query != null) {
                    try {
                        query.close();
                    } catch (SecurityException unused) {
                    }
                }
                if (j == -1) {
                    Toast.makeText(context, context.getResources().getString(R.string.could_not_create_playlist), Toast.LENGTH_SHORT).show();
                }
                return j;
            }
        } catch (SecurityException unused2) {
            return 0;
        }
    }

    public static void deletePlaylists(Context context, ArrayList<Playlist> arrayList) {
        StringBuilder sb = new StringBuilder();
        sb.append("_id IN (");
        for (int i = 0; i < arrayList.size(); i++) {
            sb.append(arrayList.get(i).f188id);
            if (i < arrayList.size() - 1) {
                sb.append(",");
            }
        }
        sb.append(")");
        try {
            context.getContentResolver().delete(MediaStore.Audio.Playlists.EXTERNAL_CONTENT_URI, sb.toString(), null);
            context.getContentResolver().notifyChange(MediaStore.Audio.Playlists.EXTERNAL_CONTENT_URI, null);
        } catch (SecurityException unused) {
        }
    }

    public static void addToPlaylist(Context context, ArrayList<Songs> arrayList, long j, boolean z) throws Throwable {
        int size = arrayList.size();
        ContentResolver contentResolver = context.getContentResolver();
        Uri contentUri = MediaStore.Audio.Playlists.Members.getContentUri("external", j);
        Cursor query = contentResolver.query(contentUri, new String[]{"max(play_order)"}, null, null, null);
        if (query == null || !query.moveToFirst()) {
            while (size > 0) {
            }
            context.getContentResolver().notifyChange(contentUri, null);
            return;
        }
        int i = query.getInt(0) + 1;
        if (query != null) {
            try {
                query.close();
            } catch (SecurityException e) {
                e.printStackTrace();
                return;
            }
        }
        int i2 = 0;
        for (int i3 = 0; i3 < size; i3 += 1000) {
            i2 += contentResolver.bulkInsert(contentUri, insertItems(arrayList, i3, 1000, i));
        }
        context.getContentResolver().notifyChange(contentUri, null);
    }

    public static String getNameForPlaylist(Context context, long j) {
        Cursor cursor = null;
        try {
            Cursor query = context.getContentResolver().query(ContentUris.withAppendedId(MediaStore.Audio.Playlists.EXTERNAL_CONTENT_URI, j), new String[]{"name"}, null, null, null);
            if (query == null) {
                return "";
            }
            if (query.moveToFirst()) {
                String string = query.getString(0);
                query.close();
                return string;
            }
            query.close();
            query.close();
            return "";
        } catch (SecurityException unused) {
            return "";
        } catch (Throwable th) {
            cursor.close();
            throw th;
        }
    }

    public static ContentValues[] insertItems(ArrayList<Songs> arrayList, int i, int i2, int i3) {
        if (i + i2 > arrayList.size()) {
            i2 = arrayList.size() - i;
        }
        ContentValues[] contentValuesArr = new ContentValues[i2];
        for (int i4 = 0; i4 < i2; i4++) {
            contentValuesArr[i4] = new ContentValues();
            contentValuesArr[i4].put("play_order", Integer.valueOf(i3 + i + i4));
            contentValuesArr[i4].put("audio_id", Long.valueOf(arrayList.get(i + i4).f189id));
        }
        return contentValuesArr;
    }

    public static void removeFromPlaylist(Context context, ArrayList<PlaylistSong> arrayList) {
        Uri contentUri = MediaStore.Audio.Playlists.Members.getContentUri("external", arrayList.get(0).playlistId);
        int size = arrayList.size();
        String[] strArr = new String[size];
        for (int i = 0; i < size; i++) {
            strArr[i] = String.valueOf(arrayList.get(i).idInPlayList);
        }
        String str = "_id in (";
        for (int i2 = 0; i2 < size; i2++) {
            String str2 = strArr[i2];
            str = str + "?, ";
        }
        try {
            context.getContentResolver().delete(contentUri, str.substring(0, str.length() - 2) + ")", strArr);
            context.getContentResolver().notifyChange(contentUri, null);
        } catch (SecurityException unused) {
        }
    }
}
