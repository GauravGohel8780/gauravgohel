package com.djmusicmixer.djmixer.audiomixer.loop.BeatWithMusic;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.loop.MyCustom.MyUtil;
import com.h6ah4i.android.widget.verticalseekbar.VerticalSeekBar;

public class MND_MyMixerFragment extends Fragment {
    int maxVolume = 100;
    VerticalSeekBar mySeekBar1;
    VerticalSeekBar mySeekBar2;
    VerticalSeekBar mySeekBar3;
    VerticalSeekBar mySeekBar4;
    VerticalSeekBar mySeekBar5;
    VerticalSeekBar mySeekBar6;
    TextView txt_seek1;
    TextView txt_seek2;
    TextView txt_seek3;
    TextView txt_seek4;
    TextView txt_seek5;
    String[] type10Progress = {"Drum", "Bass", "Syn", "Arp", "Guitar"};
    String[] type1Progress = {"Beat", "Bass", "Pad", "Lead", "Arp"};
    String[] type2Progress = {"Drum", "Syn", "Pluck", "Vocal", "FX"};
    String[] type3Progress = {"Beat", "Bass", "Stabs", "Rise", "Syn"};
    String[] type4Progress = {"Beat", "Bass", "Chord", "Arp", "Lead"};
    String[] type5Progress = {"Beat", "Bass", "Syn", "Vocal", "FX"};
    String[] type6Progress = {"Beat", "Bass", "Pad", "Syn", "Arp"};
    String[] type7Progress = {"Beat", "Bass", "Down", "Syn", "Arp"};
    String[] type8Progress = {"Drum", "Bass", "Arp", "Pad", "Syn"};
    String[] type9Progress = {"Drum", "Bass", "Organ", "Chord", "Lead"};
    VolumeChangeListner volumeChangeListner;

    public interface VolumeChangeListner {
        void onVolumeMedia1(float f);

        void onVolumeMedia2(float f);

        void onVolumeMedia3(float f);

        void onVolumeMedia4(float f);

        void onVolumeMedia5(float f);

        void onVolumeMedia6(float f);
    }

    public void setOnVolumeChangeListner(VolumeChangeListner volumeChangeListner2) {
        this.volumeChangeListner = volumeChangeListner2;
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_mymixer, viewGroup, false);
        this.mySeekBar1 = (VerticalSeekBar) inflate.findViewById(R.id.mySeekBar1);
        this.mySeekBar2 = (VerticalSeekBar) inflate.findViewById(R.id.mySeekBar2);
        this.mySeekBar3 = (VerticalSeekBar) inflate.findViewById(R.id.mySeekBar3);
        this.mySeekBar4 = (VerticalSeekBar) inflate.findViewById(R.id.mySeekBar4);
        this.mySeekBar5 = (VerticalSeekBar) inflate.findViewById(R.id.mySeekBar5);
        this.mySeekBar6 = (VerticalSeekBar) inflate.findViewById(R.id.mySeekBar6);
        this.txt_seek1 = (TextView) inflate.findViewById(R.id.txt_seek1);
        this.txt_seek2 = (TextView) inflate.findViewById(R.id.txt_seek2);
        this.txt_seek3 = (TextView) inflate.findViewById(R.id.txt_seek3);
        this.txt_seek4 = (TextView) inflate.findViewById(R.id.txt_seek4);
        this.txt_seek5 = (TextView) inflate.findViewById(R.id.txt_seek5);
        this.mySeekBar1.setMax(150);
        this.mySeekBar1.setProgress(130);
        this.mySeekBar2.setMax(150);
        this.mySeekBar2.setProgress(130);
        this.mySeekBar3.setMax(150);
        this.mySeekBar3.setProgress(130);
        this.mySeekBar4.setMax(150);
        this.mySeekBar4.setProgress(130);
        this.mySeekBar5.setMax(150);
        this.mySeekBar5.setProgress(130);
        this.mySeekBar6.setMax(150);
        this.mySeekBar6.setProgress(130);

        this.mySeekBar1.setThumbOffset((int) thumbSetting(0.0f));
        this.mySeekBar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                float f = ((float) i) / ((float) MND_MyMixerFragment.this.maxVolume);
                if (MND_MyMixerFragment.this.volumeChangeListner != null) {
                    MND_MyMixerFragment.this.volumeChangeListner.onVolumeMedia1(f);
                }
            }
        });
        this.mySeekBar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                float f = ((float) i) / ((float) MND_MyMixerFragment.this.maxVolume);
                if (MND_MyMixerFragment.this.volumeChangeListner != null) {
                    MND_MyMixerFragment.this.volumeChangeListner.onVolumeMedia2(f);
                }
            }
        });
        this.mySeekBar3.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                float f = ((float) i) / ((float) MND_MyMixerFragment.this.maxVolume);
                if (MND_MyMixerFragment.this.volumeChangeListner != null) {
                    MND_MyMixerFragment.this.volumeChangeListner.onVolumeMedia3(f);
                }
            }
        });
        this.mySeekBar4.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                float f = ((float) i) / ((float) MND_MyMixerFragment.this.maxVolume);
                if (MND_MyMixerFragment.this.volumeChangeListner != null) {
                    MND_MyMixerFragment.this.volumeChangeListner.onVolumeMedia4(f);
                }
            }
        });
        this.mySeekBar5.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                float f = ((float) i) / ((float) MND_MyMixerFragment.this.maxVolume);
                if (MND_MyMixerFragment.this.volumeChangeListner != null) {
                    MND_MyMixerFragment.this.volumeChangeListner.onVolumeMedia5(f);
                }
            }
        });
        this.mySeekBar6.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                float f = ((float) i) / ((float) MND_MyMixerFragment.this.maxVolume);
                if (MND_MyMixerFragment.this.volumeChangeListner != null) {
                    MND_MyMixerFragment.this.volumeChangeListner.onVolumeMedia6(f);
                }
            }
        });
        if (MyUtil.featureNumber == 1) {
            this.txt_seek1.setText(this.type1Progress[0]);
            this.txt_seek2.setText(this.type1Progress[1]);
            this.txt_seek3.setText(this.type1Progress[2]);
            this.txt_seek4.setText(this.type1Progress[3]);
            this.txt_seek5.setText(this.type1Progress[4]);
        } else if (MyUtil.featureNumber == 2) {
            this.txt_seek1.setText(this.type2Progress[0]);
            this.txt_seek2.setText(this.type2Progress[1]);
            this.txt_seek3.setText(this.type2Progress[2]);
            this.txt_seek4.setText(this.type2Progress[3]);
            this.txt_seek5.setText(this.type2Progress[4]);
        } else if (MyUtil.featureNumber == 3) {
            this.txt_seek1.setText(this.type3Progress[0]);
            this.txt_seek2.setText(this.type3Progress[1]);
            this.txt_seek3.setText(this.type3Progress[2]);
            this.txt_seek4.setText(this.type3Progress[3]);
            this.txt_seek5.setText(this.type3Progress[4]);
        } else if (MyUtil.featureNumber == 4) {
            this.txt_seek1.setText(this.type4Progress[0]);
            this.txt_seek2.setText(this.type4Progress[1]);
            this.txt_seek3.setText(this.type4Progress[2]);
            this.txt_seek4.setText(this.type4Progress[3]);
            this.txt_seek5.setText(this.type4Progress[4]);
        } else if (MyUtil.featureNumber == 5) {
            this.txt_seek1.setText(this.type5Progress[0]);
            this.txt_seek2.setText(this.type5Progress[1]);
            this.txt_seek3.setText(this.type5Progress[2]);
            this.txt_seek4.setText(this.type5Progress[3]);
            this.txt_seek5.setText(this.type5Progress[4]);
        } else if (MyUtil.featureNumber == 6) {
            this.txt_seek1.setText(this.type6Progress[0]);
            this.txt_seek2.setText(this.type6Progress[1]);
            this.txt_seek3.setText(this.type6Progress[2]);
            this.txt_seek4.setText(this.type6Progress[3]);
            this.txt_seek5.setText(this.type6Progress[4]);
        } else if (MyUtil.featureNumber == 7) {
            this.txt_seek1.setText(this.type7Progress[0]);
            this.txt_seek2.setText(this.type7Progress[1]);
            this.txt_seek3.setText(this.type7Progress[2]);
            this.txt_seek4.setText(this.type7Progress[3]);
            this.txt_seek5.setText(this.type7Progress[4]);
        } else if (MyUtil.featureNumber == 8) {
            this.txt_seek1.setText(this.type8Progress[0]);
            this.txt_seek2.setText(this.type8Progress[1]);
            this.txt_seek3.setText(this.type8Progress[2]);
            this.txt_seek4.setText(this.type8Progress[3]);
            this.txt_seek5.setText(this.type8Progress[4]);
        } else if (MyUtil.featureNumber == 9) {
            this.txt_seek1.setText(this.type9Progress[0]);
            this.txt_seek2.setText(this.type9Progress[1]);
            this.txt_seek3.setText(this.type9Progress[2]);
            this.txt_seek4.setText(this.type9Progress[3]);
            this.txt_seek5.setText(this.type9Progress[4]);
        } else if (MyUtil.featureNumber == 10) {
            this.txt_seek1.setText(this.type10Progress[0]);
            this.txt_seek2.setText(this.type10Progress[1]);
            this.txt_seek3.setText(this.type10Progress[2]);
            this.txt_seek4.setText(this.type10Progress[3]);
            this.txt_seek5.setText(this.type10Progress[4]);
        }
        return inflate;
    }

    private float thumbSetting(float f) {
        return f * (((float) getResources().getDisplayMetrics().densityDpi) / 160.0f);
    }
}
