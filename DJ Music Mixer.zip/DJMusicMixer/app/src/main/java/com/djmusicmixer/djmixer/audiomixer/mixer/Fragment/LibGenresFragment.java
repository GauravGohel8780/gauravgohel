package com.djmusicmixer.djmixer.audiomixer.mixer.Fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.mixer.Adapter.LibGenresAdapter;
import com.djmusicmixer.djmixer.audiomixer.mixer.GenresDetailsActivity;
import com.djmusicmixer.djmixer.audiomixer.mixer.Loader.GenreLoader;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Genres;
import com.djmusicmixer.djmixer.audiomixer.mixer.Utils.MusicConstant;

import java.util.ArrayList;
import java.util.Objects;

public class LibGenresFragment extends Fragment {
    private LibGenresAdapter genresAdapter;
    public ArrayList<Genres> genresList = new ArrayList<>();
    private RecyclerView recyclerView;
    public Genres selected_genres;
    private TextView tv_empty;

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_rkappzia_music_library, viewGroup, false);
        init(inflate);
        return inflate;
    }

    private void init(View view) {
        this.recyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        this.tv_empty = (TextView) view.findViewById(R.id.tv_empty);
        FragmentActivity activity = getActivity();
        Objects.requireNonNull(activity);
        activity.runOnUiThread(new Runnable() {
            public void run() {
                LibGenresFragment libGenresFragment = LibGenresFragment.this;
                Context context = libGenresFragment.getContext();
                Objects.requireNonNull(context);
                libGenresFragment.genresList = GenreLoader.getAllGenres(context);
            }
        });
    }

    @Override
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        ArrayList<Genres> arrayList = this.genresList;
        if (arrayList != null) {
            this.tv_empty.setVisibility(arrayList.size() > 0 ? View.GONE : View.VISIBLE);
            if (this.genresList.size() > 0) {
                this.recyclerView.setHasFixedSize(true);
                this.recyclerView.setLayoutManager(new GridLayoutManager((Context) getActivity(), 3, RecyclerView.VERTICAL, false));
                LibGenresAdapter libGenresAdapter = new LibGenresAdapter(getActivity(), this.genresList);
                this.genresAdapter = libGenresAdapter;
                this.recyclerView.setAdapter(libGenresAdapter);
                this.genresAdapter.setOnItemClickListener(new LibGenresAdapter.OnGenresClickListener() {
                    @Override
                    public void onClick(Genres genres) {
                        LibGenresFragment.this.selected_genres = genres;
                        Intent intent = new Intent(LibGenresFragment.this.getActivity(), GenresDetailsActivity.class);
                        intent.putExtra("genres", LibGenresFragment.this.selected_genres);
                        FragmentActivity activity = LibGenresFragment.this.getActivity();
                        Objects.requireNonNull(activity);
                        activity.startActivityForResult(intent, 1);
                        MusicConstant.ActivityFlag = "";
                    }
                });
            }
        }
    }
}
