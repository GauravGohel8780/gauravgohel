package com.djmusicmixer.djmixer.audiomixer.mixer.Adapter;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.mixer.AlbumDetailsActivity;
import com.djmusicmixer.djmixer.audiomixer.mixer.ArtistDetailsActivity;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Album;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Artist;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Songs;
import com.djmusicmixer.djmixer.audiomixer.mixer.SearchLibraryActivity;
import com.djmusicmixer.djmixer.audiomixer.mixer.Utils.MusicUtil;

import java.util.ArrayList;

public class SearchLibraryAdapter extends RecyclerView.Adapter<SearchLibraryAdapter.ViewHolder> {
    public Activity activity;
    public ArrayList<Object> arrayList;

    public SearchLibraryAdapter(Activity activity2, ArrayList<Object> arrayList2) {
        this.activity = activity2;
        this.arrayList = arrayList2;
    }

    @Override 
    public int getItemViewType(int i) {
        if (this.arrayList.get(i) instanceof Album) {
            return 1;
        }
        if (this.arrayList.get(i) instanceof Artist) {
            return 2;
        }
        return this.arrayList.get(i) instanceof Songs ? 3 : 0;
    }

    @Override 
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        if (i == 0) {
            return new ViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.search_music_list_header, viewGroup, false), i);
        }
        return new ViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.search_music_list_item, viewGroup, false), i);
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        int itemViewType = getItemViewType(i);
        if (itemViewType == 1) {
            Album album = (Album) this.arrayList.get(i);
            ((RequestBuilder) Glide.with(this.activity).load(MusicUtil.getAlbumCoverUri(album.getFirstSong().albumId)).placeholder((int) R.drawable.ic_thumb)).into(viewHolder.iv_thumb);
            viewHolder.tv_title.setText(album.getTitle());
            viewHolder.tv_info.setText(getAlbumText(album));
        } else if (itemViewType == 2) {
            Artist artist = (Artist) this.arrayList.get(i);
            ((RequestBuilder) Glide.with(this.activity).load(MusicUtil.getAlbumCoverUri(artist.getFirstAlbum().getFirstSong().albumId)).placeholder((int) R.drawable.ic_thumb)).into(viewHolder.iv_thumb);
            viewHolder.tv_title.setText(artist.getName());
            viewHolder.tv_info.setText(MusicUtil.getArtistInfo(artist));
        } else if (itemViewType != 3) {
            viewHolder.tv_header.setText(this.arrayList.get(i).toString());
        } else {
            Songs songs = (Songs) this.arrayList.get(i);
            ((RequestBuilder) Glide.with(this.activity).load(MusicUtil.getAlbumCoverUri(songs.albumId)).placeholder((int) R.drawable.ic_thumb)).into(viewHolder.iv_thumb);
            viewHolder.tv_title.setText(songs.title);
            viewHolder.tv_info.setText(songs.artistName);
            viewHolder.tv_duration.setText(MusicUtil.getReadableDuration(songs.duration));
            viewHolder.iv_more.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    ((SearchLibraryActivity) SearchLibraryAdapter.this.activity).onSongsMoreClick(i, view, "more", false);
                }
            });
            viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    ((SearchLibraryActivity) SearchLibraryAdapter.this.activity).onSongsMoreClick(i, view, "play_pause", false);
                }
            });
        }
    }

    @Override 
    public int getItemCount() {
        return this.arrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView iv_more;
        ImageView iv_play_pause;
        ImageView iv_thumb;
        LinearLayout ly_play_pause;
        TextView tv_duration;
        TextView tv_header;
        TextView tv_info;
        TextView tv_title;
        View view_line;

        ViewHolder(View view, int i) {
            super(view);
            this.tv_header = (TextView) view.findViewById(R.id.tv_header);
            this.iv_thumb = (ImageView) view.findViewById(R.id.iv_thumb);
            this.tv_title = (TextView) view.findViewById(R.id.tv_title_rkappzia);
            this.tv_info = (TextView) view.findViewById(R.id.tv_info);
            this.ly_play_pause = (LinearLayout) view.findViewById(R.id.ly_play_pause);
            this.iv_play_pause = (ImageView) view.findViewById(R.id.iv_play_pause);
            this.tv_duration = (TextView) view.findViewById(R.id.tv_duration);
            this.iv_more = (ImageView) view.findViewById(R.id.iv_more);
            View findViewById = view.findViewById(R.id.view_line);
            this.view_line = findViewById;
            if (!(i == 0 || findViewById == null)) {
                findViewById.setVisibility(View.VISIBLE);
            }
            ImageView imageView = this.iv_more;
            if (imageView != null) {
                if (i == 3) {
                    imageView.setVisibility(View.VISIBLE);
                    this.ly_play_pause.setVisibility(View.VISIBLE);
                } else {
                    imageView.setVisibility(View.INVISIBLE);
                    this.ly_play_pause.setVisibility(View.INVISIBLE);
                }
            }
            view.setOnClickListener(new View.OnClickListener() {
                public final void onClick(View view) {
                    ViewHolder.this.lambda$new$0$SearchLibraryAdapter$ViewHolder(view);
                }
            });
        }

        public void lambda$new$0$SearchLibraryAdapter$ViewHolder(View view) {
            Object obj = SearchLibraryAdapter.this.arrayList.get(getAdapterPosition());
            int itemViewType = getItemViewType();
            if (itemViewType == 1) {
                SearchLibraryAdapter.this.activity.startActivityForResult(new Intent(SearchLibraryAdapter.this.activity, AlbumDetailsActivity.class).putExtra("albumId", ((Album) obj).getId()), 1);
            } else if (itemViewType == 2) {
                SearchLibraryAdapter.this.activity.startActivityForResult(new Intent(SearchLibraryAdapter.this.activity, ArtistDetailsActivity.class).putExtra("artistId", ((Artist) obj).getId()), 1);
            }
        }
    }

    private String getAlbumText(Album album) {
        if (album.songs != null) {
            return MusicUtil.buildInfoString("", MusicUtil.getSongCount(album.songs.size()));
        }
        return "";
    }
}
