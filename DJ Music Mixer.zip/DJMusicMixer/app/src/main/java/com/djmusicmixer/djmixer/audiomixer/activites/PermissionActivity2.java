package com.djmusicmixer.djmixer.audiomixer.activites;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.app.ActivityCompat;

import com.djmusicmixer.djmixer.audiomixer.ExtraPage.IntroActivity;
import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.SharePrefUtils;
import com.djmusicmixer.djmixer.audiomixer.base.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.drummain.Drum_Main_Screen;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.kyleduo.switchbutton.SwitchButton;

import java.util.Map;
import java.util.function.Predicate;

public class PermissionActivity2 extends BaseActivity implements Predicate {
    private boolean check = false;
    private boolean check2 = false;

    private ActivityResultLauncher<String[]> permissionsResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback() {
        @Override
        public final void onActivityResult(Object obj) {
            PermissionActivity2.this.PermissionsResult((Map) obj);
        }
    });
    private ActivityResultLauncher<String[]> permissionsResult2 = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback() {
        @Override
        public final void onActivityResult(Object obj) {
            PermissionActivity2.this.PermissionsResult2((Map) obj);
        }
    });

    @Override
    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
        if (z) {
            fullScreenImmersive(getWindow());
        }
    }

    private void fullScreenImmersive(Window window) {
        if (window != null) {
            fullScreenImmersive(window.getDecorView());
        }
    }

    private void fullScreenImmersive(View view) {
        view.setSystemUiVisibility(5638);
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        SystemUtils.setLocale(this);
        setContentView(R.layout.activity_permission2);

        findViewById(R.id.cv_readphone).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (!((SwitchButton) PermissionActivity2.this.findViewById(R.id.swStore)).isChecked()) {
                    PermissionActivity2.this.requestGallery();
                }
            }
        });
        findViewById(R.id.cv_overlay).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (!((SwitchButton) PermissionActivity2.this.findViewById(R.id.sw_overlay)).isChecked()) {
                    PermissionActivity2.this.requestGallery2();
                }
            }
        });
        findViewById(R.id.tv_start).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(PermissionActivity2.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        if (!(ActivityCompat.checkSelfPermission(PermissionActivity2.this, "android.permission.RECORD_AUDIO") == 0)) {
                            PermissionActivity2.this.requestGallery2();
                        } else if (!(ActivityCompat.checkSelfPermission(PermissionActivity2.this, "android.permission.READ_MEDIA_VIDEO") == 0 && ActivityCompat.checkSelfPermission(PermissionActivity2.this, "android.permission.READ_MEDIA_IMAGES") == 0 || ActivityCompat.checkSelfPermission(PermissionActivity2.this, "android.permission.READ_MEDIA_AUDIO") == 0) && !(ActivityCompat.checkSelfPermission(PermissionActivity2.this, "android.permission.READ_EXTERNAL_STORAGE") == 0)) {
                            PermissionActivity2.this.requestGallery();
                        } else {
                            PermissionActivity2.this.start();
                        }
                    }
                }, MAIN_CLICK);
            }
        });
    }

    private void ui() {
        if (ActivityCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") == 0) {
            findViewById(R.id.sw_overlay).setVisibility(View.INVISIBLE);
            findViewById(R.id.sw_overlay2).setVisibility(View.VISIBLE);
        }
        if (Build.VERSION.SDK_INT >= 33) {
            if (ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_VIDEO") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_IMAGES") == 0 && ActivityCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_AUDIO") == 0) {
                findViewById(R.id.swStore).setVisibility(View.INVISIBLE);
                findViewById(R.id.swStore2).setVisibility(View.VISIBLE);
            }
        } else if (ActivityCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0) {
            findViewById(R.id.swStore).setVisibility(View.INVISIBLE);
            findViewById(R.id.swStore2).setVisibility(View.VISIBLE);
        }
    }


    private void start() {
        if (!SharePrefUtils.getFistTimeEnter(PermissionActivity2.this)) {
            Intent intent = new Intent(PermissionActivity2.this, IntroActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        } else {
            Intent intent = new Intent(PermissionActivity2.this, Drum_Main_Screen.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        }
    }

    private void requestGallery() {
        this.check = true;
        if (Build.VERSION.SDK_INT >= 33) {
            this.permissionsResult.launch(new String[]{"android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_AUDIO"});
        } else {
            this.permissionsResult.launch(new String[]{"android.permission.READ_EXTERNAL_STORAGE"});
        }
    }

    public void PermissionsResult(Map map) {
        if (Build.VERSION.SDK_INT < 24) {
            return;
        }
        if (map.entrySet().stream().allMatch(this::test)) {
            findViewById(R.id.swStore).setVisibility(View.INVISIBLE);
            findViewById(R.id.swStore2).setVisibility(View.VISIBLE);
        }
    }

    private void requestGallery2() {
        this.check2 = true;
        if (Build.VERSION.SDK_INT >= 33) {
            this.permissionsResult2.launch(new String[]{"android.permission.RECORD_AUDIO"});
        } else {
            this.permissionsResult2.launch(new String[]{"android.permission.RECORD_AUDIO"});
        }
    }

    public void PermissionsResult2(Map map) {
        if (Build.VERSION.SDK_INT < 24) {
            return;
        }
        if (map.entrySet().stream().allMatch(this::test)) {
            findViewById(R.id.sw_overlay).setVisibility(View.INVISIBLE);
            findViewById(R.id.sw_overlay2).setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public boolean test(Object obj) {
        return ((Boolean) ((Map.Entry) obj).getValue()).booleanValue();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ui();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
