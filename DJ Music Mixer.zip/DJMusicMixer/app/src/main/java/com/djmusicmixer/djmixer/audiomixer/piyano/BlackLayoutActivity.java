package com.djmusicmixer.djmixer.audiomixer.piyano;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

public class BlackLayoutActivity extends ViewGroup {
    public BlackLayoutActivity(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    @SuppressLint("WrongConstant")
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        double width = (double) getWidth();
        Double.isNaN(width);
        Double.isNaN(width);
        double d = width / 20.0d;
        double d2 = (d / 3.0d) * 2.0d;
        int childCount = getChildCount();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (i5 == 1 || i5 == 5 || i5 == 8 || i5 == 12 || i5 == 15 || i5 == 19) {
                childAt.setVisibility(4);
            }
            double d3 = (double) i5;
            Double.isNaN(d3);
            Double.isNaN(d3);
            int i6 = (int) ((d3 * d) - (d2 / 2.0d));
            double d4 = (double) i6;
            Double.isNaN(d4);
            Double.isNaN(d4);
            childAt.layout(i6, 0, (int) (d4 + d2), 350);
        }
    }
}
