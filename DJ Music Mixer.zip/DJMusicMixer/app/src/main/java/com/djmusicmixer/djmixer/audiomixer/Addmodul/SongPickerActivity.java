package com.djmusicmixer.djmixer.audiomixer.Addmodul;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.djmusicmixer.djmixer.audiomixer.Help;
import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.base.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.util.ArrayList;
import java.util.List;

public class SongPickerActivity extends BaseActivity {
    song_list f341k;
    AdapterView.OnItemClickListener f342l = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
            getInstance(SongPickerActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    Intent intent = new Intent();
                    intent.putExtra("song_uri", ((song_model) view.getTag()).f346b);
                    SongPickerActivity.this.setResult(-1, intent);
                    SongPickerActivity cNX_SongPickerActivity = SongPickerActivity.this;
                    Toast.makeText(cNX_SongPickerActivity, cNX_SongPickerActivity.getString(R.string.Song_is_Loaded), Toast.LENGTH_SHORT).show();
                    SongPickerActivity.this.finish();
                }
            }, MAIN_CLICK);
        }
    };

    LinearLayout llNoMusic;

    private List<song_model> m76k() {
        Cursor query = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, new String[]{"_id", "artist", "title", "_data", "_display_name", "duration"}, "is_music != 0", null, null);
        ArrayList arrayList = new ArrayList();
        while (query.moveToNext()) {
            song_model cNX_song_model = new song_model();
            cNX_song_model.f345a = query.getString(1);
            cNX_song_model.f347c = query.getString(2);
            cNX_song_model.f346b = query.getString(3);
            arrayList.add(cNX_song_model);
        }
        return arrayList;
    }

    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        requestWindowFeature(1);
        getWindow().addFlags(128);
        setContentView(R.layout.cnxx_activity_song_picker);

        getWindow().setFlags(1024, 1024);
        Help.width = getResources().getDisplayMetrics().widthPixels;
        Help.height = getResources().getDisplayMetrics().heightPixels;
        List<song_model> m76k = m76k();
        song_list cNX_song_list = new song_list(this);
        this.f341k = cNX_song_list;
        cNX_song_list.song_list(m76k);
        this.llNoMusic = (LinearLayout) findViewById(R.id.ll_no_music);
        if (cNX_song_list.getCount() > 0) {
            this.llNoMusic.setVisibility(View.GONE);
        } else {
            this.llNoMusic.setVisibility(View.VISIBLE);
        }
        ListView listView = (ListView) findViewById(R.id.song_list_view);
        listView.setAdapter((ListAdapter) this.f341k);
        listView.setOnItemClickListener(this.f342l);
        ((ImageView) findViewById(R.id.ic_back)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(SongPickerActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        SongPickerActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
    }

    @Override
    public void onBackPressed() {
        finish();
        super.onBackPressed();
    }
}
