package com.djmusicmixer.djmixer.audiomixer.drummain;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.djmusicmixer.djmixer.audiomixer.Ads_Common.ExitActivity;
import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.activites.Home_Activity;
import com.djmusicmixer.djmixer.audiomixer.base.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;
import com.djmusicmixer.djmixer.audiomixer.loop.MND_LoopPadActivity;
import com.djmusicmixer.djmixer.audiomixer.loop.MND_MyMusicActivity;
import com.djmusicmixer.djmixer.audiomixer.mixer.MixerActivity;
import com.djmusicmixer.djmixer.audiomixer.piyano.PianoMainActivity;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;


public class Drum_Main_Screen extends BaseActivity {
    private AlertDialog alertDialog;
    RelativeLayout beatmaker;
    Context context;
    RelativeLayout djmixer, piyano;
    RelativeLayout drumpad;
    RelativeLayout rlMyMusic;

    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        setContentView(R.layout.activity_drum_main_screen);


        this.drumpad = (RelativeLayout) findViewById(R.id.drumpad);
        this.beatmaker = (RelativeLayout) findViewById(R.id.beatmaker);
        this.djmixer = (RelativeLayout) findViewById(R.id.djmixer);
        this.piyano = (RelativeLayout) findViewById(R.id.piyano);
        this.context = this;
        this.rlMyMusic = (RelativeLayout) findViewById(R.id.rl_my_music);
        this.rlMyMusic.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Drum_Main_Screen.this.CallIntent(0);
            }
        });
        this.djmixer.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Drum_Main_Screen.this.CallIntent(1);
            }
        });
        this.drumpad.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Drum_Main_Screen.this.CallIntent(2);
            }
        });
        this.beatmaker.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Drum_Main_Screen.this.CallIntent(3);
            }
        });
        this.piyano.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Drum_Main_Screen.this.CallIntent(4);
            }
        });
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        getWindow().getDecorView().setSystemUiVisibility(5638);
    }

    @Override
    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
        getWindow().getDecorView().setSystemUiVisibility(5638);
    }

    @Override
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (iArr.length <= 0) {
            return;
        }
        if (i == 1111 || i == 1112) {
            int i2 = 0;
            for (int i3 : iArr) {
                if (i3 == -1) {
                    i2++;
                }
            }
            if (i2 > 0) {
                Toast.makeText(this, getString(R.string.Permission_is_denied), Toast.LENGTH_SHORT).show();
                this.alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
                    public void onShow(DialogInterface dialogInterface) {
                        Drum_Main_Screen.this.alertDialog.getButton(-1).setTextColor(Drum_Main_Screen.this.getResources().getColor(R.color.black));
                    }
                });
                this.alertDialog.show();
            }
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
        new Handler(getMainLooper()).postDelayed(new Runnable() {
            public void run() {
                try {
                    Drum_Main_Screen.this.getWindow().getDecorView().setSystemUiVisibility(5638);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, 3000);
    }

    public void CallIntent(int i) {
        getInstance(this).ShowAd(new HandleClick() {
            @Override
            public void Show(boolean adShow) {
                if (i == 0) {
                    startActivity(new Intent(Drum_Main_Screen.this, MND_MyMusicActivity.class));
                } else if (i == 1) {
                    startActivity(new Intent(Drum_Main_Screen.this, MixerActivity.class));
                } else if (i == 2) {
                    startActivity(new Intent(Drum_Main_Screen.this, Home_Activity.class));
                } else if (i == 3) {
                    startActivity(new Intent(Drum_Main_Screen.this, MND_LoopPadActivity.class));
                } else if (i == 4) {
                    startActivity(new Intent(Drum_Main_Screen.this, PianoMainActivity.class));
                }
            }
        }, MAIN_CLICK);
    }


    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        startActivity(new Intent(Drum_Main_Screen.this, ExitActivity.class));
    }
}
