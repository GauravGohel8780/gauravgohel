package com.djmusicmixer.djmixer.audiomixer.Addmodul;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.base.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;

public class DrumDemoActivity4 extends BaseActivity implements View.OnClickListener {
    Context context;
    ImageView f180A;
    ImageView f181B;
    ImageView f182C;
    LinearLayout f183D;
    MediaPlayer.OnCompletionListener f184E = new MediaPlayer.OnCompletionListener() {
        public void onCompletion(MediaPlayer mediaPlayer) {
            DrumDemoActivity4.this.f186G.setImageResource(R.drawable.ic_play_music_drums);
            DrumDemoActivity4.this.f203X = false;
        }
    };
    MediaPlayer.OnPreparedListener f185F = new MediaPlayer.OnPreparedListener() {
        public void onPrepared(MediaPlayer mediaPlayer) {
            DrumDemoActivity4.this.f203X = true;
        }
    };
    ImageView f186G;
    MediaPlayer f187H;
    MediaPlayer f188I;
    MediaPlayer f189J;
    MediaPlayer f190K;
    MediaPlayer f191L;
    MediaPlayer f192M;
    MediaPlayer f193N;
    MediaPlayer f194O;
    MediaPlayer f195P;
    MediaPlayer f196Q;
    MediaPlayer f197R1;
    MediaPlayer f198S;
    MediaPlayer f199T;
    MediaPlayer f200U;
    MediaPlayer f201V;
    MediaPlayer f202W;
    public boolean f203X = false;
    public MediaPlayer f204Y = new MediaPlayer();
    ImageView f205k;
    float f206l = 1.0f;
    MediaPlayer.OnErrorListener f207m = new MediaPlayer.OnErrorListener() {
        public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
            DrumDemoActivity4.this.f186G.setImageResource(R.drawable.ic_play_music_drums);
            DrumDemoActivity4.this.f203X = false;
            return false;
        }
    };
    ImageView f208n;
    ImageView f209o;
    ImageView f210p;
    ImageView f211q;
    ImageView f212r;
    ImageView f213s;
    ImageView f214t;
    ImageView f215u;
    ImageView f216v;
    ImageView f217w;
    ImageView f218x;
    ImageView f219y;
    ImageView f220z;

    public void mo17346a(String str) {
        mo17348l();
        try {
            this.f204Y.setDataSource(str);
            this.f204Y.prepare();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void mo17347k() {
        if (this.f203X) {
            this.f204Y.start();
            this.f186G.setImageResource(R.drawable.ic_pause_music_drums);
            return;
        }
        Toast.makeText(this, (int) R.string.Please_Select_Spark_Song, Toast.LENGTH_SHORT).show();
    }

    public void mo17348l() {
        this.f203X = false;
        if (this.f204Y.isPlaying()) {
            this.f204Y.stop();
        }
        this.f204Y.reset();
    }

    public void mo17349m() {
        this.f204Y.pause();
        this.f186G.setImageResource(R.drawable.ic_play_music_drums);
    }

    public void mo17350n() {
        this.f204Y.stop();
        this.f186G.setImageResource(R.drawable.ic_play_music_drums);
    }

    public void mo17351o() {
        if (this.f204Y.isPlaying()) {
            this.f204Y.stop();
        }
        this.f204Y.reset();
        this.f204Y.release();
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 0 && i2 == -1) {
            mo17346a(intent.getStringExtra("song_uri"));
        }
    }

    @Override
    public void onDestroy() {
        mo17351o();
        super.onDestroy();
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        MediaPlayer mediaPlayer = this.f187H;
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            this.f187H.release();
            this.f187H = null;
        }
        MediaPlayer mediaPlayer2 = this.f195P;
        if (mediaPlayer2 != null) {
            mediaPlayer2.stop();
            this.f195P.release();
            this.f195P = null;
        }
        MediaPlayer mediaPlayer3 = this.f196Q;
        if (mediaPlayer3 != null) {
            mediaPlayer3.stop();
            this.f196Q.release();
            this.f196Q = null;
        }
        MediaPlayer mediaPlayer4 = this.f197R1;
        if (mediaPlayer4 != null) {
            mediaPlayer4.stop();
            this.f197R1.release();
            this.f197R1 = null;
        }
        MediaPlayer mediaPlayer5 = this.f198S;
        if (mediaPlayer5 != null) {
            mediaPlayer5.stop();
            this.f198S.release();
            this.f198S = null;
        }
        MediaPlayer mediaPlayer6 = this.f199T;
        if (mediaPlayer6 != null) {
            mediaPlayer6.stop();
            this.f199T.release();
            this.f199T = null;
        }
        MediaPlayer mediaPlayer7 = this.f200U;
        if (mediaPlayer7 != null) {
            mediaPlayer7.stop();
            this.f200U.release();
            this.f200U = null;
        }
        MediaPlayer mediaPlayer8 = this.f201V;
        if (mediaPlayer8 != null) {
            mediaPlayer8.stop();
            this.f201V.release();
            this.f201V = null;
        }
        MediaPlayer mediaPlayer9 = this.f202W;
        if (mediaPlayer9 != null) {
            mediaPlayer9.stop();
            this.f202W.release();
            this.f202W = null;
        }
        MediaPlayer mediaPlayer10 = this.f188I;
        if (mediaPlayer10 != null) {
            mediaPlayer10.stop();
            this.f188I.release();
            this.f188I = null;
        }
        MediaPlayer mediaPlayer11 = this.f189J;
        if (mediaPlayer11 != null) {
            mediaPlayer11.stop();
            this.f189J.release();
            this.f189J = null;
        }
        MediaPlayer mediaPlayer12 = this.f190K;
        if (mediaPlayer12 != null) {
            mediaPlayer12.stop();
            this.f190K.release();
            this.f190K = null;
        }
        MediaPlayer mediaPlayer13 = this.f191L;
        if (mediaPlayer13 != null) {
            mediaPlayer13.stop();
            this.f191L.release();
            this.f191L = null;
        }
        MediaPlayer mediaPlayer14 = this.f192M;
        if (mediaPlayer14 != null) {
            mediaPlayer14.stop();
            this.f192M.release();
            this.f192M = null;
        }
        MediaPlayer mediaPlayer15 = this.f193N;
        if (mediaPlayer15 != null) {
            mediaPlayer15.stop();
            this.f193N.release();
            this.f193N = null;
        }
        MediaPlayer mediaPlayer16 = this.f194O;
        if (mediaPlayer16 != null) {
            mediaPlayer16.stop();
            this.f194O.release();
            this.f194O = null;
        }
        finish();
    }

    public void CallIntent(int i) {
        if (i == 1) {
            if (this.f204Y.isPlaying()) {
                mo17350n();
            } else {
                startActivityForResult(new Intent(this, SongPickerActivity.class), 0);
            }
        }
    }

    public void onClick(View view) {
        MediaPlayer mediaPlayer;
        switch (view.getId()) {
            case R.id.lbl1:
                MediaPlayer mediaPlayer2 = this.f187H;
                if (mediaPlayer2 != null) {
                    mediaPlayer2.stop();
                    this.f187H.release();
                }
                MediaPlayer create = MediaPlayer.create(this, (int) R.raw.ato1);
                this.f187H = create;
                float f = this.f206l;
                create.setVolume(f, f);
                mediaPlayer = this.f187H;
                break;
            case R.id.lbl10:
                MediaPlayer mediaPlayer3 = this.f188I;
                if (mediaPlayer3 != null) {
                    mediaPlayer3.stop();
                    this.f188I.release();
                }
                MediaPlayer create2 = MediaPlayer.create(this, (int) R.raw.ato10);
                this.f188I = create2;
                float f2 = this.f206l;
                create2.setVolume(f2, f2);
                mediaPlayer = this.f188I;
                break;
            case R.id.lbl11:
                MediaPlayer mediaPlayer4 = this.f189J;
                if (mediaPlayer4 != null) {
                    mediaPlayer4.stop();
                    this.f189J.release();
                }
                MediaPlayer create3 = MediaPlayer.create(this, (int) R.raw.ato11);
                this.f189J = create3;
                float f3 = this.f206l;
                create3.setVolume(f3, f3);
                mediaPlayer = this.f189J;
                break;
            case R.id.lbl12:
                MediaPlayer mediaPlayer5 = this.f190K;
                if (mediaPlayer5 != null) {
                    mediaPlayer5.stop();
                    this.f190K.release();
                }
                MediaPlayer create4 = MediaPlayer.create(this, (int) R.raw.ato12);
                this.f190K = create4;
                float f4 = this.f206l;
                create4.setVolume(f4, f4);
                mediaPlayer = this.f190K;
                break;
            case R.id.lbl13:
                MediaPlayer mediaPlayer6 = this.f191L;
                if (mediaPlayer6 != null) {
                    mediaPlayer6.stop();
                    this.f191L.release();
                }
                MediaPlayer create5 = MediaPlayer.create(this, (int) R.raw.ato13);
                this.f191L = create5;
                float f5 = this.f206l;
                create5.setVolume(f5, f5);
                mediaPlayer = this.f191L;
                break;
            case R.id.lbl14:
                MediaPlayer mediaPlayer7 = this.f192M;
                if (mediaPlayer7 != null) {
                    mediaPlayer7.stop();
                    this.f192M.release();
                }
                MediaPlayer create6 = MediaPlayer.create(this, (int) R.raw.ato14);
                this.f192M = create6;
                float f6 = this.f206l;
                create6.setVolume(f6, f6);
                mediaPlayer = this.f192M;
                break;
            case R.id.lbl15:
                MediaPlayer mediaPlayer8 = this.f193N;
                if (mediaPlayer8 != null) {
                    mediaPlayer8.stop();
                    this.f193N.release();
                }
                MediaPlayer create7 = MediaPlayer.create(this, (int) R.raw.ato15);
                this.f193N = create7;
                float f7 = this.f206l;
                create7.setVolume(f7, f7);
                mediaPlayer = this.f193N;
                break;
            case R.id.lbl16:
                MediaPlayer mediaPlayer9 = this.f194O;
                if (mediaPlayer9 != null) {
                    mediaPlayer9.stop();
                    this.f194O.release();
                }
                MediaPlayer create8 = MediaPlayer.create(this, (int) R.raw.ato16);
                this.f194O = create8;
                float f8 = this.f206l;
                create8.setVolume(f8, f8);
                mediaPlayer = this.f194O;
                break;
            case R.id.lbl2:
                MediaPlayer mediaPlayer10 = this.f195P;
                if (mediaPlayer10 != null) {
                    mediaPlayer10.stop();
                    this.f195P.release();
                }
                MediaPlayer create9 = MediaPlayer.create(this, (int) R.raw.ato2);
                this.f195P = create9;
                float f9 = this.f206l;
                create9.setVolume(f9, f9);
                mediaPlayer = this.f195P;
                break;
            case R.id.lbl3:
                MediaPlayer mediaPlayer11 = this.f196Q;
                if (mediaPlayer11 != null) {
                    mediaPlayer11.stop();
                    this.f196Q.release();
                }
                MediaPlayer create10 = MediaPlayer.create(this, (int) R.raw.ato3);
                this.f196Q = create10;
                float f10 = this.f206l;
                create10.setVolume(f10, f10);
                mediaPlayer = this.f196Q;
                break;
            case R.id.lbl4:
                MediaPlayer mediaPlayer12 = this.f197R1;
                if (mediaPlayer12 != null) {
                    mediaPlayer12.stop();
                    this.f197R1.release();
                }
                MediaPlayer create11 = MediaPlayer.create(this, (int) R.raw.ato4);
                this.f197R1 = create11;
                float f11 = this.f206l;
                create11.setVolume(f11, f11);
                mediaPlayer = this.f197R1;
                break;
            case R.id.lbl5:
                MediaPlayer mediaPlayer13 = this.f198S;
                if (mediaPlayer13 != null) {
                    mediaPlayer13.stop();
                    this.f198S.release();
                }
                MediaPlayer create12 = MediaPlayer.create(this, (int) R.raw.ato5);
                this.f198S = create12;
                float f12 = this.f206l;
                create12.setVolume(f12, f12);
                mediaPlayer = this.f198S;
                break;
            case R.id.lbl6:
                MediaPlayer mediaPlayer14 = this.f199T;
                if (mediaPlayer14 != null) {
                    mediaPlayer14.stop();
                    this.f199T.release();
                }
                MediaPlayer create13 = MediaPlayer.create(this, (int) R.raw.ato6);
                this.f199T = create13;
                float f13 = this.f206l;
                create13.setVolume(f13, f13);
                mediaPlayer = this.f199T;
                break;
            case R.id.lbl7:
                MediaPlayer mediaPlayer15 = this.f200U;
                if (mediaPlayer15 != null) {
                    mediaPlayer15.stop();
                    this.f200U.release();
                }
                MediaPlayer create14 = MediaPlayer.create(this, (int) R.raw.ato7);
                this.f200U = create14;
                float f14 = this.f206l;
                create14.setVolume(f14, f14);
                mediaPlayer = this.f200U;
                break;
            case R.id.lbl8:
                MediaPlayer mediaPlayer16 = this.f201V;
                if (mediaPlayer16 != null) {
                    mediaPlayer16.stop();
                    this.f201V.release();
                }
                MediaPlayer create15 = MediaPlayer.create(this, (int) R.raw.ato8);
                this.f201V = create15;
                float f15 = this.f206l;
                create15.setVolume(f15, f15);
                mediaPlayer = this.f201V;
                break;
            case R.id.lbl9:
                MediaPlayer mediaPlayer17 = this.f202W;
                if (mediaPlayer17 != null) {
                    mediaPlayer17.stop();
                    this.f202W.release();
                }
                MediaPlayer create16 = MediaPlayer.create(this, (int) R.raw.ato9);
                this.f202W = create16;
                float f16 = this.f206l;
                create16.setVolume(f16, f16);
                mediaPlayer = this.f202W;
                break;
            default:
                return;
        }
        mediaPlayer.start();
    }

    @Override
    public void onCreate(Bundle bundle) {

        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        setContentView(R.layout.activity_drum_demo4);


        this.context = this;
        findViewById(R.id.lbltitle1).setSelected(true);
        ImageView imageView = (ImageView) findViewById(R.id.back4);
        this.f205k = imageView;
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumDemoActivity4.this.onBackPressed();
            }
        });
        this.f208n = (ImageView) findViewById(R.id.lbl1);
        this.f216v = (ImageView) findViewById(R.id.lbl2);
        this.f217w = (ImageView) findViewById(R.id.lbl3);
        this.f218x = (ImageView) findViewById(R.id.lbl4);
        this.f219y = (ImageView) findViewById(R.id.lbl5);
        this.f220z = (ImageView) findViewById(R.id.lbl6);
        this.f180A = (ImageView) findViewById(R.id.lbl7);
        this.f181B = (ImageView) findViewById(R.id.lbl8);
        this.f182C = (ImageView) findViewById(R.id.lbl9);
        this.f209o = (ImageView) findViewById(R.id.lbl10);
        this.f210p = (ImageView) findViewById(R.id.lbl11);
        this.f211q = (ImageView) findViewById(R.id.lbl12);
        this.f212r = (ImageView) findViewById(R.id.lbl13);
        this.f213s = (ImageView) findViewById(R.id.lbl14);
        this.f214t = (ImageView) findViewById(R.id.lbl15);
        this.f215u = (ImageView) findViewById(R.id.lbl16);
        this.f208n.setOnClickListener(this);
        this.f216v.setOnClickListener(this);
        this.f217w.setOnClickListener(this);
        this.f218x.setOnClickListener(this);
        this.f219y.setOnClickListener(this);
        this.f220z.setOnClickListener(this);
        this.f180A.setOnClickListener(this);
        this.f181B.setOnClickListener(this);
        this.f182C.setOnClickListener(this);
        this.f209o.setOnClickListener(this);
        this.f210p.setOnClickListener(this);
        this.f211q.setOnClickListener(this);
        this.f212r.setOnClickListener(this);
        this.f213s.setOnClickListener(this);
        this.f214t.setOnClickListener(this);
        this.f215u.setOnClickListener(this);
        this.f187H = MediaPlayer.create(this, (int) R.raw.ato1);
        this.f195P = MediaPlayer.create(this, (int) R.raw.ato2);
        this.f196Q = MediaPlayer.create(this, (int) R.raw.ato3);
        this.f197R1 = MediaPlayer.create(this, (int) R.raw.ato4);
        this.f198S = MediaPlayer.create(this, (int) R.raw.ato5);
        this.f199T = MediaPlayer.create(this, (int) R.raw.ato6);
        this.f200U = MediaPlayer.create(this, (int) R.raw.ato7);
        this.f201V = MediaPlayer.create(this, (int) R.raw.ato8);
        this.f202W = MediaPlayer.create(this, (int) R.raw.ato9);
        this.f188I = MediaPlayer.create(this, (int) R.raw.ato10);
        this.f189J = MediaPlayer.create(this, (int) R.raw.ato11);
        this.f190K = MediaPlayer.create(this, (int) R.raw.ato12);
        this.f191L = MediaPlayer.create(this, (int) R.raw.ato13);
        this.f192M = MediaPlayer.create(this, (int) R.raw.ato14);
        this.f193N = MediaPlayer.create(this, (int) R.raw.ato15);
        this.f194O = MediaPlayer.create(this, (int) R.raw.ato16);
        this.f204Y.setOnPreparedListener(this.f185F);
        this.f204Y.setOnErrorListener(this.f207m);
        this.f204Y.setOnCompletionListener(this.f184E);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.load_song);
        this.f183D = linearLayout;
        linearLayout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumDemoActivity4.this.CallIntent(1);
            }
        });
        ImageView imageView2 = (ImageView) findViewById(R.id.play_song);
        this.f186G = imageView2;
        imageView2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity4.this.f204Y.isPlaying()) {
                    DrumDemoActivity4.this.mo17349m();
                } else {
                    DrumDemoActivity4.this.mo17347k();
                }
            }
        });
    }
}
