package com.djmusicmixer.djmixer.audiomixer.Addmodul;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.base.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;

public class DrumDemoActivity6 extends BaseActivity implements View.OnClickListener {
    Context context;
    ImageView f261A;
    ImageView f262B;
    LinearLayout f263C;
    MediaPlayer.OnCompletionListener f264D = new MediaPlayer.OnCompletionListener() {
        public void onCompletion(MediaPlayer mediaPlayer) {
            DrumDemoActivity6.this.f266F.setImageResource(R.drawable.ic_play_music_drums);
            DrumDemoActivity6.this.f283W = false;
        }
    };
    MediaPlayer.OnPreparedListener f265E = new MediaPlayer.OnPreparedListener() {
        public void onPrepared(MediaPlayer mediaPlayer) {
            DrumDemoActivity6.this.f283W = true;
        }
    };
    ImageView f266F;
    MediaPlayer f267G;
    MediaPlayer f268H;
    MediaPlayer f269I;
    MediaPlayer f270J;
    MediaPlayer f271K;
    MediaPlayer f272L;
    MediaPlayer f273M;
    MediaPlayer f274N;
    MediaPlayer f275O;
    MediaPlayer f276P;
    MediaPlayer f277Q;
    MediaPlayer f278R1;
    MediaPlayer f279S;
    MediaPlayer f280T;
    MediaPlayer f281U;
    MediaPlayer f282V;
    public boolean f283W = false;
    public MediaPlayer f284X = new MediaPlayer();
    float f285k = 1.0f;
    MediaPlayer.OnErrorListener f286l = new MediaPlayer.OnErrorListener() {
        public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
            DrumDemoActivity6.this.f266F.setImageResource(R.drawable.ic_play_music_drums);
            DrumDemoActivity6.this.f283W = false;
            return false;
        }
    };
    ImageView f287m;
    ImageView f288n;
    ImageView f289o;
    ImageView f290p;
    ImageView f291q;
    ImageView f292r;
    ImageView f293s;
    ImageView f294t;
    ImageView f295u;
    ImageView f296v;
    ImageView f297w;
    ImageView f298x;
    ImageView f299y;
    ImageView f300z;

    public void mo17372a(String str) {
        mo17374l();
        try {
            this.f284X.setDataSource(str);
            this.f284X.prepare();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void mo17373k() {
        if (this.f283W) {
            this.f284X.start();
            this.f266F.setImageResource(R.drawable.ic_pause_music_drums);
            return;
        }
        Toast.makeText(this, (int) R.string.Please_Select_Spark_Song, Toast.LENGTH_SHORT).show();
    }

    public void mo17374l() {
        this.f283W = false;
        if (this.f284X.isPlaying()) {
            this.f284X.stop();
        }
        this.f284X.reset();
    }

    public void mo17375m() {
        this.f284X.pause();
        this.f266F.setImageResource(R.drawable.ic_play_music_drums);
    }

    public void mo17376n() {
        this.f284X.stop();
        this.f266F.setImageResource(R.drawable.ic_play_music_drums);
    }

    public void mo17377o() {
        if (this.f284X.isPlaying()) {
            this.f284X.stop();
        }
        this.f284X.reset();
        this.f284X.release();
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 0 && i2 == -1) {
            mo17372a(intent.getStringExtra("song_uri"));
        }
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        try {
            MediaPlayer mediaPlayer = this.f267G;
            if (mediaPlayer != null) {
                mediaPlayer.stop();
                this.f267G.release();
            }
            MediaPlayer mediaPlayer2 = this.f275O;
            if (mediaPlayer2 != null) {
                mediaPlayer2.stop();
                this.f275O.release();
            }
            MediaPlayer mediaPlayer3 = this.f276P;
            if (mediaPlayer3 != null) {
                mediaPlayer3.stop();
                this.f276P.release();
            }
            MediaPlayer mediaPlayer4 = this.f277Q;
            if (mediaPlayer4 != null) {
                mediaPlayer4.stop();
                this.f277Q.release();
            }
            MediaPlayer mediaPlayer5 = this.f278R1;
            if (mediaPlayer5 != null) {
                mediaPlayer5.stop();
                this.f278R1.release();
            }
            MediaPlayer mediaPlayer6 = this.f279S;
            if (mediaPlayer6 != null) {
                mediaPlayer6.stop();
                this.f279S.release();
            }
            MediaPlayer mediaPlayer7 = this.f280T;
            if (mediaPlayer7 != null) {
                mediaPlayer7.stop();
                this.f280T.release();
            }
            MediaPlayer mediaPlayer8 = this.f281U;
            if (mediaPlayer8 != null) {
                mediaPlayer8.stop();
                this.f281U.release();
            }
            MediaPlayer mediaPlayer9 = this.f282V;
            if (mediaPlayer9 != null) {
                mediaPlayer9.stop();
                this.f282V.release();
            }
            MediaPlayer mediaPlayer10 = this.f268H;
            if (mediaPlayer10 != null) {
                mediaPlayer10.stop();
                this.f268H.release();
            }
            MediaPlayer mediaPlayer11 = this.f269I;
            if (mediaPlayer11 != null) {
                mediaPlayer11.stop();
                this.f269I.release();
            }
            MediaPlayer mediaPlayer12 = this.f270J;
            if (mediaPlayer12 != null) {
                mediaPlayer12.stop();
                this.f270J.release();
            }
            MediaPlayer mediaPlayer13 = this.f271K;
            if (mediaPlayer13 != null) {
                mediaPlayer13.stop();
                this.f271K.release();
            }
            MediaPlayer mediaPlayer14 = this.f272L;
            if (mediaPlayer14 != null) {
                mediaPlayer14.stop();
                this.f272L.release();
            }
            MediaPlayer mediaPlayer15 = this.f273M;
            if (mediaPlayer15 != null) {
                mediaPlayer15.stop();
                this.f273M.release();
            }
            MediaPlayer mediaPlayer16 = this.f274N;
            if (mediaPlayer16 != null) {
                mediaPlayer16.stop();
                this.f274N.release();
            }
        } catch (IllegalStateException unused) {
        }
        finish();
    }

    public void CallIntent(int i) {
        if (i == 1) {
            if (this.f284X.isPlaying()) {
                mo17376n();
            } else {
                startActivityForResult(new Intent(this, SongPickerActivity.class), 0);
            }
        }
    }

    public void onClick(View view) {
        MediaPlayer mediaPlayer;
        switch (view.getId()) {
            case R.id.lbl1:
                MediaPlayer mediaPlayer2 = this.f267G;
                if (mediaPlayer2 != null) {
                    mediaPlayer2.stop();
                    this.f267G.release();
                }
                MediaPlayer create = MediaPlayer.create(this, (int) R.raw.ki1);
                this.f267G = create;
                float f = this.f285k;
                create.setVolume(f, f);
                mediaPlayer = this.f267G;
                break;
            case R.id.lbl10:
                MediaPlayer mediaPlayer3 = this.f268H;
                if (mediaPlayer3 != null) {
                    mediaPlayer3.stop();
                    this.f268H.release();
                }
                MediaPlayer create2 = MediaPlayer.create(this, (int) R.raw.ki10);
                this.f268H = create2;
                float f2 = this.f285k;
                create2.setVolume(f2, f2);
                mediaPlayer = this.f268H;
                break;
            case R.id.lbl11:
                MediaPlayer mediaPlayer4 = this.f269I;
                if (mediaPlayer4 != null) {
                    mediaPlayer4.stop();
                    this.f269I.release();
                }
                MediaPlayer create3 = MediaPlayer.create(this, (int) R.raw.ki11);
                this.f269I = create3;
                float f3 = this.f285k;
                create3.setVolume(f3, f3);
                mediaPlayer = this.f269I;
                break;
            case R.id.lbl12:
                MediaPlayer mediaPlayer5 = this.f270J;
                if (mediaPlayer5 != null) {
                    mediaPlayer5.stop();
                    this.f270J.release();
                }
                MediaPlayer create4 = MediaPlayer.create(this, (int) R.raw.ki12);
                this.f270J = create4;
                float f4 = this.f285k;
                create4.setVolume(f4, f4);
                mediaPlayer = this.f270J;
                break;
            case R.id.lbl13:
                MediaPlayer mediaPlayer6 = this.f271K;
                if (mediaPlayer6 != null) {
                    mediaPlayer6.stop();
                    this.f271K.release();
                }
                MediaPlayer create5 = MediaPlayer.create(this, (int) R.raw.ki13);
                this.f271K = create5;
                float f5 = this.f285k;
                create5.setVolume(f5, f5);
                mediaPlayer = this.f271K;
                break;
            case R.id.lbl14:
                MediaPlayer mediaPlayer7 = this.f272L;
                if (mediaPlayer7 != null) {
                    mediaPlayer7.stop();
                    this.f272L.release();
                }
                MediaPlayer create6 = MediaPlayer.create(this, (int) R.raw.ki14);
                this.f272L = create6;
                float f6 = this.f285k;
                create6.setVolume(f6, f6);
                mediaPlayer = this.f272L;
                break;
            case R.id.lbl15:
                MediaPlayer mediaPlayer8 = this.f273M;
                if (mediaPlayer8 != null) {
                    mediaPlayer8.stop();
                    this.f273M.release();
                }
                MediaPlayer create7 = MediaPlayer.create(this, (int) R.raw.ki15);
                this.f273M = create7;
                float f7 = this.f285k;
                create7.setVolume(f7, f7);
                mediaPlayer = this.f273M;
                break;
            case R.id.lbl16:
                MediaPlayer mediaPlayer9 = this.f274N;
                if (mediaPlayer9 != null) {
                    mediaPlayer9.stop();
                    this.f274N.release();
                }
                MediaPlayer create8 = MediaPlayer.create(this, (int) R.raw.ki16);
                this.f274N = create8;
                float f8 = this.f285k;
                create8.setVolume(f8, f8);
                mediaPlayer = this.f274N;
                break;
            case R.id.lbl2:
                MediaPlayer mediaPlayer10 = this.f275O;
                if (mediaPlayer10 != null) {
                    mediaPlayer10.stop();
                    this.f275O.release();
                }
                MediaPlayer create9 = MediaPlayer.create(this, (int) R.raw.ki2);
                this.f275O = create9;
                float f9 = this.f285k;
                create9.setVolume(f9, f9);
                mediaPlayer = this.f275O;
                break;
            case R.id.lbl3:
                MediaPlayer mediaPlayer11 = this.f276P;
                if (mediaPlayer11 != null) {
                    mediaPlayer11.stop();
                    this.f276P.release();
                }
                MediaPlayer create10 = MediaPlayer.create(this, (int) R.raw.ki3);
                this.f276P = create10;
                float f10 = this.f285k;
                create10.setVolume(f10, f10);
                mediaPlayer = this.f276P;
                break;
            case R.id.lbl4:
                MediaPlayer mediaPlayer12 = this.f277Q;
                if (mediaPlayer12 != null) {
                    mediaPlayer12.stop();
                    this.f277Q.release();
                }
                MediaPlayer create11 = MediaPlayer.create(this, (int) R.raw.ki4);
                this.f277Q = create11;
                float f11 = this.f285k;
                create11.setVolume(f11, f11);
                mediaPlayer = this.f277Q;
                break;
            case R.id.lbl5:
                MediaPlayer mediaPlayer13 = this.f278R1;
                if (mediaPlayer13 != null) {
                    mediaPlayer13.stop();
                    this.f278R1.release();
                }
                MediaPlayer create12 = MediaPlayer.create(this, (int) R.raw.ki5);
                this.f278R1 = create12;
                float f12 = this.f285k;
                create12.setVolume(f12, f12);
                mediaPlayer = this.f278R1;
                break;
            case R.id.lbl6:
                MediaPlayer mediaPlayer14 = this.f279S;
                if (mediaPlayer14 != null) {
                    mediaPlayer14.stop();
                    this.f279S.release();
                }
                MediaPlayer create13 = MediaPlayer.create(this, (int) R.raw.ki6);
                this.f279S = create13;
                float f13 = this.f285k;
                create13.setVolume(f13, f13);
                mediaPlayer = this.f279S;
                break;
            case R.id.lbl7:
                MediaPlayer mediaPlayer15 = this.f280T;
                if (mediaPlayer15 != null) {
                    mediaPlayer15.stop();
                    this.f280T.release();
                }
                MediaPlayer create14 = MediaPlayer.create(this, (int) R.raw.ki7);
                this.f280T = create14;
                float f14 = this.f285k;
                create14.setVolume(f14, f14);
                mediaPlayer = this.f280T;
                break;
            case R.id.lbl8:
                MediaPlayer mediaPlayer16 = this.f281U;
                if (mediaPlayer16 != null) {
                    mediaPlayer16.stop();
                    this.f281U.release();
                }
                MediaPlayer create15 = MediaPlayer.create(this, (int) R.raw.ki8);
                this.f281U = create15;
                float f15 = this.f285k;
                create15.setVolume(f15, f15);
                mediaPlayer = this.f281U;
                break;
            case R.id.lbl9:
                MediaPlayer mediaPlayer17 = this.f282V;
                if (mediaPlayer17 != null) {
                    mediaPlayer17.stop();
                    this.f282V.release();
                }
                MediaPlayer create16 = MediaPlayer.create(this, (int) R.raw.ki9);
                this.f282V = create16;
                float f16 = this.f285k;
                create16.setVolume(f16, f16);
                mediaPlayer = this.f282V;
                break;
            default:
                return;
        }
        mediaPlayer.start();
    }

    @Override
    public void onCreate(Bundle bundle) {
        
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        setContentView(R.layout.activity_drum_demo6);

        this.context = this;
        findViewById(R.id.lbltitle1).setSelected(true);
        findViewById(R.id.back4).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumDemoActivity6.this.onBackPressed();
            }
        });
        this.f287m = (ImageView) findViewById(R.id.lbl1);
        this.f295u = (ImageView) findViewById(R.id.lbl2);
        this.f296v = (ImageView) findViewById(R.id.lbl3);
        this.f297w = (ImageView) findViewById(R.id.lbl4);
        this.f298x = (ImageView) findViewById(R.id.lbl5);
        this.f299y = (ImageView) findViewById(R.id.lbl6);
        this.f300z = (ImageView) findViewById(R.id.lbl7);
        this.f261A = (ImageView) findViewById(R.id.lbl8);
        this.f262B = (ImageView) findViewById(R.id.lbl9);
        this.f288n = (ImageView) findViewById(R.id.lbl10);
        this.f289o = (ImageView) findViewById(R.id.lbl11);
        this.f290p = (ImageView) findViewById(R.id.lbl12);
        this.f291q = (ImageView) findViewById(R.id.lbl13);
        this.f292r = (ImageView) findViewById(R.id.lbl14);
        this.f293s = (ImageView) findViewById(R.id.lbl15);
        this.f294t = (ImageView) findViewById(R.id.lbl16);
        this.f287m.setOnClickListener(this);
        this.f295u.setOnClickListener(this);
        this.f296v.setOnClickListener(this);
        this.f297w.setOnClickListener(this);
        this.f298x.setOnClickListener(this);
        this.f299y.setOnClickListener(this);
        this.f300z.setOnClickListener(this);
        this.f261A.setOnClickListener(this);
        this.f262B.setOnClickListener(this);
        this.f288n.setOnClickListener(this);
        this.f289o.setOnClickListener(this);
        this.f290p.setOnClickListener(this);
        this.f291q.setOnClickListener(this);
        this.f292r.setOnClickListener(this);
        this.f293s.setOnClickListener(this);
        this.f294t.setOnClickListener(this);
        this.f267G = MediaPlayer.create(this, (int) R.raw.ki1);
        this.f275O = MediaPlayer.create(this, (int) R.raw.ki2);
        this.f276P = MediaPlayer.create(this, (int) R.raw.ki3);
        this.f277Q = MediaPlayer.create(this, (int) R.raw.ki4);
        this.f278R1 = MediaPlayer.create(this, (int) R.raw.ki5);
        this.f279S = MediaPlayer.create(this, (int) R.raw.ki6);
        this.f280T = MediaPlayer.create(this, (int) R.raw.ki7);
        this.f281U = MediaPlayer.create(this, (int) R.raw.ki8);
        this.f282V = MediaPlayer.create(this, (int) R.raw.ki9);
        this.f268H = MediaPlayer.create(this, (int) R.raw.ki10);
        this.f269I = MediaPlayer.create(this, (int) R.raw.ki11);
        this.f270J = MediaPlayer.create(this, (int) R.raw.ki12);
        this.f271K = MediaPlayer.create(this, (int) R.raw.ki13);
        this.f272L = MediaPlayer.create(this, (int) R.raw.ki14);
        this.f273M = MediaPlayer.create(this, (int) R.raw.ki15);
        this.f274N = MediaPlayer.create(this, (int) R.raw.ki16);
        this.f284X.setOnPreparedListener(this.f265E);
        this.f284X.setOnErrorListener(this.f286l);
        this.f284X.setOnCompletionListener(this.f264D);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.load_song);
        this.f263C = linearLayout;
        linearLayout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumDemoActivity6.this.CallIntent(1);
            }
        });
        ImageView imageView = (ImageView) findViewById(R.id.play_song);
        this.f266F = imageView;
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DrumDemoActivity6.this.f284X.isPlaying()) {
                    DrumDemoActivity6.this.mo17375m();
                } else {
                    DrumDemoActivity6.this.mo17373k();
                }
            }
        });
        ((ImageView) findViewById(R.id.back4)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumDemoActivity6.this.onBackPressed();
            }
        });
    }

    @Override
    public void onDestroy() {
        mo17377o();
        super.onDestroy();
    }
}
