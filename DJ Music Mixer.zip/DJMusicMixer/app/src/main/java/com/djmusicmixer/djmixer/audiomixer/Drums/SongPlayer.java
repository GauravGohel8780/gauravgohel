package com.djmusicmixer.djmixer.audiomixer.Drums;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.djmusicmixer.djmixer.audiomixer.R;

public class SongPlayer {
    public Activity activity;
    private ImageView btnControlsSlider;
    public ImageView btnPlay;
    public View controlsHolder;
    MediaPlayer.OnErrorListener errorListener = new MediaPlayer.OnErrorListener() {
        public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
            SongPlayer.this.btnPlay.setImageResource(R.drawable.ic_play_drums);
            SongPlayer.this.isPrepared = false;
            return false;
        }
    };
    public MediaPlayer f352mp = new MediaPlayer();
    public boolean isControlBarVisible;
    public boolean isPrepared = false;
    MediaPlayer.OnCompletionListener onCompletionListener = new MediaPlayer.OnCompletionListener() {
        public void onCompletion(MediaPlayer mediaPlayer) {
            SongPlayer.this.btnPlay.setImageResource(R.drawable.ic_play_drums);
            SongPlayer.this.isPrepared = false;
        }
    };
    MediaPlayer.OnPreparedListener onPreparedListener = new MediaPlayer.OnPreparedListener() {
        public void onPrepared(MediaPlayer mediaPlayer) {
            SongPlayer.this.isPrepared = true;
        }
    };
    private View.OnClickListener playClickListener = new View.OnClickListener() {
        public void onClick(View view) {
            if (SongPlayer.this.f352mp.isPlaying()) {
                SongPlayer.this.pause();
            } else {
                SongPlayer.this.resume();
            }
        }
    };
    private View.OnClickListener selectFileListener = new View.OnClickListener() {
        public void onClick(View view) {
            if (SongPlayer.this.f352mp.isPlaying()) {
                SongPlayer.this.stop();
            } else {
                SongPlayer.this.activity.startActivityForResult(new Intent(SongPlayer.this.activity, SongPickerActivity.class), 0);
            }
        }
    };
    private View.OnClickListener sliderClickListener = new View.OnClickListener() {
        public void onClick(View view) {
            if (SongPlayer.this.isControlBarVisible) {
                SongPlayer.this.controlsHolder.setVisibility(View.INVISIBLE);
                SongPlayer.this.isControlBarVisible = false;
                return;
            }
            SongPlayer.this.controlsHolder.setVisibility(View.VISIBLE);
            SongPlayer.this.isControlBarVisible = true;
        }
    };

    private SongPlayer(Activity activity2) {
        this.f352mp.setOnPreparedListener(this.onPreparedListener);
        this.f352mp.setOnErrorListener(this.errorListener);
        this.f352mp.setOnCompletionListener(this.onCompletionListener);
        this.activity = activity2;
    }

    public void prepare(String str) {
        reset();
        try {
            this.f352mp.setDataSource(str);
            this.f352mp.prepare();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void resume() {
        if (this.isPrepared) {
            this.f352mp.start();
            this.btnPlay.setImageResource(R.drawable.ic_pause_drums);
            return;
        }
        Activity activity2 = this.activity;
        Toast.makeText(activity2, activity2.getResources().getString(R.string.Song_not_ready), Toast.LENGTH_SHORT).show();
    }

    public void pause() {
        this.f352mp.pause();
        this.btnPlay.setImageResource(R.drawable.ic_play_drums);
    }

    public void stop() {
        this.f352mp.stop();
        this.btnPlay.setImageResource(R.drawable.ic_play_drums);
    }

    public void reset() {
        this.isPrepared = false;
        if (this.f352mp.isPlaying()) {
            this.f352mp.stop();
        }
        this.f352mp.reset();
    }

    private void initUIControls(View view) {
        ImageView imageView = (ImageView) view.findViewById(R.id.play);
        this.btnPlay = imageView;
        imageView.setOnClickListener(this.playClickListener);
        ImageView imageView2 = (ImageView) view.findViewById(R.id.controls_slider);
        this.btnControlsSlider = imageView2;
        imageView2.setOnClickListener(this.sliderClickListener);
        view.findViewById(R.id.btn_select_files).setOnClickListener(this.selectFileListener);
        View findViewById = view.findViewById(R.id.play_controls);
        this.controlsHolder = findViewById;
        this.isControlBarVisible = findViewById.getVisibility() == View.VISIBLE;
    }

    public static SongPlayer createInstance(Activity activity2, View view) {
        SongPlayer cNX_SongPlayer = new SongPlayer(activity2);
        cNX_SongPlayer.initUIControls(view);
        return cNX_SongPlayer;
    }

    public void destroy() {
        if (this.f352mp.isPlaying()) {
            this.f352mp.stop();
        }
        this.f352mp.reset();
        this.f352mp.release();
    }
}
