package com.djmusicmixer.djmixer.audiomixer.mixer.Adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.mixer.Listener.OnClickLibraryItem;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Album;
import com.djmusicmixer.djmixer.audiomixer.mixer.Utils.MusicUtil;

import java.util.ArrayList;

public class LibAlbumAdapter extends RecyclerView.Adapter<LibAlbumAdapter.ViewHolder> {
    private Activity activity;
    public ArrayList<Album> arrayList;
    public OnClickLibraryItem onClickLibraryItem;

    public LibAlbumAdapter(Activity activity2, ArrayList<Album> arrayList2) {
        this.activity = activity2;
        this.arrayList = arrayList2;
    }

    @Override 
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.libalbum_rkappzia_list_item, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        ((RequestBuilder) Glide.with(this.activity).load(MusicUtil.getAlbumCoverUri(this.arrayList.get(i).getFirstSong().albumId)).placeholder((int) R.drawable.ic_album_music_dj)).into(viewHolder.iv_thumb);
        viewHolder.tv_title.setText(this.arrayList.get(i).getTitle());
        viewHolder.tv_info.setText(getAlbumText(this.arrayList.get(i)));
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                LibAlbumAdapter.this.onClickLibraryItem.onClickSongsItem(LibAlbumAdapter.this.arrayList.get(i).getId());
            }
        });
    }

    @Override 
    public int getItemCount() {
        return this.arrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView iv_thumb;
        TextView tv_info;
        TextView tv_title;

        ViewHolder(View view) {
            super(view);
            this.iv_thumb = (ImageView) view.findViewById(R.id.iv_thumb);
            this.tv_title = (TextView) view.findViewById(R.id.tv_title_rkappzia);
            this.tv_info = (TextView) view.findViewById(R.id.tv_info);
        }
    }

    public void setOnItemClickListener(OnClickLibraryItem onClickLibraryItem2) {
        this.onClickLibraryItem = onClickLibraryItem2;
    }

    private String getAlbumText(Album album) {
        if (album.songs != null) {
            return MusicUtil.buildInfoString("", MusicUtil.getSongCount(album.songs.size()));
        }
        return "";
    }
}
