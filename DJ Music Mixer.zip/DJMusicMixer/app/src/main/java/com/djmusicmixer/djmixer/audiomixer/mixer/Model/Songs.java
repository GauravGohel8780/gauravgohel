package com.djmusicmixer.djmixer.audiomixer.mixer.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class Songs implements Parcelable {
    public static final Creator<Songs> CREATOR = new Creator<Songs>() {
        @Override 
        public Songs createFromParcel(Parcel parcel) {
            return new Songs(parcel);
        }

        @Override 
        public Songs[] newArray(int i) {
            return new Songs[i];
        }
    };
    public static final Songs empty_songs = new Songs(-1, "", -1, -1, -1, "", -1, -1, "", -1, "");
    public final long albumId;
    public final String albumName;
    public final long artistId;
    public final String artistName;
    public final String data;
    public final long dateModified;
    public final long duration;
    public final long f189id;
    public final int songNumber;
    public final String title;
    public final int year;

    public int describeContents() {
        return 0;
    }

    public Songs(long j, String str, int i, int i2, long j2, String str2, long j3, long j4, String str3, long j5, String str4) {
        this.f189id = j;
        this.title = str;
        this.songNumber = i;
        this.year = i2;
        this.duration = j2;
        this.data = str2;
        this.dateModified = j3;
        this.albumId = j4;
        this.albumName = str3;
        this.artistId = j5;
        this.artistName = str4;
    }

    public boolean equals(Object obj) {
        String str;
        String str2;
        String str3;
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass()) {
            Songs songs = (Songs) obj;
            if (this.f189id != songs.f189id || this.songNumber != songs.songNumber || this.year != songs.year || this.duration != songs.duration || this.dateModified != songs.dateModified || this.albumId != songs.albumId || this.artistId != songs.artistId || ((str = this.title) != null ? !str.equals(songs.title) : songs.title != null) || ((str2 = this.data) != null ? !str2.equals(songs.data) : songs.data != null) || ((str3 = this.albumName) != null ? !str3.equals(songs.albumName) : songs.albumName != null)) {
                return false;
            }
            String str4 = this.artistName;
            String str5 = songs.artistName;
            if (str4 != null) {
                return str4.equals(str5);
            }
            if (str5 == null) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        int i = ((int) this.f189id) * 31;
        String str = this.title;
        int i2 = 0;
        int hashCode = str != null ? str.hashCode() : 0;
        long j = this.duration;
        int i3 = (((((((i + hashCode) * 31) + this.songNumber) * 31) + this.year) * 31) + ((int) (j ^ (j >>> 32)))) * 31;
        String str2 = this.data;
        int hashCode2 = str2 != null ? str2.hashCode() : 0;
        long j2 = this.dateModified;
        int i4 = (((((i3 + hashCode2) * 31) + ((int) (j2 ^ (j2 >>> 32)))) * 31) + ((int) this.albumId)) * 31;
        String str3 = this.albumName;
        int hashCode3 = (((i4 + (str3 != null ? str3.hashCode() : 0)) * 31) + ((int) this.artistId)) * 31;
        String str4 = this.artistName;
        if (str4 != null) {
            i2 = str4.hashCode();
        }
        return hashCode3 + i2;
    }

    public String toString() {
        return "Songs{id=" + this.f189id + ", title='" + this.title + '\'' + ", songNumber=" + this.songNumber + ", year=" + this.year + ", duration=" + this.duration + ", data='" + this.data + '\'' + ", dateModified=" + this.dateModified + ", albumId=" + this.albumId + ", albumName='" + this.albumName + '\'' + ", artistId=" + this.artistId + ", artistName='" + this.artistName + '\'' + '}';
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeLong(this.f189id);
        parcel.writeString(this.title);
        parcel.writeInt(this.songNumber);
        parcel.writeInt(this.year);
        parcel.writeLong(this.duration);
        parcel.writeString(this.data);
        parcel.writeLong(this.dateModified);
        parcel.writeLong(this.albumId);
        parcel.writeString(this.albumName);
        parcel.writeLong(this.artistId);
        parcel.writeString(this.artistName);
    }

    protected Songs(Parcel parcel) {
        this.f189id = parcel.readLong();
        this.title = parcel.readString();
        this.songNumber = parcel.readInt();
        this.year = parcel.readInt();
        this.duration = parcel.readLong();
        this.data = parcel.readString();
        this.dateModified = parcel.readLong();
        this.albumId = parcel.readLong();
        this.albumName = parcel.readString();
        this.artistId = parcel.readLong();
        this.artistName = parcel.readString();
    }
}
