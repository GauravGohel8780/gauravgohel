package com.djmusicmixer.djmixer.audiomixer.Addmodul;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.djmusicmixer.djmixer.audiomixer.DrumActivity;
import com.djmusicmixer.djmixer.audiomixer.Help;
import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.activites.DrumDemoActivity;
import com.djmusicmixer.djmixer.audiomixer.base.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class SecondActivity extends BaseActivity {
    Context context;
    RelativeLayout iv_2;
    RelativeLayout iv_3;
    RelativeLayout iv_4;
    RelativeLayout iv_5;
    RelativeLayout iv_6;
    RelativeLayout iv_7;
    LinearLayout llBanner;
    RelativeLayout rlDrumPad;
    RelativeLayout rlElectroDrum;

    @Override
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
    }

    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        getWindow().addFlags(128);
        setContentView(R.layout.activity_second);


        this.context = this;
        Help.width = getResources().getDisplayMetrics().widthPixels;
        Help.height = getResources().getDisplayMetrics().heightPixels;
        RelativeLayout relativeLayout2 = (RelativeLayout) findViewById(R.id.iv_2);
        this.iv_2 = relativeLayout2;
        relativeLayout2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                SecondActivity.this.CallIntent(1);
            }
        });
        RelativeLayout relativeLayout3 = (RelativeLayout) findViewById(R.id.iv_3);
        this.iv_3 = relativeLayout3;
        relativeLayout3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                SecondActivity.this.CallIntent(2);
            }
        });
        RelativeLayout relativeLayout4 = (RelativeLayout) findViewById(R.id.iv_4);
        this.iv_4 = relativeLayout4;
        relativeLayout4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                SecondActivity.this.CallIntent(3);
            }
        });
        RelativeLayout relativeLayout5 = (RelativeLayout) findViewById(R.id.iv_5);
        this.iv_5 = relativeLayout5;
        relativeLayout5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                SecondActivity.this.CallIntent(4);
            }
        });
        RelativeLayout relativeLayout6 = (RelativeLayout) findViewById(R.id.iv_6);
        this.iv_6 = relativeLayout6;
        relativeLayout6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                SecondActivity.this.CallIntent(5);
            }
        });
        RelativeLayout relativeLayout7 = (RelativeLayout) findViewById(R.id.iv_7);
        this.iv_7 = relativeLayout7;
        relativeLayout7.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                SecondActivity.this.CallIntent(6);
            }
        });
        ((ImageView) findViewById(R.id.ic_back)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(SecondActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        SecondActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        this.rlDrumPad = (RelativeLayout) findViewById(R.id.rl_drum_pad);
        RelativeLayout relativeLayout8 = (RelativeLayout) findViewById(R.id.rl_electro_drums);
        this.rlElectroDrum = relativeLayout8;
        relativeLayout8.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(SecondActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        SecondActivity.this.startActivity(new Intent(SecondActivity.this, DrumDemoActivity.class));
                    }
                }, MAIN_CLICK);
            }
        });
        this.rlDrumPad.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(SecondActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        SecondActivity.this.startActivity(new Intent(SecondActivity.this, DrumActivity.class));
                    }
                }, MAIN_CLICK);
            }
        });
    }


    public void CallIntent(int i) {
        if (i == 1) {
            callintent(DrumDemoActivity2.class);
        } else if (i == 2) {
            callintent(DrumDemoActivity3.class);
        } else if (i == 3) {
            callintent(DrumDemoActivity4.class);
        } else if (i == 4) {
            callintent(DrumDemoActivity5.class);
        } else if (i == 5) {
            callintent(DrumDemoActivity6.class);
        } else if (i == 6) {
            callintent(DrumDemoActivity7.class);
        }
    }

    public void callintent(Class cls) {
        getInstance(SecondActivity.this).ShowAd(new HandleClick() {
            @Override
            public void Show(boolean adShow) {
                startActivity(new Intent(SecondActivity.this, cls));
            }
        }, MAIN_CLICK);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall2).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}
