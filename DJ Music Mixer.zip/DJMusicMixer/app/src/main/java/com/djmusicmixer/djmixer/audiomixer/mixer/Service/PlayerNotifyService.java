package com.djmusicmixer.djmixer.audiomixer.mixer.Service;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.view.View;
import android.widget.RemoteViews;

import androidx.core.app.NotificationCompat;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.mixer.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.mixer.MixerActivity;

import java.util.Objects;

public class PlayerNotifyService extends Service {
    public static final String CHANNEL_ID = "PlayerServiceChannel";
    private NotificationCompat.Builder builder;
    private RemoteViews custom_view;
    protected String music_nameA;
    protected String music_nameB;
    protected Notification notification;
    private NotificationManager notificationManager;

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        super.onCreate();
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        if (Objects.equals(intent.getStringExtra("start_service"), "start")) {
            displayNotification(true);
            return Service.START_NOT_STICKY;
        } else if (Objects.equals(intent.getStringExtra("update_service"), "update")) {
            displayNotification(false);
            return Service.START_NOT_STICKY;
        } else if (Objects.equals(intent.getAction(), "play_pauseA")) {
            if (MixerActivity.disk_player[0].isPlaying()) {
                MixerActivity.disk_player[0].pause();
                MixerActivity.iv_play_musicA.setImageResource(R.drawable.ic_mic_play);
                displayNotification(false);
                MixerActivity.vumeterA.pause();
                BaseActivity.stopHandleAnimation(MixerActivity.iv_handle1);
                MixerActivity.rotate_diskA.cancel();
                return Service.START_NOT_STICKY;
            }
            MixerActivity.disk_player[0].start();
            MixerActivity.iv_play_musicA.setImageResource(R.drawable.ic_mic_pause);
            displayNotification(false);
            MixerActivity.vumeterA.resume(true);
            BaseActivity.startHandleAnimation(MixerActivity.iv_handle1);
            MixerActivity.rl_diskA.startAnimation(MixerActivity.rotate_diskA);
            return Service.START_NOT_STICKY;
        } else if (!Objects.equals(intent.getAction(), "play_pauseB")) {
            return Service.START_NOT_STICKY;
        } else {
            if (MixerActivity.disk_player[1].isPlaying()) {
                MixerActivity.disk_player[1].pause();
                MixerActivity.iv_play_musicB.setImageResource(R.drawable.ic_mic_play);
                displayNotification(false);
                MixerActivity.vumeterB.pause();
                BaseActivity.stopHandleAnimation(MixerActivity.iv_handle2);
                MixerActivity.rotate_diskB.cancel();
                return Service.START_NOT_STICKY;
            }
            MixerActivity.disk_player[1].start();
            MixerActivity.iv_play_musicB.setImageResource(R.drawable.ic_mic_pause);
            displayNotification(false);
            MixerActivity.vumeterB.resume(true);
            BaseActivity.startHandleAnimation(MixerActivity.iv_handle2);
            MixerActivity.rl_diskB.startAnimation(MixerActivity.rotate_diskB);
            return Service.START_NOT_STICKY;
        }
    }

    @SuppressLint("WrongConstant")
    private void displayNotification(boolean z) {
        PendingIntent pendingIntent;
        this.music_nameA = MixerActivity.tv_musicA.getText().toString();
        this.music_nameB = MixerActivity.tv_musicB.getText().toString();
        if (z) {
            createNotifyChannel();
            this.custom_view = new RemoteViews(getPackageName(), (int) R.layout.custom_notify_view);
            this.builder = new NotificationCompat.Builder(this, CHANNEL_ID);
            if (Build.VERSION.SDK_INT >= 23) {
                pendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, MixerActivity.class), 201326592);
            } else {
                pendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, MixerActivity.class), PendingIntent.FLAG_UPDATE_CURRENT);
            }
            if (Build.VERSION.SDK_INT >= 29 || Build.MANUFACTURER.equals("Xiaomi")) {
                this.custom_view.setViewVisibility(R.id.rl_icon, View.VISIBLE);
            }
            notifyAction();
            this.builder.setContentTitle(getResources().getString(R.string.app_name)).setSmallIcon(R.mipmap.ic_launcher).setContentIntent(pendingIntent).setCustomContentView(this.custom_view).setCustomBigContentView(this.custom_view).setPriority(2).setNotificationSilent().setDefaults(2);
            Notification build = this.builder.build();
            this.notification = build;
            startForeground(1, build);
            return;
        }
        notifyAction();
        Notification build2 = this.builder.build();
        this.notification = build2;
        startForeground(1, build2);
    }

    @SuppressLint("WrongConstant")
    private void notifyAction() {
        PendingIntent pendingIntent;
        PendingIntent pendingIntent2;
        Intent intent = new Intent(this, PlayerNotifyService.class);
        intent.setAction("play_pauseA");
        if (Build.VERSION.SDK_INT >= 23) {
            pendingIntent = PendingIntent.getService(this, 0, intent, 201326592);
        } else {
            pendingIntent = PendingIntent.getService(this, 0, intent, 134217728);
        }
        Intent intent2 = new Intent(this, PlayerNotifyService.class);
        intent2.setAction("play_pauseB");
        if (Build.VERSION.SDK_INT >= 23) {
            pendingIntent2 = PendingIntent.getService(this, 0, intent2, 201326592);
        } else {
            pendingIntent2 = PendingIntent.getService(this, 0, intent2, PendingIntent.FLAG_UPDATE_CURRENT);
        }
        this.custom_view.setOnClickPendingIntent(R.id.iv_play_pause1, pendingIntent);
        this.custom_view.setOnClickPendingIntent(R.id.iv_play_pause2, pendingIntent2);
        this.custom_view.setTextViewText(R.id.tv_song1, this.music_nameA);
        this.custom_view.setTextViewText(R.id.tv_song2, this.music_nameB);
        if (MixerActivity.disk_player[0] == null || !MixerActivity.disk_player[0].isPlaying()) {
            this.custom_view.setImageViewResource(R.id.iv_play_pause1, R.drawable.ic_nic_play);
        } else {
            this.custom_view.setImageViewResource(R.id.iv_play_pause1, R.drawable.ic_nic_pause);
        }
        if (MixerActivity.disk_player[1] == null || !MixerActivity.disk_player[1].isPlaying()) {
            this.custom_view.setImageViewResource(R.id.iv_play_pause2, R.drawable.ic_nic_play);
        } else {
            this.custom_view.setImageViewResource(R.id.iv_play_pause2, R.drawable.ic_nic_pause);
        }
    }

    private void createNotifyChannel() {
        if (this.notificationManager == null) {
            this.notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        }
        if (Build.VERSION.SDK_INT >= 26 && this.notificationManager.getNotificationChannel(CHANNEL_ID) == null) {
            this.notificationManager.createNotificationChannel(new NotificationChannel(CHANNEL_ID, "DJ Music Mixer", NotificationManager.IMPORTANCE_HIGH));
        }
    }

    public void onDestroy() {
        super.onDestroy();
    }
}
