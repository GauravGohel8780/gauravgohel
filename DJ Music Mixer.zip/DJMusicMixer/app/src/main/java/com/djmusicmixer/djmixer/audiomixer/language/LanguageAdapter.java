package com.djmusicmixer.djmixer.audiomixer.language;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;

import com.djmusicmixer.djmixer.audiomixer.R;

import java.util.List;

public class LanguageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context context;
    private IClickLanguage iClickLanguage;
    private List<LanguageModel> lists;

    public LanguageAdapter(Context context2, List<LanguageModel> list, IClickLanguage iClickLanguage2) {
        this.context = context2;
        this.lists = list;
        this.iClickLanguage = iClickLanguage2;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new LanguageViewHolder(LayoutInflater.from(this.context).inflate(R.layout.item_language, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        LanguageModel languageModel = this.lists.get(i);
        if (viewHolder instanceof LanguageViewHolder) {
            LanguageViewHolder languageViewHolder = (LanguageViewHolder) viewHolder;
            languageViewHolder.bind(languageModel);
            languageViewHolder.relayLanguage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    iClickLanguage.onClick(languageModel);
                }
            });
            if (languageModel.isCheck()) {
                languageViewHolder.relayLanguage.setBackgroundResource(R.drawable.bg_gradiant_boder);
            } else {
                languageViewHolder.relayLanguage.setBackgroundResource(R.drawable.bg_language_false);
            }
        }
    }
    @Override
    public int getItemCount() {
        List<LanguageModel> list = this.lists;
        if (list == null) {
            return 0;
        }
        return list.size();
    }

    public class LanguageViewHolder extends RecyclerView.ViewHolder {
        ImageView ivAvatar;
        View relayLanguage;

        public LanguageViewHolder(View view) {
            super(view);
            this.ivAvatar = (ImageView) view.findViewById(R.id.img_avatar);
            this.relayLanguage = (View) view.findViewById(R.id.relay_language);
        }

        public void bind(LanguageModel languageModel) {
            this.ivAvatar.setImageDrawable(LanguageAdapter.this.context.getDrawable(languageModel.getImage()));
        }
    }

    public void setSelectLanguage(LanguageModel languageModel) {
        for (LanguageModel languageModel2 : this.lists) {
            if (languageModel2.getLanguageName().equals(languageModel.getLanguageName())) {
                languageModel2.setCheck(true);
            } else {
                languageModel2.setCheck(false);
            }
        }
        notifyDataSetChanged();
    }
}
