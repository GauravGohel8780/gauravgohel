package com.djmusicmixer.djmixer.audiomixer;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.djmusicmixer.djmixer.audiomixer.base.BaseActivity;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class DrumActivity extends BaseActivity {
    ArrayList<String> audioPaths = new ArrayList<>();
    ImageView btn1;
    ImageView btn10;
    ImageView btn11;
    ImageView btn12;
    ImageView btn2;
    ImageView btn3;
    ImageView btn4;
    ImageView btn5;
    ImageView btn6;
    ImageView btn7;
    ImageView btn8;
    ImageView btn9;
    boolean fromAsset;
    boolean isSwitched = false;
    MediaPlayer mediaPlayer;
    String path;
    LinearLayout switch_btn;

    @Override
    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this);
        super.onCreate(bundle);
        getWindow().addFlags(128);
        setContentView(R.layout.activity_drum);

        Intent intent = getIntent();
        boolean booleanExtra = intent.getBooleanExtra("fromAsset", true);
        this.fromAsset = booleanExtra;
        if (booleanExtra) {
            listAssetFiles("");
        } else {
            this.path = intent.getStringExtra("path");
            for (File file : new File(this.path).listFiles()) {
                this.audioPaths.add(file.getAbsolutePath());
            }
        }
        Log.e("size", this.audioPaths.size() + "");
        this.btn1 = (ImageView) findViewById(R.id.btn1);
        this.btn2 = (ImageView) findViewById(R.id.btn2);
        this.btn3 = (ImageView) findViewById(R.id.btn3);
        this.btn4 = (ImageView) findViewById(R.id.btn4);
        this.btn5 = (ImageView) findViewById(R.id.btn5);
        this.btn6 = (ImageView) findViewById(R.id.btn6);
        this.btn7 = (ImageView) findViewById(R.id.btn7);
        this.btn8 = (ImageView) findViewById(R.id.btn8);
        this.btn9 = (ImageView) findViewById(R.id.btn9);
        this.btn10 = (ImageView) findViewById(R.id.btn10);
        this.btn11 = (ImageView) findViewById(R.id.btn11);
        this.btn12 = (ImageView) findViewById(R.id.btn12);
        this.switch_btn = (LinearLayout) findViewById(R.id.switch_btn);

        this.switch_btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(DrumActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        if (DrumActivity.this.isSwitched) {
                            DrumActivity cNX_DrumActivity = DrumActivity.this;
                            cNX_DrumActivity.isSwitched = false;
                            cNX_DrumActivity.btn1.setImageResource(R.drawable.ic_orange_drum_pad);
                            DrumActivity.this.btn2.setImageResource(R.drawable.ic_blue_drum_pad);
                            DrumActivity.this.btn3.setImageResource(R.drawable.ic_green_drum_pad);
                            DrumActivity.this.btn4.setImageResource(R.drawable.ic_green_drum_pad);
                            DrumActivity.this.btn5.setImageResource(R.drawable.ic_yellow_drum_pad);
                            DrumActivity.this.btn6.setImageResource(R.drawable.ic_violet_drum_pad);
                            DrumActivity.this.btn7.setImageResource(R.drawable.ic_violet_drum_pad);
                            DrumActivity.this.btn8.setImageResource(R.drawable.ic_orange_drum_pad);
                            DrumActivity.this.btn9.setImageResource(R.drawable.ic_blue_drum_pad);
                            DrumActivity.this.btn10.setImageResource(R.drawable.ic_green_drum_pad);
                            DrumActivity.this.btn11.setImageResource(R.drawable.ic_yellow_drum_pad);
                            DrumActivity.this.btn12.setImageResource(R.drawable.ic_green_drum_pad);
                            return;
                        }
                        DrumActivity cNX_DrumActivity2 = DrumActivity.this;
                        cNX_DrumActivity2.isSwitched = true;
                        cNX_DrumActivity2.btn1.setImageResource(R.drawable.ic_green_drum_pad);
                        DrumActivity.this.btn2.setImageResource(R.drawable.ic_yellow_drum_pad);
                        DrumActivity.this.btn3.setImageResource(R.drawable.ic_blue_drum_pad);
                        DrumActivity.this.btn4.setImageResource(R.drawable.ic_violet_drum_pad);
                        DrumActivity.this.btn5.setImageResource(R.drawable.ic_green_drum_pad);
                        DrumActivity.this.btn6.setImageResource(R.drawable.ic_orange_drum_pad);
                        DrumActivity.this.btn7.setImageResource(R.drawable.ic_blue_drum_pad);
                        DrumActivity.this.btn8.setImageResource(R.drawable.ic_violet_drum_pad);
                        DrumActivity.this.btn9.setImageResource(R.drawable.ic_green_drum_pad);
                        DrumActivity.this.btn10.setImageResource(R.drawable.ic_green_drum_pad);
                        DrumActivity.this.btn11.setImageResource(R.drawable.ic_blue_drum_pad);
                        DrumActivity.this.btn12.setImageResource(R.drawable.ic_violet_drum_pad);
                    }
                }, MAIN_CLICK);
            }
        });
        this.btn1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumActivity.this.playAudio(1);
            }
        });
        this.btn2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumActivity.this.playAudio(2);
            }
        });
        this.btn3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumActivity.this.playAudio(3);
            }
        });
        this.btn4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumActivity.this.playAudio(4);
            }
        });
        this.btn5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumActivity.this.playAudio(5);
            }
        });
        this.btn6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumActivity.this.playAudio(6);
            }
        });
        this.btn7.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumActivity.this.playAudio(7);
            }
        });
        this.btn8.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumActivity.this.playAudio(8);
            }
        });
        this.btn9.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumActivity.this.playAudio(9);
            }
        });
        this.btn10.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumActivity.this.playAudio(10);
            }
        });
        this.btn11.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumActivity.this.playAudio(11);
            }
        });
        this.btn12.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DrumActivity.this.playAudio(12);
            }
        });
        ((ImageView) findViewById(R.id.back)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                getInstance(DrumActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        DrumActivity.this.onBackPressed();
                    }
                }, MAIN_CLICK);
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    public void playAudio(int i) {
        try {
            if (this.isSwitched) {
                i += 12;
            }
            String str = this.audioPaths.get(i - 1);
            MediaPlayer mediaPlayer2 = new MediaPlayer();
            this.mediaPlayer = mediaPlayer2;
            if (this.fromAsset) {
                AssetFileDescriptor openFd = getAssets().openFd(str);
                this.mediaPlayer.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                openFd.close();
            } else {
                mediaPlayer2.setDataSource(str);
            }
            this.mediaPlayer.prepare();
            this.mediaPlayer.start();
            this.mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                public void onCompletion(MediaPlayer mediaPlayer) {
                    mediaPlayer.release();
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean listAssetFiles(String str) {
        try {
            String[] list = getAssets().list(str);
            if (list.length <= 0) {
                return true;
            }
            for (String str2 : list) {
                if (!listAssetFiles(str + "/" + str2)) {
                    return false;
                }
                if (str2.endsWith("wav")) {
                    this.audioPaths.add(str2);
                }
            }
            return true;
        } catch (IOException unused) {
            return false;
        }
    }
}
