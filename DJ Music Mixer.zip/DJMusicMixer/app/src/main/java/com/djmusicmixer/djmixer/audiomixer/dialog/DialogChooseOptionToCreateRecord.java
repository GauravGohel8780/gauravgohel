package com.djmusicmixer.djmixer.audiomixer.dialog;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.language.SystemUtils;

public class DialogChooseOptionToCreateRecord extends Dialog {
    private RelativeLayout beatmaker;
    private Context context;
    private RelativeLayout djmixer;
    private RelativeLayout drumpad;
    private IOnClickDialogChooseOptionToCreateRecord iOnClickDialogChooseOptionToCreateRecord;
    private TextView tvNegative;
    private TextView tvPositive;

    public interface IOnClickDialogChooseOptionToCreateRecord {
        void onClickBeatMaker();

        void onClickDJMixer();

        void onClickPlayInstrument();

        void onClickPositive();
    }

    public DialogChooseOptionToCreateRecord(Context context2, IOnClickDialogChooseOptionToCreateRecord iOnClickDialogChooseOptionToCreateRecord2) {
        super(context2, R.style.BaseDialog);
        this.context = context2;
        this.iOnClickDialogChooseOptionToCreateRecord = iOnClickDialogChooseOptionToCreateRecord2;
    }

    public void onCreate(Bundle bundle) {
        SystemUtils.setLocale(this.context);
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(R.layout.dialog_choose_option_create_record);
        setCancelable(true);
        this.tvPositive = (TextView) findViewById(R.id.tv_positive);
        this.tvNegative = (TextView) findViewById(R.id.tv_negative);
        this.djmixer = (RelativeLayout) findViewById(R.id.djmixer);
        this.beatmaker = (RelativeLayout) findViewById(R.id.beatmaker);
        this.drumpad = (RelativeLayout) findViewById(R.id.drumpad);
        this.tvPositive.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DialogChooseOptionToCreateRecord.this.iOnClickDialogChooseOptionToCreateRecord.onClickPositive();
            }
        });
        this.tvNegative.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DialogChooseOptionToCreateRecord.this.dismiss();
            }
        });
        this.djmixer.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DialogChooseOptionToCreateRecord.this.iOnClickDialogChooseOptionToCreateRecord.onClickDJMixer();
            }
        });
        this.beatmaker.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DialogChooseOptionToCreateRecord.this.iOnClickDialogChooseOptionToCreateRecord.onClickBeatMaker();
            }
        });
        this.drumpad.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DialogChooseOptionToCreateRecord.this.iOnClickDialogChooseOptionToCreateRecord.onClickPlayInstrument();
            }
        });
    }
}
