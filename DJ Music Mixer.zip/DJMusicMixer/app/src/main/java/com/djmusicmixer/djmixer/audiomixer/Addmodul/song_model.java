package com.djmusicmixer.djmixer.audiomixer.Addmodul;

public class song_model {
    public String f345a;
    public String f346b;
    public String f347c;
}
