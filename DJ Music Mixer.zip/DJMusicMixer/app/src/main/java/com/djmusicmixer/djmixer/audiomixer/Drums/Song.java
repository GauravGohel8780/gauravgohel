package com.djmusicmixer.djmixer.audiomixer.Drums;

public class Song {
    public String artist;
    public String data;
    public String title;
}
