package com.djmusicmixer.djmixer.audiomixer.mixer.Adapter;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.djmusicmixer.djmixer.audiomixer.mixer.Fragment.LibGenresFragment;
import com.djmusicmixer.djmixer.audiomixer.mixer.Fragment.LibSongsFragment;

public class MusicLibraryPagerAdapter extends FragmentPagerAdapter {
    private int tabCount;

    public MusicLibraryPagerAdapter(FragmentManager fragmentManager, int i) {
        super(fragmentManager);
        this.tabCount = i;
    }

    @Override
    public Fragment getItem(int i) {
        if (i == 0) {
            return new LibSongsFragment();
        }
        return new LibGenresFragment();
    }

    @Override
    public int getCount() {
        return this.tabCount;
    }
}
