package com.djmusicmixer.djmixer.audiomixer.language;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SystemUtils {
    public static boolean checkAppOpen = false;
    private static Locale myLocale;

    public static boolean haveNetworkConnection(Context context) {
        NetworkInfo[] allNetworkInfo = ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE)).getAllNetworkInfo();
        boolean z = false;
        boolean z2 = false;
        for (NetworkInfo networkInfo : allNetworkInfo) {
            if (networkInfo.getTypeName().equalsIgnoreCase("WIFI") && networkInfo.isConnected()) {
                z = true;
            }
            if (networkInfo.getTypeName().equalsIgnoreCase("MOBILE") && networkInfo.isConnected()) {
                z2 = true;
            }
        }
        if (z || z2) {
            return true;
        }
        return false;
    }

    public static void setLocale(Context context) {
        String preLanguage = getPreLanguage(context);
        if (preLanguage.equals("")) {
            Configuration configuration = new Configuration();
            Locale locale = Locale.getDefault();
            Locale.setDefault(locale);
            configuration.locale = locale;
            context.getResources().updateConfiguration(configuration, context.getResources().getDisplayMetrics());
            return;
        }
        changeLang(preLanguage, context);
    }

    public static void changeLang(String str, Context context) {
        if (!str.equalsIgnoreCase("")) {
            myLocale = new Locale(str);
            saveLocale(context, str);
            Locale.setDefault(myLocale);
            Configuration configuration = new Configuration();
            configuration.locale = myLocale;
            context.getResources().updateConfiguration(configuration, context.getResources().getDisplayMetrics());
        }
    }

    public static void saveLocale(Context context, String str) {
        setPreLanguage(context, str);
    }

    public static String getPreLanguage(Context context) {
        String str;
        SharedPreferences sharedPreferences = context.getSharedPreferences("MY_PRE", Context.MODE_MULTI_PROCESS);
        Locale.getDefault().getDisplayLanguage();
        if (Build.VERSION.SDK_INT >= 24) {
            str = Resources.getSystem().getConfiguration().getLocales().get(0).getLanguage();
        } else {
            str = Resources.getSystem().getConfiguration().locale.getLanguage();
        }
        if (!getLanguageApp().contains(str)) {
            return sharedPreferences.getString("KEY_LANGUAGE", "en");
        }
        return sharedPreferences.getString("KEY_LANGUAGE", str);
    }

    public static void setPreLanguage(Context context, String str) {
        if (str != null && !str.equals("")) {
            context.getSharedPreferences("MY_PRE", Context.MODE_MULTI_PROCESS).edit().putString("KEY_LANGUAGE", str).apply();
        }
    }

    public static List<String> getLanguageApp() {
        ArrayList arrayList = new ArrayList();
        arrayList.add("en");
        arrayList.add("de");
        arrayList.add("fr");
        arrayList.add("pt");
        arrayList.add("es");
        arrayList.add("hi");
        return arrayList;
    }

    public static void setPreIntroOrLanguage(Context context, boolean z) {
        context.getSharedPreferences("MY_PRE", Context.MODE_MULTI_PROCESS).edit().putBoolean("PreIntroOrLanguage", true).apply();
    }

    public static boolean getPreIntroOrLanguage(Context context) {
        return context.getSharedPreferences("MY_PRE", Context.MODE_MULTI_PROCESS).getBoolean("PreIntroOrLanguage", false);
    }
}
