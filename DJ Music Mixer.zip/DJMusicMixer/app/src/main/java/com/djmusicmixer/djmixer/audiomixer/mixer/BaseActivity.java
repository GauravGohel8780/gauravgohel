package com.djmusicmixer.djmixer.audiomixer.mixer;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.afollestad.materialdialogs.MaterialDialog;
import com.djmusicmixer.djmixer.audiomixer.R;
import com.djmusicmixer.djmixer.audiomixer.mixer.Loader.PlaylistLoader;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Playlist;
import com.djmusicmixer.djmixer.audiomixer.mixer.Model.Songs;
import com.djmusicmixer.djmixer.audiomixer.mixer.Utils.PlaylistUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;

public class BaseActivity extends AppCompatActivity {
    public static RotateAnimation rotateAnimation;
    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().getDecorView().setSystemUiVisibility(5638);
    }

    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
        getWindow().getDecorView().setSystemUiVisibility(5638);
    }

    public static void startHandleAnimation(ImageView imageView) {
        RotateAnimation rotateAnimation2 = new RotateAnimation(0.0f, 10.0f, 1, 0.55f, 1, 0.2f);
        rotateAnimation = rotateAnimation2;
        rotateAnimation2.setInterpolator(new LinearInterpolator());
        rotateAnimation.setDuration(2000);
        rotateAnimation.setFillEnabled(true);
        rotateAnimation.setFillAfter(true);
        imageView.startAnimation(rotateAnimation);
    }

    public static void stopHandleAnimation(ImageView imageView) {
        imageView.setAnimation(null);
    }

    public static void addToPlaylistDialog(final Activity activity, final Songs songs) {
        final ArrayList<Playlist> allPlaylists = PlaylistLoader.getAllPlaylists(activity);
        int size = allPlaylists.size() + 1;
        CharSequence[] charSequenceArr = new CharSequence[size];
        charSequenceArr[0] = "New Playlist...";
        for (int i = 1; i < size; i++) {
            charSequenceArr[i] = allPlaylists.get(i - 1).name;
        }
        new MaterialDialog.Builder(activity).backgroundColor(activity.getResources().getColor(R.color.view_line)).titleColor(activity.getResources().getColor(R.color.white)).title("Add to playlist").itemsColor(activity.getResources().getColor(R.color.hint_txt_color)).items(charSequenceArr).itemsCallback(new MaterialDialog.ListCallback() {
            @Override
            public void onSelection(MaterialDialog materialDialog, View view, int i, CharSequence charSequence) {
                if (i == 0) {
                    materialDialog.dismiss();
                    BaseActivity.createPlaylistDialog(activity, songs);
                    return;
                }
                materialDialog.dismiss();
                try {
                    PlaylistUtil.addToPlaylist(activity, new ArrayList(Collections.singleton(songs)), ((Playlist) allPlaylists.get(i - 1)).f188id, true);
                } catch (Throwable th) {
                    th.printStackTrace();
                }
            }
        }).show();
    }

    public static void createPlaylistDialog(final Activity activity, final Songs songs) {
        final Dialog dialog = new Dialog(activity, R.style.DialogTheme2);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.enter_name_dialog);
        Window window = dialog.getWindow();
        Objects.requireNonNull(window);
        window.setBackgroundDrawable(new ColorDrawable(0));
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        final EditText editText = (EditText) dialog.findViewById(R.id.et_name);
        TextView textView = (TextView) dialog.findViewById(R.id.tv_save_rkappzia);
        ((TextView) dialog.findViewById(R.id.tv_title_rkappzia)).setText(activity.getResources().getString(R.string.Create_New_Playlist));
        editText.setHint(activity.getResources().getString(R.string.Playlist_Name));
        textView.setText(activity.getResources().getString(R.string.Create_base));
        textView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String trim = editText.getText().toString().trim();
                if (trim.isEmpty()) {
                    Toast.makeText(activity, activity.getResources().getString(R.string.Enter_Your_Playlist_Name), Toast.LENGTH_SHORT).show();
                } else if (!PlaylistUtil.isPlaylistExist(activity, trim)) {
                    try {
                        PlaylistUtil.addToPlaylist(activity, new ArrayList(Collections.singleton(songs)), PlaylistUtil.createPlaylist(activity, trim), true);
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                    dialog.dismiss();
                }
            }
        });
        ((TextView) dialog.findViewById(R.id.tv_cancel_rkappzia)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}
