package com.djmusicmixer.djmixer.audiomixer.language;

public interface IClickLanguage {
    void onClick(LanguageModel languageModel);
}
