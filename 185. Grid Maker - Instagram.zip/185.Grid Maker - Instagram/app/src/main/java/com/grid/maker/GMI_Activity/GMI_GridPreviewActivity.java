package com.grid.maker.GMI_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.grid.maker.Ads_Common.AdsBaseActivity;
import com.grid.maker.MainActivity;
import com.grid.maker.R;
import com.grid.maker.GMI_adapter.GMI_PreviewAdapter;
import com.grid.maker.GMI_Utils.GMI_ClickListener;
import com.grid.maker.GMI_Utils.GMI_Constant;
import com.grid.maker.GMI_Utils.GMI_RVGridSpacing;
import com.iten.tenoku.ad.AdShow;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;


import java.util.ArrayList;
import java.util.List;

public class GMI_GridPreviewActivity extends AdsBaseActivity {
    private String from;
    private ImageView ivBack;
    private Context mContext;
    private GMI_PreviewAdapter previewAdapter;
    private RelativeLayout relativeTop;
    private RecyclerView rvPreview;
    private List<String> pathList = new ArrayList();

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.gmi_activity_grid_preview);
        this.mContext = this;
        this.from = getIntent().getStringExtra("from");
        ui();
        myClickListener();
        List<String> list = GMI_Constant.pathList;
        this.pathList = list;
        previewAdapter = new GMI_PreviewAdapter(this.mContext, list, new GMI_ClickListener() {
            @Override
            public void onItemClick(int i) {
                getInstance(GMI_GridPreviewActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Uri.parse((String) GMI_GridPreviewActivity.this.pathList.get(i));
                        Intent intent = new Intent(GMI_GridPreviewActivity.this.mContext, GMI_SharePreviewActivity.class);
                        intent.putExtra("path", (String) GMI_GridPreviewActivity.this.pathList.get(i));
                        GMI_GridPreviewActivity.this.startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });
        this.rvPreview.setAdapter(previewAdapter);
    }

    private void myClickListener() {
        this.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(GMI_GridPreviewActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        GMI_GridPreviewActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
    }

    private void ui() {
        this.relativeTop = (RelativeLayout) findViewById(R.id.rlTop);
        this.ivBack = (ImageView) findViewById(R.id.ivBack);
        this.rvPreview = (RecyclerView) findViewById(R.id.rvPreview);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this.mContext, 3);
        GMI_RVGridSpacing aSHA_GRID_CUT_RVGridSpacing = new GMI_RVGridSpacing(3, 7, false);
        this.rvPreview.setLayoutManager(gridLayoutManager);
        this.rvPreview.addItemDecoration(aSHA_GRID_CUT_RVGridSpacing);
    }

    @Override
    public void onBackPressed() {
        if (this.from.equalsIgnoreCase("creation")) {
            super.onBackPressed();
            return;
        }
        Intent intent = new Intent(this.mContext, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        AdShow.getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}
