package com.grid.maker.GMI_Sqlite;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;

import java.util.ArrayList;

public class GMI_DatabaseHelper extends GMI_SQLiteAssetHelper {
    private static final String DATABASE_NAME = "GridMaker.db";
    private static String COLUMN_MATRIX = "matrix";
    private static String COLUMN_ROW = "number_of_row";
    private static String TABLE_NAME = "color_template";

    public GMI_DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }
    @SuppressLint("Range")
    public ArrayList<Grid> getGrids() {
        ArrayList<Grid> arrayList = new ArrayList<>();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        SQLiteQueryBuilder sQLiteQueryBuilder = new SQLiteQueryBuilder();
        String[] strArr = {COLUMN_ROW, COLUMN_MATRIX};
        sQLiteQueryBuilder.setTables(TABLE_NAME);
        Cursor query = sQLiteQueryBuilder.query(readableDatabase, strArr, null, null, null, null, null);
        while (query.moveToNext()) {
             int i = query.getInt(query.getColumnIndex(COLUMN_ROW));
            String string = query.getString(query.getColumnIndex(COLUMN_MATRIX));
            Grid grid = new Grid();
            grid.setRow(i);
            grid.setMatrix(string);
            arrayList.add(grid);
        }
        query.close();
        return arrayList;
    }

    
    public static class Grid {
        public String matrix;
        public int row;

        public Grid(int i, String str) {
            this.row = i;
            this.matrix = str;
        }

        public Grid() {
        }

        public int getRow() {
            return this.row;
        }

        public void setRow(int i) {
            this.row = i;
        }

        public String getMatrix() {
            return this.matrix;
        }

        public void setMatrix(String str) {
            this.matrix = str;
        }
    }
}
