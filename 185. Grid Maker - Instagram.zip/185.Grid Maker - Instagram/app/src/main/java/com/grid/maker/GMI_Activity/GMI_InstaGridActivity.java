package com.grid.maker.GMI_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.grid.maker.Ads_Common.AdsBaseActivity;
import com.grid.maker.MainActivity;
import com.grid.maker.R;
import com.grid.maker.GMI_adapter.GMI_ArtAdapter;
import com.grid.maker.GMI_adapter.GMI_ColorAdapter;
import com.grid.maker.GMI_adapter.GMI_GridAdapter;
import com.grid.maker.GMI_Utils.GMI_AppHelper;
import com.grid.maker.GMI_Utils.GMI_AssetsHelper;
import com.grid.maker.GMI_Utils.GMI_BitmapHelper;
import com.grid.maker.GMI_Utils.GMI_Constant;
import com.grid.maker.GMI_Utils.GMI_DisplayHelper;
import com.grid.maker.GMI_Utils.GMI_GridHelper;

import com.grid.maker.GMI_Sqlite.GMI_DatabaseHelper;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.ortiz.touchview.TouchImageView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;


public class GMI_InstaGridActivity extends AdsBaseActivity {
    private static int box_color = 0;
    private static int box_size = 0;
    private static FrameLayout frameGrid;
    private static FrameLayout frameGrid2;
    private static boolean isGrid = true;
    private static Context mContext;
    private static String matrix;
    private static int row = 0;
    private static int view_width = 9;
    private GMI_ArtAdapter artAdapter;
    private LinearLayout block0, block0Fake, block1, block1Fake, block2, block2Fake, block3, block3Fake, block4, block4Fake, block5, block5Fake, block6, block6Fake, block7, block7Fake, block8, block8Fake;
    private GMI_ColorAdapter colorAdapter;
    private int[] colors;
    private GMI_DatabaseHelper dbHelper;
    private int display_width;
    private GMI_GridAdapter gridAdapter;
    private ImageView ivArt;
    private ImageView ivBack;
    private ImageView ivColor;
    private ImageView ivDone;
    private ImageView ivGrid;
    private ImageView ivOverlay;
    private TouchImageView ivPhoto;
    private LinearLayout linearBottomControl;
    private LinearLayout linearColor;
    private LinearLayout linearMain;
    private ProgressBar progressBar;
    private RelativeLayout relativeBottomControl;
    private RelativeLayout relativeContainer;
    private RelativeLayout relativeTop;
    private LinearLayout row1;
    private LinearLayout row1Fake;
    private LinearLayout row2;
    private LinearLayout row2Fake;
    private LinearLayout row3;
    private LinearLayout row3Fake;
    private RecyclerView rvArt;
    private RecyclerView rvColor;
    private RecyclerView rvInstaGrid;
    private SeekBar sbOpacity;
    private TextView tvTitle;
    private View view_1Fake;
    private View view_2Fake;
    private View view_3Fake;
    private View view_4Fake;
    private View view_5Fake;
    private View view_6Fake;
    private View view_7Fake;
    private View view_8Fake;
    private View view_bottom;
    private View view_top;
    private ArrayList<String> arts = new ArrayList<>();
    private ArrayList<String> arts_big = new ArrayList<>();
    private int grid_position = 0;
    private ArrayList<GMI_DatabaseHelper.Grid> grids = new ArrayList<>();

    public enum CLICK_TYPE {
        GRID, ART, COLOR
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.gmi_activity_insta_grid);
        mContext = this;
        this.dbHelper = new GMI_DatabaseHelper(mContext);
        this.display_width = GMI_DisplayHelper.getDisplayWidth(mContext);
        GMI_GridHelper.SCALE_WIDTH = GMI_DisplayHelper.getDisplayWidth(mContext);
        GMI_GridHelper.SCALE_HEIGHT = GMI_DisplayHelper.getDisplayHeight(mContext);
        ui();
        myClickListener();
        setImageData(getIntent());
        this.arts = GMI_AssetsHelper.listOfFiles(mContext, "artwork/small");
        this.arts_big = GMI_AssetsHelper.listOfFiles(mContext, "artwork/big");
        TypedArray obtainTypedArray = mContext.getResources().obtainTypedArray(R.array.colors);
        this.colors = new int[obtainTypedArray.length()];
        for (int i = 0; i < obtainTypedArray.length(); i++) {
            this.colors[i] = obtainTypedArray.getColor(i, 0);
        }
        obtainTypedArray.recycle();
        box_color = this.colors[21];
        this.grids = this.dbHelper.getGrids();
        setupGrid(this.grid_position);
        setBlockAlpha(135);
        setUpRV(CLICK_TYPE.GRID);
        setApter();
        this.sbOpacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int i2, boolean z) {
                if (GMI_InstaGridActivity.isGrid) {
                    GMI_InstaGridActivity.this.setBlockAlpha(i2);
                } else {
                    GMI_InstaGridActivity.this.ivOverlay.setAlpha(i2 / 255.0f);
                }
            }
        });
    }

    private void setApter() {
        GMI_GridAdapter gridAdapter = new GMI_GridAdapter(mContext, this.grids, new GMI_GridAdapter.OnItemClick() {
            @Override
            public void itemClick(int i) {
                GMI_InstaGridActivity.this.ivOverlay.setImageBitmap(null);
                GMI_InstaGridActivity.this.grid_position = i;
                GMI_InstaGridActivity instaGridActivity = GMI_InstaGridActivity.this;
                instaGridActivity.setupGrid(instaGridActivity.grid_position);
            }
        });
        this.gridAdapter = gridAdapter;
        this.rvInstaGrid.setAdapter(gridAdapter);
        artAdapter = new GMI_ArtAdapter(mContext, this.arts, new GMI_ArtAdapter.OnItemClick() {
            @Override
            public void itemClick(int i) {
                String str = (String) GMI_InstaGridActivity.this.arts_big.get(i);
                GMI_InstaGridActivity.this.setupArtGrid(i, str);
                GMI_InstaGridActivity.this.ivOverlay.setImageBitmap(GMI_AssetsHelper.getBitmap(GMI_InstaGridActivity.mContext, str));
            }
        });
        this.rvArt.setAdapter(artAdapter);
        colorAdapter = new GMI_ColorAdapter(mContext, this.colors, new GMI_ColorAdapter.OnItemClick() {
            @Override
            public void itemClick(int i) {
                if (GMI_InstaGridActivity.isGrid) {
                    int unused = GMI_InstaGridActivity.box_color = GMI_InstaGridActivity.this.colors[i];
                    GMI_InstaGridActivity.this.setBoxColor(GMI_InstaGridActivity.matrix);
                } else {
                    GMI_InstaGridActivity.this.ivOverlay.setColorFilter(GMI_InstaGridActivity.this.colors[i], PorterDuff.Mode.MULTIPLY);
                }
                GMI_InstaGridActivity.this.sbOpacity.setProgress(135);
                if (GMI_InstaGridActivity.isGrid) {
                    GMI_InstaGridActivity.this.setBlockAlpha(135);
                } else {
                    GMI_InstaGridActivity.this.ivOverlay.setAlpha(0.5294118f);
                }
            }
        });
        this.rvColor.setAdapter(colorAdapter);
    }

    public void setBlockAlpha(int i) {


    }

    private void myClickListener() {
        this.ivGrid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(GMI_InstaGridActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        boolean unused = GMI_InstaGridActivity.isGrid = true;
                        GMI_InstaGridActivity.this.setUpRV(CLICK_TYPE.GRID);
                    }
                }, MAIN_CLICK);
            }
        });
        this.ivArt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(GMI_InstaGridActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        boolean unused = GMI_InstaGridActivity.isGrid = false;
                        GMI_InstaGridActivity.this.setUpRV(CLICK_TYPE.ART);
                    }
                }, MAIN_CLICK);
            }
        });
        this.ivColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(GMI_InstaGridActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        GMI_InstaGridActivity.this.setUpRV(CLICK_TYPE.COLOR);
                    }
                }, MAIN_CLICK);
            }
        });
        this.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(GMI_InstaGridActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        GMI_InstaGridActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        this.ivDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(GMI_InstaGridActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        GMI_InstaGridActivity.this.progressBar.setVisibility(View.VISIBLE);
                        new SaveTask(new SaveTask.onCompleted() {
                            @Override
                            public void onSaved(List<Bitmap> list) {
                                GMI_InstaGridActivity.this.progressBar.setVisibility(View.GONE);
                                GMI_Constant.bitmapLis = list;
                                Toast.makeText(GMI_InstaGridActivity.mContext, "Image Saved Successfully..", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(GMI_InstaGridActivity.mContext, GMI_GridPreviewActivity.class);
                                intent.putExtra("from", "editing");
                                GMI_InstaGridActivity.this.startActivity(intent);
                            }
                        }).execute(new Void[0]);
                    }
                }, MAIN_CLICK);
            }
        });
    }

    static class AnonymousClass10 {
        static final int[] a;

        static {
            int[] iArr = new int[CLICK_TYPE.values().length];
            a = iArr;
            try {
                iArr[CLICK_TYPE.ART.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                a[CLICK_TYPE.GRID.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                a[CLICK_TYPE.COLOR.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
        }
    }

    public void setUpRV(CLICK_TYPE click_type) {
        switch (AnonymousClass10.a[click_type.ordinal()]) {
            case 1:
                row = 3;
                this.rvArt.setVisibility(View.VISIBLE);
                this.rvInstaGrid.setVisibility(View.GONE);
                this.linearColor.setVisibility(View.GONE);
                this.block0.setVisibility(View.INVISIBLE);
                this.block1.setVisibility(View.INVISIBLE);
                this.block2.setVisibility(View.INVISIBLE);
                this.block3.setVisibility(View.INVISIBLE);
                this.block4.setVisibility(View.INVISIBLE);
                this.block5.setVisibility(View.INVISIBLE);
                this.block6.setVisibility(View.INVISIBLE);
                this.block7.setVisibility(View.INVISIBLE);
                this.block8.setVisibility(View.INVISIBLE);
                this.ivGrid.setSelected(false);
                this.ivArt.setSelected(true);
                this.ivColor.setSelected(false);
                return;
            case 2:
                this.rvInstaGrid.setVisibility(View.VISIBLE);
                this.rvArt.setVisibility(View.GONE);
                this.linearColor.setVisibility(View.GONE);
                this.ivOverlay.setImageBitmap(null);
                setupGrid(this.grid_position);
                this.block0.setVisibility(View.VISIBLE);
                this.block1.setVisibility(View.VISIBLE);
                this.block2.setVisibility(View.VISIBLE);
                this.block3.setVisibility(View.VISIBLE);
                this.block4.setVisibility(View.VISIBLE);
                this.block5.setVisibility(View.VISIBLE);
                this.block6.setVisibility(View.VISIBLE);
                this.block7.setVisibility(View.VISIBLE);
                this.block8.setVisibility(View.VISIBLE);
                this.ivGrid.setSelected(true);
                this.ivArt.setSelected(false);
                this.ivColor.setSelected(false);
                return;
            case 3:
                this.rvInstaGrid.setVisibility(View.GONE);
                this.rvArt.setVisibility(View.GONE);
                this.linearColor.setVisibility(View.VISIBLE);
                this.ivGrid.setSelected(false);
                this.ivArt.setSelected(false);
                this.ivColor.setSelected(true);
                return;
            default:
                return;
        }
    }

    public void setupGrid(int i) {
        GMI_DatabaseHelper.Grid grid = this.grids.get(i);
        int i2 = grid.row;
        row = i2;
        if (i2 == 1) {
            this.row2.setVisibility(View.GONE);
            this.row3.setVisibility(View.GONE);
            this.row2Fake.setVisibility(View.GONE);
            this.row3Fake.setVisibility(View.GONE);
            this.view_3Fake.setVisibility(View.GONE);
            this.view_6Fake.setVisibility(View.GONE);
            GMI_GridHelper.setHeight(mContext, frameGrid, this.view_1Fake.getHeight());
            GMI_GridHelper.setHeight(mContext, frameGrid2, this.view_1Fake.getHeight());
        } else if (i2 == 2) {
            this.row2.setVisibility(View.VISIBLE);
            this.row2Fake.setVisibility(View.VISIBLE);
            this.view_3Fake.setVisibility(View.VISIBLE);
            this.row3.setVisibility(View.GONE);
            this.row3Fake.setVisibility(View.GONE);
            this.view_6Fake.setVisibility(View.GONE);
            GMI_GridHelper.setHeight(mContext, frameGrid, this.view_1Fake.getHeight() * 2);
            GMI_GridHelper.setHeight(mContext, frameGrid2, this.view_1Fake.getHeight() * 2);
        } else {
            this.row2.setVisibility(View.VISIBLE);
            this.row3.setVisibility(View.VISIBLE);
            this.row2Fake.setVisibility(View.VISIBLE);
            this.row3Fake.setVisibility(View.VISIBLE);
            this.view_3Fake.setVisibility(View.VISIBLE);
            this.view_6Fake.setVisibility(View.VISIBLE);
            GMI_GridHelper.setHeight(mContext, frameGrid, this.display_width);
            GMI_GridHelper.setHeight(mContext, frameGrid2, this.display_width);
        }
        this.ivPhoto.setZoom(1.0f);
        this.ivPhoto.animate().alpha(1.0f).setDuration(300L).setInterpolator(new AccelerateInterpolator());
        String matrix2 = grid.getMatrix();
        matrix = matrix2;
        setBoxColor(matrix2);
    }

    public void setupArtGrid(int i, String str) {
        try {
            i = Integer.parseInt(str.substring(18, 20));
        } catch (NumberFormatException e) {
        }
        if (i < 24) {
            row = 3;
        } else if (i < 45) {
            row = 2;
        } else {
            row = 1;
        }
        int i2 = row;
        if (i2 == 1) {
            this.row2.setVisibility(View.GONE);
            this.row3.setVisibility(View.GONE);
            this.row2Fake.setVisibility(View.GONE);
            this.row3Fake.setVisibility(View.GONE);
            this.view_3Fake.setVisibility(View.GONE);
            this.view_6Fake.setVisibility(View.GONE);
            int i22 = this.display_width / 3;
            GMI_GridHelper.setHeight(mContext, frameGrid, i22);
            GMI_GridHelper.setHeight(mContext, frameGrid2, i22);
        } else if (i2 == 2) {
            this.row2.setVisibility(View.VISIBLE);
            this.row2Fake.setVisibility(View.VISIBLE);
            this.view_3Fake.setVisibility(View.VISIBLE);
            this.row3.setVisibility(View.GONE);
            this.row3Fake.setVisibility(View.GONE);
            this.view_6Fake.setVisibility(View.GONE);
            int i3 = (this.display_width / 3) * 2;
            GMI_GridHelper.setHeight(mContext, frameGrid, i3);
            GMI_GridHelper.setHeight(mContext, frameGrid2, i3);
        } else {
            this.row2.setVisibility(View.VISIBLE);
            this.row3.setVisibility(View.VISIBLE);
            this.row2Fake.setVisibility(View.VISIBLE);
            this.row3Fake.setVisibility(View.VISIBLE);
            this.view_3Fake.setVisibility(View.VISIBLE);
            this.view_6Fake.setVisibility(View.VISIBLE);
            GMI_GridHelper.setHeight(mContext, frameGrid, this.display_width);
            GMI_GridHelper.setHeight(mContext, frameGrid2, this.display_width);
        }
        this.ivPhoto.setZoom(1.0f);
        this.ivPhoto.animate().alpha(1.0f).setDuration(300L).setInterpolator(new AccelerateInterpolator());
    }

    public void setBoxColor(String str) {
        String[] split = str.split(",");
        for (int i = 0; i < split.length; i++) {
            switch (i) {
                case 0:
                    if (!split[i].equals("0")) {
                        this.block0.setBackgroundColor(mContext.getResources().getColor(R.color.transparent_black_0));
                        break;
                    } else {
                        this.block0.setBackgroundColor(box_color);
                        break;
                    }
                case 1:
                    if (!split[i].equals("0")) {
                        this.block1.setBackgroundColor(mContext.getResources().getColor(R.color.transparent_black_0));
                        break;
                    } else {
                        this.block1.setBackgroundColor(box_color);
                        break;
                    }
                case 2:
                    if (!split[i].equals("0")) {
                        this.block2.setBackgroundColor(mContext.getResources().getColor(R.color.transparent_black_0));
                        break;
                    } else {
                        this.block2.setBackgroundColor(box_color);
                        break;
                    }
                case 3:
                    if (!split[i].equals("0")) {
                        this.block3.setBackgroundColor(mContext.getResources().getColor(R.color.transparent_black_0));
                        break;
                    } else {
                        this.block3.setBackgroundColor(box_color);
                        break;
                    }
                case 4:
                    if (!split[i].equals("0")) {
                        this.block4.setBackgroundColor(mContext.getResources().getColor(R.color.transparent_black_0));
                        break;
                    } else {
                        this.block4.setBackgroundColor(box_color);
                        break;
                    }
                case 5:
                    if (!split[i].equals("0")) {
                        this.block5.setBackgroundColor(mContext.getResources().getColor(R.color.transparent_black_0));
                        break;
                    } else {
                        this.block5.setBackgroundColor(box_color);
                        break;
                    }
                case 6:
                    if (!split[i].equals("0")) {
                        this.block6.setBackgroundColor(mContext.getResources().getColor(R.color.transparent_black_0));
                        break;
                    } else {
                        this.block6.setBackgroundColor(box_color);
                        break;
                    }
                case 7:
                    if (!split[i].equals("0")) {
                        this.block7.setBackgroundColor(mContext.getResources().getColor(R.color.transparent_black_0));
                        break;
                    } else {
                        this.block7.setBackgroundColor(box_color);
                        break;
                    }
                case 8:
                    if (!split[i].equals("0")) {
                        this.block8.setBackgroundColor(mContext.getResources().getColor(R.color.transparent_black_0));
                        break;
                    } else {
                        this.block8.setBackgroundColor(box_color);
                        break;
                    }
            }
        }
    }


    private void ui() {
        linearMain = (LinearLayout) findViewById(R.id.llMain);
        linearBottomControl = (LinearLayout) findViewById(R.id.llBottomControl);
        relativeTop = (RelativeLayout) findViewById(R.id.rlTop);
        relativeBottomControl = (RelativeLayout) findViewById(R.id.rlBottomControl);
        ivBack = (ImageView) findViewById(R.id.ivBack);
        tvTitle = (TextView) findViewById(R.id.tvTitle);
        ivDone = (ImageView) findViewById(R.id.ivDone);
        relativeContainer = (RelativeLayout) findViewById(R.id.relative_container);
        frameGrid = (FrameLayout) findViewById(R.id.flGrid);
        frameGrid2 = (FrameLayout) findViewById(R.id.flGrid2);
        ivPhoto = (TouchImageView) findViewById(R.id.ivPhoto);
        ivOverlay = (ImageView) findViewById(R.id.ivOverlay);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        row1 = (LinearLayout) findViewById(R.id.llRow1);
        block0 = (LinearLayout) findViewById(R.id.llBlock0);
        block1 = (LinearLayout) findViewById(R.id.llBlock1);
        block2 = (LinearLayout) findViewById(R.id.llBlock2);
        row2 = (LinearLayout) findViewById(R.id.llRow2);
        block3 = (LinearLayout) findViewById(R.id.llBlock3);
        block4 = (LinearLayout) findViewById(R.id.llBlock4);
        block5 = (LinearLayout) findViewById(R.id.llBlock5);
        row3 = (LinearLayout) findViewById(R.id.llRow3);
        block6 = (LinearLayout) findViewById(R.id.llBlock6);
        block7 = (LinearLayout) findViewById(R.id.llBlock7);
        block8 = (LinearLayout) findViewById(R.id.llBlock8);
        row1Fake = (LinearLayout) findViewById(R.id.llRow1Fake);
        block0Fake = (LinearLayout) findViewById(R.id.llBlock0Fake);
        block1Fake = (LinearLayout) findViewById(R.id.llBlock1Fake);
        block2Fake = (LinearLayout) findViewById(R.id.llBlock2Fake);
        row2Fake = (LinearLayout) findViewById(R.id.llRow2Fake);
        block3Fake = (LinearLayout) findViewById(R.id.llBlock3Fake);
        block4Fake = (LinearLayout) findViewById(R.id.llBlock4Fake);
        block5Fake = (LinearLayout) findViewById(R.id.llBlock5Fake);
        row3Fake = (LinearLayout) findViewById(R.id.llRow3Fake);
        block6Fake = (LinearLayout) findViewById(R.id.llBlock6Fake);
        block7Fake = (LinearLayout) findViewById(R.id.llBlock7Fake);
        block8Fake = (LinearLayout) findViewById(R.id.llBlock8Fake);
        rvInstaGrid = (RecyclerView) findViewById(R.id.rvInstaGrid);
        rvArt = (RecyclerView) findViewById(R.id.rvArt);
        ivGrid = (ImageView) findViewById(R.id.ivGrid);
        ivArt = (ImageView) findViewById(R.id.ivArt);
        ivColor = (ImageView) findViewById(R.id.ivColor);
        view_1Fake = findViewById(R.id.v1Fake);
        view_2Fake = findViewById(R.id.v2Fake);
        view_3Fake = findViewById(R.id.v3Fake);
        view_4Fake = findViewById(R.id.v4Fake);
        view_5Fake = findViewById(R.id.v5Fake);
        view_6Fake = findViewById(R.id.v6Fake);
        view_7Fake = findViewById(R.id.v7Fake);
        view_8Fake = findViewById(R.id.v8Fake);
        view_top = findViewById(R.id.vTop);
        view_bottom = findViewById(R.id.vBottom);
        linearColor = (LinearLayout) findViewById(R.id.llColor);
        sbOpacity = (SeekBar) findViewById(R.id.sbOpacity);
        rvColor = (RecyclerView) findViewById(R.id.rvColor);
        rvInstaGrid.setLayoutManager(new LinearLayoutManager(mContext, RecyclerView.HORIZONTAL, false));
        rvArt.setLayoutManager(new LinearLayoutManager(mContext, RecyclerView.HORIZONTAL, false));
        rvColor.setLayoutManager(new LinearLayoutManager(mContext, RecyclerView.HORIZONTAL, false));
        Log.d("WIDTH", this.display_width + "");
        box_size = this.display_width / 3;
        Log.d("BOX_SIZE", box_size + "");
        Context context = mContext;
        LinearLayout linearLayout = this.block0;
        int i = box_size;
        GMI_GridHelper.setHeightWidth(context, linearLayout, i, i);
        Context context2 = mContext;
        LinearLayout linearLayout2 = this.block1;
        int i2 = box_size;
        GMI_GridHelper.setHeightWidth(context2, linearLayout2, i2, i2);
        Context context3 = mContext;
        LinearLayout linearLayout3 = this.block2;
        int i3 = box_size;
        GMI_GridHelper.setHeightWidth(context3, linearLayout3, i3, i3);
        Context context4 = mContext;
        LinearLayout linearLayout4 = this.block3;
        int i4 = box_size;
        GMI_GridHelper.setHeightWidth(context4, linearLayout4, i4, i4);
        Context context5 = mContext;
        LinearLayout linearLayout5 = this.block4;
        int i5 = box_size;
        GMI_GridHelper.setHeightWidth(context5, linearLayout5, i5, i5);
        Context context6 = mContext;
        LinearLayout linearLayout6 = this.block5;
        int i6 = box_size;
        GMI_GridHelper.setHeightWidth(context6, linearLayout6, i6, i6);
        Context context7 = mContext;
        LinearLayout linearLayout7 = this.block6;
        int i7 = box_size;
        GMI_GridHelper.setHeightWidth(context7, linearLayout7, i7, i7);
        Context context8 = mContext;
        LinearLayout linearLayout8 = this.block7;
        int i8 = box_size;
        GMI_GridHelper.setHeightWidth(context8, linearLayout8, i8, i8);
        Context context9 = mContext;
        LinearLayout linearLayout9 = this.block8;
        int i9 = box_size;
        GMI_GridHelper.setHeightWidth(context9, linearLayout9, i9, i9);
        GMI_GridHelper.setHeight(mContext, this.row1, box_size);
        GMI_GridHelper.setHeight(mContext, this.row2, box_size);
        GMI_GridHelper.setHeight(mContext, this.row3, box_size);
        Log.d("BOX_SIZE_FAKE", box_size + "");
        int i10 = (this.display_width / 3) + (-6);
        box_size = i10;
        GMI_GridHelper.setHeightWidth(mContext, this.block0Fake, i10, i10);
        Context context10 = mContext;
        LinearLayout linearLayout10 = this.block1Fake;
        int i11 = box_size;
        GMI_GridHelper.setHeightWidth(context10, linearLayout10, i11, i11);
        Context context11 = mContext;
        LinearLayout linearLayout11 = this.block2Fake;
        int i12 = box_size;
        GMI_GridHelper.setHeightWidth(context11, linearLayout11, i12, i12);
        Context context12 = mContext;
        LinearLayout linearLayout12 = this.block3Fake;
        int i13 = box_size;
        GMI_GridHelper.setHeightWidth(context12, linearLayout12, i13, i13);
        Context context13 = mContext;
        LinearLayout linearLayout13 = this.block4Fake;
        int i14 = box_size;
        GMI_GridHelper.setHeightWidth(context13, linearLayout13, i14, i14);
        Context context14 = mContext;
        LinearLayout linearLayout14 = this.block5Fake;
        int i15 = box_size;
        GMI_GridHelper.setHeightWidth(context14, linearLayout14, i15, i15);
        Context context15 = mContext;
        LinearLayout linearLayout15 = this.block6Fake;
        int i16 = box_size;
        GMI_GridHelper.setHeightWidth(context15, linearLayout15, i16, i16);
        Context context16 = mContext;
        LinearLayout linearLayout16 = this.block7Fake;
        int i17 = box_size;
        GMI_GridHelper.setHeightWidth(context16, linearLayout16, i17, i17);
        Context context17 = mContext;
        LinearLayout linearLayout17 = this.block8Fake;
        int i18 = box_size;
        GMI_GridHelper.setHeightWidth(context17, linearLayout17, i18, i18);
        GMI_GridHelper.setHeight(mContext, this.row1Fake, box_size);
        GMI_GridHelper.setHeight(mContext, this.row2Fake, box_size);
        GMI_GridHelper.setHeight(mContext, this.row3Fake, box_size);
        GMI_GridHelper.setHeight(mContext, this.view_1Fake, box_size);
        GMI_GridHelper.setHeight(mContext, this.view_2Fake, box_size);
        GMI_GridHelper.setHeight(mContext, this.view_4Fake, box_size);
        GMI_GridHelper.setHeight(mContext, this.view_5Fake, box_size);
        GMI_GridHelper.setHeight(mContext, this.view_7Fake, box_size);
        GMI_GridHelper.setHeight(mContext, this.view_8Fake, box_size);
        GMI_GridHelper.setWidth(mContext, this.view_3Fake, this.display_width);
        GMI_GridHelper.setWidth(mContext, this.view_6Fake, this.display_width);
        GMI_GridHelper.setWidth(mContext, this.view_1Fake, view_width);
        GMI_GridHelper.setWidth(mContext, this.view_2Fake, view_width);
        GMI_GridHelper.setHeight(mContext, this.view_3Fake, view_width);
        GMI_GridHelper.setWidth(mContext, this.view_4Fake, view_width);
        GMI_GridHelper.setWidth(mContext, this.view_5Fake, view_width);
        GMI_GridHelper.setHeight(mContext, this.view_6Fake, view_width);
        GMI_GridHelper.setWidth(mContext, this.view_7Fake, view_width);
        GMI_GridHelper.setWidth(mContext, this.view_8Fake, view_width);
    }

    private void setImageData(@NonNull Intent intent) {
        Uri uri = (Uri) intent.getParcelableExtra("imageUri");
        GMI_BitmapHelper.getBitmap(mContext, uri);
        if (uri != null) {
            this.ivPhoto.setImageURI(uri);
            this.ivPhoto.setMaxZoom(4.0f);
            GMI_GridHelper.setHeight(mContext, frameGrid, this.display_width);
            GMI_GridHelper.setHeight(mContext, frameGrid2, this.display_width);
        }
    }

    private static class SaveTask extends AsyncTask<Void, Void, Void> {
        Bitmap a;
        onCompleted c;
        List<Bitmap> b = new ArrayList();
        List<String> d = new ArrayList();
        String e = new SimpleDateFormat("ddMMyyyy_HHmmss", Locale.getDefault()).format(new Date());

        public interface onCompleted {
            void onSaved(List<Bitmap> list);
        }

        @Override
        public void onPreExecute() {
            super.onPreExecute();
        }

        public SaveTask(onCompleted oncompleted) {
            this.c = oncompleted;
        }

        @Override
        public Void doInBackground(Void... voidArr) {
            Bitmap bitmap = GMI_BitmapHelper.getBitmap(GMI_InstaGridActivity.frameGrid);
            this.a = bitmap;
            this.b = GMI_InstaGridActivity.cutImageInFour(bitmap, GMI_InstaGridActivity.row);
            for (int i = 0; i < this.b.size(); i++) {
                String outputPath = GMI_AppHelper.getOutputPath(GMI_InstaGridActivity.mContext);
                List<String> list = this.d;
                list.add(GMI_BitmapHelper.saveImage(GMI_InstaGridActivity.mContext, this.b.get(i), outputPath, this.e + "_" + String.format("%02d", Integer.valueOf(i)) + "_" + this.b.size() + ".jpg"));
            }
            return null;
        }

        @Override
        public void onPostExecute(Void r2) {
            super.onPostExecute(r2);
            this.c.onSaved(this.b);
            GMI_Constant.pathList = this.d;
        }
    }

    public static List<Bitmap> cutImageInFour(Bitmap bitmap, int i) {
        ArrayList arrayList = new ArrayList();
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        if (i == 1) {
            int i2 = width / 3;
            arrayList.add(Bitmap.createBitmap(bitmap, 0, 0, i2, height));
            arrayList.add(Bitmap.createBitmap(bitmap, i2, 0, i2, height));
            arrayList.add(Bitmap.createBitmap(bitmap, i2 * 2, 0, i2, height));
        } else if (i == 2) {
            int i3 = width / 3;
            int i4 = height / 2;
            arrayList.add(Bitmap.createBitmap(bitmap, 0, 0, i3, i4));
            arrayList.add(Bitmap.createBitmap(bitmap, i3, 0, i3, i4));
            int i5 = i3 * 2;
            arrayList.add(Bitmap.createBitmap(bitmap, i5, 0, i3, i4));
            arrayList.add(Bitmap.createBitmap(bitmap, 0, i4, i3, i4));
            arrayList.add(Bitmap.createBitmap(bitmap, i3, i4, i3, i4));
            arrayList.add(Bitmap.createBitmap(bitmap, i5, i4, i3, i4));
        } else if (i == 3) {
            int i6 = width / 3;
            int i7 = height / 3;
            arrayList.add(Bitmap.createBitmap(bitmap, 0, 0, i6, i7));
            arrayList.add(Bitmap.createBitmap(bitmap, i6, 0, i6, i7));
            int i8 = i6 * 2;
            arrayList.add(Bitmap.createBitmap(bitmap, i8, 0, i6, i7));
            arrayList.add(Bitmap.createBitmap(bitmap, 0, i7, i6, i7));
            arrayList.add(Bitmap.createBitmap(bitmap, i6, i7, i6, i7));
            arrayList.add(Bitmap.createBitmap(bitmap, i8, i7, i6, i7));
            int i9 = i7 * 2;
            arrayList.add(Bitmap.createBitmap(bitmap, 0, i9, i6, i7));
            arrayList.add(Bitmap.createBitmap(bitmap, i6, i9, i6, i7));
            arrayList.add(Bitmap.createBitmap(bitmap, i8, i9, i6, i7));
        }
        return arrayList;
    }

}
