package com.grid.maker.Ads_Common;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.iten.tenoku.utils.AdConstant;

public class AdsBaseActivity extends AppCompatActivity {
    @Override
    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
    }

    @Override
    protected void onStart() {
        super.onStart();
        AdConstant.isResume = true;
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }
}
