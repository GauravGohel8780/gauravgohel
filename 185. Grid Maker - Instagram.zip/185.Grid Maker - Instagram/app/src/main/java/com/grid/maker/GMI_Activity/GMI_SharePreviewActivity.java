package com.grid.maker.GMI_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.core.content.FileProvider;

import com.bumptech.glide.Glide;
import com.grid.maker.Ads_Common.AdsBaseActivity;
import com.grid.maker.MainActivity;
import com.grid.maker.R;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;


import java.io.File;

public class GMI_SharePreviewActivity extends AdsBaseActivity {
    private ImageView imgBack;
    private ImageView ivPreview;
    private ImageView ivShare;
    private Context mContext;
    private String path;
    private LinearLayout toolbar;
    private View view_bottom;
    private View view_top;

    @Override 
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.gmi_share_photo_preview);
        this.mContext = this;
        this.path = getIntent().getStringExtra("path");
        ui();
        myCLickListner();
        Glide.with(this.mContext).load(this.path).into(this.ivPreview);

    }

    private void myCLickListner() {
        this.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(GMI_SharePreviewActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        GMI_SharePreviewActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        this.ivShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GMI_SharePreviewActivity.this.share();
            }
        });
    }

    public void share() {
        Uri data = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", new File(this.path));
        grantUriPermission(getPackageName(), data, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        Intent sendIntent = new Intent("android.intent.action.SEND");
        sendIntent.setType("image/*");
        sendIntent.putExtra("android.intent.extra.SUBJECT", "Image");
        sendIntent.putExtra("android.intent.extra.STREAM", data);
        sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        sendIntent.putExtra("android.intent.extra.TEXT", getResources().getString(R.string.app_name));
        startActivity(Intent.createChooser(sendIntent, "Share Image:"));
    }

    private void ui() {
        this.ivPreview = (ImageView) findViewById(R.id.ivPreview);
        this.imgBack = (ImageView) findViewById(R.id.ivBack);
        this.ivShare = (ImageView) findViewById(R.id.ivShareimage);
        this.view_top = findViewById(R.id.vTop);
        this.view_bottom = findViewById(R.id.vBottom);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
