package com.grid.maker.GMI_adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.viewpager.widget.PagerAdapter;

import com.grid.maker.R;
import com.grid.maker.GMI_Activity.GMI_IntroModel;

import java.util.List;

public class GMI_IntroViewPagerAdapter extends PagerAdapter {
    Context mContext;
    List<GMI_IntroModel> mListScreen;

    @Override
    public boolean isViewFromObject(View view, Object obj) {
        return view == obj;
    }

    public GMI_IntroViewPagerAdapter(Context context, List<GMI_IntroModel> list) {
        this.mContext = context;
        this.mListScreen = list;
    }

    @Override
    public Object instantiateItem(ViewGroup viewGroup, int i) {
        View inflate = ((LayoutInflater) this.mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.gmi_intro_lay, (ViewGroup) null);
        ((TextView) inflate.findViewById(R.id.tvIntroTitle)).setText(this.mListScreen.get(i).getTitle());
        ((TextView) inflate.findViewById(R.id.tvIntroDescription)).setText(this.mListScreen.get(i).getDescription());
        ((ImageView) inflate.findViewById(R.id.ivIntroImg)).setImageResource(this.mListScreen.get(i).getScreenImg());
        viewGroup.addView(inflate);
        return inflate;
    }

    @Override
    public int getCount() {
        return this.mListScreen.size();
    }

    @Override
    public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
        viewGroup.removeView((View) obj);
    }
}
