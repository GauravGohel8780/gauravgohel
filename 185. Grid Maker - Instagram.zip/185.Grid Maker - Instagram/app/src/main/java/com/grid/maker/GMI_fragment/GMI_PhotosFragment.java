package com.grid.maker.GMI_fragment;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.grid.maker.MainActivity;
import com.grid.maker.R;
import com.grid.maker.GMI_Activity.GMI_GridPreviewActivity;
import com.grid.maker.GMI_adapter.GMI_PhotoAdapter;
import com.grid.maker.GMI_Utils.GMI_AppHelper;
import com.grid.maker.GMI_Utils.GMI_ClickListener;
import com.grid.maker.GMI_Utils.GMI_Constant;
import com.grid.maker.GMI_Utils.GMI_FileHelper;
import com.grid.maker.GMI_Utils.GMI_RVGridSpacing;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;


public class GMI_PhotosFragment extends Fragment {
    private GMI_PhotoAdapter adapter;
    private RecyclerView mCategory;
    private Context mContext;
    private ArrayList<String> photoList = new ArrayList<>();
    private TextView tvNoGlitch;

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.gmi_fragment_photos, viewGroup, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.mContext = getActivity();
        ui(view);
        new LoadPhotos().execute(new Void[0]);
    }

    private void ui(View view) {
        this.mCategory = (RecyclerView) view.findViewById(R.id.rvPhotos);
        this.tvNoGlitch = (TextView) view.findViewById(R.id.tvNoData);
        this.mCategory.addItemDecoration(new GMI_RVGridSpacing(3, 7, false));
        this.mCategory.setLayoutManager(new GridLayoutManager(this.mContext, 3));
    }

    @Override
    public void onResume() {
        super.onResume();
        new LoadPhotos().execute(new Void[0]);
    }

    
    private class LoadPhotos extends AsyncTask<Void, Void, Boolean> {
        private LoadPhotos() {
        }

        @Override
        public Boolean doInBackground(Void... voidArr) {
            ArrayList<String> loadFiles = GMI_FileHelper.loadFiles(GMI_AppHelper.getOutputPath(GMI_PhotosFragment.this.mContext));
            Collections.reverse(loadFiles);
            if (GMI_PhotosFragment.this.photoList.isEmpty()) {
                GMI_PhotosFragment.this.photoList = loadFiles;
                return true;
            } else if (GMI_PhotosFragment.this.photoList.size() != loadFiles.size()) {
                GMI_PhotosFragment.this.photoList = loadFiles;
                return true;
            } else {
                return false;
            }
        }

        @Override
        public void onPostExecute(Boolean bool) {
            super.onPostExecute(bool);
            if (bool.booleanValue()) {
                if (GMI_PhotosFragment.this.photoList.size() > 0) {
                    Collections.reverse(GMI_PhotosFragment.this.photoList);
                    GMI_PhotosFragment.this.tvNoGlitch.setVisibility(View.GONE);
                    GMI_PhotosFragment.this.mCategory.setVisibility(View.VISIBLE);
                    GMI_PhotosFragment photosFragment = GMI_PhotosFragment.this;
                    photosFragment.adapter = new GMI_PhotoAdapter(photosFragment.mContext, GMI_PhotosFragment.this.photoList, new GMI_ClickListener() {
                        @Override
                        public void onItemClick(int i) {
                            int i2;
                            String str = (String) GMI_PhotosFragment.this.photoList.get(i);
                            if (str.length() == 5) {
                                i2 = Integer.parseInt(str.substring(0, 1));
                            } else {
                                int i22 = str.length();
                                if (i22 > 5) {
                                    i2 = Integer.parseInt(str.substring(str.length() - 5).substring(0, 1));
                                } else {
                                    throw new IllegalArgumentException("word has less than 5 characters!");
                                }
                            }
                            String str2 = GMI_AppHelper.getOutputPath(GMI_PhotosFragment.this.mContext) + File.separator + str.substring(str.lastIndexOf("/") + 1).substring(0, 15);
                            ArrayList arrayList = new ArrayList();
                            for (int i3 = 0; i3 < i2; i3++) {
                                String str3 = str2 + "_" + String.format("%02d", Integer.valueOf(i3)) + "_" + i2 + ".jpg";
                                if (new File(str3).exists()) {
                                    arrayList.add(str3);
                                    Log.d("FILE_EXIST", str3);
                                } else {
                                    Log.d("FILE_NOT_EXIST", str3);
                                }
                            }
                            GMI_Constant.pathList = arrayList;
                            getInstance((Activity) mContext).ShowAd(new HandleClick() {
                                @Override
                                public void Show(boolean adShow) {
                                    Intent intent = new Intent(GMI_PhotosFragment.this.mContext, GMI_GridPreviewActivity.class);
                                    intent.putExtra("from", "creation");
                                    GMI_PhotosFragment.this.startActivity(intent);
                                }
                            }, MAIN_CLICK);

                        }
                    });
                    GMI_PhotosFragment.this.mCategory.setAdapter(GMI_PhotosFragment.this.adapter);
                    GMI_PhotosFragment.this.adapter.notifyDataSetChanged();
                    return;
                }
                GMI_PhotosFragment.this.tvNoGlitch.setVisibility(View.VISIBLE);
                GMI_PhotosFragment.this.mCategory.setVisibility(View.GONE);
            }
        }
    }
}
