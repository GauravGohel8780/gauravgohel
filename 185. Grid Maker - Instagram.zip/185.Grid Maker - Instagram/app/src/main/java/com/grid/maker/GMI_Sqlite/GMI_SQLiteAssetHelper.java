package com.grid.maker.GMI_Sqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.zip.ZipInputStream;

public class GMI_SQLiteAssetHelper extends SQLiteOpenHelper {
    String a;
    private String mAssetPath;
    private final Context mContext;
    private SQLiteDatabase mDatabase;
    private String mDatabasePath;
    private final SQLiteDatabase.CursorFactory mFactory;
    private int mForcedUpgradeVersion;
    private boolean mIsInitializing;
    private final String mName;
    private final int mNewVersion;
    private String mUpgradePathFormat;

    @Override
    public final void onConfigure(SQLiteDatabase sQLiteDatabase) {
    }

    @Override
    public final void onCreate(SQLiteDatabase sQLiteDatabase) {
    }

    @Override
    public final void onDowngrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
    }

    public GMI_SQLiteAssetHelper(Context context, String str, String str2, SQLiteDatabase.CursorFactory cursorFactory, int i) {
        super(context, str, cursorFactory, i);
        this.a = "ASHA_GRID_CUT_SQLiteAssetHelper";
        this.mDatabase = null;
        this.mIsInitializing = false;
        this.mForcedUpgradeVersion = 0;
        if (i < 1) {
            throw new IllegalArgumentException("Version must be >= 1, was " + i);
        } else if (str == null) {
            throw new IllegalArgumentException("Database name cannot be null");
        } else {
            this.mContext = context;
            this.mName = str;
            this.mFactory = cursorFactory;
            this.mNewVersion = i;
            this.mAssetPath = "databases/" + str;
            if (str2 != null) {
                this.mDatabasePath = str2;
            } else {
                this.mDatabasePath = context.getApplicationInfo().dataDir + "/databases";
            }
            this.mUpgradePathFormat = "databases/" + str + "_upgrade_%s-%s.sql";
        }
    }

    public GMI_SQLiteAssetHelper(Context context, String str, SQLiteDatabase.CursorFactory cursorFactory, int i) {
        this(context, str, null, cursorFactory, i);
    }

    @Override
    public synchronized SQLiteDatabase getWritableDatabase() {
        SQLiteDatabase sQLiteDatabase = this.mDatabase;
        if (sQLiteDatabase != null && sQLiteDatabase.isOpen() && !this.mDatabase.isReadOnly()) {
            return this.mDatabase;
        } else if (this.mIsInitializing) {
            throw new IllegalStateException("getWritableDatabase called recursively");
        } else {
            this.mIsInitializing = true;
            SQLiteDatabase db = createOrOpenDatabase(false);
            int version = db.getVersion();
            if (version != 0 && version < this.mForcedUpgradeVersion) {
                db = createOrOpenDatabase(true);
                db.setVersion(this.mNewVersion);
                version = db.getVersion();
            }
            if (version != this.mNewVersion) {
                db.beginTransaction();
                try {
                    if (version == 0) {
                        onCreate(db);
                    } else {
                        if (version > this.mNewVersion) {
                            String str = this.a;
                            Log.w(str, "Can't downgrade read-only database from version " + version + " to " + this.mNewVersion + ": " + db.getPath());
                        }
                        onUpgrade(db, version, this.mNewVersion);
                    }
                    db.setVersion(this.mNewVersion);
                    db.setTransactionSuccessful();
                    db.endTransaction();
                } catch (Throwable th) {
                    db.endTransaction();
                    throw th;
                }
            }
            onOpen(db);
            this.mIsInitializing = false;
            SQLiteDatabase sQLiteDatabase2 = this.mDatabase;
            if (sQLiteDatabase2 != null) {
                try {
                    sQLiteDatabase2.close();
                } catch (Exception e) {
                }
            }
            this.mDatabase = db;
            return db;
        }
    }

    @Override
    public synchronized SQLiteDatabase getReadableDatabase() {
        SQLiteDatabase sQLiteDatabase = this.mDatabase;
        if (sQLiteDatabase != null && sQLiteDatabase.isOpen()) {
            return this.mDatabase;
        } else if (this.mIsInitializing) {
            throw new IllegalStateException("getReadableDatabase called recursively");
        } else {
            try {
                return getWritableDatabase();
            } catch (SQLiteException e) {
                if (this.mName == null) {
                    throw e;
                }
                String str = this.a;
                Log.e(str, "Couldn't open " + this.mName + " for writing (will try read-only):", e);
                this.mIsInitializing = true;
                String path = this.mContext.getDatabasePath(this.mName).getPath();
                SQLiteDatabase sQLiteDatabase2 = SQLiteDatabase.openDatabase(path, this.mFactory, 1);
                if (sQLiteDatabase2.getVersion() != this.mNewVersion) {
                    throw new SQLiteException("Can't upgrade read-only database from version " + sQLiteDatabase2.getVersion() + " to " + this.mNewVersion + ": " + path);
                }
                onOpen(sQLiteDatabase2);
                String str2 = this.a;
                Log.w(str2, "Opened " + this.mName + " in read-only mode");
                this.mDatabase = sQLiteDatabase2;
                this.mIsInitializing = false;
                return sQLiteDatabase2;
            }
        }
    }

    @Override
    public synchronized void close() {
        if (this.mIsInitializing) {
            throw new IllegalStateException("Closed during initialization");
        }
        SQLiteDatabase sQLiteDatabase = this.mDatabase;
        if (sQLiteDatabase != null && sQLiteDatabase.isOpen()) {
            this.mDatabase.close();
            this.mDatabase = null;
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        String str = this.a;
        Log.w(str, "Upgrading database " + this.mName + " from version " + i + " to " + i2 + "...");
        ArrayList<String> arrayList = new ArrayList<>();
        getUpgradeFilePaths(i, i2 + (-1), i2, arrayList);
        if (arrayList.isEmpty()) {
            String str2 = this.a;
            Log.e(str2, "no upgrade script path from " + i + " to " + i2);
            throw new SQLiteAssetException("no upgrade script path from " + i + " to " + i2);
        }
        Collections.sort(arrayList, new GMI_VersionComparator());
        Iterator<String> it = arrayList.iterator();
        while (it.hasNext()) {
            String next = it.next();
            try {
                String str3 = this.a;
                Log.w(str3, "processing upgrade: " + next);
                String convertStreamToString = GMI_Utils.convertStreamToString(this.mContext.getAssets().open(next));
                if (convertStreamToString != null) {
                    for (String str4 : GMI_Utils.splitSqlScript(convertStreamToString, ';')) {
                        if (str4.trim().length() > 0) {
                            sQLiteDatabase.execSQL(str4);
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        String str5 = this.a;
        Log.w(str5, "Successfully upgraded database " + this.mName + " from version " + i + " to " + i2);
    }

    @Deprecated
    public void setForcedUpgradeVersion(int i) {
        setForcedUpgrade(i);
    }

    public void setForcedUpgrade(int i) {
        this.mForcedUpgradeVersion = i;
    }

    private SQLiteDatabase createOrOpenDatabase(boolean z) {
        StringBuilder sb = new StringBuilder();
        sb.append(this.mDatabasePath);
        sb.append("/");
        sb.append(this.mName);
        SQLiteDatabase returnDatabase = new File(sb.toString()).exists() ? returnDatabase() : null;
        if (returnDatabase == null) {
            copyDatabaseFromAssets();
            return returnDatabase();
        } else if (!z) {
            return returnDatabase;
        } else {
            Log.w(this.a, "forcing database upgrade!");
            copyDatabaseFromAssets();
            return returnDatabase();
        }
    }

    private SQLiteDatabase returnDatabase() {
        try {
            SQLiteDatabase openDatabase = SQLiteDatabase.openDatabase(this.mDatabasePath + "/" + this.mName, this.mFactory, 0);
            String str = this.a;
            Log.i(str, "successfully opened database " + this.mName);
            return openDatabase;
        } catch (SQLiteException e) {
            String str2 = this.a;
            Log.w(str2, "could not open database " + this.mName + " - " + e.getMessage());
            return null;
        }
    }

    private void copyDatabaseFromAssets() {
        InputStream is;
        Log.w(this.a, "copying database from assets...");
        String path = this.mAssetPath;
        String dest = this.mDatabasePath + "/" + this.mName;
        boolean isZip = false;
        try {
            is = this.mContext.getAssets().open(path);
        } catch (IOException e) {
            try {
                InputStream is2 = this.mContext.getAssets().open(path + ".zip");
                isZip = true;
                is = is2;
            } catch (IOException e2) {
                try {
                    InputStream is3 = this.mContext.getAssets().open(path + ".gz");
                    is = is3;
                } catch (IOException e3) {
                    SQLiteAssetException se = new SQLiteAssetException("Missing " + this.mAssetPath + " file (or .zip, .gz archive) in assets, or target folder not writable");
                    se.setStackTrace(e3.getStackTrace());
                    throw se;
                }
            }
        }
        try {
            File f = new File(this.mDatabasePath + "/");
            if (!f.exists()) {
                f.mkdir();
            }
            if (isZip) {
                ZipInputStream zis = GMI_Utils.getFileFromZip(is);
                if (zis == null) {
                    throw new SQLiteAssetException("Archive is missing a SQLite database file");
                }
                GMI_Utils.writeExtractedFileToDisk(zis, new FileOutputStream(dest));
            } else {
                GMI_Utils.writeExtractedFileToDisk(is, new FileOutputStream(dest));
            }
            Log.w(this.a, "database copy complete");
        } catch (IOException e4) {
            SQLiteAssetException se2 = new SQLiteAssetException("Unable to write " + dest + " to data directory");
            se2.setStackTrace(e4.getStackTrace());
            throw se2;
        }
    }

    private InputStream getUpgradeSQLStream(int i, int i2) {
        String format = String.format(this.mUpgradePathFormat, Integer.valueOf(i), Integer.valueOf(i2));
        try {
            return this.mContext.getAssets().open(format);
        } catch (IOException e) {
            String str = this.a;
            Log.w(str, "missing database upgrade script: " + format);
            return null;
        }
    }

    private void getUpgradeFilePaths(int i, int i2, int i3, ArrayList<String> arrayList) {
        int i4;
        if (getUpgradeSQLStream(i2, i3) != null) {
            arrayList.add(String.format(this.mUpgradePathFormat, Integer.valueOf(i2), Integer.valueOf(i3)));
            i3 = i2;
            i4 = i2 - 1;
        } else {
            i4 = i2 - 1;
        }
        if (i4 >= i) {
            getUpgradeFilePaths(i, i4, i3, arrayList);
        }
    }

    
    public static class SQLiteAssetException extends SQLiteException {
        public SQLiteAssetException() {
        }

        public SQLiteAssetException(String str) {
            super(str);
        }
    }
}
