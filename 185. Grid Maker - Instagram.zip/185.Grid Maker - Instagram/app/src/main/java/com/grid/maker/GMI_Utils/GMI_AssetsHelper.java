package com.grid.maker.GMI_Utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;


public class GMI_AssetsHelper {

    public static ArrayList<String> listOfFiles(Context context, String str) {
        ArrayList<String> arrayList = new ArrayList<>();
        try {
            String[] list = context.getAssets().list(str);
            for (int i = 0; i < list.length; i++) {
                arrayList.add(str + File.separator + list[i]);
            }
        } catch (IOException e) {
        }
        return arrayList;
    }

    public static Bitmap getBitmap(Context r1, String r2) {
        return BitmapFactory.decodeStream(getInputStream(r1, r2));
    }

    public static InputStream getInputStream(Context context, String fileAssetPath) {
        try {
            InputStream ins = context.getAssets().open(fileAssetPath);
            return ins;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
