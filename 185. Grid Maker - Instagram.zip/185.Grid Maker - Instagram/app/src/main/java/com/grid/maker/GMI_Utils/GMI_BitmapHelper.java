package com.grid.maker.GMI_Utils;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import android.view.View;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class GMI_BitmapHelper {
    public static Bitmap getBitmap(View view) {
        view.clearFocus();
        view.setPressed(false);
        boolean willNotCacheDrawing = view.willNotCacheDrawing();
        view.setWillNotCacheDrawing(false);
        int drawingCacheBackgroundColor = view.getDrawingCacheBackgroundColor();
        view.setDrawingCacheBackgroundColor(0);
        if (drawingCacheBackgroundColor != 0) {
            view.destroyDrawingCache();
        }
        view.buildDrawingCache();
        Bitmap drawingCache = view.getDrawingCache();
        if (drawingCache == null) {
            Log.e("ERROR", "failed getViewBitmap(" + view + ")", new RuntimeException());
            return null;
        }
        Bitmap createBitmap = Bitmap.createBitmap(drawingCache);
        view.destroyDrawingCache();
        view.setWillNotCacheDrawing(willNotCacheDrawing);
        view.setDrawingCacheBackgroundColor(drawingCacheBackgroundColor);
        return createBitmap;
    }


    public static String saveImage(Context context, Bitmap bitmap, String str, String str2) {
        Intent intent;
        File file;
        File file2 = new File(str);
        file2.mkdirs();
        File file3 = new File(file2, str2);
        String path = file3.getPath();
        if (file3.exists()) {
            file3.delete();
        }
        try {
            if (!file3.exists()) {
                file3.createNewFile();
            }
            FileOutputStream fileOutputStream = new FileOutputStream(file3);
            bitmap.compress(Bitmap.CompressFormat.PNG, 10, fileOutputStream);
            fileOutputStream.close();
            intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
            file = new File(path);
        } catch (Exception e) {
            intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
            file = new File(path);
        } catch (Throwable th) {
            Intent intent2 = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
            intent2.setData(Uri.fromFile(new File(path)));
            context.sendBroadcast(intent2);
            throw th;
        }
        intent.setData(Uri.fromFile(file));
        context.sendBroadcast(intent);
        return file3.getPath();
    }


    public static Bitmap getBitmap(Context context, Uri uri) {
        try {
            ParcelFileDescriptor openFileDescriptor = context.getContentResolver().openFileDescriptor(uri, "r");
            Bitmap bitmap = BitmapFactory.decodeFileDescriptor(openFileDescriptor.getFileDescriptor());
            try {
                openFileDescriptor.close();
            } catch (IOException e) {
            }
            return bitmap;
        } catch (IOException e3) {
            e3.printStackTrace();
            return null;
        }
    }
}
