package com.grid.maker.GMI_Utils;

import android.graphics.Bitmap;
import android.os.Environment;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

    public class GMI_Constant {
        public static List<Bitmap> bitmapLis = new ArrayList();
        public static String folder;
        public static List<String> pathList;

        static {
            StringBuilder sb = new StringBuilder();
            sb.append(Environment.getExternalStorageDirectory());
            String str = File.separator;
            sb.append(str);
            sb.append("WhatsApp");
            sb.append(str);
            sb.append("Media");
            sb.append(str);
            sb.append(".Statuses");
            folder = sb.toString();
            pathList = new ArrayList();
        }
    }
