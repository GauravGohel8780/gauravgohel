package com.grid.maker.GMI_Utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.os.StrictMode;
import android.util.Log;
import android.widget.Toast;

import androidx.core.view.PointerIconCompat;

import com.grid.maker.R;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class GMI_CameraHelper {
    public static String CANCELLED_PHOTO = "Cancelled image capture";
    public static String FAILED_PHOTO = "Sorry! Failed to capture image";
    public static int REQUEST_PHOTO = PointerIconCompat.TYPE_CONTEXT_MENU;
    public static String TAG = "JNP__" + GMI_CameraHelper.class.getSimpleName();
    public static String no_camera = "Sorry! Your device doesn't support camera";

    public static boolean isDeviceSupportCamera(Context context) {
        return context.getPackageManager().hasSystemFeature("android.hardware.camera");
    }

    public static String getAppName(Context context) {
        return context.getString(R.string.app_name);
    }

    public static Uri captureImage(Context context, int i) {
        if (!isDeviceSupportCamera(context)) {
            Toast.makeText(context, no_camera, Toast.LENGTH_LONG).show();
            return null;
        }
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), getAppName(context));
        if (file.exists() || file.mkdirs()) {
            String format = new SimpleDateFormat("ddMMyyyy_HHmmss", Locale.getDefault()).format(new Date());
            Uri fromFile = Uri.fromFile(new File(file.getPath() + File.separator + "IMG_" + format + ".jpg"));
            Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
            intent.putExtra("output", fromFile);
            ((Activity) context).startActivityForResult(intent, i);
            return fromFile;
        }
        String str = TAG;
        Log.d(str, "Oops! Failed create " + getAppName(context) + " directory");
        return null;
    }
}
