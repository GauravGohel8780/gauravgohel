package com.grid.maker;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.grid.maker.Ads_Common.AdsBaseActivity;
import com.grid.maker.Ads_Common.ExitActivity;
import com.grid.maker.GMI_Activity.GMI_InstaGridActivity;
import com.grid.maker.GMI_Activity.GMI_MyCreationActivity;
import com.grid.maker.GMI_Utils.GMI_AppHelper;
import com.grid.maker.GMI_Utils.GMI_CameraHelper;
import com.grid.maker.GMI_Utils.GMI_ChooserHelper;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AdsBaseActivity {
    private static final int PERMISSION_REQUEST_CODE = 123;
    private Uri imgUri;
    private ImageView ivCamera, ivCreation, ivGallery, ivShare;
    private Context mContext;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.gmi_activity_main);
        this.mContext = this;
        ui();
        myClickListener();

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                getInstance(MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        startActivity(new Intent(MainActivity.this, ExitActivity.class));
                    }
                }, BACK_CLICK);
            }
        };

        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    private void ui() {
        this.ivCamera = (ImageView) findViewById(R.id.ivCamera);
        this.ivGallery = (ImageView) findViewById(R.id.ivGallery);
        this.ivCreation = (ImageView) findViewById(R.id.ivCreation);
        this.ivShare = (ImageView) findViewById(R.id.ivShare);
    }

    public void myClickListener() {
        ivGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    checkAndRequestPermissions(new String[]{Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.CAMERA, Manifest.permission.READ_MEDIA_IMAGES}, 0);
                } else {
                    checkAndRequestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA}, 0);
                }
            }
        });
        ivCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    checkAndRequestPermissions(new String[]{Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.CAMERA, Manifest.permission.READ_MEDIA_IMAGES}, 1);
                } else {
                    checkAndRequestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA}, 1);
                }
            }
        });
        ivCreation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    checkAndRequestPermissions(new String[]{Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.CAMERA, Manifest.permission.READ_MEDIA_IMAGES}, 2);
                } else {
                    checkAndRequestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA}, 2);
                }
            }
        });
        this.ivShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GMI_AppHelper.shareApp(MainActivity.this.mContext);
            }
        });
    }


    private void checkAndRequestPermissions(String[] permissions, int position) {
        List<String> permissionsNeeded = new ArrayList<>();
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(permission);
            }
        }

        if (!permissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsNeeded.toArray(new String[0]), PERMISSION_REQUEST_CODE);
        } else {
            getInstance(MainActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    if (position == 0) {
                        MainActivity mainActivity = MainActivity.this;
                        mainActivity.imgUri = GMI_CameraHelper.captureImage(mainActivity.mContext, GMI_CameraHelper.REQUEST_PHOTO);
                    } else if (position == 1) {
                        GMI_ChooserHelper.chooseImage(MainActivity.this.mContext, GMI_ChooserHelper.REQUEST_PHOTO);
                    } else if (position == 2) {
                        MainActivity.this.startActivity(new Intent(MainActivity.this.mContext, GMI_MyCreationActivity.class));
                    }
                }
            }, MAIN_CLICK);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allPermissionsGranted = true;
            for (int grantResult : grantResults) {
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false;
                    break;
                }
            }

            if (!allPermissionsGranted) {
                boolean shouldShowRationale = false;
                for (String permission : permissions) {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                        shouldShowRationale = true;
                        break;
                    }
                }

                if (shouldShowRationale) {
                    showRationaleDialog();
                } else {
                    Toast.makeText(this, "Permission denied. Please enable it in app settings.", Toast.LENGTH_LONG).show();
                    showRationaleDialog();
                }
            }
        }
    }

    private void showRationaleDialog() {
        new AlertDialog.Builder(this).setTitle("Permission Required").setMessage("This app requires permission to access your media. Please allow it in app settings.").setPositiveButton("OK", (dialogInterface, i) -> {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }).setNegativeButton("Cancel", null).create().show();
    }


    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == GMI_CameraHelper.REQUEST_PHOTO) {
            if (i2 == -1) {
                try {
                    startEdit(this.imgUri);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            } else if (i2 == 0) {
                Toast.makeText(this.mContext, GMI_CameraHelper.CANCELLED_PHOTO, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this.mContext, GMI_CameraHelper.FAILED_PHOTO, Toast.LENGTH_SHORT).show();
            }
        } else if (i == GMI_ChooserHelper.REQUEST_PHOTO) {
            if (i2 == -1) {
                Uri data = intent.getData();
                try {
                    startEdit(data);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            } else if (i2 == 0) {
                Toast.makeText(this.mContext, GMI_ChooserHelper.CANCELLED_PHOTO, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this.mContext, GMI_ChooserHelper.FAILED_PHOTO, Toast.LENGTH_SHORT).show();
            }
        }
    }


    private void startEdit(Uri uri) throws IOException {
        Intent intent = new Intent(this.mContext, GMI_InstaGridActivity.class);
        intent.putExtra("imageUri", uri);
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BIG);
    }
}
