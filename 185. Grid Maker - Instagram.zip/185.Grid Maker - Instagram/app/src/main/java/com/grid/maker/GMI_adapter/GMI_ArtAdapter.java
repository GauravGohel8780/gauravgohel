package com.grid.maker.GMI_adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.grid.maker.R;
import com.grid.maker.GMI_Utils.GMI_AssetsHelper;

import java.util.ArrayList;

public class GMI_ArtAdapter extends RecyclerView.Adapter<GMI_ArtAdapter.ViewHolder> {
    private ArrayList<String> grids;
    private Context mContext;
    private OnItemClick onItemClick;

    
    public interface OnItemClick {
        void itemClick(int i);
    }

    @Override
    public int getItemViewType(int i) {
        return i;
    }

    public GMI_ArtAdapter(Context context, ArrayList<String> arrayList, OnItemClick onItemClick2) {
        this.grids = new ArrayList<>();
        this.mContext = context;
        this.grids = arrayList;
        this.onItemClick = onItemClick2;
    }

    @Override
    @NonNull
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View inflate = LayoutInflater.from(this.mContext).inflate(R.layout.gmi_card_art, viewGroup, false);
        final ViewHolder viewHolder = new ViewHolder(this, inflate);
        inflate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GMI_ArtAdapter.this.onItemClick.itemClick(viewHolder.getPosition());
            }
        });
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        viewHolder.ivArt.setImageBitmap(GMI_AssetsHelper.getBitmap(this.mContext, this.grids.get(i)));
    }

    @Override
    public int getItemCount() {
        return this.grids.size();
    }

    
    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView ivArt;

        public ViewHolder(GMI_ArtAdapter adapter, View view) {
            super(view);
            this.ivArt = (ImageView) view.findViewById(R.id.ivArt);
        }
    }
}
