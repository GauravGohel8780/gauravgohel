package com.grid.maker.GMI_adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.grid.maker.R;
import com.grid.maker.GMI_Utils.GMI_ClickListener;
import com.grid.maker.GMI_Utils.GMI_DisplayHelper;


import java.util.List;

public class GMI_PreviewAdapter extends RecyclerView.Adapter<GMI_PreviewAdapter.CategoryHolder> {
    Context context;
    List<String> list;
    public GMI_ClickListener clickListener;

    public GMI_PreviewAdapter(Context context, List<String> list, GMI_ClickListener aSHA_GRID_CUT_RVClickListener) {
        this.context = context;
        this.list = list;
        this.clickListener = aSHA_GRID_CUT_RVClickListener;
    }

    @Override
    @NonNull
    public CategoryHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View inflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.gmi_card_preview, viewGroup, false);
        CategoryHolder categoryHolder = new CategoryHolder(this, inflate);
        inflate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });
        return categoryHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final CategoryHolder categoryHolder, @SuppressLint("RecyclerView") final int i) {
        Glide.with(context).load(list.get(i)).into(categoryHolder.iv_category_icon);
        categoryHolder.iv_category_icon.getLayoutParams().height = GMI_DisplayHelper.getDisplayWidth(context) / 3;
        categoryHolder.view.getLayoutParams().height = GMI_DisplayHelper.getDisplayWidth(context) / 3;
        categoryHolder.view.getLayoutParams().width = GMI_DisplayHelper.getDisplayWidth(context) / 3;
        TextView textView = categoryHolder.tv_num;
        textView.setText((list.size() - i) + "");
        categoryHolder.iv_category_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GMI_PreviewAdapter.this.clickListener.onItemClick(i);
                categoryHolder.view.setBackgroundColor(context.getResources().getColor(R.color.orange_trans));
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }


    public class CategoryHolder extends RecyclerView.ViewHolder {
        ImageView iv_category_icon;
        RelativeLayout relative_num;
        TextView tv_num;
        View view;

        public CategoryHolder(GMI_PreviewAdapter previewAdapter, View view2) {
            super(view2);
            iv_category_icon = (ImageView) view2.findViewById(R.id.ivCategoryicon);
            relative_num = (RelativeLayout) view2.findViewById(R.id.rlNum);
            tv_num = (TextView) view2.findViewById(R.id.tvNum);
            view = view2.findViewById(R.id.view);
        }
    }

    @Override
    public int getItemViewType(int i) {
        return super.getItemViewType(i);
    }
}
