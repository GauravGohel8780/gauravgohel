package com.grid.maker.GMI_adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.grid.maker.R;

public class GMI_ColorAdapter extends RecyclerView.Adapter<GMI_ColorAdapter.ViewHolder> {
    private int[] allColors;
    private Context mContext;
    private OnItemClick onItemClick;

    
    public interface OnItemClick {
        void itemClick(int i);
    }

    @Override
    public int getItemViewType(int i) {
        return i;
    }

    public GMI_ColorAdapter(Context context, int[] iArr, OnItemClick onItemClick2) {
        this.mContext = context;
        this.allColors = iArr;
        this.onItemClick = onItemClick2;
    }

    @Override
    @NonNull
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View inflate = LayoutInflater.from(this.mContext).inflate(R.layout.gmi_card_color, viewGroup, false);
        final ViewHolder viewHolder = new ViewHolder(this, inflate);
        inflate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GMI_ColorAdapter.this.onItemClick.itemClick(viewHolder.getPosition());
            }
        });
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        Log.d("COLOR", String.valueOf(this.allColors[i] + i));
        viewHolder.ivArt.setBackgroundColor(this.allColors[i]);
    }

    @Override
    public int getItemCount() {
        return this.allColors.length;
    }

    
    public class ViewHolder extends RecyclerView.ViewHolder {
        private View ivArt;

        public ViewHolder(GMI_ColorAdapter adapter, View view) {
            super(view);
            this.ivArt = view.findViewById(R.id.ivColor);
        }
    }
}
