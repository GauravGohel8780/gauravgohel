package com.grid.maker.GMI_Utils;

import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.util.Log;


import com.grid.maker.R;

import java.io.File;

public class GMI_AppHelper {
    private static boolean log = true;
    private static String log_tag = "JNP__" + GMI_AppHelper.class.getSimpleName();
    private static boolean toast = true;

    public static void log(String str) {
        if (log) {
            Log.i(log_tag, str);
        }
    }

    public static void log(int i) {
        if (log) {
            String str = log_tag;
            Log.i(str, i + "");
        }
    }

    public static void log(Exception exc) {
        if (log) {
            Log.i(log_tag, exc.toString());
        }
    }

    public static void log(String str, String str2) {
        if (log) {
            Log.i(str, str2);
        }
    }

    public static void log(String str, int i) {
        if (log) {
            Log.i(str, i + "");
        }
    }

    public static void log(String str, Exception exc) {
        if (log) {
            Log.i(str, exc.toString());
        }
    }

    public static String getAppName(Context context) {
        return context.getString(R.string.app_name);
    }

    public static String getOutputPath(Context context) {
        String str = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + File.separator + getAppName(context);
        File file = new File(str);
        if (!file.exists()) {
            file.mkdir();
        }
        return str;
    }
    public static void shareApp(Context context) {
        String format = String.format("I am using the 9 cut instagrid app: %1$s. if you want to have a try, please search: \"%2$s\" in play store!,  Or Click on the link given below to download. ", getAppName(context), getAppName(context));
        Intent intent = new Intent("android.intent.action.SEND");
        intent.putExtra("android.intent.extra.TEXT", format + "https://play.google.com/store/apps/details?id=" + context.getPackageName());
        intent.setType("text/plain");
        context.startActivity(Intent.createChooser(intent, "Share Via"));
    }
}
