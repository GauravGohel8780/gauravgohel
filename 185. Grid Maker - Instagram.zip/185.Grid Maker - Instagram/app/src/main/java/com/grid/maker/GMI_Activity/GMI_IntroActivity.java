package com.grid.maker.GMI_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;

import com.google.android.material.tabs.TabLayout;
import com.grid.maker.Ads_Common.AdsBaseActivity;
import com.grid.maker.MainActivity;
import com.grid.maker.R;
import com.grid.maker.GMI_adapter.GMI_IntroViewPagerAdapter;
import com.grid.maker.GMI_Utils.GMI_PrefManager;
import com.grid.maker.databinding.GmiActivityIntroBinding;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.util.ArrayList;

public class GMI_IntroActivity extends AdsBaseActivity {

    GmiActivityIntroBinding binding;
    Animation btnAnim;
    GMI_IntroViewPagerAdapter introViewPagerAdapter;
    int position = 0;
    private ViewPager screenPager;
    TabLayout tab_indicator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SetSystemFullScreen(this);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        GmiActivityIntroBinding inflate = GmiActivityIntroBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView(inflate.getRoot());

        final ArrayList arrayList = new ArrayList();
        arrayList.add(new GMI_IntroModel(getString(R.string.gmi_text_title_a), getString(R.string.gmi_text_intro_a), R.drawable.ic_intro_logo_1));
        arrayList.add(new GMI_IntroModel(getString(R.string.gmi_text_title_a), getString(R.string.gmi_text_intro_b), R.drawable.ic_intro_logo_2));
        arrayList.add(new GMI_IntroModel(getString(R.string.gmi_text_title_a), getString(R.string.gmi_text_intro_c), R.drawable.ic_intro_logo_3));
        this.screenPager = (ViewPager) findViewById(R.id.vpScreenViewpager);
        this.tab_indicator = (TabLayout) findViewById(R.id.tlTabIndicator);
        GMI_IntroViewPagerAdapter introViewPagerAdapter = new GMI_IntroViewPagerAdapter(this, arrayList);
        this.introViewPagerAdapter = introViewPagerAdapter;
        this.screenPager.setAdapter(introViewPagerAdapter);
        this.tab_indicator.setupWithViewPager(this.screenPager);
        findViewById(R.id.ivNext).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(GMI_IntroActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        GMI_IntroActivity intro_Activity = GMI_IntroActivity.this;
                        intro_Activity.position = intro_Activity.screenPager.getCurrentItem();
                        if (position < arrayList.size()) {
                            position++;
                            screenPager.setCurrentItem(position);
                        }
                        if (position == arrayList.size() - 1) {
                            loaddLastScreen();
                        }
                        if (position == arrayList.size()) {
                            startActivity(new Intent(GMI_IntroActivity.this, MainActivity.class));
                            new GMI_PrefManager().setFistTimeIntro(GMI_IntroActivity.this, true);
                        }
                    }
                }, MAIN_CLICK);
            }
        });
        this.tab_indicator.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getPosition() == arrayList.size() - 1) {
                    loaddLastScreen();
                }
                if (tab.getPosition() == arrayList.size() - 2) {
                    tab_indicator.setVisibility(View.INVISIBLE);
                }
            }
        });
    }

    public void loaddLastScreen() {
        this.tab_indicator.setVisibility(View.INVISIBLE);
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        finishAffinity();
    }


    public static void SetSystemFullScreen(Activity activity) {
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) {
            View v = activity.getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            View decorView = activity.getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
