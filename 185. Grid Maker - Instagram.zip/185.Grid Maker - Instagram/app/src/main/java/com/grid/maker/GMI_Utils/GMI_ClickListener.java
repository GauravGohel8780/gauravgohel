package com.grid.maker.GMI_Utils;


public interface GMI_ClickListener {
    void onItemClick(int i);
}
