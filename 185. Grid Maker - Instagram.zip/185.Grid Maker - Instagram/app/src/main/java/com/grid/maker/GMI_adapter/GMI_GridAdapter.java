package com.grid.maker.GMI_adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.grid.maker.R;
import com.grid.maker.GMI_Sqlite.GMI_DatabaseHelper;

import java.util.ArrayList;

public class GMI_GridAdapter extends RecyclerView.Adapter<GMI_GridAdapter.ViewHolder> {
    private ArrayList<GMI_DatabaseHelper.Grid> grids;
    private Context mContext;
    private OnItemClick onItemClick;

    
    public interface OnItemClick {
        void itemClick(int i);
    }

    @Override
    public int getItemViewType(int i) {
        return i;
    }

    public GMI_GridAdapter(Context context, ArrayList<GMI_DatabaseHelper.Grid> arrayList, OnItemClick onItemClick2) {
        this.grids = new ArrayList<>();
        this.mContext = context;
        this.grids = arrayList;
        this.onItemClick = onItemClick2;
    }

    @Override
    @NonNull
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View inflate = LayoutInflater.from(this.mContext).inflate(R.layout.gmi_card_grid, viewGroup, false);
        final ViewHolder viewHolder = new ViewHolder(this, inflate);
        inflate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GMI_GridAdapter.this.onItemClick.itemClick(viewHolder.getPosition());
            }
        });
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        GMI_DatabaseHelper.Grid grid = this.grids.get(i);
        int i2 = grid.row;
        if (i2 == 1) {
            viewHolder.row2.setVisibility(View.GONE);
            viewHolder.row3.setVisibility(View.GONE);
            viewHolder.view3.setVisibility(View.GONE);
            viewHolder.view6.setVisibility(View.GONE);
        } else if (i2 == 2) {
            viewHolder.row3.setVisibility(View.GONE);
            viewHolder.view6.setVisibility(View.GONE);
        }
        setBoxColor(viewHolder, grid.getMatrix());
    }

    private void setBoxColor(ViewHolder viewHolder, String str) {
        String[] split = str.split(",");
        for (int i = 0; i < split.length; i++) {
            switch (i) {
                case 0:
                    if (split[i].equals("0")) {
                        viewHolder.block0.setBackgroundColor(this.mContext.getResources().getColor(R.color.white));
                        break;
                    } else {
                        viewHolder.block0.setBackgroundColor(this.mContext.getResources().getColor(R.color.red));
                        break;
                    }
                case 1:
                    if (split[i].equals("0")) {
                        viewHolder.block1.setBackgroundColor(this.mContext.getResources().getColor(R.color.white));
                        break;
                    } else {
                        viewHolder.block1.setBackgroundColor(this.mContext.getResources().getColor(R.color.red));
                        break;
                    }
                case 2:
                    if (split[i].equals("0")) {
                        viewHolder.block2.setBackgroundColor(this.mContext.getResources().getColor(R.color.white));
                        break;
                    } else {
                        viewHolder.block2.setBackgroundColor(this.mContext.getResources().getColor(R.color.red));
                        break;
                    }
                case 3:
                    if (split[i].equals("0")) {
                        viewHolder.block3.setBackgroundColor(this.mContext.getResources().getColor(R.color.white));
                        break;
                    } else {
                        viewHolder.block3.setBackgroundColor(this.mContext.getResources().getColor(R.color.red));
                        break;
                    }
                case 4:
                    if (split[i].equals("0")) {
                        viewHolder.block4.setBackgroundColor(this.mContext.getResources().getColor(R.color.white));
                        break;
                    } else {
                        viewHolder.block4.setBackgroundColor(this.mContext.getResources().getColor(R.color.red));
                        break;
                    }
                case 5:
                    if (split[i].equals("0")) {
                        viewHolder.block5.setBackgroundColor(this.mContext.getResources().getColor(R.color.white));
                        break;
                    } else {
                        viewHolder.block5.setBackgroundColor(this.mContext.getResources().getColor(R.color.red));
                        break;
                    }
                case 6:
                    if (split[i].equals("0")) {
                        viewHolder.block6.setBackgroundColor(this.mContext.getResources().getColor(R.color.white));
                        break;
                    } else {
                        viewHolder.block6.setBackgroundColor(this.mContext.getResources().getColor(R.color.red));
                        break;
                    }
                case 7:
                    if (split[i].equals("0")) {
                        viewHolder.block7.setBackgroundColor(this.mContext.getResources().getColor(R.color.white));
                        break;
                    } else {
                        viewHolder.block7.setBackgroundColor(this.mContext.getResources().getColor(R.color.red));
                        break;
                    }
                case 8:
                    if (split[i].equals("0")) {
                        viewHolder.block8.setBackgroundColor(this.mContext.getResources().getColor(R.color.white));
                        break;
                    } else {
                        viewHolder.block8.setBackgroundColor(this.mContext.getResources().getColor(R.color.red));
                        break;
                    }
            }
        }
    }

    @Override
    public int getItemCount() {
        return this.grids.size();
    }

    
    public class ViewHolder extends RecyclerView.ViewHolder {
        private LinearLayout block0;
        private LinearLayout block1;
        private LinearLayout block2;
        private LinearLayout block3;
        private LinearLayout block4;
        private LinearLayout block5;
        private LinearLayout block6;
        private LinearLayout block7;
        private LinearLayout block8;
        private FrameLayout frameGrid;
        private LinearLayout linearGridMain;
        private RelativeLayout linearMain;
        private LinearLayout row1;
        private LinearLayout row2;
        private LinearLayout row3;
        private View view1;
        private View view2;
        private View view3;
        private View view4;
        private View view5;
        private View view6;
        private View view7;
        private View view8;

        public ViewHolder(GMI_GridAdapter gridAdapter, View view) {
            super(view);
            this.linearMain = (RelativeLayout) view.findViewById(R.id.llMain);
            this.frameGrid = (FrameLayout) view.findViewById(R.id.flGrid);
            this.linearGridMain = (LinearLayout) view.findViewById(R.id.llGridMain);
            this.row1 = (LinearLayout) view.findViewById(R.id.llRow1);
            this.block0 = (LinearLayout) view.findViewById(R.id.llBlock0);
            this.view1 = view.findViewById(R.id.v1);
            this.block1 = (LinearLayout) view.findViewById(R.id.llBlock1);
            this.view2 = view.findViewById(R.id.v2);
            this.block2 = (LinearLayout) view.findViewById(R.id.llBlock2);
            this.view3 = view.findViewById(R.id.v3);
            this.row2 = (LinearLayout) view.findViewById(R.id.llRow2);
            this.block3 = (LinearLayout) view.findViewById(R.id.llBlock3);
            this.view4 = view.findViewById(R.id.v4);
            this.block4 = (LinearLayout) view.findViewById(R.id.llBlock4);
            this.view5 = view.findViewById(R.id.v5);
            this.block5 = (LinearLayout) view.findViewById(R.id.llBlock5);
            this.view6 = view.findViewById(R.id.v6);
            this.row3 = (LinearLayout) view.findViewById(R.id.llRow3);
            this.block6 = (LinearLayout) view.findViewById(R.id.llBlock6);
            this.view7 = view.findViewById(R.id.v7);
            this.block7 = (LinearLayout) view.findViewById(R.id.llBlock7);
            this.view8 = view.findViewById(R.id.v8);
            this.block8 = (LinearLayout) view.findViewById(R.id.llBlock8);
        }
    }
}
