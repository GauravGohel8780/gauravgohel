package com.grid.maker.GMI_Utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.provider.MediaStore;
import android.util.Log;
public class GMI_ChooserHelper {
    public static String CANCELLED_PHOTO = "Cancelled image load";
    public static String FAILED_PHOTO = "Sorry! Failed to load image";
    public static int REQUEST_PHOTO = 10001;
    public static String TAG = "JNP__" + GMI_ChooserHelper.class.getSimpleName();

    public static void chooseImage(Context context, int i) {
        try {
            ((Activity) context).startActivityForResult(Intent.createChooser(new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI), "Select Picture"), i);
        } catch (Exception e) {
            Log.d(TAG, e.toString());
        }
    }
}
