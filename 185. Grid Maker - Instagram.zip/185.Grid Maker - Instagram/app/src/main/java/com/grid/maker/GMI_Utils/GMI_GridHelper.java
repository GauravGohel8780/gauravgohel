package com.grid.maker.GMI_Utils;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.View;

public class GMI_GridHelper {
    public static int SCALE_HEIGHT = 1920;
    public static int SCALE_WIDTH = 1080;

    public static void setHeightWidth(Context context, View view, int i, int i2) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        int i3 = (displayMetrics.widthPixels * i) / SCALE_WIDTH;
        int i4 = (displayMetrics.heightPixels * i2) / SCALE_HEIGHT;
        view.getLayoutParams().width = i3;
        view.getLayoutParams().height = i4;
    }

    public static void setWidth(Context context, View view, int i) {
        view.getLayoutParams().width = (context.getResources().getDisplayMetrics().widthPixels * i) / SCALE_WIDTH;
    }

    public static void setHeight(Context context, View view, int i) {
        view.getLayoutParams().height = (context.getResources().getDisplayMetrics().heightPixels * i) / SCALE_HEIGHT;
    }
}
