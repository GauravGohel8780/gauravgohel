package com.grid.maker.GMI_adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.grid.maker.R;
import com.grid.maker.GMI_Utils.GMI_ClickListener;
import com.grid.maker.GMI_Utils.GMI_DisplayHelper;

import java.util.ArrayList;

public class GMI_PhotoAdapter extends RecyclerView.Adapter<GMI_PhotoAdapter.CategoryHolder> {
    Context context;
    ArrayList<String> arrayList;
    public GMI_ClickListener clickListener;

    public GMI_PhotoAdapter(Context context, ArrayList<String> arrayList, GMI_ClickListener aSHA_GRID_CUT_RVClickListener) {
        this.context = context;
        this.arrayList = arrayList;
        this.clickListener = aSHA_GRID_CUT_RVClickListener;
    }

    @Override
    @NonNull
    public CategoryHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View inflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.gmi_card_photo, viewGroup, false);
        final CategoryHolder categoryHolder = new CategoryHolder(this, inflate);
        inflate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GMI_PhotoAdapter.this.clickListener.onItemClick(categoryHolder.getPosition());
            }
        });
        return categoryHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryHolder categoryHolder, int i) {
        Glide.with(this.context).load(arrayList.get(i)).into(categoryHolder.iv_category_icon);
        categoryHolder.iv_category_icon.getLayoutParams().height = GMI_DisplayHelper.getDisplayWidth(this.context) / 3;
    }

    @Override
    public int getItemCount() {
        return this.arrayList.size();
    }


    public class CategoryHolder extends RecyclerView.ViewHolder {
        ImageView iv_category_icon;

        public CategoryHolder(GMI_PhotoAdapter photoAdapter, View view) {
            super(view);
            iv_category_icon = (ImageView) view.findViewById(R.id.ivCategoryicon);
        }
    }

    @Override
    public int getItemViewType(int i) {
        return super.getItemViewType(i);
    }
}
