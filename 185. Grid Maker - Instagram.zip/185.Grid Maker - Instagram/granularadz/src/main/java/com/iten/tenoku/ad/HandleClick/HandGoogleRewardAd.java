package com.iten.tenoku.ad.HandleClick;

public interface HandGoogleRewardAd {
    void RewardAdShown(boolean adShow);
}
