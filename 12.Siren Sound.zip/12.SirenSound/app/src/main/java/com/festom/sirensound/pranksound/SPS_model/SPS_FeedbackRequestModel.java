package com.festom.sirensound.pranksound.SPS_model;

public class SPS_FeedbackRequestModel {
    public String vName;
    public String vEmail;
    public String vFeedBackMessage;
    public String vPackageName;
    public String vDeviceName;
    public int iVersion;

    public SPS_FeedbackRequestModel(String vName, String vEmail, String vFeedBackMessage, String vPackageName, String vDeviceName, int iVersion) {
        this.vName = vName;
        this.vEmail = vEmail;
        this.vFeedBackMessage = vFeedBackMessage;
        this.vPackageName = vPackageName;
        this.vDeviceName = vDeviceName;
        this.iVersion = iVersion;
    }

    public String getvName() {
        return vName;
    }

    public void setvName(String vName) {
        this.vName = vName;
    }

    public String getvEmail() {
        return vEmail;
    }

    public void setvEmail(String vEmail) {
        this.vEmail = vEmail;
    }

    public String getvFeedBackMessage() {
        return vFeedBackMessage;
    }

    public void setvFeedBackMessage(String vFeedBackMessage) {
        this.vFeedBackMessage = vFeedBackMessage;
    }

    public String getvPackageName() {
        return vPackageName;
    }

    public void setvPackageName(String vPackageName) {
        this.vPackageName = vPackageName;
    }

    public String getvDeviceName() {
        return vDeviceName;
    }

    public void setvDeviceName(String vDeviceName) {
        this.vDeviceName = vDeviceName;
    }

    public int getiVersion() {
        return iVersion;
    }

    public void setiVersion(int dVersion) {
        this.iVersion = dVersion;
    }
}