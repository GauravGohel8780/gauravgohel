package com.festom.sirensound.pranksound.SPS_model;

public class SPS_LanguageModel {

    int flag;
    String languageName;
    int selectedPosition;
    String langCode;

    public SPS_LanguageModel(int flag, String languageName, String langCode) {
        this.flag = flag;
        this.languageName = languageName;
        this.langCode = langCode;
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getLanguageName() {
        return languageName;
    }

    public void setLanguageName(String languageName) {
        this.languageName = languageName;
    }

    public int getSelectedPosition() {
        return selectedPosition;
    }

    public void setSelectedPosition(int selectedPosition) {
        this.selectedPosition = selectedPosition;
    }

    public String getLangCode() {
        return langCode;
    }

    public void setLangCode(String langCode) {
        this.langCode = langCode;
    }
}
