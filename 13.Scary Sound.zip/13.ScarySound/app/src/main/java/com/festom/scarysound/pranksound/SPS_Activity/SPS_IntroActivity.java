package com.festom.scarysound.pranksound.SPS_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import com.festom.scarysound.pranksound.SPS_Adapter.SPS_IntroPagerAdapter;
import com.festom.scarysound.pranksound.Ads_Common.AdsBaseActivity;
import com.festom.scarysound.pranksound.R;
import com.festom.scarysound.pranksound.SPS_fragement.SPS_FirstIntroFragment;
import com.festom.scarysound.pranksound.SPS_fragement.SPS_SecondIntroFragment;
import com.festom.scarysound.pranksound.SPS_fragement.SPS_ThirdIntroFragment;
import com.festom.scarysound.pranksound.SPS_preference.SPS_SharePref;
import com.festom.scarysound.pranksound.SPS_util.SPS_CubeOutTransformer;
import com.festom.scarysound.pranksound.SPS_util.SPS_Utils;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class SPS_IntroActivity extends AdsBaseActivity {
    ViewPager vpIntro;
    SPS_IntroPagerAdapter introPagerAdapter;
    int focusPos = 0;
    ImageView ivNextBtn;
    TextView tvDetail;
    private LinearLayout llDotIndicator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);
        SPS_Utils.setStatusBarGradiant(this);

        vpIntro = findViewById(R.id.vpIntro);
        llDotIndicator = findViewById(R.id.llDotIndicator);

        ivNextBtn = findViewById(R.id.ivNextBtn);
        tvDetail = findViewById(R.id.tvDetail);

        introPagerAdapter = new SPS_IntroPagerAdapter(getSupportFragmentManager());
        vpIntro.setPageTransformer(true, new SPS_CubeOutTransformer());
        introPagerAdapter.add(new SPS_FirstIntroFragment());
        introPagerAdapter.add(new SPS_SecondIntroFragment());
        introPagerAdapter.add(new SPS_ThirdIntroFragment());
        vpIntro.setAdapter(introPagerAdapter);

        tvDetail.setText(R.string.intro_text_1);


        addIndicators(introPagerAdapter.getCount());

        ivNextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(SPS_IntroActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        int currentItem = vpIntro.getCurrentItem();
                        int lastItem = introPagerAdapter.getCount() - 1;

                        if (currentItem == lastItem) {
                            gotoLanguageSelection();
                        } else {
                            vpIntro.setCurrentItem(currentItem + 1);
                        }
                    }
                }, MAIN_CLICK);
            }
        });

        vpIntro.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                SPS_IntroActivity.this.focusPos = position;
                int i = SPS_IntroActivity.this.focusPos;
                if (i == 0) {
                    tvDetail.setText(R.string.intro_text_1);
                } else if (i == 1) {
                    tvDetail.setText(R.string.intro_text_2);
                } else {
                    tvDetail.setText(R.string.intro_text_3);
                }
            }

            @Override
            public void onPageSelected(int position) {
                updateIndicators(position);
                vpIntro.setCurrentItem(position);
                Log.d("--viewpager--", "onPageSelected: getCurrentItem " + vpIntro.getCurrentItem());
                Log.d("--viewpager--", "onPageSelected: position " + position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private void gotoLanguageSelection() {
        startActivity(new Intent(SPS_IntroActivity.this, SPS_LanguageSelectionActivity.class));
        SPS_SharePref.setIsFirstLaunch(SPS_IntroActivity.this, true);
        finish();
    }


    private void addIndicators(int count) {
        for (int i = 0; i < count; i++) {
            ImageView indicator = new ImageView(this);
            indicator.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_selected_dot));
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            layoutParams.setMargins(8, 0, 8, 0);
            llDotIndicator.addView(indicator, layoutParams);
        }
        updateIndicators(0);
    }

    private void updateIndicators(int position) {
        for (int i = 0; i < llDotIndicator.getChildCount(); i++) {
            ImageView indicator = (ImageView) llDotIndicator.getChildAt(i);
            if (position == 0) {
                indicator.setImageDrawable(ContextCompat.getDrawable(this,
                        i == position ? R.drawable.ic_selected_dot : R.drawable.ic_unselected_dot));
            } else if (position == 1) {
                indicator.setImageDrawable(ContextCompat.getDrawable(this,
                        i == position ? R.drawable.ic_selected_dot : R.drawable.ic_unselected_dot));
            } else {
                indicator.setImageDrawable(ContextCompat.getDrawable(this,
                        i == position ? R.drawable.ic_selected_dot : R.drawable.ic_unselected_dot));
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}