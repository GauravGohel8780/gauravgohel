package com.festom.scarysound.pranksound.SPS_util;


import com.festom.scarysound.pranksound.SPS_model.SPS_FeedBackResponseModel;
import com.festom.scarysound.pranksound.SPS_model.SPS_FeedbackRequestModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface SPS_ApiService {

    @POST("api/v1/feedBack/save")
    Call<SPS_FeedBackResponseModel> feedbackUser(@Body SPS_FeedbackRequestModel request);
}