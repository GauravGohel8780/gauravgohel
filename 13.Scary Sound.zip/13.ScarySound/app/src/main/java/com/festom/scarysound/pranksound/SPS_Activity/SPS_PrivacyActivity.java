package com.festom.scarysound.pranksound.SPS_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.MyApplication.sharedPreferencesHelper;

import android.os.Bundle;
import android.webkit.WebViewClient;

import com.festom.scarysound.pranksound.Ads_Common.AdsBaseActivity;
import com.festom.scarysound.pranksound.R;
import com.festom.scarysound.pranksound.databinding.ActivityPrivacyBinding;
import com.iten.tenoku.utils.AdUtils;

public class SPS_PrivacyActivity extends AdsBaseActivity {
    ActivityPrivacyBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPrivacyBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.web.loadUrl(sharedPreferencesHelper.getPrivacyPolicy());

        binding.web.getSettings().setJavaScriptEnabled(true);

        binding.web.setWebViewClient(new WebViewClient());
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}