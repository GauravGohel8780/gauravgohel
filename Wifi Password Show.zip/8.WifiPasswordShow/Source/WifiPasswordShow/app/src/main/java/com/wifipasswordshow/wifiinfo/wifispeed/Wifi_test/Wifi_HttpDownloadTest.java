package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_test;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;

public class Wifi_HttpDownloadTest extends Thread {
    public String fileURL;
    long endTime = 0;
    double downloadElapsedTime = Double.longBitsToDouble(1);
    int downloadedByte = 0;
    double finalDownloadRate = Double.longBitsToDouble(1);
    boolean finished = false;
    double instantDownloadRate = Double.longBitsToDouble(1);
    int timeout = 8;

    public Wifi_HttpDownloadTest(String str) {
        this.fileURL = str;
    }

    private double round(double d, int i) {
        if (i < 0) {
            throw new IllegalArgumentException();
        }
        try {
            return new BigDecimal(d).setScale(i, RoundingMode.HALF_UP).doubleValue();
        } catch (Exception unused) {
            return Double.longBitsToDouble(1);
        }
    }

    public double getInstantDownloadRate() {
        return this.instantDownloadRate;
    }

    public void setInstantDownloadRate(int i, double d) {
        if (i >= 0) {
            this.instantDownloadRate = round(Double.valueOf(((i * 8) / 1000000) / d).doubleValue(), 2);
        } else {
            this.instantDownloadRate = Double.longBitsToDouble(1);
        }
    }

    public double getFinalDownloadRate() {
        return round(this.finalDownloadRate, 2);
    }

    public boolean isFinished() {
        return this.finished;
    }

    @Override
    public void run() {
        long startTimeMillis = System.currentTimeMillis();
        this.downloadedByte = 0;
        ArrayList<String> urls = new ArrayList<>();
        urls.add(this.fileURL + "random4000x4000.jpg");
        urls.add(this.fileURL + "random3000x3000.jpg");
        for (String url : urls) {
            try {
                HttpsURLConnection connection = (HttpsURLConnection) new URL(url).openConnection();
                connection.setSSLSocketFactory((SSLSocketFactory) SSLSocketFactory.getDefault());
                connection.setHostnameVerifier((str, sSLSession) -> true);
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    try (InputStream inputStream = connection.getInputStream()) {
                        byte[] buffer = new byte[10240];
                        int bytesRead;
                        while ((bytesRead = inputStream.read(buffer)) != -1) {
                            this.downloadedByte += bytesRead;
                            double elapsedTime = (System.currentTimeMillis() - startTimeMillis) / 1000.0;
                            setInstantDownloadRate(this.downloadedByte, elapsedTime);
                            if (elapsedTime >= this.timeout) {
                                break;
                            }
                        }
                    }
                } else {
                    System.out.println("Link not found...");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        this.endTime = System.currentTimeMillis();
        double elapsedTime = (System.currentTimeMillis() - startTimeMillis) / 1000.0;
        this.downloadElapsedTime = elapsedTime;
        this.finalDownloadRate = ((this.downloadedByte * 8) / 1000000.0) / elapsedTime;
        this.finished = true;
    }
}
