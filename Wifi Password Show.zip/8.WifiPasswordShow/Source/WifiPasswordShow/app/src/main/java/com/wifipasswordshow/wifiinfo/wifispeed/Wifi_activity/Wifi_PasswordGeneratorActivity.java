package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.ClipboardManager;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.wifipasswordshow.wifiinfo.wifispeed.R;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_adapter.Wifi_Adapterpassword;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_extra.Wifi_MyData;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_extra.Wifi_PasswordGenerator;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_model.Wifi_ModelPassword;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Wifi_PasswordGeneratorActivity extends Wifi_BaseActivity {
    ImageView aSwitch;
    ImageView bSwitch;
    TextView button;
    ImageView cSwitch;
    Context context;
    ImageView dSwitch;
    EditText editText;
    ImageView imgBack;
    ImageView imgNoData;
    ArrayList<Wifi_ModelPassword> list = new ArrayList<>();
    ConstraintLayout main;
    ConstraintLayout main2;
    ImageView minus;
    Wifi_MyData myData;
    ImageView plus;
    RecyclerView recyclerView;
    TextView textCopy;
    TextView textSave;
    TextView textView;
    ConstraintLayout topBar;


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_password_generator);
        this.context = this;
        this.textView = (TextView) findViewById(R.id.text_password);
        this.button = (TextView) findViewById(R.id.bt_generator);
        this.aSwitch = (ImageView) findViewById(R.id.swich_lower);
        this.bSwitch = (ImageView) findViewById(R.id.swich_uper);
        this.cSwitch = (ImageView) findViewById(R.id.swich_number);
        this.dSwitch = (ImageView) findViewById(R.id.symbols_number);
        this.textCopy = (TextView) findViewById(R.id.text_copy);
        this.textSave = (TextView) findViewById(R.id.text_save);
        this.plus = (ImageView) findViewById(R.id.plus_number);
        this.minus = (ImageView) findViewById(R.id.minus_number);
        this.imgNoData = (ImageView) findViewById(R.id.img_no_data);
        this.recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        this.topBar = (ConstraintLayout) findViewById(R.id.constraint_action_bar_layout);
        this.main = (ConstraintLayout) findViewById(R.id.constraint_main);
        this.main2 = (ConstraintLayout) findViewById(R.id.constraint_main_2);
        this.imgBack = (ImageView) findViewById(R.id.img_back_language);
        this.editText = (EditText) findViewById(R.id.edit_number);
        this.myData = new Wifi_MyData(this.context);
        this.editText.setText("8");
        this.list = this.myData.getPasswordList();
        this.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_PasswordGeneratorActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Wifi_PasswordGeneratorActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        this.textSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_PasswordGeneratorActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        if (!Wifi_PasswordGeneratorActivity.this.textView.getText().toString().isEmpty()) {
                            Wifi_PasswordGeneratorActivity.this.list.add(new Wifi_ModelPassword(Wifi_PasswordGeneratorActivity.this.list.size() + 1, Wifi_PasswordGeneratorActivity.this.textView.getText().toString()));
                            Wifi_PasswordGeneratorActivity.this.myData.setPasswordList(Wifi_PasswordGeneratorActivity.this.list);
                            Wifi_PasswordGeneratorActivity.this.listSort();
                            Wifi_PasswordGeneratorActivity.this.recyclerView.getAdapter().notifyDataSetChanged();
                        } else {
                            Toast.makeText(Wifi_PasswordGeneratorActivity.this.context, (int) R.string.password_generat_first, Toast.LENGTH_SHORT).show();
                        }
                        Wifi_PasswordGeneratorActivity.this.listEmpty();
                    }
                }, MAIN_CLICK);
            }
        });
        this.textCopy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_PasswordGeneratorActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        if (!Wifi_PasswordGeneratorActivity.this.textView.getText().toString().isEmpty()) {
                            ((ClipboardManager) Wifi_PasswordGeneratorActivity.this.context.getSystemService(Context.CLIPBOARD_SERVICE)).setText(Wifi_PasswordGeneratorActivity.this.textView.getText());
                            Toast.makeText(Wifi_PasswordGeneratorActivity.this.context, (int) R.string.copied_to_clipboard, Toast.LENGTH_SHORT).show();
                            return;
                        }
                        Toast.makeText(Wifi_PasswordGeneratorActivity.this.context, (int) R.string.password_generat_first, Toast.LENGTH_SHORT).show();
                    }
             }, MAIN_CLICK);
            }
        });
        listSort();
        Wifi_Adapterpassword adapterpassword = new Wifi_Adapterpassword(this.list, new Wifi_Adapterpassword.OnClickItemListener() {
            @Override
            public void onClickItem(int i) {
                getInstance(Wifi_PasswordGeneratorActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        ((ClipboardManager) Wifi_PasswordGeneratorActivity.this.context.getSystemService(Context.CLIPBOARD_SERVICE)).setText(Wifi_PasswordGeneratorActivity.this.list.get(i).getWifiPassword());
                        Toast.makeText(Wifi_PasswordGeneratorActivity.this.context, (int) R.string.copied_to_clipboard, Toast.LENGTH_SHORT).show();
                    }
                }, MAIN_CLICK);
            }
        });
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this.context, RecyclerView.VERTICAL, false));
        this.recyclerView.setAdapter(adapterpassword);
        this.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_PasswordGeneratorActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        if (Wifi_PasswordGeneratorActivity.this.editText.getText().toString().isEmpty()) {
                            Wifi_PasswordGeneratorActivity.this.editText.setText("8");
                        }
                        int parseInt = Integer.parseInt(Wifi_PasswordGeneratorActivity.this.editText.getText().toString());
                        if (!Wifi_PasswordGeneratorActivity.this.aSwitch.isSelected() && !Wifi_PasswordGeneratorActivity.this.bSwitch.isSelected() && !Wifi_PasswordGeneratorActivity.this.cSwitch.isSelected() && !Wifi_PasswordGeneratorActivity.this.dSwitch.isSelected()) {
                            Wifi_PasswordGeneratorActivity.this.aSwitch.setSelected(true);
                        }
                        Wifi_PasswordGeneratorActivity.this.textView.setText(new Wifi_PasswordGenerator.PasswordGeneratorBuilder().useDigits(Wifi_PasswordGeneratorActivity.this.cSwitch.isSelected()).useLower(Wifi_PasswordGeneratorActivity.this.aSwitch.isSelected()).useUpper(Wifi_PasswordGeneratorActivity.this.bSwitch.isSelected()).usePunctuation(Wifi_PasswordGeneratorActivity.this.dSwitch.isSelected()).build().generate(parseInt));
                    }
                }, MAIN_CLICK);
            }
        });
        this.plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int parseInt = Integer.parseInt(Wifi_PasswordGeneratorActivity.this.editText.getText().toString());
                if (parseInt >= 8) {
                    EditText editText = Wifi_PasswordGeneratorActivity.this.editText;
                    editText.setText((parseInt + 1) + "");
                    return;
                }
                Wifi_PasswordGeneratorActivity.this.editText.setText("9");
            }
        });
        this.minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int parseInt = Integer.parseInt(Wifi_PasswordGeneratorActivity.this.editText.getText().toString());
                if (parseInt > 8) {
                    EditText editText = Wifi_PasswordGeneratorActivity.this.editText;
                    StringBuilder sb = new StringBuilder();
                    sb.append(parseInt - 1);
                    sb.append("");
                    editText.setText(sb.toString());
                    return;
                }
                Wifi_PasswordGeneratorActivity.this.editText.setText("8");
            }
        });
        if (!this.aSwitch.isSelected() && !this.bSwitch.isSelected() && !this.cSwitch.isSelected() && !this.dSwitch.isSelected()) {
            this.aSwitch.setSelected(true);
        }
        this.aSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Wifi_PasswordGeneratorActivity.this.aSwitch.isSelected()) {
                    if (!Wifi_PasswordGeneratorActivity.this.bSwitch.isSelected() && !Wifi_PasswordGeneratorActivity.this.cSwitch.isSelected() && !Wifi_PasswordGeneratorActivity.this.dSwitch.isSelected()) {
                        Wifi_PasswordGeneratorActivity.this.bSwitch.setSelected(true);
                    }
                    Wifi_PasswordGeneratorActivity.this.aSwitch.setSelected(false);
                    return;
                }
                Wifi_PasswordGeneratorActivity.this.aSwitch.setSelected(true);
            }
        });
        this.bSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Wifi_PasswordGeneratorActivity.this.bSwitch.isSelected()) {
                    if (!Wifi_PasswordGeneratorActivity.this.aSwitch.isSelected() && !Wifi_PasswordGeneratorActivity.this.cSwitch.isSelected() && !Wifi_PasswordGeneratorActivity.this.dSwitch.isSelected()) {
                        Wifi_PasswordGeneratorActivity.this.aSwitch.setSelected(true);
                    }
                    Wifi_PasswordGeneratorActivity.this.bSwitch.setSelected(false);
                    return;
                }
                Wifi_PasswordGeneratorActivity.this.bSwitch.setSelected(true);
            }
        });
        this.cSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Wifi_PasswordGeneratorActivity.this.cSwitch.isSelected()) {
                    if (!Wifi_PasswordGeneratorActivity.this.aSwitch.isSelected() && !Wifi_PasswordGeneratorActivity.this.bSwitch.isSelected() && !Wifi_PasswordGeneratorActivity.this.dSwitch.isSelected()) {
                        Wifi_PasswordGeneratorActivity.this.bSwitch.setSelected(true);
                    }
                    Wifi_PasswordGeneratorActivity.this.cSwitch.setSelected(false);
                    return;
                }
                Wifi_PasswordGeneratorActivity.this.cSwitch.setSelected(true);
            }
        });
        this.dSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Wifi_PasswordGeneratorActivity.this.dSwitch.isSelected()) {
                    if (!Wifi_PasswordGeneratorActivity.this.aSwitch.isSelected() && !Wifi_PasswordGeneratorActivity.this.bSwitch.isSelected() && !Wifi_PasswordGeneratorActivity.this.cSwitch.isSelected()) {
                        Wifi_PasswordGeneratorActivity.this.cSwitch.setSelected(true);
                    }
                    Wifi_PasswordGeneratorActivity.this.dSwitch.setSelected(false);
                    return;
                }
                Wifi_PasswordGeneratorActivity.this.dSwitch.setSelected(true);
            }
        });
        listEmpty();
    }


    public void listEmpty() {
        if (this.list.isEmpty()) {
            this.imgNoData.setVisibility(View.VISIBLE);
            return;
        }
        this.imgNoData.setVisibility(View.INVISIBLE);
    }

    public void listSort() {
        if (Build.VERSION.SDK_INT >= 24) {
            Collections.sort(this.list, new Comparator<Wifi_ModelPassword>() {
                @Override
                public int compare(Wifi_ModelPassword modelPassword, Wifi_ModelPassword modelPassword2) {
                    return modelPassword.getId() - modelPassword2.getId();
                }
            }.reversed());
        }
    }

}
