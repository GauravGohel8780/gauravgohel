package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.widget.AppCompatButton;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.wifipasswordshow.wifiinfo.wifispeed.Ads_Common.ExitActivity;
import com.wifipasswordshow.wifiinfo.wifispeed.R;
import com.wifipasswordshow.wifiinfo.wifispeed.databinding.ActivityMainBinding;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_extra.Wifi_MyData;


public class Wifi_MainActivity extends Wifi_BaseActivity {
    ActivityMainBinding binding;
    Context context;
    ImageView imgLanguage, imgPrivacy;
    private long mLastClickTime1;
    ConstraintLayout topBar;
    int REQUESTPERMISSIONCODE = 10;

    LinearLayout imgConnected, imgPasswordGen, imgScanQR, imgShowPassword, imgSpeedTest, imgWifiList, imgHosport, imgLiveLocation, imgPhoneInfo, imgSignalStrength;
    Wifi_MyData myData;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        this.context = this;
        this.myData = new Wifi_MyData(this);
        this.topBar = (ConstraintLayout) findViewById(R.id.constraint_action_bar_layout);
        this.imgLanguage = (ImageView) findViewById(R.id.img_back_language);
        this.imgPrivacy = (ImageView) findViewById(R.id.img_done_language);
        this.imgWifiList = (LinearLayout) findViewById(R.id.img_wifi);
        this.imgPasswordGen = (LinearLayout) findViewById(R.id.img_wifi_password);
        this.imgScanQR = (LinearLayout) findViewById(R.id.img_wifi_qr_connect);
        this.imgShowPassword = (LinearLayout) findViewById(R.id.img_show_passwords);
        this.imgSpeedTest = (LinearLayout) findViewById(R.id.img_speed_test);
        this.imgConnected = (LinearLayout) findViewById(R.id.img_connected_devices);
        this.imgHosport = (LinearLayout) findViewById(R.id.img_hotsport);
        this.imgSignalStrength = (LinearLayout) findViewById(R.id.img_signal);
        this.imgLiveLocation = (LinearLayout) findViewById(R.id.img_live_location);
        this.imgPhoneInfo = (LinearLayout) findViewById(R.id.img_phone_info);

        getPermission();
        this.imgLanguage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Wifi_MainActivity.this.startActivity(new Intent(Wifi_MainActivity.this.context, Wifi_LanguageActivity.class).putExtra("from", 2));
                    }
                }, MAIN_CLICK);
            }
        });
        this.imgPrivacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Wifi_MainActivity.this.startActivity(new Intent(Wifi_MainActivity.this, Wifi_Privacy_policy.class));
                    }
                }, MAIN_CLICK);
            }
        });


        imgConnected.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        startActivity(new Intent(Wifi_MainActivity.this, Wifi_ConnectedDevicesActivity.class));
                    }
                }, MAIN_CLICK);
            }
        });
        this.imgSpeedTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        startActivity(new Intent(Wifi_MainActivity.this, Wifi_SpeedTestActivity.class));
                    }
                }, MAIN_CLICK);
            }
        });
        this.imgPasswordGen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        startActivity(new Intent(Wifi_MainActivity.this, Wifi_PasswordGeneratorActivity.class));
                    }
                }, MAIN_CLICK);
            }
        });
        this.imgWifiList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        startActivity(new Intent(Wifi_MainActivity.this, WifiListActivity.class));
                    }
                }, MAIN_CLICK);
            }
        });
        this.imgScanQR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        if (!Settings.System.canWrite(Wifi_MainActivity.this)) {
                            Wifi_MainActivity.this.camaraDialog();
                        } else {
                            startActivity(new Intent(Wifi_MainActivity.this, Wifi_ScanQRActivity.class));
                        }
                    }
                }, MAIN_CLICK);
            }
        });
        this.imgShowPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        startActivity(new Intent(Wifi_MainActivity.this, WifiPasswordShowActivity.class));
                    }
                }, MAIN_CLICK);
            }
        });

        this.imgLiveLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        if (!((LocationManager) getSystemService(Context.LOCATION_SERVICE)).isProviderEnabled("gps")) {
                            locationDialog();
                        } else {
                            startActivity(new Intent(Wifi_MainActivity.this, Wifi_LiveLocationActivity.class));
                        }
                    }
                }, MAIN_CLICK);
            }
        });
        this.imgPhoneInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        startActivity(new Intent(Wifi_MainActivity.this, Wifi_PhoneInfoActivity.class));
                    }
                }, MAIN_CLICK);
            }
        });
        this.imgSignalStrength.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        startActivity(new Intent(Wifi_MainActivity.this, Wifi_SignalStrengthActivity.class));
                    }
                }, MAIN_CLICK);
            }
        });
        this.imgHosport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent("android.intent.action.MAIN", (Uri) null);
                        intent.addCategory("android.intent.category.LAUNCHER");
                        intent.setComponent(new ComponentName("com.android.settings", "com.android.settings.TetherSettings"));
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                getInstance(Wifi_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        startActivity(new Intent(Wifi_MainActivity.this, ExitActivity.class));
                    }
                }, BACK_CLICK);
            }
        };

        getOnBackPressedDispatcher().addCallback(this, callback);

    }

    public void locationDialog() {
        final Dialog dialog = new Dialog(Wifi_MainActivity.this);
        View inflate = LayoutInflater.from(Wifi_MainActivity.this).inflate(R.layout.location_permission_dialog, (ViewGroup) null);
        dialog.setCancelable(false);
        dialog.setContentView(inflate);
        TextView textView = (TextView) inflate.findViewById(R.id.text_cancle);
        TextView textView2 = (TextView) inflate.findViewById(R.id.text_okay);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        textView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!((LocationManager) Wifi_MainActivity.this.getSystemService(Context.LOCATION_SERVICE)).isProviderEnabled("gps")) {
                    startActivity(new Intent("android.settings.LOCATION_SOURCE_SETTINGS"));
                }
                dialog.dismiss();
            }
        });
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.show();
    }


    public void camaraDialog() {
        final Dialog dialog = new Dialog(this);
        View inflate = LayoutInflater.from(this).inflate(R.layout.camara_permission_dialog, (ViewGroup) null);
        dialog.setCancelable(false);
        dialog.setContentView(inflate);
        TextView textView = (TextView) inflate.findViewById(R.id.text_cancle);
        TextView textView2 = (TextView) inflate.findViewById(R.id.text_okay);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        textView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!Settings.System.canWrite(Wifi_MainActivity.this)) {
                    Wifi_MainActivity MainActivity = Wifi_MainActivity.this;
                    MainActivity.startActivity(new Intent("android.settings.action.MANAGE_WRITE_SETTINGS", Uri.parse("package:" + Wifi_MainActivity.this.getPackageName())));
                }
                dialog.dismiss();
            }
        });
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.show();
    }

    public void getPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            String[] strArr = {"android.permission.CAMERA", "android.permission.RECORD_AUDIO", "android.permission.ACCESS_FINE_LOCATION"};
            if (checkSelfPermission("android.permission.CAMERA") != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(strArr, this.REQUESTPERMISSIONCODE);
            }
        } else {
            String[] strArr2 = {"android.permission.CAMERA", "android.permission.RECORD_AUDIO", "android.permission.ACCESS_FINE_LOCATION"};
            if (checkSelfPermission("android.permission.CAMERA") != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(strArr2, this.REQUESTPERMISSIONCODE);
            }
        }
        if (((LocationManager) getSystemService(Context.LOCATION_SERVICE)).isProviderEnabled("gps")) {
            return;
        }
        startActivity(new Intent("android.settings.LOCATION_SOURCE_SETTINGS"));
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
