package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_extra;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_model.Wifi_ModelPassword;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_model.Wifi_ModelWifiPassword;

import java.util.ArrayList;


public class Wifi_MyData {
    SharedPreferences sharedPreferences;
    String keyData = "keyData";
    String keyPassword = "keyPassword";

    public Wifi_MyData(Context context) {
        this.sharedPreferences = context.getSharedPreferences("keyMyData", 0);
    }

    public ArrayList<Wifi_ModelWifiPassword> getList() {
        ArrayList<Wifi_ModelWifiPassword> arrayList = (ArrayList) new Gson().fromJson(this.sharedPreferences.getString(this.keyData, ""), new TypeToken<ArrayList<Wifi_ModelWifiPassword>>() { // from class: com.wifipasswordshow.wifiinfo.wifispeed.extra.MyData.1
        }.getType());
        return arrayList == null ? new ArrayList<>() : arrayList;
    }

    public void setList(ArrayList<Wifi_ModelWifiPassword> arrayList) {
        this.sharedPreferences.edit().putString(this.keyData, new Gson().toJson(arrayList)).apply();
    }

    public ArrayList<Wifi_ModelPassword> getPasswordList() {
        ArrayList<Wifi_ModelPassword> arrayList = (ArrayList) new Gson().fromJson(this.sharedPreferences.getString(this.keyPassword, ""), new TypeToken<ArrayList<Wifi_ModelPassword>>() { // from class: com.wifipasswordshow.wifiinfo.wifispeed.extra.MyData.2
        }.getType());
        return arrayList == null ? new ArrayList<>() : arrayList;
    }

    public void setPasswordList(ArrayList<Wifi_ModelPassword> arrayList) {
        this.sharedPreferences.edit().putString(this.keyPassword, new Gson().toJson(arrayList)).apply();
    }
}
