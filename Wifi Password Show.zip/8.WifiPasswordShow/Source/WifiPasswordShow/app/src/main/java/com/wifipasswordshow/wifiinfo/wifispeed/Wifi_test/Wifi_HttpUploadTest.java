package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_test;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public class Wifi_HttpUploadTest extends Thread {
    static int uploadedKByte;
    public String fileURL;
    long startTime;
    double uploadElapsedTime = Double.longBitsToDouble(1);
    boolean finished = false;
    double elapsedTime = Double.longBitsToDouble(1);
    double finalUploadRate = Double.longBitsToDouble(1);

    public Wifi_HttpUploadTest(String str) {
        this.fileURL = str;
    }

    private double round(double d, int i) {
        if (i < 0) {
            throw new IllegalArgumentException();
        }
        try {
            return new BigDecimal(d).setScale(i, RoundingMode.HALF_UP).doubleValue();
        } catch (Exception unused) {
            return Double.longBitsToDouble(1);
        }
    }

    public boolean isFinished() {
        return this.finished;
    }

    public double getInstantUploadRate() {
        try {
            new BigDecimal(uploadedKByte);
            if (uploadedKByte >= 0) {
                double currentTimeMillis = (System.currentTimeMillis() - this.startTime) / 1000.0d;
                this.elapsedTime = currentTimeMillis;
                return round(Double.valueOf(((uploadedKByte / 1000.0d) * 8.0d) / currentTimeMillis).doubleValue(), 2);
            }
            return Double.longBitsToDouble(1);
        } catch (Exception unused) {
            return Double.longBitsToDouble(1);
        }
    }

    public double getFinalUploadRate() {
        return round(this.finalUploadRate, 2);
    }

    @Override
    public void run() {
        try {
            URL url = new URL(this.fileURL);
            uploadedKByte = 0;
            this.startTime = System.currentTimeMillis();
            ExecutorService newFixedThreadPool = Executors.newFixedThreadPool(4);
            for (int i = 0; i < 4; i++) {
                newFixedThreadPool.execute(new com.wifipasswordshow.wifiinfo.wifispeed.Wifi_test.Wifi_HandlerUpload(url));
            }
            newFixedThreadPool.shutdown();
            while (!newFixedThreadPool.isTerminated()) {
                try {
                    Thread.sleep(100L);
                } catch (InterruptedException unused) {
                }
            }
            double currentTimeMillis = (System.currentTimeMillis() - this.startTime) / 1000.0d;
            this.uploadElapsedTime = currentTimeMillis;
            this.finalUploadRate = Double.valueOf(((uploadedKByte / 1000.0d) * 8.0d) / currentTimeMillis).doubleValue();
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.finished = true;
    }
}
