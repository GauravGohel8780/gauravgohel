package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_model;


public class Wifi_ModelPassword {
    String WifiPassword;
    int id;

    public Wifi_ModelPassword(int i, String str) {
        this.id = i;
        this.WifiPassword = str;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int i) {
        this.id = i;
    }

    public String getWifiPassword() {
        return this.WifiPassword;
    }

    public void setWifiPassword(String str) {
        this.WifiPassword = str;
    }
}
