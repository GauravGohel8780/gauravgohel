package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_activity;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.iten.tenoku.utils.AdConstant;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_extra.Wifi_BOOKER_SpManager;

import java.util.Locale;

public abstract class Wifi_BaseActivity extends AppCompatActivity {

    @Override
    public void attachBaseContext(Context context) {
        super.attachBaseContext(setLocale(context, getSelectedLanguage(context)));
    }


    public static Context setLocale(Context context, String str) {
        Locale locale = new Locale(str);
        Locale.setDefault(locale);
        Configuration configuration = new Configuration();
        configuration.setLocale(locale);
        return context.createConfigurationContext(configuration);
    }

    public static String getSelectedLanguage(Context context) {
        Wifi_BOOKER_SpManager.initializingSharedPreference(context);
        return Wifi_BOOKER_SpManager.getLanguageCodeSnip();
    }

    @Override
    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
    }

    @Override
    protected void onStart() {
        super.onStart();
        AdConstant.isResume = true;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
