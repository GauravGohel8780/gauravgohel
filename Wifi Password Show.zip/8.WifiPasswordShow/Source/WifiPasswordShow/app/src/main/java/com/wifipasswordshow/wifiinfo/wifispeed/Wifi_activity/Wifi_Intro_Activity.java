package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.wifipasswordshow.wifiinfo.wifispeed.R;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_adapter.Wifi_IntroViewPagerAdapter;
import com.wifipasswordshow.wifiinfo.wifispeed.databinding.ActivityIntroBinding;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_extra.Wifi_BOOKER_SpManager;


import java.util.ArrayList;

public class Wifi_Intro_Activity extends Wifi_BaseActivity {
    ActivityIntroBinding binding;
    Animation btnAnim;
    TextView btn_get_started;
    ImageView indicator_img;
    Wifi_IntroViewPagerAdapter introViewPagerAdapter;
    TextView next_text;
    int position = 0;
    private ViewPager screenPager;
    TabLayout tab_indicator;


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        SetSystemFullScreen(this);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        ActivityIntroBinding inflate = ActivityIntroBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView(inflate.getRoot());

        final ArrayList arrayList = new ArrayList();
        arrayList.add(new Wifi_ScreenItem(getString(R.string.text_title_a), getString(R.string.text_intro_a), R.drawable.ic_intro_logo_1));
        arrayList.add(new Wifi_ScreenItem(getString(R.string.text_title_b), getString(R.string.text_intro_b), R.drawable.ic_intro_logo_2));
        arrayList.add(new Wifi_ScreenItem(getString(R.string.text_title_c), getString(R.string.text_intro_c), R.drawable.ic_intro_logo_3));
        this.screenPager = (ViewPager) findViewById(R.id.screen_viewpager);
        this.tab_indicator = (TabLayout) findViewById(R.id.tab_indicator);
        this.indicator_img = (ImageView) findViewById(R.id.indicator_img);
        this.next_text = (TextView) findViewById(R.id.next_text);
        this.btn_get_started = (TextView) findViewById(R.id.btn_get_started);
        Wifi_IntroViewPagerAdapter introViewPagerAdapter = new Wifi_IntroViewPagerAdapter(this, arrayList);
        this.introViewPagerAdapter = introViewPagerAdapter;
        this.screenPager.setAdapter(introViewPagerAdapter);
        this.tab_indicator.setupWithViewPager(this.screenPager);
        findViewById(R.id.next_text).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_Intro_Activity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Wifi_Intro_Activity intro_Activity = Wifi_Intro_Activity.this;
                        intro_Activity.position = intro_Activity.screenPager.getCurrentItem();
                        if (Wifi_Intro_Activity.this.position < arrayList.size()) {
                            Wifi_Intro_Activity.this.position++;
                            Wifi_Intro_Activity.this.screenPager.setCurrentItem(Wifi_Intro_Activity.this.position);
                        }
                        if (Wifi_Intro_Activity.this.position == arrayList.size() - 1) {
                            Wifi_Intro_Activity.this.loaddLastScreen();
                        }
                    }
                }, MAIN_CLICK);

            }
        });
        this.tab_indicator.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    Wifi_Intro_Activity.this.indicator_img.setImageResource(R.drawable.ic_intro_page_1);
                } else if (tab.getPosition() == 1) {
                    Wifi_Intro_Activity.this.indicator_img.setImageResource(R.drawable.ic_intro_page_2);
                } else if (tab.getPosition() == 2) {
                    Wifi_Intro_Activity.this.indicator_img.setImageResource(R.drawable.ic_intro_page_3);
                }
                if (tab.getPosition() == arrayList.size() - 1) {
                    Wifi_Intro_Activity.this.loaddLastScreen();
                }
                if (tab.getPosition() == arrayList.size() - 2) {
                    Wifi_Intro_Activity.this.next_text.setVisibility(View.VISIBLE);
                    Wifi_Intro_Activity.this.btn_get_started.setVisibility(View.INVISIBLE);
                    Wifi_Intro_Activity.this.tab_indicator.setVisibility(View.INVISIBLE);
                }
            }
        });
        this.btn_get_started.setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                getInstance(Wifi_Intro_Activity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Wifi_BOOKER_SpManager.initializingSharedPreference(Wifi_Intro_Activity.this);
                        Wifi_BOOKER_SpManager.setGuideCompleted(true);
                        startActivity(new Intent(Wifi_Intro_Activity.this, Wifi_MainActivity.class));
                    }
                }, MAIN_CLICK);
            }
        });
    }

    public void loaddLastScreen() {
        this.next_text.setVisibility(View.INVISIBLE);
        this.btn_get_started.setVisibility(View.VISIBLE);
        this.tab_indicator.setVisibility(View.INVISIBLE);
        this.btn_get_started.setAnimation(this.btnAnim);
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        finishAffinity();
    }


    public static void SetSystemFullScreen(Activity activity) {
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) {
            View v = activity.getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            View decorView = activity.getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
