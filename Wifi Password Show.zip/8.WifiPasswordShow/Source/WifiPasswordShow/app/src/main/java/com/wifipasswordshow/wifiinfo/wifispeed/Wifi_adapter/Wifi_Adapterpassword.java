package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.wifipasswordshow.wifiinfo.wifispeed.R;

import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_model.Wifi_ModelPassword;




import java.util.ArrayList;


public class Wifi_Adapterpassword extends RecyclerView.Adapter<Wifi_Adapterpassword.ViewHolder> {
    ArrayList<Wifi_ModelPassword> list;
    OnClickItemListener mOnClickItemListener;

    public interface OnClickItemListener {
        void onClickItem(int i);
    }

    public Wifi_Adapterpassword(ArrayList<Wifi_ModelPassword> arrayList, OnClickItemListener onClickItemListener) {
        this.list = arrayList;
        this.mOnClickItemListener = onClickItemListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.password_save_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, int i) {
        viewHolder.textWifiName.setText(this.list.get(i).getWifiPassword());
        viewHolder.btConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Wifi_Adapterpassword.this.mOnClickItemListener.onClickItem(viewHolder.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.list.size();
    }

    
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView btConnect;
        TextView textWifiName;

        public ViewHolder(View view) {
            super(view);
            this.btConnect = (TextView) view.findViewById(R.id.text_copy);
            this.textWifiName = (TextView) view.findViewById(R.id.text_password);
        }
    }
}
