package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_model;


public class Wifi_LanguageModel_new {
    public int drawRes;
    public String lan_code;
    public String lan_name;

    public Wifi_LanguageModel_new(String str, String str2, int i) {
        this.lan_code = str;
        this.lan_name = str2;
        this.drawRes = i;
    }
}
