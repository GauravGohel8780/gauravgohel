package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.github.anastr.speedviewlib.PointerSpeedometer;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.wifipasswordshow.wifiinfo.wifispeed.R;

import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_test.Wifi_GetSpeedTestHostsHandler;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_test.Wifi_HttpDownloadTest;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_test.Wifi_HttpUploadTest;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_test.Wifi_PingTest;



import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;


public class Wifi_SpeedTestActivity extends Wifi_BaseActivity {
    static int lastPosition = 0;
    static int position = 0;
    Context context;
    Wifi_GetSpeedTestHostsHandler getSpeedTestHostsHandler = null;
    ImageView imgBack;
    ImageView imgDownload;
    ImageView imgPing;
    ImageView imgUpload;
    ConstraintLayout main;
    ConstraintLayout main2;
    PointerSpeedometer speedometerDown;
    PointerSpeedometer speedometerUp;
    HashSet<String> tempBlackList;
    TextView textDownload;
    TextView textMbps;
    TextView textSatart;
    TextView textSpeed;
    TextView textUpload;
    ConstraintLayout topBar;

    public int getPositionByRate(double d) {
        if (d <= 1.0d) {
            return (int) (d * 30.0d);
        }
        if (d <= 10.0d) {
            return ((int) (d * 6.0d)) + 30;
        }
        if (d <= 30.0d) {
            return ((int) ((d - 10.0d) * 3.0d)) + 90;
        }
        if (d <= 50.0d) {
            return ((int) ((d - 30.0d) * 1.5d)) + 150;
        }
        if (d <= 100.0d) {
            return ((int) ((d - 50.0d) * 1.2d)) + 180;
        }
        return 0;
    }

    @Override
    public void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
        Wifi_GetSpeedTestHostsHandler getSpeedTestHostsHandler = new Wifi_GetSpeedTestHostsHandler();
        this.getSpeedTestHostsHandler = getSpeedTestHostsHandler;
        getSpeedTestHostsHandler.start();
    }

   
    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_speed_test);
        this.context = this;
        this.textDownload = (TextView) findViewById(R.id.text_download);
        this.imgBack = (ImageView) findViewById(R.id.img_back_language);
        this.imgPing = (ImageView) findViewById(R.id.img_ping);
        this.imgDownload = (ImageView) findViewById(R.id.img_download);
        this.imgUpload = (ImageView) findViewById(R.id.img_upload);
        this.topBar = (ConstraintLayout) findViewById(R.id.constraint_action_bar_layout);
        this.main = (ConstraintLayout) findViewById(R.id.constraint_main);
        this.main2 = (ConstraintLayout) findViewById(R.id.constraint_main_2);
        this.textUpload = (TextView) findViewById(R.id.text_upload);
        this.textSatart = (TextView) findViewById(R.id.text_start);
        this.textSpeed = (TextView) findViewById(R.id.text_speed);
        this.textMbps = (TextView) findViewById(R.id.text_mbps);
        this.speedometerDown = (PointerSpeedometer) findViewById(R.id.dlGauge);
        this.speedometerUp = (PointerSpeedometer) findViewById(R.id.ulGauge);
        TextView textView = this.textSatart;
        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        textView.setText(getString(R.string.begin_test));
        this.tempBlackList = new HashSet<>();
        Wifi_GetSpeedTestHostsHandler getSpeedTestHostsHandler = new Wifi_GetSpeedTestHostsHandler();
        this.getSpeedTestHostsHandler = getSpeedTestHostsHandler;
        getSpeedTestHostsHandler.start();
        this.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_SpeedTestActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Wifi_SpeedTestActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                        new AnonymousClass2(textView, decimalFormat);

            }
        });
    }

    class AnonymousClass2 implements View.OnClickListener {
        final DecimalFormat val$dec;
        final TextView val$startButton;

        AnonymousClass2(TextView textView, DecimalFormat decimalFormat) {
            this.val$startButton = textView;
            this.val$dec = decimalFormat;
        }

        @Override
        public void onClick(View view) {
            this.val$startButton.setEnabled(false);
            this.val$startButton.setSelected(true);
            if (Wifi_SpeedTestActivity.this.getSpeedTestHostsHandler == null) {
                Wifi_SpeedTestActivity.this.getSpeedTestHostsHandler = new Wifi_GetSpeedTestHostsHandler();
                Wifi_SpeedTestActivity.this.getSpeedTestHostsHandler.start();
            }
            new Thread(new AnonymousClass1()).start();
        }
        
        class AnonymousClass1 implements Runnable {
            TextView downloadTextView;
            TextView pingTextView;
            RotateAnimation rotate;
            TextView uploadTextView;

            AnonymousClass1() {
                this.pingTextView = (TextView) Wifi_SpeedTestActivity.this.findViewById(R.id.text_ping);
                this.downloadTextView = (TextView) Wifi_SpeedTestActivity.this.findViewById(R.id.text_download);
                this.uploadTextView = (TextView) Wifi_SpeedTestActivity.this.findViewById(R.id.text_upload);
            }

            @Override 
            public void run() {
                boolean z;
                Wifi_SpeedTestActivity.this.runOnUiThread(new Runnable() {
                    @Override 
                    public void run() {
                        AnonymousClass2.this.val$startButton.setText(Wifi_SpeedTestActivity.this.getString(R.string.test_server_selecting));
                    }
                });
                int i = 600;
                while (!Wifi_SpeedTestActivity.this.getSpeedTestHostsHandler.isFinished()) {
                    i--;
                    try {
                        Thread.sleep(100L);
                        continue;
                    } catch (InterruptedException unused) {
                    }
                    if (i <= 0) {
                        Wifi_SpeedTestActivity.this.runOnUiThread(new Runnable() {
                            @Override 
                            public void run() {
                                Toast.makeText(Wifi_SpeedTestActivity.this.getApplicationContext(), (int) R.string.text_no_net, Toast.LENGTH_LONG).show();
                                AnonymousClass2.this.val$startButton.setEnabled(true);
                                AnonymousClass2.this.val$startButton.setSelected(false);
                                AnonymousClass2.this.val$startButton.setText(Wifi_SpeedTestActivity.this.getString(R.string.restart_test));
                                AnonymousClass2.this.val$startButton.setTextColor(Wifi_SpeedTestActivity.this.getColor(R.color.white));
                            }
                        });
                        Wifi_SpeedTestActivity.this.getSpeedTestHostsHandler = null;
                        return;
                    }
                }
                HashMap<Integer, String> mapKey = Wifi_SpeedTestActivity.this.getSpeedTestHostsHandler.getMapKey();
                HashMap<Integer, List<String>> mapValue = Wifi_SpeedTestActivity.this.getSpeedTestHostsHandler.getMapValue();
                double selfLat = Wifi_SpeedTestActivity.this.getSpeedTestHostsHandler.getSelfLat();
                double selfLon = Wifi_SpeedTestActivity.this.getSpeedTestHostsHandler.getSelfLon();
                Iterator<Integer> it = mapKey.keySet().iterator();
                double d = 1.9349458E7d;
                final double d2 = Double.longBitsToDouble(1);
                int i2 = 0;
                while (it.hasNext()) {
                    int intValue = it.next().intValue();
                    Iterator<Integer> it2 = it;
                    if (Wifi_SpeedTestActivity.this.tempBlackList.contains(mapValue.get(Integer.valueOf(intValue)).get(5))) {
                        it = it2;
                    } else {
                        Location location = new Location("Source");
                        location.setLatitude(selfLat);
                        location.setLongitude(selfLon);
                        List<String> list = mapValue.get(Integer.valueOf(intValue));
                        double d3 = selfLat;
                        Location location2 = new Location("Dest");
                        location2.setLatitude(Double.parseDouble(list.get(0)));
                        location2.setLongitude(Double.parseDouble(list.get(1)));
                        double distanceTo = location.distanceTo(location2);
                        if (d > distanceTo) {
                            d = distanceTo;
                            i2 = intValue;
                        }
                        it = it2;
                        selfLat = d3;
                    }
                }
                String replace = mapKey.get(Integer.valueOf(i2)).replace("http://", "https://");
                final List<String> list2 = mapValue.get(Integer.valueOf(i2));
                if (list2 == null) {
                    Wifi_SpeedTestActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            AnonymousClass2.this.val$startButton.setText(Wifi_SpeedTestActivity.this.getString(R.string.speed_test_error));
                        }
                    });
                    return;
                }
                Wifi_SpeedTestActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        TextView textView = AnonymousClass2.this.val$startButton;
                            textView.setText((Wifi_SpeedTestActivity.this.getString(R.string.host_location) + " " + ((String) list2.get(2))) + " " + (Wifi_SpeedTestActivity.this.getString(R.string.distance) + " " + new DecimalFormat("#.##").format(d2 / 1000.0d)));
                        AnonymousClass2.this.val$startButton.setTextColor(Wifi_SpeedTestActivity.this.getColor(R.color.black));
                    }
                });
                Wifi_SpeedTestActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        AnonymousClass1.this.pingTextView.setText("0 ms");
                        AnonymousClass1.this.downloadTextView.setText("0 Mbps");
                        AnonymousClass1.this.uploadTextView.setText("0 Mbps");
                    }
                });
                ArrayList arrayList = new ArrayList();
                ArrayList arrayList2 = new ArrayList();
                ArrayList arrayList3 = new ArrayList();
                Boolean bool = false;
                Boolean bool2 = false;
                Boolean bool3 = false;
                Boolean bool4 = false;
                Boolean bool5 = false;
                Boolean bool6 = false;
                final Wifi_PingTest pingTest = new Wifi_PingTest(list2.get(6).replace(":8080", ""), 3);
                boolean z2 = true;
                final Wifi_HttpDownloadTest httpDownloadTest = new Wifi_HttpDownloadTest(replace.replace(replace.split("/")[replace.split("/").length - 1], ""));
                Wifi_HttpUploadTest httpUploadTest = new Wifi_HttpUploadTest(replace);
                while (true) {
                    if (!bool.booleanValue()) {
                        pingTest.start();
                        bool = Boolean.valueOf(z2);
                    }
                    if (bool2.booleanValue() && !bool3.booleanValue()) {
                        httpDownloadTest.start();
                        bool3 = Boolean.valueOf(z2);
                    }
                    if (bool4.booleanValue() && !bool5.booleanValue()) {
                        httpUploadTest.start();
                        bool5 = Boolean.valueOf(z2);
                    }
                    if (bool2.booleanValue()) {
                        if (pingTest.getAvgRtt() == Double.longBitsToDouble(1)) {
                            System.out.println("Ping error...");
                        } else {
                            Wifi_SpeedTestActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    TextView textView = AnonymousClass1.this.pingTextView;
                                    textView.setText(AnonymousClass2.this.val$dec.format(pingTest.getAvgRtt()) + " ms");
                                }
                            });
                        }
                    } else {
                        arrayList.add(Double.valueOf(pingTest.getInstantRtt()));
                        Wifi_SpeedTestActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                TextView textView = AnonymousClass1.this.pingTextView;
                                textView.setText(AnonymousClass2.this.val$dec.format(pingTest.getInstantRtt()) + " ms");
                            }
                        });
                        Wifi_SpeedTestActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                            }
                        });
                    }
                    if (bool2.booleanValue()) {
                        if (bool4.booleanValue()) {
                            if (httpDownloadTest.getFinalDownloadRate() == Double.longBitsToDouble(1)) {
                                System.out.println("Download error...");
                            } else {
                                Wifi_SpeedTestActivity.this.runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        String format = AnonymousClass2.this.val$dec.format(httpDownloadTest.getFinalDownloadRate());
                                        Wifi_SpeedTestActivity.this.speedometerDown.speedTo(Float.valueOf(format).floatValue());
                                        TextView textView = AnonymousClass1.this.downloadTextView;
                                        textView.setText(format + " mbps");
                                        Wifi_SpeedTestActivity.this.textSpeed.setText(Wifi_SpeedTestActivity.this.getString(R.string.text_download_speed));
                                        TextView textView2 = Wifi_SpeedTestActivity.this.textMbps;
                                        textView2.setText(format + " mbps");
                                    }
                                });
                            }
                        } else {
                            double instantDownloadRate = httpDownloadTest.getInstantDownloadRate();
                            arrayList2.add(Double.valueOf(instantDownloadRate));
                            Wifi_SpeedTestActivity.position = Wifi_SpeedTestActivity.this.getPositionByRate(instantDownloadRate);
                            Wifi_SpeedTestActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    AnonymousClass1.this.rotate = new RotateAnimation(Wifi_SpeedTestActivity.lastPosition, Wifi_SpeedTestActivity.position, 1, 0.5f, 1, 0.5f);
                                    AnonymousClass1.this.rotate.setInterpolator(new LinearInterpolator());
                                    AnonymousClass1.this.rotate.setDuration(100L);
                                    String format = AnonymousClass2.this.val$dec.format(httpDownloadTest.getInstantDownloadRate());
                                    Wifi_SpeedTestActivity.this.speedometerDown.speedTo(Float.valueOf(format).floatValue());
                                    TextView textView = AnonymousClass1.this.downloadTextView;
                                    textView.setText(format + " mbps");
                                    Wifi_SpeedTestActivity.this.textSpeed.setText(Wifi_SpeedTestActivity.this.getString(R.string.text_download_speed));
                                    TextView textView2 = Wifi_SpeedTestActivity.this.textMbps;
                                    textView2.setText(format + " mbps");
                                }
                            });
                            Wifi_SpeedTestActivity.lastPosition = Wifi_SpeedTestActivity.position;
                            Wifi_SpeedTestActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                }
                            });
                        }
                    }
                    if (bool4.booleanValue()) {
                        if (bool6.booleanValue()) {
                            if (httpUploadTest.getFinalUploadRate() == Double.longBitsToDouble(1)) {
                                System.out.println("Upload error...");
                            } else {
                                Wifi_SpeedTestActivity.this.runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Wifi_SpeedTestActivity.this.speedometerDown.setSpeedAt(-5.0f);
                                        String format = AnonymousClass2.this.val$dec.format(httpDownloadTest.getFinalDownloadRate());
                                        Wifi_SpeedTestActivity.this.speedometerUp.speedTo(Float.valueOf(format).floatValue());
                                        TextView textView = AnonymousClass1.this.uploadTextView;
                                        textView.setText(format + " mbps");
                                        Wifi_SpeedTestActivity.this.textSpeed.setText(Wifi_SpeedTestActivity.this.getString(R.string.text_upload_speed));
                                        TextView textView2 = Wifi_SpeedTestActivity.this.textMbps;
                                        textView2.setText(format + " mbps");
                                    }
                                });
                            }
                        } else {
                            double instantUploadRate = httpUploadTest.getInstantUploadRate();
                            arrayList3.add(Double.valueOf(instantUploadRate));
                            Wifi_SpeedTestActivity.position = Wifi_SpeedTestActivity.this.getPositionByRate(instantUploadRate);
                            Wifi_SpeedTestActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    AnonymousClass1.this.rotate = new RotateAnimation(Wifi_SpeedTestActivity.lastPosition, Wifi_SpeedTestActivity.position, 1, 0.5f, 1, 0.5f);
                                    AnonymousClass1.this.rotate.setInterpolator(new LinearInterpolator());
                                    AnonymousClass1.this.rotate.setDuration(100L);
                                    Wifi_SpeedTestActivity.this.speedometerDown.setSpeedAt(-5.0f);
                                    String format = AnonymousClass2.this.val$dec.format(httpDownloadTest.getInstantDownloadRate());
                                    Wifi_SpeedTestActivity.this.speedometerUp.speedTo(Float.valueOf(format).floatValue());
                                    TextView textView = AnonymousClass1.this.uploadTextView;
                                    textView.setText(format + " mbps");
                                    Wifi_SpeedTestActivity.this.textSpeed.setText(Wifi_SpeedTestActivity.this.getString(R.string.text_upload_speed));
                                    TextView textView2 = Wifi_SpeedTestActivity.this.textMbps;
                                    textView2.setText(format + " mbps");
                                }
                            });
                            Wifi_SpeedTestActivity.lastPosition = Wifi_SpeedTestActivity.position;
                            Wifi_SpeedTestActivity.this.runOnUiThread(new Runnable() {
                                @Override 
                                public void run() {
                                }
                            });
                        }
                    }
                    if (!bool2.booleanValue() || !bool4.booleanValue() || !httpUploadTest.isFinished()) {
                        if (pingTest.isFinished()) {
                            z = true;
                            bool2 = true;
                        } else {
                            z = true;
                        }
                        if (httpDownloadTest.isFinished()) {
                            bool4 = Boolean.valueOf(z);
                        }
                        if (httpUploadTest.isFinished()) {
                            bool6 = Boolean.valueOf(z);
                        }
                        if (bool.booleanValue() && !bool2.booleanValue()) {
                            try {
                                Thread.sleep(300L);
                            } catch (InterruptedException unused2) {
                            }
                        } else {
                            try {
                                Thread.sleep(100L);
                            } catch (InterruptedException unused3) {
                            }
                        }
                        z2 = z;
                    } else {
                        Wifi_SpeedTestActivity.this.runOnUiThread(new Runnable() {
                            @Override 
                            public void run() {
                                Wifi_SpeedTestActivity.this.speedometerUp.setSpeedAt(0.0f);
                                Wifi_SpeedTestActivity.this.speedometerDown.setSpeedAt(0.0f);
                                AnonymousClass2.this.val$startButton.setEnabled(true);
                                AnonymousClass2.this.val$startButton.setSelected(false);
                                AnonymousClass2.this.val$startButton.setText(Wifi_SpeedTestActivity.this.getString(R.string.restart_test));
                                AnonymousClass2.this.val$startButton.setTextColor(Wifi_SpeedTestActivity.this.getColor(R.color.white));
                            }
                        });
                        return;
                    }
                }
            }
        }
    }

}
