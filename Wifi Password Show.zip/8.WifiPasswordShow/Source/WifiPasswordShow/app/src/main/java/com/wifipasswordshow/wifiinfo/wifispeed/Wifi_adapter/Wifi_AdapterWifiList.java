package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_adapter;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.wifipasswordshow.wifiinfo.wifispeed.R;


import java.util.ArrayList;


public class Wifi_AdapterWifiList extends RecyclerView.Adapter<Wifi_AdapterWifiList.ViewHolder> {
    ArrayList<String> list;
    OnClickItemListener mOnClickItemListener;

    
    public interface OnClickItemListener {
        void onClickItem(int i);
    }

    public Wifi_AdapterWifiList(ArrayList<String> arrayList, OnClickItemListener onClickItemListener) {
        this.list = arrayList;
        this.mOnClickItemListener = onClickItemListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.wifi_list_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, int i) {
        viewHolder.textWifiName.setText(this.list.get(i));
        WifiManager wifiManager = (WifiManager) viewHolder.itemView.getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (this.list.get(i).equals(wifiManager.getConnectionInfo().getSSID().replace("\"", ""))) {
            Log.d("TAG", "onBindViewHolder: Conect " + wifiManager.getConnectionInfo().getSSID());
            viewHolder.btConnect.setVisibility(View.GONE);
        }
        viewHolder.btConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Wifi_AdapterWifiList.this.mOnClickItemListener.onClickItem(viewHolder.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.list.size();
    }

    
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView btConnect;
        ImageView imgWifi;
        ConstraintLayout main;
        TextView textWifiName;

        public ViewHolder(View view) {
            super(view);
            this.imgWifi = (ImageView) view.findViewById(R.id.img_wifi);
            this.btConnect = (TextView) view.findViewById(R.id.bt_conect);
            this.textWifiName = (TextView) view.findViewById(R.id.text_wifi_name);
            this.main = (ConstraintLayout) view.findViewById(R.id.main);
        }
    }
}
