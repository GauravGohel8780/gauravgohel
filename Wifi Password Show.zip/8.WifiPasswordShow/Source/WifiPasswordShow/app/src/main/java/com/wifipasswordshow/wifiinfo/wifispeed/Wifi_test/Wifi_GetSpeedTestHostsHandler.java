package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class Wifi_GetSpeedTestHostsHandler extends Thread {
    HashMap<Integer, String> mapKey = new HashMap<>();
    HashMap<Integer, List<String>> mapValue = new HashMap<>();
    double selfLat = Double.longBitsToDouble(1);
    double selfLon = Double.longBitsToDouble(1);
    boolean finished = false;

    public HashMap<Integer, String> getMapKey() {
        return this.mapKey;
    }

    public HashMap<Integer, List<String>> getMapValue() {
        return this.mapValue;
    }

    public double getSelfLat() {
        return this.selfLat;
    }

    public double getSelfLon() {
        return this.selfLon;
    }

    public boolean isFinished() {
        return this.finished;
    }

    @Override
    public void run() {
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL("https://www.speedtest.net/speedtest-config.php").openConnection();
            char c = 0;
            char c2 = 1;
            if (httpURLConnection.getResponseCode() == 200) {
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                while (true) {
                    String readLine = bufferedReader.readLine();
                    if (readLine != null) {
                        if (readLine.contains("isp=")) {
                            this.selfLat = Double.parseDouble(readLine.split("lat=\"")[1].split(" ")[0].replace("\"", ""));
                            this.selfLon = Double.parseDouble(readLine.split("lon=\"")[1].split(" ")[0].replace("\"", ""));
                            break;
                        }
                    } else {
                        break;
                    }
                }
                bufferedReader.close();
            }
            try {
                HttpURLConnection httpURLConnection2 = (HttpURLConnection) new URL("https://www.speedtest.net/speedtest-servers-static.php").openConnection();
                if (httpURLConnection2.getResponseCode() == 200) {
                    BufferedReader bufferedReader2 = new BufferedReader(new InputStreamReader(httpURLConnection2.getInputStream()));
                    int i = 0;
                    while (true) {
                        String readLine2 = bufferedReader2.readLine();
                        if (readLine2 == null) {
                            break;
                        } else if (readLine2.contains("<server url")) {
                            String str = readLine2.split("server url=\"")[c2].split("\"")[c];
                            String str2 = readLine2.split("lat=\"")[c2].split("\"")[c];
                            String str3 = readLine2.split("lon=\"")[c2].split("\"")[c];
                            String str4 = readLine2.split("name=\"")[c2].split("\"")[c];
                            String str5 = readLine2.split("country=\"")[c2].split("\"")[c];
                            String str6 = readLine2.split("cc=\"")[c2].split("\"")[c];
                            String str7 = readLine2.split("sponsor=\"")[c2].split("\"")[c];
                            c = 0;
                            List<String> asList = Arrays.asList(str2, str3, str4, str5, str6, str7, readLine2.split("host=\"")[c2].split("\"")[0]);
                            this.mapKey.put(Integer.valueOf(i), str);
                            this.mapValue.put(Integer.valueOf(i), asList);
                            i++;
                            c2 = 1;
                        }
                    }
                    bufferedReader2.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            this.finished = true;
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }
}
