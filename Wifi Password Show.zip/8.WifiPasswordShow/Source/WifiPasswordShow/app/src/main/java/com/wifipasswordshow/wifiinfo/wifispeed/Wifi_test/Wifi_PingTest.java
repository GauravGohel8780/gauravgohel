package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Wifi_PingTest extends Thread {
    int count;
    String server;
    double instantRtt = Double.longBitsToDouble(1);
    double avgRtt = Double.longBitsToDouble(1);
    boolean finished = false;

    public Wifi_PingTest(String str, int i) {
        this.server = str;
        this.count = i;
    }

    public double getAvgRtt() {
        return this.avgRtt;
    }

    public double getInstantRtt() {
        return this.instantRtt;
    }

    public boolean isFinished() {
        return this.finished;
    }

    @Override
    public void run() {
        Process start = null;
        BufferedReader bufferedReader = null;
        try {
            ProcessBuilder processBuilder = new ProcessBuilder("ping", "-c " + this.count, this.server);
            processBuilder.redirectErrorStream(true);
            start = processBuilder.start();
            bufferedReader = new BufferedReader(new InputStreamReader(start.getInputStream()));
            String readLine;
            while ((readLine = bufferedReader.readLine()) != null) {
                if (readLine.contains("icmp_seq")) {
                    this.instantRtt = Double.parseDouble(readLine.split(" ")[readLine.split(" ").length - 2].replace("time=", ""));
                }
                if (readLine.startsWith("rtt ")) {
                    this.avgRtt = Double.parseDouble(readLine.split("/")[4]);
                } else if (readLine.contains("Unreachable") || readLine.contains("Unknown")) {
                    break;
                }
                if (readLine.contains("%100 packet loss")) {
                    break;
                }
            }
            start.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        } finally {
            if (bufferedReader != null) {
                try {
                    bufferedReader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (start != null) {
                start.destroy();
            }
            this.finished = true;
        }
    }

}
