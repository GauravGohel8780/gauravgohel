package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_model;


public class Wifi_ModelWifiPassword {
    String WifiName;
    String WifiPassword;
    int id;

    public Wifi_ModelWifiPassword(int i, String str, String str2) {
        this.id = i;
        this.WifiName = str;
        this.WifiPassword = str2;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int i) {
        this.id = i;
    }

    public String getWifiName() {
        return this.WifiName;
    }

    public void setWifiName(String str) {
        this.WifiName = str;
    }

    public String getWifiPassword() {
        return this.WifiPassword;
    }

    public void setWifiPassword(String str) {
        this.WifiPassword = str;
    }
}
