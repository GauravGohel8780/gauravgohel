package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Context;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.wifipasswordshow.wifiinfo.wifispeed.R;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_adapter.Wifi_AdapterWifiPassword;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_extra.Wifi_MyData;

import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_model.Wifi_ModelWifiPassword;



import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class WifiPasswordShowActivity extends Wifi_BaseActivity {
    Context context;
    ImageView imgBack;
    ImageView imgData;
    ArrayList<Wifi_ModelWifiPassword> list;
    Wifi_MyData myData;
    RecyclerView recyclerView;
    TextView textNoData;
    ConstraintLayout topBar;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_wifi_password_show);
        this.context = this;
        this.topBar = (ConstraintLayout) findViewById(R.id.constraint_action_bar_layout);
        this.imgBack = (ImageView) findViewById(R.id.img_back_language);
        this.imgData = (ImageView) findViewById(R.id.img_no_data);
        this.textNoData = (TextView) findViewById(R.id.text_no_data);
        this.recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        Wifi_MyData myData = new Wifi_MyData(this.context);
        this.myData = myData;
        this.list = myData.getList();
        if (Build.VERSION.SDK_INT >= 24) {
            Collections.sort(this.list, new Comparator<Wifi_ModelWifiPassword>() {
                @Override
                public int compare(Wifi_ModelWifiPassword modelWifiPassword, Wifi_ModelWifiPassword modelWifiPassword2) {
                    return modelWifiPassword.getId() - modelWifiPassword2.getId();
                }
            }.reversed());
        }
        this.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(WifiPasswordShowActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        WifiPasswordShowActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        Wifi_AdapterWifiPassword adapterWifiPassword = new Wifi_AdapterWifiPassword(this.list, new Wifi_AdapterWifiPassword.OnClickItemListener() {
            @Override
            public void onClickItem(int i) {
            }
        });
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this.context, RecyclerView.VERTICAL, false));
        this.recyclerView.setAdapter(adapterWifiPassword);
        
        
        
        if (this.list.isEmpty()) {
            this.imgData.setVisibility(View.VISIBLE);
            this.textNoData.setVisibility(View.VISIBLE);
            return;
        }
        this.imgData.setVisibility(View.INVISIBLE);
        this.textNoData.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
