package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.wifipasswordshow.wifiinfo.wifispeed.R;

import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_model.Wifi_LanguageModel_new;

import java.util.List;


public class Wifi_LanguageAdapter_new extends RecyclerView.Adapter<Wifi_LanguageAdapter_new.MyViewHolder> {
    Context context;
    public List<Wifi_LanguageModel_new> languageList;
    OnClickItemListener mOnClickItemListener;
    int postrue;

    
    public interface OnClickItemListener {
        void onClickItem(Wifi_LanguageModel_new languageModel_new, int i);
    }

    public Wifi_LanguageAdapter_new(List<Wifi_LanguageModel_new> list, Context context, OnClickItemListener onClickItemListener, int i) {
        this.languageList = list;
        this.context = context;
        this.mOnClickItemListener = onClickItemListener;
        this.postrue = i;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.language_list_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(final MyViewHolder myViewHolder, int i) {
        myViewHolder.flag_img.setImageResource(this.languageList.get(myViewHolder.getAdapterPosition()).drawRes);
        myViewHolder.lan_name.setText(this.languageList.get(myViewHolder.getAdapterPosition()).lan_name);
        if (this.postrue == i) {
            myViewHolder.main.setBackgroundResource(R.drawable.ic_bg_blue_border);
        } else {
            myViewHolder.main.setBackgroundResource(R.drawable.ic_bg_blue);
        }
        myViewHolder.main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Wifi_LanguageAdapter_new.this.postrue = myViewHolder.getAdapterPosition();
                Wifi_LanguageAdapter_new.this.mOnClickItemListener.onClickItem(Wifi_LanguageAdapter_new.this.languageList.get(myViewHolder.getAdapterPosition()), Wifi_LanguageAdapter_new.this.postrue);
                Wifi_LanguageAdapter_new.this.notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.languageList.size();
    }

    
    public static class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView flag_img;
        TextView lan_name;
        ConstraintLayout main;

        public MyViewHolder(View view) {
            super(view);
            this.flag_img = (ImageView) view.findViewById(R.id.img_language);
            this.lan_name = (TextView) view.findViewById(R.id.text_language);
            this.main = (ConstraintLayout) view.findViewById(R.id.main);
        }
    }
}
