package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.wifipasswordshow.wifiinfo.wifispeed.R;

import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_model.Wifi_ModelWifiPassword;

import java.util.ArrayList;


public class Wifi_AdapterWifiPassword extends RecyclerView.Adapter<Wifi_AdapterWifiPassword.ViewHolder> {
    ArrayList<Wifi_ModelWifiPassword> list;
    OnClickItemListener mOnClickItemListener;
    
    public interface OnClickItemListener {
        void onClickItem(int i);
    }

    public Wifi_AdapterWifiPassword(ArrayList<Wifi_ModelWifiPassword> arrayList, OnClickItemListener onClickItemListener) {
        this.list = arrayList;
        this.mOnClickItemListener = onClickItemListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.wifi_password_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        Wifi_ModelWifiPassword modelWifiPassword = this.list.get(i);
        viewHolder.textWifiName.setText(modelWifiPassword.getWifiName());
        viewHolder.textWifiPassword.setText(modelWifiPassword.getWifiPassword());
    }

    @Override
    public int getItemCount() {
        return this.list.size();
    }

    
    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgDivider;
        ImageView imgPassword;
        ImageView imgWifi;
        ConstraintLayout main;
        TextView textWifiName;
        TextView textWifiPassword;

        public ViewHolder(View view) {
            super(view);
            this.textWifiPassword = (TextView) view.findViewById(R.id.text_wifi_password);
            this.textWifiName = (TextView) view.findViewById(R.id.text_wifi_name);
            this.imgWifi = (ImageView) view.findViewById(R.id.img_wifi);
            this.imgPassword = (ImageView) view.findViewById(R.id.img_password);
            this.imgDivider = (ImageView) view.findViewById(R.id.img_divider);
            this.main = (ConstraintLayout) view.findViewById(R.id.main);
        }
    }
}
