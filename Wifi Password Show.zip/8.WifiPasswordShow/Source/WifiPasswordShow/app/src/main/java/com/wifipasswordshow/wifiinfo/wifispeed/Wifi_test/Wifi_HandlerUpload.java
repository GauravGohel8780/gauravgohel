package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_test;

import java.io.DataOutputStream;
import java.net.URL;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;

class Wifi_HandlerUpload extends Thread {
    URL url;

    public Wifi_HandlerUpload(URL url) {
        this.url = url;
    }

    @Override
    public void run() {
        byte[] bArr = new byte[153600];
        long currentTimeMillis = System.currentTimeMillis();
        while (true) {
            try {
                HttpsURLConnection httpsURLConnection = (HttpsURLConnection) this.url.openConnection();
                httpsURLConnection.setDoOutput(true);
                httpsURLConnection.setRequestMethod("POST");
                httpsURLConnection.setRequestProperty("Connection", "Keep-Alive");
                httpsURLConnection.setSSLSocketFactory((SSLSocketFactory) SSLSocketFactory.getDefault());
                httpsURLConnection.setHostnameVerifier(new HostnameVerifier() {
                    @Override
                    public boolean verify(String str, SSLSession sSLSession) {
                        return true;
                    }
                });
                httpsURLConnection.connect();
                DataOutputStream dataOutputStream = new DataOutputStream(httpsURLConnection.getOutputStream());
                dataOutputStream.write(bArr, 0, 153600);
                dataOutputStream.flush();
                httpsURLConnection.getResponseCode();
                Wifi_HttpUploadTest.uploadedKByte = (int) (Wifi_HttpUploadTest.uploadedKByte + (153600 / 1024.0d));
                if ((System.currentTimeMillis() - currentTimeMillis) / 1000.0d >= 8) {
                    return;
                }
                dataOutputStream.close();
                httpsURLConnection.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
                return;
            }
        }
    }
}
