package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_activity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.wifi.WifiNetworkSpecifier;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.zxing.Result;
import com.wifipasswordshow.wifiinfo.wifispeed.R;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_extra.Wifi_MyData;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_model.Wifi_ModelWifiPassword;

import java.util.ArrayList;

import me.dm7.barcodescanner.zxing.ZXingScannerView;


public class Wifi_ScanQRActivity extends Wifi_BaseActivity implements ZXingScannerView.ResultHandler {
    public static String WifiName;
    public static String WifiPassword;
    Context context;
    private ConnectivityManager mConnectivityManager;
    private ConnectivityManager.NetworkCallback mNetworkCallback = new ConnectivityManager.NetworkCallback() { 
        @Override 
        public void onAvailable(Network network) {
            super.onAvailable(network);
            Log.d("TAG", "onAvailable: Ok");
        }

        @Override 
        public void onLosing(Network network, int i) {
            super.onLosing(network, i);
            Log.d("TAG", "onLosing: Ok");
        }

        @Override 
        public void onLost(Network network) {
            super.onLost(network);
            Log.d("TAG", "onLost: Ok");
        }

        @Override 
        public void onUnavailable() {
            super.onUnavailable();
            Log.d("TAG", "onUnavailable: Ok");
        }
    };
    private ZXingScannerView mScannerView;
    Wifi_MyData myData;


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        
        setContentView(R.layout.activity_scan_qractivity);
        this.mScannerView = (ZXingScannerView) findViewById(R.id.scaned);
        this.context = this;
        this.myData = new Wifi_MyData(this);
        this.mConnectivityManager = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
    }

    @Override
    public void onResume() {
        super.onResume();
        this.mScannerView.setResultHandler(this);
        this.mScannerView.startCamera();
    }

    @Override
    public void onPause() {
        super.onPause();
        this.mScannerView.stopCamera();
    }


    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void handleResult(Result result) {
        Log.d("TAG", "handleResult: " + result.getText());
        Log.d("TAG", "handleResult: " + result.getBarcodeFormat().toString());
        String[] split = result.getText().split(":");
        String[] split2 = split[2].split(";");
        String[] split3 = split[4].split(";");
        String str = split2[0];
        String str2 = split3[0];
        WifiName = str;
        WifiPassword = str2;
        connect(str, str2);
    }

    public void connect(String str, String str2) {
        ArrayList<Wifi_ModelWifiPassword> list = this.myData.getList();
        list.add(new Wifi_ModelWifiPassword(list.size() + 1, str, str2));
        this.myData.setList(list);
        if (Build.VERSION.SDK_INT >= 29) {
            this.mConnectivityManager.requestNetwork(new NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).setNetworkSpecifier(new WifiNetworkSpecifier.Builder().setSsid(str).setWpa2Passphrase(str2).setIsHiddenSsid(true).build()).build(), this.mNetworkCallback);
            finish();
            return;
        }
        getApplicationContext().startActivity(new Intent("android.net.wifi.PICK_WIFI_NETWORK").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        Toast.makeText(this, "Wifi Name:" + str + "\n Password:" + str2, Toast.LENGTH_LONG).show();
        finish();
    }
}
