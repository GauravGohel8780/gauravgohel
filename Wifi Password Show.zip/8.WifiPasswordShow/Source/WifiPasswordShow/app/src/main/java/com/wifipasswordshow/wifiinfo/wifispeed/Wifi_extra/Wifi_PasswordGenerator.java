package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_extra;

import java.util.ArrayList;
import java.util.Random;


public final class Wifi_PasswordGenerator {
    private static final String DIGITS = "0123456789";
    private static final String LOWER = "abcdefghijklmnopqrstuvwxyz";
    private static final String PUNCTUATION = "!@#$%&*()_+-=[]|,./?><";
    private static final String UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private boolean useDigits;
    private boolean useLower;
    private boolean usePunctuation;
    private boolean useUpper;


    private Wifi_PasswordGenerator(PasswordGeneratorBuilder passwordGeneratorBuilder) {
        this.useLower = passwordGeneratorBuilder.useLower;
        this.useUpper = passwordGeneratorBuilder.useUpper;
        this.useDigits = passwordGeneratorBuilder.useDigits;
        this.usePunctuation = passwordGeneratorBuilder.usePunctuation;
    }


    public static class PasswordGeneratorBuilder {
        private boolean useLower = false;
        private boolean useUpper = false;
        private boolean useDigits = false;
        private boolean usePunctuation = false;

        public PasswordGeneratorBuilder useLower(boolean z) {
            this.useLower = z;
            return this;
        }

        public PasswordGeneratorBuilder useUpper(boolean z) {
            this.useUpper = z;
            return this;
        }

        public PasswordGeneratorBuilder useDigits(boolean z) {
            this.useDigits = z;
            return this;
        }

        public PasswordGeneratorBuilder usePunctuation(boolean z) {
            this.usePunctuation = z;
            return this;
        }

        public Wifi_PasswordGenerator build() {
            return new Wifi_PasswordGenerator(this);
        }
    }

    public String generate(int i) {
        if (i <= 0) {
            return "";
        }
        StringBuilder sb = new StringBuilder(i);
        Random random = new Random(System.nanoTime());
        ArrayList arrayList = new ArrayList(4);
        if (this.useLower) {
            arrayList.add(LOWER);
        }
        if (this.useUpper) {
            arrayList.add(UPPER);
        }
        if (this.useDigits) {
            arrayList.add(DIGITS);
        }
        if (this.usePunctuation) {
            arrayList.add(PUNCTUATION);
        }
        for (int i2 = 0; i2 < i; i2++) {
            String str = (String) arrayList.get(random.nextInt(arrayList.size()));
            sb.append(str.charAt(random.nextInt(str.length())));
        }
        return new String(sb);
    }
}
