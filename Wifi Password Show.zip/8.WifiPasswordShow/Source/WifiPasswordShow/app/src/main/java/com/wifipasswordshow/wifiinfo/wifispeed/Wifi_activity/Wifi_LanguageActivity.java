package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.wifipasswordshow.wifiinfo.wifispeed.R;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_adapter.Wifi_LanguageAdapter_new;
import com.wifipasswordshow.wifiinfo.wifispeed.databinding.ActivityLanguageBinding;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_extra.Wifi_BOOKER_SpManager;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_model.Wifi_LanguageModel_new;


import java.util.ArrayList;

public class Wifi_LanguageActivity extends Wifi_BaseActivity implements Wifi_LanguageAdapter_new.OnClickItemListener {
    Wifi_LanguageAdapter_new adapter;
    ActivityLanguageBinding binding;
    Context context;
    Wifi_LanguageModel_new globalLanguage;
    ImageView imgBack;
    ImageView imgDone;
    int postrue;
    RecyclerView recyclerView;
    Resources resources;
    SharedPreferences sharedPreferences;
    ConstraintLayout topHeader;
    ArrayList<Wifi_LanguageModel_new> languageList = new ArrayList<>();
    int From = -1;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ActivityLanguageBinding inflate = ActivityLanguageBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView(inflate.getRoot());

        this.context = this;
        this.context = Wifi_BaseActivity.setLocale(this, Wifi_BaseActivity.getSelectedLanguage(this));
        this.recyclerView = (RecyclerView) findViewById(R.id.recycler_view_language);
        this.imgBack = (ImageView) findViewById(R.id.img_back_language);
        this.topHeader = (ConstraintLayout) findViewById(R.id.constraint_action_bar_layout);
        SharedPreferences sharedPreferences = getSharedPreferences("Positon", 0);
        this.sharedPreferences = sharedPreferences;
        this.postrue = sharedPreferences.getInt("pos", 0);
        this.resources = this.context.getResources();
        this.imgBack = (ImageView) findViewById(R.id.img_back_language);
        this.imgDone = (ImageView) findViewById(R.id.img_done_language);
        this.recyclerView = (RecyclerView) findViewById(R.id.recycler_view_language);
        Wifi_BOOKER_SpManager.initializingSharedPreference(this.context);
        int intExtra = getIntent().getIntExtra("from", -1);
        this.From = intExtra;
        if (intExtra == 2) {
            this.imgBack.setVisibility(View.VISIBLE);
            this.imgBack.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    getInstance(Wifi_LanguageActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            Wifi_LanguageActivity.this.onBackPressed();
                        }
                    }, BACK_CLICK);
                }
            });
        } else {
            this.imgBack.setVisibility(View.GONE);
        }
        init();
        addList();
        setAdapter();
    }


    private void setAdapter() {
        this.adapter = new Wifi_LanguageAdapter_new(this.languageList, this, this, this.postrue);
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this.context, RecyclerView.VERTICAL, false));
        this.recyclerView.setAdapter(this.adapter);
    }

    private void addList() {
        this.languageList.add(new Wifi_LanguageModel_new("en", "English (Default)", R.drawable.ic_english));
        this.languageList.add(new Wifi_LanguageModel_new("hi", "Hindi (\u0939\u093f\u0928\u094d\u0926\u0940)", R.drawable.ic_hindi));
        this.languageList.add(new Wifi_LanguageModel_new("pa", "Punjabi (\u0a2a\u0a70\u0a1c\u0a3e\u0a2c\u0a40)", R.drawable.ic_punjabi));
        this.languageList.add(new Wifi_LanguageModel_new("es", "Spanish (Espa\u00f1ol)", R.drawable.ic_spanish));
        this.languageList.add(new Wifi_LanguageModel_new("pt", "Portuguese (Portugu\u00eas)", R.drawable.ic_portuguese));
        this.languageList.add(new Wifi_LanguageModel_new("fr", "French (Fran\u00e7ais)", R.drawable.ic_french));
        this.languageList.add(new Wifi_LanguageModel_new("ru", "Russian (\u0420\u0443\u0441\u0441\u043a\u0438\u0439)", R.drawable.ic_russian));
        this.languageList.add(new Wifi_LanguageModel_new("de", "German (Deutsch)", R.drawable.ic_german));
        this.languageList.add(new Wifi_LanguageModel_new("in", "Indonesian (Bahasa Indonesia)", R.drawable.ic_indonesian));
        this.languageList.add(new Wifi_LanguageModel_new("ja", "Japanese (\u65e5\u672c\u8a9e)", R.drawable.ic_japanese));
        this.languageList.add(new Wifi_LanguageModel_new("ko", "Korean (\ud55c\uad6d\uc5b4)", R.drawable.ic_korean));
        this.languageList.add(new Wifi_LanguageModel_new("vi", "Vietnamese (Ti\u1ebfng Vi\u1ec7t)", R.drawable.ic_vietnamese));
        this.languageList.add(new Wifi_LanguageModel_new("zh", "Chinese (\u4e2d\u6587)", R.drawable.ic_chinese));
        this.languageList.add(new Wifi_LanguageModel_new("tr", "Turkish (T\u00fcrk\u00e7e)", R.drawable.ic_turkish));
        this.languageList.add(new Wifi_LanguageModel_new("it", "Italian (Italiano)", R.drawable.ic_italian));
        this.languageList.add(new Wifi_LanguageModel_new("th", "Thai (\u0e44\u0e17\u0e22)", R.drawable.ic_thai));
        this.languageList.add(new Wifi_LanguageModel_new("nl", "Dutch (Nederlands)", R.drawable.ic_dutch));
        this.globalLanguage = this.languageList.get(this.postrue);
    }

    public void init() {
        this.imgDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                getInstance(Wifi_LanguageActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Wifi_LanguageActivity.this.Clickinit(view);
                    }
                }, MAIN_CLICK);

            }
        });
    }


    public void Clickinit(View view) {
        this.sharedPreferences.edit().putInt("pos", this.postrue).apply();
        if (this.globalLanguage != null) {
            Wifi_BOOKER_SpManager.initializingSharedPreference(this);
            Wifi_BOOKER_SpManager.setLanguageCode(this.globalLanguage.lan_name);
            Wifi_BOOKER_SpManager.initializingSharedPreference(this);
            Wifi_BaseActivity.setLocale(this, this.globalLanguage.lan_code);
            Wifi_BOOKER_SpManager.setLanguageCodeSnip(this.globalLanguage.lan_code);
            Wifi_BOOKER_SpManager.setLanguageCode(this.globalLanguage.lan_name);
            Wifi_BOOKER_SpManager.setLanguageSelected(true);
            if (this.From == 2) {
                startActivity(new Intent(this, Wifi_MainActivity.class));
            } else if (!getAlreadyShown()) {
                startActivity(new Intent(this, Wifi_Intro_Activity.class));
                finish();
            } else {
                startActivity(new Intent(this, Wifi_MainActivity.class));
            }
            finish();
            return;
        }
        Wifi_BOOKER_SpManager.initializingSharedPreference(this);
        Wifi_BOOKER_SpManager.setLanguageSelected(true);
        Wifi_BOOKER_SpManager.setLanguageCodeSnip("en");
        if (this.From == 2) {
            startActivity(new Intent(this, Wifi_MainActivity.class));
            finish();
            return;
        }
        startActivity(new Intent(this, Wifi_Intro_Activity.class));
        finish();
    }

    private boolean getAlreadyShown() {
        return getSharedPreferences("PREF_INFO_SHOWN", 0).getBoolean("INFO_SHOWN", false);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void onClickItem(Wifi_LanguageModel_new languageModel_new, int i) {
        this.postrue = i;
        this.globalLanguage = languageModel_new;
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}
