package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.wifipasswordshow.wifiinfo.wifispeed.R;


import java.util.ArrayList;


public class Wifi_AdapterConnectedDevice extends RecyclerView.Adapter<Wifi_AdapterConnectedDevice.ViewHolder> {
    ArrayList<String> list;
    OnClickItemListener mOnClickItemListener;
    public interface OnClickItemListener {
        void onClickItem(int i);
    }

    public Wifi_AdapterConnectedDevice(ArrayList<String> arrayList, OnClickItemListener onClickItemListener) {
        this.list = arrayList;
        this.mOnClickItemListener = onClickItemListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.conected_devices_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        viewHolder.textWifiName.setText(this.list.get(i));
    }

    @Override
    public int getItemCount() {
        return this.list.size();
    }

    
    public class ViewHolder extends RecyclerView.ViewHolder {
        ConstraintLayout main;
        TextView textWifiName;

        public ViewHolder(View view) {
            super(view);
            this.textWifiName = (TextView) view.findViewById(R.id.text_connected_devices);
            this.main = (ConstraintLayout) view.findViewById(R.id.main);
        }
    }
}
