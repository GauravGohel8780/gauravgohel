package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.wifipasswordshow.wifiinfo.wifispeed.R;




import java.util.ArrayList;


public class Wifi_SignalStrengthActivity extends Wifi_BaseActivity {
    ConstraintLayout constraintLayout;
    ConstraintLayout constraintLayout1;
    ConstraintLayout constraintLayout2;
    ConstraintLayout constraintLayout3;
    ConstraintLayout constraintLayout4;
    ConstraintLayout constraintLayout5;
    ConstraintLayout constraintLayout6;
    Context context;
    ImageView imgBack;
    ConstraintLayout main;
    PieChart percentageView;
    String pers;
    TextView textBSSID;
    TextView textIP;
    TextView textLinkSpeed;
    TextView textNetwork;
    TextView textRSSID;
    TextView textSSID;


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_signal_strength);
        this.context = this;
        this.percentageView = (PieChart) findViewById(R.id.chart);
        this.textSSID = (TextView) findViewById(R.id.text_ssid);
        this.textIP = (TextView) findViewById(R.id.text_ip);
        this.textBSSID = (TextView) findViewById(R.id.text_bssid);
        this.textLinkSpeed = (TextView) findViewById(R.id.text_link_speed);
        this.textNetwork = (TextView) findViewById(R.id.text_network);
        this.textRSSID = (TextView) findViewById(R.id.text_rssid);
        this.imgBack = (ImageView) findViewById(R.id.img_back_language);
        this.main = (ConstraintLayout) findViewById(R.id.constraint_action_bar_layout);
        this.constraintLayout = (ConstraintLayout) findViewById(R.id.constraint);
        this.constraintLayout1 = (ConstraintLayout) findViewById(R.id.constraint_main_1);
        this.constraintLayout2 = (ConstraintLayout) findViewById(R.id.constraint_main_2);
        this.constraintLayout3 = (ConstraintLayout) findViewById(R.id.constraint_main_3);
        this.constraintLayout4 = (ConstraintLayout) findViewById(R.id.constraint_main_4);
        this.constraintLayout5 = (ConstraintLayout) findViewById(R.id.constraint_main_5);
        this.constraintLayout6 = (ConstraintLayout) findViewById(R.id.constraint_main_6);
        this.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_SignalStrengthActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Wifi_SignalStrengthActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);

            }
        });
        WifiManager wifiManager = (WifiManager) this.context.getSystemService(Context.WIFI_SERVICE);
        if (wifiManager != null) {
            float calculateSignalLevel = (float) ((WifiManager.calculateSignalLevel(wifiManager.getConnectionInfo().getRssi(), 10) / 10.0d) * 100.0d);
            Log.d("TAG", "onCreate: " + calculateSignalLevel);
            this.pers = calculateSignalLevel + "";
            setupPieChart();
            this.textIP.setText(Formatter.formatIpAddress(wifiManager.getDhcpInfo().ipAddress));
            this.textSSID.setText(wifiManager.getConnectionInfo().getSSID());
            this.textBSSID.setText(wifiManager.getConnectionInfo().getBSSID());
            TextView textView = this.textLinkSpeed;
            textView.setText(wifiManager.getConnectionInfo().getLinkSpeed() + "");
            TextView textView2 = this.textNetwork;
            textView2.setText(wifiManager.getConnectionInfo().getNetworkId() + "");
            TextView textView3 = this.textRSSID;
            textView3.setText(wifiManager.getConnectionInfo().getRssi() + "");

        }
    }


    private void setupPieChart() {
        float[] fArr = {Float.parseFloat(this.pers), 100.0f - Float.valueOf(this.pers).floatValue()};
        String[] strArr = {" ", " "};
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < 2; i++) {
            arrayList.add(new PieEntry(fArr[i], strArr[i]));
        }
        ArrayList arrayList2 = new ArrayList();
        arrayList2.add(Integer.valueOf((int) R.color.white));
        arrayList2.add(Integer.valueOf((int) R.color.signalunfill));
        PieDataSet pieDataSet = new PieDataSet(arrayList, "");
        pieDataSet.setColors(ColorTemplate.LIBERTY_COLORS);
        pieDataSet.setDrawValues(false);
        PieData pieData = new PieData(pieDataSet);
        this.percentageView.getDescription().setEnabled(false);
        this.percentageView.setHoleRadius(75.0f);
        this.percentageView.setTransparentCircleRadius(60.0f);
        this.percentageView.setCenterTextColor(-1);
        this.percentageView.setHoleColor(0);
        this.percentageView.getLegend().setEnabled(false);
        this.percentageView.setRotationEnabled(false);
        this.percentageView.setTouchEnabled(false);
        this.percentageView.setRotation(0.0f);
        this.percentageView.setDrawSliceText(false);
        this.percentageView.setMaxAngle(180.0f);
        this.percentageView.setRotationAngle(180.0f);
        this.percentageView.animateY(2000);
        this.percentageView.setData(pieData);
        this.percentageView.invalidate();
        this.percentageView.setCenterText(this.pers + "% \n ");
        Legend legend = this.percentageView.getLegend();
        legend.setForm(Legend.LegendForm.CIRCLE);
        legend.setTextSize(1.0f);
        legend.setFormSize(1.0f);
        legend.setFormToTextSpace(1.0f);
        legend.setDrawInside(false);
    }


    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }

}
