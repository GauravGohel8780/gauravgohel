package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.ActivityManager;
import android.content.Context;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.wifipasswordshow.wifiinfo.wifispeed.R;



import java.text.DecimalFormat;

import kotlin.jvm.internal.Intrinsics;


public class Wifi_PhoneInfoActivity extends Wifi_BaseActivity {
    ConstraintLayout constraintLayout1;
    ConstraintLayout constraintLayout2;
    ConstraintLayout constraintLayout3;
    ConstraintLayout constraintLayout4;
    ConstraintLayout constraintLayout5;
    ConstraintLayout constraintLayout6;
    ConstraintLayout constraintLayout7;
    ConstraintLayout constraintLayout8;
    Context context;
    ImageView imgBack;
    ConstraintLayout main;
    TextView textBrand;
    TextView textHardware;
    TextView textId;
    TextView textModel;
    TextView textOs;
    TextView textRAM;
    TextView textResolution;
    TextView textStorage;


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        
        setContentView(R.layout.activity_phone_info);
        this.context = this;
        this.imgBack = (ImageView) findViewById(R.id.img_back_language);
        this.textBrand = (TextView) findViewById(R.id.text_build_brand);
        this.textModel = (TextView) findViewById(R.id.text_model);
        this.textOs = (TextView) findViewById(R.id.text_os);
        this.textId = (TextView) findViewById(R.id.text_link_build_id);
        this.textHardware = (TextView) findViewById(R.id.text_hardware);
        this.textResolution = (TextView) findViewById(R.id.text_display);
        this.textRAM = (TextView) findViewById(R.id.text_ram);
        this.textStorage = (TextView) findViewById(R.id.text_storage);
        this.main = (ConstraintLayout) findViewById(R.id.constraint_action_bar_layout);
        this.constraintLayout1 = (ConstraintLayout) findViewById(R.id.constraint_main_1);
        this.constraintLayout2 = (ConstraintLayout) findViewById(R.id.constraint_main_2);
        this.constraintLayout3 = (ConstraintLayout) findViewById(R.id.constraint_main_3);
        this.constraintLayout4 = (ConstraintLayout) findViewById(R.id.constraint_main_4);
        this.constraintLayout5 = (ConstraintLayout) findViewById(R.id.constraint_main_5);
        this.constraintLayout6 = (ConstraintLayout) findViewById(R.id.constraint_main_6);
        this.constraintLayout7 = (ConstraintLayout) findViewById(R.id.constraint_main_7);
        this.constraintLayout8 = (ConstraintLayout) findViewById(R.id.constraint_main_8);
        this.textModel.setText(Build.MODEL);
        this.textOs.setText(Build.VERSION.RELEASE);
        this.textBrand.setText(Build.BRAND);
        this.textId.setText(Build.ID);
        this.textHardware.setText(Build.HARDWARE);
        TextView textView = this.textResolution;
        textView.setText(Resources.getSystem().getDisplayMetrics().widthPixels + " X " + Resources.getSystem().getDisplayMetrics().heightPixels);
        this.textRAM.setText(getMemorySizeHumanized(this.context));
        this.textStorage.setText(readableFileSize());
        this.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_PhoneInfoActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Wifi_PhoneInfoActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);

            }
        });
    }

    public final String getMemorySizeHumanized(Context mContext) {
        Intrinsics.checkNotNullParameter(mContext, "mContext");
        Object systemService = mContext.getApplicationContext().getSystemService(Context.ACTIVITY_SERVICE);
        if (systemService instanceof ActivityManager) {
            ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
            ((ActivityManager) systemService).getMemoryInfo(memoryInfo);
            DecimalFormat decimalFormat = new DecimalFormat("#.##");
            double totalMemory = memoryInfo.totalMem;
            double memoryInKB = totalMemory / 1024.0;
            double memoryInMB = totalMemory / 1048576.0;
            double memoryInGB = totalMemory / 1.073741824E9;
            double memoryInTB = totalMemory / 1.099511627776E12;
            if (memoryInTB > 1.0) {
                return decimalFormat.format(memoryInTB) + " TB";
            } else if (memoryInGB > 1.0) {
                return decimalFormat.format(memoryInGB) + " GB";
            } else if (memoryInMB > 1.0) {
                return decimalFormat.format(memoryInMB) + " MB";
            } else if (memoryInKB > 1.0) {
                return decimalFormat.format(memoryInKB) + " KB";
            } else {
                return decimalFormat.format(totalMemory) + " Bytes";
            }
        } else {
            return "ActivityManager service not available";
        }
    }

    public final String readableFileSize() {
        StatFs statFs = new StatFs(Environment.getExternalStorageDirectory().getPath());
        long blockSizeLong = statFs.getBlockSizeLong() * statFs.getAvailableBlocksLong();
        if (blockSizeLong <= 0) {
            return "0";
        }
        int log10 = (int) (Math.log10(blockSizeLong) / Math.log10(1024.0d));
        double size = blockSizeLong / Math.pow(1024.0d, log10);
        return new DecimalFormat("#,##0.#").format(size) + ' ' + new String[]{"B", "kB", "MB", "GB", "TB"}[log10];
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }

}
