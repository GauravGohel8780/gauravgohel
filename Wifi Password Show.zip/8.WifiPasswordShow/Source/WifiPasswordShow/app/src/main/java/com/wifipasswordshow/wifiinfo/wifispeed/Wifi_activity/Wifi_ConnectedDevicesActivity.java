package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_activity;


import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.wifipasswordshow.wifiinfo.wifispeed.R;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_adapter.Wifi_AdapterConnectedDevice;

import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;


public class Wifi_ConnectedDevicesActivity extends Wifi_BaseActivity {
    Wifi_AdapterConnectedDevice connectedDevice;
    Context context;
    ImageView imgback;
    ArrayList<String> list = new ArrayList<>();
    RecyclerView recyclerView;
    ConstraintLayout topbar;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_connected_devices);
        this.context = this;
        this.recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        this.imgback = (ImageView) findViewById(R.id.img_back_language);
        this.topbar = (ConstraintLayout) findViewById(R.id.constraint_action_bar_layout);
        this.imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_ConnectedDevicesActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Wifi_ConnectedDevicesActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (wifiManager != null) {
            final String formatIpAddress = Formatter.formatIpAddress(wifiManager.getDhcpInfo().gateway);
            Log.d("TAG", "onCreate: " + formatIpAddress);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Wifi_ConnectedDevicesActivity.this.getConnectedDevices(formatIpAddress);
                }
            }).start();
        }
        this.connectedDevice = new Wifi_AdapterConnectedDevice(this.list, new Wifi_AdapterConnectedDevice.OnClickItemListener() {
            @Override
            public void onClickItem(int i) {
            }
        });
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this.context, RecyclerView.VERTICAL, false));
        this.recyclerView.setAdapter(this.connectedDevice);
        first();


    }

    public void first() {
        new Handler(Looper.myLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.d("TAG", "run: refresh");
                Wifi_ConnectedDevicesActivity.this.recyclerView.getAdapter().notifyDataSetChanged();
                Wifi_ConnectedDevicesActivity.this.second();
            }
        }, 1000L);
    }

    void second() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.d("TAG", "run: refresh");
                Wifi_ConnectedDevicesActivity.this.recyclerView.getAdapter().notifyDataSetChanged();
                Wifi_ConnectedDevicesActivity.this.first();
            }
        }, 1000L);
    }

    public ArrayList<String> getConnectedDevices(String str) {
        ArrayList<String> arrayList = new ArrayList<>();
        String[] split = str.split("\\.");
        Log.d("TAG1", "getConnectedDevices: " + str);
        Log.d("TAG1", "getConnectedDevices: " + str.split("\\."));
        for (int i = 0; i <= 255; i++) {
            try {
                InetAddress byName = InetAddress.getByName(split[0] + "." + split[1] + "." + split[2] + "." + i);
                if (byName.isReachable(50)) {
                    Log.d("TAG", "getConnectedDevices: " + byName.getHostName());
                    this.list.add(byName.getHostName());
                    Log.d("TAG", "getConnectedDevices: " + this.list.size());
                    arrayList.add(byName.getHostName());
                }
            } catch (IOException unused) {
            }
        }
        return arrayList;
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}
