package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.viewpager.widget.PagerAdapter;

import com.wifipasswordshow.wifiinfo.wifispeed.R;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_activity.Wifi_ScreenItem;


import java.util.List;

public class Wifi_IntroViewPagerAdapter extends PagerAdapter {
    Context mContext;
    List<Wifi_ScreenItem> mListScreen;

    @Override 
    public boolean isViewFromObject(View view, Object obj) {
        return view == obj;
    }

    public Wifi_IntroViewPagerAdapter(Context context, List<Wifi_ScreenItem> list) {
        this.mContext = context;
        this.mListScreen = list;
    }

    @Override
    public Object instantiateItem(ViewGroup viewGroup, int i) {
        View inflate = ((LayoutInflater) this.mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.intro_lay, (ViewGroup) null);
        ((TextView) inflate.findViewById(R.id.intro_title)).setText(this.mListScreen.get(i).getTitle());
        ((TextView) inflate.findViewById(R.id.intro_description)).setText(this.mListScreen.get(i).getDescription());
        ((ImageView) inflate.findViewById(R.id.intro_img)).setImageResource(this.mListScreen.get(i).getScreenImg());
        viewGroup.addView(inflate);
        return inflate;
    }

    @Override
    public int getCount() {
        return this.mListScreen.size();
    }

    @Override
    public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
        viewGroup.removeView((View) obj);
    }
}
