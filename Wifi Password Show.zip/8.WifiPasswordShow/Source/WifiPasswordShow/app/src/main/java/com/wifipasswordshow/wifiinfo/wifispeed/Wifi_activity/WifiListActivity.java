package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.wifipasswordshow.wifiinfo.wifispeed.R;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_adapter.Wifi_AdapterWifiList;
import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_extra.Wifi_MyData;

import com.wifipasswordshow.wifiinfo.wifispeed.Wifi_model.Wifi_ModelWifiPassword;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class WifiListActivity extends Wifi_BaseActivity {
    Context context;
    ArrayList<Wifi_ModelWifiPassword> dataList;
    ProgressDialog dialog;
    ImageView imgBack;
    WifiManager mainWifi;
    Wifi_MyData myData;
    WifiReceiver receiverWifi;
    RecyclerView recyclerView;
    ConstraintLayout topBar;
    List<ScanResult> wifiList;
    ArrayList<String> list = new ArrayList<>();
    StringBuilder sb = new StringBuilder();

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        
        setContentView(R.layout.activity_wifi_list);
        this.context = this;
        this.recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        this.topBar = (ConstraintLayout) findViewById(R.id.constraint_action_bar_layout);
        this.imgBack = (ImageView) findViewById(R.id.img_back_language);
        this.myData = new Wifi_MyData(this.context);
        ProgressDialog progressDialog = new ProgressDialog(this.context);
        this.dialog = progressDialog;
        progressDialog.setTitle(R.string.text_please_wait);
        this.dialog.setMessage(getString(R.string.text_loading));
        this.dialog.setCancelable(false);
        this.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(WifiListActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        WifiListActivity.this.onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        Wifi_AdapterWifiList adapterWifiList = new Wifi_AdapterWifiList(this.list, new Wifi_AdapterWifiList.OnClickItemListener() {
            @Override
            public void onClickItem(int i) {
                getInstance(WifiListActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        WifiListActivity.this.wifiPasswordShow(i);
                    }
                }, MAIN_CLICK);

            }
        });
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this.context, RecyclerView.VERTICAL, false));
        this.recyclerView.setAdapter(adapterWifiList);
        WifiManager wifiManager = (WifiManager) this.context.getSystemService(Context.WIFI_SERVICE);
        this.mainWifi = wifiManager;
        if (!wifiManager.isWifiEnabled()) {
            Toast.makeText(getApplicationContext(), "wifi is disabled..making it enabled", Toast.LENGTH_LONG).show();
            this.mainWifi.setWifiEnabled(true);
        }
        WifiReceiver wifiReceiver = new WifiReceiver();
        this.receiverWifi = wifiReceiver;
        registerReceiver(wifiReceiver, new IntentFilter("android.net.wifi.SCAN_RESULTS"));
        this.mainWifi.startScan();
        this.dialog.show();
        
        
        
    }

    
    class WifiReceiver extends BroadcastReceiver {
        WifiReceiver() {
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            WifiListActivity.this.list.clear();
            WifiListActivity.this.sb = new StringBuilder();
            WifiListActivity wifiListActivity = WifiListActivity.this;
            if (ActivityCompat.checkSelfPermission(WifiListActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            wifiListActivity.wifiList = wifiListActivity.mainWifi.getScanResults();
            StringBuilder sb = WifiListActivity.this.sb;
            sb.append("\n        Number Of Wifi connections :" + WifiListActivity.this.wifiList.size() + "\n\n");
            for (int i = 0; i < WifiListActivity.this.wifiList.size(); i++) {
                String[] split = WifiListActivity.this.wifiList.get(i).toString().split(":")[1].split(",");
                if (!WifiListActivity.this.isName(split[0])) {
                    WifiListActivity.this.list.add(split[0]);
                }
                Log.d("TAG", "onReceive: " + split[0]);
            }
            WifiListActivity.this.dialog.dismiss();
            WifiListActivity.this.recyclerView.getAdapter().notifyDataSetChanged();
        }
    }
    public boolean isName(String str) {
        Iterator<String> it = this.list.iterator();
        while (it.hasNext()) {
            if (it.next().equals(str) && str == "") {
                return true;
            }
        }
        return false;
    }
   
    @Override
    public void onPause() {
        unregisterReceiver(this.receiverWifi);
        super.onPause();
    }

   
    @Override
    public void onResume() {
        registerReceiver(this.receiverWifi, new IntentFilter("android.net.wifi.SCAN_RESULTS"));
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }

    public void wifiPasswordShow(final int i) {
        this.dataList = this.myData.getList();
        final Dialog dialog = new Dialog(this);
        View inflate = LayoutInflater.from(this.context).inflate(R.layout.wifi_password_dialog, (ViewGroup) null);
        dialog.setContentView(inflate);
        final EditText editText = (EditText) inflate.findViewById(R.id.edt_wifi_password);
        TextView textView = (TextView) inflate.findViewById(R.id.bt_conect);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String obj = editText.getText().toString();
                if (!obj.isEmpty()) {
                    Iterator<Wifi_ModelWifiPassword> it = WifiListActivity.this.dataList.iterator();
                    while (it.hasNext()) {
                        Wifi_ModelWifiPassword next = it.next();
                        if (next.getWifiName().equals(WifiListActivity.this.list.get(i))) {
                            WifiListActivity.this.dataList.remove(next);
                        }
                    }
                    WifiListActivity.this.dataList.add(new Wifi_ModelWifiPassword(WifiListActivity.this.list.size() + 1, WifiListActivity.this.list.get(i), obj));
                    WifiListActivity.this.myData.setList(WifiListActivity.this.dataList);
                    WifiListActivity.this.getApplicationContext().startActivity(new Intent("android.net.wifi.PICK_WIFI_NETWORK").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                }
                dialog.dismiss();
            }
        });
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.show();
    }

}
