package com.wifipasswordshow.wifiinfo.wifispeed.Wifi_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.MyApplication.sharedPreferencesHelper;

import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.wifipasswordshow.wifiinfo.wifispeed.R;
import com.wifipasswordshow.wifiinfo.wifispeed.databinding.ActivityPrivacyPolicyBinding;

public class Wifi_Privacy_policy extends Wifi_BaseActivity {
    ActivityPrivacyPolicyBinding binding;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ActivityPrivacyPolicyBinding inflate = ActivityPrivacyPolicyBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView(inflate.getRoot());

        this.binding.backLay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(Wifi_Privacy_policy.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        onBackPressed();
                    }
                }, AdUtils.ClickType.BACK_CLICK);
            }
        });
        this.binding.webview.loadUrl(sharedPreferencesHelper.getPrivacyPolicy());
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
