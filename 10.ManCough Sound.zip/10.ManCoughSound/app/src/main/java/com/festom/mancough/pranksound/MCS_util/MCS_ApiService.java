package com.festom.mancough.pranksound.MCS_util;


import com.festom.mancough.pranksound.MCS_model.MCS_FeedBackResponseModel;
import com.festom.mancough.pranksound.MCS_model.MCS_FeedbackRequestModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface MCS_ApiService {

    @POST("api/v1/feedBack/save")
    Call<MCS_FeedBackResponseModel> feedbackUser(@Body MCS_FeedbackRequestModel request);
}