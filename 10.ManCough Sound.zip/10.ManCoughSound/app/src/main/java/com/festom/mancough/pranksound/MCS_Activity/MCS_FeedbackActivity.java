package com.festom.mancough.pranksound.MCS_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.festom.mancough.pranksound.Ads_Common.AdsBaseActivity;
import com.festom.mancough.pranksound.R;
import com.festom.mancough.pranksound.MCS_model.MCS_FeedBackResponseModel;
import com.festom.mancough.pranksound.MCS_model.MCS_FeedbackDataModel;
import com.festom.mancough.pranksound.MCS_model.MCS_FeedbackRequestModel;
import com.festom.mancough.pranksound.MCS_util.MCS_ApiService;
import com.festom.mancough.pranksound.MCS_util.MCS_LanguageUtil;
import com.festom.mancough.pranksound.MCS_util.MCS_Utils;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.io.IOException;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MCS_FeedbackActivity extends AdsBaseActivity {

    EditText etName, etEmail, etfeedback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        MCS_LanguageUtil.setLanguage(MCS_FeedbackActivity.this);
        MCS_Utils.setStatusBarGradiant(this);

        findViewById(R.id.cvBack).setOnClickListener(v -> {
            getInstance(MCS_FeedbackActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etfeedback = findViewById(R.id.etfeedback);

        String DeviceName = Build.BRAND + " " + Build.MODEL;
        int Version = Build.VERSION.SDK_INT;
        Log.w("--apiResponse--", "DeviceName  " + DeviceName);
        Log.w("--apiResponse--", "Version  " + Version);

        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://192.168.3.196:9000/").addConverterFactory(GsonConverterFactory.create()).build();

        MCS_ApiService apiService = retrofit.create(MCS_ApiService.class);

        findViewById(R.id.cvsubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Name = Objects.requireNonNull(etName.getText()).toString();
                String Email = Objects.requireNonNull(etEmail.getText()).toString();
                String feedback = Objects.requireNonNull(etfeedback.getText()).toString();

                if (TextUtils.isEmpty(Name)) {
                    Toast.makeText(MCS_FeedbackActivity.this, "Please enter your Name...", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(Email)) {
                    Toast.makeText(MCS_FeedbackActivity.this, "Please enter your Email...", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(feedback)) {
                    Toast.makeText(MCS_FeedbackActivity.this, "Please enter your feedback...", Toast.LENGTH_SHORT).show();
                } else {
                    getInstance(MCS_FeedbackActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            String DeviceName = Build.BRAND + " " + Build.MODEL;
                            int Version = Build.VERSION.SDK_INT;
                            MCS_FeedbackRequestModel userDetail = new MCS_FeedbackRequestModel(Name, Email, feedback, "com.hairclipper.funny.hairclipperprank", DeviceName, Version);

                            Call<MCS_FeedBackResponseModel> call = apiService.feedbackUser(userDetail);

                            call.enqueue(new Callback<MCS_FeedBackResponseModel>() {
                                @Override
                                public void onResponse(@NonNull Call<MCS_FeedBackResponseModel> call, @NonNull Response<MCS_FeedBackResponseModel> response) {
                                    MCS_FeedBackResponseModel apiResponse = response.body();
                                    if (response.isSuccessful()) {
                                        Toast.makeText(MCS_FeedbackActivity.this, "FeedBack Submit successfully...", Toast.LENGTH_SHORT).show();

                                        Log.w("--apiResponse--", "user_data---in USerDetails" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));
                                        MCS_FeedbackDataModel userData = apiResponse.getFeedbackDataModel();
                                        Log.w("--apiResponse--", "onResponse:getArrLoginToken ---------->" + userData.getvFeedBackMessage());
                                    } else {
                                        try {
                                            Log.w("--apiResponse--", "Error: user detail " + response.errorBody().string());
                                        } catch (IOException e) {
                                            throw new RuntimeException(e);
                                        }
                                    }
                                    etName.getText().clear();
                                    etEmail.getText().clear();
                                    etfeedback.getText().clear();
                                }

                                @Override
                                public void onFailure(@NonNull Call<MCS_FeedBackResponseModel> call, @NonNull Throwable t) {
                                    etName.getText().clear();
                                    etEmail.getText().clear();
                                    etfeedback.getText().clear();
                                    Log.e("--apiResponse--", "Error: user detail onFailure " + new Gson().toJson(t.getMessage()));
                                }
                            });
                        }
                    }, BACK_CLICK);
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}