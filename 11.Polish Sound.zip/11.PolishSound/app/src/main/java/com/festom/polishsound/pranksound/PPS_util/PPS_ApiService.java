package com.festom.polishsound.pranksound.PPS_util;


import com.festom.polishsound.pranksound.PPS_model.PPS_FeedBackResponseModel;
import com.festom.polishsound.pranksound.PPS_model.PPS_FeedbackRequestModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface PPS_ApiService {

    @POST("api/v1/feedBack/save")
    Call<PPS_FeedBackResponseModel> feedbackUser(@Body PPS_FeedbackRequestModel request);
}