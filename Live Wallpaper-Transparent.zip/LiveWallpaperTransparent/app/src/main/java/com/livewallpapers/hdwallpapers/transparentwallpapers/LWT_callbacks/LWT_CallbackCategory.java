package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_callbacks;

import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models.LWT_Category;

import java.util.ArrayList;
import java.util.List;

public class LWT_CallbackCategory {
    public List<LWT_Category> categories = new ArrayList();
    public String status = "";
}
