package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_components;

import android.content.Context;
import android.graphics.Rect;
import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public class LWT_ItemOffsetDecoration extends RecyclerView.ItemDecoration {
    private final int mItemOffset;

    private LWT_ItemOffsetDecoration(int i) {
        this.mItemOffset = i;
    }

    public LWT_ItemOffsetDecoration(Context context, int i) {
        this(context.getResources().getDimensionPixelSize(i));
    }

    @Override
    public void getItemOffsets(Rect rect, View view, RecyclerView recyclerView, RecyclerView.State state) {
        super.getItemOffsets(rect, view, recyclerView, state);
        int i = this.mItemOffset;
        rect.set(i, i, i, i);
    }
}
