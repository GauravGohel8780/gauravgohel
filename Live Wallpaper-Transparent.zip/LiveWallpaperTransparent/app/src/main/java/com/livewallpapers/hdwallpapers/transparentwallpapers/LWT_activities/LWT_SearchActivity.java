package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_activities;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;


import com.iten.tenoku.ad.AdShow;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.livewallpapers.hdwallpapers.transparentwallpapers.Ads_Common.AdsBaseActivity;
import com.livewallpapers.hdwallpapers.transparentwallpapers.R;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_adapters.LWT_CategoryAdapter;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_adapters.LWT_SearchAdapter;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_adapters.LWT_WallpaperAdapter;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_callbacks.LWT_CallbackCategory;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_callbacks.LWT_CallbackWallpaper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_components.LWT_ItemOffsetDecoration;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_prefs.LWT_SharedPref;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_sqlite.LWT_DBHelper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models.LWT_Category;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models.LWT_Wallpaper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_rests.LWT_ApiInterface;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_rests.LWT_RestAdapter;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_Constant;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_Tools;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LWT_SearchActivity extends AdsBaseActivity {
    private LWT_CategoryAdapter adapterCategory;
    private LWT_WallpaperAdapter adapterWallpaper;
    private ImageButton btClear;
    private final List<LWT_Category> categories = new ArrayList();
    private EditText etIndex;
    private EditText etSearch;
    private int failedPage = 0;
    public String flagType;
    private LinearLayoutCompat lytSuggestion;
    private LWT_SearchAdapter mAdapterSuggestion;
    private CoordinatorLayout parentView;
    private int postTotal = 0;
    private ProgressBar progressBar;
    private RecyclerView rvCategory;
    private RecyclerView rvSuggestion;
    private RecyclerView rvWallpaper;
    private LWT_SharedPref sharedPref;
    private String tags = "";
    TextWatcher textWatcher = new TextWatcher() {
        public void afterTextChanged(Editable editable) {
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            if (charSequence.toString().trim().length() == 0) {
                LWT_SearchActivity.this.btClear.setVisibility(View.GONE);
            } else {
                LWT_SearchActivity.this.btClear.setVisibility(View.VISIBLE);
            }
        }
    };
    private final List<LWT_Wallpaper> wallpapers = new ArrayList();

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        LWT_Tools.getTheme(this);
        LWT_SharedPref sharedPref2 = new LWT_SharedPref(this);
        this.sharedPref = sharedPref2;
        setContentView(R.layout.lwt_activity_search);
        initComponent();
        setupToolbar();
    }

    private void initComponent() {
        String stringExtra = getIntent().getStringExtra(LWT_Constant.EXTRA_OBJC);
        this.parentView = (CoordinatorLayout) findViewById(R.id.coordinatorLayout);
        this.progressBar = (ProgressBar) findViewById(R.id.progressBar);
        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radioGroupSearch);
        this.etIndex = (EditText) findViewById(R.id.etIndex);
        initRecyclerView();
        this.lytSuggestion = (LinearLayoutCompat) findViewById(R.id.lytSuggestion);
        etSearch = (EditText) findViewById(R.id.etSearch);
        ImageButton imageButton = (ImageButton) findViewById(R.id.btClear);
        this.btClear = imageButton;
        imageButton.setVisibility(View.GONE);
        this.etSearch.addTextChangedListener(this.textWatcher);
        if (getIntent().hasExtra(LWT_DBHelper.TAGS)) {
            this.tags = getIntent().getStringExtra(LWT_DBHelper.TAGS);
            hideKeyboard();
            searchActionTags();
        } else {
            this.etSearch.requestFocus();
            swipeProgress(false);
        }
        this.rvSuggestion.setLayoutManager(new LinearLayoutManager(this));
        this.rvSuggestion.setHasFixedSize(true);
        LWT_SearchAdapter adapterSearch = new LWT_SearchAdapter(this);
        this.mAdapterSuggestion = adapterSearch;
        this.rvSuggestion.setAdapter(adapterSearch);
        showSuggestionSearch();
        this.mAdapterSuggestion.setOnItemClickListener(new LWT_SearchAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, String str, int i) {
                etSearch.setText(str);
                lytSuggestion.setVisibility(View.GONE);
                hideKeyboard();
                searchActionWallpaper(1);
            }
        });
        this.btClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etSearch.setText("");
            }
        });
        this.etSearch.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                showSuggestionSearch();
                getWindow().setSoftInputMode(5);
                return false;
            }
        });

        if (stringExtra.equals("category")) {
            radioGroup.check(radioGroup.getChildAt(1).getId());
            requestSearchCategory();
        } else {
            radioGroup.check(radioGroup.getChildAt(0).getId());
            requestSearchWallpaper();
        }

        this.flagType = this.etIndex.getText().toString();
        this.etIndex.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable editable) {
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {

            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                LWT_SearchActivity activitySearch = LWT_SearchActivity.this;
                activitySearch.flagType = activitySearch.etIndex.getText().toString();
                LWT_SearchActivity.this.showKeyboard();
            }
        });
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i) {
                    case R.id.rbCategory:
                        requestSearchCategory();
                        rvWallpaper.setVisibility(View.GONE);
                        rvCategory.setVisibility(View.VISIBLE);
                        findViewById(R.id.lytNoitem).setVisibility(View.GONE);
                        return;
                    case R.id.rbWallpaper:
                        requestSearchWallpaper();
                        rvWallpaper.setVisibility(View.VISIBLE);
                        rvCategory.setVisibility(View.GONE);
                        findViewById(R.id.lytNoitem).setVisibility(View.GONE);
                        return;
                    default:
                        return;
                }
            }
        });
    }

    public void initRecyclerView() {
        this.rvWallpaper = (RecyclerView) findViewById(R.id.rvWallpaper);
        this.rvCategory = (RecyclerView) findViewById(R.id.rvCategory);
        this.rvSuggestion = (RecyclerView) findViewById(R.id.rvSuggestion);
    }

    public void requestSearchWallpaper() {
        this.etIndex.setText("0");
        this.rvWallpaper.setVisibility(View.VISIBLE);
        this.rvCategory.setVisibility(View.GONE);
        this.progressBar.setVisibility(View.VISIBLE);
        this.progressBar.setVisibility(View.GONE);
        this.rvWallpaper.setLayoutManager(new StaggeredGridLayoutManager(this.sharedPref.getWallpaperColumns().intValue(), 1));
        this.rvWallpaper.setHasFixedSize(true);
        LWT_WallpaperAdapter adapterWallpaper2 = new LWT_WallpaperAdapter(this, this.rvWallpaper, this.wallpapers);
        this.adapterWallpaper = adapterWallpaper2;
        this.rvWallpaper.setAdapter(adapterWallpaper2);
        this.adapterWallpaper.setOnItemClickListener(new LWT_WallpaperAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, LWT_Wallpaper wallpaper, int i) {
                getInstance(LWT_SearchActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(getApplicationContext(), LWT_WallpaperDetailActivity.class);
                        intent.putExtra(LWT_Constant.POSITION, i);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable(LWT_Constant.ARRAY_LIST, (Serializable) wallpapers);
                        intent.putExtra(LWT_Constant.BUNDLE, bundle);
                        intent.putExtra(LWT_Constant.EXTRA_OBJC, wallpaper);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);

            }
        });
        this.rvWallpaper.addOnScrollListener(new RecyclerView.OnScrollListener() {


            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int i) {
                super.onScrollStateChanged(recyclerView, i);
            }
        });
        this.adapterWallpaper.setOnLoadMoreListener(new LWT_WallpaperAdapter.OnLoadMoreListener() {
            @Override
            public void onLoadMore(int i) {
                if (postTotal <= adapterWallpaper.getItemCount() || i == 0) {
                    adapterWallpaper.setLoaded();
                } else {
                    searchActionWallpaper(i + 1);
                }
            }
        });
        this.etSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if (i != 3) {
                    return false;
                }
                if (etSearch.getText().toString().equals("")) {
                    Snackbar.make(parentView, "Please Insert Keyword", -1).show();
                    hideKeyboard();
                    swipeProgress(false);
                } else {
                    adapterWallpaper.resetListData();
                    hideKeyboard();
                    searchActionWallpaper(1);
                }
                return true;
            }
        });
    }


    public void requestSearchCategory() {
        this.etIndex.setText("1");
        this.rvWallpaper.setVisibility(View.GONE);
        this.rvCategory.setVisibility(View.VISIBLE);
        this.progressBar.setVisibility(View.GONE);
        this.progressBar.setVisibility(View.VISIBLE);
        LWT_ItemOffsetDecoration itemOffsetDecoration = new LWT_ItemOffsetDecoration(this, R.dimen.lwt_dp_4);
        int dimensionPixelOffset = getResources().getDimensionPixelOffset(R.dimen.lwt_dp_4);
        this.rvCategory.setPadding(dimensionPixelOffset, dimensionPixelOffset, dimensionPixelOffset, dimensionPixelOffset);
        this.rvCategory.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
        if (this.rvCategory.getItemDecorationCount() == 0) {
            this.rvCategory.addItemDecoration(itemOffsetDecoration);
        }
        this.rvCategory.setHasFixedSize(true);
        LWT_CategoryAdapter adapterCategory2 = new LWT_CategoryAdapter(this, this.categories);
        this.adapterCategory = adapterCategory2;
        this.rvCategory.setAdapter(adapterCategory2);
        this.adapterCategory.setOnItemClickListener(new LWT_CategoryAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, LWT_Category category, int i) {
                getInstance(LWT_SearchActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(getApplicationContext(), LWT_CategoryDetailsActivity.class);
                        intent.putExtra(LWT_Constant.EXTRA_OBJC, category);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);

            }
        });
        this.etSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if (i != 3) {
                    return false;
                }
                if (etSearch.getText().toString().equals("")) {
                    Snackbar.make(parentView, "Please Insert Keyword", -1).show();
                    hideKeyboard();
                    swipeProgress(false);
                } else {
                    adapterCategory.resetListData();
                    hideKeyboard();
                    searchActionCategory();
                }
                return true;
            }
        });
    }


    public void setupToolbar() {
        MaterialToolbar materialToolbar = (MaterialToolbar) findViewById(R.id.toolbar);
        setSupportActionBar(materialToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setTitle("");
        }
    }

    private void onFailRequestWallpaper(int i) {
        this.failedPage = i;
        this.adapterWallpaper.setLoaded();
        swipeProgress(false);
        showFailedViewWallpaper(true, getString(R.string.lwt_txt_failed_text));
    }


    private void onFailRequestCategory() {
        swipeProgress(false);
        showFailedViewCategory(true, getString(R.string.lwt_txt_failed_text));
    }

    private void searchActionWallpaper(int i) {
        this.lytSuggestion.setVisibility(View.GONE);
        showFailedViewWallpaper(false, "");
        showNotFoundViewWallpaper(false);
        String trim = this.etSearch.getText().toString().trim();
        if (!trim.equals("")) {
            if (i == 1) {
                swipeProgress(true);
            } else {
                this.adapterWallpaper.setLoading();
            }
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    Call<LWT_CallbackWallpaper> call;
                    LWT_ApiInterface createAPI = LWT_RestAdapter.createAPI();
                    if (sharedPref.getWallpaperColumns().intValue() == 3) {
                        call = createAPI.getSearch(i, 24, trim, LWT_Constant.ORDER_RECENT);
                    } else {
                        call = createAPI.getSearch(i, 20, trim, LWT_Constant.ORDER_RECENT);
                    }
                    call.enqueue(new Callback<LWT_CallbackWallpaper>() {


                        @Override
                        public void onResponse(Call<LWT_CallbackWallpaper> call, Response<LWT_CallbackWallpaper> response) {
                            LWT_CallbackWallpaper body = response.body();
                            if (body == null || !body.status.equals("ok")) {
                                LWT_SearchActivity.this.onFailRequestWallpaper(i);
                            } else {
                                LWT_SearchActivity.this.postTotal = body.count_total;
                                LWT_SearchActivity.this.adapterWallpaper.insertData(body.posts);
                                if (body.posts.size() == 0) {
                                    LWT_SearchActivity.this.showNotFoundViewWallpaper(true);
                                }
                            }
                            LWT_SearchActivity.this.swipeProgress(false);
                        }

                        @Override
                        public void onFailure(Call<LWT_CallbackWallpaper> call, Throwable th) {
                            LWT_SearchActivity.this.onFailRequestWallpaper(i);
                            LWT_SearchActivity.this.swipeProgress(false);
                        }
                    });
                }
            }, 0);
            return;
        }
        Snackbar.make(this.parentView, "Please Insert Keyword", -1).show();
        swipeProgress(false);
    }

    private void searchActionCategory() {
        this.lytSuggestion.setVisibility(View.GONE);
        showFailedViewCategory(false, "");
        showNotFoundViewCategory(false);
        String trim = this.etSearch.getText().toString().trim();
        if (!trim.equals("")) {
            swipeProgress(true);
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    LWT_RestAdapter.createAPI().getSearchCategory(trim).enqueue(new Callback<LWT_CallbackCategory>() {
                        @Override
                        public void onResponse(Call<LWT_CallbackCategory> call, Response<LWT_CallbackCategory> response) {
                            LWT_CallbackCategory body = response.body();
                            if (body == null || !body.status.equals("ok")) {
                                LWT_SearchActivity.this.onFailRequestCategory();
                                return;
                            }
                            LWT_SearchActivity.this.adapterCategory.insertData(body.categories);
                            LWT_SearchActivity.this.swipeProgress(false);
                            if (body.categories.size() == 0) {
                                LWT_SearchActivity.this.showNotFoundViewCategory(true);
                            }
                        }

                        @Override
                        public void onFailure(Call<LWT_CallbackCategory> call, Throwable th) {
                            LWT_SearchActivity.this.onFailRequestCategory();
                            LWT_SearchActivity.this.swipeProgress(false);
                        }
                    });
                }
            }, 0);
            return;
        }
        Snackbar.make(this.parentView, "Please Insert Keyword", -1).show();
        swipeProgress(false);
    }

    private void searchActionTags() {
        this.lytSuggestion.setVisibility(View.GONE);
        showFailedViewWallpaper(false, "");
        showNotFoundViewWallpaper(false);
        this.etSearch.setText(this.tags);
        String trim = this.etSearch.getText().toString().trim();
        if (!trim.equals("")) {
            swipeProgress(true);
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    Call<LWT_CallbackWallpaper> call;
                    LWT_ApiInterface createAPI = LWT_RestAdapter.createAPI();
                    if (sharedPref.getWallpaperColumns().intValue() == 3) {
                        call = createAPI.getSearch(1, 24, trim, LWT_Constant.ORDER_RECENT);
                    } else {
                        call = createAPI.getSearch(1, 20, trim, LWT_Constant.ORDER_RECENT);
                    }
                    call.enqueue(new Callback<LWT_CallbackWallpaper>() {
                        @Override
                        public void onResponse(Call<LWT_CallbackWallpaper> call, Response<LWT_CallbackWallpaper> response) {
                            LWT_CallbackWallpaper body = response.body();
                            if (body == null || !body.status.equals("ok")) {
                                LWT_SearchActivity.this.onFailRequestWallpaper(1);
                            } else {
                                LWT_SearchActivity.this.postTotal = body.count_total;
                                LWT_SearchActivity.this.adapterWallpaper.insertData(body.posts);
                                if (body.posts.size() == 0) {
                                    LWT_SearchActivity.this.showNotFoundViewWallpaper(true);
                                }
                            }
                            LWT_SearchActivity.this.swipeProgress(false);
                        }

                        @Override
                        public void onFailure(Call<LWT_CallbackWallpaper> call, Throwable th) {
                            LWT_SearchActivity.this.onFailRequestWallpaper(1);
                            LWT_SearchActivity.this.swipeProgress(false);
                        }
                    });
                }
            }, 0);
            return;
        }
        Snackbar.make(this.parentView, "Please Insert Keyword", -1).show();
        swipeProgress(false);
    }


    private void showSuggestionSearch() {
        this.mAdapterSuggestion.refreshItems();
        this.lytSuggestion.setVisibility(View.VISIBLE);
    }

    private void hideKeyboard() {
        View currentFocus = getCurrentFocus();
        if (currentFocus != null) {
            ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
        }
    }

    private void showKeyboard() {
        this.etSearch.requestFocus();
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).toggleSoftInput(2, 1);
    }

    private void showFailedViewWallpaper(boolean z, String str) {
        View findViewById = findViewById(R.id.lytFailed);
        ((TextView) findViewById(R.id.tvFailedMessage)).setText(str);
        if (z) {
            this.rvWallpaper.setVisibility(View.GONE);
            findViewById.setVisibility(View.VISIBLE);
        } else {
            this.rvWallpaper.setVisibility(View.VISIBLE);
            findViewById.setVisibility(View.GONE);
        }
        findViewById(R.id.btnFailedRetry).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                searchActionWallpaper(failedPage);
            }
        });
    }

    private void showFailedViewCategory(boolean z, String str) {
        View findViewById = findViewById(R.id.lytFailed);
        ((TextView) findViewById(R.id.tvFailedMessage)).setText(str);
        if (z) {
            this.rvCategory.setVisibility(View.GONE);
            findViewById.setVisibility(View.VISIBLE);
        } else {
            this.rvCategory.setVisibility(View.VISIBLE);
            findViewById.setVisibility(View.GONE);
        }
        findViewById(R.id.btnFailedRetry).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                searchActionCategory();
            }
        });
    }


    private void showNotFoundViewWallpaper(boolean z) {
        View findViewById = findViewById(R.id.lytNoitem);
        ((TextView) findViewById(R.id.tvNoItemMessage)).setText("No wallpapers found! if you want to continue search, please try enter another keyword!");
        if (z) {
            this.rvWallpaper.setVisibility(View.GONE);
            findViewById.setVisibility(View.VISIBLE);
            return;
        }
        this.rvWallpaper.setVisibility(View.VISIBLE);
        findViewById.setVisibility(View.GONE);
    }


    private void showNotFoundViewCategory(boolean z) {
        View findViewById = findViewById(R.id.lytNoitem);
        ((TextView) findViewById(R.id.tvNoItemMessage)).setText("No category found! if you want to continue search, please try enter another keyword!");
        if (z) {
            this.rvCategory.setVisibility(View.GONE);
            findViewById.setVisibility(View.VISIBLE);
            return;
        }
        this.rvCategory.setVisibility(View.VISIBLE);
        findViewById.setVisibility(View.GONE);
    }


    private void swipeProgress(boolean z) {
        if (!z) {
            this.progressBar.setVisibility(View.GONE);
        } else {
            this.progressBar.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onBackPressed() {
        if (getIntent().hasExtra(LWT_DBHelper.TAGS)) {
            super.onBackPressed();
        } else if (this.etSearch.length() > 0) {
            this.etSearch.setText("");
        } else {
            super.onBackPressed();
        }
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        onBackPressed();
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        AdShow.getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
