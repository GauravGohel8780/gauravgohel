package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_adapters;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import com.livewallpapers.hdwallpapers.transparentwallpapers.R;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_prefs.LWT_SharedPref;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models.LWT_Wallpaper;

import java.util.List;

public class LWT_WallpaperAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final Activity context;
    private List<LWT_Wallpaper> items;
    private boolean loading;
    private OnItemClickListener mOnItemClickListener;
    private OnLoadMoreListener onLoadMoreListener;

    public interface OnItemClickListener {
        void onItemClick(View view, LWT_Wallpaper wallpaper, int i);
    }

    public interface OnLoadMoreListener {
        void onLoadMore(int i);
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.mOnItemClickListener = onItemClickListener;
    }

    public LWT_WallpaperAdapter(Activity context2, RecyclerView recyclerView, List<LWT_Wallpaper> list) {
        this.items = list;
        this.context = context2;
        lastItemViewDetector(recyclerView);
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int i) {
                super.onScrollStateChanged(recyclerView, i);
            }
        });
    }

    public static class OriginalViewHolder extends RecyclerView.ViewHolder {
        public CardView cardView;
        FrameLayout lytParent;
        public ImageView ivWallpaperImage;

        public OriginalViewHolder(View view) {
            super(view);
            this.ivWallpaperImage = (ImageView) view.findViewById(R.id.ivWallpaperImage);
            this.cardView = (CardView) view.findViewById(R.id.cardView);
            this.lytParent = (FrameLayout) view.findViewById(R.id.lytParent);
        }
    }

    public static class ProgressViewHolder extends RecyclerView.ViewHolder {
        public ProgressBar progressBar;

        ProgressViewHolder(View view) {
            super(view);
            this.progressBar = (ProgressBar) view.findViewById(R.id.pbLoadMore);
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        if (i == 1) {
            return new OriginalViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.lwt_item_wallpaper_rectangle, viewGroup, false));
        }
        return new ProgressViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.lwt_item_load_more, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder,@SuppressLint("RecyclerView") int i) {
        boolean z = true;
        if (viewHolder instanceof OriginalViewHolder) {
            LWT_Wallpaper wallpaper = this.items.get(i);
            OriginalViewHolder originalViewHolder = (OriginalViewHolder) viewHolder;
            if (new LWT_SharedPref(this.context).getIsDarkTheme().booleanValue()) {
                originalViewHolder.cardView.setCardBackgroundColor(this.context.getResources().getColor(R.color.lwtColorGreySoft));
            } else {
                originalViewHolder.cardView.setCardBackgroundColor(this.context.getResources().getColor(R.color.lwtColorGreySoft));
            }
            if (wallpaper.type.equals("url")) {
                ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) Glide.with(this.context).load(wallpaper.image_url.replace(" ", "%20")).centerCrop()).diskCacheStrategy(DiskCacheStrategy.ALL)).placeholder(R.drawable.bg_transparent)).into(originalViewHolder.ivWallpaperImage);
            } else {
                RequestManager with = Glide.with(this.context);
                RequestBuilder<Drawable> load = with.load("https://sarkaribhaiya.com/apps/wallpaper/upload/thumbs/" + this.items.get(i).image_upload.replace(" ", "%20"));
                RequestManager with2 = Glide.with(this.context);
                ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) load.thumbnail(with2.load("https://sarkaribhaiya.com/apps/wallpaper/upload/thumbs/" + this.items.get(i).image_upload.replace(" ", "%20"))).centerCrop()).diskCacheStrategy(DiskCacheStrategy.ALL)).placeholder(R.drawable.bg_transparent)).into(originalViewHolder.ivWallpaperImage);
            }
            originalViewHolder.lytParent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    OnItemClickListener onItemClickListener = mOnItemClickListener;
                    if (onItemClickListener != null) {

                        onItemClickListener.onItemClick(view, wallpaper, i);

                    }
                }
            });
        } else {
            ((ProgressViewHolder) viewHolder).progressBar.setIndeterminate(true);
        }
        StaggeredGridLayoutManager.LayoutParams layoutParams = (StaggeredGridLayoutManager.LayoutParams) viewHolder.itemView.getLayoutParams();
        if (!(getItemViewType(i) == 0 || getItemViewType(i) == 2)) {
            z = false;
        }
        layoutParams.setFullSpan(z);
    }


    public void insertData(List<LWT_Wallpaper> list) {
        setLoaded();
        int itemCount = getItemCount();
        int size = list.size();
        this.items.addAll(list);
        notifyItemRangeInserted(itemCount, size);
    }

    public void setItems(List<LWT_Wallpaper> list) {
        this.items = list;
        notifyDataSetChanged();
    }

    public void setLoaded() {
        this.loading = false;
        for (int i = 0; i < getItemCount(); i++) {
            if (this.items.get(i) == null) {
                this.items.remove(i);
                notifyItemRemoved(i);
            }
        }
    }

    public void setLoading() {
        if (getItemCount() != 0) {
            this.items.add(null);
            notifyItemInserted(getItemCount() - 1);
            this.loading = true;
        }
    }

    public void resetListData() {
        this.items.clear();
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return this.items.size();
    }

    @Override
    public int getItemViewType(int i) {
        LWT_Wallpaper wallpaper = this.items.get(i);
        if (wallpaper != null) {
            return wallpaper.image_name == null ? 2 : 1;
        }
        return 0;
    }

    public void setOnLoadMoreListener(OnLoadMoreListener onLoadMoreListener2) {
        this.onLoadMoreListener = onLoadMoreListener2;
    }

    private void lastItemViewDetector(RecyclerView recyclerView) {
        if (recyclerView.getLayoutManager() instanceof StaggeredGridLayoutManager) {
            final StaggeredGridLayoutManager staggeredGridLayoutManager = (StaggeredGridLayoutManager) recyclerView.getLayoutManager();
            recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
                @Override 
                public void onScrolled(RecyclerView recyclerView, int i, int i2) {
                    super.onScrolled(recyclerView, i, i2);
                    int lastVisibleItem = LWT_WallpaperAdapter.this.getLastVisibleItem(staggeredGridLayoutManager.findLastVisibleItemPositions(null));
                    if (!LWT_WallpaperAdapter.this.loading && lastVisibleItem == LWT_WallpaperAdapter.this.getItemCount() - 1 && LWT_WallpaperAdapter.this.onLoadMoreListener != null) {
                        LWT_WallpaperAdapter.this.onLoadMoreListener.onLoadMore(LWT_WallpaperAdapter.this.getItemCount() / 20);
                        LWT_WallpaperAdapter.this.loading = true;
                    }
                }
            });
        }
    }

    private int getLastVisibleItem(int[] iArr) {
        int i = iArr[0];
        for (int i2 : iArr) {
            if (i < i2) {
                i = i2;
            }
        }
        return i;
    }
}
