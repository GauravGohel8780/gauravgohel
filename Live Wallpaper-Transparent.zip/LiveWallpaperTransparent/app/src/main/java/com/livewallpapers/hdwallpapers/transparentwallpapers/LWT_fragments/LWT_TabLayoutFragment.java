package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.livewallpapers.hdwallpapers.transparentwallpapers.R;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_components.LWT_CustomTabLayout;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_prefs.LWT_SharedPref;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_Constant;

public class LWT_TabLayoutFragment extends Fragment {
    public LWT_CustomTabLayout smartTabLayout;
    public int tab_count = 6;
    private View view;
    public ViewPager viewPager;

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.view = layoutInflater.inflate(R.layout.lwt_fragment_tab_layout, viewGroup, false);
        LWT_SharedPref sharedPref = new LWT_SharedPref(requireActivity());
        this.smartTabLayout = (LWT_CustomTabLayout) this.view.findViewById(R.id.ctLayout);
        initViewPager(this.tab_count);
        return this.view;
    }

    public void initViewPager(int i) {
        ViewPager viewPager2 = (ViewPager) this.view.findViewById(R.id.viewPager);
        this.viewPager = viewPager2;
        viewPager2.setOffscreenPageLimit(i);
        this.viewPager.setAdapter(new ViewPagerAdapter(getChildFragmentManager(), i));
        this.smartTabLayout.post(new Runnable() {
            @Override
            public void run() {
                smartTabLayout.setViewPager(viewPager);
            }
        });
    }



    public class ViewPagerAdapter extends FragmentStatePagerAdapter {
        int noOfItems;

        public ViewPagerAdapter(FragmentManager fragmentManager, int i) {
            super(fragmentManager, FragmentStatePagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
            this.noOfItems = i;
        }

        @Override
        public Fragment getItem(int i) {
            if (i == 0) {
                return LWT_WallpaperFragment.newInstance(LWT_Constant.ORDER_RANDOM, LWT_Constant.FILTER_WALLPAPER);
            }
            if (i == 1) {
                return LWT_WallpaperFragment.newInstance(LWT_Constant.ORDER_RECENT, LWT_Constant.FILTER_WALLPAPER);
            }
            if (i == 2) {
                return LWT_WallpaperFragment.newInstance(LWT_Constant.ORDER_RANDOM, LWT_Constant.FILTER_WALLPAPER);
            }
            if (i == 3) {
                return LWT_WallpaperFragment.newInstance(LWT_Constant.ORDER_POPULAR, LWT_Constant.FILTER_WALLPAPER);
            }
            if (i == 4) {
                return LWT_WallpaperFragment.newInstance(LWT_Constant.ORDER_FEATURED, LWT_Constant.FILTER_ALL);
            }
            return LWT_WallpaperFragment.newInstance(LWT_Constant.ORDER_LIVE, LWT_Constant.FILTER_LIVE);
        }

        @Override
        public int getCount() {
            return this.noOfItems;
        }

        @Override
        public String getPageTitle(int i) {
            if (i == 0) {
                return LWT_TabLayoutFragment.this.getResources().getString(R.string.lwt_txt_menu_random);
            }
            if (i == 1) {
                return LWT_TabLayoutFragment.this.getResources().getString(R.string.lwt_txt_menu_recent);
            }
            if (i == 2) {
                return LWT_TabLayoutFragment.this.getResources().getString(R.string.lwt_txt_menu_trending);
            }
            if (i == 3) {
                return LWT_TabLayoutFragment.this.getResources().getString(R.string.lwt_txt_menu_popular);
            }
            if (i == 4) {
                return LWT_TabLayoutFragment.this.getResources().getString(R.string.lwt_txt_menu_featured);
            }
            return LWT_TabLayoutFragment.this.getResources().getString(R.string.lwt_txt_menu_live);
        }
    }
}
