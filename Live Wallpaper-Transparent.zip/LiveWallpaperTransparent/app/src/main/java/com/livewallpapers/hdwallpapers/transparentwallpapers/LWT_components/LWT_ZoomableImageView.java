package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_components;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.view.ScaleGestureDetector;
import android.view.View;

import androidx.appcompat.widget.AppCompatImageView;

public class LWT_ZoomableImageView extends AppCompatImageView {
    float bmHeight;
    float bmWidth;
    float bottom;
    Context context;
    float height;
    PointF last = new PointF();
    float[] m;
    ScaleGestureDetector mScaleDetector;
    Matrix matrix = new Matrix();
    float maxScale = 4.0f;
    float minScale = 1.0f;
    int mode = 0;
    float origHeight;
    float origWidth;
    float redundantXSpace;
    float redundantYSpace;
    float right;
    float saveScale = 1.0f;
    PointF start = new PointF();
    float width;

    public LWT_ZoomableImageView(Context context2, AttributeSet attributeSet) {
        super(context2, attributeSet);
        super.setClickable(true);
        this.context = context2;
        this.mScaleDetector = new ScaleGestureDetector(context2, new ScaleListener());
        this.matrix.setTranslate(1.0f, 1.0f);
        this.m = new float[9];
        setImageMatrix(this.matrix);
        setScaleType(ScaleType.MATRIX);
        setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View r9, android.view.MotionEvent r10) {
                throw new UnsupportedOperationException("Method not decompiled: com.livewallpapers.hdwallpapers.transparentwallpapers.components.ZoomableImageView.AnonymousClass1.onTouch(android.view.View, android.view.MotionEvent):boolean");
            }
        });
    }

    @Override
    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        this.bmWidth = (float) bitmap.getWidth();
        this.bmHeight = (float) bitmap.getHeight();
    }

    public void setMaxZoom(float f) {
        this.maxScale = f;
    }

    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        private ScaleListener() {
        }

        public boolean onScaleBegin(ScaleGestureDetector scaleGestureDetector) {
            LWT_ZoomableImageView.this.mode = 2;
            return true;
        }

        public boolean onScale(ScaleGestureDetector r9) {
            throw new UnsupportedOperationException("Method not decompiled: com.livewallpapers.hdwallpapers.transparentwallpapers.components.ZoomableImageView.ScaleListener.onScale(android.view.ScaleGestureDetector):boolean");
        }
    }

    
    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        this.width = (float) MeasureSpec.getSize(i);
        float size = (float) MeasureSpec.getSize(i2);
        this.height = size;
        float min = Math.min(this.width / this.bmWidth, size / this.bmHeight);
        this.matrix.setScale(min, min);
        setImageMatrix(this.matrix);
        this.saveScale = 1.0f;
        float f = (this.height - (this.bmHeight * min)) / 2.0f;
        this.redundantYSpace = f;
        float f2 = (this.width - (min * this.bmWidth)) / 2.0f;
        this.redundantXSpace = f2;
        this.matrix.postTranslate(f2, f);
        float f3 = this.width;
        float f4 = this.redundantXSpace;
        this.origWidth = f3 - (f4 * 2.0f);
        float f5 = this.height;
        float f6 = this.redundantYSpace;
        this.origHeight = f5 - (f6 * 2.0f);
        float f7 = this.saveScale;
        this.right = ((f3 * f7) - f3) - ((f4 * 2.0f) * f7);
        this.bottom = ((f5 * f7) - f5) - ((f6 * 2.0f) * f7);
        setImageMatrix(this.matrix);
    }
}
