package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models;

import java.io.Serializable;

public class LWT_Category implements Serializable {
    public String category_id;
    public String category_image;
    public String category_name;
    public String total_wallpaper;
}
