package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils;

import android.app.Activity;
import android.app.ProgressDialog;
import android.app.WallpaperManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.app.AlertDialog;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;
import com.livewallpapers.hdwallpapers.transparentwallpapers.R;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models.LWT_Wallpaper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_rests.LWT_RestAdapter;

import java.io.File;
import java.io.IOException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LWT_WallpaperHelper {
    private static final String TAG = "WallpaperHelper";
    private final Activity activity;

    public LWT_WallpaperHelper(Activity activity2) {
        this.activity = activity2;
    }

    public void setWallpaper(View view, ProgressDialog progressDialog, Bitmap bitmap, String str) {
        int hashCode = str.hashCode();
        switch (hashCode) {
            case -381820416:
                if (str.equals(LWT_Constant.LOCK_SCREEN)) {
                    try {
                        WallpaperManager.getInstance(this.activity).setBitmap(bitmap, null, true, WallpaperManager.FLAG_LOCK);
                        onWallpaperApplied(progressDialog);
                    } catch (IOException e) {
                        e.printStackTrace();
                        showSnackbar(view);
                        progressDialog.dismiss();
                    }
                }
                break;
            case -250585140:
                if (str.equals(LWT_Constant.HOME_SCREEN)) {
                    try {
                        WallpaperManager.getInstance(this.activity).setBitmap(bitmap, null, true, WallpaperManager.FLAG_SYSTEM);
                        onWallpaperApplied(progressDialog);
                    } catch (IOException e) {
                        e.printStackTrace();
                        showSnackbar(view);
                        progressDialog.dismiss();
                    }
                }
                break;
            case 3029889:
                if (str.equals(LWT_Constant.BOTH)) {
                    try {
                        WallpaperManager.getInstance(this.activity).setBitmap(bitmap);
                        onWallpaperApplied(progressDialog);
                    } catch (IOException e) {
                        e.printStackTrace();
                        showSnackbar(view);
                        progressDialog.dismiss();
                    }
                }
                break;
            default:
                break;
        }
    }

    private void showSnackbar(View view) {
        Snackbar.make(view, this.activity.getString(R.string.lwt_txt_snack_bar_failed), Snackbar.LENGTH_LONG).show();
    }

    public void setWallpaper(View view, ProgressDialog progressDialog, String str) {
        progressDialog.setMessage("Preparing wallpaper…");
        progressDialog.setCancelable(false);
        progressDialog.show();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Glide.with(activity).load(str.replace(" ", "%20")).into(new CustomTarget<Drawable>() {
                    @Override
                    public void onLoadCleared(Drawable drawable) {
                    }

                    public void onResourceReady(Drawable drawable, Transition<? super Drawable> transition) {
                        try {
                            WallpaperManager.getInstance(LWT_WallpaperHelper.this.activity).setBitmap(((BitmapDrawable) drawable).getBitmap());
                            progressDialog.setMessage("Applying wallpaper…");
                            LWT_WallpaperHelper.this.onWallpaperApplied(progressDialog);
                        } catch (IOException e) {
                            e.printStackTrace();
                            Snackbar.make(view, LWT_WallpaperHelper.this.activity.getString(R.string.lwt_txt_snack_bar_failed), -1).show();
                            progressDialog.dismiss();
                        }
                    }

                    @Override
                    public void onLoadFailed(Drawable drawable) {
                        super.onLoadFailed(drawable);
                        Snackbar.make(view, LWT_WallpaperHelper.this.activity.getString(R.string.lwt_txt_snack_bar_error), -1).show();
                        progressDialog.dismiss();
                    }
                });
            }
        }, 2500);
    }


    public void onWallpaperApplied(ProgressDialog progressDialog) {
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                showSuccessDialog();
            }
        }, 2500);
    }

    public void showSuccessDialog() {
        AlertDialog show = new AlertDialog.Builder(this.activity, R.style.TransparentAlertDialog).setView(this.activity.getLayoutInflater().inflate(R.layout.lwt_dialog_success, (ViewGroup) null)).show();

        ((MaterialButton) show.findViewById(R.id.btnDone)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        show.dismiss();
                    }
                }, 250);
            }
        });
        show.show();
    }


    public void setGif(View view, ProgressDialog progressDialog, String str) {
        progressDialog.setMessage("Preparing wallpaper…");
        progressDialog.setCancelable(false);
        progressDialog.show();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Glide.with(activity).download(str.replace(" ", "%20")).listener(new RequestListener<File>() {
                    @Override
                    public boolean onLoadFailed(GlideException glideException, Object obj, Target<File> target, boolean z) {
                        progressDialog.dismiss();
                        Snackbar.make(view, LWT_WallpaperHelper.this.activity.getString(R.string.lwt_txt_snack_bar_failed), -1).show();
                        return false;
                    }

                    public boolean onResourceReady(File file, Object obj, Target<File> target, DataSource dataSource, boolean z) {
                        try {
                            LWT_Tools.setAction(LWT_WallpaperHelper.this.activity, LWT_Tools.getBytesFromFile(file), LWT_Tools.createName(str), LWT_Constant.SET_GIF);
                            progressDialog.dismiss();
                            return true;
                        } catch (IOException e) {
                            e.printStackTrace();
                            progressDialog.dismiss();
                            Snackbar.make(view, LWT_WallpaperHelper.this.activity.getString(R.string.lwt_txt_snack_bar_failed), -1).show();
                            return true;
                        }
                    }
                }).submit();
            }
        }, 2500);
    }

    public void setWallpaperFromOtherApp(String str) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Glide.with(activity).download(str.replace(" ", "%20")).listener(new RequestListener<File>() {
                    @Override
                    public boolean onLoadFailed(GlideException glideException, Object obj, Target<File> target, boolean z) {
                        return false;
                    }

                    public boolean onResourceReady(File file, Object obj, Target<File> target, DataSource dataSource, boolean z) {
                        try {
                            LWT_Tools.setAction(LWT_WallpaperHelper.this.activity, LWT_Tools.getBytesFromFile(file), LWT_Tools.createName(str), LWT_Constant.SET_WITH);
                            return true;
                        } catch (IOException e) {
                            e.printStackTrace();
                            return true;
                        }
                    }
                }).submit();
            }
        }, 2500);
    }

    public void downloadWallpaper(LWT_Wallpaper wallpaper, View view, ProgressDialog progressDialog, String str) {
        progressDialog.setMessage(this.activity.getString(R.string.lwt_txt_snack_bar_saving));
        progressDialog.setCancelable(false);
        progressDialog.show();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Glide.with(activity).download(str.replace(" ", "%20")).listener(new RequestListener<File>() {
                    @Override
                    public boolean onLoadFailed(GlideException glideException, Object obj, Target<File> target, boolean z) {
                        progressDialog.dismiss();
                        return false;
                    }

                    public boolean onResourceReady(File file, Object obj, Target<File> target, DataSource dataSource, boolean z) {
                        try {
                            LWT_Tools.setAction(LWT_WallpaperHelper.this.activity, LWT_Tools.getBytesFromFile(file), LWT_Tools.createName(str), LWT_Constant.DOWNLOAD);
                            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    Snackbar.make(view, LWT_WallpaperHelper.this.activity.getString(R.string.lwt_txt_snack_bar_saved), -1).show();
                                    LWT_WallpaperHelper.this.updateDownload(wallpaper.image_id);
                                    progressDialog.dismiss();
                                }
                            }, 2500);
                            return true;
                        } catch (IOException e) {
                            e.printStackTrace();
                            progressDialog.dismiss();
                            return true;
                        }
                    }
                }).submit();
            }
        }, 2500);
    }

    public void shareWallpaper(ProgressDialog progressDialog, String str) {
        progressDialog.setMessage("Preparing wallpaper…");
        progressDialog.setCancelable(false);
        progressDialog.show();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Glide.with(activity).download(str.replace(" ", "%20")).listener(new RequestListener<File>() {
                    @Override
                    public boolean onLoadFailed(GlideException glideException, Object obj, Target<File> target, boolean z) {
                        progressDialog.dismiss();
                        return false;
                    }

                    public boolean onResourceReady(File file, Object obj, Target<File> target, DataSource dataSource, boolean z) {
                        try {
                            LWT_Tools.setAction(LWT_WallpaperHelper.this.activity, LWT_Tools.getBytesFromFile(file), LWT_Tools.createName(str), LWT_Constant.SHARE);
                            progressDialog.dismiss();
                            return true;
                        } catch (IOException e) {
                            e.printStackTrace();
                            progressDialog.dismiss();
                            return true;
                        }
                    }
                }).submit();
            }
        }, 2500);
    }

    public void updateView(String str) {
        LWT_RestAdapter.createAPI().updateView(str).enqueue(new Callback<LWT_Wallpaper>() {
            @Override
            public void onResponse(Call<LWT_Wallpaper> call, Response<LWT_Wallpaper> response) {
                Log.d(LWT_WallpaperHelper.TAG, "success update view");
            }

            @Override
            public void onFailure(Call<LWT_Wallpaper> call, Throwable th) {
                Log.d(LWT_WallpaperHelper.TAG, "failed update view");
            }
        });
    }

    public void updateDownload(String str) {
        LWT_RestAdapter.createAPI().updateDownload(str).enqueue(new Callback<LWT_Wallpaper>() {
            @Override
            public void onResponse(Call<LWT_Wallpaper> call, Response<LWT_Wallpaper> response) {
                Log.d(LWT_WallpaperHelper.TAG, "success update download");
            }

            @Override
            public void onFailure(Call<LWT_Wallpaper> call, Throwable th) {
                Log.d(LWT_WallpaperHelper.TAG, "failed update download");
            }
        });
    }
}
