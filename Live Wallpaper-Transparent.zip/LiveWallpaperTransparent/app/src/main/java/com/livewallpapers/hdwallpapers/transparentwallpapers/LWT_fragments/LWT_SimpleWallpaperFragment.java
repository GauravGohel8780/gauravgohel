package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_fragments;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.facebook.shimmer.ShimmerFrameLayout;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.livewallpapers.hdwallpapers.transparentwallpapers.R;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_activities.LWT_WallpaperDetailActivity;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_adapters.LWT_WallpaperAdapter;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_callbacks.LWT_CallbackWallpaper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_prefs.LWT_SharedPref;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_sqlite.LWT_DBHelper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models.LWT_Wallpaper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_rests.LWT_ApiInterface;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_rests.LWT_RestAdapter;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_Constant;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_Tools;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LWT_SimpleWallpaperFragment extends Fragment {
    private LWT_WallpaperAdapter adapterWallpaper;
    private Call<LWT_CallbackWallpaper> callbackCall = null;
    private LWT_DBHelper dbHelper;
    private int failed_page = 0;
    private final List<LWT_Wallpaper> items = new ArrayList();
    private ShimmerFrameLayout lyt_shimmer;
    private int post_total = 0;
    private RecyclerView recyclerView;
    private View root_view;
    private LWT_SharedPref sharedPref;
    private String single_choice_selected;
    private SwipeRefreshLayout swipeRefreshLayout;

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.root_view = layoutInflater.inflate(R.layout.lwt_fragment_simple_wallpaper, viewGroup, false);
        setHasOptionsMenu(true);
        this.dbHelper = new LWT_DBHelper(requireActivity());
        LWT_SharedPref sharedPref2 = new LWT_SharedPref(requireActivity());
        this.sharedPref = sharedPref2;
        sharedPref2.setDefaultSortWallpaper();
        RelativeLayout relativeLayout = (RelativeLayout) this.root_view.findViewById(R.id.parent_view);
        this.swipeRefreshLayout = (SwipeRefreshLayout) this.root_view.findViewById(R.id.swipeRefreshLayout);
        relativeLayout.setBackgroundColor(getResources().getColor(R.color.lwtColorColorBackgroundDark));
        this.swipeRefreshLayout.setProgressBackgroundColorSchemeColor(getResources().getColor(R.color.lwtColorSwipeRefreshDark));
        this.swipeRefreshLayout.setColorSchemeResources(R.color.lwtColorSwipeRefresh_1, R.color.lwtColorSwipeRefresh_2, R.color.lwtColorSwipeRefresh_3, R.color.lwtColorSwipeRefresh_4);
        this.lyt_shimmer = (ShimmerFrameLayout) this.root_view.findViewById(R.id.shimmerViewContainer);
        initShimmerLayout();
        RecyclerView recyclerView2 = (RecyclerView) this.root_view.findViewById(R.id.recyclerView);
        this.recyclerView = recyclerView2;
        recyclerView2.setLayoutManager(new StaggeredGridLayoutManager(this.sharedPref.getWallpaperColumns().intValue(), 1));
        this.recyclerView.setHasFixedSize(true);
        LWT_WallpaperAdapter adapterWallpaper2 = new LWT_WallpaperAdapter(requireActivity(), this.recyclerView, this.items);
        this.adapterWallpaper = adapterWallpaper2;
        this.recyclerView.setAdapter(adapterWallpaper2);
        this.adapterWallpaper.setOnItemClickListener(new LWT_WallpaperAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, LWT_Wallpaper wallpaper, int i) {
                getInstance(getActivity()).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(requireActivity(), LWT_WallpaperDetailActivity.class);
                        intent.putExtra(LWT_Constant.POSITION, i);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable(LWT_Constant.ARRAY_LIST, (Serializable) items);
                        intent.putExtra(LWT_Constant.BUNDLE, bundle);
                        intent.putExtra(LWT_Constant.EXTRA_OBJC, wallpaper);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });
        this.recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            /* class com.livewallpapers.hdwallpapers.transparentwallpapers.fragments.FragmentSimpleWallpaper.AnonymousClass1 */

            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int i) {
                super.onScrollStateChanged(recyclerView, i);
            }
        });
        this.adapterWallpaper.setOnLoadMoreListener(new LWT_WallpaperAdapter.OnLoadMoreListener() {
            @Override
            public void onLoadMore(int i) {
                if (post_total <= adapterWallpaper.getItemCount() || i == 0) {
                    adapterWallpaper.setLoaded();
                } else {
                    requestAction(i + 1);
                }
            }
        });
        this.swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                Call<LWT_CallbackWallpaper> call = callbackCall;
                if (call != null && call.isExecuted()) {
                    callbackCall.cancel();
                }
                adapterWallpaper.resetListData();
                if (LWT_Tools.isConnect(requireActivity())) {
                    dbHelper.deleteAll(LWT_DBHelper.TABLE_RECENT);
                }
                requestAction(1);
            }
        });
        requestAction(1);
        return this.root_view;
    }


    @Override
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
    }

    private void displayApiResult(List<LWT_Wallpaper> list) {
        insertData(list);
        swipeProgress(false);
        if (list.size() == 0) {
            showNoItemView(true);
        }
    }

    private void loadDataFromDatabase(Call<LWT_CallbackWallpaper> call, int i) {
        if (this.sharedPref.getCurrentSortWallpaper().intValue() == 0) {
            List<LWT_Wallpaper> allWallpaper = this.dbHelper.getAllWallpaper(LWT_DBHelper.TABLE_RECENT);
            insertData(allWallpaper);
            if (allWallpaper.size() == 0 && !call.isCanceled()) {
                onFailRequest(i);
            }
        } else if (this.sharedPref.getCurrentSortWallpaper().intValue() == 1) {
            List<LWT_Wallpaper> allWallpaper2 = this.dbHelper.getAllWallpaper(LWT_DBHelper.TABLE_FEATURED);
            insertData(allWallpaper2);
            if (allWallpaper2.size() == 0 && !call.isCanceled()) {
                onFailRequest(i);
            }
        } else if (this.sharedPref.getCurrentSortWallpaper().intValue() == 2) {
            List<LWT_Wallpaper> allWallpaper3 = this.dbHelper.getAllWallpaper(LWT_DBHelper.TABLE_POPULAR);
            insertData(allWallpaper3);
            if (allWallpaper3.size() == 0 && !call.isCanceled()) {
                onFailRequest(i);
            }
        } else if (this.sharedPref.getCurrentSortWallpaper().intValue() == 3) {
            List<LWT_Wallpaper> allWallpaper4 = this.dbHelper.getAllWallpaper(LWT_DBHelper.TABLE_RANDOM);
            insertData(allWallpaper4);
            if (allWallpaper4.size() == 0 && !call.isCanceled()) {
                onFailRequest(i);
            }
        } else if (this.sharedPref.getCurrentSortWallpaper().intValue() == 4) {
            List<LWT_Wallpaper> allWallpaper5 = this.dbHelper.getAllWallpaper(LWT_DBHelper.TABLE_GIF);
            insertData(allWallpaper5);
            if (allWallpaper5.size() == 0 && !call.isCanceled()) {
                onFailRequest(i);
            }
        }
    }

    private void insertData(List<LWT_Wallpaper> list) {
        this.adapterWallpaper.insertData(list);
    }

    private void onFailRequest(int i) {
        this.failed_page = i;
        this.adapterWallpaper.setLoaded();
        swipeProgress(false);
        showFailedView(true, getString(R.string.lwt_txt_failed_text));
    }

    public void requestAction(int i) {
        showFailedView(false, "");
        showNoItemView(false);
        if (i == 1) {
            swipeProgress(true);
        } else {
            this.adapterWallpaper.setLoading();
        }
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                LWT_ApiInterface createAPI = LWT_RestAdapter.createAPI();
                if (sharedPref.getWallpaperColumns().intValue() == 3) {
                    if (sharedPref.getCurrentSortWallpaper().intValue() == 0) {
                        callbackCall = createAPI.getWallpapers(i, 24, LWT_Constant.FILTER_ALL, LWT_Constant.ORDER_RECENT);
                    } else if (sharedPref.getCurrentSortWallpaper().intValue() == 1) {
                        callbackCall = createAPI.getWallpapers(i, 24, LWT_Constant.FILTER_ALL, LWT_Constant.ORDER_FEATURED);
                    } else if (sharedPref.getCurrentSortWallpaper().intValue() == 2) {
                        callbackCall = createAPI.getWallpapers(i, 24, LWT_Constant.FILTER_ALL, LWT_Constant.ORDER_POPULAR);
                    } else if (sharedPref.getCurrentSortWallpaper().intValue() == 3) {
                        callbackCall = createAPI.getWallpapers(i, 24, LWT_Constant.FILTER_ALL, LWT_Constant.ORDER_RANDOM);
                    } else if (sharedPref.getCurrentSortWallpaper().intValue() == 4) {
                        callbackCall = createAPI.getWallpapers(i, 24, LWT_Constant.FILTER_LIVE, LWT_Constant.ORDER_LIVE);
                    }
                } else if (sharedPref.getCurrentSortWallpaper().intValue() == 0) {
                    callbackCall = createAPI.getWallpapers(i, 20, LWT_Constant.FILTER_ALL, LWT_Constant.ORDER_RECENT);
                } else if (sharedPref.getCurrentSortWallpaper().intValue() == 1) {
                    callbackCall = createAPI.getWallpapers(i, 20, LWT_Constant.FILTER_ALL, LWT_Constant.ORDER_FEATURED);
                } else if (sharedPref.getCurrentSortWallpaper().intValue() == 2) {
                    callbackCall = createAPI.getWallpapers(i, 20, LWT_Constant.FILTER_ALL, LWT_Constant.ORDER_POPULAR);
                } else if (sharedPref.getCurrentSortWallpaper().intValue() == 3) {
                    callbackCall = createAPI.getWallpapers(i, 20, LWT_Constant.FILTER_ALL, LWT_Constant.ORDER_RANDOM);
                } else if (sharedPref.getCurrentSortWallpaper().intValue() == 4) {
                    callbackCall = createAPI.getWallpapers(i, 20, LWT_Constant.FILTER_LIVE, LWT_Constant.ORDER_LIVE);
                }
                callbackCall.enqueue(new Callback<LWT_CallbackWallpaper>() {
                    @Override
                    public void onResponse(Call<LWT_CallbackWallpaper> call, Response<LWT_CallbackWallpaper> response) {
                        LWT_CallbackWallpaper body = response.body();
                        if (body == null || !body.status.equals("ok")) {
                            LWT_SimpleWallpaperFragment.this.onFailRequest(i);
                            return;
                        }
                        LWT_SimpleWallpaperFragment.this.post_total = body.count_total;
                        LWT_SimpleWallpaperFragment.this.displayApiResult(body.posts);
                        if (LWT_SimpleWallpaperFragment.this.sharedPref.getCurrentSortWallpaper().intValue() == 0) {
                            if (i == 1) {
                                LWT_SimpleWallpaperFragment.this.dbHelper.truncateTableWallpaper(LWT_DBHelper.TABLE_RECENT);
                            }
                            LWT_SimpleWallpaperFragment.this.dbHelper.addListWallpaper(body.posts, LWT_DBHelper.TABLE_RECENT);
                        } else if (LWT_SimpleWallpaperFragment.this.sharedPref.getCurrentSortWallpaper().intValue() == 1) {
                            if (i == 1) {
                                LWT_SimpleWallpaperFragment.this.dbHelper.truncateTableWallpaper(LWT_DBHelper.TABLE_FEATURED);
                            }
                            LWT_SimpleWallpaperFragment.this.dbHelper.addListWallpaper(body.posts, LWT_DBHelper.TABLE_FEATURED);
                        } else if (LWT_SimpleWallpaperFragment.this.sharedPref.getCurrentSortWallpaper().intValue() == 2) {
                            if (i == 1) {
                                LWT_SimpleWallpaperFragment.this.dbHelper.truncateTableWallpaper(LWT_DBHelper.TABLE_POPULAR);
                            }
                            LWT_SimpleWallpaperFragment.this.dbHelper.addListWallpaper(body.posts, LWT_DBHelper.TABLE_POPULAR);
                        } else if (LWT_SimpleWallpaperFragment.this.sharedPref.getCurrentSortWallpaper().intValue() == 3) {
                            if (i == 1) {
                                LWT_SimpleWallpaperFragment.this.dbHelper.truncateTableWallpaper(LWT_DBHelper.TABLE_RANDOM);
                            }
                            LWT_SimpleWallpaperFragment.this.dbHelper.addListWallpaper(body.posts, LWT_DBHelper.TABLE_RANDOM);
                        } else if (LWT_SimpleWallpaperFragment.this.sharedPref.getCurrentSortWallpaper().intValue() == 4) {
                            if (i == 1) {
                                LWT_SimpleWallpaperFragment.this.dbHelper.truncateTableWallpaper(LWT_DBHelper.TABLE_GIF);
                            }
                            LWT_SimpleWallpaperFragment.this.dbHelper.addListWallpaper(body.posts, LWT_DBHelper.TABLE_GIF);
                        }
                    }

                    @Override
                    public void onFailure(Call<LWT_CallbackWallpaper> call, Throwable th) {
                        LWT_SimpleWallpaperFragment.this.swipeProgress(false);
                        LWT_SimpleWallpaperFragment.this.loadDataFromDatabase(call, i);
                    }
                });
            }
        }, 0);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        swipeProgress(false);
        Call<LWT_CallbackWallpaper> call = this.callbackCall;
        if (call != null && call.isExecuted()) {
            this.callbackCall.cancel();
        }
        this.lyt_shimmer.stopShimmer();
    }

    private void showFailedView(boolean z, String str) {
        View findViewById = this.root_view.findViewById(R.id.lytFailed);
        ((TextView) this.root_view.findViewById(R.id.tvFailedMessage)).setText(str);
        if (z) {
            this.recyclerView.setVisibility(View.GONE);
            findViewById.setVisibility(View.VISIBLE);
        } else {
            this.recyclerView.setVisibility(View.VISIBLE);
            findViewById.setVisibility(View.GONE);
        }
        this.root_view.findViewById(R.id.btnFailedRetry).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requestAction(failed_page);
            }
        });
    }

    private void showNoItemView(boolean z) {
        View findViewById = this.root_view.findViewById(R.id.lytNoitem);
        ((TextView) this.root_view.findViewById(R.id.tvNoItemMessage)).setText(R.string.lwt_txt_msg_no_item);
        if (z) {
            this.recyclerView.setVisibility(View.GONE);
            findViewById.setVisibility(View.VISIBLE);
            return;
        }
        this.recyclerView.setVisibility(View.VISIBLE);
        findViewById.setVisibility(View.GONE);
    }

    private void swipeProgress(boolean z) {
        if (!z) {
            this.swipeRefreshLayout.setRefreshing(false);
            this.lyt_shimmer.setVisibility(View.GONE);
            this.lyt_shimmer.stopShimmer();
            return;
        }
        this.swipeRefreshLayout.post(new Runnable() {
            @Override
            public void run() {
                swipeRefreshLayout.setRefreshing(true);
                lyt_shimmer.setVisibility(View.VISIBLE);
                lyt_shimmer.startShimmer();
            }
        });
    }


    public void initShimmerLayout() {
        View findViewById = this.root_view.findViewById(R.id.viewShimmer2Columns);
        View findViewById2 = this.root_view.findViewById(R.id.viewShimmer3Columns);
        this.root_view.findViewById(R.id.viewShimmer2ColumnsSquare);
        this.root_view.findViewById(R.id.viewShimmer3ColumnsSquare);
        if (this.sharedPref.getWallpaperColumns().intValue() == 3) {
            findViewById2.setVisibility(View.VISIBLE);
        } else {
            findViewById.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.menu_sort) {
            String[] stringArray = getResources().getStringArray(R.array.dialog_sort_wallpaper);
            this.single_choice_selected = stringArray[this.sharedPref.getCurrentSortWallpaper().intValue()];
            new AlertDialog.Builder(requireActivity()).setTitle("Sort Wallpapers").setSingleChoiceItems(stringArray, this.sharedPref.getCurrentSortWallpaper().intValue(), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    single_choice_selected = stringArray[i];
                }
            }).setPositiveButton(R.string.lwt_txt_dialog_option_ok, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Call<LWT_CallbackWallpaper> call = callbackCall;
                    if (call != null && call.isExecuted()) {
                        callbackCall.cancel();
                    }
                    adapterWallpaper.resetListData();
                    requestAction(1);
                    if (single_choice_selected.equals(getResources().getString(R.string.lwt_txt_menu_recent))) {
                        sharedPref.updateSortWallpaper(0);
                        dbHelper.deleteAll(LWT_DBHelper.TABLE_RECENT);
                    } else if (single_choice_selected.equals(getResources().getString(R.string.lwt_txt_menu_featured))) {
                        sharedPref.updateSortWallpaper(1);
                        dbHelper.deleteAll(LWT_DBHelper.TABLE_FEATURED);
                    } else if (single_choice_selected.equals(getResources().getString(R.string.lwt_txt_menu_popular))) {
                        sharedPref.updateSortWallpaper(2);
                        dbHelper.deleteAll(LWT_DBHelper.TABLE_POPULAR);
                    } else if (single_choice_selected.equals(getResources().getString(R.string.lwt_txt_menu_random))) {
                        sharedPref.updateSortWallpaper(3);
                        dbHelper.deleteAll(LWT_DBHelper.TABLE_RANDOM);
                    } else if (single_choice_selected.equals(getResources().getString(R.string.lwt_txt_menu_live))) {
                        sharedPref.updateSortWallpaper(4);
                        dbHelper.deleteAll(LWT_DBHelper.TABLE_GIF);
                    }
                    dialogInterface.dismiss();
                }
            }).show();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    @Override
    public void onResume() {
        super.onResume();
    }
}
