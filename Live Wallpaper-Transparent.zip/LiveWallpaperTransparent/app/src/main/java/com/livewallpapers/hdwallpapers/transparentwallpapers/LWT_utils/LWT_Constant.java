package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils;

import android.app.Activity;



public class LWT_Constant {
    static Activity activity;

    public LWT_Constant(Activity activity) {
        this.activity = activity;
    }

    public static final String ARRAY_LIST = "key.ARRAY_LIST";
    public static final String BASE_IMAGE_URL = ("https://sarkaribhaiya.com/apps/wallpaper/upload/");
    public static final String BOTH = "both";
    public static final String BUNDLE = "key.BUNDLE";
    public static final String DOWNLOAD = "download";
    public static final String EXTRA_OBJC = "key.EXTRA_OBJC";
    public static final String FILTER_ALL = "g.image_extension != 'all'";
    public static final String FILTER_LIVE = "g.image_extension = 'image/gif'";
    public static final String FILTER_WALLPAPER = "g.image_extension != 'image/gif'";
    public static final String HOME_SCREEN = "home_screen";
    public static final String LOCK_SCREEN = "lock_screen";
    public static final String ORDER_FEATURED = "AND g.featured = 'yes' ORDER BY g.last_update DESC";
    public static final String ORDER_LIVE = "ORDER BY g.id DESC ";
    public static final String ORDER_POPULAR = "ORDER BY g.view_count DESC";
    public static final String ORDER_RANDOM = "ORDER BY RAND()";
    public static final String ORDER_RECENT = "ORDER BY g.id DESC";
    public static final String POSITION = "POSITION_ID";
    public static final String SET_GIF = "setGif";
    public static final String SET_WITH = "setWith";
    public static final String SHARE = "share";
    public static String gifName = "";
    public static String gifPath = "";
}
