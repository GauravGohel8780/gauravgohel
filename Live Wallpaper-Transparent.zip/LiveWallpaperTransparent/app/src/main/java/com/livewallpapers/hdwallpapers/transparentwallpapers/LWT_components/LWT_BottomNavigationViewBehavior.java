package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_components;

import android.view.View;

import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class LWT_BottomNavigationViewBehavior extends CoordinatorLayout.Behavior<BottomNavigationView> {
    private int height;

    public boolean onStartNestedScroll(CoordinatorLayout coordinatorLayout, BottomNavigationView bottomNavigationView, View view, View view2, int i, int i2) {
        return i == 2;
    }

    public boolean onLayoutChild(CoordinatorLayout coordinatorLayout, BottomNavigationView bottomNavigationView, int i) {
        this.height = bottomNavigationView.getHeight();
        return super.onLayoutChild(coordinatorLayout,bottomNavigationView, i);
    }

    public void onNestedScroll(CoordinatorLayout coordinatorLayout, BottomNavigationView bottomNavigationView, View view, int i, int i2, int i3, int i4, int i5) {
        if (i2 > 0) {
            slideDown(bottomNavigationView);
        } else if (i2 < 0) {
            slideUp(bottomNavigationView);
        }
    }

    private void slideUp(BottomNavigationView bottomNavigationView) {
        bottomNavigationView.clearAnimation();
        bottomNavigationView.animate().translationY(0.0f).setDuration(200);
    }

    private void slideDown(BottomNavigationView bottomNavigationView) {
        bottomNavigationView.clearAnimation();
        bottomNavigationView.animate().translationY((float) this.height).setDuration(200);
    }
}
