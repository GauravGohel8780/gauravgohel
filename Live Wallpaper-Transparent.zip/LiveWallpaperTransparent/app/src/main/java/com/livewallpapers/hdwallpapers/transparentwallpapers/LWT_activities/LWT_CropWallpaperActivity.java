package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_activities;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.FragmentActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.canhub.cropper.CropImageView;
import com.google.android.material.snackbar.Snackbar;


import com.iten.tenoku.ad.AdShow;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.livewallpapers.hdwallpapers.transparentwallpapers.Ads_Common.AdsBaseActivity;
import com.livewallpapers.hdwallpapers.transparentwallpapers.R;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_sqlite.LWT_DBHelper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_Constant;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_WallpaperHelper;

public class LWT_CropWallpaperActivity extends AdsBaseActivity {
    private Bitmap bitmap = null;
    private CropImageView cropImageView;
    private String imageUrl;
    private CoordinatorLayout rlParentView;
    private ProgressDialog progressDialog;
    private String SingleChoiceSelected;
    private LWT_WallpaperHelper wallpaperHelper;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.lwt_activity_set_wallpaper);


        this.progressDialog = new ProgressDialog(this);
        this.wallpaperHelper = new LWT_WallpaperHelper(this);
        this.imageUrl = getIntent().getStringExtra(LWT_DBHelper.IMAGE_URL);
        this.cropImageView = (CropImageView) findViewById(R.id.cropImageView);
        this.rlParentView = (CoordinatorLayout) findViewById(R.id.coordinatorLayout);
        loadWallpaper();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return true;
        }
        onBackPressed();
        return true;
    }

    public void loadWallpaper() {
        Glide.with((FragmentActivity) this).load(this.imageUrl.replace(" ", "%20")).into(new CustomTarget<Drawable>() {
            @Override
            public void onLoadCleared(Drawable drawable) {

            }
            public void onResourceReady(Drawable drawable, Transition<? super Drawable> transition) {
                LWT_CropWallpaperActivity.this.bitmap = ((BitmapDrawable) drawable).getBitmap();
                LWT_CropWallpaperActivity.this.cropImageView.setImageBitmap(LWT_CropWallpaperActivity.this.bitmap);
                LWT_CropWallpaperActivity.this.findViewById(R.id.btnSetWallpaper).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        LWT_CropWallpaperActivity.this.dialogOptionSetWallpaper();
                    }
                });
            }

            @Override
            public void onLoadFailed(Drawable drawable) {
                super.onLoadFailed(drawable);
                Snackbar.make(LWT_CropWallpaperActivity.this.rlParentView, "Wallpaper not set.", -1).show();
            }
        });
    }

    public void dialogOptionSetWallpaper() {
        String[] stringArray = getResources().getStringArray(R.array.dialog_set_crop_wallpaper);
        this.SingleChoiceSelected = stringArray[0];
        this.bitmap = this.cropImageView.getCroppedImage();
        new AlertDialog.Builder(this).setTitle("Set As :").setSingleChoiceItems(stringArray, 0, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                SingleChoiceSelected = stringArray[i];
            }
        }).setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                progressDialog.setMessage("Preparing wallpaper…");
                progressDialog.setCancelable(false);
                progressDialog.show();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        getInstance(LWT_CropWallpaperActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                if (SingleChoiceSelected.equals(getResources().getString(R.string.lwt_txt_set_home_screen))) {
                                    wallpaperHelper.setWallpaper(rlParentView, progressDialog, bitmap, LWT_Constant.HOME_SCREEN);
                                    progressDialog.setMessage("Applying wallpaper…");
                                } else if (SingleChoiceSelected.equals(getResources().getString(R.string.lwt_txt_set_lock_screen))) {
                                    wallpaperHelper.setWallpaper(rlParentView, progressDialog, bitmap, LWT_Constant.LOCK_SCREEN);
                                    progressDialog.setMessage("Applying wallpaper…");
                                } else if (SingleChoiceSelected.equals(getResources().getString(R.string.lwt_txt_set_both))) {
                                    wallpaperHelper.setWallpaper(rlParentView, progressDialog, bitmap, LWT_Constant.BOTH);
                                    progressDialog.setMessage("Applying wallpaper…");
                                }
                                progressDialog.dismiss();
                            }
                        }, MAIN_CLICK);
                    }
                }, 2500);
            }
        }).setNegativeButton("cancel", (DialogInterface.OnClickListener) null).show();
    }


    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 203) {
            onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        AdShow.getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
