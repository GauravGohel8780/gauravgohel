package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_components;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

import com.ogaclejapan.smarttablayout.SmartTabLayout;

public class LWT_CustomTabLayout extends SmartTabLayout {
    public LWT_CustomTabLayout(Context context) {
        super(context);
    }

    public LWT_CustomTabLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public LWT_CustomTabLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    
    @Override
    public TextView createDefaultTabView(CharSequence charSequence) {
        return super.createDefaultTabView(charSequence);
    }
}
