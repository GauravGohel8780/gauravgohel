package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_fragments;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.facebook.shimmer.ShimmerFrameLayout;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.livewallpapers.hdwallpapers.transparentwallpapers.R;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_activities.LWT_WallpaperDetailActivity;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_adapters.LWT_WallpaperAdapter;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_callbacks.LWT_CallbackWallpaper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_prefs.LWT_SharedPref;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_sqlite.LWT_DBHelper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models.LWT_Wallpaper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_rests.LWT_ApiInterface;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_rests.LWT_RestAdapter;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_Constant;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_Tools;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LWT_WallpaperFragment extends Fragment {
    private static final String ARG_FILTER = "filter";
    private static final String ARG_ORDER = "order";
    private LWT_WallpaperAdapter adapterWallpaper;
    private Call<LWT_CallbackWallpaper> callbackCall = null;
    private LWT_DBHelper dbHelper;
    private int failed_page = 0;
    private String filter;
    private final List<LWT_Wallpaper> items = new ArrayList();
    private ShimmerFrameLayout lyt_shimmer;
    private String order;
    private int post_total = 0;
    private RecyclerView recyclerView;
    private View root_view;
    private LWT_SharedPref sharedPref;
    private SwipeRefreshLayout swipeRefreshLayout;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        String str = "";
        this.order = getArguments() != null ? getArguments().getString(ARG_ORDER) : str;
        if (getArguments() != null) {
            str = getArguments().getString(ARG_FILTER);
        }
        this.filter = str;
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.root_view = layoutInflater.inflate(R.layout.lwt_fragment_wallpaper, viewGroup, false);
        setHasOptionsMenu(true);
        this.dbHelper = new LWT_DBHelper(requireActivity());
        this.sharedPref = new LWT_SharedPref(requireActivity());
        this.swipeRefreshLayout = (SwipeRefreshLayout) this.root_view.findViewById(R.id.swipeRefreshLayout);
        this.swipeRefreshLayout.setProgressBackgroundColorSchemeColor(getResources().getColor(R.color.lwtColorSwipeRefreshDark));
        this.swipeRefreshLayout.setColorSchemeResources(R.color.lwtColorSwipeRefresh_1, R.color.lwtColorSwipeRefresh_2, R.color.lwtColorSwipeRefresh_3, R.color.lwtColorSwipeRefresh_4);
        this.lyt_shimmer = (ShimmerFrameLayout) this.root_view.findViewById(R.id.shimmerViewContainer);
        initShimmerLayout();
        recyclerView = (RecyclerView) this.root_view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new StaggeredGridLayoutManager(this.sharedPref.getWallpaperColumns().intValue(), 1));
        this.recyclerView.setHasFixedSize(true);
        adapterWallpaper = new LWT_WallpaperAdapter(requireActivity(), this.recyclerView, this.items);
        this.recyclerView.setAdapter(adapterWallpaper);
        this.adapterWallpaper.setOnItemClickListener(new LWT_WallpaperAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, LWT_Wallpaper wallpaper, int i) {
                getInstance(getActivity()).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(requireActivity(), LWT_WallpaperDetailActivity.class);
                        intent.putExtra(LWT_Constant.POSITION, i);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable(LWT_Constant.ARRAY_LIST, (Serializable) items);
                        intent.putExtra(LWT_Constant.BUNDLE, bundle);
                        intent.putExtra(LWT_Constant.EXTRA_OBJC, wallpaper);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });
        this.recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            /* class com.livewallpapers.hdwallpapers.transparentwallpapers.fragments.FragmentWallpaper.AnonymousClass1 */

            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int i) {
                super.onScrollStateChanged(recyclerView, i);
            }
        });
        this.adapterWallpaper.setOnLoadMoreListener(new LWT_WallpaperAdapter.OnLoadMoreListener() {
            @Override
            public void onLoadMore(int i) {
                if (post_total <= adapterWallpaper.getItemCount() || i == 0) {
                    adapterWallpaper.setLoaded();
                } else {
                    requestAction(i + 1);
                }
            }
        });
        this.swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                Call<LWT_CallbackWallpaper> call = callbackCall;
                if (call != null && call.isExecuted()) {
                    callbackCall.cancel();
                }
                adapterWallpaper.resetListData();
                if (LWT_Tools.isConnect(requireActivity())) {
                    dbHelper.deleteAll(LWT_DBHelper.TABLE_RECENT);
                }
                requestAction(1);
            }
        });
        requestAction(1);
        return this.root_view;
    }

    public static LWT_WallpaperFragment newInstance(String str, String str2) {
        LWT_WallpaperFragment fragmentWallpaper = new LWT_WallpaperFragment();
        Bundle bundle = new Bundle();
        bundle.putString(ARG_ORDER, str);
        bundle.putString(ARG_FILTER, str2);
        fragmentWallpaper.setArguments(bundle);
        return fragmentWallpaper;
    }

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
    }

    private void displayApiResult(List<LWT_Wallpaper> list) {
        insertData(list);
        swipeProgress(false);
        if (list.size() == 0) {
            showNoItemView(true);
        }
    }

    private void loadDataFromDatabase(Call<LWT_CallbackWallpaper> call, int i) {
        String str = this.order;
        str.hashCode();
        char c = 65535;
        switch (str.hashCode()) {
            case -986885352:
                if (str.equals(LWT_Constant.ORDER_RECENT)) {
                    c = 0;
                    break;
                }
                break;
            case -528674808:
                if (str.equals(LWT_Constant.ORDER_LIVE)) {
                    c = 1;
                    break;
                }
                break;
            case 100865918:
                if (str.equals(LWT_Constant.ORDER_POPULAR)) {
                    c = 2;
                    break;
                }
                break;
            case 1060734301:
                if (str.equals(LWT_Constant.ORDER_RANDOM)) {
                    c = 3;
                    break;
                }
                break;
            case 1220360383:
                if (str.equals(LWT_Constant.ORDER_FEATURED)) {
                    c = 4;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                List<LWT_Wallpaper> allWallpaper = this.dbHelper.getAllWallpaper(LWT_DBHelper.TABLE_RECENT);
                insertData(allWallpaper);
                if (allWallpaper.size() == 0 && !call.isCanceled()) {
                    onFailRequest(i);
                    return;
                }
                return;
            case 1:
                List<LWT_Wallpaper> allWallpaper2 = this.dbHelper.getAllWallpaper(LWT_DBHelper.TABLE_GIF);
                insertData(allWallpaper2);
                if (allWallpaper2.size() == 0 && !call.isCanceled()) {
                    onFailRequest(i);
                    return;
                }
                return;
            case 2:
                List<LWT_Wallpaper> allWallpaper3 = this.dbHelper.getAllWallpaper(LWT_DBHelper.TABLE_POPULAR);
                insertData(allWallpaper3);
                if (allWallpaper3.size() == 0 && !call.isCanceled()) {
                    onFailRequest(i);
                    return;
                }
                return;
            case 3:
                List<LWT_Wallpaper> allWallpaper4 = this.dbHelper.getAllWallpaper(LWT_DBHelper.TABLE_RANDOM);
                insertData(allWallpaper4);
                if (allWallpaper4.size() == 0 && !call.isCanceled()) {
                    onFailRequest(i);
                    return;
                }
                return;
            case 4:
                List<LWT_Wallpaper> allWallpaper5 = this.dbHelper.getAllWallpaper(LWT_DBHelper.TABLE_FEATURED);
                insertData(allWallpaper5);
                if (allWallpaper5.size() == 0 && !call.isCanceled()) {
                    onFailRequest(i);
                    return;
                }
                return;
            default:
                return;
        }
    }

    private void insertData(List<LWT_Wallpaper> list) {
        this.adapterWallpaper.insertData(list);
    }

    private void onFailRequest(int i) {
        this.failed_page = i;
        this.adapterWallpaper.setLoaded();
        swipeProgress(false);
        showFailedView(true, getString(R.string.lwt_txt_failed_text));
    }

    public void requestAction(int i) {
        showFailedView(false, "");
        showNoItemView(false);
        if (i == 1) {
            swipeProgress(true);
        } else {
            this.adapterWallpaper.setLoading();
        }
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                LWT_ApiInterface createAPI = LWT_RestAdapter.createAPI();
                if (sharedPref.getWallpaperColumns().intValue() == 3) {
                    callbackCall = createAPI.getWallpapers(i, 24, filter, order);
                } else {
                    callbackCall = createAPI.getWallpapers(i, 20, filter, order);
                }
                callbackCall.enqueue(new Callback<LWT_CallbackWallpaper>() {
                    @Override
                    public void onResponse(Call<LWT_CallbackWallpaper> call, Response<LWT_CallbackWallpaper> response) {
                        LWT_CallbackWallpaper body = response.body();
                        if (body == null || !body.status.equals("ok")) {
                            LWT_WallpaperFragment.this.onFailRequest(i);
                            return;
                        }
                        LWT_WallpaperFragment.this.post_total = body.count_total;
                        LWT_WallpaperFragment.this.displayApiResult(body.posts);
                        String str = LWT_WallpaperFragment.this.order;
                        str.hashCode();
                        char c = 65535;
                        switch (str.hashCode()) {
                            case -986885352:
                                if (str.equals(LWT_Constant.ORDER_RECENT)) {
                                    c = 0;
                                    break;
                                }
                                break;
                            case -528674808:
                                if (str.equals(LWT_Constant.ORDER_LIVE)) {
                                    c = 1;
                                    break;
                                }
                                break;
                            case 100865918:
                                if (str.equals(LWT_Constant.ORDER_POPULAR)) {
                                    c = 2;
                                    break;
                                }
                                break;
                            case 1060734301:
                                if (str.equals(LWT_Constant.ORDER_RANDOM)) {
                                    c = 3;
                                    break;
                                }
                                break;
                            case 1220360383:
                                if (str.equals(LWT_Constant.ORDER_FEATURED)) {
                                    c = 4;
                                    break;
                                }
                                break;
                        }
                        switch (c) {
                            case 0:
                                if (i == 1) {
                                    LWT_WallpaperFragment.this.dbHelper.truncateTableWallpaper(LWT_DBHelper.TABLE_RECENT);
                                }
                                LWT_WallpaperFragment.this.dbHelper.addListWallpaper(body.posts, LWT_DBHelper.TABLE_RECENT);
                                return;
                            case 1:
                                if (i == 1) {
                                    LWT_WallpaperFragment.this.dbHelper.truncateTableWallpaper(LWT_DBHelper.TABLE_GIF);
                                }
                                LWT_WallpaperFragment.this.dbHelper.addListWallpaper(body.posts, LWT_DBHelper.TABLE_GIF);
                                return;
                            case 2:
                                if (i == 1) {
                                    LWT_WallpaperFragment.this.dbHelper.truncateTableWallpaper(LWT_DBHelper.TABLE_POPULAR);
                                }
                                LWT_WallpaperFragment.this.dbHelper.addListWallpaper(body.posts, LWT_DBHelper.TABLE_POPULAR);
                                return;
                            case 3:
                                if (i == 1) {
                                    LWT_WallpaperFragment.this.dbHelper.truncateTableWallpaper(LWT_DBHelper.TABLE_RANDOM);
                                }
                                LWT_WallpaperFragment.this.dbHelper.addListWallpaper(body.posts, LWT_DBHelper.TABLE_RANDOM);
                                return;
                            case 4:
                                if (i == 1) {
                                    LWT_WallpaperFragment.this.dbHelper.truncateTableWallpaper(LWT_DBHelper.TABLE_FEATURED);
                                }
                                LWT_WallpaperFragment.this.dbHelper.addListWallpaper(body.posts, LWT_DBHelper.TABLE_FEATURED);
                                return;
                            default:
                                return;
                        }
                    }

                    @Override
                    public void onFailure(Call<LWT_CallbackWallpaper> call, Throwable th) {
                        LWT_WallpaperFragment.this.swipeProgress(false);
                        LWT_WallpaperFragment.this.loadDataFromDatabase(call, i);
                    }
                });
            }
        }, 0);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        swipeProgress(false);
        Call<LWT_CallbackWallpaper> call = this.callbackCall;
        if (call != null && call.isExecuted()) {
            this.callbackCall.cancel();
        }
        this.lyt_shimmer.stopShimmer();
    }

    private void showFailedView(boolean z, String str) {
        View findViewById = this.root_view.findViewById(R.id.lytFailed);
        ((TextView) this.root_view.findViewById(R.id.tvFailedMessage)).setText(str);
        if (z) {
            this.recyclerView.setVisibility(View.GONE);
            findViewById.setVisibility(View.VISIBLE);
        } else {
            this.recyclerView.setVisibility(View.VISIBLE);
            findViewById.setVisibility(View.GONE);
        }
        this.root_view.findViewById(R.id.btnFailedRetry).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requestAction(failed_page);
            }
        });
    }

    private void showNoItemView(boolean z) {
        View findViewById = this.root_view.findViewById(R.id.lytNoitem);
        ((TextView) this.root_view.findViewById(R.id.tvNoItemMessage)).setText(R.string.lwt_txt_msg_no_item);
        if (z) {
            this.recyclerView.setVisibility(View.GONE);
            findViewById.setVisibility(View.VISIBLE);
            return;
        }
        this.recyclerView.setVisibility(View.VISIBLE);
        findViewById.setVisibility(View.GONE);
    }

    private void swipeProgress(boolean z) {
        if (!z) {
            this.swipeRefreshLayout.setRefreshing(false);
            this.lyt_shimmer.setVisibility(View.GONE);
            this.lyt_shimmer.stopShimmer();
            return;
        }
        this.swipeRefreshLayout.post(new Runnable() {
            @Override
            public void run() {
                swipeRefreshLayout.setRefreshing(true);
                lyt_shimmer.setVisibility(View.VISIBLE);
                lyt_shimmer.startShimmer();
            }
        });
    }

    public void initShimmerLayout() {
        View findViewById = this.root_view.findViewById(R.id.viewShimmer2Columns);
        View findViewById2 = this.root_view.findViewById(R.id.viewShimmer3Columns);
        this.root_view.findViewById(R.id.viewShimmer2ColumnsSquare);
        this.root_view.findViewById(R.id.viewShimmer3ColumnsSquare);
        if (this.sharedPref.getWallpaperColumns().intValue() == 3) {
            findViewById2.setVisibility(View.VISIBLE);
        } else {
            findViewById.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }
}
