package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_rests;

import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_callbacks.LWT_CallbackCategory;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_callbacks.LWT_CallbackWallpaper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models.LWT_Wallpaper;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface LWT_ApiInterface {
    String AGENT = "Data-Agent: Material Wallpaper";
    String CACHE = "Cache-Control: max-age=0";

    @Headers({CACHE, AGENT})
    @GET("api.php?get_categories")
    Call<LWT_CallbackCategory> getCategories();

    @Headers({CACHE, AGENT})
    @GET("api.php?get_category_details")
    Call<LWT_CallbackWallpaper> getCategoryDetails(@Query("page") int i, @Query("count") int i2, @Query("id") String str, @Query("filter") String str2, @Query("order") String str3);

    @Headers({CACHE, AGENT})
    @GET("api.php?get_search")
    Call<LWT_CallbackWallpaper> getSearch(@Query("page") int i, @Query("count") int i2, @Query("search") String str, @Query("order") String str2);

    @Headers({CACHE, AGENT})
    @GET("api.php?get_search_category")
    Call<LWT_CallbackCategory> getSearchCategory(@Query("search") String str);

    @Headers({CACHE, AGENT})
    @GET("api.php?get_wallpapers")
    Call<LWT_CallbackWallpaper> getWallpapers(@Query("page") int i, @Query("count") int i2, @Query("filter") String str, @Query("order") String str2);

    @FormUrlEncoded
    @POST("api.php?update_download")
    Call<LWT_Wallpaper> updateDownload(@Field("image_id") String str);

    @FormUrlEncoded
    @POST("api.php?update_view")
    Call<LWT_Wallpaper> updateView(@Field("image_id") String str);
}
