package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_activities;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;


import com.livewallpapers.hdwallpapers.transparentwallpapers.R;

public class LWT_TwoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lwt_activity_two);
        findViewById(R.id.rlNext).setOnClickListener(view -> {

            Intent intent = new Intent(LWT_TwoActivity.this, LWT_MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);

        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}