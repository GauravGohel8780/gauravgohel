package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.livewallpapers.hdwallpapers.transparentwallpapers.R;

import java.util.ArrayList;

public class LWT_TagsAdapter extends RecyclerView.Adapter<LWT_TagsAdapter.ViewHolder> {
    private final ArrayList<String> arrayList;
    private final Context context;
    private OnItemClickListener mOnItemClickListener;

    public interface OnItemClickListener {
        void onItemClick(View view, String str, int i);
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.mOnItemClickListener = onItemClickListener;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvItemTags;

        public ViewHolder(View view) {
            super(view);
            this.tvItemTags = (TextView) view.findViewById(R.id.tvItemTags);
        }
    }

    public LWT_TagsAdapter(Context context2, ArrayList<String> arrayList2) {
        this.context = context2;
        this.arrayList = arrayList2;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.lwt_item_tags, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder,@SuppressLint("RecyclerView") int i) {
        String lowerCase = this.arrayList.get(i).toLowerCase();
        viewHolder.tvItemTags.setText(lowerCase);
        viewHolder.tvItemTags.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OnItemClickListener onItemClickListener = mOnItemClickListener;
                if (onItemClickListener != null) {
                    onItemClickListener.onItemClick(view, lowerCase, i);
                }
            }
        });
    }



    @Override
    public int getItemCount() {
        return this.arrayList.size();
    }
}
