package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_prefs.LWT_SharedPref;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models.LWT_Category;
import com.livewallpapers.hdwallpapers.transparentwallpapers.R;

import java.util.List;

public class LWT_CategoryAdapter extends RecyclerView.Adapter<LWT_CategoryAdapter.ViewHolder> {
    private Context context;
    private List<LWT_Category> items;
    private OnItemClickListener mOnItemClickListener;

    public interface OnItemClickListener {
        void onItemClick(View view, LWT_Category category, int i);
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.mOnItemClickListener = onItemClickListener;
    }

    public LWT_CategoryAdapter(Context context2, List<LWT_Category> list) {
        this.items = list;
        this.context = context2;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public CardView card_view;
        public ImageView category_image;
        public TextView category_name;
        public FrameLayout lyt_parent;

        public ViewHolder(View view) {
            super(view);
            this.category_name = (TextView) view.findViewById(R.id.tvCategoryName);
            this.category_image = (ImageView) view.findViewById(R.id.ivCategoryImage);
            this.card_view = (CardView) view.findViewById(R.id.cardView);
            this.lyt_parent = (FrameLayout) view.findViewById(R.id.lytParent);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.lwt_item_category, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, @SuppressLint("RecyclerView") int i) {
        LWT_Category category = this.items.get(i);
        viewHolder.category_name.setText(category.category_name);
        if (new LWT_SharedPref(this.context).getIsDarkTheme().booleanValue()) {
            viewHolder.card_view.setCardBackgroundColor(this.context.getResources().getColor(R.color.lwtColorShimmer));
        } else {
            viewHolder.card_view.setCardBackgroundColor(this.context.getResources().getColor(R.color.lwtColorShimmer));
        }
        RequestManager with = Glide.with(this.context);
        ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) with.load("https://sarkaribhaiya.com/apps/wallpaper" + "/upload/category/" + category.category_image.replace(" ", "%20")).placeholder((int) R.drawable.bg_transparent)).diskCacheStrategy(DiskCacheStrategy.ALL)).centerCrop()).into(viewHolder.category_image);
        viewHolder.lyt_parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OnItemClickListener onItemClickListener = mOnItemClickListener;
                if (onItemClickListener != null) {
                    onItemClickListener.onItemClick(view, category, i);
                }
            }
        });
    }



    public void insertData(List<LWT_Category> list) {
        this.items.addAll(list);
    }

    public void setListData(List<LWT_Category> list) {
        this.items = list;
        notifyDataSetChanged();
    }

    public void resetListData() {
        this.items.clear();
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return this.items.size();
    }
}
