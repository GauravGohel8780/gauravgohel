package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.facebook.shimmer.ShimmerFrameLayout;

import com.livewallpapers.hdwallpapers.transparentwallpapers.R;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_activities.LWT_CategoryDetailsActivity;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_adapters.LWT_CategoryAdapter;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_callbacks.LWT_CallbackCategory;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_components.LWT_ItemOffsetDecoration;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_prefs.LWT_SharedPref;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_sqlite.LWT_DBHelper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models.LWT_Category;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_rests.LWT_RestAdapter;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_Constant;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_Tools;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LWT_CategoryFragment extends Fragment {
    private LWT_CategoryAdapter adapterCategory;
    private Call<LWT_CallbackCategory> callbackCall = null;
    private LWT_DBHelper dbHelper;
    private ShimmerFrameLayout lyt_shimmer;
    private RecyclerView recyclerView;
    private View root_view;
    private SwipeRefreshLayout swipeRefreshLayout;

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.root_view = layoutInflater.inflate(R.layout.lwt_fragment_category, viewGroup, false);
        this.dbHelper = new LWT_DBHelper(requireActivity());
        LWT_SharedPref sharedPref = new LWT_SharedPref(requireActivity());
        LinearLayoutCompat linearLayoutCompat = (LinearLayoutCompat) this.root_view.findViewById(R.id.parent_view);
        SwipeRefreshLayout swipeRefreshLayout2 = (SwipeRefreshLayout) this.root_view.findViewById(R.id.swipeRefreshLayout);
        this.swipeRefreshLayout = swipeRefreshLayout2;
        swipeRefreshLayout2.setColorSchemeResources(R.color.lwtColorSwipeRefresh_1, R.color.lwtColorSwipeRefresh_2, R.color.lwtColorSwipeRefresh_3, R.color.lwtColorSwipeRefresh_4);
        this.lyt_shimmer = (ShimmerFrameLayout) this.root_view.findViewById(R.id.shimmerViewContainer);
        linearLayoutCompat.setBackgroundColor(getResources().getColor(R.color.lwtColorColorBackgroundDark));
        this.swipeRefreshLayout.setProgressBackgroundColorSchemeColor(getResources().getColor(R.color.lwtColorSwipeRefreshDark));
        this.recyclerView = (RecyclerView) this.root_view.findViewById(R.id.recyclerView);
        int dimensionPixelOffset = getResources().getDimensionPixelOffset(R.dimen.lwt_dp_2);
        this.recyclerView.setPadding(dimensionPixelOffset, dimensionPixelOffset, dimensionPixelOffset, dimensionPixelOffset);
        this.recyclerView.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
        this.recyclerView.addItemDecoration(new LWT_ItemOffsetDecoration(requireActivity(), R.dimen.lwt_dp_2));
        this.recyclerView.setHasFixedSize(true);
        LWT_CategoryAdapter adapterCategory2 = new LWT_CategoryAdapter(requireActivity(), new ArrayList());
        this.adapterCategory = adapterCategory2;
        this.recyclerView.setAdapter(adapterCategory2);
        this.adapterCategory.setOnItemClickListener(new LWT_CategoryAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, LWT_Category category, int i) {
                Intent intent = new Intent(requireActivity(), LWT_CategoryDetailsActivity.class);
                intent.putExtra(LWT_Constant.EXTRA_OBJC, category);
                startActivity(intent);
            }
        });
        this.swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                adapterCategory.resetListData();
                requestAction();
            }
        });
        requestAction();
        return this.root_view;
    }

    private void displayApiResult(List<LWT_Category> list) {
        Collections.shuffle(list);
        this.adapterCategory.setListData(list);
        swipeProgress(false);
        if (list.size() == 0) {
            showNoItemView(true);
        }
    }

    private void onFailRequest() {
        swipeProgress(false);
        if (LWT_Tools.isConnect(requireActivity())) {
            showFailedView(true, getString(R.string.lwt_txt_failed_text));
        } else {
            showFailedView(true, getString(R.string.lwt_txt_failed_text));
        }
    }

    private void requestAction() {
        showFailedView(false, "");
        swipeProgress(true);
        showNoItemView(false);
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                Call<LWT_CallbackCategory> categories = LWT_RestAdapter.createAPI().getCategories();
                callbackCall = categories;
                categories.enqueue(new Callback<LWT_CallbackCategory>() {
                    @Override
                    public void onResponse(Call<LWT_CallbackCategory> call, Response<LWT_CallbackCategory> response) {
                        LWT_CallbackCategory body = response.body();
                        if (body == null || !body.status.equals("ok")) {
                            LWT_CategoryFragment.this.onFailRequest();
                            return;
                        }
                        LWT_CategoryFragment.this.displayApiResult(body.categories);
                        LWT_CategoryFragment.this.dbHelper.truncateTableCategory(LWT_DBHelper.TABLE_CATEGORY);
                        LWT_CategoryFragment.this.dbHelper.addListCategory(body.categories, LWT_DBHelper.TABLE_CATEGORY);
                    }

                    @Override
                    public void onFailure(Call<LWT_CallbackCategory> call, Throwable th) {
                        LWT_CategoryFragment.this.swipeProgress(false);
                        List<LWT_Category> allCategory = LWT_CategoryFragment.this.dbHelper.getAllCategory(LWT_DBHelper.TABLE_CATEGORY);
                        LWT_CategoryFragment.this.adapterCategory.setListData(allCategory);
                        if (allCategory.size() == 0 && !call.isCanceled()) {
                            LWT_CategoryFragment.this.onFailRequest();
                        }
                    }
                });
            }
        }, 0);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        swipeProgress(false);
        Call<LWT_CallbackCategory> call = this.callbackCall;
        if (call != null && call.isExecuted()) {
            this.callbackCall.cancel();
        }
        this.lyt_shimmer.stopShimmer();
    }

    private void showFailedView(boolean z, String str) {
        View findViewById = this.root_view.findViewById(R.id.lytFailedCategory);
        ((TextView) this.root_view.findViewById(R.id.tvFailedMessage)).setText(str);
        if (z) {
            this.recyclerView.setVisibility(View.GONE);
            findViewById.setVisibility(View.VISIBLE);
        } else {
            this.recyclerView.setVisibility(View.VISIBLE);
            findViewById.setVisibility(View.GONE);
        }
        this.root_view.findViewById(R.id.btnFailedRetry).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requestAction();
            }
        });
    }


    private void showNoItemView(boolean z) {
        View findViewById = this.root_view.findViewById(R.id.lytNoItemCategory);
        ((TextView) this.root_view.findViewById(R.id.tvNoItemMessage)).setText(R.string.lwt_txt_no_category_found);
        if (z) {
            this.recyclerView.setVisibility(View.GONE);
            findViewById.setVisibility(View.VISIBLE);
            return;
        }
        this.recyclerView.setVisibility(View.VISIBLE);
        findViewById.setVisibility(View.GONE);
    }

    private void swipeProgress(boolean z) {
        if (!z) {
            this.swipeRefreshLayout.setRefreshing(false);
            this.lyt_shimmer.setVisibility(View.GONE);
            this.lyt_shimmer.stopShimmer();
            return;
        }
        this.swipeRefreshLayout.post(new Runnable() {
            @Override
            public void run() {
                swipeRefreshLayout.setRefreshing(true);
                lyt_shimmer.setVisibility(View.VISIBLE);
                lyt_shimmer.startShimmer();
            }
        });
    }
}
