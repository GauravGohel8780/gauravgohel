package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_activities;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.snackbar.Snackbar;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.livewallpapers.hdwallpapers.transparentwallpapers.Ads_Common.AdsBaseActivity;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_WallpaperHelper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.R;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_adapters.LWT_WallpaperAdapter;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_callbacks.LWT_CallbackWallpaper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_prefs.LWT_SharedPref;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_sqlite.LWT_DBHelper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models.LWT_Category;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models.LWT_Wallpaper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_rests.LWT_ApiInterface;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_rests.LWT_RestAdapter;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_Constant;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_Tools;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LWT_CategoryDetailsActivity extends AdsBaseActivity {
    private LWT_WallpaperAdapter adapterWallpaper;
    private Call<LWT_CallbackWallpaper> callbackCall = null;
    private LWT_Category category;
    private LWT_DBHelper dbHelper;
    private int failedPage = 0;
    private final List<LWT_Wallpaper> items = new ArrayList();
    private ShimmerFrameLayout lytShimmer;
    private int postTotal = 0;
    private RecyclerView recyclerView;
    private LWT_SharedPref sharedPref;
    private String SingleChoiceSelected;
    private SwipeRefreshLayout swipeRefreshLayout;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        LWT_Tools.getTheme(this);
        this.sharedPref = new LWT_SharedPref(this);
        setContentView(R.layout.lwt_activity_category_details);


        this.swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout);
        if (this.sharedPref.getIsDarkTheme().booleanValue()) {
            LWT_Tools.darkNavigation(this);
            this.swipeRefreshLayout.setProgressBackgroundColorSchemeColor(getResources().getColor(R.color.lwtColorPrimaryDark));
        } else {
            LWT_Tools.lightNavigation(this);
            this.swipeRefreshLayout.setProgressBackgroundColorSchemeColor(getResources().getColor(R.color.lwtColorPrimaryDark));
        }
        this.dbHelper = new LWT_DBHelper(this);
        this.sharedPref.setDefaultSortWallpaper();
        this.category = (LWT_Category) getIntent().getSerializableExtra(LWT_Constant.EXTRA_OBJC);
        this.swipeRefreshLayout.setColorSchemeResources(R.color.lwtColorSwipeRefresh_1, R.color.lwtColorSwipeRefresh_2, R.color.lwtColorSwipeRefresh_3, R.color.lwtColorSwipeRefresh_4);
        this.lytShimmer = (ShimmerFrameLayout) findViewById(R.id.shimmerViewContainer);
        initShimmerLayout();
        RecyclerView recyclerView2 = (RecyclerView) findViewById(R.id.recyclerView);
        this.recyclerView = recyclerView2;
        recyclerView2.setLayoutManager(new StaggeredGridLayoutManager(this.sharedPref.getWallpaperColumns().intValue(), 1));
        this.recyclerView.setHasFixedSize(true);
        LWT_WallpaperAdapter adapterWallpaper2 = new LWT_WallpaperAdapter(this, this.recyclerView, this.items);
        this.adapterWallpaper = adapterWallpaper2;
        this.recyclerView.setAdapter(adapterWallpaper2);
        this.adapterWallpaper.setOnItemClickListener(new LWT_WallpaperAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, LWT_Wallpaper wallpaper, int i) {
                getInstance(LWT_CategoryDetailsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(getApplicationContext(), LWT_WallpaperDetailActivity.class);
                        intent.putExtra(LWT_Constant.POSITION, i);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable(LWT_Constant.ARRAY_LIST, (Serializable) items);
                        intent.putExtra(LWT_Constant.BUNDLE, bundle);
                        intent.putExtra(LWT_Constant.EXTRA_OBJC, wallpaper);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);

            }
        });
        this.recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int i) {
                super.onScrollStateChanged(recyclerView, i);
            }
        });
        this.adapterWallpaper.setOnLoadMoreListener(new LWT_WallpaperAdapter.OnLoadMoreListener() {
            @Override
            public void onLoadMore(int i) {
                if (postTotal <= adapterWallpaper.getItemCount() || i == 0) {
                    adapterWallpaper.setLoaded();
                } else {
                    requestAction(i + 1);
                }
            }
        });
        this.swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                Call<LWT_CallbackWallpaper> call = callbackCall;
                if (call != null && call.isExecuted()) {
                    callbackCall.cancel();
                }
                adapterWallpaper.resetListData();
                if (LWT_Tools.isConnect(LWT_CategoryDetailsActivity.this)) {
                    dbHelper.deleteWallpaperByCategory(LWT_DBHelper.TABLE_CATEGORY_DETAIL, category.category_id);
                }
                requestAction(1);
            }
        });
        requestAction(1);
        setupToolbar();
        onOptionMenuClicked();
    }


    public void setupToolbar() {
        MaterialToolbar materialToolbar = (MaterialToolbar) findViewById(R.id.toolbar);
        TextView textView = (TextView) findViewById(R.id.tvTitleToolbar);
        setSupportActionBar(materialToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            textView.setText("" + this.category.category_name);
        }
    }


    private void displayApiResult(List<LWT_Wallpaper> list) {
        insertData(list);
        swipeProgress(false);
        if (list.size() == 0) {
            showNoItemView(true);
        }
    }


    private void loadDataFromDatabase(Call<LWT_CallbackWallpaper> call, int i) {
        List<LWT_Wallpaper> allWallpaperByCategory = this.dbHelper.getAllWallpaperByCategory(LWT_DBHelper.TABLE_CATEGORY_DETAIL, this.category.category_id);
        insertData(allWallpaperByCategory);
        if (allWallpaperByCategory.size() == 0 && !call.isCanceled()) {
            onFailRequest(i);
        }
    }

    private void insertData(List<LWT_Wallpaper> list) {
        this.adapterWallpaper.insertData(list);
    }


    private void onFailRequest(int i) {
        this.failedPage = i;
        this.adapterWallpaper.setLoaded();
        swipeProgress(false);
        showFailedView(true, getString(R.string.lwt_txt_failed_text));
    }

    private void requestAction(int i) {
        showFailedView(false, "");
        showNoItemView(false);
        if (i == 1) {
            swipeProgress(true);
        } else {
            this.adapterWallpaper.setLoading();
        }
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                LWT_ApiInterface createAPI = LWT_RestAdapter.createAPI();
                if (sharedPref.getWallpaperColumns().intValue() == 3) {
                    if (sharedPref.getCurrentSortWallpaper().intValue() == 0) {
                        callbackCall = createAPI.getCategoryDetails(i, 24, category.category_id, LWT_Constant.FILTER_ALL, LWT_Constant.ORDER_RECENT);
                    } else if (sharedPref.getCurrentSortWallpaper().intValue() == 1) {
                        callbackCall = createAPI.getCategoryDetails(i, 24, category.category_id, LWT_Constant.FILTER_ALL, LWT_Constant.ORDER_FEATURED);
                    } else if (sharedPref.getCurrentSortWallpaper().intValue() == 2) {
                        callbackCall = createAPI.getCategoryDetails(i, 24, category.category_id, LWT_Constant.FILTER_ALL, LWT_Constant.ORDER_POPULAR);
                    } else if (sharedPref.getCurrentSortWallpaper().intValue() == 3) {
                        callbackCall = createAPI.getCategoryDetails(i, 24, category.category_id, LWT_Constant.FILTER_ALL, LWT_Constant.ORDER_RANDOM);
                    } else if (sharedPref.getCurrentSortWallpaper().intValue() == 4) {
                        callbackCall = createAPI.getCategoryDetails(i, 24, category.category_id, LWT_Constant.FILTER_LIVE, LWT_Constant.ORDER_LIVE);
                    }
                } else if (sharedPref.getCurrentSortWallpaper().intValue() == 0) {
                    callbackCall = createAPI.getCategoryDetails(i, 20, category.category_id, LWT_Constant.FILTER_ALL, LWT_Constant.ORDER_RECENT);
                } else if (sharedPref.getCurrentSortWallpaper().intValue() == 1) {
                    callbackCall = createAPI.getCategoryDetails(i, 20, category.category_id, LWT_Constant.FILTER_ALL, LWT_Constant.ORDER_FEATURED);
                } else if (sharedPref.getCurrentSortWallpaper().intValue() == 2) {
                    callbackCall = createAPI.getCategoryDetails(i, 20, category.category_id, LWT_Constant.FILTER_ALL, LWT_Constant.ORDER_POPULAR);
                } else if (sharedPref.getCurrentSortWallpaper().intValue() == 3) {
                    callbackCall = createAPI.getCategoryDetails(i, 20, category.category_id, LWT_Constant.FILTER_ALL, LWT_Constant.ORDER_RANDOM);
                } else if (sharedPref.getCurrentSortWallpaper().intValue() == 4) {
                    callbackCall = createAPI.getCategoryDetails(i, 20, category.category_id, LWT_Constant.FILTER_LIVE, LWT_Constant.ORDER_LIVE);
                }
                callbackCall.enqueue(new Callback<LWT_CallbackWallpaper>() {

                    @Override
                    public void onResponse(Call<LWT_CallbackWallpaper> call, Response<LWT_CallbackWallpaper> response) {
                        LWT_CallbackWallpaper body = response.body();
                        if (body == null || !body.status.equals("ok")) {
                            LWT_CategoryDetailsActivity.this.onFailRequest(i);
                            return;
                        }
                        LWT_CategoryDetailsActivity.this.postTotal = body.count_total;
                        LWT_CategoryDetailsActivity.this.displayApiResult(body.posts);
                        if (i == 1) {
                            LWT_CategoryDetailsActivity.this.dbHelper.truncateTableWallpaper(LWT_DBHelper.TABLE_CATEGORY_DETAIL);
                        }
                        LWT_CategoryDetailsActivity.this.dbHelper.addListWallpaper(body.posts, LWT_DBHelper.TABLE_CATEGORY_DETAIL);
                    }

                    @Override
                    public void onFailure(Call<LWT_CallbackWallpaper> call, Throwable th) {
                        LWT_CategoryDetailsActivity.this.swipeProgress(false);
                        LWT_CategoryDetailsActivity.this.loadDataFromDatabase(call, i);
                    }
                });
            }
        }, 0);
    }

    private void showFailedView(boolean z, String str) {
        View findViewById = findViewById(R.id.lytFailed);
        ((TextView) findViewById(R.id.tvFailedMessage)).setText(str);
        if (z) {
            this.recyclerView.setVisibility(View.GONE);
            findViewById.setVisibility(View.VISIBLE);
        } else {
            this.recyclerView.setVisibility(View.VISIBLE);
            findViewById.setVisibility(View.GONE);
        }
        findViewById(R.id.btnFailedRetry).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requestAction(failedPage);
            }
        });
    }


    private void showNoItemView(boolean z) {
        View findViewById = findViewById(R.id.lytNoitem);
        ((TextView) findViewById(R.id.tvNoItemMessage)).setText(R.string.lwt_txt_msg_no_item);
        if (z) {
            this.recyclerView.setVisibility(View.GONE);
            findViewById.setVisibility(View.VISIBLE);
            return;
        }
        this.recyclerView.setVisibility(View.VISIBLE);
        findViewById.setVisibility(View.GONE);
    }

    private void swipeProgress(boolean z) {
        if (!z) {
            this.swipeRefreshLayout.setRefreshing(false);
            this.lytShimmer.setVisibility(View.GONE);
            this.lytShimmer.stopShimmer();
            return;
        }
        this.swipeRefreshLayout.post(new Runnable() {
            @Override
            public void run() {
                swipeRefreshLayout.setRefreshing(true);
                lytShimmer.setVisibility(View.VISIBLE);
                lytShimmer.startShimmer();
            }
        });
    }

    public void initShimmerLayout() {
        View findViewById = findViewById(R.id.viewShimmer2Columns);
        View findViewById2 = findViewById(R.id.viewShimmer3Columns);
        findViewById(R.id.viewShimmer2ColumnsSquare);
        findViewById(R.id.viewShimmer3ColumnsSquare);
        if (this.sharedPref.getWallpaperColumns().intValue() == 3) {
            findViewById2.setVisibility(View.VISIBLE);
        } else {
            findViewById.setVisibility(View.VISIBLE);
        }
    }

    public void onOptionMenuClicked() {
        findViewById(R.id.btnSearch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), LWT_SearchActivity.class);
                intent.putExtra(LWT_Constant.EXTRA_OBJC, "wallpaper");
                startActivity(intent);
            }
        });
        findViewById(R.id.btnSort).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(LWT_CategoryDetailsActivity.this);
                View bottomSheetView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.set_wallpaper_layout, null);
                bottomSheetDialog.setContentView(bottomSheetView);

                RelativeLayout rlhomescreen = bottomSheetView.findViewById(R.id.rlhomescreen);
                RelativeLayout rllockscreen = bottomSheetView.findViewById(R.id.rllockscreen);
                RelativeLayout rlboth = bottomSheetView.findViewById(R.id.rlboth);
                RelativeLayout rlcrop = bottomSheetView.findViewById(R.id.rlcrop);
                RelativeLayout rlwith = bottomSheetView.findViewById(R.id.rlwith);
                ImageView ivhomescreen = bottomSheetView.findViewById(R.id.ivhomescreen);
                ImageView ivlockscreen = bottomSheetView.findViewById(R.id.ivlockscreen);
                ImageView ivboth = bottomSheetView.findViewById(R.id.ivboth);
                ImageView ivcrop = bottomSheetView.findViewById(R.id.ivcrop);
                ImageView ivwith = bottomSheetView.findViewById(R.id.ivwith);
                ImageView ivhomescreen1 = bottomSheetView.findViewById(R.id.ivhomescreen1);
                ImageView ivlockscreen1 = bottomSheetView.findViewById(R.id.ivlockscreen1);
                ImageView ivboth1 = bottomSheetView.findViewById(R.id.ivboth1);
                ImageView ivcrop1 = bottomSheetView.findViewById(R.id.ivcrop1);
                ImageView ivwith1 = bottomSheetView.findViewById(R.id.ivwith1);
                TextView tvCancel = bottomSheetView.findViewById(R.id.tvCancel);
                TextView tvOk = bottomSheetView.findViewById(R.id.tvOk);
                TextView tvTitle = bottomSheetView.findViewById(R.id.tvTitle);
                TextView tvRecent = bottomSheetView.findViewById(R.id.tvRecent);
                TextView tvFeatured = bottomSheetView.findViewById(R.id.tvFeatured);
                TextView tvPopular = bottomSheetView.findViewById(R.id.tvPopular);
                TextView tvRandom = bottomSheetView.findViewById(R.id.tvRandom);
                TextView tvLiveWallpapers = bottomSheetView.findViewById(R.id.tvLiveWallpapers);

                tvTitle.setText("Sort Wallpapers");
                tvRecent.setText("Recent");
                tvFeatured.setText("Featured");
                tvPopular.setText("Popular");
                tvRandom.setText("Random");
                tvLiveWallpapers.setText("LiveWallpapers");

                ivhomescreen1.setVisibility(View.GONE);
                ivlockscreen1.setVisibility(View.GONE);
                ivboth1.setVisibility(View.GONE);
                ivcrop1.setVisibility(View.GONE);
                ivwith1.setVisibility(View.GONE);

                ivlockscreen.setImageResource(R.drawable.ic_unselect_redio);
                ivboth.setImageResource(R.drawable.ic_unselect_redio);
                ivcrop.setImageResource(R.drawable.ic_unselect_redio);
                ivwith.setImageResource(R.drawable.ic_unselect_redio);
                ivhomescreen.setImageResource(R.drawable.ic_select_redio);
                String[] stringArray = getResources().getStringArray(R.array.dialog_sort_wallpaper);
                SingleChoiceSelected = stringArray[sharedPref.getCurrentSortWallpaper().intValue()];
                rlhomescreen.setOnClickListener(v -> {
                    SingleChoiceSelected = stringArray[0];
                    Log.d("ggg", "" + SingleChoiceSelected);
                    ivlockscreen.setImageResource(R.drawable.ic_unselect_redio);
                    ivboth.setImageResource(R.drawable.ic_unselect_redio);
                    ivcrop.setImageResource(R.drawable.ic_unselect_redio);
                    ivwith.setImageResource(R.drawable.ic_unselect_redio);
                    ivhomescreen.setImageResource(R.drawable.ic_select_redio);
                });
                rllockscreen.setOnClickListener(v -> {
                    SingleChoiceSelected = stringArray[1];
                    Log.d("ggg", "" + SingleChoiceSelected);
                    ivhomescreen.setImageResource(R.drawable.ic_unselect_redio);
                    ivboth.setImageResource(R.drawable.ic_unselect_redio);
                    ivcrop.setImageResource(R.drawable.ic_unselect_redio);
                    ivwith.setImageResource(R.drawable.ic_unselect_redio);
                    ivlockscreen.setImageResource(R.drawable.ic_select_redio);
                });
                rlboth.setOnClickListener(v -> {
                    SingleChoiceSelected = stringArray[2];
                    Log.d("ggg", "" + SingleChoiceSelected);
                    ivhomescreen.setImageResource(R.drawable.ic_unselect_redio);
                    ivlockscreen.setImageResource(R.drawable.ic_unselect_redio);
                    ivcrop.setImageResource(R.drawable.ic_unselect_redio);
                    ivwith.setImageResource(R.drawable.ic_unselect_redio);
                    ivboth.setImageResource(R.drawable.ic_select_redio);
                });
                rlcrop.setOnClickListener(v -> {
                    SingleChoiceSelected = stringArray[3];
                    Log.d("ggg", "" + SingleChoiceSelected);
                    ivhomescreen.setImageResource(R.drawable.ic_unselect_redio);
                    ivlockscreen.setImageResource(R.drawable.ic_unselect_redio);
                    ivboth.setImageResource(R.drawable.ic_unselect_redio);
                    ivwith.setImageResource(R.drawable.ic_unselect_redio);
                    ivcrop.setImageResource(R.drawable.ic_select_redio);
                });
                rlwith.setOnClickListener(v -> {
                    SingleChoiceSelected = stringArray[4];
                    Log.d("ggg", "" + SingleChoiceSelected);
                    ivhomescreen.setImageResource(R.drawable.ic_unselect_redio);
                    ivlockscreen.setImageResource(R.drawable.ic_unselect_redio);
                    ivboth.setImageResource(R.drawable.ic_unselect_redio);
                    ivcrop.setImageResource(R.drawable.ic_unselect_redio);
                    ivwith.setImageResource(R.drawable.ic_select_redio);
                });
                tvOk.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        getInstance(LWT_CategoryDetailsActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                Call<LWT_CallbackWallpaper> call = callbackCall;
                                if (call != null && call.isExecuted()) {
                                    callbackCall.cancel();
                                }
                                adapterWallpaper.resetListData();
                                if (LWT_Tools.isConnect(LWT_CategoryDetailsActivity.this)) {
                                    dbHelper.deleteWallpaperByCategory(LWT_DBHelper.TABLE_CATEGORY_DETAIL, category.category_id);
                                }
                                requestAction(1);
                                if (SingleChoiceSelected.equals(getResources().getString(R.string.lwt_txt_menu_recent))) {
                                    sharedPref.updateSortWallpaper(0);
                                } else if (SingleChoiceSelected.equals(getResources().getString(R.string.lwt_txt_menu_featured))) {
                                    sharedPref.updateSortWallpaper(1);
                                } else if (SingleChoiceSelected.equals(getResources().getString(R.string.lwt_txt_menu_popular))) {
                                    sharedPref.updateSortWallpaper(2);
                                } else if (SingleChoiceSelected.equals(getResources().getString(R.string.lwt_txt_menu_random))) {
                                    sharedPref.updateSortWallpaper(3);
                                } else if (SingleChoiceSelected.equals(getResources().getString(R.string.lwt_txt_menu_live))) {
                                    sharedPref.updateSortWallpaper(4);
                                } else {
                                    sharedPref.updateSortWallpaper(0);
                                }
                                bottomSheetDialog.dismiss();
                            }
                        }, MAIN_CLICK);
                    }
                });

                tvCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        bottomSheetDialog.dismiss();
                    }
                });

                bottomSheetDialog.show();
            }
        });
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        getInstance(this).ShowAd(new HandleClick() {
            @Override
            public void Show(boolean adShow) {
                onBackPressed();
            }
        }, BACK_CLICK);

        return true;
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        swipeProgress(false);
        Call<LWT_CallbackWallpaper> call = this.callbackCall;
        if (call != null && call.isExecuted()) {
            this.callbackCall.cancel();
        }
        this.lytShimmer.stopShimmer();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
