package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_callbacks;

import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models.LWT_Wallpaper;

import java.util.ArrayList;
import java.util.List;

public class LWT_CallbackWallpaper {
    public int count_total = -1;
    public List<LWT_Wallpaper> posts = new ArrayList();
    public String status = "";
}
