package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_activities;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Dialog;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;


import com.iten.tenoku.ad.AdShow;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.livewallpapers.hdwallpapers.transparentwallpapers.Ads_Common.AdsBaseActivity;
import com.livewallpapers.hdwallpapers.transparentwallpapers.R;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_components.LWT_AppBarLayoutBehavior;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_components.LWT_BottomNavigationViewBehavior;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_prefs.LWT_SharedPref;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_fragments.LWT_CategoryFragment;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_fragments.LWT_FavoriteFragment;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_fragments.LWT_TabLayoutFragment;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_Constant;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_Tools;

public class LWT_MainActivity extends AdsBaseActivity {
    private BottomNavigationView bottomNavigationView;
    public CoordinatorLayout coordinatorLayout;
    private MenuItem prevMenuItem;
    private LWT_SharedPref sharedPref;
    private MaterialToolbar toolbar;
    private ViewPager viewPager;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        LWT_Tools.getTheme(this);
        this.sharedPref = new LWT_SharedPref(this);
        setContentView(R.layout.lwt_activity_main);

        getWindow().setStatusBarColor(ContextCompat.getColor(LWT_MainActivity.this, R.color.mainColor));
        getWindow().setNavigationBarColor(ContextCompat.getColor(LWT_MainActivity.this, R.color.mainColor));

        this.coordinatorLayout = (CoordinatorLayout) findViewById(R.id.coordinatorLayout);
        this.bottomNavigationView = (BottomNavigationView) findViewById(R.id.navigation);
        ((CoordinatorLayout.LayoutParams) ((AppBarLayout) findViewById(R.id.appbarLayout)).getLayoutParams()).setBehavior(new LWT_AppBarLayoutBehavior());
        setupToolbar();
        ((CoordinatorLayout.LayoutParams) this.bottomNavigationView.getLayoutParams()).setBehavior(new LWT_BottomNavigationViewBehavior());
        this.bottomNavigationView.setItemIconTintList(null);
        initViewPager();
        this.sharedPref.updateAppOpenToken(1);
        inAppReview();

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                showExitDialog();
            }
        };

        getOnBackPressedDispatcher().addCallback(callback);
    }

    public void setupToolbar() {
        MaterialToolbar materialToolbar = (MaterialToolbar) findViewById(R.id.toolbar);
        this.toolbar = materialToolbar;
        setSupportActionBar(materialToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(getString(R.string.lwt_txt_wallpapers));
        }
        findViewById(R.id.etSearch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (viewPager.getCurrentItem() == 1) {
                    getInstance(LWT_MainActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            Intent intent = new Intent(getApplicationContext(), LWT_SearchActivity.class);
                            intent.putExtra(LWT_Constant.EXTRA_OBJC, "category");
                            startActivity(intent);
                        }
                    }, MAIN_CLICK);
                    return;
                }
                getInstance(LWT_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent2 = new Intent(getApplicationContext(), LWT_SearchActivity.class);
                        intent2.putExtra(LWT_Constant.EXTRA_OBJC, "wallpaper");
                        startActivity(intent2);
                    }
                }, MAIN_CLICK);
            }
        });
    }


    public void initViewPager() {
        ViewPager viewPager2 = (ViewPager) findViewById(R.id.viewPager);
        this.viewPager = viewPager2;
        viewPager2.setAdapter(new MyAdapter(getSupportFragmentManager()));
        this.viewPager.setOffscreenPageLimit(3);
        this.bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.navigation_category:
                        getInstance(LWT_MainActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                viewPager.setCurrentItem(1);
                            }
                        }, MAIN_CLICK);

                        return true;
                    case R.id.navigation_favorite:
                        getInstance(LWT_MainActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                viewPager.setCurrentItem(2);
                            }
                        }, MAIN_CLICK);

                        return true;
                    default:
                        return false;
                    case R.id.navigation_home:
                        getInstance(LWT_MainActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                viewPager.setCurrentItem(0);
                            }
                        }, MAIN_CLICK);
                        return true;
                }
            }
        });
        this.viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrollStateChanged(int i) {
            }

            @Override
            public void onPageScrolled(int i, float f, int i2) {
            }

            @Override
            public void onPageSelected(int i) {
                if (LWT_MainActivity.this.prevMenuItem != null) {
                    LWT_MainActivity.this.prevMenuItem.setChecked(false);
                } else {
                    LWT_MainActivity.this.bottomNavigationView.getMenu().getItem(0).setChecked(false);
                }
                LWT_MainActivity.this.bottomNavigationView.getMenu().getItem(i).setChecked(true);
                LWT_MainActivity mainActivity = LWT_MainActivity.this;
                mainActivity.prevMenuItem = mainActivity.bottomNavigationView.getMenu().getItem(i);
                if (LWT_MainActivity.this.viewPager.getCurrentItem() == 0) {
                    LWT_MainActivity.this.toolbar.setTitle(LWT_MainActivity.this.getResources().getString(R.string.lwt_txt_wallpapers));
                } else if (LWT_MainActivity.this.viewPager.getCurrentItem() == 1) {
                    LWT_MainActivity.this.toolbar.setTitle(LWT_MainActivity.this.getResources().getString(R.string.lwt_txt_title_nav_category));
                } else if (LWT_MainActivity.this.viewPager.getCurrentItem() == 2) {
                    LWT_MainActivity.this.toolbar.setTitle(LWT_MainActivity.this.getResources().getString(R.string.lwt_txt_title_nav_favorite));
                }
            }
        });
    }

    public class MyAdapter extends FragmentPagerAdapter {
        @Override
        public int getCount() {
            return 3;
        }

        MyAdapter(FragmentManager fragmentManager) {
            super(fragmentManager, FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        }

        @Override
        public Fragment getItem(int i) {
            if (i == 0) {
                return new LWT_TabLayoutFragment();
            }
            if (i == 1) {
                return new LWT_CategoryFragment();
            }
            return new LWT_FavoriteFragment();
        }
    }

    public AssetManager getAssets() {
        return getResources().getAssets();
    }


    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        if (this.viewPager.getCurrentItem() == 0) {
            menu.findItem(R.id.menu_sort).setVisible(false);
        } else {
            menu.findItem(R.id.menu_sort).setVisible(false);
        }
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.menu_notification) {
            getInstance(LWT_MainActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    startActivity(new Intent(getApplicationContext(), LWT_SettingsActivity.class));
                }
            }, MAIN_CLICK);
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void onRestart() {
        super.onRestart();
        LWT_SharedPref sharedPref2 = this.sharedPref;
        sharedPref2.updateAppOpenToken(sharedPref2.getAppOpenToken().intValue() + 1);
    }

    private void inAppReview() {
        if (this.sharedPref.getInAppReviewToken().intValue() < 1) {
            LWT_SharedPref sharedPref2 = this.sharedPref;
            sharedPref2.updateInAppReviewToken(sharedPref2.getInAppReviewToken().intValue() + 1);
        }
    }

    private final void showExitDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.exit_dailog_layout);
        Window window = dialog.getWindow();

        window.setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        ((TextView) dialog.findViewById(R.id.tvYes)).setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                dialog.dismiss();
                finishAffinity();
                System.exit(0);
            }
        });
        ((TextView) dialog.findViewById(R.id.tvNo)).setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        AdShow.getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }

}
