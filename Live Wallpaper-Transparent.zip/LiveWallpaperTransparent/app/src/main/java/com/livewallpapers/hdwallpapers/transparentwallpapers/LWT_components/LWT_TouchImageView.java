package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_components;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import androidx.appcompat.widget.AppCompatImageView;

public class LWT_TouchImageView extends AppCompatImageView {
    Context context;
    PointF last = new PointF();
    float[] m;
    ScaleGestureDetector mScaleDetector;
    Matrix matrix;
    float maxScale = 3.0f;
    float minScale = 1.0f;
    int mode = 0;
    int oldMeasuredHeight;
    int oldMeasuredWidth;
    protected float origHeight;
    protected float origWidth;
    float saveScale = 1.0f;
    PointF start = new PointF();
    int viewHeight;
    int viewWidth;

    public float getFixDragTrans(float f, float f2, float f3) {
        if (f3 <= f2) {
            return 0.0f;
        }
        return f;
    }

    public float getFixTrans(float f, float f2, float f3) {
        float f4;
        float f5;
        if (f3 <= f2) {
            f4 = f2 - f3;
            f5 = 0.0f;
        } else {
            f5 = f2 - f3;
            f4 = 0.0f;
        }
        if (f < f5) {
            return (-f) + f5;
        }
        if (f > f4) {
            return (-f) + f4;
        }
        return 0.0f;
    }

    public LWT_TouchImageView(Context context2) {
        super(context2);
        sharedConstructing(context2);
    }

    public LWT_TouchImageView(Context context2, AttributeSet attributeSet) {
        super(context2, attributeSet);
        sharedConstructing(context2);
    }

    private void sharedConstructing(Context context2) {
        super.setClickable(true);
        this.context = context2;
        this.mScaleDetector = new ScaleGestureDetector(context2, new ScaleListener());
        Matrix matrix2 = new Matrix();
        this.matrix = matrix2;
        this.m = new float[9];
        setImageMatrix(matrix2);
        setScaleType(ScaleType.MATRIX);
        setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                mScaleDetector.onTouchEvent(motionEvent);
                PointF pointF = new PointF(motionEvent.getX(), motionEvent.getY());
                int action = motionEvent.getAction();
                if (action == 0) {
                    last.set(pointF);
                    start.set(last);
                    mode = 1;
                } else if (action == 1) {
                    mode = 0;
                    int abs = (int) Math.abs(pointF.x - start.x);
                    int abs2 = (int) Math.abs(pointF.y - start.y);
                    if (abs < 3 && abs2 < 3) {
                        performClick();
                    }
                } else if (action != 2) {
                    if (action == 6) {
                        mode = 0;
                    }
                } else if (mode == 1) {
                    float f = pointF.x - last.x;
                    float f2 = pointF.y - last.y;
                    matrix.postTranslate(getFixDragTrans(f, (float) viewWidth, origWidth * saveScale), getFixDragTrans(f2, (float) viewHeight, origHeight * saveScale));
                    fixTrans();
                    last.set(pointF.x, pointF.y);
                }
                setImageMatrix(matrix);
                invalidate();
                return true;
            }
        });
    }



    
    public class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        private ScaleListener() {
        }

        public boolean onScaleBegin(ScaleGestureDetector scaleGestureDetector) {
            LWT_TouchImageView.this.mode = 2;
            return true;
        }

        public boolean onScale(ScaleGestureDetector scaleGestureDetector) {
            float f;
            float scaleFactor = scaleGestureDetector.getScaleFactor();
            float f2 = LWT_TouchImageView.this.saveScale;
            LWT_TouchImageView.this.saveScale *= scaleFactor;
            if (LWT_TouchImageView.this.saveScale > LWT_TouchImageView.this.maxScale) {
                LWT_TouchImageView touchImageView = LWT_TouchImageView.this;
                touchImageView.saveScale = touchImageView.maxScale;
                f = LWT_TouchImageView.this.maxScale;
            } else {
                if (LWT_TouchImageView.this.saveScale < LWT_TouchImageView.this.minScale) {
                    LWT_TouchImageView touchImageView2 = LWT_TouchImageView.this;
                    touchImageView2.saveScale = touchImageView2.minScale;
                    f = LWT_TouchImageView.this.minScale;
                }
                if (LWT_TouchImageView.this.origWidth * LWT_TouchImageView.this.saveScale > ((float) LWT_TouchImageView.this.viewWidth) || LWT_TouchImageView.this.origHeight * LWT_TouchImageView.this.saveScale <= ((float) LWT_TouchImageView.this.viewHeight)) {
                    LWT_TouchImageView.this.matrix.postScale(scaleFactor, scaleFactor, (float) (LWT_TouchImageView.this.viewWidth / 2), (float) (LWT_TouchImageView.this.viewHeight / 2));
                } else {
                    LWT_TouchImageView.this.matrix.postScale(scaleFactor, scaleFactor, scaleGestureDetector.getFocusX(), scaleGestureDetector.getFocusY());
                }
                LWT_TouchImageView.this.fixTrans();
                return true;
            }
            scaleFactor = f / f2;
            if (LWT_TouchImageView.this.origWidth * LWT_TouchImageView.this.saveScale > ((float) LWT_TouchImageView.this.viewWidth)) {
            }
            LWT_TouchImageView.this.matrix.postScale(scaleFactor, scaleFactor, (float) (LWT_TouchImageView.this.viewWidth / 2), (float) (LWT_TouchImageView.this.viewHeight / 2));
            LWT_TouchImageView.this.fixTrans();
            return true;
        }
    }


    public void fixTrans() {
        this.matrix.getValues(this.m);
        float[] fArr = this.m;
        float f = fArr[2];
        float f2 = fArr[5];
        float fixTrans = getFixTrans(f, (float) this.viewWidth, this.origWidth * this.saveScale);
        float fixTrans2 = getFixTrans(f2, (float) this.viewHeight, this.origHeight * this.saveScale);
        if (fixTrans != 0.0f || fixTrans2 != 0.0f) {
            this.matrix.postTranslate(fixTrans, fixTrans2);
        }
    }

    
    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        this.viewWidth = MeasureSpec.getSize(i);
        int size = MeasureSpec.getSize(i2);
        this.viewHeight = size;
        int i3 = this.oldMeasuredHeight;
        int i4 = this.viewWidth;
        if ((i3 != i4 || i3 != size) && i4 != 0 && size != 0) {
            this.oldMeasuredHeight = size;
            this.oldMeasuredWidth = i4;
            if (this.saveScale == 1.0f) {
                Drawable drawable = getDrawable();
                if (drawable != null && drawable.getIntrinsicWidth() != 0 && drawable.getIntrinsicHeight() != 0) {
                    int intrinsicWidth = drawable.getIntrinsicWidth();
                    int intrinsicHeight = drawable.getIntrinsicHeight();
                    Log.d("bmSize", "bmWidth: " + intrinsicWidth + " bmHeight : " + intrinsicHeight);
                    float f = (float) intrinsicWidth;
                    float f2 = (float) intrinsicHeight;
                    float min = Math.min(((float) this.viewWidth) / f, ((float) this.viewHeight) / f2);
                    this.matrix.setScale(min, min);
                    float f3 = (((float) this.viewHeight) - (f2 * min)) / 2.0f;
                    float f4 = (((float) this.viewWidth) - (min * f)) / 2.0f;
                    this.matrix.postTranslate(f4, f3);
                    this.origWidth = ((float) this.viewWidth) - (f4 * 2.0f);
                    this.origHeight = ((float) this.viewHeight) - (f3 * 2.0f);
                    setImageMatrix(this.matrix);
                } else {
                    return;
                }
            }
            fixTrans();
        }
    }
}
