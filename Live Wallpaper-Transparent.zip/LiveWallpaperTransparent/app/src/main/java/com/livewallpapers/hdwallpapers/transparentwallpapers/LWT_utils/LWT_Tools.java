package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StrictMode;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;

import com.livewallpapers.hdwallpapers.transparentwallpapers.R;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_prefs.LWT_SharedPref;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_services.LWT_SetGIFAsWallpaperService;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class LWT_Tools {
    public Context context;

    public LWT_Tools(Context context2) {
        this.context = context2;
    }

    public static void getTheme(Context context2) {
    }

    public static void darkNavigationStatusBar(Activity activity) {
        if (Build.VERSION.SDK_INT >= 23) {
            activity.getWindow().setNavigationBarColor(activity.getResources().getColor(R.color.mainColor));
            activity.getWindow().getDecorView().setSystemUiVisibility(8192);
        }
    }

    public static void darkNavigation(Activity activity) {
        activity.getWindow().setNavigationBarColor(activity.getResources().getColor(R.color.mainColor));
    }

    public static void lightNavigation(Activity activity) {
        if (Build.VERSION.SDK_INT >= 26) {
            activity.getWindow().setNavigationBarColor(activity.getResources().getColor(R.color.white));
        }
    }


    public static void transparentStatusBarNavigation(Activity activity) {
        activity.getWindow().getDecorView().setSystemUiVisibility(1792);
        setWindowFlag(activity, 201326592, false);
        activity.getWindow().setStatusBarColor(0);
        activity.getWindow().setNavigationBarColor(0);
    }

    public static void setWindowFlag(Activity activity, int i, boolean z) {
        Window window = activity.getWindow();
        WindowManager.LayoutParams attributes = window.getAttributes();
        if (z) {
            attributes.flags = i | attributes.flags;
        } else {
            attributes.flags = (~i) & attributes.flags;
        }
        window.setAttributes(attributes);
    }

    public static String withSuffix(long j) {
        if (j < 1000) {
            return "" + j;
        }
        double d = (double) j;
        int log = (int) (Math.log(d) / Math.log(1000.0d));
        return String.format("%.1f%c", Double.valueOf(d / Math.pow(1000.0d, (double) log)), Character.valueOf("KMGTPE".charAt(log - 1)));
    }

    public static void setAction(Context context2, byte[] bArr, String str, String str2) {
        File file;
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/" + context2.getString(R.string.app_name));
            } else {
                file = new File(Environment.getExternalStorageDirectory() + "/" + context2.getString(R.string.app_name));
            }
            if (!file.exists() ? file.mkdirs() : true) {
                File file2 = new File(file, str);
                FileOutputStream fileOutputStream = new FileOutputStream(file2);
                fileOutputStream.write(bArr);
                fileOutputStream.flush();
                fileOutputStream.close();
                Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                File file3 = new File(file2.getAbsolutePath());
                intent.setData(Uri.fromFile(file3));
                context2.sendBroadcast(intent);
                StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
                char c = 65535;
                switch (str2.hashCode()) {
                    case -905811966:
                        if (str2.equals(LWT_Constant.SET_GIF)) {
                            c = 3;
                            break;
                        }
                        break;
                    case 109400031:
                        if (str2.equals(LWT_Constant.SHARE)) {
                            c = 1;
                            break;
                        }
                        break;
                    case 1427818632:
                        if (str2.equals(LWT_Constant.DOWNLOAD)) {
                            c = 0;
                            break;
                        }
                        break;
                    case 1985077320:
                        if (str2.equals(LWT_Constant.SET_WITH)) {
                            c = 2;
                            break;
                        }
                        break;
                }
                if (c == 1) {
                    Intent intent2 = new Intent("android.intent.action.SEND");
                    intent2.setType("image/*");
                    intent2.putExtra("android.intent.extra.TEXT", context2.getResources().getString(R.string.lwt_txt_share_app) + context2.getResources().getString(R.string.lwt_txt_share_text) + "\nhttps://play.google.com/store/apps/details?id=" + "com.livewallpapers.hdwallpapers.transparentwallpapers");
                    StringBuilder sb = new StringBuilder();
                    sb.append("file://");
                    sb.append(file2.getAbsolutePath());
                    intent2.putExtra("android.intent.extra.STREAM", Uri.parse(sb.toString()));
                    context2.startActivity(Intent.createChooser(intent2, "Share Image"));
                } else if (c == 2) {
                    Intent intent3 = new Intent("android.intent.action.ATTACH_DATA");
                    intent3.addCategory("android.intent.category.DEFAULT");
                    intent3.setDataAndType(Uri.parse("file://" + file3.getAbsolutePath()), "image/*");
                    intent3.putExtra("mimeType", "image/*");
                    context2.startActivity(Intent.createChooser(intent3, "Set as:"));
                } else if (c == 3) {
                    if (Build.VERSION.SDK_INT >= 30) {
                        LWT_Constant.gifPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/" + context2.getString(R.string.app_name);
                    } else {
                        LWT_Constant.gifPath = Environment.getExternalStorageDirectory() + "/" + context2.getString(R.string.app_name);
                    }
                    LWT_Constant.gifName = file3.getName();
                    new LWT_SharedPref(context2).saveGif(LWT_Constant.gifPath, LWT_Constant.gifName);
                    try {
                        WallpaperManager.getInstance(context2).clear();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Intent intent4 = new Intent("android.service.wallpaper.CHANGE_LIVE_WALLPAPER");
                    intent4.putExtra("android.service.wallpaper.extra.LIVE_WALLPAPER_COMPONENT", new ComponentName(context2, LWT_SetGIFAsWallpaperService.class));
                    context2.startActivity(intent4);
                    Log.d("GIF_PATH", LWT_Constant.gifPath);
                    Log.d("GIF_NAME", LWT_Constant.gifName);
                }
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    public static String createName(String str) {
        return str.substring(str.lastIndexOf(47) + 1);
    }

    public static byte[] getBytesFromFile(File file) throws IOException {
        long length = file.length();
        if (length <= 2147483647L) {
            int i = (int) length;
            byte[] bArr = new byte[i];
            int i2 = 0;
            FileInputStream fileInputStream = new FileInputStream(file);
            while (i2 < i) {
                try {
                    int read = fileInputStream.read(bArr, i2, i - i2);
                    if (read < 0) {
                        break;
                    }
                    i2 += read;
                } catch (Throwable th) {
                    th.addSuppressed(th);
                }
            }
            fileInputStream.close();
            if (i2 >= i) {
                return bArr;
            }
            throw new IOException("Could not completely read file " + file.getName());
        }
        throw new IOException("File is too large!");
    }

    public static boolean isConnect(Context context2) {
        try {
            NetworkInfo activeNetworkInfo = ((ConnectivityManager) context2.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
            if (activeNetworkInfo == null) {
                return false;
            }
            if (activeNetworkInfo.isConnected() || activeNetworkInfo.isConnectedOrConnecting()) {
                return true;
            }
            return false;
        } catch (Exception unused) {
            return false;
        }
    }
}
