package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models;

import java.io.Serializable;

public class LWT_Wallpaper implements Serializable {
    public String category_id;
    public String tvCategoryName;
    public int downloads;
    public String featured;
    public String image_id;
    public String image_name;
    public String image_upload;
    public String image_url;
    public String last_update;
    public String mime;
    public String resolution;
    public String size;
    public String tags;

    public String type;
    public int views;
}
