package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_services;

import android.graphics.Canvas;
import android.graphics.Movie;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_prefs.LWT_SharedPref;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_Constant;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class LWT_SetGIFAsWallpaperService extends WallpaperService {
    public class GIFWallpaperEngine extends Engine {
        private final Runnable drawGIF = new Runnable() {
            @Override
            public void run() {
                if (visible) {
                    Canvas lockCanvas = holder.lockCanvas();
                    lockCanvas.save();
                    float f = scaleRatio;
                    lockCanvas.scale(f, f);
                    movie.draw(lockCanvas, x, y);
                    lockCanvas.restore();
                    holder.unlockCanvasAndPost(lockCanvas);
                    movie.setTime((int) (System.currentTimeMillis() % ((long) movie.duration())));
                    handler.removeCallbacks(drawGIF);
                    handler.postDelayed(drawGIF, 0);
                }
            }
        };
        private final Handler handler = new Handler(Looper.getMainLooper());
        private SurfaceHolder holder;
        private Movie movie;
        private float scaleRatio;
        private boolean visible;
        private float x;
        private float y;

        public GIFWallpaperEngine() {
            super();
        }

        public void onCreate(SurfaceHolder surfaceHolder) {
            super.onCreate(surfaceHolder);
            this.holder = surfaceHolder;
        }

        public void onDestroy() {
            super.onDestroy();
            this.handler.removeCallbacks(this.drawGIF);
        }

        public void onSurfaceCreated(SurfaceHolder surfaceHolder) {
            super.onSurfaceCreated(surfaceHolder);
            try {
                BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(new File(LWT_Constant.gifPath, LWT_Constant.gifName)), 16384);
                bufferedInputStream.mark(16384);
                this.movie = Movie.decodeStream(bufferedInputStream);
            } catch (FileNotFoundException e) {
                try {
                    LWT_SharedPref sharedPref = new LWT_SharedPref(LWT_SetGIFAsWallpaperService.this.getApplicationContext());
                    BufferedInputStream bufferedInputStream2 = new BufferedInputStream(new FileInputStream(new File(sharedPref.getPath() + "/" + sharedPref.getGifName())), 16384);
                    bufferedInputStream2.mark(16384);
                    this.movie = Movie.decodeStream(bufferedInputStream2);
                } catch (FileNotFoundException e2) {
                    e2.printStackTrace();
                    try {
                        this.movie = Movie.decodeStream(LWT_SetGIFAsWallpaperService.this.getResources().getAssets().open("default_image.gif"));
                    } catch (IOException e3) {
                        e3.printStackTrace();
                    }
                }
                e.printStackTrace();
            }
        }

        public void onSurfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
            super.onSurfaceChanged(surfaceHolder, i, i2, i3);
            super.onSurfaceChanged(surfaceHolder, i, i2, i3);
            float f = (float) i2;
            float width = (float) this.movie.width();
            float f2 = (float) i3;
            float height = (float) this.movie.height();
            float max = Math.max(f / width, f2 / height);
            this.scaleRatio = max;
            this.x = ((f - (width * max)) / 2.0f) / max;
            this.y = ((f2 - (height * max)) / 2.0f) / max;
        }

        public void onSurfaceDestroyed(SurfaceHolder surfaceHolder) {
            super.onSurfaceDestroyed(surfaceHolder);
        }


        public void onVisibilityChanged(boolean z) {
            this.visible = z;
            if (z) {
                this.handler.post(this.drawGIF);
            } else {
                this.handler.removeCallbacks(this.drawGIF);
            }
        }
    }

    public Engine onCreateEngine() {
        return new GIFWallpaperEngine();
    }

    public void onDestroy() {
        super.onDestroy();
    }
}
