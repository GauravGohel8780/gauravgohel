package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_activities;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.github.chrisbanes.photoview.PhotoView;
import com.google.android.flexbox.AlignItems;
import com.google.android.flexbox.FlexDirection;
import com.google.android.flexbox.FlexboxLayoutManager;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.snackbar.Snackbar;


import com.iten.tenoku.ad.AdShow;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.livewallpapers.hdwallpapers.transparentwallpapers.Ads_Common.AdsBaseActivity;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_callbacks.LWT_CallbackWallpaper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.R;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_adapters.LWT_TagsAdapter;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_components.LWT_HackyViewPager;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_prefs.LWT_SharedPref;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_sqlite.LWT_DBHelper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models.LWT_Wallpaper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_Constant;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_Tools;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_WallpaperHelper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;

public class LWT_WallpaperDetailActivity extends AdsBaseActivity {
    private RelativeLayout rlBgShadowBottom;
    private RelativeLayout rlBgShadowTop;
    private LWT_DBHelper dbHelper;
    private boolean flag = true;
    private List<LWT_Wallpaper> items = new ArrayList();
    private LinearLayoutCompat lytBottom;
    private BottomSheetDialog mBottomSheetDialog;
    private CoordinatorLayout parentView;
    private int position;
    private ProgressDialog progressDialog;
    private LWT_SharedPref sharedPref;
    private String SingleChoiceSelected;
    private MaterialToolbar toolbar;
    private LWT_WallpaperHelper wallpaperHelper;
    private static final int REQUEST_CODE_RUNNER = 123;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.sharedPref = new LWT_SharedPref(this);
        setContentView(R.layout.lwt_activity_wallpaper_detail);

        this.progressDialog = new ProgressDialog(this);
        this.wallpaperHelper = new LWT_WallpaperHelper(this);
        this.parentView = (CoordinatorLayout) findViewById(R.id.coordinatorLayout);
        this.lytBottom = (LinearLayoutCompat) findViewById(R.id.lytBottom);
        this.rlBgShadowTop = (RelativeLayout) findViewById(R.id.rlBgShadowTop);
        this.rlBgShadowBottom = (RelativeLayout) findViewById(R.id.rlBgShadowBottom);
        this.dbHelper = new LWT_DBHelper(this);
        this.position = getIntent().getIntExtra(LWT_Constant.POSITION, 0);
        this.items = (List) getIntent().getBundleExtra(LWT_Constant.BUNDLE).getSerializable(LWT_Constant.ARRAY_LIST);
        setupToolbar();
        loadView(this.position);
        setupViewPager();
    }

    public void setupViewPager() {
        ImagePagerAdapter imagePagerAdapter = new ImagePagerAdapter();
        LWT_HackyViewPager hvPager = (LWT_HackyViewPager) findViewById(R.id.hvPager);
        hvPager.setAdapter(imagePagerAdapter);
        hvPager.setCurrentItem(this.position);
        hvPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrollStateChanged(int i) {
            }

            @Override
            public void onPageScrolled(int i, float f, int i2) {
            }

            @Override
            public void onPageSelected(int i) {
                LWT_WallpaperDetailActivity.this.loadView(i);
            }
        });
    }

    public void loadView(int i) {
        LWT_Wallpaper wallpaper = this.items.get(i);
        String str = LWT_Constant.BASE_IMAGE_URL + wallpaper.image_upload;
        String str2 = wallpaper.image_url;
        if (wallpaper.image_name != null) {
            TextView textView = (TextView) findViewById(R.id.tvTitleToolbar);
            if (wallpaper.image_name.equals("")) {
                textView.setText(wallpaper.tvCategoryName);
            } else {
                textView.setText(wallpaper.image_name);
            }
            findViewById(R.id.llcInfo).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    getInstance(LWT_WallpaperDetailActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            showBottomSheetDialog(wallpaper);
                        }
                    }, MAIN_CLICK);
                }
            });
            findViewById(R.id.llcSave).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (checkWriteExternalPermission()) {
                        getInstance(LWT_WallpaperDetailActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                if (wallpaper.type.equals("upload")) {
                                    LWT_WallpaperDetailActivity.this.wallpaperHelper.downloadWallpaper(wallpaper, LWT_WallpaperDetailActivity.this.parentView, LWT_WallpaperDetailActivity.this.progressDialog, str);


                                } else if (wallpaper.type.equals("url")) {
                                    LWT_WallpaperDetailActivity.this.wallpaperHelper.downloadWallpaper(wallpaper, LWT_WallpaperDetailActivity.this.parentView, LWT_WallpaperDetailActivity.this.progressDialog, str2);

                                }
                            }
                        }, MAIN_CLICK);
                    } else {
                        if (Build.VERSION.SDK_INT >= 33) {
                            if (!(ActivityCompat.checkSelfPermission(LWT_WallpaperDetailActivity.this, "android.permission.READ_MEDIA_VIDEO") == 0 && ActivityCompat.checkSelfPermission(LWT_WallpaperDetailActivity.this, "android.permission.READ_MEDIA_IMAGES") == 0 || ActivityCompat.checkSelfPermission(LWT_WallpaperDetailActivity.this, "android.permission.READ_MEDIA_AUDIO") == 0) && !(ActivityCompat.checkSelfPermission(LWT_WallpaperDetailActivity.this, "android.permission.READ_EXTERNAL_STORAGE") == 0)) {
                                ActivityCompat.requestPermissions(LWT_WallpaperDetailActivity.this, new String[]{"android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_AUDIO"}, REQUEST_CODE_RUNNER);
                            }
                        } else {
                            if (ContextCompat.checkSelfPermission(LWT_WallpaperDetailActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                                ActivityCompat.requestPermissions(LWT_WallpaperDetailActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CODE_RUNNER);
                            }
                        }
                    }
                }
            });
            findViewById(R.id.btnShare).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    getInstance(LWT_WallpaperDetailActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            if (wallpaper.type.equals("upload")) {
                                wallpaperHelper.shareWallpaper(progressDialog, str);
                            } else if (wallpaper.type.equals("url")) {
                                wallpaperHelper.shareWallpaper(progressDialog, str2);
                            }
                        }
                    }, MAIN_CLICK);
                }
            });
            findViewById(R.id.llcApplyWallpaper).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (checkWriteExternalPermission()) {
                        getInstance(LWT_WallpaperDetailActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                if (wallpaper.image_upload.endsWith(".gif") || wallpaper.image_url.endsWith(".gif")) {
                                    if (wallpaper.type.equals("upload")) {
                                        LWT_WallpaperDetailActivity.this.wallpaperHelper.setGif(LWT_WallpaperDetailActivity.this.parentView, LWT_WallpaperDetailActivity.this.progressDialog, str);
                                    } else if (wallpaper.type.equals("url")) {
                                        LWT_WallpaperDetailActivity.this.wallpaperHelper.setGif(LWT_WallpaperDetailActivity.this.parentView, LWT_WallpaperDetailActivity.this.progressDialog, str2);
                                    }
                                } else if (Build.VERSION.SDK_INT >= 24) {
                                    if (wallpaper.type.equals("upload")) {
                                        LWT_WallpaperDetailActivity.this.dialogOptionSetWallpaper(str, wallpaper);
                                    } else if (wallpaper.type.equals("url")) {
                                        LWT_WallpaperDetailActivity.this.dialogOptionSetWallpaper(str2, wallpaper);
                                    }
                                } else if (wallpaper.type.equals("upload")) {
                                    LWT_WallpaperDetailActivity.this.wallpaperHelper.setWallpaper(LWT_WallpaperDetailActivity.this.parentView, LWT_WallpaperDetailActivity.this.progressDialog, str);
                                } else if (wallpaper.type.equals("url")) {
                                    LWT_WallpaperDetailActivity.this.wallpaperHelper.setWallpaper(LWT_WallpaperDetailActivity.this.parentView, LWT_WallpaperDetailActivity.this.progressDialog, str2);
                                }
                            }
                        }, MAIN_CLICK);
                    } else {
                        if (Build.VERSION.SDK_INT >= 33) {
                            if (!(ActivityCompat.checkSelfPermission(LWT_WallpaperDetailActivity.this, "android.permission.READ_MEDIA_VIDEO") == 0 && ActivityCompat.checkSelfPermission(LWT_WallpaperDetailActivity.this, "android.permission.READ_MEDIA_IMAGES") == 0 || ActivityCompat.checkSelfPermission(LWT_WallpaperDetailActivity.this, "android.permission.READ_MEDIA_AUDIO") == 0) && !(ActivityCompat.checkSelfPermission(LWT_WallpaperDetailActivity.this, "android.permission.READ_EXTERNAL_STORAGE") == 0)) {
                                ActivityCompat.requestPermissions(LWT_WallpaperDetailActivity.this, new String[]{"android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_AUDIO"}, REQUEST_CODE_RUNNER);
                            }
                        } else {
                            if (ContextCompat.checkSelfPermission(LWT_WallpaperDetailActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                                ActivityCompat.requestPermissions(LWT_WallpaperDetailActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CODE_RUNNER);
                            }
                        }
                    }
                }
            });
            favToggle(wallpaper);
            findViewById(R.id.llcFavorite).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    getInstance(LWT_WallpaperDetailActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            if (dbHelper.isFavoritesExist(wallpaper.image_id)) {
                                dbHelper.deleteFavorites(wallpaper);
                                Snackbar.make(parentView, "Wallpaper removed from favorite", -1).show();
                            } else {
                                dbHelper.addOneFavorite(wallpaper);
                                Snackbar.make(parentView, "Wallpaper added to favorite", -1).show();
                            }
                            favToggle(wallpaper);
                        }
                    }, MAIN_CLICK);
                }
            });
            this.wallpaperHelper.updateView(wallpaper.image_id);
            this.lytBottom.setVisibility(View.VISIBLE);
            this.toolbar.setVisibility(View.VISIBLE);
            fullScreenMode(false);
            showShadow(true);
            return;
        }
        fullScreenMode(false);
        this.lytBottom.setVisibility(View.GONE);
        this.toolbar.setVisibility(View.GONE);
        if (!this.sharedPref.getIsDarkTheme().booleanValue()) {
            LWT_Tools.darkNavigationStatusBar(this);
        }
        showShadow(false);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_RUNNER) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
            }
        }
    }

    private boolean checkWriteExternalPermission() {
        int res;
        if (Build.VERSION.SDK_INT >= 33) {
            String permission = Manifest.permission.READ_MEDIA_IMAGES;
            res = checkCallingOrSelfPermission(permission);
        } else {
            String permission = Manifest.permission.WRITE_EXTERNAL_STORAGE;
            res = checkCallingOrSelfPermission(permission);
        }
        return (res == PackageManager.PERMISSION_GRANTED);
    }

    private void showShadow(boolean z) {
        if (z) {
            this.rlBgShadowTop.setVisibility(View.VISIBLE);
            this.rlBgShadowBottom.setVisibility(View.VISIBLE);
            return;
        }
        this.rlBgShadowTop.setVisibility(View.GONE);
        this.rlBgShadowBottom.setVisibility(View.GONE);
    }

    private void favToggle(LWT_Wallpaper wallpaper) {
        ImageView imageView = (ImageView) findViewById(R.id.ivFavorite);
        if (this.dbHelper.isFavoritesExist(wallpaper.image_id)) {
            imageView.setImageResource(R.drawable.ic_action_fav);
        } else {
            imageView.setImageResource(R.drawable.ic_action_fav_outline);
        }
    }

    public void setupToolbar() {
        MaterialToolbar materialToolbar = (MaterialToolbar) findViewById(R.id.toolbar);
        this.toolbar = materialToolbar;
        setSupportActionBar(materialToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
        }
    }

    private void showBottomSheetDialog(LWT_Wallpaper wallpaper) {
        View inflate = getLayoutInflater().inflate(R.layout.lwt_include_info, (ViewGroup) null);
        FrameLayout frameLayout = (FrameLayout) inflate.findViewById(R.id.bottom_sheet);
        frameLayout.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_rounded_dark));
        if (wallpaper.image_name.equals("")) {
            ((TextView) inflate.findViewById(R.id.tvWallpaperName)).setText("-");
        } else {
            ((TextView) inflate.findViewById(R.id.tvWallpaperName)).setText(wallpaper.image_name);
        }
        ((TextView) inflate.findViewById(R.id.tvCategoryName)).setText(wallpaper.tvCategoryName);
        if (wallpaper.resolution.equals("0")) {
            ((TextView) inflate.findViewById(R.id.tvResolution)).setText("-");
        } else {
            ((TextView) inflate.findViewById(R.id.tvResolution)).setText(wallpaper.resolution);
        }
        if (wallpaper.size.equals("0")) {
            ((TextView) inflate.findViewById(R.id.tvSize)).setText("-");
        } else {
            ((TextView) inflate.findViewById(R.id.tvSize)).setText(wallpaper.size);
        }
        if (wallpaper.mime.equals("")) {
            ((TextView) inflate.findViewById(R.id.tvMimeType)).setText("image/jpeg");
        } else {
            ((TextView) inflate.findViewById(R.id.tvMimeType)).setText(wallpaper.mime);
        }
        ((TextView) inflate.findViewById(R.id.tvViewCount)).setText(LWT_Tools.withSuffix((long) wallpaper.views) + "");
        ((TextView) inflate.findViewById(R.id.tvDownloadCount)).setText(LWT_Tools.withSuffix((long) wallpaper.downloads) + "");

        LinearLayoutCompat linearLayoutCompat = (LinearLayoutCompat) inflate.findViewById(R.id.lytTags);
        if (wallpaper.tags.equals("")) {
            linearLayoutCompat.setVisibility(View.GONE);
        } else {
            linearLayoutCompat.setVisibility(View.VISIBLE);
        }
        LWT_TagsAdapter adapterTags = new LWT_TagsAdapter(this, new ArrayList(Arrays.asList(wallpaper.tags.split(","))));
        RecyclerView recyclerView = (RecyclerView) inflate.findViewById(R.id.rvTags);
        FlexboxLayoutManager flexboxLayoutManager = new FlexboxLayoutManager(this);
        flexboxLayoutManager.setFlexDirection(FlexDirection.ROW);
        flexboxLayoutManager.setAlignItems(AlignItems.FLEX_START);
        recyclerView.setLayoutManager(flexboxLayoutManager);
        recyclerView.setAdapter(adapterTags);
        adapterTags.setOnItemClickListener(new LWT_TagsAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, String str, int i) {
                Intent intent = new Intent(getApplicationContext(), LWT_SearchActivity.class);
                intent.putExtra(LWT_DBHelper.TAGS, str);
                intent.putExtra(LWT_Constant.EXTRA_OBJC, "wallpaper");
                startActivity(intent);
                mBottomSheetDialog.dismiss();
            }
        });
        if (this.sharedPref.getIsDarkTheme().booleanValue()) {
            this.mBottomSheetDialog = new BottomSheetDialog(this, R.style.SheetDialogDark);
        } else {
            this.mBottomSheetDialog = new BottomSheetDialog(this, R.style.SheetDialogLight);
        }
        this.mBottomSheetDialog.setContentView(inflate);
        this.mBottomSheetDialog.getWindow().addFlags(67108864);
        this.mBottomSheetDialog.getBehavior().setState(BottomSheetBehavior.STATE_EXPANDED);
        this.mBottomSheetDialog.show();
        this.mBottomSheetDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                mBottomSheetDialog = null;
            }
        });
    }

    public class ImagePagerAdapter extends PagerAdapter {
        static final boolean $assertionsDisabled = false;
        private final LayoutInflater inflater;

        ImagePagerAdapter() {
            this.inflater = LWT_WallpaperDetailActivity.this.getLayoutInflater();
        }

        @Override
        public int getCount() {
            return LWT_WallpaperDetailActivity.this.items.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object obj) {
            return view.equals(obj);
        }

        @Override
        public Object instantiateItem(ViewGroup viewGroup, int i) {
            View inflate = this.inflater.inflate(R.layout.lwt_item_slider_wallpaper, viewGroup, false);
            LWT_Wallpaper wallpaper = (LWT_Wallpaper) LWT_WallpaperDetailActivity.this.items.get(i);
            RelativeLayout relativeLayout = (RelativeLayout) inflate.findViewById(R.id.lyt_view);
            PhotoView photoView = (PhotoView) inflate.findViewById(R.id.pvImage);
            final ProgressBar progressBar = (ProgressBar) inflate.findViewById(R.id.progressBar);
            if (wallpaper != null) {
                if (wallpaper.image_name != null) {
                    photoView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    if (wallpaper.image_url.endsWith(".png") || wallpaper.image_upload.endsWith(".png")) {

                        relativeLayout.setBackgroundColor(ContextCompat.getColor(LWT_WallpaperDetailActivity.this.getApplicationContext(), R.color.black));

                    }
                    photoView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (LWT_WallpaperDetailActivity.this.flag) {
                                LWT_WallpaperDetailActivity.this.fullScreenMode(true);
                                LWT_WallpaperDetailActivity.this.flag = false;
                                return;
                            }
                            LWT_WallpaperDetailActivity.this.fullScreenMode(false);
                            LWT_WallpaperDetailActivity.this.flag = true;
                        }
                    });
                    if (wallpaper.type.equals("url")) {
                        RequestManager with = Glide.with((FragmentActivity) LWT_WallpaperDetailActivity.this);
                        ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) Glide.with((FragmentActivity) LWT_WallpaperDetailActivity.this).load(wallpaper.image_url.replace(" ", "%20")).placeholder((int) R.drawable.bg_transparent)).thumbnail(with.load("https://sarkaribhaiya.com/apps/wallpaper/upload/thumbs/" + ((LWT_Wallpaper) LWT_WallpaperDetailActivity.this.items.get(i)).image_upload.replace(" ", "%20"))).centerCrop()).addListener(new RequestListener<Drawable>() {
                            @Override
                            public boolean onLoadFailed(GlideException glideException, Object obj, Target<Drawable> target, boolean z) {
                                progressBar.setVisibility(View.GONE);
                                return false;
                            }

                            public boolean onResourceReady(Drawable drawable, Object obj, Target<Drawable> target, DataSource dataSource, boolean z) {
                                progressBar.setVisibility(View.GONE);
                                return false;
                            }
                        }).diskCacheStrategy(DiskCacheStrategy.ALL)).into(photoView);
                    } else {
                        RequestManager with2 = Glide.with((FragmentActivity) LWT_WallpaperDetailActivity.this);
                        RequestManager with3 = Glide.with((FragmentActivity) LWT_WallpaperDetailActivity.this);
                        ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) with2.load(LWT_Constant.BASE_IMAGE_URL + wallpaper.image_upload.replace(" ", "%20")).placeholder((int) R.drawable.bg_transparent)).thumbnail(with3.load("https://sarkaribhaiya.com/apps/wallpaper/upload/thumbs/" + ((LWT_Wallpaper) LWT_WallpaperDetailActivity.this.items.get(i)).image_upload.replace(" ", "%20"))).centerCrop()).addListener(new RequestListener<Drawable>() {
                            @Override
                            public boolean onLoadFailed(GlideException glideException, Object obj, Target<Drawable> target, boolean z) {
                                progressBar.setVisibility(View.GONE);
                                return false;
                            }

                            public boolean onResourceReady(Drawable drawable, Object obj, Target<Drawable> target, DataSource dataSource, boolean z) {
                                progressBar.setVisibility(View.GONE);
                                return false;
                            }
                        }).diskCacheStrategy(DiskCacheStrategy.ALL)).into(photoView);
                    }
                    relativeLayout.setVisibility(View.VISIBLE);
                    photoView.setVisibility(View.VISIBLE);
                    progressBar.setVisibility(View.VISIBLE);
                } else {
                    relativeLayout.setVisibility(View.GONE);
                    photoView.setVisibility(View.GONE);
                    progressBar.setVisibility(View.GONE);
                }
            }
            viewGroup.addView(inflate, 0);
            return inflate;
        }

        @Override
        public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
            viewGroup.removeView((View) obj);
        }
    }

    public void dialogOptionSetWallpaper(String str, LWT_Wallpaper wallpaper) {

        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(LWT_WallpaperDetailActivity.this);
        View bottomSheetView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.set_wallpaper_layout, null);
        bottomSheetDialog.setContentView(bottomSheetView);

        RelativeLayout rlhomescreen = bottomSheetView.findViewById(R.id.rlhomescreen);
        RelativeLayout rllockscreen = bottomSheetView.findViewById(R.id.rllockscreen);
        RelativeLayout rlboth = bottomSheetView.findViewById(R.id.rlboth);
        RelativeLayout rlcrop = bottomSheetView.findViewById(R.id.rlcrop);
        RelativeLayout rlwith = bottomSheetView.findViewById(R.id.rlwith);
        ImageView ivhomescreen = bottomSheetView.findViewById(R.id.ivhomescreen);
        ImageView ivlockscreen = bottomSheetView.findViewById(R.id.ivlockscreen);
        ImageView ivboth = bottomSheetView.findViewById(R.id.ivboth);
        ImageView ivcrop = bottomSheetView.findViewById(R.id.ivcrop);
        ImageView ivwith = bottomSheetView.findViewById(R.id.ivwith);
        TextView tvCancel = bottomSheetView.findViewById(R.id.tvCancel);
        TextView tvOk = bottomSheetView.findViewById(R.id.tvOk);

        String[] stringArray = getResources().getStringArray(R.array.dialog_set_wallpaper);
        this.SingleChoiceSelected = stringArray[0];
        ivlockscreen.setImageResource(R.drawable.ic_unselect_redio);
        ivboth.setImageResource(R.drawable.ic_unselect_redio);
        ivcrop.setImageResource(R.drawable.ic_unselect_redio);
        ivwith.setImageResource(R.drawable.ic_unselect_redio);
        ivhomescreen.setImageResource(R.drawable.ic_select_redio);

        rlhomescreen.setOnClickListener(v -> {
            SingleChoiceSelected = stringArray[0];
            Log.d("ggg", "" + SingleChoiceSelected);
            ivlockscreen.setImageResource(R.drawable.ic_unselect_redio);
            ivboth.setImageResource(R.drawable.ic_unselect_redio);
            ivcrop.setImageResource(R.drawable.ic_unselect_redio);
            ivwith.setImageResource(R.drawable.ic_unselect_redio);
            ivhomescreen.setImageResource(R.drawable.ic_select_redio);
        });
        rllockscreen.setOnClickListener(v -> {
            SingleChoiceSelected = stringArray[1];
            Log.d("ggg", "" + SingleChoiceSelected);
            ivhomescreen.setImageResource(R.drawable.ic_unselect_redio);
            ivboth.setImageResource(R.drawable.ic_unselect_redio);
            ivcrop.setImageResource(R.drawable.ic_unselect_redio);
            ivwith.setImageResource(R.drawable.ic_unselect_redio);
            ivlockscreen.setImageResource(R.drawable.ic_select_redio);
        });
        rlboth.setOnClickListener(v -> {
            SingleChoiceSelected = stringArray[2];
            Log.d("ggg", "" + SingleChoiceSelected);
            ivhomescreen.setImageResource(R.drawable.ic_unselect_redio);
            ivlockscreen.setImageResource(R.drawable.ic_unselect_redio);
            ivcrop.setImageResource(R.drawable.ic_unselect_redio);
            ivwith.setImageResource(R.drawable.ic_unselect_redio);
            ivboth.setImageResource(R.drawable.ic_select_redio);
        });
        rlcrop.setOnClickListener(v -> {
            SingleChoiceSelected = stringArray[3];
            Log.d("ggg", "" + SingleChoiceSelected);
            ivhomescreen.setImageResource(R.drawable.ic_unselect_redio);
            ivlockscreen.setImageResource(R.drawable.ic_unselect_redio);
            ivboth.setImageResource(R.drawable.ic_unselect_redio);
            ivwith.setImageResource(R.drawable.ic_unselect_redio);
            ivcrop.setImageResource(R.drawable.ic_select_redio);
        });
        rlwith.setOnClickListener(v -> {
            SingleChoiceSelected = stringArray[4];
            Log.d("ggg", "" + SingleChoiceSelected);
            ivhomescreen.setImageResource(R.drawable.ic_unselect_redio);
            ivlockscreen.setImageResource(R.drawable.ic_unselect_redio);
            ivboth.setImageResource(R.drawable.ic_unselect_redio);
            ivcrop.setImageResource(R.drawable.ic_unselect_redio);
            ivwith.setImageResource(R.drawable.ic_select_redio);
        });
        tvOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(LWT_WallpaperDetailActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        progressDialog.setMessage("Preparing wallpaper…");
                        progressDialog.setCancelable(false);
                        progressDialog.show();
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Glide.with(LWT_WallpaperDetailActivity.this).load(str.replace(" ", "%20")).into(new CustomTarget<Drawable>() {
                                    public void onResourceReady(Drawable drawable, Transition<? super Drawable> transition) {
                                        Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
                                        if (LWT_WallpaperDetailActivity.this.SingleChoiceSelected.equals(LWT_WallpaperDetailActivity.this.getResources().getString(R.string.lwt_txt_set_home_screen))) {
                                            LWT_WallpaperDetailActivity.this.wallpaperHelper.setWallpaper(LWT_WallpaperDetailActivity.this.parentView, LWT_WallpaperDetailActivity.this.progressDialog, bitmap, LWT_Constant.HOME_SCREEN);
                                            LWT_WallpaperDetailActivity.this.progressDialog.setMessage("Applying wallpaper…");
                                        } else if (LWT_WallpaperDetailActivity.this.SingleChoiceSelected.equals(LWT_WallpaperDetailActivity.this.getResources().getString(R.string.lwt_txt_set_lock_screen))) {
                                            LWT_WallpaperDetailActivity.this.wallpaperHelper.setWallpaper(LWT_WallpaperDetailActivity.this.parentView, LWT_WallpaperDetailActivity.this.progressDialog, bitmap, LWT_Constant.LOCK_SCREEN);
                                            LWT_WallpaperDetailActivity.this.progressDialog.setMessage("Applying wallpaper…");
                                        } else if (LWT_WallpaperDetailActivity.this.SingleChoiceSelected.equals(LWT_WallpaperDetailActivity.this.getResources().getString(R.string.lwt_txt_set_both))) {
                                            LWT_WallpaperDetailActivity.this.wallpaperHelper.setWallpaper(LWT_WallpaperDetailActivity.this.parentView, LWT_WallpaperDetailActivity.this.progressDialog, bitmap, LWT_Constant.BOTH);
                                            LWT_WallpaperDetailActivity.this.progressDialog.setMessage("Applying wallpaper…");
                                        } else if (LWT_WallpaperDetailActivity.this.SingleChoiceSelected.equals(LWT_WallpaperDetailActivity.this.getResources().getString(R.string.lwt_txt_set_crop))) {
                                            if (wallpaper.type.equals("upload")) {
                                                Intent intent = new Intent(LWT_WallpaperDetailActivity.this.getApplicationContext(), LWT_CropWallpaperActivity.class);
                                                intent.putExtra(LWT_DBHelper.IMAGE_URL, LWT_Constant.BASE_IMAGE_URL + wallpaper.image_upload);
                                                LWT_WallpaperDetailActivity.this.startActivity(intent);
                                            } else if (wallpaper.type.equals("url")) {
                                                Intent intent2 = new Intent(LWT_WallpaperDetailActivity.this.getApplicationContext(), LWT_CropWallpaperActivity.class);
                                                intent2.putExtra(LWT_DBHelper.IMAGE_URL, wallpaper.image_url);
                                                LWT_WallpaperDetailActivity.this.startActivity(intent2);
                                            }
                                            LWT_WallpaperDetailActivity.this.progressDialog.dismiss();
                                        } else if (LWT_WallpaperDetailActivity.this.SingleChoiceSelected.equals(LWT_WallpaperDetailActivity.this.getResources().getString(R.string.lwt_txt_set_with))) {
                                            if (wallpaper.type.equals("upload")) {
                                                LWT_WallpaperHelper wallpaperHelper = LWT_WallpaperDetailActivity.this.wallpaperHelper;
                                                wallpaperHelper.setWallpaperFromOtherApp(LWT_Constant.BASE_IMAGE_URL + wallpaper.image_upload);
                                            } else if (wallpaper.type.equals("url")) {
                                                LWT_WallpaperDetailActivity.this.wallpaperHelper.setWallpaperFromOtherApp(wallpaper.image_url);
                                            }
                                            LWT_WallpaperDetailActivity.this.progressDialog.dismiss();
                                        }
                                    }

                                    @Override
                                    public void onLoadCleared(Drawable drawable) {
                                        LWT_WallpaperDetailActivity.this.progressDialog.dismiss();
                                    }

                                    @Override
                                    public void onLoadFailed(Drawable drawable) {
                                        super.onLoadFailed(drawable);
                                        Snackbar.make(LWT_WallpaperDetailActivity.this.parentView, LWT_WallpaperDetailActivity.this.getString(R.string.lwt_txt_snack_bar_failed), -1).show();
                                        LWT_WallpaperDetailActivity.this.progressDialog.dismiss();
                                    }
                                });
                            }
                        }, 2500);
                        bottomSheetDialog.dismiss();
                    }
                }, MAIN_CLICK);
            }
        });

        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.dismiss();
            }
        });

        bottomSheetDialog.show();
    }

    public void fullScreenMode(boolean z) {
        if (z) {
            this.toolbar.setVisibility(View.GONE);
            this.toolbar.animate().translationY(-112.0f);
            this.lytBottom.setVisibility(View.GONE);
            this.lytBottom.animate().translationY((float) this.lytBottom.getHeight());
            this.rlBgShadowTop.setVisibility(View.GONE);
            this.rlBgShadowTop.animate().translationY(-112.0f);
            this.rlBgShadowBottom.setVisibility(View.GONE);
            this.rlBgShadowBottom.animate().translationY((float) this.lytBottom.getHeight());
            LWT_Tools.transparentStatusBarNavigation(this);
            hideSystemUI();
            return;
        }
        this.toolbar.setVisibility(View.VISIBLE);
        this.toolbar.animate().translationY(0.0f);
        this.lytBottom.setVisibility(View.VISIBLE);
        this.lytBottom.animate().translationY(0.0f);
        this.rlBgShadowTop.setVisibility(View.VISIBLE);
        this.rlBgShadowTop.animate().translationY(0.0f);
        this.rlBgShadowBottom.setVisibility(View.VISIBLE);
        this.rlBgShadowBottom.animate().translationY(0.0f);
        LWT_Tools.transparentStatusBarNavigation(this);
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        getInstance(LWT_WallpaperDetailActivity.this).ShowAd(new HandleClick() {
            @Override
            public void Show(boolean adShow) {
                onBackPressed();
            }
        }, BACK_CLICK);

        return true;
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(3846);
    }

    @Override
    protected void onResume() {
        super.onResume();
        AdShow.getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
