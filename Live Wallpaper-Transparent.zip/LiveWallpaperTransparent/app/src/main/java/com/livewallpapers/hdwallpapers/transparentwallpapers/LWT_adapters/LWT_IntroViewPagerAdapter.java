package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_adapters;

import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.viewpager.widget.PagerAdapter;

import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models.LWT_ScreenItem;
import com.livewallpapers.hdwallpapers.transparentwallpapers.R;

import java.util.List;

public class LWT_IntroViewPagerAdapter extends PagerAdapter {
    Context mContext;
    List<LWT_ScreenItem> mListScreen;

    @Override 
    public boolean isViewFromObject(View view, Object obj) {
        return view == obj;
    }

    public LWT_IntroViewPagerAdapter(Context context, List<LWT_ScreenItem> list) {
        this.mContext = context;
        this.mListScreen = list;
    }

    @Override
    public Object instantiateItem(ViewGroup viewGroup, int i) {
        View inflate = ((LayoutInflater) this.mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.intro_lay, (ViewGroup) null);
        String colorText= "Live Wallpaper<br>"
                + "<font color=\"#9F99FF\"><bold>"
                + "Transparent"
                + "</bold></font>";
        ((TextView) inflate.findViewById(R.id.intro_title)).setText(Html.fromHtml(colorText));
        ((TextView) inflate.findViewById(R.id.intro_description)).setText(this.mListScreen.get(i).getDescription());
        ((ImageView) inflate.findViewById(R.id.intro_img)).setImageResource(this.mListScreen.get(i).getScreenImg());
        viewGroup.addView(inflate);
        return inflate;
    }

    @Override
    public int getCount() {
        return this.mListScreen.size();
    }

    @Override
    public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
        viewGroup.removeView((View) obj);
    }
}
