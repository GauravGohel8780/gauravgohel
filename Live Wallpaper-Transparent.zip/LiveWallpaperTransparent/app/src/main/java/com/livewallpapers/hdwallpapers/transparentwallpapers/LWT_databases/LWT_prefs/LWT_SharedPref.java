package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_prefs;

import android.content.Context;
import android.content.SharedPreferences;

public class LWT_SharedPref {
    private final SharedPreferences.Editor editor;
    private final SharedPreferences sharedPreferences;

    public LWT_SharedPref(Context context) {
        SharedPreferences sharedPreferences2 = context.getSharedPreferences("settings", 0);
        this.sharedPreferences = sharedPreferences2;
        this.editor = sharedPreferences2.edit();
    }

    public void saveGif(String str, String str2) {
        this.editor.putString("path", str);
        this.editor.putString("gif_name", str2);
        this.editor.apply();
    }

    public String getPath() {
        return this.sharedPreferences.getString("path", "0");
    }

    public String getGifName() {
        return this.sharedPreferences.getString("gif_name", "0");
    }

    public Integer getDisplayPosition(int i) {
        return Integer.valueOf(this.sharedPreferences.getInt("display_position", i));
    }

    public void updateDisplayPosition(int i) {
        this.editor.putInt("display_position", i);
        this.editor.apply();
    }

    public Integer getWallpaperColumns() {
        return Integer.valueOf(this.sharedPreferences.getInt("wallpaper_columns", 3));
    }

    public void updateWallpaperColumns(int i) {
        this.editor.putInt("wallpaper_columns", i);
        this.editor.apply();
    }

    public void setDefaultSortWallpaper() {
        this.editor.putInt("sort_act", 3);
        this.editor.apply();
    }

    public Integer getCurrentSortWallpaper() {
        return Integer.valueOf(this.sharedPreferences.getInt("sort_act", 0));
    }

    public void updateSortWallpaper(int i) {
        this.editor.putInt("sort_act", i);
        this.editor.apply();
    }

    public Boolean getIsDarkTheme() {
        return Boolean.valueOf(this.sharedPreferences.getBoolean("theme", true));
    }

    public void setIsDarkTheme(Boolean bool) {
        this.editor.putBoolean("theme", bool.booleanValue());
        this.editor.apply();
    }

    public Integer getAppOpenToken() {
        return Integer.valueOf(this.sharedPreferences.getInt("app_open_token", 0));
    }

    public void updateAppOpenToken(int i) {
        this.editor.putInt("app_open_token", i);
        this.editor.apply();
    }

    public Integer getInAppReviewToken() {
        return Integer.valueOf(this.sharedPreferences.getInt("in_app_review_token", 0));
    }

    public void updateInAppReviewToken(int i) {
        this.editor.putInt("in_app_review_token", i);
        this.editor.apply();
    }
}
