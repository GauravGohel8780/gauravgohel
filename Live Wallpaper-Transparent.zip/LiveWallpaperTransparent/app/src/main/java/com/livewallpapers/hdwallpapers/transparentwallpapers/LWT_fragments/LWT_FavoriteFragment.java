package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_fragments;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;


import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.livewallpapers.hdwallpapers.transparentwallpapers.R;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_activities.LWT_WallpaperDetailActivity;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_adapters.LWT_WallpaperAdapter;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_prefs.LWT_SharedPref;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_sqlite.LWT_DBHelper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models.LWT_Wallpaper;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_Constant;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LWT_FavoriteFragment extends Fragment {
    private LWT_WallpaperAdapter adapterWallpaper;
    private LWT_DBHelper dbHelper;
    private final List<LWT_Wallpaper> items = new ArrayList();
    private View lyt_no_favorite;

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.lwt_fragment_favorite, viewGroup, false);
        this.lyt_no_favorite = inflate.findViewById(R.id.lytNotFound);
        this.dbHelper = new LWT_DBHelper(requireActivity());
        LWT_SharedPref sharedPref = new LWT_SharedPref(requireActivity());
        RelativeLayout relativeLayout = (RelativeLayout) inflate.findViewById(R.id.parent_view);
        relativeLayout.setBackgroundColor(getResources().getColor(R.color.lwtColorColorBackgroundDark));
        RecyclerView recyclerView = (RecyclerView) inflate.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new StaggeredGridLayoutManager(sharedPref.getWallpaperColumns().intValue(), 1));
        recyclerView.setHasFixedSize(true);
        LWT_WallpaperAdapter adapterWallpaper2 = new LWT_WallpaperAdapter(requireActivity(), recyclerView, this.items);
        this.adapterWallpaper = adapterWallpaper2;
        recyclerView.setAdapter(adapterWallpaper2);
        displayData();
        return inflate;
    }

    private void displayData() {
        List<LWT_Wallpaper> allFavorite = this.dbHelper.getAllFavorite(LWT_DBHelper.TABLE_FAVORITE);
        Collections.shuffle(allFavorite);
        this.adapterWallpaper.setItems(allFavorite);
        if (allFavorite.size() == 0) {
            this.lyt_no_favorite.setVisibility(View.VISIBLE);
        } else {
            this.lyt_no_favorite.setVisibility(View.GONE);
        }
        this.adapterWallpaper.setOnItemClickListener(new LWT_WallpaperAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, LWT_Wallpaper wallpaper, int i) {
                getInstance(getActivity()).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(requireActivity(), LWT_WallpaperDetailActivity.class);
                        intent.putExtra(LWT_Constant.POSITION, i);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable(LWT_Constant.ARRAY_LIST, (Serializable) allFavorite);
                        intent.putExtra(LWT_Constant.BUNDLE, bundle);
                        intent.putExtra(LWT_Constant.EXTRA_OBJC, wallpaper);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });
    }


    @Override
    public void onResume() {
        super.onResume();
        displayData();
    }
}
