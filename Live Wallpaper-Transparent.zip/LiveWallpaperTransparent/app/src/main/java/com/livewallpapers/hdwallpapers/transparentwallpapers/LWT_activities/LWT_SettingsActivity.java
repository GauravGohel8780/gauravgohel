package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_activities;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.iten.tenoku.ad.AdShow;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.livewallpapers.hdwallpapers.transparentwallpapers.Ads_Common.AdsBaseActivity;
import com.livewallpapers.hdwallpapers.transparentwallpapers.BuildConfig;
import com.livewallpapers.hdwallpapers.transparentwallpapers.R;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_prefs.LWT_SharedPref;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_utils.LWT_Tools;

public class LWT_SettingsActivity extends AdsBaseActivity {
    private LWT_SharedPref sharedPref;
    private String SingleChoiceSelected;
    String str;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        LWT_Tools.getTheme(this);
        LWT_SharedPref sharedPref2 = new LWT_SharedPref(this);
        this.sharedPref = sharedPref2;
        setContentView(R.layout.lwt_activity_settings);

        findViewById(R.id.ivBack).setOnClickListener(v -> {
            getInstance(LWT_SettingsActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });

        TextView textView = (TextView) findViewById(R.id.tvWallpapeColumns);
        if (this.sharedPref.getWallpaperColumns().intValue() == 2) {
            textView.setText(R.string.lwt_txt_option_menu_wallpaper_2_columns);
        } else if (this.sharedPref.getWallpaperColumns().intValue() == 3) {
            textView.setText(R.string.lwt_txt_option_menu_wallpaper_3_columns);
        }
        findViewById(R.id.llcWallpaperColumns).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(LWT_SettingsActivity.this);
                View bottomSheetView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.bottom_sheet_dialog, null);
                bottomSheetDialog.setContentView(bottomSheetView);

                RelativeLayout rl2columns = bottomSheetView.findViewById(R.id.rl2columns);
                RelativeLayout rl3columns = bottomSheetView.findViewById(R.id.rl3columns);
                ImageView iv2columns = bottomSheetView.findViewById(R.id.iv2columns);
                ImageView iv3columns = bottomSheetView.findViewById(R.id.iv3columns);
                TextView tvCancel = bottomSheetView.findViewById(R.id.tvCancel);
                TextView tvOk = bottomSheetView.findViewById(R.id.tvOk);

                if (sharedPref.getWallpaperColumns().intValue() == 2) {
                    iv2columns.setImageResource(R.drawable.ic_select_redio);
                    iv3columns.setImageResource(R.drawable.ic_unselect_redio);
                } else if (sharedPref.getWallpaperColumns().intValue() == 3) {
                    iv2columns.setImageResource(R.drawable.ic_unselect_redio);
                    iv3columns.setImageResource(R.drawable.ic_select_redio);
                }

                rl2columns.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        SingleChoiceSelected = "2 Columns";
                        iv2columns.setImageResource(R.drawable.ic_select_redio);
                        iv3columns.setImageResource(R.drawable.ic_unselect_redio);
                    }
                });

                rl3columns.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        SingleChoiceSelected = "3 Columns";
                        iv2columns.setImageResource(R.drawable.ic_unselect_redio);
                        iv3columns.setImageResource(R.drawable.ic_select_redio);
                    }
                });
                tvOk.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        getInstance(LWT_SettingsActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                if (SingleChoiceSelected.equals(getResources().getString(R.string.lwt_txt_option_menu_wallpaper_2_columns))) {
                                    Intent intent = new Intent(getApplicationContext(), LWT_MainActivity.class);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    startActivity(intent);
                                    sharedPref.updateWallpaperColumns(2);
                                    textView.setText(R.string.lwt_txt_option_menu_wallpaper_2_columns);
                                } else if (SingleChoiceSelected.equals(getResources().getString(R.string.lwt_txt_option_menu_wallpaper_3_columns))) {
                                    Intent intent2 = new Intent(getApplicationContext(), LWT_MainActivity.class);
                                    intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    startActivity(intent2);
                                    sharedPref.updateWallpaperColumns(3);
                                    textView.setText(R.string.lwt_txt_option_menu_wallpaper_3_columns);
                                }
                                bottomSheetDialog.dismiss();
                            }
                        }, MAIN_CLICK);
                    }
                });

                tvCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        getInstance(LWT_SettingsActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                bottomSheetDialog.dismiss();
                            }
                        }, MAIN_CLICK);
                    }
                });

                bottomSheetDialog.show();
            }
        });

        findViewById(R.id.rlShare).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("text/plain");
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, R.string.app_name);
                    String shareMessage = "\nLet me recommend you this application\n\n";
                    shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "\n\n";
                    shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                    startActivity(Intent.createChooser(shareIntent, "choose one"));
                } catch (Exception e) {
                    //e.toString();
                }
            }
        });
        findViewById(R.id.rlRate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showRateUsDialog();
            }
        });
        if (Build.VERSION.SDK_INT >= 30) {
            str = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/" + getString(R.string.app_name);
        } else {
            str = Environment.getExternalStorageDirectory() + "/" + getString(R.string.app_name);
        }
        ((TextView) findViewById(R.id.tvPath)).setText(str);

    }

    private void showRateUsDialog() {
        Dialog dialog = new Dialog(LWT_SettingsActivity.this, R.style.customDialog);
        dialog.setContentView(R.layout.dialog_rate_us);

        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.show();

        RatingBar rb = (RatingBar) dialog.findViewById(R.id.ratingBar);

        TextView tvSubmit = dialog.findViewById(R.id.tvRateUs);

        tvSubmit.setOnClickListener(view -> {
            dialog.dismiss();

            Uri uri = Uri.parse("market://details?id=" + getPackageName());
            Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
            try {
                startActivity(myAppLinkToMarket);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(LWT_SettingsActivity.this, " unable to find market app", Toast.LENGTH_LONG).show();
            }
        });

        dialog.findViewById(R.id.tvCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }
    @Override
    protected void onResume() {
        super.onResume();
        AdShow.getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
