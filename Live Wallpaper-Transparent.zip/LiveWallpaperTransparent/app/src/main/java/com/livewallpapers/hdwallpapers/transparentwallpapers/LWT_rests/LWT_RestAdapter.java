package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_rests;

import android.app.Activity;



import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LWT_RestAdapter {
    static Activity activity;

    public LWT_RestAdapter(Activity activity) {
        this.activity = activity;
    }

    public static LWT_ApiInterface createAPI() {
        new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient build = new OkHttpClient.Builder().connectTimeout(5, TimeUnit.SECONDS).writeTimeout(10, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).cache(null).build();
        Retrofit.Builder builder = new Retrofit.Builder();
        return (LWT_ApiInterface) builder.baseUrl("https://sarkaribhaiya.com/apps/wallpaper/api/v1/").addConverterFactory(GsonConverterFactory.create()).client(build).build().create(LWT_ApiInterface.class);
    }
}
