package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.livewallpapers.hdwallpapers.transparentwallpapers.R;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LWT_SearchAdapter extends RecyclerView.Adapter<LWT_SearchAdapter.ViewHolder> {
    private static final String SEARCH_HISTORY_KEY = "_SEARCH_HISTORY_KEY";
    private List<String> items;
    private OnItemClickListener onItemClickListener;
    private final SharedPreferences prefs;

    public interface OnItemClickListener {
        void onItemClick(View view, String str, int i);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public LinearLayoutCompat lytParent;
        public TextView tvTitle;

        public ViewHolder(View view) {
            super(view);
            this.tvTitle = (TextView) view.findViewById(R.id.tvTitle);
            this.lytParent = (LinearLayoutCompat) view.findViewById(R.id.lytParent);
        }
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener2) {
        this.onItemClickListener = onItemClickListener2;
    }

    public LWT_SearchAdapter(Context context) {
        this.prefs = context.getSharedPreferences("PREF_RECENT_SEARCH", 0);
        List<String> searchHistory = getSearchHistory();
        this.items = searchHistory;
        Collections.reverse(searchHistory);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.lwt_item_suggestion, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder,@SuppressLint("RecyclerView") int i) {
        String str = this.items.get(i);
        viewHolder.tvTitle.setText(str);
        viewHolder.lytParent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickListener.onItemClick(view, str, i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.items.size();
    }

    public void refreshItems() {
        List<String> searchHistory = getSearchHistory();
        this.items = searchHistory;
        Collections.reverse(searchHistory);
        notifyDataSetChanged();
    }

    public class SearchObject implements Serializable {
        public List<String> items;

        public SearchObject(List<String> list) {
            this.items = list;
        }
    }

    public void addSearchHistory(String str) {
        SearchObject searchObject = new SearchObject(getSearchHistory());
        if (searchObject.items.contains(str)) {
            searchObject.items.remove(str);
        }
        searchObject.items.add(str);
        if (searchObject.items.size() > 0) {
            searchObject.items.remove(0);
        }
        this.prefs.edit().putString(SEARCH_HISTORY_KEY, new Gson().toJson(searchObject, SearchObject.class)).apply();
    }

    private List<String> getSearchHistory() {
        String string = this.prefs.getString(SEARCH_HISTORY_KEY, "");
        if (string.equals("")) {
            return new ArrayList();
        }
        return ((SearchObject) new Gson().fromJson(string, SearchObject.class)).items;
    }
}
