package com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_databases.LWT_sqlite;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models.LWT_Category;
import com.livewallpapers.hdwallpapers.transparentwallpapers.LWT_models.LWT_Wallpaper;

import java.util.ArrayList;
import java.util.List;

public class LWT_DBHelper extends SQLiteOpenHelper {
    public static final String CATEGORY_ID = "category_id";
    public static final String CATEGORY_IMAGE = "ivCategoryImage";
    public static final String CATEGORY_NAME = "tvCategoryName";
    private static final String DATABASE_NAME = "mwp.db";
    private static final int DATABASE_VERSION = 2;
    public static final String DOWNLOADS = "downloads";
    public static final String FEATURED = "featured";
    public static final String ID = "id";
    public static final String IMAGE_ID = "image_id";
    public static final String IMAGE_NAME = "image_name";
    public static final String IMAGE_UPLOAD = "image_upload";
    public static final String IMAGE_URL = "image_url";
    public static final String LAST_UPDATE = "last_update";
    public static final String MIME = "mime";
    public static final String RESOLUTION = "resolution";
    public static final String SIZE = "size";
    public static final String TABLE_CATEGORY = "tbl_category";
    public static final String TABLE_CATEGORY_DETAIL = "tbl_category_detail";
    public static final String TABLE_FAVORITE = "tbl_favorite";
    public static final String TABLE_FEATURED = "tbl_featured";
    public static final String TABLE_GIF = "tbl_gif";
    public static final String TABLE_POPULAR = "tbl_popular";
    public static final String TABLE_RANDOM = "tbl_random";
    public static final String TABLE_RECENT = "tbl_recent";
    public static final String TAGS = "tags";
    public static final String TOTAL_WALLPAPER = "total_wallpaper";
    public static final String TYPE = "type";
    public static final String VIEWS = "views";
    private final SQLiteDatabase db = getWritableDatabase();

    public LWT_DBHelper(Context context) {
        super(context, DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 2);
        Log.d("DB", "Constructor");
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        Log.d("DB", "onCreate");
        createTableWallpaper(sQLiteDatabase, TABLE_RECENT);
        createTableWallpaper(sQLiteDatabase, TABLE_FEATURED);
        createTableWallpaper(sQLiteDatabase, TABLE_POPULAR);
        createTableWallpaper(sQLiteDatabase, TABLE_RANDOM);
        createTableWallpaper(sQLiteDatabase, TABLE_GIF);
        createTableWallpaper(sQLiteDatabase, TABLE_FAVORITE);
        createTableWallpaper(sQLiteDatabase, TABLE_CATEGORY_DETAIL);
        createTableCategory(sQLiteDatabase, TABLE_CATEGORY);
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS tbl_recent");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS tbl_featured");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS tbl_popular");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS tbl_random");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS tbl_gif");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS tbl_favorite");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS tbl_category_detail");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS tbl_category");
        createTableWallpaper(sQLiteDatabase, TABLE_RECENT);
        createTableWallpaper(sQLiteDatabase, TABLE_FEATURED);
        createTableWallpaper(sQLiteDatabase, TABLE_POPULAR);
        createTableWallpaper(sQLiteDatabase, TABLE_RANDOM);
        createTableWallpaper(sQLiteDatabase, TABLE_GIF);
        createTableWallpaper(sQLiteDatabase, TABLE_FAVORITE);
        createTableWallpaper(sQLiteDatabase, TABLE_CATEGORY_DETAIL);
        createTableCategory(sQLiteDatabase, TABLE_CATEGORY);
    }

    public void truncateTableWallpaper(String str) {
        SQLiteDatabase sQLiteDatabase = this.db;
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + str);
        createTableWallpaper(this.db, str);
    }

    public void truncateTableCategory(String str) {
        SQLiteDatabase sQLiteDatabase = this.db;
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + str);
        createTableCategory(this.db, str);
    }

    private void createTableCategory(SQLiteDatabase sQLiteDatabase, String str) {
        sQLiteDatabase.execSQL("CREATE TABLE " + str + "(" + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + CATEGORY_ID + " TEXT, " + CATEGORY_NAME + " TEXT, " + CATEGORY_IMAGE + " TEXT, " + TOTAL_WALLPAPER + " TEXT )");
    }

    private void createTableWallpaper(SQLiteDatabase sQLiteDatabase, String str) {
        sQLiteDatabase.execSQL("CREATE TABLE " + str + "(" + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + IMAGE_ID + " TEXT, " + IMAGE_NAME + " TEXT, " + IMAGE_UPLOAD + " TEXT, " + IMAGE_URL + " TEXT, " + TYPE + " TEXT, " + RESOLUTION + " TEXT, " + SIZE + " TEXT, " + MIME + " TEXT, " + VIEWS + " INTEGER, " + DOWNLOADS + " INTEGER, " + FEATURED + " TEXT, " + TAGS + " TEXT, " + CATEGORY_ID + " TEXT, " + CATEGORY_NAME + " TEXT, " + LAST_UPDATE + " TEXT )");
    }

    public void onOpen(SQLiteDatabase sQLiteDatabase) {
        super.onOpen(sQLiteDatabase);
        sQLiteDatabase.disableWriteAheadLogging();
    }

    public void addListCategory(List<LWT_Category> list, String str) {
        for (LWT_Category category : list) {
            addOneCategory(this.db, category, str);
        }
        getAllCategory(str);
    }

    public void addListWallpaper(List<LWT_Wallpaper> list, String str) {
        for (LWT_Wallpaper wallpaper : list) {
            addOneWallpaper(this.db, wallpaper, str);
        }
        getAllWallpaper(str);
    }

    public void addOneCategory(SQLiteDatabase sQLiteDatabase, LWT_Category category, String str) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(CATEGORY_ID, category.category_id);
        contentValues.put(CATEGORY_NAME, category.category_name);
        contentValues.put(CATEGORY_IMAGE, category.category_image);
        contentValues.put(TOTAL_WALLPAPER, category.total_wallpaper);
        sQLiteDatabase.insert(str, null, contentValues);
    }

    public void addOneWallpaper(SQLiteDatabase sQLiteDatabase, LWT_Wallpaper wallpaper, String str) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(IMAGE_ID, wallpaper.image_id);
        contentValues.put(IMAGE_NAME, wallpaper.image_name);
        contentValues.put(IMAGE_UPLOAD, wallpaper.image_upload);
        contentValues.put(IMAGE_URL, wallpaper.image_url);
        contentValues.put(TYPE, wallpaper.type);
        contentValues.put(RESOLUTION, wallpaper.resolution);
        contentValues.put(SIZE, wallpaper.size);
        contentValues.put(MIME, wallpaper.mime);
        contentValues.put(VIEWS, Integer.valueOf(wallpaper.views));
        contentValues.put(DOWNLOADS, Integer.valueOf(wallpaper.downloads));
        contentValues.put(FEATURED, wallpaper.featured);
        contentValues.put(TAGS, wallpaper.tags);
        contentValues.put(CATEGORY_ID, wallpaper.category_id);
        contentValues.put(CATEGORY_NAME, wallpaper.tvCategoryName);
        contentValues.put(LAST_UPDATE, wallpaper.last_update);
        sQLiteDatabase.insert(str, null, contentValues);
    }

    public void addOneFavorite(LWT_Wallpaper wallpaper) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(IMAGE_ID, wallpaper.image_id);
        contentValues.put(IMAGE_NAME, wallpaper.image_name);
        contentValues.put(IMAGE_UPLOAD, wallpaper.image_upload);
        contentValues.put(IMAGE_URL, wallpaper.image_url);
        contentValues.put(TYPE, wallpaper.type);
        contentValues.put(RESOLUTION, wallpaper.resolution);
        contentValues.put(SIZE, wallpaper.size);
        contentValues.put(MIME, wallpaper.mime);
        contentValues.put(VIEWS, Integer.valueOf(wallpaper.views));
        contentValues.put(DOWNLOADS, Integer.valueOf(wallpaper.downloads));
        contentValues.put(FEATURED, wallpaper.featured);
        contentValues.put(TAGS, wallpaper.tags);
        contentValues.put(CATEGORY_ID, wallpaper.category_id);
        contentValues.put(CATEGORY_NAME, wallpaper.tvCategoryName);
        contentValues.put(LAST_UPDATE, wallpaper.last_update);
        this.db.insert(TABLE_FAVORITE, null, contentValues);
    }

    public void deleteAll(String str) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.execSQL("DELETE FROM " + str);
    }

    public void deleteWallpaperByCategory(String str, String str2) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.execSQL("DELETE FROM " + str + " WHERE " + CATEGORY_ID + " = " + str2);
    }

    public void deleteFavorites(LWT_Wallpaper wallpaper) {
        SQLiteDatabase sQLiteDatabase = this.db;
        sQLiteDatabase.delete(TABLE_FAVORITE, "image_id = ?", new String[]{wallpaper.image_id + ""});
    }

    public List<LWT_Category> getAllCategory(String str) {
        return getAllCategories(str);
    }

    public List<LWT_Wallpaper> getAllWallpaper(String str) {
        return getAllWallpapers(str);
    }

    public List<LWT_Wallpaper> getAllWallpaperByCategory(String str, String str2) {
        return getAllWallpapersByCategory(str, str2);
    }

    public List<LWT_Wallpaper> getAllFavorite(String str) {
        return getAllFavorites(str);
    }

    private List<LWT_Category> getAllCategories(String str) {
        SQLiteDatabase sQLiteDatabase = this.db;
        return getAllCategoryFormCursor(sQLiteDatabase.rawQuery("SELECT * FROM " + str + " ORDER BY id ASC", null));
    }

    private List<LWT_Wallpaper> getAllWallpapers(String str) {
        SQLiteDatabase sQLiteDatabase = this.db;
        return getAllWallpaperFormCursor(sQLiteDatabase.rawQuery("SELECT * FROM " + str + " ORDER BY id ASC LIMIT 100", null));
    }

    private List<LWT_Wallpaper> getAllWallpapersByCategory(String str, String str2) {
        SQLiteDatabase sQLiteDatabase = this.db;
        return getAllWallpaperFormCursor(sQLiteDatabase.rawQuery("SELECT * FROM " + str + " WHERE " + CATEGORY_ID + " = " + str2 + " ORDER BY id ASC LIMIT 100", null));
    }

    private List<LWT_Wallpaper> getAllFavorites(String str) {
        SQLiteDatabase sQLiteDatabase = this.db;
        return getAllWallpaperFormCursor(sQLiteDatabase.rawQuery("SELECT * FROM " + str + " ORDER BY id DESC", null));
    }

    public boolean isFavoritesExist(String str) {
        SQLiteDatabase sQLiteDatabase = this.db;
        Cursor rawQuery = sQLiteDatabase.rawQuery("SELECT * FROM tbl_favorite WHERE image_id = ?", new String[]{str + ""});
        int count = rawQuery.getCount();
        rawQuery.close();
        if (count > 0) {
            return true;
        }
        return false;
    }

    @SuppressLint("Range")
    private List<LWT_Category> getAllCategoryFormCursor(Cursor cursor) {
        ArrayList arrayList = new ArrayList();
        if (cursor.moveToFirst()) {
            do {
                LWT_Category category = new LWT_Category();
                category.category_id = cursor.getString(cursor.getColumnIndex(CATEGORY_ID));
                category.category_name = cursor.getString(cursor.getColumnIndex(CATEGORY_NAME));
                category.category_image = cursor.getString(cursor.getColumnIndex(CATEGORY_IMAGE));
                category.total_wallpaper = cursor.getString(cursor.getColumnIndex(TOTAL_WALLPAPER));
                arrayList.add(category);
            } while (cursor.moveToNext());
        }
        return arrayList;
    }

    @SuppressLint("Range")
    private List<LWT_Wallpaper> getAllWallpaperFormCursor(Cursor cursor) {
        ArrayList arrayList = new ArrayList();
        if (cursor.moveToFirst()) {
            do {
                LWT_Wallpaper wallpaper = new LWT_Wallpaper();
                wallpaper.image_id = cursor.getString(cursor.getColumnIndex(IMAGE_ID));
                wallpaper.image_name = cursor.getString(cursor.getColumnIndex(IMAGE_NAME));
                wallpaper.image_upload = cursor.getString(cursor.getColumnIndex(IMAGE_UPLOAD));
                wallpaper.image_url = cursor.getString(cursor.getColumnIndex(IMAGE_URL));
                wallpaper.type = cursor.getString(cursor.getColumnIndex(TYPE));
                wallpaper.resolution = cursor.getString(cursor.getColumnIndex(RESOLUTION));
                wallpaper.size = cursor.getString(cursor.getColumnIndex(SIZE));
                wallpaper.mime = cursor.getString(cursor.getColumnIndex(MIME));
                wallpaper.views = cursor.getInt(cursor.getColumnIndex(VIEWS));
                wallpaper.downloads = cursor.getInt(cursor.getColumnIndex(DOWNLOADS));
                wallpaper.featured = cursor.getString(cursor.getColumnIndex(FEATURED));
                wallpaper.tags = cursor.getString(cursor.getColumnIndex(TAGS));
                wallpaper.category_id = cursor.getString(cursor.getColumnIndex(CATEGORY_ID));
                wallpaper.tvCategoryName = cursor.getString(cursor.getColumnIndex(CATEGORY_NAME));
                wallpaper.last_update = cursor.getString(cursor.getColumnIndex(LAST_UPDATE));
                arrayList.add(wallpaper);
            } while (cursor.moveToNext());
        }
        return arrayList;
    }
}
