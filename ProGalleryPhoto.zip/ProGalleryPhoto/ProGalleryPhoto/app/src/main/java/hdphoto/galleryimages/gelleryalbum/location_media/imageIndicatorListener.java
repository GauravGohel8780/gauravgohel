package hdphoto.galleryimages.gelleryalbum.location_media;


public interface imageIndicatorListener {
    void onImageIndicatorClicked(int i);
}
