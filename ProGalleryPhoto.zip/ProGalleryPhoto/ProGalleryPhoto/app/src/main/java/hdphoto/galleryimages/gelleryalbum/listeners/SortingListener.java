package hdphoto.galleryimages.gelleryalbum.listeners;

import java.util.ArrayList;


public interface SortingListener {
    void Sorting(ArrayList<Object> arrayList);
}
