package hdphoto.galleryimages.gelleryalbum.listeners;


import java.util.ArrayList;

import hdphoto.galleryimages.gelleryalbum.model.mVideo;

public interface itemDeleteClickListener {
    void onDeleteClicked(int i, ArrayList<mVideo> arrayList);
}
