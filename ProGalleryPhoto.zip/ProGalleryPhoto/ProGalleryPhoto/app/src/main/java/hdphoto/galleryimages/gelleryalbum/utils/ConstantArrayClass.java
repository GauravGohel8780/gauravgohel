package hdphoto.galleryimages.gelleryalbum.utils;

import hdphoto.galleryimages.gelleryalbum.model.DataFileModel;
import hdphoto.galleryimages.gelleryalbum.model.FolderModel;
import java.util.ArrayList;


public class ConstantArrayClass {
    public static ArrayList arrayList = new ArrayList();
    public static ArrayList<Object> albumsList = new ArrayList<>();
    public static ArrayList<Object> imageList = new ArrayList<>();
    public static ArrayList<Object> videoList = new ArrayList<>();
    public static ArrayList imageAlbumArrayList = new ArrayList();
    public static ArrayList imageAlbumArrayList2 = new ArrayList();
    public static ArrayList<FolderModel> imageAlbumsList = new ArrayList<>();
    public static ArrayList videoAlbumArrayList = new ArrayList();
    public static ArrayList videoAlbumArrayList2 = new ArrayList();
    public static ArrayList<FolderModel> videoAlbumsList = new ArrayList<>();
    public static ArrayList<Object> folderAllImageList = new ArrayList<>();
    public static ArrayList<Object> folderAllVideoList = new ArrayList<>();
    public static ArrayList arrayImageSize = new ArrayList();
    public static ArrayList arrayVideoSize = new ArrayList();
    public static ArrayList<DataFileModel> firstTimeLockDataArray = new ArrayList<>();
}
