package hdphoto.galleryimages.gelleryalbum.listeners;

import java.util.ArrayList;


public interface HideImageFolderDataSortingListener {
    void Sorting(ArrayList<Object> arrayList);
}
