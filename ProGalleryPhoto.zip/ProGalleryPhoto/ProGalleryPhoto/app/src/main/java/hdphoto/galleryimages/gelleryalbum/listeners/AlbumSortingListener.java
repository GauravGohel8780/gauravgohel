package hdphoto.galleryimages.gelleryalbum.listeners;

import hdphoto.galleryimages.gelleryalbum.model.FolderModel;
import java.util.ArrayList;


public interface AlbumSortingListener {
    void Sorting(ArrayList<FolderModel> arrayList);
}
