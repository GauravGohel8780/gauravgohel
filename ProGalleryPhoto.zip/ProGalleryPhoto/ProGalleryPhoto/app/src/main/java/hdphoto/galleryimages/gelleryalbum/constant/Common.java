package hdphoto.galleryimages.gelleryalbum.constant;


public class Common {
    public static String IdentifyActivity = "";
    public static boolean checkPreview = false;
    public static String gActivityname = "activityname";
    public static String gAlbumColumns = "albumColumns";
    public static String gAlbumPath = "albumPath";
    public static String gAlbumType = "albumType";
    public static String gArrayType = "arrayType";
    public static String gBucketID = "bucketId";
    public static String gCurrenrtPosition = "currenrtPosition";
    public static String gCurrentPassword = "currentPassword";
    public static String gDataColumns = "dataColumns";
    public static int gEff_Pos = 0;
    public static String gImagePath = "imagePath";
    public static String gIsLockStatus = "isLockStatus";
    public static String gMediaType = "";
    public static String gOldPath = "oldPath";
    public static String gQuestion = "question";
    public static String gQuestionAnswer = "questionanswer";
    public static String gTempPassword = "tempPassword";
    public static String gTotalimage = "totalimage";
    public static String gUseMasterPassword = "useMasterPassword";
    public static String strplay = "strplay";
}
