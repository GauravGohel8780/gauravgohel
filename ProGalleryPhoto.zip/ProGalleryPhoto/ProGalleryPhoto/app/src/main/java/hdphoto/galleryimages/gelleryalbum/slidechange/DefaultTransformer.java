package hdphoto.galleryimages.gelleryalbum.slidechange;

import android.view.View;


public class DefaultTransformer extends BaseTransformer {
    @Override
    public boolean isPagingEnabled() {
        return true;
    }

    @Override
    public void onTransform(View view, float f) {
    }
}
