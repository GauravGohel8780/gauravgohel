package hdphoto.galleryimages.gelleryalbum.listeners;

import java.util.ArrayList;


public interface MomentSortingListener {
    void Sorting(ArrayList<Object> arrayList);
}
