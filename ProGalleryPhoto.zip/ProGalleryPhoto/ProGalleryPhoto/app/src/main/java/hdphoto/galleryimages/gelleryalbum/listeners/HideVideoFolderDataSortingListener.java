package hdphoto.galleryimages.gelleryalbum.listeners;

import java.util.ArrayList;


public interface HideVideoFolderDataSortingListener {
    void Sorting(ArrayList<Object> arrayList);
}
