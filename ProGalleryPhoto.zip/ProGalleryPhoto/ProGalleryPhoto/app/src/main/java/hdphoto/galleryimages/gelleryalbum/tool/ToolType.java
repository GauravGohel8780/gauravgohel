package hdphoto.galleryimages.gelleryalbum.tool;


public enum ToolType {
    SHAPE,
    TEXT,
    ERASER,
    FILTER,
    EMOJI,
    STICKER
}
