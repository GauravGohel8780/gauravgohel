package hdphoto.galleryimages.gelleryalbum.duplicate;


public class PhotosHeader {
    String header;

    public PhotosHeader(String str) {
        this.header = str;
    }

    public String getHeader() {
        return this.header;
    }

    public void setHeader(String str) {
        this.header = str;
    }
}
