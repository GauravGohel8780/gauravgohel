package hdphoto.galleryimages.gelleryalbum.duplicate;

import java.util.ArrayList;

public interface SimilarClickListener {
    void onPicClicked(int i, ArrayList<pictureFacer> arrayList, String str);
}