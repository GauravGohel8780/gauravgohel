package hdphoto.galleryimages.gelleryalbum.listeners;


public interface RefreshAdapterListener {
    void Refresh(Boolean bool);
}
