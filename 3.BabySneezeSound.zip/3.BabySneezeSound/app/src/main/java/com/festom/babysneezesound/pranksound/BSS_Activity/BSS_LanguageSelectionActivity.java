package com.festom.babysneezesound.pranksound.BSS_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.festom.babysneezesound.pranksound.BSS_Adapter.BSS_LanguageSelectionAdapter;
import com.festom.babysneezesound.pranksound.BSS_Ads_Common.AdsBaseActivity;
import com.festom.babysneezesound.pranksound.R;
import com.festom.babysneezesound.pranksound.BSS_model.BSS_LanguageModel;
import com.festom.babysneezesound.pranksound.BSS_preference.BSS_SharePref;
import com.festom.babysneezesound.pranksound.BSS_util.BSS_LanguageUtil;
import com.festom.babysneezesound.pranksound.BSS_util.BSS_Utils;
import com.google.gson.Gson;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.util.ArrayList;

public class BSS_LanguageSelectionActivity extends AdsBaseActivity {

    RecyclerView rvLanguages;
    ArrayList<BSS_LanguageModel> arrayList = new ArrayList<>();
    BSS_LanguageSelectionAdapter adapter;
    TextView tvNext;
    TextView tvSkip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language_selection);
        BSS_Utils.setStatusBarGradiant(this);

        rvLanguages = findViewById(R.id.rvLanguages);
        tvNext = findViewById(R.id.tvNext);
        tvSkip = findViewById(R.id.tvSkip);

        rvLanguages.setLayoutManager(new LinearLayoutManager(this));

        arrayList.add(new BSS_LanguageModel(R.drawable.ic_english, getString(R.string.English), "en"));
        arrayList.add(new BSS_LanguageModel(R.drawable.ic_india_flag, getString(R.string.hindi), "hi"));
        arrayList.add(new BSS_LanguageModel(R.drawable.ic_afrikaans, getString(R.string.afrikaans), "af"));
        arrayList.add(new BSS_LanguageModel(R.drawable.ic_chinese, getString(R.string.Chinese), "zh"));
        arrayList.add(new BSS_LanguageModel(R.drawable.ic_german, getString(R.string.German), "de"));
        arrayList.add(new BSS_LanguageModel(R.drawable.ic_spanish, getString(R.string.spanish), "es"));
        arrayList.add(new BSS_LanguageModel(R.drawable.ic_french, getString(R.string.french), "fr"));
        arrayList.add(new BSS_LanguageModel(R.drawable.ic_vietnam, getString(R.string.vietnam), "vi"));
        arrayList.add(new BSS_LanguageModel(R.drawable.ic_portugal, getString(R.string.portugal), "pt"));


        Log.d("--languages--", "onCreate: MainAct. " + new Gson().toJson(arrayList));

        adapter = new BSS_LanguageSelectionAdapter(this, arrayList);
        rvLanguages.setAdapter(adapter);


        tvNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BSS_LanguageSelectionActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        BSS_SharePref.saveSelectedPosition(BSS_LanguageSelectionActivity.this, adapter.selectedPosition);
                        BSS_LanguageUtil.setLanguage(BSS_LanguageSelectionActivity.this);
                        Intent intent = new Intent(BSS_LanguageSelectionActivity.this, BSS_MainActivity.class);
                        BSS_SharePref.putPrefLanguage(BSS_LanguageSelectionActivity.this, arrayList.get(adapter.selectedPosition).getLangCode());
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });

        int savedSelectedPosition = BSS_SharePref.loadSelectedPosition(this);
        if (savedSelectedPosition != -1) {

            adapter.selectedPosition = savedSelectedPosition;

            Log.d("--selection--", "onClick: MainActivity " + savedSelectedPosition);

        } else {
            adapter.selectedPosition = 0;
        }

        tvSkip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BSS_LanguageSelectionActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(BSS_LanguageSelectionActivity.this, BSS_MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }, MAIN_CLICK);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}