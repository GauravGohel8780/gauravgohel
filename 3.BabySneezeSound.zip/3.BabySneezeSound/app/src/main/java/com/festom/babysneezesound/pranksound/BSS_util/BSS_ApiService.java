package com.festom.babysneezesound.pranksound.BSS_util;


import com.festom.babysneezesound.pranksound.BSS_model.BSS_FeedBackResponseModel;
import com.festom.babysneezesound.pranksound.BSS_model.BSS_FeedbackRequestModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface BSS_ApiService {

    @POST("api/v1/feedBack/save")
    Call<BSS_FeedBackResponseModel> feedbackUser(@Body BSS_FeedbackRequestModel request);
}