package com.festom.babysneezesound.pranksound.BSS_model;

public class BSS_FeedBackResponseModel {

    public int iStatusCode;
    public boolean isStatus;
    public BSS_FeedbackDataModel data;
    public String vMessage;

    public int getiStatusCode() {
        return iStatusCode;
    }

    public void setiStatusCode(int iStatusCode) {
        this.iStatusCode = iStatusCode;
    }

    public boolean isStatus() {
        return isStatus;
    }

    public void setStatus(boolean status) {
        isStatus = status;
    }

    public BSS_FeedbackDataModel getFeedbackDataModel() {
        return data;
    }

    public void setFeedbackDataModel(BSS_FeedbackDataModel data) {
        this.data = data;
    }

    public String getvMessage() {
        return vMessage;
    }

    public void setvMessage(String vMessage) {
        this.vMessage = vMessage;
    }
}
