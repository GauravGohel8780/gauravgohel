package com.festom.carsound.pranksound.CPS_Activity;

import static com.iten.tenoku.utils.MyApplication.sharedPreferencesHelper;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

import androidx.core.app.ActivityCompat;

import com.festom.carsound.pranksound.Ads_Common.UnderMaintenanceActivity;
import com.festom.carsound.pranksound.BuildConfig;
import com.festom.carsound.pranksound.R;
import com.festom.carsound.pranksound.CPS_preference.CPS_SharePref;
import com.google.gson.Gson;
import com.iten.tenoku.activity.AppSettingActivity;
import com.iten.tenoku.databinding.DialogAppUpdateBinding;
import com.iten.tenoku.databinding.DialogInternetBinding;
import com.iten.tenoku.listeners.AppSettingListeners;
import com.iten.tenoku.networking.AdsResponse;
import com.iten.tenoku.utils.AdConstant;
import com.iten.tenoku.utils.AdUtils;
import com.iten.tenoku.utils.LogUtils;
import com.iten.tenoku.utils.MyApplication;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.single.PermissionListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CPS_SplashActivity extends AppSettingActivity {

    Activity activity;
    int LAUNCH_INTERNET_ACTIVITY = 1;
    String currentDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        SetSystemFullScreen();
        setContentView(R.layout.activity_splash);
        activity = this;

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/YYYY");
        currentDate = simpleDateFormat.format(Calendar.getInstance().getTime());

        setAdRequestStatus();
        checkNotificationPermission();

    }

    private void checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                intAction();
            } else {
                checkNotificationPermissionAbove33();
            }
        } else {
            intAction();
        }
    }

    public void checkNotificationPermissionAbove33() {
        Dexter.withContext(this).withPermission(Manifest.permission.POST_NOTIFICATIONS).withListener(new PermissionListener() {
            @Override
            public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                LogUtils.logV("TAG", "MyPermission onPermissionGranted");
                intAction();
            }

            @Override
            public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
                intAction();
            }

            @Override
            public void onPermissionRationaleShouldBeShown(com.karumi.dexter.listener.PermissionRequest permissionRequest, PermissionToken permissionToken) {
                permissionToken.continuePermissionRequest();
            }

        }).onSameThread().check();
    }

    private void intAction() {
        checkConnection();
    }

    private void checkConnection() {
        if (AdUtils.isNetworkAvailable(activity)) {
            loadSetting();
        } else {
            ShowNetworkDialog();
        }
    }

    private void ShowNetworkDialog() {
        Dialog dialog = new Dialog(activity);
        DialogInternetBinding dialogInternetBinding = DialogInternetBinding.inflate(getLayoutInflater());
        dialog.setContentView(dialogInternetBinding.getRoot());
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().getAttributes().gravity = Gravity.CENTER;
        dialog.setCancelable(false);
        dialogInternetBinding.buttonRetry.setOnClickListener(v -> {
            dialog.dismiss();
            if (AdUtils.isNetworkAvailable(activity)) {
                loadSetting();
            } else {
                Intent i = new Intent(Settings.ACTION_SETTINGS);
                startActivityForResult(i, LAUNCH_INTERNET_ACTIVITY);
            }
        });
        dialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == LAUNCH_INTERNET_ACTIVITY) {
            checkConnection();
        }
    }

    private void loadSetting() {
        AppSettings(activity, BuildConfig.VERSION_CODE, BuildConfig.APPLICATION_ID, new AppSettingListeners() {
            @Override
            public void onResponseSuccess() {
                LogUtils.logE("TAG", "onResponseSuccess: ");
                if (sharedPreferencesHelper.getAppOpenAd()) {
                    new Handler().postDelayed(() -> {
                        LogUtils.logD("TAG", "AppOpenManager PassActivity after 5 sec: ");
                        openWelcome();
                    }, 4000);

                } else {
                    new Handler().postDelayed(() -> {
                        GoToMainScreen();
                    }, 3000);
                }
            }

            @Override
            public void onUnderMaintenance() {
                com.iten.tenoku.utils.MyApplication.appOpenManager.ShowOpenAd(true, adShow -> {
                    startActivity(new Intent(activity, UnderMaintenanceActivity.class));
                    finish();
                });
            }

            @Override
            public void onResponseFail() {
                LogUtils.logE("TAG", "onResponseFail  ===> ");
                if (!sharedPreferencesHelper.sharedPreferences.getAll().isEmpty()) {
                    try {
                        AdsResponse appSettings = new Gson().fromJson(sharedPreferencesHelper.getResponse(), AdsResponse.class);
                        if (appSettings.getIsStatus()) {

                            Log.e("TAG", "onResponseFail: " + appSettings.getIsStatus());
                            CheckBooleanValue(appSettings);
                            CheckStringValue(appSettings);
                            CheckIntegerValue(appSettings);
                            SetAdColors(appSettings);
                            SetRecyclerViewAd(sharedPreferencesHelper.getGridViewPerItemAdTwo(), sharedPreferencesHelper.getGridViewPerItemAdThree(), sharedPreferencesHelper.getListViewAd());
                            SetAdData(appSettings);
                            SetHideFeature(appSettings);
                            SetUserData(appSettings);
                            FacebookAd(appSettings);
                            preLoadAd();
                            HandelData(sharedPreferencesHelper.getUnderMaintenance());
                        }
                    } catch (Exception e) {
                    }
                    openWelcome();
                } else {
                    recreate();
                }
            }

            @Override
            public void onAppUpdate(String url) {
                LogUtils.logE("TAG", "onAppUpdate: ");
                AppDialogShow(url, 0);
            }

            @Override
            public void onAppRedirect(String url) {
                LogUtils.logE("TAG", "onAppRedirect: ");
                AppDialogShow(url, 1);
            }

            @Override
            public void onStatusChange() {
                LogUtils.logE("TAG", "onStatusChange: ");

            }
        });

    }

    public final void openWelcome() {
        com.iten.tenoku.utils.MyApplication.appOpenManager.ShowOpenAd(true, adShow -> {
            GoToMainScreen();
        });

    }

    public void GoToMainScreen() {
        if (CPS_SharePref.IsFirstLaunch(getApplicationContext())) {
            startActivity(new Intent(CPS_SplashActivity.this, CPS_MainActivity.class));
            finish();
        } else {
            startActivity(new Intent(getApplicationContext(), CPS_IntroActivity.class));
            finish();
        }
    }

    private void AppDialogShow(String url, int i) {
        Dialog dialog = new Dialog(activity);
        DialogAppUpdateBinding dialogAppUpdateBinding = DialogAppUpdateBinding.inflate(getLayoutInflater());
        dialog.setContentView(dialogAppUpdateBinding.getRoot());
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().getAttributes().gravity = Gravity.CENTER;
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        if (i == 0) {
            dialogAppUpdateBinding.buttonRetry.setText(com.iten.tenoku.R.string.update_title);
            dialogAppUpdateBinding.txtTitle.setText(com.iten.tenoku.R.string.update_sub_title);
            dialogAppUpdateBinding.txtDecription.setText("");
            dialogAppUpdateBinding.txtDecription.setVisibility(View.GONE);
        } else if (i == 1) {
            dialogAppUpdateBinding.buttonRetry.setText(com.iten.tenoku.R.string.install_title);
            dialogAppUpdateBinding.txtTitle.setText(com.iten.tenoku.R.string.install_sub_title);
            dialogAppUpdateBinding.txtDecription.setVisibility(View.VISIBLE);
            dialogAppUpdateBinding.txtDecription.setText(com.iten.tenoku.R.string.install_descrption);
        } else {
            dialog.dismiss();
        }
        dialogAppUpdateBinding.buttonRetry.setOnClickListener(v -> {
            dialog.dismiss();
            try {
                Uri marketUri = Uri.parse(url);
                Intent marketIntent = new Intent(Intent.ACTION_VIEW, marketUri);
                startActivity(marketIntent);
            } catch (ActivityNotFoundException ignored) {
            }
        });
        dialog.show();
    }

    public void SetSystemFullScreen() {
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) {
            View v = getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }

    private void setAdRequestStatus() {
        if (!MyApplication.sharedPreferencesHelper.getUserSavedDate().equals(currentDate)) {
//            Log.e(TAG, "Saved Date--------------->" + MyApplication.sharedPreferencesHelper.getUserSavedDate());
//            Log.e(TAG, "Current Date--------------->" + currentDate);
//            Log.e(TAG, "Total Failed Count: ------->" + MyApplication.sharedPreferencesHelper.getTotalFailedCount());
            MyApplication.sharedPreferencesHelper.setTotalFailedCount(AdConstant.ResetTotalCount);
            MyApplication.sharedPreferencesHelper.setAdmobFailedCount(AdConstant.ResetTotalCount);
            MyApplication.sharedPreferencesHelper.setFbFailedCount(AdConstant.ResetTotalCount);
            MyApplication.sharedPreferencesHelper.setUserSavedDate(currentDate);
            sharedPreferencesHelper.setRequestDataSend(false);
        }
    }
}