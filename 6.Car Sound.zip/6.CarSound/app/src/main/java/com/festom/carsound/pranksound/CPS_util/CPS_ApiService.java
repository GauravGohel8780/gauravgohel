package com.festom.carsound.pranksound.CPS_util;


import com.festom.carsound.pranksound.CPS_model.CPS_FeedBackResponseModel;
import com.festom.carsound.pranksound.CPS_model.CPS_FeedbackRequestModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface CPS_ApiService {

    @POST("api/v1/feedBack/save")
    Call<CPS_FeedBackResponseModel> feedbackUser(@Body CPS_FeedbackRequestModel request);
}