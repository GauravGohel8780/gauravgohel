package com.festom.carsound.pranksound.CPS_Activity;

import static com.festom.carsound.pranksound.CPS_Activity.CPS_DetailActivity.v;
import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.festom.carsound.pranksound.Ads_Common.AdsBaseActivity;
import com.festom.carsound.pranksound.R;
import com.festom.carsound.pranksound.CPS_util.CPS_LanguageUtil;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.util.ArrayList;
import java.util.List;

public class CPS_MainActivity extends AdsBaseActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        CPS_LanguageUtil.setLanguage(CPS_MainActivity.this);
        RecyclerView recyclerView = findViewById(R.id.rvSounds);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        List<Integer> numbersList = new ArrayList<>();
        for (int i = 1; i <= v.length; i++) {
            numbersList.add(i);
        }
        PlayListAdapter adapter = new PlayListAdapter(numbersList);
        recyclerView.setAdapter(adapter);

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                showExitDialog();
            }
        };

        getOnBackPressedDispatcher().addCallback(callback);

        ((TextView)findViewById(R.id.tvTitle)).setText(getString(R.string.app_name));

        findViewById(R.id.cvSettings).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(CPS_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(CPS_MainActivity.this, CPS_SettingsActivity.class);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });
    }


    public class PlayListAdapter extends RecyclerView.Adapter<PlayListAdapter.NumberViewHolder> {
        private List<Integer> numbersList;
        int[] backgroundDrawables = {R.drawable.bg_item1, R.drawable.bg_item2, R.drawable.bg_item3, R.drawable.bg_item4, R.drawable.bg_item5, R.drawable.bg_item6, R.drawable.bg_item7, R.drawable.bg_item8};

        public PlayListAdapter(List<Integer> numbersList) {
            this.numbersList = numbersList;
        }

        @NonNull
        @Override
        public NumberViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_hair_clipper_sounds, parent, false);
            return new NumberViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull NumberViewHolder holder, int position) {

            int index = position % backgroundDrawables.length;

            int backgroundDrawable = backgroundDrawables[index];

            holder.itemView.setBackgroundResource(backgroundDrawable);
            holder.tvSoundName.setText(getString(R.string.app_name) + " " + numbersList.get(position));

            holder.itemView.setOnClickListener(v -> {
                getInstance(CPS_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        startActivity(new Intent(CPS_MainActivity.this, CPS_DetailActivity.class).putExtra("position", position));
                    }
                }, MAIN_CLICK);
            });
        }

        @Override
        public int getItemCount() {
            return numbersList.size();
        }

        class NumberViewHolder extends RecyclerView.ViewHolder {
            TextView tvSoundName;

            NumberViewHolder(@NonNull View itemView) {
                super(itemView);
                tvSoundName = itemView.findViewById(R.id.tvSoundName);
            }
        }
    }


    private final void showExitDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.exit_dailog_layout);
        Window window = dialog.getWindow();

        window.setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        ((TextView) dialog.findViewById(R.id.tvYes)).setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                dialog.dismiss();
                finishAffinity();
                System.exit(0);
            }
        });
        ((TextView) dialog.findViewById(R.id.tvNo)).setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}