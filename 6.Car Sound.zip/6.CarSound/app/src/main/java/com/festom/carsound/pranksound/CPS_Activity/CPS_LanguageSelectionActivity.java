package com.festom.carsound.pranksound.CPS_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.festom.carsound.pranksound.CPS_Adapter.CPS_LanguageSelectionAdapter;
import com.festom.carsound.pranksound.Ads_Common.AdsBaseActivity;
import com.festom.carsound.pranksound.R;
import com.festom.carsound.pranksound.CPS_model.CPS_LanguageModel;
import com.festom.carsound.pranksound.CPS_preference.CPS_SharePref;
import com.festom.carsound.pranksound.CPS_util.CPS_LanguageUtil;
import com.festom.carsound.pranksound.CPS_util.CPS_Utils;
import com.google.gson.Gson;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.util.ArrayList;

public class CPS_LanguageSelectionActivity extends AdsBaseActivity {

    RecyclerView rvLanguages;
    ArrayList<CPS_LanguageModel> arrayList = new ArrayList<>();
    CPS_LanguageSelectionAdapter adapter;
    TextView tvNext;
    TextView tvSkip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language_selection);
        CPS_Utils.setStatusBarGradiant(this);

        rvLanguages = findViewById(R.id.rvLanguages);
        tvNext = findViewById(R.id.tvNext);
        tvSkip = findViewById(R.id.tvSkip);

        rvLanguages.setLayoutManager(new LinearLayoutManager(this));

        arrayList.add(new CPS_LanguageModel(R.drawable.ic_english, getString(R.string.English), "en"));
        arrayList.add(new CPS_LanguageModel(R.drawable.ic_india_flag, getString(R.string.hindi), "hi"));
        arrayList.add(new CPS_LanguageModel(R.drawable.ic_afrikaans, getString(R.string.afrikaans), "af"));
        arrayList.add(new CPS_LanguageModel(R.drawable.ic_chinese, getString(R.string.Chinese), "zh"));
        arrayList.add(new CPS_LanguageModel(R.drawable.ic_german, getString(R.string.German), "de"));
        arrayList.add(new CPS_LanguageModel(R.drawable.ic_spanish, getString(R.string.spanish), "es"));
        arrayList.add(new CPS_LanguageModel(R.drawable.ic_french, getString(R.string.french), "fr"));
        arrayList.add(new CPS_LanguageModel(R.drawable.ic_vietnam, getString(R.string.vietnam), "vi"));
        arrayList.add(new CPS_LanguageModel(R.drawable.ic_portugal, getString(R.string.portugal), "pt"));


        Log.d("--languages--", "onCreate: MainAct. " + new Gson().toJson(arrayList));

        adapter = new CPS_LanguageSelectionAdapter(this, arrayList);
        rvLanguages.setAdapter(adapter);


        tvNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(CPS_LanguageSelectionActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        CPS_SharePref.saveSelectedPosition(CPS_LanguageSelectionActivity.this, adapter.selectedPosition);
                        CPS_LanguageUtil.setLanguage(CPS_LanguageSelectionActivity.this);
                        Intent intent = new Intent(CPS_LanguageSelectionActivity.this, CPS_MainActivity.class);
                        CPS_SharePref.putPrefLanguage(CPS_LanguageSelectionActivity.this, arrayList.get(adapter.selectedPosition).getLangCode());
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });

        int savedSelectedPosition = CPS_SharePref.loadSelectedPosition(this);
        if (savedSelectedPosition != -1) {

            adapter.selectedPosition = savedSelectedPosition;

            Log.d("--selection--", "onClick: MainActivity " + savedSelectedPosition);

        } else {
            adapter.selectedPosition = 0;
        }

        tvSkip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(CPS_LanguageSelectionActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(CPS_LanguageSelectionActivity.this, CPS_MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }, MAIN_CLICK);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}