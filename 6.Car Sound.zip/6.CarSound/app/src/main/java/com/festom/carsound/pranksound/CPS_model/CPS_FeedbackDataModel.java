package com.festom.carsound.pranksound.CPS_model;

public class CPS_FeedbackDataModel {
    public String vName;
    public String vEmail;
    public String vFeedBackMessage;
    public String vPackageName;
    public String vDeviceName;
    public int iVersion;
    public long dtCreatedAt;

    public String getvName() {
        return vName;
    }

    public void setvName(String vName) {
        this.vName = vName;
    }

    public String getvEmail() {
        return vEmail;
    }

    public void setvEmail(String vEmail) {
        this.vEmail = vEmail;
    }

    public String getvFeedBackMessage() {
        return vFeedBackMessage;
    }

    public void setvFeedBackMessage(String vFeedBackMessage) {
        this.vFeedBackMessage = vFeedBackMessage;
    }

    public String getvPackageName() {
        return vPackageName;
    }

    public void setvPackageName(String vPackageName) {
        this.vPackageName = vPackageName;
    }

    public String getvDeviceName() {
        return vDeviceName;
    }

    public void setvDeviceName(String vDeviceName) {
        this.vDeviceName = vDeviceName;
    }

    public int getiVersion() {
        return iVersion;
    }

    public void setiVersion(int iVersion) {
        this.iVersion = iVersion;
    }

    public long getDtCreatedAt() {
        return dtCreatedAt;
    }

    public void setDtCreatedAt(long dtCreatedAt) {
        this.dtCreatedAt = dtCreatedAt;
    }
}
