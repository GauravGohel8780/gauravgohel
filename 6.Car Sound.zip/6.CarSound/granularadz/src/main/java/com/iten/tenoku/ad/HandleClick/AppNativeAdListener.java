package com.iten.tenoku.ad.HandleClick;

public interface AppNativeAdListener {

    void onAdShown(Boolean shown);
}
