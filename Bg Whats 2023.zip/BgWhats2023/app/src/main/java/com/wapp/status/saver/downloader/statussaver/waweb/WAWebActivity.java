package com.wapp.status.saver.downloader.statussaver.waweb;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.DownloadListener;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.sk.SDKX.BackInterHelper;
import com.sk.SDKX.BannerHelper;
import com.wapp.status.saver.downloader.R;

import java.util.Locale;


public class WAWebActivity extends AppCompatActivity {
    private static final String AUDIO_PERMISSION = "android.permission.RECORD_AUDIO";
    private static final int AUDIO_PERMISSION_RESULTCODE = 202;
    private static final String CAMERA_PERMISSION = "android.permission.CAMERA";
    private static final int CAMERA_PERMISSION_RESULTCODE = 201;
    private static final String CHROME_FULL = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36";
    public static final String DEBUG_TAG = "KESSI";
    private static final String STORAGE_PERMISSION = "android.permission.WRITE_EXTERNAL_STORAGE";
    private static final int STORAGE_PERMISSION_RESULTCODE = 204;
    private static final String USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36";
    private static final String[] VIDEO_PERMISSION = {CAMERA_PERMISSION, AUDIO_PERMISSION};
    private static final int VIDEO_PERMISSION_RESULTCODE = 203;
    private static final String WHATSAPP_HOMEPAGE_URL = "https://www.whatsapp.com/";
    private static final String WHATSAPP_WEB_BASE_URL = "web.whatsapp.com";
    private static final String WHATSAPP_WEB_URL = ("https://web.whatsapp.com/🌐/" + Locale.getDefault().getLanguage());
    private static final String WORLD_ICON = "🌐";
    private final Activity activity = this;
    ImageView back;
    private String mCurrentDownloadRequest = null;
    private PermissionRequest mCurrentPermissionRequest;
    private long mLastBackClick = 0;
    private ValueCallback<Uri[]> mUploadMessage;
    private WebView mWebView;
    ImageView refresh;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_waweb);
         new BannerHelper().ShowBannerAds(this, (ViewGroup) findViewById(R.id.banner));
        getWindow().setSoftInputMode(16);
        back = (ImageView) findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                onBackPressed();
            }
        });
        mWebView = (WebView) findViewById(R.id.webview);
        mWebView.setDownloadListener(new DownloadListener() {
            public void onDownloadStart(String str, String str2, String str3, String str4, long j) {
                mCurrentDownloadRequest = str;
                if (checkPermission(WAWebActivity.STORAGE_PERMISSION)) {
                    mWebView.loadUrl(BlobDownloader.getBase64StringFromBlobUrl(str));
                    triggerDownload();
                    return;
                }
                requestPermission(WAWebActivity.STORAGE_PERMISSION);
            }
        });
        mWebView.addJavascriptInterface(new BlobDownloader(getApplicationContext()), BlobDownloader.JsInstance);
        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.getSettings().setAllowContentAccess(true);
        mWebView.getSettings().setAllowFileAccess(true);
        mWebView.getSettings().setAllowFileAccessFromFileURLs(true);
        mWebView.getSettings().setAllowUniversalAccessFromFileURLs(true);
        mWebView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        mWebView.getSettings().setDomStorageEnabled(true);
        mWebView.getSettings().setDatabaseEnabled(true);
//        mWebView.getSettings().setAppCacheEnabled(false);
        mWebView.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        mWebView.getSettings().setLoadWithOverviewMode(true);
        mWebView.getSettings().setUseWideViewPort(true);
        mWebView.getSettings().setSupportZoom(true);
        mWebView.getSettings().setBuiltInZoomControls(true);
        mWebView.getSettings().setDisplayZoomControls(false);
        mWebView.getSettings().setSaveFormData(true);
        mWebView.getSettings().setLoadsImagesAutomatically(true);
        mWebView.getSettings().setBlockNetworkImage(false);
        mWebView.getSettings().setBlockNetworkLoads(false);
        mWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        mWebView.getSettings().setNeedInitialFocus(false);
        mWebView.getSettings().setGeolocationEnabled(true);
        mWebView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        mWebView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        mWebView.setScrollbarFadingEnabled(true);
        mWebView.setWebChromeClient(new WebChromeClient() {
            public boolean onCreateWindow(WebView webView, boolean z, boolean z2, Message message) {
                Toast.makeText(getApplicationContext(), "OnCreateWindow", Toast.LENGTH_LONG).show();
                return true;
            }

            public void onPermissionRequest(PermissionRequest permissionRequest) {
                if (permissionRequest.getResources()[0].equals("android.webkit.resource.VIDEO_CAPTURE")) {
                    if (ContextCompat.checkSelfPermission(activity, WAWebActivity.CAMERA_PERMISSION) == -1 && ContextCompat.checkSelfPermission(activity, WAWebActivity.AUDIO_PERMISSION) == -1) {
                        ActivityCompat.requestPermissions(activity, WAWebActivity.VIDEO_PERMISSION, WAWebActivity.VIDEO_PERMISSION_RESULTCODE);
                        mCurrentPermissionRequest = permissionRequest;
                    } else if (ContextCompat.checkSelfPermission(activity, WAWebActivity.CAMERA_PERMISSION) == -1) {
                        ActivityCompat.requestPermissions(activity, new String[]{WAWebActivity.CAMERA_PERMISSION}, WAWebActivity.CAMERA_PERMISSION_RESULTCODE);
                        mCurrentPermissionRequest = permissionRequest;
                    } else if (ContextCompat.checkSelfPermission(activity, WAWebActivity.AUDIO_PERMISSION) == -1) {
                        ActivityCompat.requestPermissions(activity, new String[]{WAWebActivity.AUDIO_PERMISSION}, WAWebActivity.AUDIO_PERMISSION_RESULTCODE);
                        mCurrentPermissionRequest = permissionRequest;
                    } else {
                        permissionRequest.grant(permissionRequest.getResources());
                    }
                } else if (!permissionRequest.getResources()[0].equals("android.webkit.resource.AUDIO_CAPTURE")) {
                    try {
                        permissionRequest.grant(permissionRequest.getResources());
                    } catch (RuntimeException e) {
                        Log.d(WAWebActivity.DEBUG_TAG, "Granting permissions failed", e);
                    }
                } else if (ContextCompat.checkSelfPermission(activity, WAWebActivity.AUDIO_PERMISSION) == 0) {
                    permissionRequest.grant(permissionRequest.getResources());
                } else {
                    ActivityCompat.requestPermissions(activity, new String[]{WAWebActivity.AUDIO_PERMISSION}, WAWebActivity.AUDIO_PERMISSION_RESULTCODE);
                    mCurrentPermissionRequest = permissionRequest;
                }
            }

            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Log.d(WAWebActivity.DEBUG_TAG, "WebView console message: " + consoleMessage.message());
                return super.onConsoleMessage(consoleMessage);
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> valueCallback, FileChooserParams fileChooserParams) {
                mUploadMessage = valueCallback;
                startActivityForResult(fileChooserParams.createIntent(), 200);
                return true;
            }
        });
        mWebView.setWebViewClient(new WebViewClient() {
            public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
                super.onPageStarted(webView, str, bitmap);
            }

            public void onPageCommitVisible(WebView webView, String str) {
                super.onPageCommitVisible(webView, str);
            }

            public void onPageFinished(WebView webView, String str) {
                super.onPageFinished(webView, str);
                webView.scrollTo(0, 0);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
                Uri url = webResourceRequest.getUrl();
                Log.d(WAWebActivity.DEBUG_TAG, url.toString());
                if (url.toString().equals(WAWebActivity.WHATSAPP_HOMEPAGE_URL)) {
                    showToast("WA Web has to be reloaded to keep the app running");
                    loadWhatsapp();
                    return true;
                } else if (url.getHost().equals(WAWebActivity.WHATSAPP_WEB_BASE_URL)) {
                    return super.shouldOverrideUrlLoading(webView, webResourceRequest);
                } else {
                    startActivity(new Intent("android.intent.action.VIEW", url));
                    return true;
                }
            }

            public void onReceivedError(WebView webView, WebResourceRequest webResourceRequest, WebResourceError webResourceError) {
            }

            public void onUnhandledKeyEvent(WebView webView, KeyEvent keyEvent) {
                Log.d(WAWebActivity.DEBUG_TAG, "Unhandled key event: " + keyEvent.toString());
            }
        });
        if (bundle == null) {
            loadWhatsapp();
        } else {
            Log.d(DEBUG_TAG, "savedInstanceState is present");
        }
        this.mWebView.getSettings().setUserAgentString("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36");
        refresh = (ImageView) findViewById(R.id.refresh);
        refresh.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                showToast("reloading...");
                loadWhatsapp();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        this.mWebView.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        this.mWebView.onPause();
    }

    private boolean checkPermission(String str) {
        return ContextCompat.checkSelfPermission(this.activity, str) == 0;
    }

    private void requestPermission(String str) {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this.activity, str)) {
            ActivityCompat.requestPermissions(this.activity, new String[]{str}, STORAGE_PERMISSION_RESULTCODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        switch (i) {
            case CAMERA_PERMISSION_RESULTCODE:
            case AUDIO_PERMISSION_RESULTCODE:
                if (iArr.length > 0 && iArr[0] == 0) {
                    try {
                        PermissionRequest permissionRequest = this.mCurrentPermissionRequest;
                        permissionRequest.grant(permissionRequest.getResources());
                        break;
                    } catch (RuntimeException e) {
                        Log.e(DEBUG_TAG, "Granting permissions failed", e);
                        break;
                    }
                } else {
                    StringBuilder sb = new StringBuilder();
                    sb.append("Permission not granted, can't use ");
                    sb.append(i == CAMERA_PERMISSION_RESULTCODE ? "camera" : "microphone");
                    showToast(sb.toString());
                    this.mCurrentPermissionRequest.deny();
                    break;
                }
            case VIDEO_PERMISSION_RESULTCODE /*{ENCODED_INT: 203}*/:
                if (strArr.length != 2 || iArr[0] != 0 || iArr[1] != 0) {
                    showToast("Permission not granted, can't use video.");
                    this.mCurrentPermissionRequest.deny();
                    break;
                } else {
                    try {
                        PermissionRequest permissionRequest2 = this.mCurrentPermissionRequest;
                        permissionRequest2.grant(permissionRequest2.getResources());
                        break;
                    } catch (RuntimeException e2) {
                        Log.e(DEBUG_TAG, "Granting permissions failed", e2);
                        break;
                    }
                }
            case STORAGE_PERMISSION_RESULTCODE:
                if (iArr.length > 0 && iArr[0] == 0) {
                    triggerDownload();
                    break;
                } else {
                    showToast("Permission not granted, can't download");
                    this.mCurrentDownloadRequest = null;
                    break;
                }
            default:
                break;
        }
        this.mCurrentPermissionRequest = null;
    }

    private void loadWhatsapp() {
        this.mWebView.getSettings().setUserAgentString("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36");
        this.mWebView.loadUrl(WHATSAPP_WEB_URL);
    }

    private void triggerDownload() {
        String str = this.mCurrentDownloadRequest;
        if (str != null) {
            this.mWebView.loadUrl(BlobDownloader.getBase64StringFromBlobUrl(str));
        }
        this.mCurrentDownloadRequest = null;
    }

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        this.mWebView.saveState(bundle);
    }

    public void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        this.mWebView.restoreState(bundle);
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i != 200) {
            Log.d(DEBUG_TAG, "Got activity result with unknown request code " + i + " - " + intent.toString());
        } else if (i2 == 0 || intent.getData() == null) {
            this.mUploadMessage.onReceiveValue(null);
        } else {
            this.mUploadMessage.onReceiveValue(new Uri[]{intent.getData()});
        }
    }

    private void showToast(final String str) {
        runOnUiThread(new Runnable() {
            public void run() {
                Toast.makeText(WAWebActivity.this, str, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        new BackInterHelper().ShowIntertistialAds(WAWebActivity.this, new BackInterHelper.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onBack();
            }
        });
    }

    private void onBack() {
        super.onBackPressed();
    }
}