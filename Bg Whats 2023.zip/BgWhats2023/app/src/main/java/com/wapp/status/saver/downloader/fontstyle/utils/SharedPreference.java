package com.wapp.status.saver.downloader.fontstyle.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.wapp.status.saver.downloader.fontstyle.model.Emot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SharedPreference {
    public static final String FAVORITES = "Product_Favorite";
    public static final String PREFS_NAME = "PRODUCT_APP";

    public void saveFavorites(Context context, List<Emot> list) {
        SharedPreferences.Editor edit = context.getSharedPreferences(PREFS_NAME, 0).edit();
        edit.putString(FAVORITES, new Gson().toJson(list));
        edit.apply();
    }

    public void addFavorite(Context context, Emot emot) {
        ArrayList<Emot> favorites = getFavorites(context);
        if (favorites == null) {
            favorites = new ArrayList<>();
        }
        favorites.add(emot);
        saveFavorites(context, favorites);
    }

    public void removeFavorite(Context context, Emot emot) {
        ArrayList<Emot> favorites = getFavorites(context);
        if (favorites != null) {
            favorites.remove(emot);
            saveFavorites(context, favorites);
        }
    }

    public ArrayList<Emot> getFavorites(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_NAME, 0);
        if (!sharedPreferences.contains(FAVORITES)) {
            return null;
        }
        return new ArrayList<>(Arrays.asList((Emot[]) new Gson().fromJson(sharedPreferences.getString(FAVORITES, null), Emot[].class)));
    }
}