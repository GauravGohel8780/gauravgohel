package com.wapp.status.saver.downloader;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.sk.SDKX.InterHelper;
import com.sk.SDKX.NativeSmallHelper;

public class I_FirstActivity extends AppCompatActivity implements View.OnClickListener {
    RelativeLayout start, share, rate, privacy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first2);

        new NativeSmallHelper().ShowNativeAds(this, (ViewGroup) findViewById(R.id.llnativesmole));

        if (Build.VERSION.SDK_INT >= 23) {
            if (!checkPermission())
                requestPermission();
        }
        bind();
    }

    private void bind() {
        start = findViewById(R.id.start);
        start.setOnClickListener(this);
        share = findViewById(R.id.share);
        share.setOnClickListener(this);
        rate = findViewById(R.id.rate);
        rate.setOnClickListener(this);
        privacy = findViewById(R.id.privacy);
        privacy.setOnClickListener(this);
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.start:
                callStart();
                break;
            case R.id.share:
                shareApp();
                break;
            case R.id.rate:
                rateUs();
                break;
            case R.id.privacy:
                startActivity(new Intent(I_FirstActivity.this, I_PrivacyActivity.class));
                break;
        }
    }

    public void shareApp() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.TEXT", "Download this awesome app\n https://play.google.com/store/apps/details?id=" + getPackageName() + " \n");
        startActivity(intent);
    }

    public void rateUs() {
        try {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + getPackageName())));
        } catch (ActivityNotFoundException unused) {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
        }
    }

    private void callStart() {
        new InterHelper().ShowIntertistialAds(I_FirstActivity.this, new InterHelper.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                startActivity(new Intent(I_FirstActivity.this, I_Secondd_Activity.class));
            }
        });
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{
                "android.permission.WRITE_EXTERNAL_STORAGE",
                "android.permission.READ_EXTERNAL_STORAGE",
        }, 1);
    }

    public boolean checkPermission() {
        return ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.WRITE_EXTERNAL_STORAGE") == 0 &&
                ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.READ_EXTERNAL_STORAGE") == 0;
    }

    @Override
    public void onBackPressed() {
        showFormBioData();
    }

    private void showFormBioData() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.botomdialouge, null);
        builder.setView(dialogView);
        builder.setCancelable(false);
        MaterialButton btnRate = dialogView.findViewById(R.id.btnRate);
        TextView txtNoThanks = dialogView.findViewById(R.id.txtNoThanks);
        final AlertDialog dialog = builder.create();
        dialog.show();
        btnRate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rateUs();
                dialog.dismiss();
            }
        });
        txtNoThanks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finishAffinity();
            }
        });
    }
}