package com.wapp.status.saver.downloader.statussaver;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.fragment.app.FragmentActivity;

import com.bumptech.glide.Glide;
import com.sk.SDKX.BackInterHelper;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.statussaver.fragments.Utils;

import java.io.File;
import java.net.URLConnection;


public class WA_PreviewStatusActivity extends AppCompatActivity implements View.OnClickListener {
    AlertDialog.Builder builder;
    ImageView deleteIV;
    ImageView displayIV;
    VideoView displayVV;
    ImageView shareIV;
    ImageView wAppIV;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_preview);
        bind();
    }

    private void bind() {
        shareIV = findViewById(R.id.shareIV);
        shareIV.setOnClickListener(this);
        deleteIV = findViewById(R.id.deleteIV);
        deleteIV.setOnClickListener(this);
        wAppIV = findViewById(R.id.wAppIV);
        wAppIV.setOnClickListener(this);
        displayIV = findViewById(R.id.displayIV);
        displayVV = (VideoView) findViewById(R.id.displayVV);
        if (isImageFile(Utils.mPath)) {
            Glide.with((FragmentActivity) this).load(Utils.mPath).into(this.displayIV);
            displayIV.setVisibility(View.VISIBLE);
            displayVV.setVisibility(View.INVISIBLE);
        } else if (isVideoFile(Utils.mPath)) {
            displayVV.setVideoPath(Utils.mPath);
            displayVV.start();
            displayIV.setVisibility(View.INVISIBLE);
            displayVV.setVisibility(View.VISIBLE);
        }
        AlertDialog.Builder builder2 = new AlertDialog.Builder(this);
        this.builder = builder2;
        builder2.setTitle("Confirm Delete....");
        builder.setMessage("Are you sure, You Want To Delete This Status?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                new File(Utils.mPath).delete();
                Toast.makeText(WA_PreviewStatusActivity.this, "Status is deleted!!!", Toast.LENGTH_SHORT).show();
                setResult(10, new Intent());
                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.shareIV:
                share();
                break;
            case R.id.deleteIV:
                if (WA_PreviewStatusActivity.isVideoFile(Utils.mPath)) {
                    displayVV.pause();
                }
                delete();
                break;
            case R.id.wAppIV:
                onWapp();
                break;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (isVideoFile(Utils.mPath)) {
            displayVV.setVideoPath(Utils.mPath);
            displayVV.start();
            displayIV.setVisibility(View.INVISIBLE);
            displayVV.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    public static boolean isImageFile(String str) {
        String guessContentTypeFromName = URLConnection.guessContentTypeFromName(str);
        return guessContentTypeFromName != null && guessContentTypeFromName.startsWith("image");
    }

    public static boolean isVideoFile(String str) {
        String guessContentTypeFromName = URLConnection.guessContentTypeFromName(str);
        return guessContentTypeFromName != null && guessContentTypeFromName.startsWith("video");
    }

    public void share() {
        if (isImageFile(Utils.mPath)) {
            File file = new File(Utils.mPath);
            Intent intent = new Intent("android.intent.action.SEND");
            intent.addFlags(1);
            intent.setType("image/*");
            Context applicationContext = getApplicationContext();
            intent.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(applicationContext, getApplicationContext().getPackageName() + ".provider", file));
            startActivity(Intent.createChooser(intent, "Share via"));
        } else if (isVideoFile(Utils.mPath)) {
            Context applicationContext2 = getApplicationContext();
            Uri uriForFile = FileProvider.getUriForFile(applicationContext2, getApplicationContext().getPackageName() + ".provider", new File(Utils.mPath));
            Intent intent2 = new Intent("android.intent.action.SEND");
            intent2.setType("*/*");
            intent2.addFlags(1);
            intent2.putExtra("android.intent.extra.STREAM", uriForFile);
            startActivity(intent2);
        }
    }

    public void onWapp() {
        if (isImageFile(Utils.mPath)) {
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("image/*");
            intent.setPackage("com.whatsapp");
            File file = new File(Utils.mPath);
            Context applicationContext = getApplicationContext();
            intent.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(applicationContext, getApplicationContext().getPackageName() + ".provider", file));
            startActivity(Intent.createChooser(intent, "Share Image!"));
        } else if (isVideoFile(Utils.mPath)) {
            Context applicationContext2 = getApplicationContext();
            Uri uriForFile = FileProvider.getUriForFile(applicationContext2, getApplicationContext().getPackageName() + ".provider", new File(Utils.mPath));
            Intent intent2 = new Intent("android.intent.action.SEND");
            intent2.setType("*/*");
            intent2.setPackage("com.whatsapp");
            intent2.addFlags(1);
            intent2.putExtra("android.intent.extra.STREAM", uriForFile);
            startActivity(intent2);
        }
    }

    public void delete() {
        this.builder.show();
    }

     @Override
    public void onBackPressed() {
        super.onBackPressed();
        new BackInterHelper().ShowIntertistialAds(WA_PreviewStatusActivity.this, new BackInterHelper.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onBack();
            }
        });
    }

    private void onBack() {
        super.onBackPressed();
    }


}