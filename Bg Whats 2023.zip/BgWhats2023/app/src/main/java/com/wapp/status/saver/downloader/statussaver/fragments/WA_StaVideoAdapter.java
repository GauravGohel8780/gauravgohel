package com.wapp.status.saver.downloader.statussaver.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;

import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.sk.SDKX.InterHelper;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.statussaver.WA_PreviewStatusActivity;
import com.wapp.status.saver.downloader.statussaver.model.StatusModel;

import java.io.File;
import java.util.List;


public class WA_StaVideoAdapter extends BaseAdapter {
    List<StatusModel> VideoValues;
    private Activity context;
    public OnCheckboxListener onCheckboxListener;
    int width;

    public interface OnCheckboxListener {
        void onCheckboxListener(View view, List<StatusModel> list);
    }

    public Object getItem(int i) {
        return null;
    }

    public long getItemId(int i) {
        return 0;
    }

    public WA_StaVideoAdapter(Activity fragment, List<StatusModel> list, OnCheckboxListener onCheckboxListener2) {
        this.context = fragment;
        this.VideoValues = list;
        this.onCheckboxListener = onCheckboxListener2;
        this.width = fragment.getResources().getDisplayMetrics().widthPixels;
    }

    public int getCount() {
        return this.VideoValues.size();
    }

    public View getView(final int i, View view, ViewGroup viewGroup) {
        LayoutInflater layoutInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        new View(this.context);
        if (view == null) {
            layoutInflater.inflate(R.layout.ins_row_video, (ViewGroup) null);
        }
        View inflate = layoutInflater.inflate(R.layout.ins_row_video, (ViewGroup) null);
        Glide.with(this.context).load(this.VideoValues.get(i).getFilePath()).into((ImageView) inflate.findViewById(R.id.gridImageVideo));
        ((ImageView) inflate.findViewById(R.id.share)).setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                WA_StaVideoAdapter WAStaVideoAdapter = WA_StaVideoAdapter.this;
                WAStaVideoAdapter.share(WAStaVideoAdapter.VideoValues.get(i).getFilePath());
            }
        });
        CheckBox checkBox = (CheckBox) inflate.findViewById(R.id.checkbox);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                WA_StaVideoAdapter.this.VideoValues.get(i).setSelected(z);
                if (WA_StaVideoAdapter.this.onCheckboxListener != null) {
                    WA_StaVideoAdapter.this.onCheckboxListener.onCheckboxListener(compoundButton, WA_StaVideoAdapter.this.VideoValues);
                }
            }
        });
        if (this.VideoValues.get(i).isSelected()) {
            checkBox.setChecked(true);
        } else {
            checkBox.setChecked(false);
        }
        inflate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Utils.mPath = WA_StaVideoAdapter.this.VideoValues.get(i).getFilePath();
                new InterHelper().ShowIntertistialAds(context, new InterHelper.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        WA_StaVideoAdapter.this.context.startActivityForResult(new Intent(WA_StaVideoAdapter.this.context, WA_PreviewStatusActivity.class), 10);
                    }
                });
            }
        });
        int i2 = this.width;
        inflate.setLayoutParams(new AbsListView.LayoutParams((i2 * 460) / 1080, (i2 * 460) / 1080));
        return inflate;
    }

    public void share(String str) {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.addFlags(1);
        intent.setType("video/*");
        Context applicationContext = this.context.getApplicationContext();
        intent.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(applicationContext, this.context.getApplicationContext().getPackageName() + ".provider", new File(str)));
        this.context.startActivity(Intent.createChooser(intent, "Share via"));
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        Log.d("MyAdapter", "onActivityResult");
    }
}