package com.wapp.status.saver.downloader.fontstyle.frag;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.sk.SDKX.NativeHelper;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.Activity.HomeActivity;
import com.wapp.status.saver.downloader.fontstyle.utils.Copy_han;


public class Txtplay_fragment extends Fragment {
    ImageView back;
    ImageView close;
    Activity context;
    ImageView csf_bt_she;
    ImageView csf_bt_she_flip;
    ImageView csf_bt_she_reverseflip;
    EditText csf_i_p_t;
    TextView csf_r_r_r;
    ImageView csfb_c2;
    ImageView csfb_c2_filp;
    ImageView csfb_c_reverse;
    TextView txt_flip_text;
    TextView txt_reverseflip_text;

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.txt_play_frag, viewGroup, false);
         new NativeHelper().ShowNativeAds(getActivity(), (ViewGroup) inflate.findViewById(R.id.llnative));
        this.close = (ImageView) inflate.findViewById(R.id.csf_clos22);
        this.csf_i_p_t = (EditText) inflate.findViewById(R.id.csf_i_p_t);
        this.csf_r_r_r = (TextView) inflate.findViewById(R.id.csf_r_r_r);
        back = (ImageView) inflate.findViewById(R.id.backBtn);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                startActivity(new Intent(context, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                getActivity().finish();
            }
        });
        txt_reverseflip_text = (TextView) inflate.findViewById(R.id.txt_reverseflip_text);
        txt_flip_text = (TextView) inflate.findViewById(R.id.txt_flip_text);
        csfb_c2 = (ImageView) inflate.findViewById(R.id.btncopy);
        csfb_c2_filp = (ImageView) inflate.findViewById(R.id.btncopy_flip);
        csfb_c_reverse = (ImageView) inflate.findViewById(R.id.btncopy_reverseflip);
        csf_bt_she = (ImageView) inflate.findViewById(R.id.csf_bt_she);
        csf_bt_she_flip = (ImageView) inflate.findViewById(R.id.csf_bt_she_flip);
        csf_bt_she_reverseflip = (ImageView) inflate.findViewById(R.id.csf_bt_she_revrerseflip);
        final Copy_han copy_han = new Copy_han(this.context);
        this.csf_i_p_t.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable editable) {
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                TextView textView = csf_r_r_r;
                Txtplay_fragment txtplay_fragment = Txtplay_fragment.this;
                textView.setText(txtplay_fragment.revrsetext(txtplay_fragment.csf_i_p_t.getText().toString()));
                TextView textView2 = txt_reverseflip_text;
                Txtplay_fragment txtplay_fragment2 = Txtplay_fragment.this;
                textView2.setText(txtplay_fragment2.convertString(txtplay_fragment2.csf_i_p_t.getText().toString()));
                TextView textView3 = txt_flip_text;
                Txtplay_fragment txtplay_fragment3 = Txtplay_fragment.this;
                textView3.setText(txtplay_fragment3.revrsetext(txtplay_fragment3.convertString(txtplay_fragment3.csf_i_p_t.getText().toString())));
            }
        });
        this.csfb_c2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.copy(csf_r_r_r.getText().toString());
            }
        });
        this.csfb_c2_filp.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                StringBuilder sb = new StringBuilder();
                sb.append("txt_flip_text: ");
                sb.append(txt_flip_text.getText().toString());
                copy_han.copy(txt_flip_text.getText().toString());
            }
        });
        this.csfb_c_reverse.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.copy(txt_reverseflip_text.getText().toString());
            }
        });
        this.csf_bt_she.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.Share(csf_r_r_r.getText().toString());
            }
        });
        this.csf_bt_she_flip.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.Share(txt_flip_text.getText().toString());
            }
        });
        this.csf_bt_she_reverseflip.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.Share(txt_reverseflip_text.getText().toString());
            }
        });
        this.close.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                int length = csf_i_p_t.getText().length();
                if (length > 0) {
                    csf_i_p_t.getText().delete(length - 1, length);
                }
            }
        });
        this.close.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View view) {
                csf_i_p_t.getText().clear();
                return false;
            }
        });
        return inflate;
    }

    public String revrsetext(String str) {
        StringBuffer stringBuffer = new StringBuffer(str);
        stringBuffer.reverse();
        return String.valueOf(stringBuffer);
    }

    @Override
    public void onAttach(Context context2) {
        super.onAttach(context2);
        this.context = (Activity) context2;
    }

    public String convertString(String str) {
        String string = getString(R.string.normal_text);
        String string2 = getString(R.string.fliped_text);
        String str2 = "";
        for (int i = 0; i < str.length(); i++) {
            char charAt = str.charAt(i);
            int indexOf = string.indexOf(charAt);
            StringBuilder sb = new StringBuilder();
            sb.append(str2);
            if (indexOf != -1) {
                charAt = string2.charAt(indexOf);
            }
            sb.append(charAt);
            str2 = sb.toString();
        }
        return new StringBuilder(str2).reverse().toString();
    }
}