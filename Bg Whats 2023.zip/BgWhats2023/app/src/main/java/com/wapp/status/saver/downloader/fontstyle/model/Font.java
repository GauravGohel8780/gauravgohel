package com.wapp.status.saver.downloader.fontstyle.model;

public class Font {
    private String fontName;
    private String previewText = "Preview Text";

    public Font(String str) {
        this.fontName = str;
    }

    public String getFontName() {
        return this.fontName;
    }

    public String getPreviewText() {
        return this.previewText;
    }

    public void setPreviewText(String str) {
        this.previewText = str;
    }
}