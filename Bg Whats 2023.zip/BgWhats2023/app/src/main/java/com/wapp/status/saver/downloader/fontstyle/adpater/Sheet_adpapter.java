package com.wapp.status.saver.downloader.fontstyle.adpater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.interfaces.RecyclerViewItem;

import java.util.ArrayList;


public class Sheet_adpapter extends RecyclerView.Adapter<Sheet_adpapter.MyViewHolder> {
    Context context;
    ArrayList<String> o;
    RecyclerViewItem recyclerViewItem;

    public Sheet_adpapter(Context context2, ArrayList<String> arrayList, RecyclerViewItem recyclerViewItem2) {
        this.context = context2;
        this.o = arrayList;
        this.recyclerViewItem = recyclerViewItem2;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(this.context).inflate(R.layout.sheet_itm, viewGroup, false));
    }

    public void onBindViewHolder(final MyViewHolder myViewHolder, final int i) {
        myViewHolder.symbol.setText(this.o.get(i));
        myViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Sheet_adpapter.this.recyclerViewItem.onItemClick(myViewHolder.getAdapterPosition(), Sheet_adpapter.this.o.get(i));
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.o.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private final TextView symbol;

        private MyViewHolder(View view) {
            super(view);
            this.symbol = (TextView) view.findViewById(R.id.csf_sym_12);
        }
    }
}