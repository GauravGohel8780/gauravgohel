package com.wapp.status.saver.downloader.fontstyle.model;

import com.wapp.status.saver.downloader.fontstyle.interfaces.Style;

import java.util.Arrays;

public class Blueeff implements Style {
    private static final String[] EFFECTS = new String[52];
    private static final String NORMAL = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

    static {
        int i = 0;
        while (i < 52) {
            int i2 = i + 1;
            EFFECTS[i] = "🇦 🇧 🇨 🇩 🇪 🇫 🇬 🇭 🇮 🇯 🇰 🇱 🇲 🇳 🇴 🇵 🇶 🇷 🇸 🇹 🇺 🇻 🇼 🇽 🇾 🇿 🇦 🇧 🇨 🇩 🇪 🇫 🇬 🇭 🇮 🇯 🇰 🇱 🇲 🇳 🇴 🇵 🇶 🇷 🇸 🇹 🇺 🇻 🇼 🇽 🇾 🇿 ".substring(i * 3, i2 * 3);
            i = i2;
        }
    }

    @Override // com.epic.chatstyle.fontstyle.AppData.interfaces.Style
    public String generate(String str) {
        StringBuilder sb = new StringBuilder();
        Object obj = null;
        for (int i = 0; i < str.length(); i++) {
            char charAt = str.charAt(i);
            int indexOf = NORMAL.indexOf(charAt);
            if (indexOf != -1) {
                try {
                    obj = EFFECTS[indexOf];
                } catch (Exception unused) {
                    sb.append(charAt);
                }
            } else {
                obj = Character.valueOf(charAt);
            }
            sb.append(obj);
        }
        return sb.toString();
    }

    public int hashCode() {
        return Arrays.hashCode(EFFECTS);
    }
}