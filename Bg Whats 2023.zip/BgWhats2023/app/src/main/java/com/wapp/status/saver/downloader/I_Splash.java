package com.wapp.status.saver.downloader;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.sk.SDKX.AppcompactActivity;
import com.sk.SDKX.getDataListner;

public class I_Splash extends AppcompactActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        ADSinit(I_Splash.this, new getDataListner() {
            @Override
            public void onSuccess() {
                startActivity(new Intent(I_Splash.this, I_FirstActivity.class));
            }

            @Override
            public void onError() {
                startActivity(new Intent(I_Splash.this, I_FirstActivity.class));
            }
        });
    }

//        final Handler handler = new Handler();
//        handler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                call_next();
//            }
//        }, 4000);
//}
//    private void call_next() {
//        Intent intent = new Intent(I_Splash.this, I_FirstActivity.class);
//        startActivity(intent);
//        finish();
//    }

}