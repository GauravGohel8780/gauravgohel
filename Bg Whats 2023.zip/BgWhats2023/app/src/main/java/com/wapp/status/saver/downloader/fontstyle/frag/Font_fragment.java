package com.wapp.status.saver.downloader.fontstyle.frag;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.sk.SDKX.NativeSmallHelper;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.Activity.HomeActivity;
import com.wapp.status.saver.downloader.fontstyle.adpater.Font_adpapter;
import com.wapp.status.saver.downloader.fontstyle.more.Font_genrateActivty;
import com.wapp.status.saver.downloader.fontstyle.utils.Bottom_sheet;


public class Font_fragment extends Fragment implements TextWatcher {
    private static final String KEY = "FontFragment";
    ImageView backBtn;
    Context context;
    Font_adpapter csf_adap;
    ImageView csf_cls;
    RecyclerView csf_f_rv;
    private Font_genrateActivty csf_gen;
    ImageView csf_sb;
    EditText editText;
    SharedPreferences.Editor editor;
    SharedPreferences sharedPreferences;

    public void afterTextChanged(Editable editable) {
    }

    public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }

    @Override 
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.font_frag, viewGroup, false);

         new NativeSmallHelper().ShowNativeAds((Activity) context, (ViewGroup) inflate.findViewById(R.id.llnativesmole));

        this.csf_gen = new Font_genrateActivty(this.context);
        this.backBtn = (ImageView) inflate.findViewById(R.id.backBtn);
        this.csf_cls = (ImageView) inflate.findViewById(R.id.csf_cls_btn);
        csf_sb= (ImageView) inflate.findViewById(R.id.csf_sym1);
        csf_sb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Bottom_sheet.showDialogbox(context, editText);
            }
        });
        csf_f_rv = (RecyclerView) inflate.findViewById(R.id.csf_rec_v_f);
        csf_f_rv.setLayoutManager(new LinearLayoutManager(this.context));
        this.editText = (EditText) inflate.findViewById(R.id.csf_ed_ff);
        this.csf_f_rv.setHasFixedSize(true);
        Font_adpapter font_adpapter = new Font_adpapter(this.context);
        this.csf_adap = font_adpapter;
        this.csf_f_rv.setAdapter(font_adpapter);
        this.editText.addTextChangedListener(this);
        restoreText();
        this.csf_cls.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                int length = editText.getText().length();
                if (length > 0) {
                    editText.getText().delete(length - 1, length);
                }
            }
        });
        this.csf_cls.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View view) {
                editText.getText().clear();
                return false;
            }
        });
        this.backBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                startActivity(new Intent(context, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                getActivity().finish();
            }
        });
        return inflate;
    }

    private void convertText(String str) {
        if (str.isEmpty()) {
            str = "Fancy Text";
        }
        this.csf_adap.setData(this.csf_gen.generate(str));
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        convertText(this.editText.getText().toString());
    }

    private void restoreText() {
        SharedPreferences sharedPreferences2 = this.context.getSharedPreferences("MyPre", 0);
        this.sharedPreferences = sharedPreferences2;
        SharedPreferences.Editor edit = sharedPreferences2.edit();
        this.editor = edit;
        edit.apply();
        this.editText.setText(this.sharedPreferences.getString("FontFragment1", ""));
    }

    @Override
    public void onDestroyView() {
        SharedPreferences sharedPreferences2 = this.context.getSharedPreferences("MyPre", 0);
        this.sharedPreferences = sharedPreferences2;
        SharedPreferences.Editor edit = sharedPreferences2.edit();
        this.editor = edit;
        edit.apply();
        this.editor.putString("FontFragment1", this.editText.getText().toString()).apply();
        super.onDestroyView();
    }

    @Override
    public void onAttach(Context context2) {
        super.onAttach(context2);
        this.context = context2;
    }
}