package com.wapp.status.saver.downloader.statussaver.fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.storage.StorageManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;

import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.statussaver.adapter.RecWappAdapter;
import com.wapp.status.saver.downloader.statussaver.model.StatusModel;
import com.wapp.status.saver.downloader.statussaver.model.Util;
import com.wapp.status.saver.downloader.statussaver.util.SharedPrefs;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


public class WA_RecentWapp extends Fragment implements RecWappAdapter.OnCheckboxListener {
    int REQUEST_ACTION_OPEN_DOCUMENT_TREE = 101;
    LinearLayout actionLay;
    ArrayList<StatusModel> f = new ArrayList<>();
    ArrayList<StatusModel> filesToDelete = new ArrayList<>();
    GridView imagegrid;
    ProgressBar loader;
    RecWappAdapter myAdapter;
    LinearLayout sAccessBtn;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }



    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.sta_photos, viewGroup, false);
        loader = (ProgressBar) inflate.findViewById(R.id.loader);
        imagegrid = (GridView) inflate.findViewById(R.id.WorkImageGrid);
        actionLay = (LinearLayout) inflate.findViewById(R.id.actionLay);
        sAccessBtn = (LinearLayout) inflate.findViewById(R.id.sAccessBtn);
        sAccessBtn.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                Intent intent;
                if (Util.appInstalledOrNot(getActivity(), "com.whatsapp")) {
                    StorageManager storageManager = (StorageManager) getActivity().getSystemService("storage");
                    String whatsupFolder = getWhatsupFolder();
                    if (Build.VERSION.SDK_INT >= 29) {
                        intent = storageManager.getPrimaryStorageVolume().createOpenDocumentTreeIntent();
                        String replace = ((Uri) intent.getParcelableExtra("android.provider.extra.INITIAL_URI")).toString().replace("/root/", "/document/");
                        intent.putExtra("android.provider.extra.INITIAL_URI", Uri.parse(replace + "%3A" + whatsupFolder));
                    } else {
                        intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
                        intent.putExtra("android.provider.extra.INITIAL_URI", Uri.parse("content://com.android.externalstorage.documents/document/primary%3A" + whatsupFolder));
                    }
                    intent.addFlags(2);
                    intent.addFlags(1);
                    intent.addFlags(128);
                    intent.addFlags(64);
                    startActivityForResult(intent, REQUEST_ACTION_OPEN_DOCUMENT_TREE);
                    return;
                }
                Toast.makeText(getActivity(), "Please Install WhatsApp For Download Status!!!!!", Toast.LENGTH_SHORT).show();
            }
        });
        if (!SharedPrefs.getWATree(getActivity()).equals("")) {
            populateGrid();
        }
        return inflate;
    }


    public void populateGrid() {
        new loadDataAsync().execute(new Void[0]);
    }

    public class loadDataAsync extends AsyncTask<Void, Void, Void> {
        DocumentFile[] allFiles;

        loadDataAsync() {
        }

        public void onPreExecute() {
            super.onPreExecute();
            loader.setVisibility(View.VISIBLE);
            imagegrid.setVisibility(View.GONE);
            sAccessBtn.setVisibility(View.GONE);
        }

        public Void doInBackground(Void... voidArr) {
            this.allFiles = null;
            f = new ArrayList<>();
            this.allFiles = getFromSdcard();
            int i = 0;
            while (true) {
                DocumentFile[] documentFileArr = this.allFiles;
                if (i >= documentFileArr.length - 1) {
                    return null;
                }
                if (!documentFileArr[i].getUri().toString().contains(".nomedia")) {
                    f.add(new StatusModel(this.allFiles[i].getUri().toString()));
                }
                i++;
            }
        }

        public void onPostExecute(Void r4) {
            super.onPostExecute((Void) r4);
            new Handler().postDelayed(new Runnable() {
                public final void run() {
                    loadDataAsync.this.lambda$onPostExecute$0$RecentWapp$loadDataAsync();
                }
            }, 1000);
        }

        public void lambda$onPostExecute$0$RecentWapp$loadDataAsync() {
            if (WA_RecentWapp.this.getActivity() != null) {
                WA_RecentWapp WARecentWapp = WA_RecentWapp.this;
                WA_RecentWapp WARecentWapp2 = WA_RecentWapp.this;
                WARecentWapp.myAdapter = new RecWappAdapter(getActivity(), WARecentWapp2.f, WA_RecentWapp.this);
                imagegrid.setAdapter((ListAdapter) myAdapter);
                loader.setVisibility(View.GONE);
                imagegrid.setVisibility(View.VISIBLE);
            }
        }
    }

    private DocumentFile[] getFromSdcard() {
        DocumentFile fromTreeUri = DocumentFile.fromTreeUri(requireContext().getApplicationContext(), Uri.parse(SharedPrefs.getWATree(getActivity())));
        if (fromTreeUri == null || !fromTreeUri.exists() || !fromTreeUri.isDirectory() || !fromTreeUri.canRead() || !fromTreeUri.canWrite()) {
            return null;
        }
        return fromTreeUri.listFiles();
    }

    public String getWhatsupFolder() {
        StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStorageDirectory());
        sb.append(File.separator);
        sb.append("Android/media/com.whatsapp/WhatsApp");
        sb.append(File.separator);
        sb.append("Media");
        sb.append(File.separator);
        sb.append(".Statuses");
        return new File(sb.toString()).isDirectory() ? "Android%2Fmedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F.Statuses" : "WhatsApp%2FMedia%2F.Statuses";
    }

    @Override
    public void onCheckboxListener(View view, List<StatusModel> list) {
        this.filesToDelete.clear();
        for (StatusModel statusModel : list) {
            if (statusModel.isSelected()) {
                filesToDelete.add(statusModel);
            }
        }
        if (filesToDelete.size() == this.f.size()) {
        }
        if (!filesToDelete.isEmpty()) {
            actionLay.setVisibility(View.VISIBLE);
            return;
        }
        actionLay.setVisibility(View.GONE);
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == this.REQUEST_ACTION_OPEN_DOCUMENT_TREE && i2 == -1) {
            Uri data = intent.getData();
            Log.e("onActivityResult: ", "" + intent.getData());
            try {
                if (Build.VERSION.SDK_INT >= 19) {
                    requireContext().getContentResolver().takePersistableUriPermission(data, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            SharedPrefs.setWATree(getActivity(), data.toString());
            populateGrid();
        }
    }
}