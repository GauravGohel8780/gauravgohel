package com.wapp.status.saver.downloader.fontstyle.adpater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.model.Emot;
import com.wapp.status.saver.downloader.fontstyle.utils.Copy_han;
import com.wapp.status.saver.downloader.fontstyle.utils.SharedPreference;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class Fav_adpapter extends RecyclerView.Adapter<Fav_adpapter.ViewHolder> {
    private final Context k;
    List<Emot> r;
    SharedPreference sharedPreference = new SharedPreference();

    public Fav_adpapter(Context context, List<Emot> list) {
        this.k = context;
        this.r = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.itm_fav, viewGroup, false));
    }

    public void onBindViewHolder(final ViewHolder viewHolder, final int i) {
        final Copy_han copy_han = new Copy_han(this.k);
        final Emot emot = this.r.get(i);
        viewHolder.fav_text_view.setText(emot.getName());
        viewHolder.fav_text_view.setSelected(true);
        viewHolder.number.setText(String.valueOf(i + 1));
        viewHolder.k1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (viewHolder.k1.getTag().toString().equalsIgnoreCase("grey")) {
                    Fav_adpapter.this.sharedPreference.addFavorite(Fav_adpapter.this.k, Fav_adpapter.this.r.get(i));
                    viewHolder.k1.setTag("red");
                    viewHolder.k1.setImageResource(R.drawable.csf_fav_icon);
                    return;
                }
                Fav_adpapter.this.sharedPreference.removeFavorite(Fav_adpapter.this.k, Fav_adpapter.this.r.get(i));
                viewHolder.k1.setTag("grey");
                viewHolder.k1.setImageResource(R.drawable.csf_fav);
                Fav_adpapter fav_adpapter = Fav_adpapter.this;
                fav_adpapter.remove(fav_adpapter.r.get(i));
            }
        });
        viewHolder.a.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.copy(emot.getName());
            }
        });
        viewHolder.share.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.Share(emot.getName());
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.r.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView a;
        TextView fav_text_view;
        ImageView k1;
        TextView number;
        ImageView share;

        public ViewHolder(View view) {
            super(view);
            this.fav_text_view = (TextView) view.findViewById(R.id.emoti);
            this.k1 = (ImageView) view.findViewById(R.id.csf_fav_b1);
            this.number = (TextView) view.findViewById(R.id.csf_number12);
            this.a = (ImageView) view.findViewById(R.id.copy);
            this.share = (ImageView) view.findViewById(R.id.share);
        }
    }

    public boolean checkFavoriteItem(Emot emot) {
        ArrayList<Emot> favorites = this.sharedPreference.getFavorites(this.k);
        if (favorites == null) {
            return false;
        }
        Iterator<Emot> it = favorites.iterator();
        while (it.hasNext()) {
            if (it.next().equals(emot)) {
                return true;
            }
        }
        return false;
    }

    public void remove(Emot emot) {
        this.r.remove(emot);
        notifyDataSetChanged();
    }
}