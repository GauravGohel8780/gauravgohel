package com.wapp.status.saver.downloader.fontstyle.model;

public class ListModel {
    private String _name;

    public ListModel(String str) {
        this._name = str;
    }

    public String get_name() {
        return this._name;
    }
}