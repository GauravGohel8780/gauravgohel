package com.wapp.status.saver.downloader.fontstyle.Activity;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.sk.SDKX.BackInterHelper;
import com.sk.SDKX.InterHelper;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.frag.Deco_fragment;
import com.wapp.status.saver.downloader.fontstyle.frag.Design_fragment;
import com.wapp.status.saver.downloader.fontstyle.frag.Emoji_sheet_fragment;
import com.wapp.status.saver.downloader.fontstyle.frag.Font_fragment;
import com.wapp.status.saver.downloader.fontstyle.frag.Giltch_fragment;
import com.wapp.status.saver.downloader.fontstyle.frag.Num_style_fragment;
import com.wapp.status.saver.downloader.fontstyle.frag.Repest_fragment;
import com.wapp.status.saver.downloader.fontstyle.frag.Txtplay_fragment;

public class I_ShowActivity extends AppCompatActivity {
    String KEY = "Home";

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_show);
        int intExtra = getIntent().getIntExtra(this.KEY, 1);
        if (intExtra == 1) {
                    loadFragment(new Font_fragment());

        }
        if (intExtra == 2) {
                    loadFragment(new Deco_fragment());

        }
        if (intExtra == 4) {
                    loadFragment(new Emoji_sheet_fragment());

        }
        if (intExtra == 5) {
                    loadFragment(new Giltch_fragment());

        }
        if (intExtra == 6) {
                    loadFragment(new Repest_fragment());

        }
        if (intExtra == 8) {
                    loadFragment(new Design_fragment());

        }
        if (intExtra == 9) {
                    loadFragment(new Txtplay_fragment());

        }
        if (intExtra == 11) {
                    loadFragment(new Num_style_fragment());

        }
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction().replace(R.id.showFragment, fragment).commit();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        new BackInterHelper().ShowIntertistialAds(I_ShowActivity.this, new BackInterHelper.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onBack();
            }
        });
    }

    private void onBack() {
        super.onBackPressed();
    }
}