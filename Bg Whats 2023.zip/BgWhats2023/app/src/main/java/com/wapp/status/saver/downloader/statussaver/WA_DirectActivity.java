package com.wapp.status.saver.downloader.statussaver;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.rilixtech.widget.countrycodepicker.CountryCodePicker;
import com.sk.SDKX.BackInterHelper;
import com.sk.SDKX.NativeHelper;
import com.wapp.status.saver.downloader.R;


public class WA_DirectActivity extends AppCompatActivity {
    ImageView back;
    CountryCodePicker ccp;
    EditText edtPhoneNumber;
    EditText msg_edt;
    CardView wapp;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_direct);

        new NativeHelper().ShowNativeAds(this, (ViewGroup) findViewById(R.id.llnative));

        back = (ImageView) findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                onBackPressed();
            }
        });
        ccp = (CountryCodePicker) findViewById(R.id.ccp);
        edtPhoneNumber = (EditText) findViewById(R.id.phone_number_edt);
        ccp.registerPhoneNumberTextView(edtPhoneNumber);
        msg_edt = (EditText) findViewById(R.id.msg_edt);
        wapp = (CardView) findViewById(R.id.wapp);
        wapp.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                redirect();
            }
        });
    }

    public void redirect() {
        if (TextUtils.isEmpty(this.edtPhoneNumber.getText().toString())) {
            Toast.makeText(this, "Select country and Enter Mobile Number.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse("http://api.whatsapp.com/send?phone=" + this.ccp.getSelectedCountryCode() + this.edtPhoneNumber.getText().toString() + "&text=" + this.msg_edt.getText().toString()));
            startActivity(intent);
        } catch (Exception unused) {
            Toast.makeText(this, "Install WhatsApp First...", Toast.LENGTH_SHORT).show();
        }
    }

   @Override
    public void onBackPressed() {
        super.onBackPressed();
        new BackInterHelper().ShowIntertistialAds(WA_DirectActivity.this, new BackInterHelper.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onBack();
            }
        });
    }

    private void onBack() {
        super.onBackPressed();
    }
}
