package com.wapp.status.saver.downloader.fontstyle.adpater;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.model.ListModel;
import com.wapp.status.saver.downloader.fontstyle.utils.Copy_han;

import java.util.List;


public class Txt_adpapter extends RecyclerView.Adapter<Txt_adpapter.MyViewHolder> {
    private final Activity context;
    private final List<ListModel> l1;

    public Txt_adpapter(List<ListModel> list, Activity activity) {
        this.l1 = list;
        this.context = activity;
        notifyDataSetChanged();
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(this.context).inflate(R.layout.txt_itm, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {
        myViewHolder.w.setText(this.l1.get(i).get_name());
        myViewHolder.num.setText(String.valueOf(i + 1));
        final Copy_han copy_han = new Copy_han(this.context);
        final String charSequence = myViewHolder.w.getText().toString();
        myViewHolder.cg.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.copy(charSequence);
            }
        });
        myViewHolder.share.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.Share(charSequence);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.l1.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView cg;
        TextView num;
        ImageView share;
        TextView w;

        private MyViewHolder(View view) {
            super(view);
            this.num = (TextView) view.findViewById(R.id.csf_number3);
            this.cg = (ImageView) view.findViewById(R.id.csf_b_c_6);
            this.share = (ImageView) view.findViewById(R.id.csf_b_s_8);
            this.w = (TextView) view.findViewById(R.id.csf_t_design);
        }
    }
}