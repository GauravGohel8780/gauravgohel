package com.wapp.status.saver.downloader.fontstyle;

import java.util.Random;

public class Zalgo {
    public static final char[] DOWN_CHARS = {790, 791, 792, 793, 796, 797, 798, 799, 800, 804, 805, 806, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 825, 826, 827, 828, 837, 839, 840, 841, 845, 846, 851, 852, 853, 854, 857, 858, 803};
    public static final char[] MID_CHARS = {789, 795, 832, 833, 856, 801, 802, 807, 808, 820, 821, 822, 847, 860, 861, 862, 863, 864, 866, 824, 823, 865, 1161};
    public static final char[] UP_CHARS = {781, 782, 772, 773, 831, 785, 774, 784, 850, 855, 849, 775, 776, 778, 834, 835, 836, 842, 843, 844, 771, 770, 780, 848, 768, 769, 779, 783, 786, 787, 788, 829, 777, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 830, 859, 838, 794};

    private static boolean isZalgo(char c) {
        for (char c2 : UP_CHARS) {
            if (c == c2) {
                return true;
            }
        }
        for (char c3 : DOWN_CHARS) {
            if (c == c3) {
                return true;
            }
        }
        for (char c4 : MID_CHARS) {
            if (c == c4) {
                return true;
            }
        }
        return false;
    }

    public static String generate(String str, int i, int i2, int i3) {
        StringBuilder sb = new StringBuilder();
        Random random = new Random(System.currentTimeMillis());
        for (int i4 = 0; i4 < str.length(); i4++) {
            if (!isZalgo(str.charAt(i4))) {
                sb.append(str.charAt(i4));
                int nextInt = i > 0 ? random.nextInt(i) : 0;
                int nextInt2 = i3 > 0 ? random.nextInt(i3) : 0;
                int nextInt3 = i2 > 0 ? random.nextInt(i2) : 0;
                for (int i5 = 0; i5 < nextInt; i5++) {
                    char[] cArr = UP_CHARS;
                    sb.append(cArr[random.nextInt(cArr.length)]);
                }
                for (int i6 = 0; i6 < nextInt2; i6++) {
                    char[] cArr2 = DOWN_CHARS;
                    sb.append(cArr2[random.nextInt(cArr2.length)]);
                }
                for (int i7 = 0; i7 < nextInt3; i7++) {
                    char[] cArr3 = MID_CHARS;
                    sb.append(cArr3[random.nextInt(cArr3.length)]);
                }
            }
        }
        return sb.toString();
    }

    public static String generate(String str) {
        return generate(str, 16, 6, 16);
    }
}