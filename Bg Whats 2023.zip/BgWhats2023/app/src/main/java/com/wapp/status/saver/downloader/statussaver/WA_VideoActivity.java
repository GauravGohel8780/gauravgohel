package com.wapp.status.saver.downloader.statussaver;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import com.sk.SDKX.BackInterHelper;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.statussaver.fragments.Utils;


public class WA_VideoActivity extends AppCompatActivity implements View.OnClickListener {
    ImageView backIV;
    VideoView displayVV;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_video_preview);
        bind();
    }

    private void bind() {
        backIV = findViewById(R.id.backIV);
        backIV.setOnClickListener(this);
        displayVV = findViewById(R.id.displayVV);
        displayVV.setVideoPath(Utils.mPath);
        MediaController mediaController = new MediaController(this);
        mediaController.setAnchorView(this.displayVV);
        displayVV.setMediaController(mediaController);
        displayVV.start();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.backIV:
                onBackPressed();
                break;
        }
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public void onResume() {
        super.onResume();
        this.displayVV.setVideoPath(Utils.mPath);
        this.displayVV.start();
    }

        @Override
    public void onBackPressed() {
        super.onBackPressed();
        new BackInterHelper().ShowIntertistialAds(WA_VideoActivity.this, new BackInterHelper.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onBack();
            }
        });
    }

    private void onBack() {
        super.onBackPressed();
    }


}
