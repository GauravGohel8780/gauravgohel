package com.wapp.status.saver.downloader.fontstyle.utils;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class Copy_han {
    private Context context;

    public Copy_han(Context context2) {
        this.context = context2;
    }

    public void copy(String str) {
        if (str.isEmpty()) {
            Toast.makeText(this.context, "Enter some text", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager clipboardManager = (ClipboardManager) this.context.getSystemService("clipboard");
        Context context2 = this.context;
        Toast.makeText(context2, ((Object) "Copied to clipboard! Your copied text is ") + str, Toast.LENGTH_SHORT).show();
        ClipData newPlainText = ClipData.newPlainText("simple text", str);
        if (clipboardManager != null) {
            clipboardManager.setPrimaryClip(newPlainText);
        }
    }

    public void Share(String str) {
        if (str.isEmpty()) {
            Toast.makeText(this.context, "Enter some text", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("text/plain");
            intent.putExtra("android.intent.extra.TEXT", str);
            this.context.startActivity(Intent.createChooser(intent, "choose one"));
        } catch (Exception unused) {
        }
    }

    public void copysi(String str) {
        if (str.isEmpty()) {
            Toast.makeText(this.context, "Enter some text", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager clipboardManager = (ClipboardManager) this.context.getSystemService("clipboard");
        Toast.makeText(this.context, "Copied to clipboard!", Toast.LENGTH_SHORT).show();
        ClipData newPlainText = ClipData.newPlainText("simple text", str);
        if (clipboardManager != null) {
            clipboardManager.setPrimaryClip(newPlainText);
        }
    }
}