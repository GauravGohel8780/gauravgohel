package com.wapp.status.saver.downloader.fontstyle.adpater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.interfaces.RecyclerViewItem;


public class Style_adpapter extends RecyclerView.Adapter<Style_adpapter.StylersViewHolder> {
    Context context;
    RecyclerViewItem recyclerViewItem;
    String[] s;
    int type = 0;

    public Style_adpapter(Context context2, int i, String[] strArr, RecyclerViewItem recyclerViewItem2) {
        this.context = context2;
        this.type = i;
        this.s = strArr;
        this.recyclerViewItem = recyclerViewItem2;
    }

    @Override
    public StylersViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new StylersViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.sheet_itm, viewGroup, false));
    }

    public void onBindViewHolder(final StylersViewHolder stylersViewHolder, final int i) {
        stylersViewHolder.txt_content.setText(this.s[i]);
        stylersViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Style_adpapter.this.recyclerViewItem.onItemClick(stylersViewHolder.getAdapterPosition(), Style_adpapter.this.s[i]);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.s.length;
    }

    public static class StylersViewHolder extends RecyclerView.ViewHolder {
        View itemView;
        public TextView txt_content;

        public StylersViewHolder(View view) {
            super(view);
            this.txt_content = (TextView) view.findViewById(R.id.csf_sym_12);
            this.itemView = view;
        }
    }
}