package com.wapp.status.saver.downloader.statussaver;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.sk.SDKX.BackInterHelper;
import com.sk.SDKX.BannerHelper;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.statussaver.fragments.WA_RecentWapp;
import com.wapp.status.saver.downloader.statussaver.fragments.WA_RecentWappBus;

import java.util.ArrayList;
import java.util.List;


public class WA_RecStatusActivity extends AppCompatActivity implements View.OnClickListener {
    ImageView backIV;
    TabLayout tabLayout;
    TextView topTV;
    ViewPager viewPager;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_recent_status);
          new BannerHelper().ShowBannerAds(this, (ViewGroup) findViewById(R.id.banner));
        bind();
    }

    private void bind() {
        backIV = findViewById(R.id.backIV);
        backIV.setOnClickListener(this);
        topTV = findViewById(R.id.topTV);
        viewPager = findViewById(R.id.pagerdiet);
        setupViewPager(viewPager);
        tabLayout = findViewById(R.id.tab_layoutdiet);
        tabLayout.setupWithViewPager(this.viewPager);
        setupTabIcons();
        tabLayout.addOnTabSelectedListener((TabLayout.OnTabSelectedListener) new TabLayout.OnTabSelectedListener() {
            public void onTabReselected(TabLayout.Tab tab) {
            }

            public void onTabUnselected(TabLayout.Tab tab) {
            }

            public void onTabSelected(TabLayout.Tab tab) {
            }
        });
    }

    private void setupTabIcons() {
        TextView textView = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, (ViewGroup) null);
        textView.setText("Whatsapp");
        this.tabLayout.getTabAt(0).setCustomView((View) textView);
        TextView textView2 = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, (ViewGroup) null);
        textView2.setText("WA Business");
        this.tabLayout.getTabAt(1).setCustomView((View) textView2);
    }

    private void setupViewPager(ViewPager viewPager2) {
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        viewPagerAdapter.addFragment(new WA_RecentWapp(), "Whatsapp");
        viewPagerAdapter.addFragment(new WA_RecentWappBus(), "WA Business");
        viewPager2.setAdapter(viewPagerAdapter);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.backIV:
                onBackPressed();
                break;
        }
    }

    static class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList();
        private final List<String> mFragmentTitleList = new ArrayList();

        public ViewPagerAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        public Fragment getItem(int i) {
            return this.mFragmentList.get(i);
        }

        public int getCount() {
            return this.mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String str) {
            this.mFragmentList.add(fragment);
            this.mFragmentTitleList.add(str);
        }

        public CharSequence getPageTitle(int i) {
            return this.mFragmentTitleList.get(i);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        new BackInterHelper().ShowIntertistialAds(WA_RecStatusActivity.this, new BackInterHelper.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onBack();
            }
        });
    }

    private void onBack() {
        super.onBackPressed();
    }
}
