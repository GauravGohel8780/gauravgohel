package com.wapp.status.saver.downloader.fontstyle.model;

public class Emot {
    private int id;
    private String name;

    public Emot() {
    }

    public Emot(int i, String str) {
        this.id = i;
        this.name = str;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int i) {
        this.id = i;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public int hashCode() {
        return this.id + 31;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return obj != null && getClass() == obj.getClass() && this.id == ((Emot) obj).id;
    }

    public String toString() {
        return "Product [id=" + this.id + ", name=" + this.name + "]";
    }
}