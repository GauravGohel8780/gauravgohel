package com.wapp.status.saver.downloader.fontstyle.interfaces;

public interface RecyclerViewItem {
    void onItemClick(int i, String str);
}