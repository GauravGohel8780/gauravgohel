package com.wapp.status.saver.downloader.fontstyle.model;

import com.wapp.status.saver.downloader.fontstyle.interfaces.Style;

public class Rht_eff implements Style {
    private String character;

    public Rht_eff(String str) {
        this.character = str;
    }

    @Override
    public String generate(String str) {
        try {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < str.length(); i++) {
                if (str.charAt(i) == ' ') {
                    sb.append(" ");
                } else {
                    sb.append(str.charAt(i));
                    sb.append(this.character);
                }
            }
            return sb.toString();
        } catch (OutOfMemoryError unused) {
            return "";
        }
    }

    public int hashCode() {
        return this.character.hashCode();
    }
}