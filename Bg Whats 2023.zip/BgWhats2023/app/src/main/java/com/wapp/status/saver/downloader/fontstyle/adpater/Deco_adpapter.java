package com.wapp.status.saver.downloader.fontstyle.adpater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.model.Font;
import com.wapp.status.saver.downloader.fontstyle.utils.Bottom_sheet;
import com.wapp.status.saver.downloader.fontstyle.utils.Copy_han;

import java.util.ArrayList;


public class Deco_adpapter extends RecyclerView.Adapter<Deco_adpapter.MyViewHolder> {
    private final Context activity;
    private final ArrayList<Font> csf_fonts;

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.deco_act, viewGroup, false));
    }

    public Deco_adpapter(ArrayList<Font> arrayList, Context context) {
        this.csf_fonts = arrayList;
        this.activity = context;
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {
        Font font = this.csf_fonts.get(i);
        myViewHolder.title.setText(font.getFontName());
        StringBuilder sb = new StringBuilder(font.getPreviewText());
        switch (i) {
            case 0:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("★·.·´¯`·.·★")) {
                        sb.insert(0, "★·.·´¯`·.·★");
                        sb.insert(sb.length(), "★·.·´¯`·.·★");
                        break;
                    }
                } else {
                    sb.insert(0, "★·.·´¯`·.·★");
                    sb.insert(sb.length(), "★·.·´¯`·.·★");
                    break;
                }
                break;
            case 1:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("✦͙͙͙*͙*❥⃝∗⁎.ʚ")) {
                        sb.insert(0, "✦͙͙͙*͙*❥⃝∗⁎.ʚ");
                        sb.insert(sb.length(), "ɞ.⁎∗❥⃝**͙✦͙͙͙");
                        break;
                    }
                } else {
                    sb.insert(0, "✦͙͙͙*͙*❥⃝∗⁎.ʚ");
                    sb.insert(sb.length(), "ɞ.⁎∗❥⃝**͙✦͙͙͙");
                    break;
                }
                break;
            case 2:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("█ ▇ ▆ ▅ ▄ ▂ ▁")) {
                        sb.insert(0, "▁ ▂ ▄ ▅ ▆ ▇ █");
                        sb.insert(sb.length(), "█ ▇ ▆ ▅ ▄ ▂ ▁");
                        break;
                    }
                } else {
                    sb.insert(0, "▁ ▂ ▄ ▅ ▆ ▇ █ ");
                    sb.insert(sb.length(), "█ ▇ ▆ ▅ ▄ ▂ ▁");
                    break;
                }
                break;
            case 3:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("¸¸♬·¯·♩¸¸♪·¯·♫¸¸")) {
                        sb.insert(0, "¸¸♬·¯·♩¸¸♪·¯·♫¸¸");
                        sb.insert(sb.length(), "¸¸♫·¯·♪¸¸♩·¯·♬¸¸");
                        break;
                    }
                } else {
                    sb.insert(0, "¸¸♬·¯·♩¸¸♪·¯·♫¸¸");
                    sb.insert(sb.length(), "¸¸♫·¯·♪¸¸♩·¯·♬¸¸");
                    break;
                }
                break;
            case 4:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("{♥‿♥}")) {
                        sb.insert(0, "{♥‿♥}");
                        sb.insert(sb.length(), "{♥‿♥}");
                        break;
                    }
                } else {
                    sb.insert(0, "{♥‿♥}");
                    sb.insert(sb.length(), "{♥‿♥}");
                    break;
                }
                break;
            case 5:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("✿◕ ‿ ◕✿")) {
                        sb.insert(0, "✿◕ ‿ ◕✿");
                        sb.insert(sb.length(), "✿◕ ‿ ◕✿");
                        break;
                    }
                } else {
                    sb.insert(0, "✿◕ ‿ ◕✿");
                    sb.insert(sb.length(), "✿◕ ‿ ◕✿");
                    break;
                }
                break;
            case 6:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("웃❤유")) {
                        sb.insert(0, "웃❤유");
                        sb.insert(sb.length(), "유❤웃");
                        break;
                    }
                } else {
                    sb.insert(0, "웃❤유");
                    sb.insert(sb.length(), "유❤웃");
                    break;
                }
                break;
            case 7:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("✿.｡.:* ☆:**:.")) {
                        sb.insert(0, "✿.｡.:* ☆:**:.");
                        sb.insert(sb.length(), ".:**:.☆*.:｡.✿");
                        break;
                    }
                } else {
                    sb.insert(0, "✿.｡.:* ☆:**:.");
                    sb.insert(sb.length(), ".:**:.☆*.:｡.✿");
                    break;
                }
                break;
            case 8:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("¤¸¸.•´¯`•¸¸.•..>>")) {
                        sb.insert(0, "¤¸¸.•´¯`•¸¸.•..>>");
                        sb.insert(sb.length(), "<<..•.¸¸•´¯`•.¸¸¤");
                        break;
                    }
                } else {
                    sb.insert(0, "¤¸¸.•´¯`•¸¸.•..>>");
                    sb.insert(sb.length(), "<<..•.¸¸•´¯`•.¸¸¤");
                    break;
                }
                break;
            case 9:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("◦•●◉✿")) {
                        sb.insert(0, "◦•●◉✿");
                        sb.insert(sb.length(), "✿◉●•◦");
                        break;
                    }
                } else {
                    sb.insert(0, "◦•●◉✿");
                    sb.insert(sb.length(), "✿◉●•◦");
                    break;
                }
                break;
            case 10:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("▀▄▀▄▀▄")) {
                        sb.insert(0, "▀▄▀▄▀▄");
                        sb.insert(sb.length(), "▄▀▄▀▄▀");
                        break;
                    }
                } else {
                    sb.insert(0, "▀▄▀▄▀▄");
                    sb.insert(sb.length(), "▄▀▄▀▄▀");
                    break;
                }
                break;
            case 11:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains(".•°¤*(¯`★´¯)*¤°")) {
                        sb.insert(0, ".•°¤*(¯`★´¯)*¤°");
                        sb.insert(sb.length(), "°¤*(¯´★`¯)*¤°•.");
                        break;
                    }
                } else {
                    sb.insert(0, ".•°¤*(¯`★´¯)*¤°");
                    sb.insert(sb.length(), "°¤*(¯´★`¯)*¤°•.");
                    break;
                }
                break;
            case 12:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("☆(❁‿❁)☆")) {
                        sb.insert(0, "☆(❁‿❁)☆");
                        sb.insert(sb.length(), "☆(❁‿❁)☆");
                        break;
                    }
                } else {
                    sb.insert(0, "☆(❁‿❁)☆");
                    sb.insert(sb.length(), "☆(❁‿❁)☆");
                    break;
                }
                break;
            case 13:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("ღ(¯`◕‿◕´¯) ♫ ♪ ♫")) {
                        sb.insert(0, "ღ(¯`◕‿◕´¯) ♫ ♪ ♫");
                        sb.insert(sb.length(), "♫ ♪ ♫ (¯`◕‿◕´¯)ღ");
                        break;
                    }
                } else {
                    sb.insert(0, "ღ(¯`◕‿◕´¯) ♫ ♪ ♫");
                    sb.insert(sb.length(), "♫ ♪ ♫ (¯`◕‿◕´¯)ღ");
                    break;
                }
                break;
            case 14:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("«-(¯`v´¯)-«")) {
                        sb.insert(0, "«-(¯`v´¯)-«");
                        sb.insert(sb.length(), "»-(¯`v´¯)-»");
                        break;
                    }
                } else {
                    sb.insert(0, "«-(¯`v´¯)-«");
                    sb.insert(sb.length(), "»-(¯`v´¯)-»");
                    break;
                }
                break;
            case 15:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("=。:.ﾟ(●ö◡ö●):.｡+ﾟ")) {
                        sb.insert(0, "=。:.ﾟ(●ö◡ö●):.｡+ﾟ");
                        sb.insert(sb.length(), "=。:.ﾟ(●ö◡ö●):.｡+ﾟ");
                        break;
                    }
                } else {
                    sb.insert(0, "=。:.ﾟ(●ö◡ö●):.｡+ﾟ");
                    sb.insert(sb.length(), "=。:.ﾟ(●ö◡ö●):.｡+ﾟ");
                    break;
                }
                break;
            case 16:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("❤(｡◕‿◕｡)❤")) {
                        sb.insert(0, "❤(｡◕‿◕｡)❤");
                        sb.insert(sb.length(), "❤(｡◕‿◕｡)❤");
                        break;
                    }
                } else {
                    sb.insert(0, "❤(｡◕‿◕｡)❤");
                    sb.insert(sb.length(), "❤(｡◕‿◕｡)❤");
                    break;
                }
                break;
            case 17:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("ლ❣☆(❁‿❁)")) {
                        sb.insert(0, "ლ❣☆(❁‿❁)");
                        sb.insert(sb.length(), "(❁‿❁)☆❣ლ");
                        break;
                    }
                } else {
                    sb.insert(0, "ლ❣☆(❁‿❁)");
                    sb.insert(sb.length(), "(❁‿❁)☆❣ლ");
                    break;
                }
                break;
            case 18:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("๑۞๑,¸¸,ø¤º°`°๑۩")) {
                        sb.insert(0, "๑۞๑,¸¸,ø¤º°`°๑۩");
                        sb.insert(sb.length(), "๑۩ ,¸¸,ø¤º°`°๑۞๑");
                        break;
                    }
                } else {
                    sb.insert(0, "๑۞๑,¸¸,ø¤º°`°๑۩");
                    sb.insert(sb.length(), "๑۩ ,¸¸,ø¤º°`°๑۞๑");
                    break;
                }
                break;
            case 19:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("*:;,．★ ～☆・:.,;*")) {
                        sb.insert(0, "*:;,．★ ～☆・:.,;*");
                        sb.insert(sb.length(), "*:;,．☆ ～★・:.,;*");
                        break;
                    }
                } else {
                    sb.insert(0, "*:;,．★ ～☆・:.,;*");
                    sb.insert(sb.length(), "*:;,．☆ ～★・:.,;*");
                    break;
                }
                break;
            case 20:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("╚»★«╝")) {
                        sb.insert(0, "╚»★«╝");
                        sb.insert(sb.length(), "╚»★«╝");
                        break;
                    }
                } else {
                    sb.insert(0, "╚»★«╝");
                    sb.insert(sb.length(), "╚»★«╝");
                    break;
                }
                break;
            case 21:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("➶➶➶➶➶")) {
                        sb.insert(0, "➶➶➶➶➶");
                        sb.insert(sb.length(), "➷➷➷➷➷");
                        break;
                    }
                } else {
                    sb.insert(0, "➶➶➶➶➶");
                    sb.insert(sb.length(), "➷➷➷➷➷");
                    break;
                }
                break;
            case 22:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("(｡◕‿‿◕｡)")) {
                        sb.insert(0, "(｡◕‿‿◕｡)");
                        sb.insert(sb.length(), "(｡◕‿‿◕｡)");
                        break;
                    }
                } else {
                    sb.insert(0, "(｡◕‿‿◕｡)");
                    sb.insert(sb.length(), "(｡◕‿‿◕｡)");
                    break;
                }
                break;
            case 23:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("`•.¸¸.•´´¯`••._.•")) {
                        sb.insert(0, "`•.¸¸.•´´¯`••._.•");
                        sb.insert(sb.length(), "•._.••`¯´´•.¸¸.•`");
                        break;
                    }
                } else {
                    sb.insert(0, "`•.¸¸.•´´¯`••._.•");
                    sb.insert(sb.length(), "•._.••`¯´´•.¸¸.•`");
                    break;
                }
                break;
            case 24:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("☮▁▂▃▄☾ ♛")) {
                        sb.insert(0, "☮▁▂▃▄☾ ♛");
                        sb.insert(sb.length(), "♛ ☽▄▃▂▁☮");
                        break;
                    }
                } else {
                    sb.insert(0, "☮▁▂▃▄☾ ♛");
                    sb.insert(sb.length(), "♛ ☽▄▃▂▁☮");
                    break;
                }
                break;
            case 25:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("¸,ø¤º°`°º¤ø,¸¸,ø¤º°")) {
                        sb.insert(0, "¸,ø¤º°`°º¤ø,¸¸,ø¤º°");
                        sb.insert(sb.length(), "°º¤ø,¸¸,ø¤º°`°º¤ø,¸");
                        break;
                    }
                } else {
                    sb.insert(0, "¸,ø¤º°`°º¤ø,¸¸,ø¤º°");
                    sb.insert(sb.length(), "°º¤ø,¸¸,ø¤º°`°º¤ø,¸");
                    break;
                }
                break;
            case 26:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("╰☆☆")) {
                        sb.insert(0, "╰☆☆");
                        sb.insert(sb.length(), "☆☆╮");
                        break;
                    }
                } else {
                    sb.insert(0, "╰☆☆");
                    sb.insert(sb.length(), "☆☆╮");
                    break;
                }
                break;
            case 27:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("]|I{•------»")) {
                        sb.insert(0, "]|I{•------»");
                        sb.insert(sb.length(), "«------•}I|[");
                        break;
                    }
                } else {
                    sb.insert(0, "]|I{•------»");
                    sb.insert(sb.length(), "«------•}I|[");
                    break;
                }
                break;
            case 28:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("(ღ˘⌣˘ღ)")) {
                        sb.insert(0, "(ღ˘⌣˘ღ)");
                        sb.insert(sb.length(), "(ღ˘⌣˘ღ)");
                        break;
                    }
                } else {
                    sb.insert(0, "(ღ˘⌣˘ღ)");
                    sb.insert(sb.length(), "(ღ˘⌣˘ღ)");
                    break;
                }
                break;
            case 29:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("(¯`·.¸¸.·´¯`·.¸¸.->")) {
                        sb.insert(0, "(¯`·.¸¸.·´¯`·.¸¸.->");
                        sb.insert(sb.length(), "<-.¸¸.·´¯`·.¸¸.·´¯)");
                        break;
                    }
                } else {
                    sb.insert(0, "(¯`·.¸¸.·´¯`·.¸¸.->");
                    sb.insert(sb.length(), "<-.¸¸.·´¯`·.¸¸.·´¯)");
                    break;
                }
                break;
            case 30:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("↤↤❤↤↤")) {
                        sb.insert(0, "↤↤❤↤↤");
                        sb.insert(sb.length(), "↦↦❤↦↦");
                        break;
                    }
                } else {
                    sb.insert(0, "↤↤❤↤↤");
                    sb.insert(sb.length(), "↦↦❤↦↦");
                    break;
                }
                break;
            case 31:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("↫↫↫↫↫")) {
                        sb.insert(0, "↫↫↫↫↫");
                        sb.insert(sb.length(), "↬↬↬↬↬");
                        break;
                    }
                } else {
                    sb.insert(0, "↫↫↫↫↫");
                    sb.insert(sb.length(), "↬↬↬↬↬");
                    break;
                }
                break;
            case 32:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("【｡_｡】")) {
                        sb.insert(0, "【｡_｡】");
                        sb.insert(sb.length(), "【｡_｡】");
                        break;
                    }
                } else {
                    sb.insert(0, "【｡_｡】");
                    sb.insert(sb.length(), "【｡_｡】");
                    break;
                }
                break;
            case 33:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("░▒▓█►─═")) {
                        sb.insert(0, "░▒▓█►─═");
                        sb.insert(sb.length(), "═─◄█▓▒░");
                        break;
                    }
                } else {
                    sb.insert(0, "░▒▓█►─═");
                    sb.insert(sb.length(), "═─◄█▓▒░");
                    break;
                }
                break;
            case 34:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("|!¤*'~``~'*¤!|")) {
                        sb.insert(0, "|!¤*'~``~'*¤!|");
                        sb.insert(sb.length(), "|!¤*'~``~'*¤!|");
                        break;
                    }
                } else {
                    sb.insert(0, "|!¤*'~``~'*¤!|");
                    sb.insert(sb.length(), "|!¤*'~``~'*¤!|");
                    break;
                }
                break;
            case 35:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("._|.<(+_+)>.|_.")) {
                        sb.insert(0, "._|.<(+_+)>.|_.");
                        sb.insert(sb.length(), "._|.<(+_+)>.|_.");
                        break;
                    }
                } else {
                    sb.insert(0, "._|.<(+_+)>.|_.");
                    sb.insert(sb.length(), "._|.<(+_+)>.|_.");
                    break;
                }
                break;
            case 36:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("❤(❁´◡`❁)❤")) {
                        sb.insert(0, "❤(❁´◡`❁)❤");
                        sb.insert(sb.length(), "❤(❁´◡`❁)❤");
                        break;
                    }
                } else {
                    sb.insert(0, "❤(❁´◡`❁)❤");
                    sb.insert(sb.length(), "❤(❁´◡`❁)❤");
                    break;
                }
                break;
            case 37:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("-漫~*'¨¯¨'*·舞~")) {
                        sb.insert(0, "-漫~*'¨¯¨'*·舞~");
                        sb.insert(sb.length(), "~舞*'¨¯¨'*·~漫-");
                        break;
                    }
                } else {
                    sb.insert(0, "-漫~*'¨¯¨'*·舞~");
                    sb.insert(sb.length(), "~舞*'¨¯¨'*·~漫-");
                    break;
                }
                break;
            case 38:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains(".•°¤*(¯`★´¯)*¤°")) {
                        sb.insert(0, ".•°¤*(¯`★´¯)*¤°");
                        sb.insert(sb.length(), "°¤*(¯´★`¯)*¤°•.");
                        break;
                    }
                } else {
                    sb.insert(0, ".•°¤*(¯`★´¯)*¤°");
                    sb.insert(sb.length(), "°¤*(¯´★`¯)*¤°•.");
                    break;
                }
                break;
            case 39:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("⊂◉‿◉つ")) {
                        sb.insert(0, "⊂◉‿◉つ");
                        sb.insert(sb.length(), "⊂◉‿◉つ");
                        break;
                    }
                } else {
                    sb.insert(0, "⊂◉‿◉つ");
                    sb.insert(sb.length(), "⊂◉‿◉つ");
                    break;
                }
                break;
            case 40:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("●▬▬▬▬๑۩")) {
                        sb.insert(0, "●▬▬▬▬๑۩");
                        sb.insert(sb.length(), "۩๑▬▬▬▬▬●");
                        break;
                    }
                } else {
                    sb.insert(0, "●▬▬▬▬๑۩");
                    sb.insert(sb.length(), "۩๑▬▬▬▬▬●");
                    break;
                }
                break;
            case 41:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("╚═| ~ ಠ ₒ ಠ ~ |═╝")) {
                        sb.insert(0, "╚═| ~ ಠ ₒ ಠ ~ |═╝");
                        sb.insert(sb.length(), "╚═| ~ ಠ ₒ ಠ ~ |═╝");
                        break;
                    }
                } else {
                    sb.insert(0, "╚═| ~ ಠ ₒ ಠ ~ |═╝");
                    sb.insert(sb.length(), "╚═| ~ ಠ ₒ ಠ ~ |═╝");
                    break;
                }
                break;
            case 42:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("✿◡‿◡")) {
                        sb.insert(0, "✿◡‿◡");
                        sb.insert(sb.length(), "◡‿◡✿");
                        break;
                    }
                } else {
                    sb.insert(0, "✿◡‿◡");
                    sb.insert(sb.length(), "◡‿◡✿");
                    break;
                }
                break;
            case 43:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("<(▰˘◡˘▰)>")) {
                        sb.insert(0, "<(▰˘◡˘▰)>");
                        sb.insert(sb.length(), "<(▰˘◡˘▰)>");
                        break;
                    }
                } else {
                    sb.insert(0, "<(▰˘◡˘▰)>");
                    sb.insert(sb.length(), "<(▰˘◡˘▰)>");
                    break;
                }
                break;
            case 44:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("ლ༼ ▀̿ Ĺ̯ ▀̿ ლ༽")) {
                        sb.insert(0, "ლ༼ ▀̿ Ĺ̯ ▀̿ ლ༽");
                        sb.insert(sb.length(), "ლ༼ ▀̿ Ĺ̯ ▀̿ ლ༽");
                        break;
                    }
                } else {
                    sb.insert(0, "ლ༼ ▀̿ Ĺ̯ ▀̿ ლ༽");
                    sb.insert(sb.length(), "ლ༼ ▀̿ Ĺ̯ ▀̿ ლ༽");
                    break;
                }
                break;
            case 45:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("乁། ˵ ◕ – ◕ ˵ །ㄏ")) {
                        sb.insert(0, "乁། ˵ ◕ – ◕ ˵ །ㄏ");
                        sb.insert(sb.length(), "乁། ˵ ◕ – ◕ ˵ །ㄏ");
                        break;
                    }
                } else {
                    sb.insert(0, "乁། ˵ ◕ – ◕ ˵ །ㄏ");
                    sb.insert(sb.length(), "乁། ˵ ◕ – ◕ ˵ །ㄏ");
                    break;
                }
                break;
            case 46:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("❤☆(◒‿◒)☆❤")) {
                        sb.insert(0, "❤☆(◒‿◒)☆❤");
                        sb.insert(sb.length(), "❤☆(◒‿◒)☆❤");
                        break;
                    }
                } else {
                    sb.insert(0, "❤☆(◒‿◒)☆❤");
                    sb.insert(sb.length(), "❤☆(◒‿◒)☆❤");
                    break;
                }
                break;
            case 47:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("╰། ◉ ◯ ◉ །╯")) {
                        sb.insert(0, "╰། ◉ ◯ ◉ །╯");
                        sb.insert(sb.length(), "╰། ◉ ◯ ◉ །╯");
                        break;
                    }
                } else {
                    sb.insert(0, "╰། ◉ ◯ ◉ །╯");
                    sb.insert(sb.length(), "╰། ◉ ◯ ◉ །╯");
                    break;
                }
                break;
            case 48:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("⋋⁞ ◔ ﹏ ◔ ⁞⋌")) {
                        sb.insert(0, "⋋⁞ ◔ ﹏ ◔ ⁞⋌");
                        sb.insert(sb.length(), "⋋⁞ ◔ ﹏ ◔ ⁞⋌");
                        break;
                    }
                } else {
                    sb.insert(0, "⋋⁞ ◔ ﹏ ◔ ⁞⋌");
                    sb.insert(sb.length(), "⋋⁞ ◔ ﹏ ◔ ⁞⋌");
                    break;
                }
                break;
            case 49:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("ᕕ༼✪ل͜✪༽ᕗ")) {
                        sb.insert(0, "ᕕ༼✪ل͜✪༽ᕗ");
                        sb.insert(sb.length(), "ᕗ༼✪ل͜✪༽ᕕ");
                        break;
                    }
                } else {
                    sb.insert(0, "ᕕ༼✪ل͜✪༽ᕗ");
                    sb.insert(sb.length(), "ᕗ༼✪ل͜✪༽ᕕ");
                    break;
                }
                break;
            case 50:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("(Ɔ ˘⌣˘)♥")) {
                        sb.insert(0, "(Ɔ ˘⌣˘)♥");
                        sb.insert(sb.length(), "♥(˘⌣˘ C)");
                        break;
                    }
                } else {
                    sb.insert(0, "(Ɔ ˘⌣˘)♥");
                    sb.insert(sb.length(), "♥(˘⌣˘ C)");
                    break;
                }
                break;
            case 51:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("*•.¸♡")) {
                        sb.insert(0, "*•.¸♡");
                        sb.insert(sb.length(), "♡¸.•*");
                        break;
                    }
                } else {
                    sb.insert(0, "*•.¸♡");
                    sb.insert(sb.length(), "♡¸.•*");
                    break;
                }
                break;
            case 52:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("(❁´◡`❁)")) {
                        sb.insert(0, "(❁´◡`❁)");
                        sb.insert(sb.length(), "(❁´◡`❁)");
                        break;
                    }
                } else {
                    sb.insert(0, "(❁´◡`❁)");
                    sb.insert(sb.length(), "(❁´◡`❁)");
                    break;
                }
                break;
            case 53:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("☜♡☞")) {
                        sb.insert(0, "☜♡☞");
                        sb.insert(sb.length(), "☜♡☞");
                        break;
                    }
                } else {
                    sb.insert(0, "☜♡☞");
                    sb.insert(sb.length(), "☜♡☞");
                    break;
                }
                break;
            case 54:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("-`ღ´--`ღ´-")) {
                        sb.insert(0, "-`ღ´--`ღ´-");
                        sb.insert(sb.length(), "-`ღ´--`ღ´-");
                        break;
                    }
                } else {
                    sb.insert(0, "-`ღ´--`ღ´-");
                    sb.insert(sb.length(), "-`ღ´--`ღ´-");
                    break;
                }
                break;
            case 55:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("♡＾▽＾♡")) {
                        sb.insert(0, "♡＾▽＾♡");
                        sb.insert(sb.length(), "♡＾▽＾♡");
                        break;
                    }
                } else {
                    sb.insert(0, "♡＾▽＾♡");
                    sb.insert(sb.length(), "♡＾▽＾♡");
                    break;
                }
                break;
            case 56:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("(。♡‿♡。)")) {
                        sb.insert(0, "(。♡‿♡。)");
                        sb.insert(sb.length(), "(。♡‿♡。)");
                        break;
                    }
                } else {
                    sb.insert(0, "(。♡‿♡。)");
                    sb.insert(sb.length(), "(。♡‿♡。)");
                    break;
                }
                break;
            case 57:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("♥‿♥")) {
                        sb.insert(0, "♥‿♥");
                        sb.insert(sb.length(), "♥‿♥");
                        break;
                    }
                } else {
                    sb.insert(0, "♥‿♥");
                    sb.insert(sb.length(), "♥‿♥");
                    break;
                }
                break;
            case 58:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("♥╣[-_-]╠♥")) {
                        sb.insert(0, "♥╣[-_-]╠♥");
                        sb.insert(sb.length(), "♥╣[-_-]╠♥");
                        break;
                    }
                } else {
                    sb.insert(0, "♥╣[-_-]╠♥");
                    sb.insert(sb.length(), "♥╣[-_-]╠♥");
                    break;
                }
                break;
            case 59:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("(✿◠‿◠✿)")) {
                        sb.insert(0, "(✿◠‿◠✿)");
                        sb.insert(sb.length(), "(✿◠‿◠✿)");
                        break;
                    }
                } else {
                    sb.insert(0, "(✿◠‿◠✿)");
                    sb.insert(sb.length(), "(✿◠‿◠✿)");
                    break;
                }
                break;
            case 60:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("❣♥(｡◕‿◕｡)♥❣")) {
                        sb.insert(0, "❣♥(｡◕‿◕｡)♥❣");
                        sb.insert(sb.length(), "❣♥(｡◕‿◕｡)♥❣");
                        break;
                    }
                } else {
                    sb.insert(0, "❣♥(｡◕‿◕｡)♥❣");
                    sb.insert(sb.length(), "❣♥(｡◕‿◕｡)♥❣");
                    break;
                }
                break;
            case 61:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("ლ❣☆(❁‿❁)☆❣ლ")) {
                        sb.insert(0, "ლ❣☆(❁‿❁)☆❣ლ");
                        sb.insert(sb.length(), "ლ❣☆(❁‿❁)☆❣ლ");
                        break;
                    }
                } else {
                    sb.insert(0, "ლ❣☆(❁‿❁)☆❣ლ");
                    sb.insert(sb.length(), "ლ❣☆(❁‿❁)☆❣ლ");
                    break;
                }
                break;
            case 62:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("✿❀❁(◠‿◠)❁❀✿")) {
                        sb.insert(0, "✿❀❁(◠‿◠)❁❀✿");
                        sb.insert(sb.length(), "✿❀❁(◠‿◠)❁❀✿");
                        break;
                    }
                } else {
                    sb.insert(0, "✿❀❁(◠‿◠)❁❀✿");
                    sb.insert(sb.length(), "✿❀❁(◠‿◠)❁❀✿");
                    break;
                }
                break;
            case 63:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("✌✌(•ิ‿•ิ)✌✌")) {
                        sb.insert(0, "✌✌(•ิ‿•ิ)✌✌");
                        sb.insert(sb.length(), "✌✌(•ิ‿•ิ)✌✌");
                        break;
                    }
                } else {
                    sb.insert(0, "✌✌(•ิ‿•ิ)✌✌");
                    sb.insert(sb.length(), "✌✌(•ิ‿•ิ)✌✌");
                    break;
                }
                break;
            case 64:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("❆❆≧◠‿◠≦❆❆")) {
                        sb.insert(0, "❆❆≧◠‿◠≦❆❆");
                        sb.insert(sb.length(), "❆❆≧◠‿◠≦❆❆");
                        break;
                    }
                } else {
                    sb.insert(0, "❆❆≧◠‿◠≦❆❆");
                    sb.insert(sb.length(), "❆❆≧◠‿◠≦❆❆");
                    break;
                }
                break;
            case 65:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("❤❣♥‿♥❣❤")) {
                        sb.insert(0, "❤❣♥‿♥❣❤");
                        sb.insert(sb.length(), "❤❣♥‿♥❣❤");
                        break;
                    }
                } else {
                    sb.insert(0, "❤❣♥‿♥❣❤");
                    sb.insert(sb.length(), "❤❣♥‿♥❣❤");
                    break;
                }
                break;
            case 66:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("【★】【★】")) {
                        sb.insert(0, "【★】【★】");
                        sb.insert(sb.length(), "【★】【★】");
                        break;
                    }
                } else {
                    sb.insert(0, "【★】【★】");
                    sb.insert(sb.length(), "【★】【★】");
                    break;
                }
                break;
            case 67:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("☜☆☞")) {
                        sb.insert(0, "☜☆☞");
                        sb.insert(sb.length(), "☜☆☞");
                        break;
                    }
                } else {
                    sb.insert(0, "☜☆☞");
                    sb.insert(sb.length(), "☜☆☞");
                    break;
                }
                break;
            case 68:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("●♡▬▬♡")) {
                        sb.insert(0, "●♡▬▬♡");
                        sb.insert(sb.length(), "♡▬▬♡●");
                        break;
                    }
                } else {
                    sb.insert(0, "●♡▬▬♡");
                    sb.insert(sb.length(), "♡▬▬♡●");
                    break;
                }
                break;
            case 69:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("❣❤---» [")) {
                        sb.insert(0, "❣❤---» [");
                        sb.insert(sb.length(), "] «---❤❣");
                        break;
                    }
                } else {
                    sb.insert(0, "❣❤---» [");
                    sb.insert(sb.length(), "] «---❤❣");
                    break;
                }
                break;
            case 70:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("(▰˘◡˘▰)")) {
                        sb.insert(0, "(▰˘◡˘▰)");
                        sb.insert(sb.length(), "(▰˘◡˘▰)");
                        break;
                    }
                } else {
                    sb.insert(0, "(▰˘◡˘▰)");
                    sb.insert(sb.length(), "(▰˘◡˘▰)");
                    break;
                }
                break;
            case 71:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("☀(ღ˘⌣˘ღ)☀")) {
                        sb.insert(0, "☀(ღ˘⌣˘ღ)☀");
                        sb.insert(sb.length(), "☀(ღ˘⌣˘ღ)☀");
                        break;
                    }
                } else {
                    sb.insert(0, "☀(ღ˘⌣˘ღ)☀");
                    sb.insert(sb.length(), "☀(ღ˘⌣˘ღ)☀");
                    break;
                }
                break;
            case 72:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("☀❤◕ ‿ ◕❤☀")) {
                        sb.insert(0, "☀❤◕ ‿ ◕❤☀");
                        sb.insert(sb.length(), "☀❤◕ ‿ ◕❤☀");
                        break;
                    }
                } else {
                    sb.insert(0, "☀❤◕ ‿ ◕❤☀");
                    sb.insert(sb.length(), "☀❤◕ ‿ ◕❤☀");
                    break;
                }
                break;
            case 73:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("❤╰། ◉ ◯ ◉ །╯❤")) {
                        sb.insert(0, "❤╰། ◉ ◯ ◉ །╯❤");
                        sb.insert(sb.length(), "❤╰། ◉ ◯ ◉ །╯❤");
                        break;
                    }
                } else {
                    sb.insert(0, "❤╰། ◉ ◯ ◉ །╯❤");
                    sb.insert(sb.length(), "❤╰། ◉ ◯ ◉ །╯❤");
                    break;
                }
                break;
            case 74:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("❄♥‿♥❄")) {
                        sb.insert(0, "❄♥‿♥❄");
                        sb.insert(sb.length(), "❄♥‿♥❄");
                        break;
                    }
                } else {
                    sb.insert(0, "❄♥‿♥❄");
                    sb.insert(sb.length(), "❄♥‿♥❄");
                    break;
                }
                break;
            case 75:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("☀☀｡◕‿‿◕｡☀☀")) {
                        sb.insert(0, "☀☀｡◕‿‿◕｡☀☀");
                        sb.insert(sb.length(), "☀☀｡◕‿‿◕｡☀☀");
                        break;
                    }
                } else {
                    sb.insert(0, "☀☀｡◕‿‿◕｡☀☀");
                    sb.insert(sb.length(), "☀☀｡◕‿‿◕｡☀☀");
                    break;
                }
                break;
            case 76:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("↫❣(◕ω◕)❣↬")) {
                        sb.insert(0, "↫❣(◕ω◕)❣↬");
                        sb.insert(sb.length(), "↫❣(◕ω◕)❣↬");
                        break;
                    }
                } else {
                    sb.insert(0, "↫❣(◕ω◕)❣↬");
                    sb.insert(sb.length(), "↫❣(◕ω◕)❣↬");
                    break;
                }
                break;
            case 77:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("☜☆☞(◠‿◠)")) {
                        sb.insert(0, "☜☆☞(◠‿◠)");
                        sb.insert(sb.length(), "(◠‿◠)☜☆☞");
                        break;
                    }
                } else {
                    sb.insert(0, "☜☆☞(◠‿◠)");
                    sb.insert(sb.length(), "(◠‿◠)☜☆☞");
                    break;
                }
                break;
            case 78:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("☀웃❤유☀")) {
                        sb.insert(0, "☀웃❤유☀");
                        sb.insert(sb.length(), "☀웃❤유☀");
                        break;
                    }
                } else {
                    sb.insert(0, "☀웃❤유☀");
                    sb.insert(sb.length(), "☀웃❤유☀");
                    break;
                }
                break;
            case 79:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("❤ᶫᵒᵛᵉᵧₒᵤ❤")) {
                        sb.insert(0, "❤ᶫᵒᵛᵉᵧₒᵤ❤");
                        sb.insert(sb.length(), "❤ᶫᵒᵛᵉᵧₒᵤ❤");
                        break;
                    }
                } else {
                    sb.insert(0, "❤ᶫᵒᵛᵉᵧₒᵤ❤");
                    sb.insert(sb.length(), "❤ᶫᵒᵛᵉᵧₒᵤ❤");
                    break;
                }
                break;
            case 80:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("❤ℐɕℎ ℒ℩ℯɓℯ ɗ℩ɕℎ❤")) {
                        sb.insert(0, "❤ℐɕℎ ℒ℩ℯɓℯ ɗ℩ɕℎ❤");
                        sb.insert(sb.length(), "❤ℐɕℎ ℒ℩ℯɓℯ ɗ℩ɕℎ❤");
                        break;
                    }
                } else {
                    sb.insert(0, "❤ℐɕℎ ℒ℩ℯɓℯ ɗ℩ɕℎ❤");
                    sb.insert(sb.length(), "❤ℐɕℎ ℒ℩ℯɓℯ ɗ℩ɕℎ❤");
                    break;
                }
                break;
            case 81:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("➳♥➳♥➳")) {
                        sb.insert(0, "➳♥➳♥➳");
                        sb.insert(sb.length(), "➳♥➳♥➳");
                        break;
                    }
                } else {
                    sb.insert(0, "➳♥➳♥➳");
                    sb.insert(sb.length(), "➳♥➳♥➳");
                    break;
                }
                break;
            case 82:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("✿◡‿◡✿")) {
                        sb.insert(0, "✿◡‿◡✿");
                        sb.insert(sb.length(), "✿◡‿◡✿");
                        break;
                    }
                } else {
                    sb.insert(0, "✿◡‿◡✿");
                    sb.insert(sb.length(), "✿◡‿◡✿");
                    break;
                }
                break;
            case 83:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("●▬ൠൠ▬")) {
                        sb.insert(0, "●▬ൠൠ▬");
                        sb.insert(sb.length(), "▬ൠൠ▬●");
                        break;
                    }
                } else {
                    sb.insert(0, "●▬ൠൠ▬");
                    sb.insert(sb.length(), "▬ൠൠ▬●");
                    break;
                }
                break;
            case 84:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("[̲̅ə̲̅٨̲̅٥̲̅٦̲̅]")) {
                        sb.insert(0, "[̲̅ə̲̅٨̲̅٥̲̅٦̲̅]");
                        sb.insert(sb.length(), "[̲̅ə̲̅٨̲̅٥̲̅٦̲̅]");
                        break;
                    }
                } else {
                    sb.insert(0, "[̲̅ə̲̅٨̲̅٥̲̅٦̲̅]");
                    sb.insert(sb.length(), "[̲̅ə̲̅٨̲̅٥̲̅٦̲̅]");
                    break;
                }
                break;
            case 85:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("✰(❤˘⌣˘❤)✰")) {
                        sb.insert(0, "✰(❤˘⌣˘❤)✰");
                        sb.insert(sb.length(), "✰(❤˘⌣˘❤)✰");
                        break;
                    }
                } else {
                    sb.insert(0, "✰(❤˘⌣˘❤)✰");
                    sb.insert(sb.length(), "✰(❤˘⌣˘❤)✰");
                    break;
                }
                break;
            case 86:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("❤◉◡◉❤")) {
                        sb.insert(0, "❤◉◡◉❤");
                        sb.insert(sb.length(), "❤◉◡◉❤");
                        break;
                    }
                } else {
                    sb.insert(0, "❤◉◡◉❤");
                    sb.insert(sb.length(), "❤◉◡◉❤");
                    break;
                }
                break;
            case 87:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("✬✬（⌒▽⌒）✬✬")) {
                        sb.insert(0, "✬✬（⌒▽⌒）✬✬");
                        sb.insert(sb.length(), "✬✬（⌒▽⌒）✬✬");
                        break;
                    }
                } else {
                    sb.insert(0, "✬✬（⌒▽⌒）✬✬");
                    sb.insert(sb.length(), "✬✬（⌒▽⌒）✬✬");
                    break;
                }
                break;
            case 88:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("❣⍣◕‿◕⍣❣")) {
                        sb.insert(0, "❣⍣◕‿◕⍣❣");
                        sb.insert(sb.length(), "❣⍣◕‿◕⍣❣");
                        break;
                    }
                } else {
                    sb.insert(0, "❣⍣◕‿◕⍣❣");
                    sb.insert(sb.length(), "❣⍣◕‿◕⍣❣");
                    break;
                }
                break;
            case 89:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("☀☀♡♡")) {
                        sb.insert(0, "☀☀♡♡");
                        sb.insert(sb.length(), "♡♡☀☀");
                        break;
                    }
                } else {
                    sb.insert(0, "☀☀♡♡");
                    sb.insert(sb.length(), "♡♡☀☀");
                    break;
                }
                break;
            case 90:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("ღღ(∩_∩)ღღ")) {
                        sb.insert(0, "ღღ(∩_∩)ღღ");
                        sb.insert(sb.length(), "ღღ(∩_∩)ღღ");
                        break;
                    }
                } else {
                    sb.insert(0, "ღღ(∩_∩)ღღ");
                    sb.insert(sb.length(), "ღღ(∩_∩)ღღ");
                    break;
                }
                break;
            case 91:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("☃（*^_^*）☃")) {
                        sb.insert(0, "☃（*^_^*）☃");
                        sb.insert(sb.length(), "☃（*^_^*）☃");
                        break;
                    }
                } else {
                    sb.insert(0, "☃（*^_^*）☃");
                    sb.insert(sb.length(), "☃（*^_^*）☃");
                    break;
                }
                break;
            case 92:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("✮{◕ ◡ ◕}✮")) {
                        sb.insert(0, "✮{◕ ◡ ◕}✮");
                        sb.insert(sb.length(), "✮{◕ ◡ ◕}✮");
                        break;
                    }
                } else {
                    sb.insert(0, "✮{◕ ◡ ◕}✮");
                    sb.insert(sb.length(), "✮{◕ ◡ ◕}✮");
                    break;
                }
                break;
            case 93:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("⁑☾˙❀‿❀˙☽⁑")) {
                        sb.insert(0, "⁑☾˙❀‿❀˙☽⁑");
                        sb.insert(sb.length(), "⁑☾˙❀‿❀˙☽⁑");
                        break;
                    }
                } else {
                    sb.insert(0, "⁑☾˙❀‿❀˙☽⁑");
                    sb.insert(sb.length(), "⁑☾˙❀‿❀˙☽⁑");
                    break;
                }
                break;
            case 94:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("♥♡◙‿◙♡♥")) {
                        sb.insert(0, "♥♡◙‿◙♡♥");
                        sb.insert(sb.length(), "♥♡◙‿◙♡♥");
                        break;
                    }
                } else {
                    sb.insert(0, "♥♡◙‿◙♡♥");
                    sb.insert(sb.length(), "♥♡◙‿◙♡♥");
                    break;
                }
                break;
            case 95:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("❄｡◕ ‿ ◕｡❄")) {
                        sb.insert(0, "❄｡◕ ‿ ◕｡❄");
                        sb.insert(sb.length(), "❄｡◕ ‿ ◕｡❄");
                        break;
                    }
                } else {
                    sb.insert(0, "❄｡◕ ‿ ◕｡❄");
                    sb.insert(sb.length(), "❄｡◕ ‿ ◕｡❄");
                    break;
                }
                break;
            case 96:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("❣ლʘ‿ʘლ❣")) {
                        sb.insert(0, "❣ლʘ‿ʘლ❣");
                        sb.insert(sb.length(), "❣ლʘ‿ʘლ❣");
                        break;
                    }
                } else {
                    sb.insert(0, "❣ლʘ‿ʘლ❣");
                    sb.insert(sb.length(), "❣ლʘ‿ʘლ❣");
                    break;
                }
                break;
            case 97:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("❤(●'◡'●)❤")) {
                        sb.insert(0, "❤(●'◡'●)❤");
                        sb.insert(sb.length(), "❤(●'◡'●)❤");
                        break;
                    }
                } else {
                    sb.insert(0, "❤(●'◡'●)❤");
                    sb.insert(sb.length(), "❤(●'◡'●)❤");
                    break;
                }
                break;
            case 98:
                if (!"Preview text".equals(font.getPreviewText())) {
                    if (!font.getPreviewText().contains("♪┏(°.°)┛")) {
                        sb.insert(0, "♪┏(°.°)┛");
                        sb.insert(sb.length(), "♪┏(°.°)┛");
                        break;
                    }
                } else {
                    sb.insert(0, "♪┏(°.°)┛");
                    sb.insert(sb.length(), "♪┏(°.°)┛");
                    break;
                }
                break;
        }
        font.setPreviewText(sb.toString());
        myViewHolder.csf_d.setText(font.getPreviewText());
        final Copy_han copy_han = new Copy_han(this.activity);
        final String charSequence = myViewHolder.csf_d.getText().toString();
        myViewHolder.csf_c.setOnClickListener(new View.OnClickListener() {
            /* class com.epic.chatstyle.fontstyle.AppData.adpater.Deco_adpapter.AnonymousClass1 */

            public void onClick(View view) {
                copy_han.copy(charSequence);
            }
        });
        myViewHolder.csf_im.setOnClickListener(new View.OnClickListener() {
            /* class com.epic.chatstyle.fontstyle.AppData.adpater.Deco_adpapter.AnonymousClass2 */

            public void onClick(View view) {
                copy_han.Share(charSequence);
            }
        });
        myViewHolder.csf_d.setSelected(true);
        myViewHolder.csf_sv.setOnClickListener(new View.OnClickListener() {
            /* class com.epic.chatstyle.fontstyle.AppData.adpater.Deco_adpapter.AnonymousClass3 */

            public void onClick(View view) {
                new Bottom_sheet().styleBottom(Deco_adpapter.this.activity, charSequence);
            }
        });
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.csf_fonts.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView csf_c;
        TextView csf_d;
        ImageView csf_im;
        LinearLayout csf_sv;
        TextView title;

        private MyViewHolder(View view) {
            super(view);
            this.csf_c = (ImageView) view.findViewById(R.id.csf_cpy1);
            this.csf_im = (ImageView) view.findViewById(R.id.csf_btn_shr1);
            this.title = (TextView) view.findViewById(R.id.csf_tlt_df);
            this.csf_d = (TextView) view.findViewById(R.id.csf_desc_view);
            this.csf_sv = (LinearLayout) view.findViewById(R.id.csf_coli);
        }
    }
}