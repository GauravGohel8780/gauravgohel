package com.wapp.status.saver.downloader.fontstyle.frag;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.sk.SDKX.BannerHelper;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.Activity.HomeActivity;
import com.wapp.status.saver.downloader.fontstyle.adpater.Txt_adpapter;
import com.wapp.status.saver.downloader.fontstyle.model.ListModel;
import com.wapp.status.saver.downloader.fontstyle.more.ArtsActivity;

import java.util.ArrayList;


public class Design_fragment extends Fragment {
    ImageView backBtn;
    private Activity context;

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.txt_design_frag, viewGroup, false);

        new BannerHelper().ShowBannerAds(getActivity(), (ViewGroup) inflate.findViewById(R.id.banner));

        backBtn = (ImageView) inflate.findViewById(R.id.backBtn);
        RecyclerView recyclerView = (RecyclerView) inflate.findViewById(R.id.csf_txt_sedign);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.context));
        recyclerView.setAdapter(new Txt_adpapter(getlist(), this.context));
        backBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                startActivity(new Intent(context, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                getActivity().finish();
            }
        });
        return inflate;
    }

    private ArrayList<ListModel> getlist() {
        ArrayList<ListModel> arrayList = new ArrayList<>();
        ArrayList<String> arrayList2 = new ArtsActivity().get();
        for (int i = 0; i < arrayList2.size(); i++) {
            arrayList.add(new ListModel(arrayList2.get(i)));
        }
        return arrayList;
    }

    @Override
    public void onAttach(Context context2) {
        super.onAttach(context2);
        this.context = (Activity) context2;
    }
}