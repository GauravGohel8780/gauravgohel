package com.wapp.status.saver.downloader;

public class Global {

    public static String privacy_link = "https://thezebra12.blogspot.com/2022/03/the-zebra.html";


}
