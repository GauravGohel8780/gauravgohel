package com.wapp.status.saver.downloader.fontstyle.adpater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.utils.Bottom_sheet;
import com.wapp.status.saver.downloader.fontstyle.utils.CSF_num_style;
import com.wapp.status.saver.downloader.fontstyle.utils.Copy_han;


public class Num_adpapter extends RecyclerView.Adapter<Num_adpapter.MyViewHolder> {
    private final Context context;
    private String name;
    String[][] p0;
    private final String[] p1;
    int type;
    int value;

    public Num_adpapter(Context context2, String[] strArr, String[][] strArr2, String str, int i) {
        this.context = context2;
        this.p1 = strArr;
        this.p0 = strArr2;
        this.name = str;
        this.type = i;
    }

    public void setName(String str, int i) {
        this.name = str;
        this.type = i;
        notifyDataSetChanged();
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(this, LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.num_item, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {
        int i2 = i + 1;
        myViewHolder.number.setText(String.valueOf(i2));
        this.value = i;
        final Copy_han copy_han = new Copy_han(this.context);
        if (this.name.equalsIgnoreCase(" ")) {
            myViewHolder.e1.setText(StyleMaker("0123456789".toLowerCase().toCharArray(), CSF_num_style.numberStyle[i]));
            StringBuilder sb = new StringBuilder();
            sb.append(i2);
            sb.append("");
        } else if (!this.name.isEmpty()) {
            myViewHolder.e1.setText(StyleMaker(this.name.toLowerCase().toCharArray(), CSF_num_style.numberStyle[i]));
            StringBuilder sb2 = new StringBuilder();
            sb2.append(i2);
            sb2.append("");
        }
        final String StyleMaker = StyleMaker(this.name.toLowerCase().toCharArray(), CSF_num_style.numberStyle[i]);
        myViewHolder.f1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.Share(StyleMaker);
            }
        });
        myViewHolder.e.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.copy(StyleMaker);
            }
        });
        myViewHolder.layout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                new Bottom_sheet().styleBottom(Num_adpapter.this.context, StyleMaker);
            }
        });
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView e;
        TextView e1;
        ImageView f1;
        LinearLayout layout = ((LinearLayout) this.itemView.findViewById(R.id.csf_lin_clk1));
        TextView number;

        public MyViewHolder(Num_adpapter num_adpapter, View view) {
            super(view);
            this.e1 = (TextView) view.findViewById(R.id.textView);
            this.number = (TextView) view.findViewById(R.id.txt_number);
            this.f1 = (ImageView) view.findViewById(R.id.share);
            this.e = (ImageView) view.findViewById(R.id.Copy_stylish);
        }
    }

    @Override
    public int getItemCount() {
        return this.p1.length;
    }

    @Override
    public long getItemId(int i) {
        return Long.parseLong(this.p1[i]);
    }

    private String StyleMaker(char[] cArr, String[] strArr) {
        StringBuilder sb = new StringBuilder();
        for (char c : cArr) {
            int i = c - '0';
            if (i >= 0 && c - '9' <= 10) {
                sb.append(strArr[i]);
            }
        }
        return sb.toString();
    }
}