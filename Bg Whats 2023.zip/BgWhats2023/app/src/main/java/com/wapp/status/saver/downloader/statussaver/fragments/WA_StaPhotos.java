package com.wapp.status.saver.downloader.statussaver.fragments;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.statussaver.adapter.StaPhotoAdapter;
import com.wapp.status.saver.downloader.statussaver.model.StatusModel;

import org.apache.commons.io.comparator.LastModifiedFileComparator;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;


public class WA_StaPhotos extends Fragment implements StaPhotoAdapter.OnCheckboxListener {
    public static ArrayList<StatusModel> f = new ArrayList<>();
    public static StaPhotoAdapter myAdapter;
    LinearLayout actionLay;
    LinearLayout deleteIV;
    ArrayList<StatusModel> filesToDelete = new ArrayList<>();
    GridView imagegrid;
    ProgressBar loader;
    int save = 10;
    CheckBox selectAll;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.sta_myphotos, viewGroup, false);
        loader = (ProgressBar) inflate.findViewById(R.id.loader);
        imagegrid = (GridView) inflate.findViewById(R.id.WorkImageGrid);
        populateGrid();
        actionLay = (LinearLayout) inflate.findViewById(R.id.actionLay);
        deleteIV = (LinearLayout) inflate.findViewById(R.id.deleteIV);
        deleteIV.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (!filesToDelete.isEmpty()) {
                    new AlertDialog.Builder(getContext()).setMessage("Are you sure , You want to delete selected files?").setCancelable(true).setNegativeButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            ArrayList arrayList = new ArrayList();
                            Iterator<StatusModel> it = filesToDelete.iterator();
                            char c = 65535;
                            while (it.hasNext()) {
                                StatusModel next = it.next();
                                File file = new File(next.getFilePath());
                                if (!file.exists() || !file.delete()) {
                                    c = 0;
                                } else {
                                    arrayList.add(next);
                                    if (c != 0) {
                                        c = 1;
                                    } else {
                                        return;
                                    }
                                }
                            }
                            filesToDelete.clear();
                            Iterator it2 = arrayList.iterator();
                            while (it2.hasNext()) {
                                WA_StaPhotos.f.remove((StatusModel) it2.next());
                            }
                            WA_StaPhotos.myAdapter.notifyDataSetChanged();
                            if (c == 0) {
                                Toast.makeText(getContext(), "Couldn't delete some files", Toast.LENGTH_SHORT).show();
                            } else if (c == 1) {
                                Toast.makeText(getActivity(), "Deleted successfully", Toast.LENGTH_SHORT).show();
                            }
                            actionLay.setVisibility(View.GONE);
                            selectAll.setChecked(false);
                        }
                    }).setPositiveButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    }).create().show();
                }
            }
        });
        selectAll = (CheckBox) inflate.findViewById(R.id.selectAll);
        selectAll.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (compoundButton.isPressed()) {
                    filesToDelete.clear();
                    int i = 0;
                    while (true) {
                        if (i >= WA_StaPhotos.f.size()) {
                            break;
                        } else if (!WA_StaPhotos.f.get(i).selected) {
                            z = true;
                            break;
                        } else {
                            i++;
                        }
                    }
                    if (z) {
                        for (int i2 = 0; i2 < WA_StaPhotos.f.size(); i2++) {
                            WA_StaPhotos.f.get(i2).selected = true;
                            filesToDelete.add(WA_StaPhotos.f.get(i2));
                        }
                        selectAll.setChecked(true);
                    } else {
                        for (int i3 = 0; i3 < WA_StaPhotos.f.size(); i3++) {
                            WA_StaPhotos.f.get(i3).selected = false;
                        }
                        actionLay.setVisibility(View.GONE);
                    }
                    WA_StaPhotos.myAdapter.notifyDataSetChanged();
                }
            }
        });
        return inflate;
    }

    public void populateGrid() {
        new loadDataAsync().execute(new Void[0]);
    }

    public class loadDataAsync extends AsyncTask<Void, Void, Void> {
        loadDataAsync() {
        }

        public void onPreExecute() {
            super.onPreExecute();
            imagegrid.setVisibility(View.GONE);
            loader.setVisibility(View.VISIBLE);
        }

        public Void doInBackground(Void... voidArr) {
            getFromSdcard();
            return null;
        }

        public void onPostExecute(Void r4) {
            super.onPostExecute((Void) r4);
            new Handler().postDelayed(new Runnable() {
                public final void run() {
                    loadDataAsync.this.lambda$onPostExecute$0$StaPhotos$loadDataAsync();
                }
            }, 1000);
        }

        public void lambda$onPostExecute$0$StaPhotos$loadDataAsync() {
            if (getActivity() != null) {
                WA_StaPhotos.myAdapter = new StaPhotoAdapter(getActivity(), WA_StaPhotos.f, WA_StaPhotos.this);
                imagegrid.setAdapter((ListAdapter) WA_StaPhotos.myAdapter);
                loader.setVisibility(View.GONE);
                imagegrid.setVisibility(View.VISIBLE);
            }
        }
    }

    public void getFromSdcard() {
        File file = new File(Environment.getExternalStorageDirectory().toString() + "/Download/" + getResources().getString(R.string.app_name) + "/Images");
        f = new ArrayList<>();
        if (file.isDirectory()) {
            File[] listFiles = file.listFiles();
            Arrays.sort(listFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
            for (File file2 : listFiles) {
                f.add(new StatusModel(file2.getAbsolutePath()));
            }
        }
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        myAdapter.onActivityResult(i, i2, intent);
        int i3 = this.save;
        if (i == i3 && i2 == i3) {
            myAdapter.notifyDataSetChanged();
            populateGrid();
            this.actionLay.setVisibility(View.GONE);
            this.selectAll.setChecked(false);
        }
    }

    @Override
    public void onCheckboxListener(View view, List<StatusModel> list) {
        this.filesToDelete.clear();
        for (StatusModel statusModel : list) {
            if (statusModel.isSelected()) {
                this.filesToDelete.add(statusModel);
            }
        }
        if (this.filesToDelete.size() == f.size()) {
            this.selectAll.setChecked(true);
        }
        if (!this.filesToDelete.isEmpty()) {
            this.actionLay.setVisibility(View.VISIBLE);
            return;
        }
        this.selectAll.setChecked(false);
        this.actionLay.setVisibility(View.GONE);
    }
}