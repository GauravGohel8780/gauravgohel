package com.wapp.status.saver.downloader.fontstyle.frag;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.tabs.TabLayout;
import com.sk.SDKX.BannerHelper;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.Activity.HomeActivity;
import com.wapp.status.saver.downloader.fontstyle.adpater.Style_adpapter;
import com.wapp.status.saver.downloader.fontstyle.interfaces.RecyclerViewItem;
import com.wapp.status.saver.downloader.fontstyle.utils.Copy_han;

import java.util.Objects;


public class Emoji_sheet_fragment extends Fragment implements RecyclerViewItem {
    ImageView backBtn;
    private Context context;
    ImageView csf_btn;
    ImageView csf_close;
    private Style_adpapter csf_sht_adap;
    private String[] csf_str;
    private EditText editText;
    private TabLayout layout;
    private RecyclerView recyclerView;

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.emoji_shet_frag, viewGroup, false);
        new BannerHelper().ShowBannerAds((Activity) context, (ViewGroup) inflate.findViewById(R.id.banner));
        this.recyclerView = (RecyclerView) inflate.findViewById(R.id.csf_rstyle);
        this.editText = (EditText) inflate.findViewById(R.id.csf_editt1);
        this.layout = (TabLayout) inflate.findViewById(R.id.csf_screll);
        backBtn = (ImageView) inflate.findViewById(R.id.backBtn);
        backBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Emoji_sheet_fragment.this.startActivity(new Intent(Emoji_sheet_fragment.this.context, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                Emoji_sheet_fragment.this.getActivity().finish();
            }
        });
        this.csf_close = (ImageView) inflate.findViewById(R.id.csf_clos22);
        this.csf_btn = (ImageView) inflate.findViewById(R.id.copy);
        this.csf_str = getResources().getStringArray(R.array.emoji_activity);
        this.recyclerView.setLayoutManager(new GridLayoutManager(this.context, 5));
        Style_adpapter style_adpapter = new Style_adpapter(this.context, 1, this.csf_str, this);
        this.csf_sht_adap = style_adpapter;
        this.recyclerView.setAdapter(style_adpapter);
        this.layout.addOnTabSelectedListener((TabLayout.OnTabSelectedListener) new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                TabLayout.Tab tabAt = Emoji_sheet_fragment.this.layout.getTabAt(0);
                Objects.requireNonNull(tabAt);
                if (tabAt.isSelected()) {
                    Emoji_sheet_fragment emoji_sheet_fragment = Emoji_sheet_fragment.this;
                    emoji_sheet_fragment.csf_str = emoji_sheet_fragment.getResources().getStringArray(R.array.emoji_activity);
                    Emoji_sheet_fragment emoji_sheet_fragment2 = Emoji_sheet_fragment.this;
                    emoji_sheet_fragment2.csf_sht_adap = new Style_adpapter(emoji_sheet_fragment2.context, 1, Emoji_sheet_fragment.this.csf_str, new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            Emoji_sheet_fragment.this.editText.getEditableText().append((CharSequence) str);
                        }
                    });
                    Emoji_sheet_fragment.this.recyclerView.setAdapter(Emoji_sheet_fragment.this.csf_sht_adap);
                }
                TabLayout.Tab tabAt2 = Emoji_sheet_fragment.this.layout.getTabAt(1);
                Objects.requireNonNull(tabAt2);
                if (tabAt2.isSelected()) {
                    Emoji_sheet_fragment emoji_sheet_fragment3 = Emoji_sheet_fragment.this;
                    emoji_sheet_fragment3.csf_str = emoji_sheet_fragment3.getResources().getStringArray(R.array.emoji_animals);
                    Emoji_sheet_fragment emoji_sheet_fragment4 = Emoji_sheet_fragment.this;
                    emoji_sheet_fragment4.csf_sht_adap = new Style_adpapter(emoji_sheet_fragment4.context, 1, Emoji_sheet_fragment.this.csf_str, new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            Emoji_sheet_fragment.this.editText.getEditableText().append((CharSequence) str);
                        }
                    });
                    Emoji_sheet_fragment.this.recyclerView.setAdapter(Emoji_sheet_fragment.this.csf_sht_adap);
                }
                TabLayout.Tab tabAt3 = Emoji_sheet_fragment.this.layout.getTabAt(2);
                Objects.requireNonNull(tabAt3);
                if (tabAt3.isSelected()) {
                    Emoji_sheet_fragment emoji_sheet_fragment5 = Emoji_sheet_fragment.this;
                    emoji_sheet_fragment5.csf_str = emoji_sheet_fragment5.getResources().getStringArray(R.array.characters);
                    Emoji_sheet_fragment emoji_sheet_fragment6 = Emoji_sheet_fragment.this;
                    emoji_sheet_fragment6.csf_sht_adap = new Style_adpapter(emoji_sheet_fragment6.context, 1, Emoji_sheet_fragment.this.csf_str, new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            Emoji_sheet_fragment.this.editText.getEditableText().append((CharSequence) str);
                        }
                    });
                    Emoji_sheet_fragment.this.recyclerView.setAdapter(Emoji_sheet_fragment.this.csf_sht_adap);
                }
                TabLayout.Tab tabAt4 = Emoji_sheet_fragment.this.layout.getTabAt(3);
                Objects.requireNonNull(tabAt4);
                if (tabAt4.isSelected()) {
                    Emoji_sheet_fragment emoji_sheet_fragment7 = Emoji_sheet_fragment.this;
                    emoji_sheet_fragment7.csf_str = emoji_sheet_fragment7.getResources().getStringArray(R.array.emoji_food);
                    Emoji_sheet_fragment emoji_sheet_fragment8 = Emoji_sheet_fragment.this;
                    emoji_sheet_fragment8.csf_sht_adap = new Style_adpapter(emoji_sheet_fragment8.context, 1, Emoji_sheet_fragment.this.csf_str, new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            Emoji_sheet_fragment.this.editText.getEditableText().append((CharSequence) str);
                        }
                    });
                    Emoji_sheet_fragment.this.recyclerView.setAdapter(Emoji_sheet_fragment.this.csf_sht_adap);
                }
                TabLayout.Tab tabAt5 = Emoji_sheet_fragment.this.layout.getTabAt(4);
                Objects.requireNonNull(tabAt5);
                if (tabAt5.isSelected()) {
                    Emoji_sheet_fragment emoji_sheet_fragment9 = Emoji_sheet_fragment.this;
                    emoji_sheet_fragment9.csf_str = emoji_sheet_fragment9.getResources().getStringArray(R.array.emoji_object);
                    Emoji_sheet_fragment emoji_sheet_fragment10 = Emoji_sheet_fragment.this;
                    emoji_sheet_fragment10.csf_sht_adap = new Style_adpapter(emoji_sheet_fragment10.context, 1, Emoji_sheet_fragment.this.csf_str, new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            Emoji_sheet_fragment.this.editText.getEditableText().append((CharSequence) str);
                        }
                    });
                    Emoji_sheet_fragment.this.recyclerView.setAdapter(Emoji_sheet_fragment.this.csf_sht_adap);
                }
                TabLayout.Tab tabAt6 = Emoji_sheet_fragment.this.layout.getTabAt(5);
                Objects.requireNonNull(tabAt6);
                if (tabAt6.isSelected()) {
                    Emoji_sheet_fragment emoji_sheet_fragment11 = Emoji_sheet_fragment.this;
                    emoji_sheet_fragment11.csf_str = emoji_sheet_fragment11.getResources().getStringArray(R.array.emoji_people);
                    Emoji_sheet_fragment emoji_sheet_fragment12 = Emoji_sheet_fragment.this;
                    emoji_sheet_fragment12.csf_sht_adap = new Style_adpapter(emoji_sheet_fragment12.context, 1, Emoji_sheet_fragment.this.csf_str, new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            Emoji_sheet_fragment.this.editText.getEditableText().append((CharSequence) str);
                        }
                    });
                    Emoji_sheet_fragment.this.recyclerView.setAdapter(Emoji_sheet_fragment.this.csf_sht_adap);
                }
                TabLayout.Tab tabAt7 = Emoji_sheet_fragment.this.layout.getTabAt(6);
                Objects.requireNonNull(tabAt7);
                if (tabAt7.isSelected()) {
                    Emoji_sheet_fragment emoji_sheet_fragment13 = Emoji_sheet_fragment.this;
                    emoji_sheet_fragment13.csf_str = emoji_sheet_fragment13.getResources().getStringArray(R.array.csf_sym1);
                    Emoji_sheet_fragment emoji_sheet_fragment14 = Emoji_sheet_fragment.this;
                    emoji_sheet_fragment14.csf_sht_adap = new Style_adpapter(emoji_sheet_fragment14.context, 1, Emoji_sheet_fragment.this.csf_str, new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            Emoji_sheet_fragment.this.editText.getEditableText().append((CharSequence) str);
                        }
                    });
                    Emoji_sheet_fragment.this.recyclerView.setAdapter(Emoji_sheet_fragment.this.csf_sht_adap);
                }
                TabLayout.Tab tabAt8 = Emoji_sheet_fragment.this.layout.getTabAt(7);
                Objects.requireNonNull(tabAt8);
                if (tabAt8.isSelected()) {
                    Emoji_sheet_fragment emoji_sheet_fragment15 = Emoji_sheet_fragment.this;
                    emoji_sheet_fragment15.csf_str = emoji_sheet_fragment15.getResources().getStringArray(R.array.emoji_travel);
                    Emoji_sheet_fragment emoji_sheet_fragment16 = Emoji_sheet_fragment.this;
                    emoji_sheet_fragment16.csf_sht_adap = new Style_adpapter(emoji_sheet_fragment16.context, 1, Emoji_sheet_fragment.this.csf_str, new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            Emoji_sheet_fragment.this.editText.getEditableText().append((CharSequence) str);
                        }
                    });
                    Emoji_sheet_fragment.this.recyclerView.setAdapter(Emoji_sheet_fragment.this.csf_sht_adap);
                }
                TabLayout.Tab tabAt9 = Emoji_sheet_fragment.this.layout.getTabAt(8);
                Objects.requireNonNull(tabAt9);
                if (tabAt9.isSelected()) {
                    Emoji_sheet_fragment emoji_sheet_fragment17 = Emoji_sheet_fragment.this;
                    emoji_sheet_fragment17.csf_str = emoji_sheet_fragment17.getResources().getStringArray(R.array.emoji_flag);
                    Emoji_sheet_fragment emoji_sheet_fragment18 = Emoji_sheet_fragment.this;
                    emoji_sheet_fragment18.csf_sht_adap = new Style_adpapter(emoji_sheet_fragment18.context, 1, Emoji_sheet_fragment.this.csf_str, new RecyclerViewItem() {


                        @Override
                        public void onItemClick(int i, String str) {
                            Emoji_sheet_fragment.this.editText.getEditableText().append((CharSequence) str);
                        }
                    });
                    Emoji_sheet_fragment.this.recyclerView.setAdapter(Emoji_sheet_fragment.this.csf_sht_adap);
                }
            }
        });
        this.csf_btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                new Copy_han(Emoji_sheet_fragment.this.context).copy(Emoji_sheet_fragment.this.editText.getText().toString());
            }
        });
        this.csf_close.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                int length = Emoji_sheet_fragment.this.editText.getText().length();
                if (length > 0) {
                    Emoji_sheet_fragment.this.editText.getText().delete(length - 1, length);
                }
            }
        });
        this.csf_close.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View view) {
                Emoji_sheet_fragment.this.editText.getText().clear();
                return false;
            }
        });
        return inflate;
    }

    @Override
    public void onAttach(Context context2) {
        super.onAttach(context2);
        this.context = context2;
    }

    @Override
    public void onItemClick(int i, String str) {
        this.editText.getEditableText().append((CharSequence) str);
    }
}