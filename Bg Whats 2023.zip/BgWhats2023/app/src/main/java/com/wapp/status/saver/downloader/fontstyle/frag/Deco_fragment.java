package com.wapp.status.saver.downloader.fontstyle.frag;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.sk.SDKX.NativeSmallHelper;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.Activity.HomeActivity;
import com.wapp.status.saver.downloader.fontstyle.adpater.Deco_adpapter;
import com.wapp.status.saver.downloader.fontstyle.model.Font;
import com.wapp.status.saver.downloader.fontstyle.utils.Bottom_sheet;

import java.util.ArrayList;


public class Deco_fragment extends Fragment {
    ImageView backBtn;
    private Activity context;
    ImageView csf_close;
    private final ArrayList<Font> csf_d_f = new ArrayList<>();
    RecyclerView csf_rec_f_;
    ImageView csf_sym;
    private EditText editText;

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        Deco_fragment deco_fragment;
        View inflate = layoutInflater.inflate(R.layout.deco_frag, viewGroup, false);

         new NativeSmallHelper().ShowNativeAds(context, (ViewGroup) inflate.findViewById(R.id.llnativesmole));

        this.backBtn = (ImageView) inflate.findViewById(R.id.backBtn);
        this.csf_close = (ImageView) inflate.findViewById(R.id.csf_clos22);
        this.csf_sym = (ImageView) inflate.findViewById(R.id.csf_symbol);
        if (this.csf_d_f.isEmpty()) {
            Font font = new Font("Decoration 1");
            Font font2 = new Font("Decoration 2");
            Font font3 = new Font("Decoration 3");
            Font font4 = new Font("Decoration 4");
            Font font5 = new Font("Decoration 5");
            Font font6 = new Font("Decoration 6");
            Font font7 = new Font("Decoration 7");
            Font font8 = new Font("Decoration 8");
            Font font9 = new Font("Decoration 9");
            Font font10 = new Font("Decoration 10");
            Font font11 = new Font("Decoration 11");
            Font font12 = new Font("Decoration 12");
            Font font13 = new Font("Decoration 13");
            Font font14 = new Font("Decoration 14");
            Font font15 = new Font("Decoration 15");
            Font font16 = new Font("Decoration 16");
            Font font17 = new Font("Decoration 17");
            Font font18 = new Font("Decoration 18");
            Font font19 = new Font("Decoration 19");
            Font font20 = new Font("Decoration 20");
            Font font21 = new Font("Decoration 21");
            Font font22 = new Font("Decoration 22");
            Font font23 = new Font("Decoration 23");
            Font font24 = new Font("Decoration 24");
            Font font25 = new Font("Decoration 25");
            Font font26 = new Font("Decoration 26");
            Font font27 = new Font("Decoration 27");
            Font font28 = new Font("Decoration 28");
            Font font29 = new Font("Decoration 29");
            Font font30 = new Font("Decoration 30");
            Font font31 = new Font("Decoration 31");
            Font font32 = new Font("Decoration 32");
            Font font33 = new Font("Decoration 33");
            Font font34 = new Font("Decoration 34");
            Font font35 = new Font("Decoration 35");
            Font font36 = new Font("Decoration 36");
            Font font37 = new Font("Decoration 37");
            Font font38 = new Font("Decoration 38");
            Font font39 = new Font("Decoration 39");
            Font font40 = new Font("Decoration 40");
            Font font41 = new Font("Decoration 41");
            Font font42 = new Font("Decoration 42");
            Font font43 = new Font("Decoration 43");
            Font font44 = new Font("Decoration 44");
            Font font45 = new Font("Decoration 45");
            Font font46 = new Font("Decoration 46");
            Font font47 = new Font("Decoration 47");
            Font font48 = new Font("Decoration 48");
            Font font49 = new Font("Decoration 49");
            Font font50 = new Font("Decoration 50");
            Font font51 = new Font("Decoration 51");
            Font font52 = new Font("Decoration 52");
            Font font53 = new Font("Decoration 53");
            Font font54 = new Font("Decoration 54");
            Font font55 = new Font("Decoration 55");
            Font font56 = new Font("Decoration 56");
            Font font57 = new Font("Decoration 57");
            Font font58 = new Font("Decoration 58");
            Font font59 = new Font("Decoration 59");
            Font font60 = new Font("Decoration 60");
            Font font61 = new Font("Decoration 61");
            Font font62 = new Font("Decoration 62");
            Font font63 = new Font("Decoration 63");
            Font font64 = new Font("Decoration 64");
            Font font65 = new Font("Decoration 65");
            Font font66 = new Font("Decoration 66");
            Font font67 = new Font("Decoration 67");
            Font font68 = new Font("Decoration 68");
            Font font69 = new Font("Decoration 69");
            Font font70 = new Font("Decoration 70");
            Font font71 = new Font("Decoration 71");
            Font font72 = new Font("Decoration 72");
            Font font73 = new Font("Decoration 73");
            Font font74 = new Font("Decoration 74");
            Font font75 = new Font("Decoration 75");
            Font font76 = new Font("Decoration 76");
            Font font77 = new Font("Decoration 77");
            Font font78 = new Font("Decoration 78");
            Font font79 = new Font("Decoration 79");
            Font font80 = new Font("Decoration 80");
            Font font81 = new Font("Decoration 81");
            Font font82 = new Font("Decoration 82");
            Font font83 = new Font("Decoration 83");
            Font font84 = new Font("Decoration 84");
            Font font85 = new Font("Decoration 85");
            Font font86 = new Font("Decoration 86");
            Font font87 = new Font("Decoration 87");
            Font font88 = new Font("Decoration 88");
            Font font89 = new Font("Decoration 89");
            Font font90 = new Font("Decoration 90");
            Font font91 = new Font("Decoration 91");
            Font font92 = new Font("Decoration 92");
            Font font93 = new Font("Decoration 93");
            Font font94 = new Font("Decoration 94");
            Font font95 = new Font("Decoration 95");
            Font font96 = new Font("Decoration 96");
            Font font97 = new Font("Decoration 97");
            Font font98 = new Font("Decoration 98");
            Font font99 = new Font("Decoration 99");
            this.csf_d_f.add(font);
            this.csf_d_f.add(font2);
            this.csf_d_f.add(font3);
            this.csf_d_f.add(font4);
            this.csf_d_f.add(font5);
            this.csf_d_f.add(font6);
            this.csf_d_f.add(font7);
            this.csf_d_f.add(font8);
            this.csf_d_f.add(font9);
            this.csf_d_f.add(font10);
            this.csf_d_f.add(font11);
            this.csf_d_f.add(font12);
            this.csf_d_f.add(font13);
            this.csf_d_f.add(font14);
            this.csf_d_f.add(font15);
            this.csf_d_f.add(font16);
            this.csf_d_f.add(font17);
            this.csf_d_f.add(font18);
            this.csf_d_f.add(font19);
            this.csf_d_f.add(font20);
            this.csf_d_f.add(font21);
            this.csf_d_f.add(font22);
            this.csf_d_f.add(font23);
            this.csf_d_f.add(font24);
            this.csf_d_f.add(font25);
            this.csf_d_f.add(font26);
            this.csf_d_f.add(font27);
            this.csf_d_f.add(font28);
            this.csf_d_f.add(font29);
            this.csf_d_f.add(font30);
            this.csf_d_f.add(font31);
            this.csf_d_f.add(font32);
            this.csf_d_f.add(font33);
            this.csf_d_f.add(font34);
            this.csf_d_f.add(font35);
            this.csf_d_f.add(font36);
            this.csf_d_f.add(font37);
            this.csf_d_f.add(font38);
            this.csf_d_f.add(font39);
            this.csf_d_f.add(font40);
            this.csf_d_f.add(font41);
            this.csf_d_f.add(font42);
            this.csf_d_f.add(font43);
            this.csf_d_f.add(font44);
            this.csf_d_f.add(font45);
            this.csf_d_f.add(font46);
            this.csf_d_f.add(font47);
            this.csf_d_f.add(font48);
            this.csf_d_f.add(font49);
            this.csf_d_f.add(font50);
            this.csf_d_f.add(font51);
            this.csf_d_f.add(font52);
            this.csf_d_f.add(font53);
            this.csf_d_f.add(font54);
            this.csf_d_f.add(font55);
            this.csf_d_f.add(font56);
            this.csf_d_f.add(font57);
            this.csf_d_f.add(font58);
            this.csf_d_f.add(font59);
            this.csf_d_f.add(font60);
            this.csf_d_f.add(font61);
            this.csf_d_f.add(font62);
            this.csf_d_f.add(font63);
            this.csf_d_f.add(font64);
            this.csf_d_f.add(font65);
            this.csf_d_f.add(font66);
            this.csf_d_f.add(font67);
            this.csf_d_f.add(font68);
            this.csf_d_f.add(font69);
            this.csf_d_f.add(font70);
            this.csf_d_f.add(font71);
            this.csf_d_f.add(font72);
            this.csf_d_f.add(font73);
            this.csf_d_f.add(font74);
            this.csf_d_f.add(font75);
            this.csf_d_f.add(font76);
            this.csf_d_f.add(font77);
            this.csf_d_f.add(font78);
            this.csf_d_f.add(font79);
            this.csf_d_f.add(font80);
            this.csf_d_f.add(font81);
            this.csf_d_f.add(font82);
            this.csf_d_f.add(font83);
            this.csf_d_f.add(font84);
            this.csf_d_f.add(font85);
            this.csf_d_f.add(font86);
            this.csf_d_f.add(font87);
            this.csf_d_f.add(font88);
            this.csf_d_f.add(font89);
            this.csf_d_f.add(font90);
            this.csf_d_f.add(font91);
            this.csf_d_f.add(font92);
            this.csf_d_f.add(font93);
            this.csf_d_f.add(font94);
            this.csf_d_f.add(font95);
            this.csf_d_f.add(font96);
            this.csf_d_f.add(font97);
            this.csf_d_f.add(font98);
            this.csf_d_f.add(font99);
            deco_fragment = this;
        } else {
            deco_fragment = this;
            deco_fragment.csf_d_f.clear();
            Font font100 = new Font("Decoration 1");
            Font font101 = new Font("Decoration 2");
            Font font102 = new Font("Decoration 3");
            Font font103 = new Font("Decoration 4");
            Font font104 = new Font("Decoration 5");
            Font font105 = new Font("Decoration 6");
            Font font106 = new Font("Decoration 7");
            Font font107 = new Font("Decoration 8");
            Font font108 = new Font("Decoration 9");
            Font font109 = new Font("Decoration 10");
            Font font110 = new Font("Decoration 11");
            Font font111 = new Font("Decoration 12");
            Font font112 = new Font("Decoration 13");
            Font font113 = new Font("Decoration 14");
            Font font114 = new Font("Decoration 15");
            Font font115 = new Font("Decoration 16");
            Font font116 = new Font("Decoration 17");
            Font font117 = new Font("Decoration 18");
            Font font118 = new Font("Decoration 19");
            Font font119 = new Font("Decoration 20");
            Font font120 = new Font("Decoration 21");
            Font font121 = new Font("Decoration 22");
            Font font122 = new Font("Decoration 23");
            Font font123 = new Font("Decoration 24");
            Font font124 = new Font("Decoration 25");
            Font font125 = new Font("Decoration 26");
            Font font126 = new Font("Decoration 27");
            Font font127 = new Font("Decoration 28");
            Font font128 = new Font("Decoration 29");
            Font font129 = new Font("Decoration 30");
            Font font130 = new Font("Decoration 31");
            Font font131 = new Font("Decoration 32");
            Font font132 = new Font("Decoration 33");
            Font font133 = new Font("Decoration 34");
            Font font134 = new Font("Decoration 35");
            Font font135 = new Font("Decoration 36");
            Font font136 = new Font("Decoration 37");
            Font font137 = new Font("Decoration 38");
            Font font138 = new Font("Decoration 39");
            Font font139 = new Font("Decoration 40");
            Font font140 = new Font("Decoration 41");
            Font font141 = new Font("Decoration 42");
            Font font142 = new Font("Decoration 43");
            Font font143 = new Font("Decoration 44");
            Font font144 = new Font("Decoration 45");
            Font font145 = new Font("Decoration 46");
            Font font146 = new Font("Decoration 47");
            Font font147 = new Font("Decoration 48");
            Font font148 = new Font("Decoration 49");
            Font font149 = new Font("Decoration 50");
            Font font150 = new Font("Decoration 51");
            Font font151 = new Font("Decoration 52");
            Font font152 = new Font("Decoration 53");
            Font font153 = new Font("Decoration 54");
            Font font154 = new Font("Decoration 55");
            Font font155 = new Font("Decoration 56");
            Font font156 = new Font("Decoration 57");
            Font font157 = new Font("Decoration 58");
            Font font158 = new Font("Decoration 59");
            Font font159 = new Font("Decoration 60");
            Font font160 = new Font("Decoration 61");
            Font font161 = new Font("Decoration 62");
            Font font162 = new Font("Decoration 63");
            Font font163 = new Font("Decoration 64");
            Font font164 = new Font("Decoration 65");
            Font font165 = new Font("Decoration 66");
            Font font166 = new Font("Decoration 67");
            Font font167 = new Font("Decoration 68");
            Font font168 = new Font("Decoration 69");
            Font font169 = new Font("Decoration 70");
            Font font170 = new Font("Decoration 71");
            Font font171 = new Font("Decoration 72");
            Font font172 = new Font("Decoration 73");
            Font font173 = new Font("Decoration 74");
            Font font174 = new Font("Decoration 75");
            Font font175 = new Font("Decoration 76");
            Font font176 = new Font("Decoration 77");
            Font font177 = new Font("Decoration 78");
            Font font178 = new Font("Decoration 79");
            Font font179 = new Font("Decoration 80");
            Font font180 = new Font("Decoration 81");
            Font font181 = new Font("Decoration 82");
            Font font182 = new Font("Decoration 83");
            Font font183 = new Font("Decoration 84");
            Font font184 = new Font("Decoration 85");
            Font font185 = new Font("Decoration 86");
            Font font186 = new Font("Decoration 87");
            Font font187 = new Font("Decoration 88");
            Font font188 = new Font("Decoration 89");
            Font font189 = new Font("Decoration 90");
            Font font190 = new Font("Decoration 91");
            Font font191 = new Font("Decoration 92");
            Font font192 = new Font("Decoration 93");
            Font font193 = new Font("Decoration 94");
            Font font194 = new Font("Decoration 95");
            Font font195 = new Font("Decoration 96");
            Font font196 = new Font("Decoration 97");
            Font font197 = new Font("Decoration 98");
            Font font198 = new Font("Decoration 99");
            deco_fragment.csf_d_f.add(font100);
            deco_fragment.csf_d_f.add(font101);
            deco_fragment.csf_d_f.add(font102);
            deco_fragment.csf_d_f.add(font103);
            deco_fragment.csf_d_f.add(font104);
            deco_fragment.csf_d_f.add(font105);
            deco_fragment.csf_d_f.add(font106);
            deco_fragment.csf_d_f.add(font107);
            deco_fragment.csf_d_f.add(font108);
            deco_fragment.csf_d_f.add(font109);
            deco_fragment.csf_d_f.add(font110);
            deco_fragment.csf_d_f.add(font111);
            deco_fragment.csf_d_f.add(font112);
            deco_fragment.csf_d_f.add(font113);
            deco_fragment.csf_d_f.add(font114);
            deco_fragment.csf_d_f.add(font115);
            deco_fragment.csf_d_f.add(font116);
            deco_fragment.csf_d_f.add(font117);
            deco_fragment.csf_d_f.add(font118);
            deco_fragment.csf_d_f.add(font119);
            deco_fragment.csf_d_f.add(font120);
            deco_fragment.csf_d_f.add(font121);
            deco_fragment.csf_d_f.add(font122);
            deco_fragment.csf_d_f.add(font123);
            deco_fragment.csf_d_f.add(font124);
            deco_fragment.csf_d_f.add(font125);
            deco_fragment.csf_d_f.add(font126);
            deco_fragment.csf_d_f.add(font127);
            deco_fragment.csf_d_f.add(font128);
            deco_fragment.csf_d_f.add(font129);
            deco_fragment.csf_d_f.add(font130);
            deco_fragment.csf_d_f.add(font131);
            deco_fragment.csf_d_f.add(font132);
            deco_fragment.csf_d_f.add(font133);
            deco_fragment.csf_d_f.add(font134);
            deco_fragment.csf_d_f.add(font135);
            deco_fragment.csf_d_f.add(font136);
            deco_fragment.csf_d_f.add(font137);
            deco_fragment.csf_d_f.add(font138);
            deco_fragment.csf_d_f.add(font139);
            deco_fragment.csf_d_f.add(font140);
            deco_fragment.csf_d_f.add(font141);
            deco_fragment.csf_d_f.add(font142);
            deco_fragment.csf_d_f.add(font143);
            deco_fragment.csf_d_f.add(font144);
            deco_fragment.csf_d_f.add(font145);
            deco_fragment.csf_d_f.add(font146);
            deco_fragment.csf_d_f.add(font147);
            deco_fragment.csf_d_f.add(font148);
            deco_fragment.csf_d_f.add(font149);
            deco_fragment.csf_d_f.add(font150);
            deco_fragment.csf_d_f.add(font151);
            deco_fragment.csf_d_f.add(font152);
            deco_fragment.csf_d_f.add(font153);
            deco_fragment.csf_d_f.add(font154);
            deco_fragment.csf_d_f.add(font155);
            deco_fragment.csf_d_f.add(font156);
            deco_fragment.csf_d_f.add(font157);
            deco_fragment.csf_d_f.add(font158);
            deco_fragment.csf_d_f.add(font159);
            deco_fragment.csf_d_f.add(font160);
            deco_fragment.csf_d_f.add(font161);
            deco_fragment.csf_d_f.add(font162);
            deco_fragment.csf_d_f.add(font163);
            deco_fragment.csf_d_f.add(font164);
            deco_fragment.csf_d_f.add(font165);
            deco_fragment.csf_d_f.add(font166);
            deco_fragment.csf_d_f.add(font167);
            deco_fragment.csf_d_f.add(font168);
            deco_fragment.csf_d_f.add(font169);
            deco_fragment.csf_d_f.add(font170);
            deco_fragment.csf_d_f.add(font171);
            deco_fragment.csf_d_f.add(font172);
            deco_fragment.csf_d_f.add(font173);
            deco_fragment.csf_d_f.add(font174);
            deco_fragment.csf_d_f.add(font175);
            deco_fragment.csf_d_f.add(font176);
            deco_fragment.csf_d_f.add(font177);
            deco_fragment.csf_d_f.add(font178);
            deco_fragment.csf_d_f.add(font179);
            deco_fragment.csf_d_f.add(font180);
            deco_fragment.csf_d_f.add(font181);
            deco_fragment.csf_d_f.add(font182);
            deco_fragment.csf_d_f.add(font183);
            deco_fragment.csf_d_f.add(font184);
            deco_fragment.csf_d_f.add(font185);
            deco_fragment.csf_d_f.add(font186);
            deco_fragment.csf_d_f.add(font187);
            deco_fragment.csf_d_f.add(font188);
            deco_fragment.csf_d_f.add(font189);
            deco_fragment.csf_d_f.add(font190);
            deco_fragment.csf_d_f.add(font191);
            deco_fragment.csf_d_f.add(font192);
            deco_fragment.csf_d_f.add(font193);
            deco_fragment.csf_d_f.add(font194);
            deco_fragment.csf_d_f.add(font195);
            deco_fragment.csf_d_f.add(font196);
            deco_fragment.csf_d_f.add(font197);
            deco_fragment.csf_d_f.add(font198);
        }
        deco_fragment.csf_rec_f_ = (RecyclerView) inflate.findViewById(R.id.csf_view_rec);
        final Deco_adpapter deco_adpapter = new Deco_adpapter(deco_fragment.csf_d_f, deco_fragment.context);
        deco_fragment.csf_rec_f_.setLayoutManager(new LinearLayoutManager(deco_fragment.context));
        deco_fragment.csf_rec_f_.setAdapter(deco_adpapter);
        deco_fragment.editText = (EditText) inflate.findViewById(R.id.csf_txt_edit);
        deco_fragment.csf_sym.setOnClickListener(new View.OnClickListener() {
            /* class com.epic.chatstyle.fontstyle.AppData.frag.Deco_fragment.AnonymousClass1 */

            public void onClick(View view) {
                Bottom_sheet.showDialogbox(Deco_fragment.this.context, Deco_fragment.this.editText);
            }
        });
        deco_fragment.editText.addTextChangedListener(new TextWatcher() {
            /* class com.epic.chatstyle.fontstyle.AppData.frag.Deco_fragment.AnonymousClass2 */

            public void afterTextChanged(Editable editable) {
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                String obj = Deco_fragment.this.editText.getText().toString();
                if (obj.isEmpty()) {
                    obj = "Preview text";
                }
                for (int i4 = 0; i4 < Deco_fragment.this.csf_d_f.size(); i4++) {
                    ((Font) Deco_fragment.this.csf_d_f.get(i4)).setPreviewText(obj);
                    deco_adpapter.notifyDataSetChanged();
                }
            }
        });
        deco_fragment.csf_close.setOnClickListener(new View.OnClickListener() {
            /* class com.epic.chatstyle.fontstyle.AppData.frag.Deco_fragment.AnonymousClass3 */

            public void onClick(View view) {
                int length = Deco_fragment.this.editText.getText().length();
                if (length > 0) {
                    Deco_fragment.this.editText.getText().delete(length - 1, length);
                }
            }
        });
        deco_fragment.csf_close.setOnLongClickListener(new View.OnLongClickListener() {
            /* class com.epic.chatstyle.fontstyle.AppData.frag.Deco_fragment.AnonymousClass4 */

            public boolean onLongClick(View view) {
                Deco_fragment.this.editText.getText().clear();
                return false;
            }
        });
        deco_fragment.backBtn.setOnClickListener(new View.OnClickListener() {
            /* class com.epic.chatstyle.fontstyle.AppData.frag.Deco_fragment.AnonymousClass5 */

            public void onClick(View view) {
                Deco_fragment.this.startActivity(new Intent(Deco_fragment.this.context, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                Deco_fragment.this.getActivity().finish();
            }
        });
        return inflate;
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context2) {
        super.onAttach(context2);
        this.context = (Activity) context2;
    }
}