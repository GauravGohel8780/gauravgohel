package com.wapp.status.saver.downloader.fontstyle.utils;

import android.text.Editable;
import android.text.TextWatcher;

import com.wapp.status.saver.downloader.fontstyle.frag.Num_style_fragment;

public class Num_edit implements TextWatcher {
    public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        if (charSequence.length() == 0) {
            Num_style_fragment.name_number = " ";
            Num_style_fragment.numberAdapter.setName(Num_style_fragment.name_number, Num_style_fragment.type);
            Num_style_fragment.numberAdapter.notifyDataSetChanged();
        } else if (charSequence.length() >= 1) {
            Num_style_fragment.name_number = charSequence.toString();
            Num_style_fragment.numberAdapter.setName(Num_style_fragment.name_number, Num_style_fragment.type);
        }
    }

    public void afterTextChanged(Editable editable) {
        Num_style_fragment.name_number = "0123456789";
        Num_style_fragment.numberAdapter.notifyDataSetChanged();
    }
}