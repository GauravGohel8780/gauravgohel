package com.wapp.status.saver.downloader.fontstyle.adpater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.wapp.status.saver.downloader.R;


public class Cust_adpapter extends BaseAdapter {
    private Context csf_cnt;
    private int[] csf_icon;
    private LayoutInflater csf_inflater;
    private String[] csf_logo;

    public Object getItem(int i) {
        return null;
    }

    public long getItemId(int i) {
        return 0;
    }

    public Cust_adpapter(Context context, String[] strArr, int[] iArr) {
        this.csf_cnt = context;
        this.csf_logo = strArr;
        this.csf_inflater = LayoutInflater.from(context);
        this.csf_icon = iArr;
    }

    public int getCount() {
        return this.csf_logo.length;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        View inflate = this.csf_inflater.inflate(R.layout.fgridview, (ViewGroup) null);
        ((ImageView) inflate.findViewById(R.id.image)).setImageDrawable(this.csf_cnt.getDrawable(this.csf_icon[i]));
        ((TextView) inflate.findViewById(R.id.name)).setText(this.csf_logo[i]);
        return inflate;
    }
}