package com.wapp.status.saver.downloader.statussaver.fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.statussaver.model.StatusModel;

import org.apache.commons.io.comparator.LastModifiedFileComparator;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;


public class WA_StaVideos extends Fragment implements WA_StaVideoAdapter.OnCheckboxListener {
    int SAVE = 10;
    LinearLayout actionLay;
    WA_StaVideoAdapter adapter;
    LinearLayout deleteIV;
    ArrayList<StatusModel> fileList = new ArrayList<>();
    ArrayList<StatusModel> filesToDelete = new ArrayList<>();
    GridView gridView;
    ProgressBar loader;
    CheckBox selectAll;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.sta_videos, viewGroup, false);
        loader = (ProgressBar) inflate.findViewById(R.id.loader);
        gridView = (GridView) inflate.findViewById(R.id.videoGrid);
        populateVideo();
        actionLay = (LinearLayout) inflate.findViewById(R.id.actionLay);
        deleteIV = (LinearLayout) inflate.findViewById(R.id.deleteIV);
        deleteIV.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (!filesToDelete.isEmpty()) {
                    new AlertDialog.Builder(getContext()).setMessage("Are you sure , You want to delete selected files?").setCancelable(true).setNegativeButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            ArrayList arrayList = new ArrayList();
                            Iterator<StatusModel> it = filesToDelete.iterator();
                            char c = 65535;
                            while (it.hasNext()) {
                                StatusModel next = it.next();
                                File file = new File(next.getFilePath());
                                if (!file.exists() || !file.delete()) {
                                    c = 0;
                                } else {
                                    arrayList.add(next);
                                    if (c != 0) {
                                        c = 1;
                                    } else {
                                        return;
                                    }
                                }
                            }
                            filesToDelete.clear();
                            Iterator it2 = arrayList.iterator();
                            while (it2.hasNext()) {
                                fileList.remove((StatusModel) it2.next());
                            }
                            adapter.notifyDataSetChanged();
                            if (c == 0) {
                                Toast.makeText(getContext(), "Couldn't delete some files", Toast.LENGTH_SHORT).show();
                            } else if (c == 1) {
                                Toast.makeText(getActivity(), "Deleted successfully", Toast.LENGTH_SHORT).show();
                            }
                            actionLay.setVisibility(View.GONE);
                            selectAll.setChecked(false);
                        }
                    }).setPositiveButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    }).create().show();
                }
            }
        });
        selectAll = (CheckBox) inflate.findViewById(R.id.selectAll);
        selectAll.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (compoundButton.isPressed()) {
                    filesToDelete.clear();
                    int i = 0;
                    while (true) {
                        if (i >= fileList.size()) {
                            break;
                        } else if (!fileList.get(i).selected) {
                            z = true;
                            break;
                        } else {
                            i++;
                        }
                    }
                    if (z) {
                        for (int i2 = 0; i2 < fileList.size(); i2++) {
                            fileList.get(i2).selected = true;
                            filesToDelete.add(fileList.get(i2));
                        }
                        selectAll.setChecked(true);
                    } else {
                        for (int i3 = 0; i3 < fileList.size(); i3++) {
                            fileList.get(i3).selected = false;
                        }
                        actionLay.setVisibility(View.GONE);
                    }
                    adapter.notifyDataSetChanged();
                }
            }
        });
        return inflate;
    }

    public void populateVideo() {
        new loadDataAsync().execute(new Void[0]);
    }

    public class loadDataAsync extends AsyncTask<Void, Void, Void> {
        loadDataAsync() {
        }

        public void onPreExecute() {
            super.onPreExecute();
            gridView.setVisibility(View.GONE);
//            loader.setVisibility(View.VISIBLE);
        }

        public Void doInBackground(Void... voidArr) {
            updateSongList();
            return null;
        }

        public void onPostExecute(Void r4) {
            super.onPostExecute((Void) r4);
            new Handler().postDelayed(new Runnable() {
                public final void run() {
                    loadDataAsync.this.lambda$onPostExecute$0$StaVideos$loadDataAsync();
                }
            }, 1000);
        }

        public void lambda$onPostExecute$0$StaVideos$loadDataAsync() {
            if (getActivity() != null) {
                if (fileList != null) {
                    WA_StaVideos WAStaVideos = WA_StaVideos.this;
                    WA_StaVideos WAStaVideos2 = WA_StaVideos.this;
                    WAStaVideos.adapter = new WA_StaVideoAdapter(getActivity(), WAStaVideos2.fileList, WA_StaVideos.this);
                    gridView.setAdapter((ListAdapter) adapter);
                }
//                loader.setVisibility(View.GONE);
                gridView.setVisibility(View.VISIBLE);
            }
        }
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        this.adapter.onActivityResult(i, i2, intent);
        int i3 = this.SAVE;
        if (i == i3 && i2 == i3) {
            this.adapter.notifyDataSetChanged();
            populateVideo();
            this.actionLay.setVisibility(View.GONE);
            this.selectAll.setChecked(false);
        }
    }

    public void updateSongList() {
        File file = new File(Environment.getExternalStorageDirectory().toString() + "/Download/" + getResources().getString(R.string.app_name) + "/Videos");
        if (file.isDirectory()) {
            this.fileList = new ArrayList<>();
            if (file.isDirectory()) {
                File[] listFiles = file.listFiles();
                Arrays.sort(listFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                for (File file2 : listFiles) {
                    this.fileList.add(new StatusModel(file2.getAbsolutePath()));
                }
            }
        }
    }

    @Override
    public void onCheckboxListener(View view, List<StatusModel> list) {
        this.filesToDelete.clear();
        for (StatusModel statusModel : list) {
            if (statusModel.isSelected()) {
                this.filesToDelete.add(statusModel);
            }
        }
        if (this.filesToDelete.size() == this.fileList.size()) {
            this.selectAll.setChecked(true);
        }
        if (!this.filesToDelete.isEmpty()) {
            this.actionLay.setVisibility(View.VISIBLE);
            return;
        }
        this.selectAll.setChecked(false);
        this.actionLay.setVisibility(View.GONE);
    }
}