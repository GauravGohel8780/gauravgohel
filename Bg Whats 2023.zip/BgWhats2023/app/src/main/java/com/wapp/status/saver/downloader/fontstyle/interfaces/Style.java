package com.wapp.status.saver.downloader.fontstyle.interfaces;

public interface Style {
    String generate(String str);
}