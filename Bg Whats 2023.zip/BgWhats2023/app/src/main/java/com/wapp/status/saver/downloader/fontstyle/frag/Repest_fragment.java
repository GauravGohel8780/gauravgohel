package com.wapp.status.saver.downloader.fontstyle.frag;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;

import com.sk.SDKX.NativeHelper;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.Activity.HomeActivity;
import com.wapp.status.saver.downloader.fontstyle.utils.Copy_han;


public class Repest_fragment extends Fragment {
    Activity activity;
    ImageView backBtn;
    ImageView close;
    EditText input;
    EditText number;
    TextView outputt;
    SwitchCompat switchCompat;
    String text = "";

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.repet_frag, viewGroup, false);

        new NativeHelper().ShowNativeAds(activity, (ViewGroup) inflate.findViewById(R.id.llnative));

        this.backBtn = (ImageView) inflate.findViewById(R.id.backBtn);
        this.close = (ImageView) inflate.findViewById(R.id.csf_clos22);
        this.input = (EditText) inflate.findViewById(R.id.editText);
        this.number = (EditText) inflate.findViewById(R.id.number);
        this.switchCompat = (SwitchCompat) inflate.findViewById(R.id.nLine);
        this.outputt = (TextView) inflate.findViewById(R.id.csf_txt_pev);
        final Copy_han copy_han = new Copy_han(this.activity);
        inflate.findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Repest_fragment.this.textRepeat();
                Repest_fragment.this.outputt.setText(Repest_fragment.this.text);
            }
        });
        inflate.findViewById(R.id.copy).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.copysi(Repest_fragment.this.outputt.getText().toString());
            }
        });
        inflate.findViewById(R.id.share).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.Share(Repest_fragment.this.outputt.getText().toString());
            }
        });
        this.switchCompat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                Repest_fragment.this.textRepeat();
            }
        });
        this.close.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                int length = Repest_fragment.this.input.getText().length();
                if (length > 0) {
                    Repest_fragment.this.input.getText().delete(length - 1, length);
                }
            }
        });
        this.close.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View view) {
                Repest_fragment.this.input.getText().clear();
                return false;
            }
        });
        this.backBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Repest_fragment.this.startActivity(new Intent(Repest_fragment.this.activity, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                Repest_fragment.this.getActivity().finish();
            }
        });
        return inflate;
    }

    private void textRepeat() {
        String obj = this.input.getText().toString();
        String obj2 = this.number.getText().toString();
        if (this.input.getText().toString().trim().isEmpty() || obj.isEmpty()) {
            Toast.makeText(this.activity, (int) R.string.toast, Toast.LENGTH_LONG).show();
            return;
        }
        if (!obj2.equals("")) {
            int parseInt = Integer.parseInt(this.number.getText().toString());
            this.text = "";
            for (int i = 0; i < parseInt; i++) {
                if (this.switchCompat.isChecked()) {
                    this.text += obj + "\n";
                } else {
                    this.text += obj;
                }
            }
        }
        this.outputt.setText(this.text);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.activity = (Activity) context;
    }
}