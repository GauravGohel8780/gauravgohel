package com.wapp.status.saver.downloader.statussaver;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.documentfile.provider.DocumentFile;
import androidx.viewpager.widget.ViewPager;

import com.sk.SDKX.BackInterHelper;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.statussaver.adapter.FullscreenImageAdapter;
import com.wapp.status.saver.downloader.statussaver.model.StatusModel;
import com.wapp.status.saver.downloader.statussaver.util.Utils;

import java.io.File;
import java.util.ArrayList;


public class WA_PagerPreviewActivity extends AppCompatActivity {
    ImageView backIV;
    private View.OnClickListener clickListener = new View.OnClickListener() {
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.backIV:
                    onBackPressed();
                    return;
                case R.id.deleteIV:
                    if (imageList.size() > 0) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(WA_PagerPreviewActivity.this);
                        builder.setTitle((CharSequence) "Confirm Delete....");
                        builder.setMessage((CharSequence) "Are you sure, You Want To Delete This Status?");
                        builder.setPositiveButton((CharSequence) "Yes", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                                if (statusdownload.equals("download")) {
                                    File file = new File(imageList.get(viewPager.getCurrentItem()).getFilePath());
                                    if (file.exists()) {
                                        file.delete();
                                        delete(0);
                                        return;
                                    }
                                    return;
                                }
                                DocumentFile fromSingleUri = DocumentFile.fromSingleUri(WA_PagerPreviewActivity.this, Uri.parse(imageList.get(viewPager.getCurrentItem()).getFilePath()));
                                if (fromSingleUri.exists()) {
                                    fromSingleUri.delete();
                                    delete(0);
                                }
                            }
                        });
                        builder.setNegativeButton((CharSequence) "No", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        });
                        builder.show();
                        return;
                    }
                    finish();
                    return;
                case R.id.downloadIV:
                    if (imageList.size() > 0) {
                        try {
                            WA_PagerPreviewActivity WAPagerPreviewActivity = WA_PagerPreviewActivity.this;
                            Utils.download(WAPagerPreviewActivity, WAPagerPreviewActivity.imageList.get(viewPager.getCurrentItem()).getFilePath());
                            Toast.makeText(WA_PagerPreviewActivity.this, "Status saved successfully", Toast.LENGTH_SHORT).show();
                            return;
                        } catch (Exception unused) {
                            Toast.makeText(WA_PagerPreviewActivity.this, "Sorry we can't move file.try with other file.", Toast.LENGTH_LONG).show();
                            return;
                        }
                    } else {
                        finish();
                        return;
                    }
                case R.id.shareIV:
                    if (imageList.size() > 0) {
                        WA_PagerPreviewActivity WAPagerPreviewActivity2 = WA_PagerPreviewActivity.this;
                        Utils.shareFile(WAPagerPreviewActivity2, Utils.isVideoFile(WAPagerPreviewActivity2, WAPagerPreviewActivity2.imageList.get(viewPager.getCurrentItem()).getFilePath()), imageList.get(viewPager.getCurrentItem()).getFilePath());
                        return;
                    }
                    finish();
                    return;
                case R.id.wAppIV:
                    WA_PagerPreviewActivity WAPagerPreviewActivity3 = WA_PagerPreviewActivity.this;
                    Utils.repostWhatsApp(WAPagerPreviewActivity3, Utils.isVideoFile(WAPagerPreviewActivity3, WAPagerPreviewActivity3.imageList.get(viewPager.getCurrentItem()).getFilePath()), imageList.get(viewPager.getCurrentItem()).getFilePath());
                    return;
                default:
                    return;
            }
        }
    };
    ImageView deleteIV;
    LinearLayout downloadIV;
    FullscreenImageAdapter fullscreenImageAdapter;
    ArrayList<StatusModel> imageList;
    int position;
    ImageView shareIV;
    String statusdownload;
    ViewPager viewPager;
    ImageView wAppIV;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_pager_preview);
        bind();
    }

    private void bind() {
        backIV = (ImageView) findViewById(R.id.backIV);
        viewPager = (ViewPager) findViewById(R.id.viewPager);
        shareIV = (ImageView) findViewById(R.id.shareIV);
        downloadIV = (LinearLayout) findViewById(R.id.downloadIV);
        deleteIV = (ImageView) findViewById(R.id.deleteIV);
        wAppIV = (ImageView) findViewById(R.id.wAppIV);
        imageList = getIntent().getParcelableArrayListExtra("images");
        position = getIntent().getIntExtra("position", 0);
        String stringExtra = getIntent().getStringExtra("statusdownload");
        this.statusdownload = stringExtra;
        if (stringExtra.equals("download")) {
            downloadIV.setVisibility(View.GONE);
        } else {
            downloadIV.setVisibility(View.VISIBLE);
        }
        FullscreenImageAdapter fullscreenImageAdapter2 = new FullscreenImageAdapter(this, this.imageList);
        fullscreenImageAdapter = fullscreenImageAdapter2;
        viewPager.setAdapter(fullscreenImageAdapter2);
        viewPager.setCurrentItem(this.position);
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            public void onPageScrollStateChanged(int i) {
            }

            public void onPageScrolled(int i, float f, int i2) {
            }

            public void onPageSelected(int i) {
            }
        });
        downloadIV.setOnClickListener(this.clickListener);
        shareIV.setOnClickListener(this.clickListener);
        deleteIV.setOnClickListener(this.clickListener);
        backIV.setOnClickListener(this.clickListener);
        wAppIV.setOnClickListener(this.clickListener);
    }

    public void delete(int i) {
        if (this.imageList.size() > 0 && this.viewPager.getCurrentItem() < this.imageList.size()) {
            i = this.viewPager.getCurrentItem();
        }
        this.imageList.remove(this.viewPager.getCurrentItem());
        FullscreenImageAdapter fullscreenImageAdapter2 = new FullscreenImageAdapter(this, this.imageList);
        this.fullscreenImageAdapter = fullscreenImageAdapter2;
        this.viewPager.setAdapter(fullscreenImageAdapter2);
        setResult(10, new Intent());
        if (this.imageList.size() > 0) {
            this.viewPager.setCurrentItem(i);
        } else {
            finish();
        }
    }

    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        new BackInterHelper().ShowIntertistialAds(WA_PagerPreviewActivity.this, new BackInterHelper.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onBack();
            }
        });
    }

    private void onBack() {
        super.onBackPressed();
    }
}
