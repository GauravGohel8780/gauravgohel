package com.wapp.status.saver.downloader.fontstyle.more;

import android.content.Context;
import android.content.SharedPreferences;

import com.wapp.status.saver.downloader.fontstyle.interfaces.Style;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Objects;

public class Font_genrateActivty {
    private static final String csf_pn = "stylish_position.xml";
    private ArrayList<Style> csf_mencode = Font_changeActivity.makeStyle();
    Context mContext;

    public Font_genrateActivty(Context context) {
        this.mContext = context;
        long currentTimeMillis = System.currentTimeMillis();
        if (context != null) {
            sortEncoders(context);
        }
        PrintStream printStream = System.out;
        printStream.println("time = " + (System.currentTimeMillis() - currentTimeMillis));
    }

    private void sortEncoders(Context context) {
        final HashMap hashMap = new HashMap();
        for (int i = 0; i < this.csf_mencode.size(); i++) {
            hashMap.put(this.csf_mencode.get(i), Integer.valueOf(i));
        }
        SharedPreferences sharedPreferences = context.getSharedPreferences(csf_pn, 0);
        if (sharedPreferences.getInt(Integer.toHexString(this.csf_mencode.get(0).hashCode()), -1) == -1) {
            SharedPreferences.Editor edit = sharedPreferences.edit();
            for (int i2 = 0; i2 < this.csf_mencode.size(); i2++) {
                edit.putInt(Integer.toHexString(this.csf_mencode.get(i2).hashCode()), i2);
            }
            edit.apply();
        }
        for (int i3 = 0; i3 < this.csf_mencode.size(); i3++) {
            Style style = this.csf_mencode.get(i3);
            hashMap.put(style, Integer.valueOf(sharedPreferences.getInt(Integer.toHexString(style.hashCode()), i3)));
        }
        Collections.sort(this.csf_mencode, new Comparator<Style>() {
            public int compare(Style style, Style style2) {
                Integer num = (Integer) hashMap.get(style);
                Objects.requireNonNull(num);
                Integer num2 = (Integer) hashMap.get(style2);
                Objects.requireNonNull(num2);
                return num.compareTo(num2);
            }
        });
    }

    public ArrayList<String> generate(String str) {
        ArrayList<String> arrayList = new ArrayList<>();
        Iterator<Style> it = this.csf_mencode.iterator();
        while (it.hasNext()) {
            arrayList.add(it.next().generate(str));
        }
        return arrayList;
    }
}