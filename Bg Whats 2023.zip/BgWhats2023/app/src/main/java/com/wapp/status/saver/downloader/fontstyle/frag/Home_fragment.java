package com.wapp.status.saver.downloader.fontstyle.frag;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.fragment.app.Fragment;

import com.sk.SDKX.InterHelper;
import com.sk.SDKX.NativeHelper;
import com.sk.SDKX.NativeSmallHelper;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.Activity.I_EmotionActivity;
import com.wapp.status.saver.downloader.fontstyle.Activity.I_ShowActivity;


public class Home_fragment extends Fragment implements View.OnClickListener {
    String KEY = "Home";
    Activity context;
    LinearLayout csf_i1;
    LinearLayout csf_i10;
    LinearLayout csf_i11;
    LinearLayout csf_i13;
    LinearLayout csf_i2;
    LinearLayout csf_i3;
    LinearLayout csf_i6;
    LinearLayout csf_i7;
    LinearLayout csf_i8;
    int currentCounter = 1;
    Intent intent;

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.i_home, viewGroup, false);

       new NativeHelper().ShowNativeAds(context, (ViewGroup) inflate.findViewById(R.id.llnative));

        csf_i1 = inflate.findViewById(R.id.csf_i1);
        csf_i2 = inflate.findViewById(R.id.csf_i2);
        csf_i3 = inflate.findViewById(R.id.csf_i3);
        csf_i7 = inflate.findViewById(R.id.csf_i7);
        csf_i8 = inflate.findViewById(R.id.csf_i8);
        csf_i11 = inflate.findViewById(R.id.csf_i11);
        csf_i10 = inflate.findViewById(R.id.csf_i10);
        csf_i13 = inflate.findViewById(R.id.csf_i13);

        csf_i1.setOnClickListener(this);
        csf_i2.setOnClickListener(this);
        csf_i3.setOnClickListener(this);
        csf_i7.setOnClickListener(this);
        csf_i8.setOnClickListener(this);
        csf_i11.setOnClickListener(this);
        csf_i10.setOnClickListener(this);
        csf_i13.setOnClickListener(this);
        return inflate;
    }


    @Override
    public void onAttach(Context context2) {
        super.onAttach(context2);
        this.context = (Activity) context2;
    }

    public void onClick(View view) {
        if (view == this.csf_i1) {
            new InterHelper().ShowIntertistialAds( context, new InterHelper.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    Intent intent = new Intent(Home_fragment.this.context, I_ShowActivity.class);
                    intent.putExtra(Home_fragment.this.KEY, 1);
                    startActivity(intent);
                }
            });
        }
        if (view == this.csf_i2) {
            new InterHelper().ShowIntertistialAds( context, new InterHelper.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    Intent intent = new Intent(Home_fragment.this.context, I_ShowActivity.class);
                    intent.putExtra(Home_fragment.this.KEY, 2);
                    startActivity(intent);
                }
            });
        }
        if (view == this.csf_i3) {
            new InterHelper().ShowIntertistialAds(context, new InterHelper.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    intent = new Intent(Home_fragment.this.context, I_EmotionActivity.class);
                    startActivity(intent);
                }
            });
        }
        if (view == this.csf_i10) {
            new InterHelper().ShowIntertistialAds( context, new InterHelper.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    Intent intent = new Intent(Home_fragment.this.context, I_ShowActivity.class);
                    intent.putExtra(Home_fragment.this.KEY, 5);
                    startActivity(intent);
                }
            });
        }
        if (view == this.csf_i7) {
            new InterHelper().ShowIntertistialAds(context, new InterHelper.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    Intent intent = new Intent(Home_fragment.this.context, I_ShowActivity.class);
                    intent.putExtra(Home_fragment.this.KEY, 6);
                    startActivity(intent);
                }
            });
        }
        if (view == this.csf_i8) {
            new InterHelper().ShowIntertistialAds(context, new InterHelper.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    Intent intent = new Intent(Home_fragment.this.context, I_ShowActivity.class);
                    intent.putExtra(Home_fragment.this.KEY, 8);
                    startActivity(intent);
                }
            });
        }
        if (view == this.csf_i13) {
            new InterHelper().ShowIntertistialAds(context, new InterHelper.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    Intent intent = new Intent(Home_fragment.this.context, I_ShowActivity.class);
                    intent.putExtra(Home_fragment.this.KEY, 9);
                    startActivity(intent);
                }
            });
        }
        if (view == this.csf_i11) {
            new InterHelper().ShowIntertistialAds(context, new InterHelper.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    Intent intent = new Intent(Home_fragment.this.context, I_ShowActivity.class);
                    intent.putExtra(Home_fragment.this.KEY, 11);
                    startActivity(intent);
                }
            });
        }
        this.currentCounter++;
    }


}