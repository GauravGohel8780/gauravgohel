package com.wapp.status.saver.downloader;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.sk.SDKX.BackInterHelper;
import com.sk.SDKX.InterHelper;
import com.sk.SDKX.NativeHelper;
import com.wapp.status.saver.downloader.fontstyle.Activity.HomeActivity;
import com.wapp.status.saver.downloader.statussaver.WA_DirectActivity;
import com.wapp.status.saver.downloader.statussaver.WA_MyStatusActivity;
import com.wapp.status.saver.downloader.statussaver.WA_RecStatusActivity;
import com.wapp.status.saver.downloader.statussaver.waweb.WAWebActivity;

public class I_Secondd_Activity extends AppCompatActivity implements View.OnClickListener {
    String[] permissionsList = {"android.permission.WRITE_EXTERNAL_STORAGE"};
    LinearLayout directBtn;
    LinearLayout recentBtn;
    LinearLayout statusBtn;
    LinearLayout wbWebBtn;
    LinearLayout text_style;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_isecondd);
        new NativeHelper().ShowNativeAds(this, (ViewGroup) findViewById(R.id.llnative));
        bindd();
    }

    private void bindd() {
        recentBtn = findViewById(R.id.recentBtn);
        recentBtn.setOnClickListener(this);
        statusBtn = findViewById(R.id.statusBtn);
        statusBtn.setOnClickListener(this);
        directBtn = findViewById(R.id.directBtn);
        directBtn.setOnClickListener(this);
        wbWebBtn = findViewById(R.id.wbWebBtn);
        wbWebBtn.setOnClickListener(this);
        text_style = findViewById(R.id.text_style);
        text_style.setOnClickListener(this);
    }

    public static boolean checkPermissions(Context context, String... strArr) {
        if (context == null || strArr == null) {
            return true;
        }
        for (String checkSelfPermission : strArr) {
            if (ContextCompat.checkSelfPermission(context, checkSelfPermission) != 0) {
                return false;
            }
        }
        return true;
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.directBtn:
                if (!checkPermissions(this, this.permissionsList)) {
                    ActivityCompat.requestPermissions(this, this.permissionsList, 21);
                    return;
                } else {
                    new InterHelper().ShowIntertistialAds(I_Secondd_Activity.this, new InterHelper.OnIntertistialAdsListner() {
                        @Override
                        public void onAdsDismissed() {
                            startActivity(new Intent(I_Secondd_Activity.this, WA_DirectActivity.class));
                        }
                    });
                    return;
                }
            case R.id.recentBtn:
                if (!checkPermissions(this, this.permissionsList)) {
                    ActivityCompat.requestPermissions(this, this.permissionsList, 21);
                    return;
                } else {
                    new InterHelper().ShowIntertistialAds(I_Secondd_Activity.this, new InterHelper.OnIntertistialAdsListner() {
                        @Override
                        public void onAdsDismissed() {
                            startActivity(new Intent(I_Secondd_Activity.this, WA_RecStatusActivity.class));
                        }
                    });
                    return;
                }
            case R.id.statusBtn:
                if (!checkPermissions(this, this.permissionsList)) {
                    ActivityCompat.requestPermissions(this, this.permissionsList, 21);
                    return;
                } else {
                    new InterHelper().ShowIntertistialAds(I_Secondd_Activity.this, new InterHelper.OnIntertistialAdsListner() {
                        @Override
                        public void onAdsDismissed() {
                            startActivity(new Intent(I_Secondd_Activity.this, WA_MyStatusActivity.class));
                        }
                    });
                    return;
                }
            case R.id.wbWebBtn:
                if (!checkPermissions(this, this.permissionsList)) {
                    ActivityCompat.requestPermissions(this, this.permissionsList, 21);
                    return;
                } else {
                    new InterHelper().ShowIntertistialAds(I_Secondd_Activity.this, new InterHelper.OnIntertistialAdsListner() {
                        @Override
                        public void onAdsDismissed() {
                            startActivity(new Intent(I_Secondd_Activity.this, WAWebActivity.class));
                        }
                    });
                    return;
                }
            case R.id.text_style:
                if (!checkPermissions(this, this.permissionsList)) {
                    ActivityCompat.requestPermissions(this, this.permissionsList, 21);
                    return;
                } else {
                    new InterHelper().ShowIntertistialAds(I_Secondd_Activity.this, new InterHelper.OnIntertistialAdsListner() {
                        @Override
                        public void onAdsDismissed() {
                            startActivity(new Intent(I_Secondd_Activity.this, HomeActivity.class));
                        }
                    });
                    return;
                }
            default:
                return;
        }
    }
     @Override
    public void onBackPressed() {
        super.onBackPressed();
        new BackInterHelper().ShowIntertistialAds(I_Secondd_Activity.this, new BackInterHelper.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onBack();
            }
        });
    }

    private void onBack() {
        super.onBackPressed();
    }
}