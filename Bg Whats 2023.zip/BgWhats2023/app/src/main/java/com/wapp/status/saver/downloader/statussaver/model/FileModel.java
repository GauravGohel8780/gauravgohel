package com.wapp.status.saver.downloader.statussaver.model;

import android.os.Parcel;
import android.os.Parcelable;

public class FileModel implements Parcelable {
    public static final Creator<FileModel> CREATOR = new Creator<FileModel>() {
        public FileModel createFromParcel(Parcel parcel) {
            return new FileModel(parcel);
        }

        public FileModel[] newArray(int i) {
            return new FileModel[i];
        }
    };
    private String filename;
    private String filepath;
    public boolean selected = false;
    private String size;

    public int describeContents() {
        return 0;
    }

    public boolean isSelected() {
        return this.selected;
    }

    public void setSelected(boolean z) {
        this.selected = z;
    }

    public FileModel(String str, String str2) {
        this.filepath = str;
        this.filename = str2;
    }

    protected FileModel(Parcel parcel) {
        this.filename = parcel.readString();
        this.filepath = parcel.readString();
    }

    public String getFileName() {
        return this.filename;
    }

    public String getFilePath() {
        return this.filepath;
    }

    public void setFileName(String str) {
        this.filename = str;
    }

    public void setFilePath(String str) {
        this.filepath = str;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.filename);
        parcel.writeString(this.filepath);
    }
}
