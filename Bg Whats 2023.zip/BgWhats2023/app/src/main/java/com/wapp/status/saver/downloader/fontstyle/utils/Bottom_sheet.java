package com.wapp.status.saver.downloader.fontstyle.utils;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.adpater.Sheet_adpapter;
import com.wapp.status.saver.downloader.fontstyle.interfaces.RecyclerViewItem;

import java.util.ArrayList;
import java.util.Objects;


public class Bottom_sheet {
    Context context;
    BottomSheetDialog csf_bg_1;

    public static void showDialogbox(final Context context2, final EditText editText) {
        View inflate = LayoutInflater.from(context2).inflate(R.layout.fsymbol, (ViewGroup) null);
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context2, R.style.BottomSheetDialog);
        bottomSheetDialog.setContentView(inflate);
        inflate.findViewById(R.id.back_delete).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                int length = editText.getText().length();
                if (length > 0) {
                    editText.getText().delete(length - 1, length);
                }
            }
        });
        inflate.findViewById(R.id.delete).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                editText.getText().clear();
            }
        });
        RadioGroup radioGroup = (RadioGroup) inflate.findViewById(R.id.radio_group_sym);
        radioGroup.check(R.id.rd1);
        final RecyclerView recyclerView = (RecyclerView) inflate.findViewById(R.id.recyclerviewSheet);
        recyclerView.setLayoutManager(new GridLayoutManager(context2, 5));
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (i == R.id.rd1) {
                    Context context = context2;
                    recyclerView.setAdapter(new Sheet_adpapter(context, Bottom_sheet.getcsf_sym1(context.getString(R.string.SYM1)), new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            editText.getEditableText().insert(Math.max(editText.getSelectionStart(), 0), str);
                        }
                    }));
                }
                if (i == R.id.rd2) {
                    Context context2 = null;
                    recyclerView.setAdapter(new Sheet_adpapter(null, Bottom_sheet.getcsf_sym1(context2.getString(R.string.SYM2)), new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            editText.append(str);
                        }
                    }));
                }
                if (i == R.id.rd3) {
                    Context context3 = context2;
                    recyclerView.setAdapter(new Sheet_adpapter(context3, Bottom_sheet.getcsf_sym1(context3.getString(R.string.SYM3)), new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            editText.append(str);
                        }
                    }));
                }
                if (i == R.id.rd4) {
                    Context context4 = context2;
                    recyclerView.setAdapter(new Sheet_adpapter(context4, Bottom_sheet.getcsf_sym1(context4.getString(R.string.SYM4)), new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            editText.append(str);
                        }
                    }));
                }
                if (i == R.id.rd5) {
                    Context context5 = context2;
                    recyclerView.setAdapter(new Sheet_adpapter(context5, Bottom_sheet.getcsf_sym1(context5.getString(R.string.SYM5)), new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            editText.append(str);
                        }
                    }));
                }
                if (i == R.id.rd6) {
                    Context context6 = context2;
                    recyclerView.setAdapter(new Sheet_adpapter(context6, Bottom_sheet.getcsf_sym1(context6.getString(R.string.SYM6)), new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            editText.append(str);
                        }
                    }));
                }
                if (i == R.id.rd7) {
                    Context context7 = context2;
                    recyclerView.setAdapter(new Sheet_adpapter(context7, Bottom_sheet.getcsf_sym1(context7.getString(R.string.SYM7)), new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            editText.append(str);
                        }
                    }));
                }
                if (i == R.id.rd8) {
                    Context context8 = context2;
                    recyclerView.setAdapter(new Sheet_adpapter(context8, Bottom_sheet.getcsf_sym1(context8.getString(R.string.SYM8)), new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            editText.append(str);
                        }
                    }));
                }
                if (i == R.id.rd9) {
                    Context context9 = context2;
                    recyclerView.setAdapter(new Sheet_adpapter(context9, Bottom_sheet.getcsf_sym1(context9.getString(R.string.SYM9)), new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            editText.append(str);
                        }
                    }));
                }
                if (i == R.id.rd10) {
                    Context context10 = context2;
                    recyclerView.setAdapter(new Sheet_adpapter(context10, Bottom_sheet.getcsf_sym1(context10.getString(R.string.SYM10)), new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            editText.getEditableText().insert(Math.max(editText.getSelectionStart(), 0), str);
                        }
                    }));
                }
                if (i == R.id.rd11) {
                    Context context11 = context2;
                    recyclerView.setAdapter(new Sheet_adpapter(context11, Bottom_sheet.getcsf_sym1(context11.getString(R.string.SYM11)), new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            editText.append(str);
                        }
                    }));
                }
                if (i == R.id.rd12) {
                    Context context12 = context2;
                    recyclerView.setAdapter(new Sheet_adpapter(context12, Bottom_sheet.getcsf_sym1(context12.getString(R.string.SYM12)), new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            editText.append(str);
                        }
                    }));
                }
                if (i == R.id.rd13) {
                    Context context13 = context2;
                    recyclerView.setAdapter(new Sheet_adpapter(context13, Bottom_sheet.getcsf_sym1(context13.getString(R.string.SYM13)), new RecyclerViewItem() {
                        @Override
                        public void onItemClick(int i, String str) {
                            editText.append(str);
                        }
                    }));
                }
            }
        });
        recyclerView.setAdapter(new Sheet_adpapter(context2, getcsf_sym1(context2.getString(R.string.SYM1)), new RecyclerViewItem() {
            @Override
            public void onItemClick(int i, String str) {
                editText.append(str);
            }
        }));
        Window window = bottomSheetDialog.getWindow();
        Objects.requireNonNull(window);
        window.setDimAmount(0.0f);
        bottomSheetDialog.show();
    }

    public static ArrayList<String> getcsf_sym1(String str) {
        String[] split = str.split(" ");
        ArrayList<String> arrayList = new ArrayList<>();
        for (String str2 : split) {
            if (str2 != null && !str2.trim().equals("")) {
                arrayList.add(str2);
            }
        }
        return arrayList;
    }

    public void styleBottom(Context context2, final String str) {
        final Copy_han copy_han = new Copy_han(context2);
        this.csf_bg_1 = new BottomSheetDialog(context2, R.style.BottomSheetDialog);
        View inflate = LayoutInflater.from(context2).inflate(R.layout.bottom_pre_act, (ViewGroup) null);
        inflate.findViewById(R.id.csf_c_btn).setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                copy_han.copy(str);
            }
        });
        inflate.findViewById(R.id.csf_shr_btn).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.Share(str);
            }
        });
        inflate.findViewById(R.id.csf_back).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Bottom_sheet.this.csf_bg_1.hide();
            }
        });
        ((TextView) inflate.findViewById(R.id.preview_font)).setText(str);
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context2);
        this.csf_bg_1 = bottomSheetDialog;
        bottomSheetDialog.setContentView(inflate);
        this.csf_bg_1.show();
    }
}