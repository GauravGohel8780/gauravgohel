package com.wapp.status.saver.downloader.fontstyle.frag;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.sk.SDKX.BannerHelper;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.Activity.HomeActivity;
import com.wapp.status.saver.downloader.fontstyle.adpater.Num_adpapter;
import com.wapp.status.saver.downloader.fontstyle.utils.CSF_num_style;
import com.wapp.status.saver.downloader.fontstyle.utils.Num_edit;


public class Num_style_fragment extends Fragment {
    public static String name_number = "0123456789";
    public static Num_adpapter numberAdapter = null;
    public static int type = 1;
    ImageView back;
    ImageView close;
    Context context;
    EditText csf_i_p_t;
    RecyclerView recycler_view;

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.num_style_frag, viewGroup, false);
        new BannerHelper().ShowBannerAds(getActivity(), (ViewGroup) inflate.findViewById(R.id.banner));
        this.csf_i_p_t = (EditText) inflate.findViewById(R.id.csf_in_style);
        recycler_view = (RecyclerView) inflate.findViewById(R.id.recycler_view);
        recycler_view.setLayoutManager(new LinearLayoutManager(this.context));
        Num_adpapter num_adpapter = new Num_adpapter(this.context, CSF_num_style.csf_num1, CSF_num_style.numberStyle, name_number, type);
        numberAdapter = num_adpapter;
        this.recycler_view.setAdapter(num_adpapter);
        this.csf_i_p_t.addTextChangedListener(new Num_edit());
        close = (ImageView) inflate.findViewById(R.id.csf_cls_btn);
        back = (ImageView) inflate.findViewById(R.id.backBtn);
        close.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                int length = Num_style_fragment.this.csf_i_p_t.getText().length();
                if (length > 0) {
                    Num_style_fragment.this.csf_i_p_t.getText().delete(length - 1, length);
                }
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Num_style_fragment.this.startActivity(new Intent(Num_style_fragment.this.context, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                Num_style_fragment.this.getActivity().finish();
            }
        });
        this.close.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View view) {
                Num_style_fragment.this.csf_i_p_t.getText().clear();
                return false;
            }
        });
        return inflate;
    }

    @Override
    public void onAttach(Context context2) {
        super.onAttach(context2);
        this.context = context2;
    }
}