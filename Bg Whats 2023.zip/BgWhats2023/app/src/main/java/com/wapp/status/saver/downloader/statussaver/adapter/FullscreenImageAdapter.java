package com.wapp.status.saver.downloader.statussaver.adapter;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;
import com.sk.SDKX.InterHelper;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.statussaver.WA_VideoActivity;
import com.wapp.status.saver.downloader.statussaver.model.StatusModel;
import com.wapp.status.saver.downloader.statussaver.util.Utils;

import java.util.ArrayList;


public class FullscreenImageAdapter extends PagerAdapter {
    Activity activity;
    ArrayList<StatusModel> imageList;

    public FullscreenImageAdapter(Activity activity2, ArrayList<StatusModel> arrayList) {
        this.activity = activity2;
        this.imageList = arrayList;
    }

    public Object instantiateItem(ViewGroup viewGroup, final int i) {
        View inflate = LayoutInflater.from(this.activity).inflate(R.layout.preview_list_item, viewGroup, false);
        ImageView imageView = (ImageView) inflate.findViewById(R.id.imageView);
        ImageView imageView2 = (ImageView) inflate.findViewById(R.id.iconplayer);
        if (!Utils.getBack(this.imageList.get(i).getFilePath(), "((\\.mp4|\\.webm|\\.ogg|\\.mpK|\\.avi|\\.mkv|\\.flv|\\.mpg|\\.wmv|\\.vob|\\.ogv|\\.mov|\\.qt|\\.rm|\\.rmvb\\.|\\.asf|\\.m4p|\\.m4v|\\.mp2|\\.mpeg|\\.mpe|\\.mpv|\\.m2v|\\.3gp|\\.f4p|\\.f4a|\\.f4b|\\.f4v)$)").isEmpty()) {
            imageView2.setVisibility(View.VISIBLE);
        } else {
            imageView2.setVisibility(View.GONE);
        }
        Glide.with(this.activity).load(this.imageList.get(i).getFilePath()).into(imageView);
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (!Utils.getBack(FullscreenImageAdapter.this.imageList.get(i).getFilePath(), "((\\.mp4|\\.webm|\\.ogg|\\.mpK|\\.avi|\\.mkv|\\.flv|\\.mpg|\\.wmv|\\.vob|\\.ogv|\\.mov|\\.qt|\\.rm|\\.rmvb\\.|\\.asf|\\.m4p|\\.m4v|\\.mp2|\\.mpeg|\\.mpe|\\.mpv|\\.m2v|\\.3gp|\\.f4p|\\.f4a|\\.f4b|\\.f4v)$)").isEmpty()) {
                    com.wapp.status.saver.downloader.statussaver.fragments.Utils.mPath = FullscreenImageAdapter.this.imageList.get(i).getFilePath();
                    new InterHelper().ShowIntertistialAds(activity, new InterHelper.OnIntertistialAdsListner() {
                        @Override
                        public void onAdsDismissed() {
                            FullscreenImageAdapter.this.activity.startActivity(new Intent(FullscreenImageAdapter.this.activity, WA_VideoActivity.class));
                        }
                    });
                }
            }
        });
        viewGroup.addView(inflate);
        return inflate;
    }

    public int getCount() {
        return this.imageList.size();
    }

    public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
        viewGroup.removeView((RelativeLayout) obj);
    }

    public boolean isViewFromObject(View view, Object obj) {
        return view == ((RelativeLayout) obj);
    }
}
