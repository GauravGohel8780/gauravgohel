package com.wapp.status.saver.downloader.statussaver.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;

import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.sk.SDKX.InterHelper;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.statussaver.WA_PagerPreviewActivity;
import com.wapp.status.saver.downloader.statussaver.fragments.Utils;
import com.wapp.status.saver.downloader.statussaver.model.StatusModel;

import java.io.File;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;


public class StaPhotoAdapter extends BaseAdapter {
    List<StatusModel> arrayList;
    Activity context;
    LayoutInflater inflater;
    public OnCheckboxListener onCheckboxListener;
    int width;
    View inflate;
    private ImageView play;

    public interface OnCheckboxListener {
        void onCheckboxListener(View view, List<StatusModel> list);
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public StaPhotoAdapter(Activity fragment, List<StatusModel> list, OnCheckboxListener onCheckboxListener2) {
        this.context = fragment;
        this.arrayList = list;
        this.inflater = (LayoutInflater) fragment.getSystemService("layout_inflater");
        this.width = fragment.getResources().getDisplayMetrics().widthPixels;
        this.onCheckboxListener = onCheckboxListener2;
    }

    public int getCount() {
        return this.arrayList.size();
    }

    public Object getItem(int i) {
        return Integer.valueOf(i);
    }

    public View getView(final int i, View view, ViewGroup viewGroup) {
        inflate = this.inflater.inflate(R.layout.ins_row_video, (ViewGroup) null);
        play = (ImageView) inflate.findViewById(R.id.play);
        if (isVideoFile(this.arrayList.get(i).getFilePath())) {
            play.setVisibility(View.VISIBLE);
        } else {
            play.setVisibility(View.GONE);
        }
        ((ImageView) inflate.findViewById(R.id.share)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                StaPhotoAdapter staPhotoAdapter = StaPhotoAdapter.this;
                staPhotoAdapter.share(staPhotoAdapter.arrayList.get(i).getFilePath());
            }
        });
        int i2 = this.width;
        inflate.setLayoutParams(new AbsListView.LayoutParams((i2 * 460) / 1080, (i2 * 460) / 1080));
        Glide.with(this.context).load(this.arrayList.get(i).getFilePath()).into((ImageView) inflate.findViewById(R.id.gridImageVideo));
        CheckBox checkBox = (CheckBox) inflate.findViewById(R.id.checkbox);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                arrayList.get(i).setSelected(z);
                if (onCheckboxListener != null) {
                    onCheckboxListener.onCheckboxListener(compoundButton, arrayList);
                }
            }
        });
        if (this.arrayList.get(i).isSelected()) {
            checkBox.setChecked(true);
        } else {
            checkBox.setChecked(false);
        }
        inflate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                   new InterHelper().ShowIntertistialAds( context, new InterHelper.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    Log.e("click", "click");
                    Intent intent = new Intent(context, WA_PagerPreviewActivity.class);
                    intent.putParcelableArrayListExtra("images", (ArrayList) arrayList);
                    intent.putExtra("position", i);
                    intent.putExtra("statusdownload", "download");
                    context.startActivity(intent);
                }});
            }
        });
        return inflate;
    }


    public void share(String str) {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.addFlags(1);
        intent.setType("video/*");
        Context applicationContext = this.context.getApplicationContext();
        intent.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(applicationContext, this.context.getApplicationContext().getPackageName() + ".provider", new File(str)));
        this.context.startActivity(Intent.createChooser(intent, "Share via"));
    }

    public boolean isVideoFile(String str) {
        String guessContentTypeFromName = URLConnection.guessContentTypeFromName(str);
        return guessContentTypeFromName != null && guessContentTypeFromName.startsWith(Utils.VIDEO);
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        Log.d("MyAdapter", "onActivityResult");
    }
}
