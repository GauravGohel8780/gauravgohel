package com.wapp.status.saver.downloader.statussaver.waweb;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import androidx.core.content.FileProvider;

import com.wapp.status.saver.downloader.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;



public class BlobDownloader {
    public static final String JsInstance = "Downloader";
    private static String lastDownloadBlob = "";
    private static long lastDownloadTime;
    private Context context;
    private final long sameFileDownloadTimeout = 100;

    public BlobDownloader(Context context2) {
        this.context = context2;
    }

    @JavascriptInterface
    public void getBase64FromBlobData(String str) throws IOException {
        Log.d(WAWebActivity.DEBUG_TAG, "Download triggered " + System.currentTimeMillis());
        lastDownloadTime = System.currentTimeMillis();
        if (System.currentTimeMillis() - lastDownloadTime < 100) {
            Log.d(WAWebActivity.DEBUG_TAG, "Download within sameFileDownloadTimeout");
            if (lastDownloadBlob.equals(str)) {
                Log.d(WAWebActivity.DEBUG_TAG, "Blobs match, ignoring download");
                return;
            }
            Log.d(WAWebActivity.DEBUG_TAG, "Blobs do not match, downloading");
            lastDownloadBlob = str;
            convertBase64StringToFileAndStoreIt(str);
        }
    }

    public static String getBase64StringFromBlobUrl(String str) {
        if (!str.startsWith("blob")) {
            return "javascript: console.log('It is not a Blob URL');";
        }
        return "javascript: var xhr = new XMLHttpRequest();xhr.open('GET', '" + str + "', true);xhr.responseType = 'blob';xhr.onload = function(e) {    if (this.status == 200) {        var blobFile = this.response;        var reader = new FileReader();        reader.readAsDataURL(blobFile);        reader.onloadend = function() {            base64data = reader.result;            " + JsInstance + ".getBase64FromBlobData(base64data);        }    }};xhr.send();";
    }

    private void convertBase64StringToFileAndStoreIt(String str) throws IOException {
        Notification notification;
        int currentTimeMillis = (int) System.currentTimeMillis();
        String[] split = str.split(",");
        String lookupExt = MimeTypes.lookupExt(split[0]);
        if (lookupExt == null) {
            String str2 = split[0];
            lookupExt = "." + str2.substring(str2.indexOf(47) + 1, str2.indexOf(59));
        }
        String str3 = "WAWTG_" + new SimpleDateFormat("yyyyMMdd-hhmmss").format(new Date()) + lookupExt;
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + File.separator + str3);
        byte[] decode = Base64.decode(str.replaceFirst(split[0], ""), 0);
        FileOutputStream fileOutputStream = new FileOutputStream(file, false);
        fileOutputStream.write(decode);
        fileOutputStream.flush();
        if (file.exists()) {
            Intent intent = new Intent();
            intent.setAction("android.intent.action.VIEW");
            intent.setDataAndType(FileProvider.getUriForFile(this.context, this.context.getApplicationContext().getPackageName() + ".provider", file), MimeTypeMap.getSingleton().getMimeTypeFromExtension(lookupExt));
            intent.addFlags(1);
            PendingIntent activity = PendingIntent.getActivity(this.context, currentTimeMillis, intent, 268435456);
            NotificationManager notificationManager = (NotificationManager) this.context.getSystemService("notification");
            if (notificationManager != null) {
                if (Build.VERSION.SDK_INT >= 26) {
                    NotificationChannel notificationChannel = new NotificationChannel("Downloads", "name", 2);
                    notification = new Notification.Builder(this.context, "Downloads").setContentText(String.format(this.context.getString(R.string.notification_text_saved_as), new Object[]{str3})).setContentTitle(this.context.getString(R.string.notification_title_tap_to_open)).setContentIntent(activity).setChannelId("Downloads").setSmallIcon(17301623).build();
                    notificationManager.createNotificationChannel(notificationChannel);
                } else {
                    notification = new NotificationCompat.Builder(this.context, "Downloads").setDefaults(-1).setSmallIcon(17301623).setContentIntent(activity).setContentTitle(String.format(this.context.getString(R.string.notification_text_saved_as), new Object[]{str3})).setContentText(this.context.getString(R.string.notification_title_tap_to_open)).build();
                }
                notificationManager.notify(currentTimeMillis, notification);
                Toast.makeText(this.context, R.string.toast_saved_to_downloads_folder, Toast.LENGTH_SHORT).show();
            }
        }
    }
}
