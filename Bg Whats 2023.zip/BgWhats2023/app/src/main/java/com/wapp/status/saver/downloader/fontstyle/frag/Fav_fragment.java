package com.wapp.status.saver.downloader.fontstyle.frag;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.adpater.Fav_adpapter;
import com.wapp.status.saver.downloader.fontstyle.model.Emot;
import com.wapp.status.saver.downloader.fontstyle.utils.SharedPreference;

import java.util.List;


public class Fav_fragment extends Fragment {
    Context csf_cnt;
    List<Emot> csf_fav1;
    Fav_adpapter csf_fsv_adp;
    MaterialToolbar csf_ml;
    RecyclerView recyclerView;
    SharedPreference sharedPreference;
    TextView textView;

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.activity_emotion, viewGroup, false);
        this.sharedPreference = new SharedPreference();
        this.textView = (TextView) inflate.findViewById(R.id.csf_favtext);
        this.csf_ml = (MaterialToolbar) inflate.findViewById(R.id.toolbar);
        this.csf_fav1 = this.sharedPreference.getFavorites(this.csf_cnt);
        recyclerView = (RecyclerView) inflate.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        this.recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        List<Emot> list = this.csf_fav1;
        if (list != null) {
            Fav_adpapter fav_adpapter = new Fav_adpapter(this.csf_cnt, list);
            this.csf_fsv_adp = fav_adpapter;
            this.recyclerView.setAdapter(fav_adpapter);
        }
        List<Emot> list2 = this.csf_fav1;
        if (list2 == null) {
            this.textView.setVisibility(View.VISIBLE);
        } else if (list2.size() == 0) {
            this.textView.setVisibility(View.VISIBLE);
        }
        return inflate;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.csf_cnt = context;
    }
}