package com.wapp.status.saver.downloader.fontstyle.adpater;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.model.Emot;
import com.wapp.status.saver.downloader.fontstyle.utils.Bottom_sheet;
import com.wapp.status.saver.downloader.fontstyle.utils.Copy_han;
import com.wapp.status.saver.downloader.fontstyle.utils.SharedPreference;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Emotion_adpapter extends RecyclerView.Adapter<Emotion_adpapter.MyViewHolder> {
    private final Activity context;
    List<Emot> csf_emot;
    SharedPreference sharedPreference = new SharedPreference();

    public Emotion_adpapter(List<Emot> list, Activity activity) {
        this.csf_emot = list;
        this.context = activity;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(this.context).inflate(R.layout.emotion_itm, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {
        myViewHolder.csf_e.setText(this.csf_emot.get(i).getName());
        myViewHolder.csf_e.setSelected(true);
        myViewHolder.csf_n.setText(String.valueOf(i + 1));
        final Copy_han copy_han = new Copy_han(this.context);
        final String charSequence = myViewHolder.csf_e.getText().toString();
        myViewHolder.csf_c.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.copy(charSequence);
            }
        });
        myViewHolder.share.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.Share(charSequence);
            }
        });
        myViewHolder.csf_cv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                new Bottom_sheet().styleBottom(Emotion_adpapter.this.context, charSequence);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.csf_emot.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView csf_c;
        LinearLayout csf_cv;
        TextView csf_e;
        TextView csf_n;
        ImageView share;

        public MyViewHolder(View view) {
            super(view);
            this.csf_n = (TextView) view.findViewById(R.id.csf_number12);
            this.csf_c = (ImageView) view.findViewById(R.id.csf_cpy_btn);
            this.share = (ImageView) view.findViewById(R.id.csf_shr12);
            this.csf_e = (TextView) view.findViewById(R.id.emoti);
            this.csf_cv = (LinearLayout) view.findViewById(R.id.csf_r1);
        }
    }

    public boolean checkFavoriteItem(Emot emot) {
        ArrayList<Emot> favorites = this.sharedPreference.getFavorites(this.context);
        if (favorites == null) {
            return false;
        }
        Iterator<Emot> it = favorites.iterator();
        while (it.hasNext()) {
            if (it.next().equals(emot)) {
                return true;
            }
        }
        return false;
    }

    public void add(Emot emot) {
        this.csf_emot.add(emot);
        notifyDataSetChanged();
    }
}