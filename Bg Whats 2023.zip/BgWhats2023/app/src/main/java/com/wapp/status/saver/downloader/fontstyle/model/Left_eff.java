package com.wapp.status.saver.downloader.fontstyle.model;

import com.wapp.status.saver.downloader.fontstyle.interfaces.Style;

public class Left_eff implements Style {
    private String left;

    public Left_eff(String str) {
        this.left = str;
    }

    @Override
    public String generate(String str) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) == ' ') {
                sb.append(this.left);
                sb.append(" ");
            } else {
                sb.append(this.left);
                sb.append(str.charAt(i));
            }
        }
        sb.append(this.left);
        return sb.toString();
    }

    public int hashCode() {
        return this.left.hashCode();
    }
}