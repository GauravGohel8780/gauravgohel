package com.wapp.status.saver.downloader.fontstyle.adpater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.utils.Bottom_sheet;
import com.wapp.status.saver.downloader.fontstyle.utils.Copy_han;

import java.util.ArrayList;


public class Font_adpapter extends RecyclerView.Adapter<Font_adpapter.MyViewHolder> {
    private final Context activity;
    private final ArrayList<String> p = new ArrayList<>();

    public Font_adpapter(Context context) {
        this.activity = context;
    }

    public void setData(ArrayList<String> arrayList) {
        this.p.clear();
        this.p.addAll(arrayList);
        notifyDataSetChanged();
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.font_adap, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {
        myViewHolder.description.setText(this.p.get(i));
        myViewHolder.description.setSelected(true);
        myViewHolder.number.setText(String.valueOf(i + 1));
        final Copy_han copy_han = new Copy_han(this.activity);
        final String charSequence = myViewHolder.description.getText().toString();
        myViewHolder.copy.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.copy(charSequence);
            }
        });
        myViewHolder.share.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.Share(charSequence);
            }
        });
        myViewHolder.layout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                new Bottom_sheet().styleBottom(Font_adpapter.this.activity, charSequence);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.p.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView copy;
        TextView description;
        LinearLayout layout;
        TextView number;
        ImageView share;

        private MyViewHolder(View view) {
            super(view);
            this.description = (TextView) view.findViewById(R.id.csf_desc_1);
            this.number = (TextView) view.findViewById(R.id.txt_number);
            this.copy = (ImageView) view.findViewById(R.id.btn_copy);
            this.share = (ImageView) view.findViewById(R.id.csf_shr1);
            this.layout = (LinearLayout) view.findViewById(R.id.csf_lin_clk1);
        }
    }
}