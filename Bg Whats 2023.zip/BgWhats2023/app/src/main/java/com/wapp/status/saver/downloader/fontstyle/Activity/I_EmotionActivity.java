package com.wapp.status.saver.downloader.fontstyle.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListAdapter;

import androidx.appcompat.app.AppCompatActivity;

import com.sk.SDKX.BackInterHelper;
import com.sk.SDKX.BannerHelper;
import com.sk.SDKX.InterHelper;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.adpater.Cust_adpapter;


public class I_EmotionActivity extends AppCompatActivity {
    GridView csf_sg;
    int[] icon = {R.drawable.csf_love, R.drawable.csf_happy, R.drawable.csf_music, R.drawable.csf_animal, R.drawable.csf_angry, R.drawable.csf_sad, R.drawable.csf_splee, R.drawable.csf_excited, R.drawable.csf_hungry, R.drawable.csf_shy, R.drawable.csf_other, R.drawable.csf_kiss, R.drawable.csf_smile, R.drawable.csf_laugh};
    String[] logos = {"Love", "Happy", "Music", "Animals", "Angry", "Sad", "Sleeping", "Excited", "Hungry", "Shy", "Other", "Kiss", "Smile", "Laugh"};

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_emotion_grid);
        new BannerHelper().ShowBannerAds(this, (ViewGroup) findViewById(R.id.banner));
        csf_sg = (GridView) findViewById(R.id.csf_grid);
        csf_sg.setAdapter((ListAdapter) new Cust_adpapter(this, this.logos, this.icon));
        csf_sg.setOnItemClickListener(new csf_sgListner());
        findViewById(R.id.backBtn).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                I_EmotionActivity.this.finish();
            }
        });
    }

    private class csf_sgListner implements AdapterView.OnItemClickListener {
        private csf_sgListner() {
        }

        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, final int i, long j) {
            new InterHelper().ShowIntertistialAds( I_EmotionActivity.this, new InterHelper.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    Intent intent = new Intent(I_EmotionActivity.this.getApplicationContext(), EmotionActivity.class);
                    intent.putExtra("image", I_EmotionActivity.this.logos[i]);
                    intent.putExtra("P", i);
                    intent.putExtra("name", I_EmotionActivity.this.logos[i]);
                    I_EmotionActivity.this.startActivity(intent);
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        new BackInterHelper().ShowIntertistialAds(I_EmotionActivity.this, new BackInterHelper.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onBack();
            }
        });
    }

    private void onBack() {
        super.onBackPressed();
    }
}