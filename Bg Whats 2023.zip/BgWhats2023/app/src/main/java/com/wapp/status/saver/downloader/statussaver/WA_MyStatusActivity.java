package com.wapp.status.saver.downloader.statussaver;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.sk.SDKX.BackInterHelper;
import com.sk.SDKX.BannerHelper;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.statussaver.fragments.WA_StaPhotos;
import com.wapp.status.saver.downloader.statussaver.fragments.WA_StaVideos;

import java.util.ArrayList;
import java.util.List;


public class WA_MyStatusActivity extends AppCompatActivity {
    ImageView backIV;
    RelativeLayout header;
    TabLayout tabLayout;
    TextView topTV;
    ViewPager viewPager;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_my_status);
        new BannerHelper().ShowBannerAds(this, (ViewGroup) findViewById(R.id.banner));
        bind();
    }

    private void bind() {
        header = (RelativeLayout) findViewById(R.id.header);
        backIV = (ImageView) findViewById(R.id.backIV);
        backIV.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                onBackPressed();
            }
        });
        topTV = (TextView) findViewById(R.id.topTV);
        ViewPager viewPager2 = (ViewPager) findViewById(R.id.pagerdiet);
        this.viewPager = viewPager2;
        setupViewPager(viewPager2);
        tabLayout = (TabLayout) findViewById(R.id.tab_layoutdiet);
        tabLayout.setupWithViewPager(this.viewPager);
        setupTabIcons();
        tabLayout.addOnTabSelectedListener((TabLayout.OnTabSelectedListener) new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                showInterAd(WA_MyStatusActivity.this, null, 0);

            }
        });
    }

    public static void showInterAd(final Activity activity, final Intent intent, final int i) {
        startActivity(activity, intent, i);
        return;
    }

    static void startActivity(Activity activity, Intent intent, int i) {
        if (intent != null) {
            activity.startActivityForResult(intent, i);
        }
    }


    private void setupTabIcons() {
        TextView textView = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, (ViewGroup) null);
        textView.setText("Photos");
        this.tabLayout.getTabAt(0).setCustomView(textView);
        TextView textView2 = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, (ViewGroup) null);
        textView2.setText("Videos");
        this.tabLayout.getTabAt(1).setCustomView(textView2);
    }

    private void setupViewPager(ViewPager viewPager2) {
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        viewPagerAdapter.addFragment(new WA_StaPhotos(), "Photos");
        viewPagerAdapter.addFragment(new WA_StaVideos(), "Videos");
        viewPager2.setAdapter(viewPagerAdapter);
    }

    public class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList();
        private final List<String> mFragmentTitleList = new ArrayList();

        public ViewPagerAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        @Override
        public Fragment getItem(int i) {
            return this.mFragmentList.get(i);
        }

        @Override
        public int getCount() {
            return this.mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String str) {
            this.mFragmentList.add(fragment);
            this.mFragmentTitleList.add(str);
        }

        @Override
        public CharSequence getPageTitle(int i) {
            return this.mFragmentTitleList.get(i);
        }
    }

   @Override
    public void onBackPressed() {
        super.onBackPressed();
        new BackInterHelper().ShowIntertistialAds(WA_MyStatusActivity.this, new BackInterHelper.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onBack();
            }
        });
    }

    private void onBack() {
        super.onBackPressed();
    }
}