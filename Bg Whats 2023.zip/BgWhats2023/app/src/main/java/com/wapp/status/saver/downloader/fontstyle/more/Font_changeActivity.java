package com.wapp.status.saver.downloader.fontstyle.more;

import com.wapp.status.saver.downloader.fontstyle.Zalgo;
import com.wapp.status.saver.downloader.fontstyle.interfaces.Style;
import com.wapp.status.saver.downloader.fontstyle.model.Blueeff;
import com.wapp.status.saver.downloader.fontstyle.model.Left_eff;
import com.wapp.status.saver.downloader.fontstyle.model.Replace_eff;
import com.wapp.status.saver.downloader.fontstyle.model.Rgt_stle;
import com.wapp.status.saver.downloader.fontstyle.model.Rht_eff;

import java.util.ArrayList;
import java.util.Iterator;

public class Font_changeActivity {

    private static ArrayList<String> createLeft() {
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("๖ۣۜ");
        arrayList.add("⸾");
        arrayList.add("⸽");
        arrayList.add("⸾⸾");
        arrayList.add("⸽⸽");
        arrayList.add("☢");
        arrayList.add("☣");
        arrayList.add("☠");
        arrayList.add("⚠");
        arrayList.add("☤");
        arrayList.add("⚕");
        arrayList.add("⚚");
        arrayList.add("†");
        arrayList.add("☯");
        arrayList.add("⚖");
        arrayList.add("☮");
        arrayList.add("⚘");
        arrayList.add("⚔");
        arrayList.add("☭");
        arrayList.add("⚒");
        arrayList.add("⚓");
        arrayList.add("⚛");
        arrayList.add("⚜");
        arrayList.add("⚡");
        arrayList.add("⚶");
        arrayList.add("☥");
        arrayList.add("✠");
        arrayList.add("✙");
        arrayList.add("✞");
        arrayList.add("✟");
        arrayList.add("✧");
        arrayList.add("⋆");
        arrayList.add("★");
        arrayList.add("☆");
        arrayList.add("✪");
        arrayList.add("✫");
        arrayList.add("✬");
        arrayList.add("✭");
        arrayList.add("✮");
        arrayList.add("✯");
        arrayList.add("☸");
        arrayList.add("✵");
        arrayList.add("❂");
        arrayList.add("☘");
        arrayList.add("♡");
        arrayList.add("♥");
        arrayList.add("❤");
        arrayList.add("⚘");
        arrayList.add("❀");
        arrayList.add("❃");
        arrayList.add("❁");
        arrayList.add("✼");
        arrayList.add("☀");
        arrayList.add("✌");
        arrayList.add("♫");
        arrayList.add("♪");
        arrayList.add("☃");
        arrayList.add("❄");
        arrayList.add("❅");
        arrayList.add("❆");
        arrayList.add("☕");
        arrayList.add("☂");
        arrayList.add("❦");
        arrayList.add("✈");
        arrayList.add("♕");
        arrayList.add("♛");
        arrayList.add("♖");
        arrayList.add("♜");
        arrayList.add("☁");
        arrayList.add("☾");
        return arrayList;
    }

    private static ArrayList<Pair<String, String>> createLeftRightPair() {
        ArrayList<Pair<String, String>> arrayList = new ArrayList<>();
        arrayList.add(new Pair<>("⫷", "⫸"));
        arrayList.add(new Pair<>("╰", "╯"));
        arrayList.add(new Pair<>("╭", "╮"));
        arrayList.add(new Pair<>("╟", "╢"));
        arrayList.add(new Pair<>("╚", "╝"));
        arrayList.add(new Pair<>("╔", "╗"));
        arrayList.add(new Pair<>("⚞", "⚟"));
        arrayList.add(new Pair<>("⟅", "⟆"));
        arrayList.add(new Pair<>("⟦", "⟧"));
        arrayList.add(new Pair<>("☾", "☽"));
        arrayList.add(new Pair<>("【", "】"));
        arrayList.add(new Pair<>("〔", "〕"));
        arrayList.add(new Pair<>("《", "》"));
        arrayList.add(new Pair<>("〘", "〙"));
        arrayList.add(new Pair<>("『", "』"));
        arrayList.add(new Pair<>("┋", "┋"));
        arrayList.add(new Pair<>("[̲̅", "̲̅]"));
        return arrayList;
    }

    private static ArrayList<String> createRight() {
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("⃠");
        arrayList.add("̾");
        arrayList.add("͚");
        arrayList.add("̫");
        arrayList.add("̏");
        arrayList.add("͒");
        arrayList.add("̐");
        arrayList.add("̥");
        arrayList.add("̃");
        arrayList.add("♥");
        arrayList.add("͎");
        arrayList.add("͓̽");
        arrayList.add("̟");
        arrayList.add("͙");
        arrayList.add("̺");
        arrayList.add("͆");
        arrayList.add("̾");
        arrayList.add("̳");
        arrayList.add("̲");
        arrayList.add("̸");
        arrayList.add("̷");
        arrayList.add("̴");
        arrayList.add("̶");
        char[] cArr = Zalgo.UP_CHARS;
        for (char c : cArr) {
            arrayList.add(c + "");
        }
        for (char c2 : Zalgo.DOWN_CHARS) {
            arrayList.add(c2 + "");
        }
        for (char c3 : Zalgo.MID_CHARS) {
            arrayList.add(c3 + "");
        }
        return arrayList;
    }

    public static ArrayList<Style> makeStyle() {
        ArrayList<Style> arrayList = new ArrayList<>();
        arrayList.add(new Blueeff());
        arrayList.addAll(Replace_eff.createStyle());
        Iterator<Pair<String, String>> it = createLeftRightPair().iterator();
        while (it.hasNext()) {
            Pair<String, String> next = it.next();
            arrayList.add(new Rgt_stle(next.first, next.second));
        }
        Iterator<String> it2 = createLeft().iterator();
        while (it2.hasNext()) {
            arrayList.add(new Left_eff(it2.next()));
        }
        Iterator<String> it3 = createRight().iterator();
        while (it3.hasNext()) {
            arrayList.add(new Rht_eff(it3.next()));
        }
        return arrayList;
    }

    public static class Pair<F, S> {
        F first;
        S second;

        Pair(F f, S s) {
            this.first = f;
            this.second = s;
        }
    }
}