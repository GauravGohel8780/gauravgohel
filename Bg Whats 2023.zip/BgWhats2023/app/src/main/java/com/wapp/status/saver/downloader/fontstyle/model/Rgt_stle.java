package com.wapp.status.saver.downloader.fontstyle.model;

import com.wapp.status.saver.downloader.fontstyle.interfaces.Style;

public class Rgt_stle implements Style {
    private String left;
    private String right;

    public Rgt_stle(String str, String str2) {
        this.left = str;
        this.right = str2;
    }

    @Override
    public String generate(String str) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) == ' ') {
                sb.append(" ");
            } else {
                sb.append(this.left);
                sb.append(str.charAt(i));
                sb.append(this.right);
            }
        }
        return sb.toString();
    }

    public int hashCode() {
        return (this.left.hashCode() * 31) + this.right.hashCode();
    }
}