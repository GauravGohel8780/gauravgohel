package com.wapp.status.saver.downloader.fontstyle.frag;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.sk.SDKX.NativeHelper;
import com.wapp.status.saver.downloader.R;
import com.wapp.status.saver.downloader.fontstyle.Activity.HomeActivity;
import com.wapp.status.saver.downloader.fontstyle.Zalgo;
import com.wapp.status.saver.downloader.fontstyle.utils.Copy_han;


public class Giltch_fragment extends Fragment {
    private Activity activity;
    ImageView backBtn;
    ImageView close;
    ImageView copy;
    private CheckBox csf_m_c2;
    private TextView csf_pre_text;
    private EditText csf_text_f2;
    private CheckBox csf_up_c2;
    private CheckBox downCheck;
    private SeekBar intensitySlider;
    ImageView share;

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.gitch_frag, viewGroup, false);
        new NativeHelper().ShowNativeAds(activity, (ViewGroup) inflate.findViewById(R.id.llnative));
        csf_text_f2 = (EditText) inflate.findViewById(R.id.editText);
        close = (ImageView) inflate.findViewById(R.id.csf_close12);
        csf_pre_text = (TextView) inflate.findViewById(R.id.csf_txt_pev);
        intensitySlider = (SeekBar) inflate.findViewById(R.id.seekBar);
        copy = (ImageView) inflate.findViewById(R.id.copy);
        share = (ImageView) inflate.findViewById(R.id.share);
        backBtn = (ImageView) inflate.findViewById(R.id.backBtn);
        backBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                getActivity().finish();
            }
        });
        csf_up_c2 = (CheckBox) inflate.findViewById(R.id.csf_upword);
        csf_m_c2 = (CheckBox) inflate.findViewById(R.id.csf_mid);
        downCheck = (CheckBox) inflate.findViewById(R.id.csf_downwd1);
        csf_up_c2.setChecked(true);
        downCheck.setChecked(true);
        final Copy_han copy_han = new Copy_han(this.activity);
        this.csf_text_f2.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void afterTextChanged(Editable editable) {
                updatePreview();
            }
        });
        this.intensitySlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                updatePreview();
            }
        });
        this.copy.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.copysi(csf_m_z2());
            }
        });
        this.share.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copy_han.Share(csf_m_z2());
            }
        });
        this.csf_up_c2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                updatePreview();
            }
        });
        this.csf_m_c2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                updatePreview();
            }
        });
        this.downCheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                updatePreview();
            }
        });
        this.close.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                int length = csf_text_f2.getText().length();
                if (length > 0) {
                    csf_text_f2.getText().delete(length - 1, length);
                }
            }
        });
        this.close.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View view) {
                csf_text_f2.getText().clear();
                return false;
            }
        });
        return inflate;
    }

    private void updatePreview() {
        this.csf_pre_text.setText(getString(R.string.csf_txt_pev, csf_m_z2()));
    }

    private String csf_m_z2() {
        String obj = this.csf_text_f2.getText().toString();
        int progress = this.intensitySlider.getProgress() + 2;
        int i = this.csf_up_c2.isChecked() ? progress : 0;
        int i2 = this.csf_m_c2.isChecked() ? progress : 0;
        if (!this.downCheck.isChecked()) {
            progress = 0;
        }
        return Zalgo.generate(obj, i, i2, progress);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.activity = (Activity) context;
    }
}