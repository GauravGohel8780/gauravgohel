package com.sk.SDKX;

import android.content.Context;
import android.net.ConnectivityManager;

public class Constant {

    public static String userurl = "aHR0cHM6Ly94bnh2aWRlb3BsYXllci54eXovZ2V0YXBwbWFuYWdlYWRzP2FwcGlkPTM2MA==";

    public static boolean isConnected(Context activity) {
        ConnectivityManager connectivityManager = (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnected();
    }
}
