package com.sk.SDKX;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Base64;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.ads.AdSettings;
import com.facebook.ads.AudienceNetworkAds;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.gson.Gson;

import java.io.UnsupportedEncodingException;

public class AppcompactActivity extends AppCompatActivity {

    AppOpenAd.AppOpenAdLoadCallback loadCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);


    }

    public void ADSinit(final Activity activity, final getDataListner myCallback1) {

        MobileAds.initialize(activity);
        AudienceNetworkAds.initialize(activity);

        AdSettings.setTestMode(true);

        if (SDK.isOnline(this)) {
            String url = fundecode(Constant.userurl);

            getAppSDK(url, activity, myCallback1);
        }

    }

    private void getAppSDK(String url, final Activity activity, final getDataListner myCallback1) {
        try {
            Volley.newRequestQueue(this).add(new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                public void onResponse(String str) {

                    try {

                        String data = new String(str);

                        ManageAdsResponse response = new Gson().fromJson(data, ManageAdsResponse.class);

                        SDK.setResponse(activity, response);

                        if (Preference.getString(activity, "Appislive").equals("yes")) {

                            if (Preference.getString(activity, "AppopenShow").equals("yes")) {
                                try {

                                    loadCallback = new AppOpenAd.AppOpenAdLoadCallback() {
                                        @Override
                                        public void onAdLoaded(@NonNull AppOpenAd appOpenAd) {
                                            super.onAdLoaded(appOpenAd);

                                            FullScreenContentCallback r2 = new FullScreenContentCallback() {
                                                public void onAdDismissedFullScreenContent() {
                                                    myCallback1.onSuccess();
                                                }

                                                public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                                                    myCallback1.onSuccess();
                                                }

                                                public void onAdShowedFullScreenContent() {

                                                }
                                            };

                                            appOpenAd.show(activity);
                                            appOpenAd.setFullScreenContentCallback(r2);

                                        }

                                        @Override
                                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                            super.onAdFailedToLoad(loadAdError);
                                            myCallback1.onSuccess();
                                        }
                                    };
                                    String[] appopenids = Preference.getString(activity, "Am_AppOpen").split("\\$");
                                    AppOpenAd.load(activity, appopenids[0], new AdRequest.Builder().build(), AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback);

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                            } else {
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        new InterHelper().ShowIntertistialAds( activity, new InterHelper.OnIntertistialAdsListner() {
                                            @Override
                                            public void onAdsDismissed() {
                                                myCallback1.onSuccess();
                                            }
                                        });
                                    }
                                }, 4000);
                            }
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        myCallback1.onSuccess();
                    }

                }
            }, new Response.ErrorListener() {
                public void onErrorResponse(VolleyError volleyError) {
                    Log.e("msg", "" + volleyError.toString());

                    SharedPreferences sharedPreferences = activity.getSharedPreferences("SK_SDKX", activity.MODE_PRIVATE);

                    if (!sharedPreferences.getString("Appislive", "no data").equals("yes")) {
                        Preference.putString(activity, "AdsShows", "no");
                    }
                    myCallback1.onError();
                }
            }));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void showAppopen(Activity activity, final getDataListner myCallback1) {
        if (Preference.getString(activity, "Appislive").equals("yes")) {

            if (Preference.getString(activity, "AppopenShow").equals("yes")) {
                try {

                    loadCallback = new AppOpenAd.AppOpenAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull AppOpenAd appOpenAd) {
                            super.onAdLoaded(appOpenAd);

                            FullScreenContentCallback r2 = new FullScreenContentCallback() {
                                public void onAdDismissedFullScreenContent() {
                                    myCallback1.onSuccess();
                                }

                                public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                                    myCallback1.onSuccess();
                                }

                                public void onAdShowedFullScreenContent() {

                                }
                            };

                            appOpenAd.show(activity);
                            appOpenAd.setFullScreenContentCallback(r2);

                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            super.onAdFailedToLoad(loadAdError);
                            myCallback1.onSuccess();
                        }
                    };
                    String[] appopenids = Preference.getString(activity, "Am_AppOpen").split("\\$");
                    AppOpenAd.load(activity, appopenids[0], new AdRequest.Builder().build(), AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback);

                } catch (Exception e) {
                    e.printStackTrace();
                }

            } else {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        new InterHelper().ShowIntertistialAds( activity, new InterHelper.OnIntertistialAdsListner() {
                            @Override
                            public void onAdsDismissed() {
                                myCallback1.onSuccess();
                            }
                        });
                    }
                }, 4000);
            }
        }
    }

    public String fundecode(String str) {
        try {
            return new String(Base64.decode(str, 0), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return "";
        }
    }
}