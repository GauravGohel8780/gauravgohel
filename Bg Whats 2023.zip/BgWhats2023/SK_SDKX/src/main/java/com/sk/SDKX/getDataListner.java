package com.sk.SDKX;

public interface getDataListner {

    void onSuccess();

    void onError();

}
