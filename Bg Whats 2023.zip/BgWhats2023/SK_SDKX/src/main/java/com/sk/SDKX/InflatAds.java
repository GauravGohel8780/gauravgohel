package com.sk.SDKX;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.ads.AdOptionsView;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeBannerAd;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.nativead.NativeAdView;

import java.util.ArrayList;
import java.util.List;

public class InflatAds {
    Context context;

    public InflatAds(Context context) {
        this.context = context;
    }

    public void inflat_admobnative(com.google.android.gms.ads.nativead.NativeAd unifiedNativeAd, ViewGroup viewGroup) {

        SDK.extraarray = Preference.getString(context, "extra").split(",");
        if (SDK.extraarray[0].equals("match")) {
            viewGroup.setVisibility(View.VISIBLE);

            NativeAdView adView = (NativeAdView) ((Activity) context).getLayoutInflater().inflate(R.layout.ads_native_admob, null);

            com.google.android.gms.ads.nativead.MediaView mediaView = adView.findViewById(R.id.ad_media);
            adView.setMediaView(mediaView);
            adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
            adView.setBodyView(adView.findViewById(R.id.ad_body));
            TextView button = adView.findViewById(R.id.ad_call_to_action);

            adView.setCallToActionView(button);
            adView.setIconView(adView.findViewById(R.id.ad_app_icon));
            adView.setPriceView(adView.findViewById(R.id.ad_price));
            adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
            adView.setStoreView(adView.findViewById(R.id.ad_store));
            adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));
            ((TextView) adView.getHeadlineView()).setText(unifiedNativeAd.getHeadline());
            if (unifiedNativeAd.getBody() == null) {
                adView.getBodyView().setVisibility(View.INVISIBLE);
            } else {
                adView.getBodyView().setVisibility(View.VISIBLE);
                ((TextView) adView.getBodyView()).setText(unifiedNativeAd.getBody());
            }

            if (unifiedNativeAd.getCallToAction() == null) {
                adView.getCallToActionView().setVisibility(View.INVISIBLE);
            } else {
                adView.getCallToActionView().setVisibility(View.VISIBLE);
                ((TextView) adView.getCallToActionView()).setText(unifiedNativeAd.getCallToAction());
            }

            if (unifiedNativeAd.getIcon() == null) {
                adView.getIconView().setVisibility(View.GONE);
            } else {
                ((ImageView) adView.getIconView()).setImageDrawable(
                        unifiedNativeAd.getIcon().getDrawable());
                adView.getIconView().setVisibility(View.VISIBLE);
            }

            if (unifiedNativeAd.getPrice() == null) {
                adView.getPriceView().setVisibility(View.INVISIBLE);
            } else {
                adView.getPriceView().setVisibility(View.VISIBLE);
                ((TextView) adView.getPriceView()).setText(unifiedNativeAd.getPrice());
            }

            if (unifiedNativeAd.getStore() == null) {
                adView.getStoreView().setVisibility(View.INVISIBLE);
            } else {
                adView.getStoreView().setVisibility(View.VISIBLE);
                ((TextView) adView.getStoreView()).setText(unifiedNativeAd.getStore());
            }

            if (unifiedNativeAd.getStarRating() == null) {
                adView.getStarRatingView().setVisibility(View.INVISIBLE);
            } else {
                ((RatingBar) adView.getStarRatingView())
                        .setRating(unifiedNativeAd.getStarRating().floatValue());
                adView.getStarRatingView().setVisibility(View.VISIBLE);
            }

            if (unifiedNativeAd.getAdvertiser() == null) {
                adView.getAdvertiserView().setVisibility(View.INVISIBLE);
            } else {
                ((TextView) adView.getAdvertiserView()).setText(unifiedNativeAd.getAdvertiser());
                adView.getAdvertiserView().setVisibility(View.VISIBLE);
            }
            adView.setNativeAd(unifiedNativeAd);


            viewGroup.removeAllViews();
            viewGroup.addView(adView);
        } else {
            viewGroup.setVisibility(View.VISIBLE);

            NativeAdView adView = (NativeAdView) ((Activity) context).getLayoutInflater().inflate(R.layout.ads_nativ_admob, null);

            adView.setMediaView((com.google.android.gms.ads.nativead.MediaView) adView.findViewById(R.id.ad_media));

            // Set other ad assets.
            adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
            adView.setBodyView(adView.findViewById(R.id.ad_body));
            adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
            adView.setIconView(adView.findViewById(R.id.ad_app_icon));
            adView.setPriceView(adView.findViewById(R.id.ad_price));
            adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
            adView.setStoreView(adView.findViewById(R.id.ad_store));
            adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

            // The headline and mediaContent are guaranteed to be in every NativeAd.
            ((TextView) adView.getHeadlineView()).setText(unifiedNativeAd.getHeadline());
            adView.getMediaView().setMediaContent(unifiedNativeAd.getMediaContent());

            // These assets aren't guaranteed to be in every NativeAd, so it's important to
            // check before trying to display them.
            if (unifiedNativeAd.getBody() == null) {
                adView.getBodyView().setVisibility(View.INVISIBLE);
            } else {
                adView.getBodyView().setVisibility(View.VISIBLE);
                ((TextView) adView.getBodyView()).setText(unifiedNativeAd.getBody());
            }

            if (unifiedNativeAd.getCallToAction() == null) {
                adView.getCallToActionView().setVisibility(View.INVISIBLE);
            } else {
                adView.getCallToActionView().setVisibility(View.VISIBLE);
                ((Button) adView.getCallToActionView()).setText(unifiedNativeAd.getCallToAction());
            }

            if (unifiedNativeAd.getIcon() == null) {
                adView.getIconView().setVisibility(View.GONE);
            } else {
                ((ImageView) adView.getIconView()).setImageDrawable(
                        unifiedNativeAd.getIcon().getDrawable());
                adView.getIconView().setVisibility(View.VISIBLE);
            }

            if (unifiedNativeAd.getPrice() == null) {
                adView.getPriceView().setVisibility(View.INVISIBLE);
            } else {
                adView.getPriceView().setVisibility(View.VISIBLE);
                ((TextView) adView.getPriceView()).setText(unifiedNativeAd.getPrice());
            }

            if (unifiedNativeAd.getStore() == null) {
                adView.getStoreView().setVisibility(View.INVISIBLE);
            } else {
                adView.getStoreView().setVisibility(View.VISIBLE);
                ((TextView) adView.getStoreView()).setText(unifiedNativeAd.getStore());
            }

            if (unifiedNativeAd.getStarRating() == null) {
                adView.getStarRatingView().setVisibility(View.INVISIBLE);
            } else {
                ((RatingBar) adView.getStarRatingView())
                        .setRating(unifiedNativeAd.getStarRating().floatValue());
                adView.getStarRatingView().setVisibility(View.VISIBLE);
            }

            if (unifiedNativeAd.getAdvertiser() == null) {
                adView.getAdvertiserView().setVisibility(View.INVISIBLE);
            } else {
                ((TextView) adView.getAdvertiserView()).setText(unifiedNativeAd.getAdvertiser());
                adView.getAdvertiserView().setVisibility(View.VISIBLE);
            }

            // This method tells the Google Mobile Ads SDK that you have finished populating your
            // native ad view with this native ad.
            adView.setNativeAd(unifiedNativeAd);

            // Get the video controller for the ad. One will always be provided, even if the ad doesn't
            // have a video asset.
            VideoController vc = unifiedNativeAd.getMediaContent().getVideoController();

            // Updates the UI to say whether or not this ad has a video asset.
            if (vc.hasVideoContent()) {


                // Create a new VideoLifecycleCallbacks object and pass it to the VideoController. The
                // VideoController will call methods on this object when events occur in the video
                // lifecycle.
                vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                    @Override
                    public void onVideoEnd() {
                        // Publishers should allow native ads to complete video playback before
                        // refreshing or replacing them with another ad in the same UI location.
                        super.onVideoEnd();
                    }
                });
            }

            viewGroup.removeAllViews();
            viewGroup.addView(adView);
        }

    }

    public void inflate_nativebanner(NativeBannerAd nativeBannerAd, ViewGroup viewGroup) {
        nativeBannerAd.unregisterView();
        View inflate = LayoutInflater.from(context).inflate(R.layout.ads_nativebanner_fb, (ViewGroup) null);
        viewGroup.removeAllViews();
        viewGroup.addView(inflate);
        LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.ad_choices_container);
        AdOptionsView adOptionsView = new AdOptionsView(context, nativeBannerAd, (NativeAdLayout) inflate.findViewById(R.id.nativview));
        linearLayout.removeAllViews();
        int i = 0;
        linearLayout.addView(adOptionsView, 0);
        TextView textView = (TextView) inflate.findViewById(R.id.native_ad_title);
        TextView textView2 = (TextView) inflate.findViewById(R.id.native_ad_social_context);
        MediaView mediaView = (MediaView) inflate.findViewById(R.id.native_icon_view);
        TextView textView3 = (TextView) inflate.findViewById(R.id.native_ad_call_to_action);
        textView3.setText(nativeBannerAd.getAdCallToAction());
        if (!nativeBannerAd.hasCallToAction()) {
            i = 4;
        }
        textView3.setVisibility(i);
        textView.setText(nativeBannerAd.getAdvertiserName());
        textView2.setText(nativeBannerAd.getAdBodyText());
        ArrayList arrayList = new ArrayList();
        arrayList.add(textView);
        arrayList.add(textView3);
        arrayList.add(mediaView);
        arrayList.add(textView2);
        nativeBannerAd.registerViewForInteraction(inflate, mediaView, (List<View>) arrayList);
    }

    public void inflat_facebooknative(NativeAd nativeAd, ViewGroup viewGroup) {
        int i = 0;
        viewGroup.setVisibility(View.VISIBLE);
        nativeAd.unregisterView();
        View inflate = LayoutInflater.from(this.context).inflate(R.layout.ads_nativ_fb, (ViewGroup) null);
        viewGroup.removeAllViews();

        viewGroup.addView(inflate);
        LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.ad_choices_container);
        AdOptionsView adOptionsView = new AdOptionsView(this.context, nativeAd, (NativeAdLayout) inflate.findViewById(R.id.nativview));
        linearLayout.removeAllViews();
        linearLayout.addView(adOptionsView, 0);
        MediaView mediaView = (MediaView) inflate.findViewById(R.id.native_ad_icon);
        TextView textView = (TextView) inflate.findViewById(R.id.native_ad_title);
        MediaView mediaView2 = (MediaView) inflate.findViewById(R.id.native_ad_media);
        TextView textView2 = (TextView) inflate.findViewById(R.id.native_ad_social_context);
        TextView textView3 = (TextView) inflate.findViewById(R.id.native_ad_body);
        TextView textView4 = (TextView) inflate.findViewById(R.id.native_ad_sponsored_label);
        TextView textView5 = (TextView) inflate.findViewById(R.id.native_ad_call_to_action);
        textView.setText(nativeAd.getAdvertiserName());
        textView3.setText(nativeAd.getAdBodyText());
        textView2.setText(nativeAd.getAdSocialContext());
        if (!nativeAd.hasCallToAction()) {
            i = 4;
        }
        textView5.setVisibility(i);
        textView5.setText(nativeAd.getAdCallToAction());
        textView4.setText(nativeAd.getSponsoredTranslation());
        ArrayList arrayList = new ArrayList();
        arrayList.add(textView);
        arrayList.add(textView3);
        arrayList.add(textView5);
        arrayList.add(mediaView);
        arrayList.add(textView2);
        nativeAd.registerViewForInteraction(inflate, mediaView2, mediaView, (List<View>) arrayList);
    }

    public void inflat_facebooknativesmall(NativeAd nativeAd, ViewGroup viewGroup) {
        int i = 0;
        viewGroup.setVisibility(View.VISIBLE);
        nativeAd.unregisterView();
        View inflate = LayoutInflater.from(this.context).inflate(R.layout.ads_nativ_fb1, (ViewGroup) null);
        viewGroup.removeAllViews();
        viewGroup.addView(inflate);
        LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.ad_choices_container);
        AdOptionsView adOptionsView = new AdOptionsView(this.context, nativeAd, (NativeAdLayout) inflate.findViewById(R.id.nativview));
        linearLayout.removeAllViews();
        linearLayout.addView(adOptionsView, 0);
        MediaView mediaView = (MediaView) inflate.findViewById(R.id.native_ad_icon);
        TextView textView = (TextView) inflate.findViewById(R.id.native_ad_title);
        MediaView mediaView2 = (MediaView) inflate.findViewById(R.id.native_ad_media);
        TextView textView2 = (TextView) inflate.findViewById(R.id.native_ad_social_context);
        TextView textView3 = (TextView) inflate.findViewById(R.id.native_ad_body);
        TextView textView4 = (TextView) inflate.findViewById(R.id.native_ad_sponsored_label);
        TextView textView5 = (TextView) inflate.findViewById(R.id.native_ad_call_to_action);
        textView.setText(nativeAd.getAdvertiserName());
        textView3.setText(nativeAd.getAdBodyText());
        textView2.setText(nativeAd.getAdSocialContext());
        if (!nativeAd.hasCallToAction()) {
            i = 4;
        }
        textView5.setVisibility(i);
        textView5.setText(nativeAd.getAdCallToAction());
        textView4.setText(nativeAd.getSponsoredTranslation());
        ArrayList arrayList = new ArrayList();
        arrayList.add(textView);
        arrayList.add(textView3);
        arrayList.add(textView5);
        arrayList.add(mediaView);
        arrayList.add(textView2);
        nativeAd.registerViewForInteraction(inflate, mediaView2, mediaView, (List<View>) arrayList);
    }

    public void inflat_admobnativesmall(com.google.android.gms.ads.nativead.NativeAd unifiedNativeAd, ViewGroup viewGroup) {

        viewGroup.setVisibility(View.VISIBLE);

        NativeAdView adView = (NativeAdView) ((Activity) context).getLayoutInflater().inflate(R.layout.ads_native_admob1, null);

        com.google.android.gms.ads.nativead.MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        TextView button = adView.findViewById(R.id.ad_call_to_action);

        adView.setCallToActionView(button);
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));
        ((TextView) adView.getHeadlineView()).setText(unifiedNativeAd.getHeadline());
        if (unifiedNativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(unifiedNativeAd.getBody());
        }

        if (unifiedNativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((TextView) adView.getCallToActionView()).setText(unifiedNativeAd.getCallToAction());
        }

        if (unifiedNativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    unifiedNativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }

        if (unifiedNativeAd.getPrice() == null) {
            adView.getPriceView().setVisibility(View.INVISIBLE);
        } else {
            adView.getPriceView().setVisibility(View.VISIBLE);
            ((TextView) adView.getPriceView()).setText(unifiedNativeAd.getPrice());
        }

        if (unifiedNativeAd.getStore() == null) {
            adView.getStoreView().setVisibility(View.INVISIBLE);
        } else {
            adView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) adView.getStoreView()).setText(unifiedNativeAd.getStore());
        }

        if (unifiedNativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(unifiedNativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        if (unifiedNativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.INVISIBLE);
        } else {
            ((TextView) adView.getAdvertiserView()).setText(unifiedNativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.VISIBLE);
        }
        adView.setNativeAd(unifiedNativeAd);


        viewGroup.removeAllViews();
        viewGroup.addView(adView);

    }

}
