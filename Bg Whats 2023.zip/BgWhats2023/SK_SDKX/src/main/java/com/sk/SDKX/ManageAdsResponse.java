package com.sk.SDKX;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ManageAdsResponse {


    @SerializedName("Response")
    @Expose
    public String response;
    @SerializedName("DataArray")
    @Expose
    public DataArray dataArray;

    public class AppSetting {

        @SerializedName("appislive")
        @Expose
        public String appislive;
        @SerializedName("am_inter")
        @Expose
        public String amInter;
        @SerializedName("am_native")
        @Expose
        public String amNative;
        @SerializedName("am_banner")
        @Expose
        public String amBanner;
        @SerializedName("am_appopen")
        @Expose
        public String amAppopen;
        @SerializedName("am_reward")
        @Expose
        public String amReward;
        @SerializedName("fb_inter")
        @Expose
        public String fbInter;
        @SerializedName("fb_native")
        @Expose
        public String fbNative;
        @SerializedName("fb_banner")
        @Expose
        public String fbBanner;
        @SerializedName("fb_nativebanner")
        @Expose
        public String fbNativebanner;
        @SerializedName("fb_reward")
        @Expose
        public String fbReward;
        @SerializedName("ads_prioritytype")
        @Expose
        public String adsPrioritytype;
        @SerializedName("ads_priority")
        @Expose
        public String adsPriority;
        @SerializedName("showads")
        @Expose
        public String showads;
        @SerializedName("clickcount")
        @Expose
        public String clickcount;
        @SerializedName("appopenshow")
        @Expose
        public String appopenshow;
        @SerializedName("addialogshow")
        @Expose
        public String addialogshow;
        @SerializedName("testmode")
        @Expose
        public String testmode;
        @SerializedName("addextra")
        @Expose
        public String addextra;

    }

    public class DataArray {

        @SerializedName("Moreapps")
        @Expose
        public List<Moreapp> moreapps = null;
        @SerializedName("AppSetting")
        @Expose
        public List<AppSetting> appSetting = null;

    }

    public class Moreapp {

        @SerializedName("app_name")
        @Expose
        public String appName;
        @SerializedName("app_logo")
        @Expose
        public String appLogo;
        @SerializedName("app_link")
        @Expose
        public String appLink;

    }

}
