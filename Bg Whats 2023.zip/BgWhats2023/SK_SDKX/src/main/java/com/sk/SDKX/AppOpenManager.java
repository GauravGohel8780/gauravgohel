package com.sk.SDKX;

import static androidx.lifecycle.Lifecycle.Event.ON_START;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;

import java.util.Date;

public class AppOpenManager implements LifecycleObserver, Application.ActivityLifecycleCallbacks {

    private static final String LOG_TAG = "AppOpenManager";
    private static boolean isShowingAd = false;
    private final MyApplication myApplication;
    SharedPreferences sharedPreferences;
    Context context;
    private AppOpenAd appOpenAdd = null;
    private Activity currentActivity;
    private long loadTime = 0;
    private AppOpenAd.AppOpenAdLoadCallback loadCallback;

    public AppOpenManager(MyApplication myApplication, Context context) {
        this.context = context;
        sharedPreferences = context.getSharedPreferences("SK_SDKX", context.MODE_PRIVATE);
        this.myApplication = myApplication;
        this.myApplication.registerActivityLifecycleCallbacks(this);
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
        Log.d("SSSS", "ADOPENID: " + sharedPreferences.getString("Am_AppOpen", "no data"));

    }

    public void fetchAd() {
        if (isAdAvailable()) {
            return;
        }


        loadCallback = new AppOpenAd.AppOpenAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull AppOpenAd appOpenAd) {
                super.onAdLoaded(appOpenAd);
                appOpenAdd = appOpenAd;
                loadTime = (new Date()).getTime();
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);


            }
        };

        AppOpenAd.load(myApplication, sharedPreferences.getString("Am_AppOpen", "no data"), new AdRequest.Builder().build(), AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback);


    }

    private AdRequest getAdRequest() {
        return new AdRequest.Builder().build();
    }

    public boolean isAdAvailable() {
        return appOpenAdd != null;
    }

    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
    }

    @Override
    public void onActivityStarted(Activity activity) {
        currentActivity = activity;
    }

    @Override
    public void onActivityResumed(Activity activity) {
        currentActivity = activity;
    }

    @Override
    public void onActivityStopped(Activity activity) {
    }

    @Override
    public void onActivityPaused(Activity activity) {
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    @Override
    public void onActivityDestroyed(Activity activity) {
        currentActivity = null;
    }

    public void showAdIfAvailable() {

        if (!isShowingAd && isAdAvailable() && sharedPreferences.getString("Appislive", "no data").equals("yes") && sharedPreferences.getString("AdsShows", "no data").equals("yes")) {
            Log.d(LOG_TAG, "Will show ad.");

            FullScreenContentCallback fullScreenContentCallback = new FullScreenContentCallback() {
                public void onAdDismissedFullScreenContent() {
                    AppOpenManager.this.appOpenAdd = null;
                    isShowingAd = false;
                    fetchAd();
                }

                public void onAdFailedToShowFullScreenContent(AdError adError) {

                }

                public void onAdShowedFullScreenContent() {

                    isShowingAd = true;
                }
            };

            appOpenAdd.show(currentActivity);
            appOpenAdd.setFullScreenContentCallback(fullScreenContentCallback);

        } else {
            Log.d(LOG_TAG, "Can not show ad.");
            fetchAd();
        }
    }

    @OnLifecycleEvent(ON_START)
    public void onStart() {
        showAdIfAvailable();
        Log.d(LOG_TAG, "onStart");
    }

    //For Splash Ads
    public void showAdIfAvailable(final splshADlistner splshadlistner) {
        if (isShowingAd || !isAdAvailable()) {
            splshadlistner.onError("");
            return;
        }

        FullScreenContentCallback r2 = new FullScreenContentCallback() {
            public void onAdDismissedFullScreenContent() {

                AppOpenManager.this.appOpenAdd = null;
                boolean unused = AppOpenManager.isShowingAd = false;
                splshadlistner.onsuccess();
            }

            public void onAdFailedToShowFullScreenContent(AdError adError) {
                splshadlistner.onError(adError.getMessage());

            }

            public void onAdShowedFullScreenContent() {
                boolean unused = AppOpenManager.isShowingAd = true;
            }
        };

        appOpenAdd.show(currentActivity);
        appOpenAdd.setFullScreenContentCallback(r2);
    }

    public interface splshADlistner {
        void onError(String str);

        void onsuccess();
    }

}
