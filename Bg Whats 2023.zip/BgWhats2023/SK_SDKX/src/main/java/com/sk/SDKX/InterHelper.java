package com.sk.SDKX;

import android.app.Activity;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.browser.customtabs.CustomTabsIntent;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.gms.ads.FullScreenContentCallback;

import java.util.ArrayList;

public class InterHelper {
    public static int ads_clickcounter = 0;
    public static ArrayList<String> interstitial_sequence = new ArrayList<>();
    public static int count_click_for_alt = -1;
    public static Dialog dialog;

    public void ShowIntertistialAds(Activity activity, OnIntertistialAdsListner onAdsListner) {

        dialog = new Dialog(activity);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog_loader);

        onAdsListner.onAdsDismissed();

        if (Preference.getString(activity, "AdsShows").equals("yes") && Constant.isConnected(activity)) {

            if (ads_clickcounter == Integer.parseInt(Preference.getString(activity, "ClickCount"))) {
                ads_clickcounter = 0;

                if (Preference.getString(activity, "AdsDialogShow").equals("all")) {
                    dialog.show();
                }

                if (Preference.getString(activity, "PriorityType").equals("fix")) {
                    interstitial_sequence.clear();

                    String[] adsPriority = Preference.getString(activity, "Priority").split(",");

                    for (int temp = 0; temp < adsPriority.length; temp++) {
                        interstitial_sequence.add(adsPriority[temp]);
                    }

                    if (interstitial_sequence.size() != 0) {

                        displayInterstitialAd(activity, interstitial_sequence.get(0));

                    }
                } else {

                    count_click_for_alt++;
                    interstitial_sequence.clear();

                    String alernateAd[] = Preference.getString(activity, "Priority").split(",");

                    int index = 0;
                    for (int j = 0; j <= 10; j++) {
                        if (count_click_for_alt % alernateAd.length == j) {
                            index = j;
                            interstitial_sequence.add(alernateAd[index]);
                        }
                    }

                    String adSequence[] = Preference.getString(activity, "Priority").split(",");
                    for (int j = 0; j < adSequence.length; j++) {
                        if (interstitial_sequence.size() != 0) {
                            if (!interstitial_sequence.get(0).equals(adSequence[j])) {
                                interstitial_sequence.add(adSequence[j]);
                            }
                        }

                    }

                    if (interstitial_sequence.size() != 0) {

                        displayInterstitialAd(activity, interstitial_sequence.get(0));

                    }
                }
            } else {
                ads_clickcounter = ads_clickcounter + 1;
            }
        }
    }

    public void displayInterstitialAd(final Activity activity, String platform) {
        if (platform.equals("0")) {
            try {
                if (SDK.ADMOBInterstitialAd != null) {

                    SDK.ADMOBInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                        @Override
                        public void onAdFailedToShowFullScreenContent(@NonNull com.google.android.gms.ads.AdError adError) {
                            super.onAdFailedToShowFullScreenContent(adError);

                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }
                            SDK.LoadInter1(activity, 0);
                            nextInterstitialPlatform(activity);
                        }

                        @Override
                        public void onAdDismissedFullScreenContent() {
                            super.onAdDismissedFullScreenContent();
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }
                            SDK.LoadInter1(activity, 0);
                        }
                    });

                    SDK.ADMOBInterstitialAd.show(activity);

                } else {
                    if (dialog.isShowing()) {
                        dialog.dismiss();
                    }
                    SDK.LoadInter1(activity, 0);
                    nextInterstitialPlatform(activity);
                }

            } catch (Exception e) {
                if (dialog.isShowing()) {
                    dialog.dismiss();
                }
                SDK.LoadInter1(activity, 0);
            }
        } else if (platform.equals("1")) {
            try {
                if (SDK.FBinterstitialAd.isAdLoaded()) {
                    SDK.FBinterstitialAd.buildLoadAdConfig().withAdListener(new InterstitialAdListener() {
                        @Override
                        public void onInterstitialDisplayed(Ad ad) {

                        }

                        @Override
                        public void onInterstitialDismissed(Ad ad) {
                            SDK.LoadFBIntertistialAds(activity, 0);
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }
                        }

                        @Override
                        public void onError(Ad ad, AdError adError) {
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }
                            SDK.LoadFBIntertistialAds(activity, 0);
                            nextInterstitialPlatform(activity);
                        }

                        @Override
                        public void onAdLoaded(Ad ad) {

                        }

                        @Override
                        public void onAdClicked(Ad ad) {

                        }

                        @Override
                        public void onLoggingImpression(Ad ad) {

                        }
                    });
                    SDK.FBinterstitialAd.show();
                } else {
                    if (dialog.isShowing()) {
                        dialog.dismiss();
                    }
                    SDK.LoadFBIntertistialAds(activity, 0);
                    nextInterstitialPlatform(activity);
                }
            } catch (Exception e) {
                e.printStackTrace();
                if (dialog.isShowing()) {
                    dialog.dismiss();
                }
                SDK.LoadFBIntertistialAds(activity, 0);
            }
        } else if (platform.equals("2")) {
            if (dialog.isShowing()) {
                dialog.dismiss();
            }
            CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
            CustomTabsIntent customTabsIntent = builder.build();

            Intent intent = new Intent(String.valueOf(Intent.FLAG_ACTIVITY_NO_USER_ACTION));

            PendingIntent pendingIntent = PendingIntent.getActivity(activity,
                    100,
                    intent,
                    PendingIntent.FLAG_IMMUTABLE);

            Bitmap bitmap = BitmapFactory.decodeResource(activity.getResources(), R.drawable.ic_ad);
            builder.setActionButton(bitmap, "Ad", pendingIntent);

            SDK.extraarray = Preference.getString(activity, "extra").split(",");
            customTabsIntent.launchUrl(activity, Uri.parse(SDK.extraarray[1]));

        } else if (platform.equals("3")) {
            try {
                if (SDK.appOpenAd != null) {
                    FullScreenContentCallback r2 = new FullScreenContentCallback() {
                        public void onAdDismissedFullScreenContent() {
                            SDK.loadAppopen(0);
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }
                        }

                        public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                            SDK.loadAppopen(0);
                            nextInterstitialPlatform(activity);
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }
                        }

                        public void onAdShowedFullScreenContent() {

                        }
                    };

                    SDK.appOpenAd.show(activity);
                    SDK.appOpenAd.setFullScreenContentCallback(r2);
                } else {
                    SDK.loadAppopen(0);
                    nextInterstitialPlatform(activity);
                    if (dialog.isShowing()) {
                        dialog.dismiss();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                SDK.loadAppopen(0);
                if (dialog.isShowing()) {
                    dialog.dismiss();
                }
            }
        }
    }

    private void nextInterstitialPlatform(Activity activity) {

        if (interstitial_sequence.size() != 0) {
            interstitial_sequence.remove(0);

            if (interstitial_sequence.size() != 0) {
                displayInterstitialAd(activity, interstitial_sequence.get(0));
            }

        }
    }

    public interface OnIntertistialAdsListner {
        void onAdsDismissed();
    }

}