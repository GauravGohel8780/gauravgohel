package com.sk.SDKX;

import android.app.Activity;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.browser.customtabs.CustomTabsIntent;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import java.util.ArrayList;
import java.util.List;

public class SDK {

    public static String[] extraarray;
    public static String PriorityDisplayInter = "none";
    public static List<ManageAdsResponse.Moreapp> moreappDataList = new ArrayList<>();


    public static InterstitialAd ADMOBInterstitialAd;
    public static com.facebook.ads.InterstitialAd FBinterstitialAd;
    public static AppOpenAd.AppOpenAdLoadCallback loadCallback;
    public static AppOpenAd appOpenAd = null;

    // inter

    public static Activity context;


    public static boolean isOnline(Context context) {
        ConnectivityManager connMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnected());
    }

    public static void setResponse(Activity activity, ManageAdsResponse response) {

        context = activity;

        Preference.putString(context, "Am_Inter", response.dataArray.appSetting.get(0).amInter);
        Preference.putString(context, "Am_Banner", response.dataArray.appSetting.get(0).amBanner);
        Preference.putString(context, "Am_Native", response.dataArray.appSetting.get(0).amNative);
        Preference.putString(context, "Am_AppOpen", response.dataArray.appSetting.get(0).amAppopen);
        Preference.putString(context, "Am_Reward", response.dataArray.appSetting.get(0).amReward);

        Preference.putString(context, "Fb_Inter", response.dataArray.appSetting.get(0).fbInter);
        Preference.putString(context, "Fb_Banner", response.dataArray.appSetting.get(0).fbBanner);
        Preference.putString(context, "Fb_Native", response.dataArray.appSetting.get(0).fbNative);
        Preference.putString(context, "Fb_NativeBanner", response.dataArray.appSetting.get(0).fbNativebanner);
        Preference.putString(context, "Fb_Reward", response.dataArray.appSetting.get(0).fbReward);

        Preference.putString(context, "Appislive", response.dataArray.appSetting.get(0).appislive);
        Preference.putString(context, "PriorityType", response.dataArray.appSetting.get(0).adsPrioritytype);
        Preference.putString(context, "Priority", response.dataArray.appSetting.get(0).adsPriority);
        Preference.putString(context, "ClickCount", response.dataArray.appSetting.get(0).clickcount);
        Preference.putString(context, "AppopenShow", response.dataArray.appSetting.get(0).appopenshow);
        Preference.putString(context, "AdsDialogShow", response.dataArray.appSetting.get(0).addialogshow);
        Preference.putString(context, "AdsShows", response.dataArray.appSetting.get(0).showads);
        Preference.putString(context, "extra", response.dataArray.appSetting.get(0).addextra);

        moreappDataList = response.dataArray.moreapps;
        extraarray = Preference.getString(context, "extra").split(",");

        LoadInter1(activity, 0);
        loadAppopen(0);
        LoadFBIntertistialAds(activity, 0);
    }

    public static void loadAppopen(final int current) {
        try {

            final String[] appopenids = Preference.getString(context, "Am_AppOpen").split("\\$");
            loadCallback = new AppOpenAd.AppOpenAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull AppOpenAd appOpenAd) {
                    super.onAdLoaded(appOpenAd);
                    SDK.appOpenAd = appOpenAd;
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    super.onAdFailedToLoad(loadAdError);
                    SDK.appOpenAd = null;
                    if (current <= appopenids.length - 1 && appopenids.length > 1) {
                        loadAppopen((current + 1));
                    }
                }
            };
            AppOpenAd.load(context, appopenids[current], new AdRequest.Builder().build(), AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void LoadInter1(final Activity activity, final int current) {

        context = activity;

        ADMOBInterstitialAd = null;
        final String[] interadsid = Preference.getString(context, "Am_Inter").split("\\$");

        InterstitialAd.load(context, interadsid[current], new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                // The mInterstitialAd reference will be null until
                // an ad is loaded.
                Log.i("AdmobInter", "onAdLoaded");

                ADMOBInterstitialAd = interstitialAd;
                ADMOBInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdFailedToShowFullScreenContent(@NonNull com.google.android.gms.ads.AdError adError) {
                        super.onAdFailedToShowFullScreenContent(adError);
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        super.onAdShowedFullScreenContent();
                    }

                    @Override
                    public void onAdDismissedFullScreenContent() {
                        super.onAdDismissedFullScreenContent();

                        LoadInter1(activity, 0);

                    }

                    @Override
                    public void onAdImpression() {
                        super.onAdImpression();
                    }
                });
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                // Handle the error
                Log.i("AdmobInter", loadAdError.getMessage());
                ADMOBInterstitialAd = null;
                if (current <= interadsid.length - 1 && interadsid.length > 1) {
                    LoadInter1(activity, (current + 1));
                }
            }
        });
    }

    public static void LoadFBIntertistialAds(final Activity activity, final int current) {

        context = activity;

        final String[] fbinterids = Preference.getString(context, "Fb_Inter").split("\\$");

        FBinterstitialAd = new com.facebook.ads.InterstitialAd(context, fbinterids[current]);
        FBinterstitialAd.loadAd();
        FBinterstitialAd.buildLoadAdConfig().withAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
                Log.e("FacebookInter", "Interstitial ad_folder displayed.");
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                Log.e("FacebookInter", "Interstitial ad_folder dismissed.");
                LoadFBIntertistialAds(activity, 0);
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.e("FacebookInter", "Interstitial ad_folder failed to load: " + adError.getErrorMessage());
                if (current <= fbinterids.length - 1 && fbinterids.length > 1) {
                    LoadFBIntertistialAds(activity, (current + 1));
                }
            }

            @Override
            public void onAdLoaded(Ad ad) {
                Log.e("FacebookInter", "Interstitial ad_folder is loaded and ready to be displayed!");
            }

            @Override
            public void onAdClicked(Ad ad) {
                Log.e("FacebookInter", "Interstitial ad_folder clicked!");
            }

            @Override
            public void onLoggingImpression(Ad ad) {
                Log.e("FacebookInter", "Interstitial ad_folder impression logged!");
            }
        });
    }

    public static void firstprivacydialog(Activity context) {
        if (!Preference.getBoolean(context, "isCheckPrivacy")) {
            Dialog dialog = new Dialog(context);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
            dialog.setCancelable(false);
            dialog.setContentView(R.layout.dialog_privacy);

            dialog.findViewById(R.id.privacy).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                    CustomTabsIntent customTabsIntent = builder.build();
                    SDK.extraarray = Preference.getString(context, "extra").split(",");
                    customTabsIntent.launchUrl(context, Uri.parse(SDK.extraarray[2]));

                }
            });

            dialog.findViewById(R.id.btnCancel).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    context.finish();
                    context.finishAffinity();
                    System.exit(0);
                    dialog.dismiss();
                }
            });

            dialog.findViewById(R.id.btnAccept).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Preference.putBoolean(context, "isCheckPrivacy", true);
                    dialog.dismiss();
                }
            });

            dialog.show();
        }
    }


    public static void linkintent(Activity context) {

        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
        CustomTabsIntent customTabsIntent = builder.build();
        SDK.extraarray = Preference.getString(context, "extra").split(",");
        customTabsIntent.launchUrl(context, Uri.parse(SDK.extraarray[1]));
    }
}
