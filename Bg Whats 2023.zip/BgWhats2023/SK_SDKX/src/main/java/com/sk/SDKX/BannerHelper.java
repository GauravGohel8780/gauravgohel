package com.sk.SDKX;

import android.app.Activity;
import android.content.res.Resources;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.browser.customtabs.CustomTabsIntent;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;

import java.util.ArrayList;
import java.util.Random;

public class BannerHelper {

    public static ArrayList<String> banner_sequence = new ArrayList<>();
    public static int count_click_for_alt = -1;

    public void ShowBannerAds(Activity activity, final ViewGroup viewGroup) {

        if (Preference.getString(activity, "AdsShows").equals("yes") && Constant.isConnected(activity)) {

            if (Preference.getString(activity, "PriorityType").equals("fix")) {
                banner_sequence.clear();

                String[] adsPriority = Preference.getString(activity, "Priority").split(",");

                for (int temp = 0; temp < adsPriority.length; temp++) {
                    banner_sequence.add(adsPriority[temp]);
                }

                if (banner_sequence.size() != 0) {
                    displayBannerAd(activity, banner_sequence.get(0), viewGroup);
                }
            } else {

                count_click_for_alt++;
                banner_sequence.clear();

                String alernateAd[] = Preference.getString(activity, "Priority").split(",");

                int index = 0;
                for (int j = 0; j <= 10; j++) {
                    if (count_click_for_alt % alernateAd.length == j) {
                        index = j;
                        banner_sequence.add(alernateAd[index]);
                    }
                }

                String adSequence[] = Preference.getString(activity, "Priority").split(",");
                for (int j = 0; j < adSequence.length; j++) {
                    if (banner_sequence.size() != 0) {
                        if (!banner_sequence.get(0).equals(adSequence[j])) {
                            banner_sequence.add(adSequence[j]);
                        }
                    }

                }

                if (banner_sequence.size() != 0) {

                    displayBannerAd(activity, banner_sequence.get(0), viewGroup);

                }
            }
        }
    }

    public void displayBannerAd(final Activity activity, String platform, final ViewGroup viewGroup) {
        if (platform.equals("0")) {
            showbannerads(activity, viewGroup, 0);
        } else if (platform.equals("1")) {
            final NativeBannerAd nativeBannerAd = new NativeBannerAd(activity, Preference.getString(activity, "Fb_NativeBanner"));
            nativeBannerAd.loadAd(nativeBannerAd.buildLoadAdConfig().withAdListener(new NativeAdListener() {
                public void onAdClicked(Ad ad) {
                }

                public void onLoggingImpression(Ad ad) {
                }

                public void onMediaDownloaded(Ad ad) {
                    viewGroup.removeAllViews();
                    new InflatAds(activity).inflate_nativebanner(nativeBannerAd, viewGroup);
                }

                public void onError(Ad ad, AdError adError) {
                    nextInterstitialPlatform(activity, viewGroup);
                }

                public void onAdLoaded(Ad ad) {
                    if (nativeBannerAd != null && nativeBannerAd == ad) {
                        nativeBannerAd.downloadMedia();
                    }
                }
            }).build());
        } else if (platform.equals("2")) {
            RelativeLayout adView = (RelativeLayout) ((Activity) activity).getLayoutInflater().inflate(R.layout.layout_qureka_bannerads, null);

            ImageView bannerimage = adView.findViewById(R.id.bannerimage);
            int[] bannerarray = new int[]{R.drawable.banner1, R.drawable.banner2, R.drawable.banner3, R.drawable.banner4};
            int random = new Random().nextInt(5 - 1);

            try {
                bannerimage.setImageDrawable(activity.getResources().getDrawable(bannerarray[random]));
            } catch (Resources.NotFoundException e) {
                e.printStackTrace();
                bannerimage.setImageDrawable(activity.getResources().getDrawable(R.drawable.banner1));
            }

            adView.findViewById(R.id.clickQureka).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                    CustomTabsIntent customTabsIntent = builder.build();
                    SDK.extraarray = Preference.getString(activity, "extra").split(",");
                    customTabsIntent.launchUrl(activity, Uri.parse(SDK.extraarray[1]));
                }
            });

            viewGroup.removeAllViews();
            viewGroup.addView(adView);
        } else if (platform.equals("3")) {
            nextInterstitialPlatform(activity, viewGroup);
        }
    }

    public void showbannerads(final Activity activity, final ViewGroup viewGroup, final int current) {

        final String[] bannerids = Preference.getString(activity, "Am_Banner").split("\\$");
        final com.google.android.gms.ads.AdView adView = new com.google.android.gms.ads.AdView(activity);
        adView.setAdSize(com.google.android.gms.ads.AdSize.BANNER);
        adView.setAdUnitId(bannerids[current]);
        adView.loadAd(new AdRequest.Builder().build());

        adView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                viewGroup.removeAllViews();
                viewGroup.addView(adView);
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                Log.e("AdmobAds", "Banner Ads Failed " + current);
                viewGroup.removeAllViews();
                if (current <= bannerids.length - 1 && bannerids.length > 1) {
                    showbannerads(activity, viewGroup, (current + 1));
                } else {
                    nextInterstitialPlatform(activity, viewGroup);
                }
            }
        });
    }

    private void nextInterstitialPlatform(Activity activity, ViewGroup viewGroup) {

        if (banner_sequence.size() != 0) {
            banner_sequence.remove(0);

            if (banner_sequence.size() != 0) {
                displayBannerAd(activity, banner_sequence.get(0), viewGroup);
            }

        }
    }

}
