package com.sk.SDKX;

import android.app.Activity;
import android.content.res.Resources;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.browser.customtabs.CustomTabsIntent;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdListener;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;

import java.util.ArrayList;
import java.util.Random;

public class NativeHelper {

    public static ArrayList<String> native_sequence = new ArrayList<>();
    public static int count_click_for_alt = -1;

    public void ShowNativeAds(Activity activity, final ViewGroup viewGroup) {

        if (Preference.getString(activity, "AdsShows").equals("yes") && Constant.isConnected(activity)) {

            if (Preference.getString(activity, "PriorityType").equals("fix")) {
                native_sequence.clear();

                String[] adsPriority = Preference.getString(activity, "Priority").split(",");

                for (int temp = 0; temp < adsPriority.length; temp++) {
                    native_sequence.add(adsPriority[temp]);
                }

                if (native_sequence.size() != 0) {
                    displayNativeAd(activity, native_sequence.get(0), viewGroup);
                }
            } else {

                count_click_for_alt++;
                native_sequence.clear();

                String alernateAd[] = Preference.getString(activity, "Priority").split(",");

                int index = 0;
                for (int j = 0; j <= 10; j++) {
                    if (count_click_for_alt % alernateAd.length == j) {
                        index = j;
                        native_sequence.add(alernateAd[index]);
                    }
                }

                String adSequence[] = Preference.getString(activity, "Priority").split(",");
                for (int j = 0; j < adSequence.length; j++) {
                    if (native_sequence.size() != 0) {
                        if (!native_sequence.get(0).equals(adSequence[j])) {
                            native_sequence.add(adSequence[j]);
                        }
                    }
                }

                if (native_sequence.size() != 0) {

                    displayNativeAd(activity, native_sequence.get(0), viewGroup);

                }
            }
        }
    }

    public void displayNativeAd(final Activity activity, String platform, final ViewGroup viewGroup) {
        if (platform.equals("0")) {

            shownativeads(activity, viewGroup, 0);
        } else if (platform.equals("1")) {
            final NativeAd nativeAd = new NativeAd(activity, Preference.getString(activity, "Fb_Native"));
            nativeAd.loadAd(nativeAd.buildLoadAdConfig().withAdListener(new NativeAdListener() {
                public void onAdClicked(Ad ad) {
                }

                public void onLoggingImpression(Ad ad) {
                }

                public void onMediaDownloaded(Ad ad) {
                }

                public void onError(Ad ad, AdError adError) {
                    Log.e("Facebookads", "" + adError.getErrorMessage());
                    nextInterstitialPlatform(activity, viewGroup);
                }

                public void onAdLoaded(Ad ad) {
                    Log.e("Facebookads", "Ads Load");
                    if (nativeAd != null && nativeAd == ad) {
                        Log.e("Facebookads", "Ads Load");
                        new InflatAds(activity).inflat_facebooknative(nativeAd, viewGroup);
                    }
                }
            }).build());
        } else if (platform.equals("2")) {
            RelativeLayout adView = (RelativeLayout) (activity).getLayoutInflater().inflate(R.layout.layout_qureka_nativeads, null);

            ImageView nativeimages = adView.findViewById(R.id.nativeimages);
            int[] nativearray = new int[]{R.drawable.native_banner_1, R.drawable.native_banner_2, R.drawable.native_banner_3, R.drawable.native_banner_4};
            int random = new Random().nextInt(5 - 1);

            try {
                nativeimages.setImageDrawable(activity.getResources().getDrawable(nativearray[random]));
            } catch (Resources.NotFoundException e) {
                e.printStackTrace();
                nativeimages.setImageDrawable(activity.getResources().getDrawable(R.drawable.native_banner_1));
            }

            adView.findViewById(R.id.clickQureka).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                    CustomTabsIntent customTabsIntent = builder.build();
                    SDK.extraarray = Preference.getString(activity, "extra").split(",");
                    customTabsIntent.launchUrl(activity, Uri.parse(SDK.extraarray[1]));
                }
            });

            viewGroup.removeAllViews();
            viewGroup.addView(adView);
        } else if (platform.equals("3")) {
            nextInterstitialPlatform(activity, viewGroup);
        }
    }

    public void shownativeads(final Activity activity, final ViewGroup viewGroup, final int current) {

        final String[] nativeids = Preference.getString(activity, "Am_Native").split("\\$");

        AdLoader.Builder builder = new AdLoader.Builder(activity, nativeids[current]);
        builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {
            @Override
            public void onNativeAdLoaded(@NonNull com.google.android.gms.ads.nativead.NativeAd nativeAd) {

                new InflatAds(activity).inflat_admobnative(nativeAd, viewGroup);

            }

        });
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
                Log.e("AdmobAds", "Native Ads Failed " + current);
                if (current <= nativeids.length - 1 && nativeids.length > 1) {
                    shownativeads(activity, viewGroup, (current + 1));
                } else {
                    nextInterstitialPlatform(activity, viewGroup);
                }
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void nextInterstitialPlatform(Activity activity, ViewGroup viewGroup) {

        if (native_sequence.size() != 0) {
            native_sequence.remove(0);

            if (native_sequence.size() != 0) {
                displayNativeAd(activity, native_sequence.get(0), viewGroup);
            }

        }
    }
}
