package com.sk.SDKX;

import android.app.Application;

public class MyApplication extends Application {

    public static AppOpenManager appOpenManager;

    public void onCreate() {
        super.onCreate();
        appOpenManager = new AppOpenManager(this, this);
    }
}
