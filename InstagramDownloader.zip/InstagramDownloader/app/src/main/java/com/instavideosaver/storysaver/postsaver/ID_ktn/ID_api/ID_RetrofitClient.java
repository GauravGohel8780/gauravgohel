package com.instavideosaver.storysaver.postsaver.ID_ktn.ID_api;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class ID_RetrofitClient {
    public static String BASE_URL = "https://www.instagram.com/";
    private static ID_RetrofitApiInterface retrofit;

    public static ID_RetrofitApiInterface getClient() {
        if (retrofit == null) {
            retrofit = (ID_RetrofitApiInterface) new Retrofit.Builder().baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create()).build().create(ID_RetrofitApiInterface.class);
        }
        return retrofit;
    }
}
