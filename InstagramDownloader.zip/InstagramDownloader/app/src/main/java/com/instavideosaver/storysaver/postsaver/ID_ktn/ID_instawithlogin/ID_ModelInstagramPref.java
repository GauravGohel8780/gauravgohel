package com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin;


public class ID_ModelInstagramPref {
    public String PREFERENCE_COOKIES;
    public String PREFERENCE_CSRF;
    public String PREFERENCE_ISINSTAGRAMLOGEDIN;
    public String PREFERENCE_SESSIONID;
    public String PREFERENCE_USERID;

    public ID_ModelInstagramPref(String str, String str2, String str3, String str4, String str5) {
        this.PREFERENCE_SESSIONID = "";
        this.PREFERENCE_USERID = "";
        this.PREFERENCE_COOKIES = "";
        this.PREFERENCE_CSRF = "";
        this.PREFERENCE_ISINSTAGRAMLOGEDIN = "";
        this.PREFERENCE_SESSIONID = str;
        this.PREFERENCE_USERID = str2;
        this.PREFERENCE_COOKIES = str3;
        this.PREFERENCE_CSRF = str4;
        this.PREFERENCE_ISINSTAGRAMLOGEDIN = str5;
    }

    public String getPREFERENCE_SESSIONID() {
        return this.PREFERENCE_SESSIONID;
    }

    public String getPREFERENCE_USERID() {
        return this.PREFERENCE_USERID;
    }

    public String getPREFERENCE_ISINSTAGRAMLOGEDIN() {
        return this.PREFERENCE_ISINSTAGRAMLOGEDIN;
    }
}
