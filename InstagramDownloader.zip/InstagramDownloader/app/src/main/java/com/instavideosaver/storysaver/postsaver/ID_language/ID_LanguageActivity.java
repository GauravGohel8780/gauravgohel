package com.instavideosaver.storysaver.postsaver.ID_language;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.instavideosaver.storysaver.postsaver.ID_Activity.MainActivity;
import com.instavideosaver.storysaver.postsaver.Ads_Common.AdsBaseActivity;
import com.instavideosaver.storysaver.postsaver.ID_PreferenceManager;
import com.instavideosaver.storysaver.postsaver.R;
import com.iten.tenoku.ad.AdShow;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.util.ArrayList;

public class ID_LanguageActivity extends AdsBaseActivity {

    private ID_LanguageAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language2);


        findViewById(R.id.back_btn).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });


        findViewById(R.id.select_btn).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    ID_LanguageLocaleUtils.changeLocale(getBaseContext(), ID_PreferenceManager.getPrefLanguage(ID_LanguageActivity.this));
                    startActivity(new Intent(ID_LanguageActivity.this, MainActivity.class));
                }
            }, MAIN_CLICK);
        });


        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        ArrayList<ID_LanguageModel> dataList = generateData();
        adapter = new ID_LanguageAdapter(dataList, this);
        recyclerView.setAdapter(adapter);

    }

    private ArrayList<ID_LanguageModel> generateData() {
        ArrayList<ID_LanguageModel> dataList = new ArrayList<>();
        dataList.add(new ID_LanguageModel(R.drawable.ic_usflagicon, "English", "en"));
        dataList.add(new ID_LanguageModel(R.drawable.ic_indiaflag, "Hindi", "hi"));
        dataList.add(new ID_LanguageModel(R.drawable.ic_franceflagicon, "French", "fr"));
        return dataList;
    }

    @Override
    protected void onResume() {
        super.onResume();
        AdShow.getInstance(this).ShowNativeAd(findViewById(R.id.native_big_ad_layout).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BIG);

    }
}