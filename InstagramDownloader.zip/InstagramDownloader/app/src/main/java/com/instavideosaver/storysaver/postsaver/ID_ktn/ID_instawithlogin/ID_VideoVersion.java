package com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;


public class ID_VideoVersion implements Serializable {
    @SerializedName("height")
    private long height;
    @SerializedName("id")
    private String id;
    @SerializedName("type")
    private long type;
    @SerializedName("url")
    private String url;
    @SerializedName("width")
    private long width;

    @SerializedName("type")
    public long getType() {
        return this.type;
    }

    @SerializedName("type")
    public void setType(long j) {
        this.type = j;
    }

    @SerializedName("width")
    public long getWidth() {
        return this.width;
    }

    @SerializedName("width")
    public void setWidth(long j) {
        this.width = j;
    }

    @SerializedName("height")
    public long getHeight() {
        return this.height;
    }

    @SerializedName("height")
    public void setHeight(long j) {
        this.height = j;
    }

    @SerializedName("url")
    public String geditTextPasteUrl() {
        return this.url;
    }

    @SerializedName("url")
    public void seditTextPasteUrl(String str) {
        this.url = str;
    }

    @SerializedName("id")
    public String getid() {
        return this.id;
    }

    @SerializedName("id")
    public void setid(String str) {
        this.id = str;
    }
}
