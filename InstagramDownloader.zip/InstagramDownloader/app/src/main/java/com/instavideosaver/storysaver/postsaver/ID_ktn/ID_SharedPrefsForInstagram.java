package com.instavideosaver.storysaver.postsaver.ID_ktn;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatDelegate;

import com.google.gson.Gson;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin.ID_ModelInstagramPref;


public class ID_SharedPrefsForInstagram {
    public static String PREFERENCE = "InSaverPrefs";
    public static String PREFERENCE_item = "instadata";
    public static Context context;
    private static ID_SharedPrefsForInstagram instance;
    SharedPreferences.Editor editor;
    SharedPreferences sharedPreference;

    public ID_SharedPrefsForInstagram() {
    }

    public ID_SharedPrefsForInstagram(Context context2) {
        context = context2;
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        SharedPreferences sharedPreferences = context2.getSharedPreferences(PREFERENCE, 0);
        this.sharedPreference = sharedPreferences;
        this.editor = sharedPreferences.edit();
    }

    public static ID_SharedPrefsForInstagram getInstance() {
        return instance;
    }

    public void setPreference(ID_ModelInstagramPref modelInstagramPref) {
        String json = new Gson().toJson(modelInstagramPref);
        SharedPreferences.Editor edit = this.sharedPreference.edit();
        this.editor = edit;
        edit.putString(PREFERENCE_item, json);
        this.editor.apply();
    }

    public ID_ModelInstagramPref getPreference() {
        try {
            return (ID_ModelInstagramPref) new Gson().fromJson(this.sharedPreference.getString(PREFERENCE_item, "oopsDintWork"), ID_ModelInstagramPref.class);
        } catch (Exception e) {
            e.printStackTrace();
            return new ID_ModelInstagramPref("", "", "", "", "false");
        }
    }

    public void clearSharePrefs() {
        String json = new Gson().toJson(new ID_ModelInstagramPref("", "", "", "", "false"));
        SharedPreferences.Editor edit = this.sharedPreference.edit();
        this.editor = edit;
        edit.putString(PREFERENCE_item, json);
        this.editor.apply();
    }
}
