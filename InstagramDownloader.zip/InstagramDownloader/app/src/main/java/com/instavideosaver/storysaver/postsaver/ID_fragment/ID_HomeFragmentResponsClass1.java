package com.instavideosaver.storysaver.postsaver.ID_fragment;

import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.instavideosaver.storysaver.postsaver.R;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_DownloadFileMain;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_storymodels.ID_ModelEdNode;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_storymodels.ID_ModelGetEdgetoNode;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_storymodels.ID_ModelInstagramResponse;
import com.instavideosaver.storysaver.postsaver.ID_utils.ID_Utils;

import java.util.List;

import kotlin.jvm.internal.Intrinsics;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public final class ID_HomeFragmentResponsClass1 implements Callback<JsonObject> {
    final String URL;
    ID_HomeFragment homeFragment;
    FragmentActivity myselectedActivity;
    public ID_HomeFragmentResponsClass1(ID_HomeFragment pasteFragment, String str, FragmentActivity myselectedActivity) {
        this.homeFragment = pasteFragment;
        this.URL = str;
        this.myselectedActivity = myselectedActivity;
    }

    @Override
    public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
        FragmentActivity fragmentActivity;
        FragmentActivity fragmentActivity2;
        FragmentActivity fragmentActivity3;
        FragmentActivity fragmentActivity4;
        FragmentActivity fragmentActivity5;
        FragmentActivity fragmentActivity6;
        FragmentActivity fragmentActivity7;
        Intrinsics.checkNotNullParameter(call, "call");
        Intrinsics.checkNotNullParameter(response, "response");
        System.out.println((Object) ("response1122334455 ress :   " + response.body()));
        try {
            ID_ModelInstagramResponse modelInstagramResponse = (ID_ModelInstagramResponse) new GsonBuilder().create().fromJson(String.valueOf(response.body()), new TypeToken<ID_ModelInstagramResponse>() {
            }.getType());
            String user_profile_pic =  modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getOwner().getProfile_pic_url();
            if (modelInstagramResponse == null) {
                fragmentActivity3 = myselectedActivity;
                Intrinsics.checkNotNull(fragmentActivity3);
                Toast.makeText(myselectedActivity, homeFragment.getResources().getString(R.string.somthing), Toast.LENGTH_SHORT).show();
                try {
                    homeFragment.dismissMyDialogFrag();
                    return;
                } catch (Exception e) {
                    e.printStackTrace();
                    return;
                }
            } else if (modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getEdge_sidecar_to_children() != null) {
                ID_ModelGetEdgetoNode edge_sidecar_to_children = modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getEdge_sidecar_to_children();
                Intrinsics.checkNotNullExpressionValue(edge_sidecar_to_children, "modelInstagramResponse.m….edge_sidecar_to_children");
                homeFragment.setMyInstaUsername(modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getOwner().getUsername());
                List<ID_ModelEdNode> modelEdNodes = edge_sidecar_to_children.getModelEdNodes();
                Intrinsics.checkNotNullExpressionValue(modelEdNodes, "modelGetEdgetoNode.modelEdNodes");
                int size = modelEdNodes.size();
                for (int i = 0; i < size; i++) {
                    if (modelEdNodes.get(i).getModelNode().isIs_video()) {
                        homeFragment.setMyVideoUrlIs(modelEdNodes.get(i).getModelNode().getVideo_url());
                        fragmentActivity7 = myselectedActivity;
                        Intrinsics.checkNotNull(fragmentActivity7);
                        ID_DownloadFileMain.startDownloading(fragmentActivity7, homeFragment.getMyVideoUrlIs(), homeFragment.getMyInstaUsername() + ID_Utils.getVideoFilenameFromURL(homeFragment.getMyVideoUrlIs()), ".mp4",user_profile_pic);
                        try {
                            homeFragment.dismissMyDialogFrag();
                        } catch (Exception e2) {
                            e2.printStackTrace();
                        }
                        homeFragment.setMyVideoUrlIs("");
                    } else {
                        homeFragment.setMyPhotoUrlIs(modelEdNodes.get(i).getModelNode().getDisplay_resources().get(modelEdNodes.get(i).getModelNode().getDisplay_resources().size() - 1).getSrc());
                        fragmentActivity6 = myselectedActivity;
                        Intrinsics.checkNotNull(fragmentActivity6);
                        ID_DownloadFileMain.startDownloading(fragmentActivity6, homeFragment.getMyPhotoUrlIs(), homeFragment.getMyInstaUsername() + ID_Utils.getImageFilenameFromURL(homeFragment.getMyPhotoUrlIs()), ".png",user_profile_pic);
                        homeFragment.setMyPhotoUrlIs("");
                        try {
                            try {
                                homeFragment.dismissMyDialogFrag();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                        } catch (Exception e4) {
                            try {
                                e4.printStackTrace();
                                System.out.println((Object) ("response1122334455 exe 1:   " + e4.getLocalizedMessage()));
                                try {
                                    homeFragment.dismissMyDialogFrag();
                                } catch (Exception e5) {
                                    e5.printStackTrace();
                                }
                                System.err.println("workkkkkkkkk 5.1");
                                e4.printStackTrace();
                                fragmentActivity2 = myselectedActivity;
                                Intrinsics.checkNotNull(fragmentActivity2);
                                ID_Utils.ShowToast(fragmentActivity2, homeFragment.getString(R.string.error_occ));
                                return;
                            } catch (Exception e6) {
                                e6.printStackTrace();
                                fragmentActivity = myselectedActivity;
                                Intrinsics.checkNotNull(fragmentActivity);
                                final ID_HomeFragment pasteFragment = homeFragment;
                                fragmentActivity.runOnUiThread(new Runnable() {
                                    @Override
                                    public final void run() {
                                        Intrinsics.checkNotNullParameter(pasteFragment, "homeFragment");
                                        pasteFragment.dismissMyDialogFrag();
                                        ID_Utils.ShowToast(pasteFragment.getContext(), homeFragment.getString(R.string.enter_valid_url));
                                    }
                                });
                                return;
                            }
                        }
                    }
                }
                return;
            } else {
                boolean isIs_video = modelInstagramResponse.getModelGraphshortcode().getShortcode_media().isIs_video();
                homeFragment.setMyInstaUsername(modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getOwner().getUsername());
                if (isIs_video) {
                    homeFragment.setMyVideoUrlIs(modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getVideo_url());
                    fragmentActivity5 = myselectedActivity;
                    Intrinsics.checkNotNull(fragmentActivity5);
                    ID_DownloadFileMain.startDownloading(fragmentActivity5, homeFragment.getMyVideoUrlIs(), homeFragment.getMyInstaUsername() + ID_Utils.getVideoFilenameFromURL(homeFragment.getMyVideoUrlIs()), ".mp4",user_profile_pic);
                    try {
                        homeFragment.dismissMyDialogFrag();
                    } catch (Exception e7) {
                        e7.printStackTrace();
                    }
                    homeFragment.setMyVideoUrlIs("");
                    return;
                }
                homeFragment.setMyPhotoUrlIs(modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getDisplay_resources().get(modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getDisplay_resources().size() - 1).getSrc());
                fragmentActivity4 = myselectedActivity;
                Intrinsics.checkNotNull(fragmentActivity4);
                ID_DownloadFileMain.startDownloading(fragmentActivity4, homeFragment.getMyPhotoUrlIs(), homeFragment.getMyInstaUsername() + ID_Utils.getImageFilenameFromURL(homeFragment.getMyPhotoUrlIs()), ".png",user_profile_pic);
                try {
                    homeFragment.dismissMyDialogFrag();
                } catch (Exception e8) {
                    e8.printStackTrace();
                }
                homeFragment.setMyPhotoUrlIs("");
                return;
            }
        } catch (Exception unused) {
            System.err.println("workkkkkkkkk 4");
            homeFragment.downloadInstagramImageOrVideodata(URL, "");
        }
        System.err.println("workkkkkkkkk 4");
        homeFragment.downloadInstagramImageOrVideodata(URL, "");
    }


    @Override
    public void onFailure(Call<JsonObject> call, Throwable t) {
        FragmentActivity fragmentActivity;
        Intrinsics.checkNotNullParameter(call, "call");
        Intrinsics.checkNotNullParameter(t, "t");
        try {
            System.out.println((Object) ("response1122334455:   Failed0" + t.getMessage()));
            homeFragment.dismissMyDialogFrag();
            fragmentActivity = myselectedActivity;
            Intrinsics.checkNotNull(fragmentActivity);
            Toast.makeText(fragmentActivity, homeFragment.getResources().getString(R.string.somthing), Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
