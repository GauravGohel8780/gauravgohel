package com.instavideosaver.storysaver.postsaver.ID_fragment;


import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.instavideosaver.storysaver.postsaver.ID_PreferenceManager;
import com.instavideosaver.storysaver.postsaver.R;
import com.instavideosaver.storysaver.postsaver.ID_SharedViewModel;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_SharedPrefsForInstagram;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin.ID_ModelInstagramPref;

public class ID_WebFragment extends Fragment {

    private WebView webView;
    private boolean isLoggedIn = false;

    private boolean isWebViewLoaded = false;
    private ID_SharedViewModel sharedViewModel;

    private String lastCopiedLink;
    private ClipboardManager clipboardManager;
    private ClipboardManager.OnPrimaryClipChangedListener clipChangedListener;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_web, container, false);

        sharedViewModel = new ViewModelProvider(requireActivity()).get(ID_SharedViewModel.class);
        webView = view.findViewById(R.id.webView);
        initWebView();


        webView.loadUrl("https://www.instagram.com/accounts/login/");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                // Page started loading
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (url.equals("https://www.instagram.com/") || url.startsWith("https://www.instagram.com/?")) {
                    ID_PreferenceManager.saveBooleanToPreferences(getActivity(), true);

                    if (!isLoggedIn && url.startsWith("https://www.instagram.com/") && !url.contains("accounts/login")) {
                        String cookie = CookieManager.getInstance().getCookie(url);
                        try {
                            String cookie2 = getCookie(url, "sessionid");
                            String cookie3 = getCookie(url, "csrftoken");
                            String cookie4 = getCookie(url, "ds_user_id");
                            if (cookie2 == null || cookie3 == null || cookie4 == null) {
                                return;
                            }
                            new ID_SharedPrefsForInstagram(getActivity()).setPreference(new ID_ModelInstagramPref(cookie2, cookie4, cookie, cookie3, "true"));

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        isLoggedIn = true;

                        onInstagramLoggedIn();

                    }
                } else {
                    ID_PreferenceManager.saveBooleanToPreferences(getActivity(), false);
                    new ID_SharedPrefsForInstagram(getActivity()).clearSharePrefs();
                }

            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                // Intercept requests if needed
                return super.shouldInterceptRequest(view, request);
            }
        });


        Log.d("ssss", "this---->: " + this);
        clipboardManager = (ClipboardManager) requireActivity().getSystemService(Context.CLIPBOARD_SERVICE);

        clipChangedListener = new ClipboardManager.OnPrimaryClipChangedListener() {
            @Override
            public void onPrimaryClipChanged() {
                ClipData clipData = clipboardManager.getPrimaryClip();
                if (clipData != null && clipData.getItemCount() > 0) {
                    CharSequence copiedText = clipData.getItemAt(0).getText();
                    if (copiedText != null && isUrl(copiedText.toString())) {
                        if (!copiedText.toString().equals(lastCopiedLink)) {
                            ID_PreferenceManager.dowloadbtn(getContext(), false);
                            lastCopiedLink = copiedText.toString();
                            sharedViewModel.setCopiedLink(copiedText.toString());
                        }
                    }
                }
            }
        };
        clipboardManager.addPrimaryClipChangedListener(clipChangedListener);


        return view;
    }

    private boolean isUrl(String text) {
        // Simple check to see if the text looks like a URL
        return text.startsWith("http://") || text.startsWith("https://");
    }

    private void showToast(String message) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
    }

    private void initWebView() {
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        webSettings.setDomStorageEnabled(true);

        CookieManager cookieManager = CookieManager.getInstance();

        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);

        WebView.setWebContentsDebuggingEnabled(true);

        webView.setWebChromeClient(new WebChromeClient());
    }

    private void onInstagramLoggedIn() {
        if (ID_PreferenceManager.getusername(getContext()).isEmpty()) {
            webView.loadUrl("https://www.instagram.com/");
        } else {
            webView.loadUrl("https://www.instagram.com/" + ID_PreferenceManager.getusername(getContext()));
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    ID_PreferenceManager.putusername(getContext(), "");
                }
            }, 1000);
        }
    }

    public String getCookie(String str, String str2) {
        String[] split;
        String cookie = CookieManager.getInstance().getCookie(str);
        if (cookie != null && !cookie.isEmpty()) {
            for (String str3 : cookie.split(";")) {
                if (str3.contains(str2)) {
                    return str3.split("=")[1];
                }
            }
        }
        return null;
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (clipboardManager != null && clipChangedListener != null) {
            clipboardManager.removePrimaryClipChangedListener(clipChangedListener);
        }
    }
}

