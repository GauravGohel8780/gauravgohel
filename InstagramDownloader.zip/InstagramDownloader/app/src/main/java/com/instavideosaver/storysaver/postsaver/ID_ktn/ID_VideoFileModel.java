package com.instavideosaver.storysaver.postsaver.ID_ktn;

public class ID_VideoFileModel {
        private String fileName;
        private String filePath;
        private long videoDuration;

        public ID_VideoFileModel(String fileName, String filePath, long videoDuration) {
            this.fileName = fileName;
            this.filePath = filePath;
            this.videoDuration = videoDuration;
        }

    public ID_VideoFileModel(String fileName, String filePath) {
        this.fileName = fileName;
        this.filePath = filePath;
    }

    public String getFileName() {
            return fileName;
        }

        public long getVideoDuration() {
            return videoDuration;
        }

        public String getFilePath() {
            return filePath;
        }
    }