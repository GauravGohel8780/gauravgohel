package com.instavideosaver.storysaver.postsaver.ID_utils;

import android.content.Context;
import android.content.SharedPreferences;


public class ID_Preference {
    public SharedPreferences appSharedPrefs;
    Context context;
    boolean isSync;
    public SharedPreferences.Editor prefsEditor;

    public ID_Preference(Context context) {
        this.context = context;
        SharedPreferences sharedPreferences = context.getSharedPreferences("XproVPN_pref", 0);
        this.appSharedPrefs = sharedPreferences;
        this.prefsEditor = sharedPreferences.edit();
    }

    public Integer getInAppReviewToken() {
        return Integer.valueOf(this.appSharedPrefs.getInt("in_app_review_token", 0));
    }

    public void updateInAppReviewToken(int i) {
        this.prefsEditor.putInt("in_app_review_token", i);
        this.prefsEditor.apply();
    }

    public Integer getApiKeyPosition() {
        return Integer.valueOf(this.appSharedPrefs.getInt("api_key_position", 0));
    }

    public void updateApiKeyPosition(int i) {
        this.prefsEditor.putInt("api_key_position", i);
        this.prefsEditor.apply();
    }

    public Integer getRetryToken() {
        return Integer.valueOf(this.appSharedPrefs.getInt("retry_token", 0));
    }

    public void updateRetryToken(int i) {
        this.prefsEditor.putInt("retry_token", i);
        this.prefsEditor.apply();
    }
}
