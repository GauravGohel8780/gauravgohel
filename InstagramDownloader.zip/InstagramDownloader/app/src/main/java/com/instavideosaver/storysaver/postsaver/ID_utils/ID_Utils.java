package com.instavideosaver.storysaver.postsaver.ID_utils;

import android.content.Context;
import android.os.Environment;
import android.widget.Toast;

import java.io.File;
import java.net.URL;


public class ID_Utils {
    private static Context context;
    public static String[] UserAgentsList = {"Instagram 9.5.2 (iPhone7,2; iPhone OS 9_3_3; en_US; en-US; scale=2.00; 750x1334) AppleWebKit/420+", "Instagram 9.5.2 (iPhone7,2; iPhone OS 9_3_3; en_US; en-US; scale=2.00; 750x1334) AppleWebKit/420+"};
    public static File FolderPathShow = new File(Environment.getExternalStorageDirectory() + "/Download/ReelDownloader");

    public ID_Utils(Context context2) {
        context = context2;
    }

    public static String getImageFilenameFromURL(String str) {
        try {
            return new File(new URL(str).getPath()).getName();
        } catch (Exception e) {
            e.printStackTrace();
            return System.currentTimeMillis() + ".png";
        }
    }

    public static String getVideoFilenameFromURL(String str) {
        try {
            return new File(new URL(str).getPath()).getName();
        } catch (Exception e) {
            e.printStackTrace();
            return System.currentTimeMillis() + ".mp4";
        }
    }

    public static void ShowToast(Context context2, String str) {
        try {
            Toast.makeText(context2, str, Toast.LENGTH_LONG).show();
        } catch (Exception unused) {
            Toast.makeText(context2, "" + str, Toast.LENGTH_LONG).show();
        }
    }

    public static void createFolder() {
        if (FolderPathShow.exists()) {
            return;
        }
        FolderPathShow.mkdirs();
    }
}
