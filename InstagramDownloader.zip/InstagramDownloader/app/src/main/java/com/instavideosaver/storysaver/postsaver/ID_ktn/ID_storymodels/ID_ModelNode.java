package com.instavideosaver.storysaver.postsaver.ID_ktn.ID_storymodels;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;


public class ID_ModelNode implements Serializable {
    @SerializedName("display_resources")
    private List<ID_ModelDispRes> display_resources;
    @SerializedName("display_url")
    private String display_url;
    @SerializedName("is_video")
    private boolean is_video;
    @SerializedName("video_url")
    private String video_url;

    public String getDisplay_url() {
        return this.display_url;
    }

    public void setDisplay_url(String str) {
        this.display_url = str;
    }

    public List<ID_ModelDispRes> getDisplay_resources() {
        return this.display_resources;
    }

    public void setDisplay_resources(List<ID_ModelDispRes> list) {
        this.display_resources = list;
    }

    public boolean isIs_video() {
        return this.is_video;
    }

    public void setIs_video(boolean z) {
        this.is_video = z;
    }

    public String getVideo_url() {
        return this.video_url;
    }

    public void setVideo_url(String str) {
        this.video_url = str;
    }
}
