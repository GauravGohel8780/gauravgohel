package com.instavideosaver.storysaver.postsaver.ID_fragment;

import static com.instavideosaver.storysaver.postsaver.ID_utils.ID_Utils.createFolder;
import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;
import com.instavideosaver.storysaver.postsaver.ID_Activity.MainActivity;
import com.instavideosaver.storysaver.postsaver.ID_PreferenceManager;
import com.instavideosaver.storysaver.postsaver.R;
import com.instavideosaver.storysaver.postsaver.ID_SharedViewModel;
import com.instavideosaver.storysaver.postsaver.ID_ShowDP.ID_ContactDAO;
import com.instavideosaver.storysaver.postsaver.ID_ShowDP.ID_DpShowAdapter;
import com.instavideosaver.storysaver.postsaver.ID_ShowDP.ID_DpShowModel;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_SharedPrefsForInstagram;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin.ID_ModelInstagramPref;

import org.json.JSONObject;

import java.lang.reflect.Type;
import java.net.URI;
import java.util.List;
import java.util.Random;

import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.text.CharsKt;
import kotlin.text.StringsKt;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.franmontiel.persistentcookiejar.PersistentCookieJar;
import com.franmontiel.persistentcookiejar.cache.SetCookieCache;
import com.franmontiel.persistentcookiejar.persistence.SharedPrefsCookiePersistor;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_DownloadFileMain;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_api.ID_RetrofitApiInterface;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_api.ID_RetrofitClient;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin.ID_CarouselMedia;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin.ID_Item;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin.ID_ModelInstaWithLogin;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_storymodels.ID_ModelEdNode;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_storymodels.ID_ModelGetEdgetoNode;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_storymodels.ID_ModelInstagramResponse;
import com.instavideosaver.storysaver.postsaver.ID_utils.ID_Utils;
import com.instavideosaver.storysaver.postsaver.ID_utils.ID_iUtils;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;

public class ID_HomeFragment extends Fragment {
    private static final String TAG = "HomeFragment";
    private String lastCopiedLink;
    private String myPhotoUrlIs;
    private String myVideoUrlIs;
    private FragmentActivity myselectedActivity;
    public SharedPreferences pref;
    private SharedPreferences.Editor prefEditor;
    public ProgressDialog progressDralogGenaratinglink;
    private String myInstaUsername = "";
    ID_SharedViewModel sharedViewModel;



    public final ProgressDialog getProgressDralogGenaratinglink() {
        ProgressDialog progressDialog = this.progressDralogGenaratinglink;
        if (progressDialog != null) {
            return progressDialog;
        }
        Intrinsics.throwUninitializedPropertyAccessException("progressDralogGenaratinglink");
        return null;
    }

    public final void setProgressDralogGenaratinglink(ProgressDialog progressDialog) {
        Intrinsics.checkNotNullParameter(progressDialog, "<set-?>");
        this.progressDralogGenaratinglink = progressDialog;
    }

    public final SharedPreferences getPref() {
        SharedPreferences sharedPreferences = this.pref;
        if (sharedPreferences != null) {
            return sharedPreferences;
        }
        Intrinsics.throwUninitializedPropertyAccessException("pref");
        return null;
    }

    public final void setPref(SharedPreferences sharedPreferences) {
        Intrinsics.checkNotNullParameter(sharedPreferences, "<set-?>");
        this.pref = sharedPreferences;
    }


    public final String getMyVideoUrlIs() {
        return this.myVideoUrlIs;
    }

    public final void setMyVideoUrlIs(String str) {
        this.myVideoUrlIs = str;
    }

    public final String getMyInstaUsername() {
        return this.myInstaUsername;
    }

    public final void setMyInstaUsername(String str) {
        this.myInstaUsername = str;
    }

    public final String getMyPhotoUrlIs() {
        return this.myPhotoUrlIs;
    }

    public final void setMyPhotoUrlIs(String str) {
        this.myPhotoUrlIs = str;
    }

    EditText editTextPasteUrl;

    private ID_ContactDAO contactDAO;
    private RecyclerView recyclerView;
    private ID_DpShowAdapter adapter;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);


        contactDAO = new ID_ContactDAO(requireContext());
        recyclerView = view.findViewById(R.id.rvdpshow);

        GridLayoutManager layoutManager = new GridLayoutManager(getContext(), 4);
        recyclerView.setLayoutManager(layoutManager);

        List<ID_DpShowModel> contacts = getContacts();
        adapter = new ID_DpShowAdapter(contacts, getActivity());
        recyclerView.setAdapter(adapter);




        editTextPasteUrl = view.findViewById(R.id.editTextPasteUrl);
        sharedViewModel = new ViewModelProvider(requireActivity()).get(ID_SharedViewModel.class);

        view.findViewById(R.id.pathpaste).setOnClickListener(v -> {
            getInstance(getActivity()).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    ClipData.Item itemAt;
                    Intrinsics.checkNotNullParameter(getActivity(), "this");
                    FragmentActivity fragmentActivity = myselectedActivity;
                    Object systemService = fragmentActivity.getSystemService(Context.CLIPBOARD_SERVICE);
                    Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.content.ClipboardManager");
                    ClipData primaryClip = ((ClipboardManager) systemService).getPrimaryClip();
                    String valueOf = String.valueOf((primaryClip == null || (itemAt = primaryClip.getItemAt(0)) == null) ? null : itemAt.getText());
                    editTextPasteUrl.getText().clear();
                    editTextPasteUrl.setText(Editable.Factory.getInstance().newEditable(valueOf));
                }
            }, MAIN_CLICK);
        });

        setActivityAfterAttached();
        if (isAdded()) {
            FragmentActivity fragmentActivity = this.myselectedActivity;
            Intrinsics.checkNotNull(fragmentActivity);
            setProgressDralogGenaratinglink(new ProgressDialog(fragmentActivity));
            getProgressDralogGenaratinglink().setMessage(getResources().getString(R.string.genarating_download_link));
            getProgressDralogGenaratinglink().setCancelable(false);
            FragmentActivity fragmentActivity2 = this.myselectedActivity;
            Intrinsics.checkNotNull(fragmentActivity2);
            SharedPreferences sharedPreferences = fragmentActivity2.getSharedPreferences("tikVideoDownloader", 0);
            Intrinsics.checkNotNullExpressionValue(sharedPreferences, "myselectedActivity!!.get…Preferences(PREF_CLIP, 0)");
            setPref(sharedPreferences);
            SharedPreferences.Editor edit = getPref().edit();
            Intrinsics.checkNotNullExpressionValue(edit, "pref.edit()");
            this.prefEditor = edit;
            SharedPreferences.Editor editor = this.prefEditor;
            if (editor == null) {
                Intrinsics.throwUninitializedPropertyAccessException("prefEditor");
                editor = null;
            }
            editor.apply();
            view.findViewById(R.id.linearLayoutDownloader).setOnClickListener(new View.OnClickListener() { 
                @Override 
                public final void onClick(View view2) {

                    createFolder();

                    getProgressDralogGenaratinglink().setMessage(getResources().getString(R.string.genarating_download_link));
                    ClipData.Item itemAt;
                    Intrinsics.checkNotNullParameter(getActivity(), "this");
                    FragmentActivity fragmentActivity = myselectedActivity;
                    Intrinsics.checkNotNull(fragmentActivity);
                    Object systemService = fragmentActivity.getSystemService(Context.CLIPBOARD_SERVICE);
                    Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.content.ClipboardManager");
                    ClipData primaryClip = ((ClipboardManager) systemService).getPrimaryClip();
                    String valueOf = String.valueOf((primaryClip == null || (itemAt = primaryClip.getItemAt(0)) == null) ? null : itemAt.getText());
                    editTextPasteUrl.getText().clear();
                    editTextPasteUrl.setText(Editable.Factory.getInstance().newEditable(valueOf));
                    String obj = editTextPasteUrl.getText().toString();
                    if (Intrinsics.areEqual(obj, "") && ID_iUtils.checkURL(obj)) {
                        FragmentActivity fragmentActivity2 = myselectedActivity;
                        FragmentActivity fragmentActivity3 = fragmentActivity2;
                        Intrinsics.checkNotNull(fragmentActivity2);
                        Resources resources = fragmentActivity2.getResources();
                        ID_Utils.ShowToast(fragmentActivity3, resources != null ? resources.getString(R.string.enter_valid) : null);
                        return;
                    }
                    getInstance(getActivity()).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            startInstaDownloadMethod(obj);
                        }
                    }, MAIN_CLICK);
                }
            });
        }

        return view;
    }


    public final <T> void startInstaDownloadMethod(final String str) {
        try {
            Log.e(TAG, "String: --------->" + str);
            URI uri = new URI(str);
            Log.e(TAG, "Uri: --------->" + uri);
            URI uri2 = new URI(uri.getScheme(), uri.getAuthority(), uri.getPath(), null, uri.getFragment());
            Log.e(TAG, "Uri2: --------->" + uri2);
            final Ref.ObjectRef objectRef = new Ref.ObjectRef();
            objectRef.element = uri2;
            Log.e(TAG, "objectRef.Elements: --------->" + objectRef.element);
            T t = (T) uri2;

            Log.e(TAG, "Type T---------->: " + t);
//            if (contains$default((CharSequence) objectRef.element,  "/reel/", false, 2, (Object) null)) {
            if (t.toString().contains("/reel/")) {
                Log.e(TAG, "IN IF---------->: ");
                objectRef.element = replace$default(String.valueOf(objectRef.element), "/reel/", "/p/", false, 4, (Object) null);
            }


            if (t.toString().contains("/p/")) {
                objectRef.element = replace$default(String.valueOf(objectRef.element), "/tv/", "/p/", false, 4, (Object) null);
            }
            final String str2 = (String) objectRef.element;
            objectRef.element = ((String) objectRef.element) + "?__a=1&__d=dis";
            System.err.println("workkkkkkkkk 87878788 " + ((String) objectRef.element));
            System.err.println("workkkkkkkkk 777777 " + ((String) objectRef.element));
            try {
                if (((String) split$default((CharSequence) objectRef.element, new String[]{"/"}, false, 0, 6, (Object) null).get(4)).length() > 15) {
                    ID_SharedPrefsForInstagram sharedPrefsForInstagram = new ID_SharedPrefsForInstagram(this.myselectedActivity);
                    if (Intrinsics.areEqual(sharedPrefsForInstagram.getPreference().getPREFERENCE_SESSIONID(), "")) {
                        sharedPrefsForInstagram.clearSharePrefs();
                    }
                    ID_ModelInstagramPref preference = sharedPrefsForInstagram.getPreference();
                    if (preference != null && Intrinsics.areEqual(preference.getPREFERENCE_ISINSTAGRAMLOGEDIN(), "false")) {
                        dismissMyDialogFrag();
                        LoingDialogshow();
                        return;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            FragmentActivity fragmentActivity = this.myselectedActivity;
            Intrinsics.checkNotNull(fragmentActivity);
            if (fragmentActivity.isFinishing()) {
                return;
            }
            FragmentActivity fragmentActivity2 = this.myselectedActivity;
            Intrinsics.checkNotNull(fragmentActivity2);
            FragmentActivity fragmentActivity3 = this.myselectedActivity;
            Intrinsics.checkNotNull(fragmentActivity3);
            applyServer1((String) objectRef.element, str2);
        } catch (Exception unused) {
            Log.e(TAG, "startInstaDownloadMethod: catch -----------> " + unused.toString());
            dismissMyDialogFrag();
            FragmentActivity fragmentActivity4 = this.myselectedActivity;
            Intrinsics.checkNotNull(fragmentActivity4);
            ID_Utils.ShowToast(fragmentActivity4, getString(R.string.invalid_url));
        }
    }

    private List<ID_DpShowModel> getContacts() {
        contactDAO.open();
        List<ID_DpShowModel> contacts = contactDAO.getAllContacts();
        contactDAO.close();
        return contacts;
    }

    public final void applyServer1(String urlwithoutlettersqp, String urlwithoutlettersqp_noa) {
        if (!getActivity().isFinishing()) {
            getProgressDralogGenaratinglink().show();
        }
        try {
            System.err.println("workkkkkkkkk 4 ");
            FragmentActivity fragmentActivity2 = this.myselectedActivity;
            Intrinsics.checkNotNull(fragmentActivity2);
            ID_ModelInstagramPref preference = new ID_SharedPrefsForInstagram(fragmentActivity2).getPreference();
            if (preference != null && preference.getPREFERENCE_USERID() != null && !Intrinsics.areEqual(preference.getPREFERENCE_USERID(), "oopsDintWork") && !Intrinsics.areEqual(preference.getPREFERENCE_USERID(), "")) {
                System.err.println("workkkkkkkkk 476 " + urlwithoutlettersqp + "____ds_user_id=" + preference.getPREFERENCE_USERID() + "; sessionid=" + preference.getPREFERENCE_SESSIONID());
                downloadInstagramImageOrVideodata_withlogin(urlwithoutlettersqp, "ds_user_id=" + preference.getPREFERENCE_USERID() + "; sessionid=" + preference.getPREFERENCE_SESSIONID());
                return;
            }
            downloadInstagramImageOrVideoResponseOkhttp(urlwithoutlettersqp_noa);
        } catch (Exception e) {
            dismissMyDialogFrag();
            System.err.println("workkkkkkkkk 5");
            e.printStackTrace();
            FragmentActivity fragmentActivity3 = this.myselectedActivity;
            Intrinsics.checkNotNull(fragmentActivity3);
            ID_Utils.ShowToast(fragmentActivity3, getString(R.string.error_occ));
        }
    }


    public final void downloadInstagramImageOrVideodata_withlogin(String str, String str2) {
        int nextInt = new Random().nextInt(ID_iUtils.UserAgentsList.length);
        if (TextUtils.isEmpty(str2)) {
            str2 = "";
        }
        ID_RetrofitApiInterface client = ID_RetrofitClient.getClient();
        Intrinsics.checkNotNullExpressionValue(client, "getClient()");
        Call<JsonObject> instagramData = client.getInstagramData(str, str2, ID_iUtils.UserAgentsList[nextInt]);
        Intrinsics.checkNotNullExpressionValue(instagramData, "apiService.getInstagramD…erAgentsList[j]\n        )");
        instagramData.enqueue(new ID_HomeFragmentResponsClass(this, str));

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                List<ID_DpShowModel> contacts = getContacts();
                adapter = new ID_DpShowAdapter(contacts, getActivity());
                recyclerView.setAdapter(adapter);
            }
        },3000);

    }


    public final void dismissMyDialogFrag() {
        FragmentActivity fragmentActivity = this.myselectedActivity;
        if (fragmentActivity != null) {
            fragmentActivity.runOnUiThread(new Runnable() { 
                @Override 
                public final void run() {
                    Intrinsics.checkNotNullParameter(this, "this");
                    if (getProgressDralogGenaratinglink() == null || !getProgressDralogGenaratinglink().isShowing()) {
                        return;
                    }
                    FragmentActivity fragmentActivity = myselectedActivity;
                    Intrinsics.checkNotNull(fragmentActivity, "null cannot be cast to non-null type android.app.Activity");
                    if (fragmentActivity.isFinishing()) {
                        return;
                    }
                    getProgressDralogGenaratinglink().dismiss();
                }
            });
        }
    }


    @Override 
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        System.out.println((Object) ("proddddd11111222 " + i2 + " __" + intent));
        if (i == 200 && i2 == -1) {
            System.out.println((Object) ("proddddd11111200 " + i2 + " __" + intent));
        }
        Log.e("Result Called", "111111111");
        Log.e("Request code", String.valueOf(i));
        Log.e("result code", String.valueOf(i2));
        if (intent != null) {
            intent.getData();
        }
    }

    private void setActivityAfterAttached() {
        try {
            if (getActivity() == null || !isAdded()) {
                return;
            }
            this.myselectedActivity = getActivity();
        } catch (Exception e) {
            this.myselectedActivity = requireActivity();
            e.printStackTrace();
        }
    }

    private final void downloadInstagramImageOrVideo_tikinfApi(String str) {
        AndroidNetworking.get("http://tikdd.infusiblecoder.com/ini/ilog.php?url=" + str).setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener() { 
            @Override
            public void onResponse(JSONObject response) {
                FragmentActivity fragmentActivity;
                FragmentActivity fragmentActivity2;
                FragmentActivity fragmentActivity3;
                FragmentActivity fragmentActivity4;
                FragmentActivity fragmentActivity5;
                Intrinsics.checkNotNullParameter(response, "response");
                String jSONObject = response.toString();
                Intrinsics.checkNotNullExpressionValue(jSONObject, "response.toString()");
                System.out.println((Object) ("myresponseis111 eeee " + jSONObject));
                try {
                    Type type = new TypeToken<ID_ModelInstaWithLogin>() {
                    }.getType();
                    Intrinsics.checkNotNullExpressionValue(type, "object : TypeToken<ModelInstaWithLogin?>() {}.type");
                    Object fromJson = new Gson().fromJson(jSONObject, type);
                    Intrinsics.checkNotNullExpressionValue(fromJson, "Gson().fromJson(\n       …                        )");
                    ID_ModelInstaWithLogin modelInstaWithLogin = (ID_ModelInstaWithLogin) fromJson;
                    String username = modelInstaWithLogin.getItems().get(0).getUser().getUsername();
                    String userimg = modelInstaWithLogin.getItems().get(0).getUser().getProfile_pic_url();
                    if (modelInstaWithLogin.getItems().get(0).getMediaType() == 8) {
                        List<ID_CarouselMedia> carouselMedia = modelInstaWithLogin.getItems().get(0).getCarouselMedia();
                        Intrinsics.checkNotNullExpressionValue(carouselMedia, "modelGetEdgetoNode.carouselMedia");
                        int size = carouselMedia.size();
                        for (int i = 0; i < size; i++) {
                            if (carouselMedia.get(i).getMediaType() == 2) {
                                ID_HomeFragment.this.setMyVideoUrlIs(carouselMedia.get(i).getVideoVersions().get(0).geditTextPasteUrl());
                                fragmentActivity5 = ID_HomeFragment.this.myselectedActivity;
                                Toast.makeText(getActivity(), "this1", Toast.LENGTH_SHORT).show();
                                ID_DownloadFileMain.startDownloading(fragmentActivity5, ID_HomeFragment.this.getMyVideoUrlIs(), username, ".mp4", userimg);
                                ID_HomeFragment.this.setMyVideoUrlIs("");
                            } else {
                                ID_HomeFragment.this.setMyPhotoUrlIs(carouselMedia.get(i).getImageVersions2().getCandidates().get(0).geditTextPasteUrl());
                                fragmentActivity4 = ID_HomeFragment.this.myselectedActivity;
                                Toast.makeText(getActivity(), "this2", Toast.LENGTH_SHORT).show();
                                ID_DownloadFileMain.startDownloading(fragmentActivity4, ID_HomeFragment.this.getMyPhotoUrlIs(), username, ".png", userimg);
                                ID_HomeFragment.this.setMyPhotoUrlIs("");
                                ID_HomeFragment.this.dismissMyDialogFrag();
                            }
                        }
                    } else {
                        ID_Item item = modelInstaWithLogin.getItems().get(0);
                        if (item.getMediaType() == 2) {
                            ID_HomeFragment.this.setMyVideoUrlIs(item.getVideoVersions().get(0).geditTextPasteUrl());
                            fragmentActivity3 = ID_HomeFragment.this.myselectedActivity;
                            Toast.makeText(getActivity(), "this3", Toast.LENGTH_SHORT).show();
                            ID_DownloadFileMain.startDownloading(fragmentActivity3, ID_HomeFragment.this.getMyVideoUrlIs(), username, ".mp4", userimg);
                            ID_HomeFragment.this.setMyVideoUrlIs("");
                        } else {
                            ID_HomeFragment.this.setMyPhotoUrlIs(item.getImageVersions2().getCandidates().get(0).geditTextPasteUrl());
                            fragmentActivity2 = ID_HomeFragment.this.myselectedActivity;
                            Toast.makeText(getActivity(), "this4", Toast.LENGTH_SHORT).show();
                            ID_DownloadFileMain.startDownloading(fragmentActivity2, ID_HomeFragment.this.getMyPhotoUrlIs(), username, ".png", userimg);
                            ID_HomeFragment.this.dismissMyDialogFrag();
                            ID_HomeFragment.this.setMyPhotoUrlIs("");
                        }
                    }
                    ID_HomeFragment.this.dismissMyDialogFrag();
                } catch (Exception e) {
                    e.printStackTrace();
                    System.out.println((Object) ("myresponseis111 try exp " + e.getMessage()));
                    ID_HomeFragment.this.dismissMyDialogFrag();
                    fragmentActivity = ID_HomeFragment.this.myselectedActivity;
                    Toast.makeText(fragmentActivity, "test2", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onError(ANError error) {
                FragmentActivity fragmentActivity;
                Intrinsics.checkNotNullParameter(error, "error");
                System.out.println((Object) ("myresponseis111 exp " + error.getMessage()));
                ID_HomeFragment.this.dismissMyDialogFrag();
                fragmentActivity = ID_HomeFragment.this.myselectedActivity;
                LoingDialogshow();
            }
        });
    }

    private void LoingDialogshow() {
        final Dialog dialog2 = new Dialog(getContext());
        dialog2.requestWindowFeature(1);
        dialog2.setContentView(R.layout.dialog_logout);
        dialog2.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog2.getWindow().setLayout(-1, -2);
        dialog2.setCanceledOnTouchOutside(false);
        dialog2.setCancelable(false);

        ((TextView) dialog2.findViewById(R.id.txtdelete)).setText(R.string.urlisprivate);
        ((MaterialButton) dialog2.findViewById(R.id.btnnotnow)).setText(R.string.cancel);
        ((MaterialButton) dialog2.findViewById(R.id.btnyes)).setText(R.string.login);

        dialog2.findViewById(R.id.btnyes).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ID_PreferenceManager.putloginuser(getContext(), "user");
                startActivity(new Intent(getContext(), MainActivity.class));
                dialog2.dismiss();
            }
        });
        dialog2.findViewById(R.id.btnnotnow).setOnClickListener(new View.OnClickListener() {
            @Override 
            public void onClick(View view) {
                dialog2.dismiss();
            }
        });
        dialog2.show();
    }

    public final void downloadInstagramImageOrVideodata(String str, String str2) {
        int nextInt = new Random().nextInt(ID_Utils.UserAgentsList.length);
        if (TextUtils.isEmpty(str2)) {
            str2 = "";
        }
        ID_RetrofitApiInterface client = ID_RetrofitClient.getClient();
        Intrinsics.checkNotNullExpressionValue(client, "getClient()");
        Call<JsonObject> instagramData = client.getInstagramData(str, str2, ID_Utils.UserAgentsList[nextInt]);
        Intrinsics.checkNotNullExpressionValue(instagramData, "apiService.getInstagramD…erAgentsList[j]\n        )");
        instagramData.enqueue(new ID_HomeFragmentResponsClass1(this, str, myselectedActivity));
    }

    public final void downloadInstagramImageOrVideoResponseOkhttp(String str) {
        try {
            HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor();
            httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            Response execute = new OkHttpClient.Builder().cookieJar(new PersistentCookieJar(new SetCookieCache(), new SharedPrefsCookiePersistor(getContext()))).addInterceptor(httpLoggingInterceptor).build().newCall(new Request.Builder().url(str + "?__a=1&__d=dis").method("GET", null).build()).execute();
            ResponseBody body = execute.body();
            Intrinsics.checkNotNull(body);
            String string = body.string();
            int code = execute.code();
            if (!contains$default((CharSequence) string, (CharSequence) "shortcode_media", false, 2, (Object) null)) {
                code = 400;
            }
            if (code != 200) {
                FragmentActivity fragmentActivity9 = (FragmentActivity) getContext();
                Intrinsics.checkNotNull(fragmentActivity9);
                fragmentActivity9.runOnUiThread(new Runnable() {
                    @Override
                    public final void run() {
                        Intrinsics.checkNotNullParameter(this, "homeFragment");
                        getProgressDralogGenaratinglink().setMessage("Server 1 failed trying Server 2");
                    }
                });
                Intrinsics.checkNotNull(str);
                downloadInstagramImageOrVideoResOkhttpM2(str);
                return;
            }
            try {
                ID_ModelInstagramResponse modelInstagramResponse = (ID_ModelInstagramResponse) new GsonBuilder().create().fromJson(string, new TypeToken<ID_ModelInstagramResponse>() {
                }.getType());
                String user_profile_pic = modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getOwner().getProfile_pic_url();
                if (modelInstagramResponse == null) {
                    Toast.makeText(getContext(), getResources().getString(R.string.somthing), Toast.LENGTH_SHORT).show();
                    dismissMyDialogFrag();
                } else if (modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getEdge_sidecar_to_children() != null) {
                    ID_ModelGetEdgetoNode edge_sidecar_to_children = modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getEdge_sidecar_to_children();
                    Intrinsics.checkNotNullExpressionValue(edge_sidecar_to_children, "modelInstagramResponse.m….edge_sidecar_to_children");
                    List<ID_ModelEdNode> modelEdNodes = edge_sidecar_to_children.getModelEdNodes();
                    Intrinsics.checkNotNullExpressionValue(modelEdNodes, "modelGetEdgetoNode.modelEdNodes");
                    int size = modelEdNodes.size();
                    for (int i = 0; i < size; i++) {
                        if (modelEdNodes.get(i).getModelNode().isIs_video()) {
                            setMyVideoUrlIs(modelEdNodes.get(i).getModelNode().getVideo_url());
                            ID_DownloadFileMain.startDownloading(getContext(), getMyVideoUrlIs(), getMyInstaUsername(), ".mp4", user_profile_pic);
                            dismissMyDialogFrag();
                            setMyVideoUrlIs("");
                        } else {
                            setMyPhotoUrlIs(modelEdNodes.get(i).getModelNode().getDisplay_resources().get(modelEdNodes.get(i).getModelNode().getDisplay_resources().size() - 1).getSrc());
                            ID_DownloadFileMain.startDownloading(getContext(), getMyPhotoUrlIs(), getMyInstaUsername(), ".png", user_profile_pic);
                            setMyPhotoUrlIs("");
                            dismissMyDialogFrag();
                        }
                    }
                } else if (modelInstagramResponse.getModelGraphshortcode().getShortcode_media().isIs_video()) {
                    setMyVideoUrlIs(modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getVideo_url());
                    ID_DownloadFileMain.startDownloading(getContext(), getMyVideoUrlIs(), getMyInstaUsername(), ".mp4", user_profile_pic);
                    dismissMyDialogFrag();
                    setMyVideoUrlIs("");
                } else {
                    setMyPhotoUrlIs(modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getDisplay_resources().get(modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getDisplay_resources().size() - 1).getSrc());
                    ID_DownloadFileMain.startDownloading(getContext(), getMyPhotoUrlIs(), getMyInstaUsername(), ".png", user_profile_pic);
                    dismissMyDialogFrag();
                    setMyPhotoUrlIs("");
                }
            } catch (Exception unused) {
                FragmentActivity fragmentActivity3 = (FragmentActivity) getContext();
                Intrinsics.checkNotNull(fragmentActivity3);
                fragmentActivity3.runOnUiThread(new Runnable() {
                    @Override
                    public final void run() {
                        Intrinsics.checkNotNullParameter(this, "homeFragment");
                        getProgressDralogGenaratinglink().setMessage("Server 1 failed trying Server 2");
                    }
                });

                Intrinsics.checkNotNull(str);
                this.downloadInstagramImageOrVideoResOkhttpM2(str);
            }
        } catch (Throwable th) {
            th.printStackTrace();
            System.out.println((Object) ("The request has failed " + th.getMessage()));
            FragmentActivity fragmentActivity = (FragmentActivity) getContext();
            Intrinsics.checkNotNull(fragmentActivity);
            fragmentActivity.runOnUiThread(new Runnable() {
                @Override
                public final void run() {
                    Intrinsics.checkNotNullParameter(this, "homeFragment");
                    getProgressDralogGenaratinglink().setMessage("Server 1 failed trying Server 2");
                }
            });

            Intrinsics.checkNotNull(str);
            this.downloadInstagramImageOrVideoResOkhttpM2(str);
        }
    }

    String substring;

    public final void downloadInstagramImageOrVideoResOkhttpM2(String str) {
        HttpLoggingInterceptor httpLoggingInterceptor;
        try {
            httpLoggingInterceptor = new HttpLoggingInterceptor();
            httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

            Response execute = new OkHttpClient.Builder().cookieJar(new PersistentCookieJar(new SetCookieCache(), new SharedPrefsCookiePersistor(this.myselectedActivity))).addInterceptor(httpLoggingInterceptor).build().newCall(new Request.Builder().url(str + "embed/captioned/").method("GET", null).build()).execute();
            ResponseBody body = execute.body();
            Intrinsics.checkNotNull(body);
            String string = body.string();
            int code = execute.code();
            if (!contains$default((CharSequence) string, (CharSequence) "shortcode_media", false, 2, (Object) null)) {
                code = 400;
            }
            if (code == 200) {
                try {
                    Intrinsics.checkNotNullExpressionValue(string.substring(indexOf$default((CharSequence) string, "window.__additionalDataLoaded(", 0, false, 6, (Object) null) + 38, indexOf$default((CharSequence) string, "}}});", 0, false, 6, (Object) null) + 3), "this as java.lang.String…ing(startIndex, endIndex)");
                    String str2 = "{\"graphql\":" + trim((CharSequence) substring).toString() + ",\"showQRModal\":false\"}";
                    StringBuilder append = new StringBuilder().append("HttpResponse ddffd23 ");
                    String substring2 = str2.substring(str2.length() - 30);
                    Intrinsics.checkNotNullExpressionValue(substring2, "this as java.lang.String).substring(startIndex)");
                    System.out.println((Object) append.append(substring2).toString());
                    ID_ModelInstagramResponse modelInstagramResponse = (ID_ModelInstagramResponse) new GsonBuilder().create().fromJson(str2, new TypeToken<ID_ModelInstagramResponse>() {
                    }.getType());
                    if (modelInstagramResponse != null) {
                        if (modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getEdge_sidecar_to_children() != null) {
                            ID_ModelGetEdgetoNode edge_sidecar_to_children = modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getEdge_sidecar_to_children();
                            String user_profile_img = modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getOwner().getProfile_pic_url();
                            Intrinsics.checkNotNullExpressionValue(edge_sidecar_to_children, "modelInstagramResponse.m….edge_sidecar_to_children");
                            List<ID_ModelEdNode> modelEdNodes = edge_sidecar_to_children.getModelEdNodes();
                            Intrinsics.checkNotNullExpressionValue(modelEdNodes, "modelGetEdgetoNode.modelEdNodes");
                            int size = modelEdNodes.size();
                            for (int i = 0; i < size; i++) {
                                if (modelEdNodes.get(i).getModelNode().isIs_video()) {
                                    this.myVideoUrlIs = modelEdNodes.get(i).getModelNode().getVideo_url();
                                    FragmentActivity fragmentActivity = this.myselectedActivity;
                                    Intrinsics.checkNotNull(fragmentActivity);
                                    ID_DownloadFileMain.startDownloading(fragmentActivity, this.myVideoUrlIs, this.myInstaUsername + ID_Utils.getVideoFilenameFromURL(this.myVideoUrlIs), ".mp4", user_profile_img);
                                    dismissMyDialogFrag();
                                    this.myVideoUrlIs = "";
                                } else {
                                    this.myPhotoUrlIs = modelEdNodes.get(i).getModelNode().getDisplay_resources().get(modelEdNodes.get(i).getModelNode().getDisplay_resources().size() - 1).getSrc();
                                    FragmentActivity fragmentActivity2 = this.myselectedActivity;
                                    Intrinsics.checkNotNull(fragmentActivity2);
                                    ID_DownloadFileMain.startDownloading(fragmentActivity2, this.myPhotoUrlIs, this.myInstaUsername + ID_Utils.getImageFilenameFromURL(this.myPhotoUrlIs), ".png", user_profile_img);
                                    this.myPhotoUrlIs = "";
                                    dismissMyDialogFrag();
                                }
                            }
                            return;
                        } else if (modelInstagramResponse.getModelGraphshortcode().getShortcode_media().isIs_video()) {
                            this.myVideoUrlIs = modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getVideo_url();
                            String user_profile_img = modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getOwner().getProfile_pic_url();
                            FragmentActivity fragmentActivity3 = this.myselectedActivity;
                            Intrinsics.checkNotNull(fragmentActivity3);
                            ID_DownloadFileMain.startDownloading(fragmentActivity3, this.myVideoUrlIs, this.myInstaUsername + ID_Utils.getVideoFilenameFromURL(this.myVideoUrlIs), ".mp4", user_profile_img);
                            dismissMyDialogFrag();
                            this.myVideoUrlIs = "";
                            return;
                        } else {
                            this.myPhotoUrlIs = modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getDisplay_resources().get(modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getDisplay_resources().size() - 1).getSrc();
                            FragmentActivity fragmentActivity4 = this.myselectedActivity;
                            Intrinsics.checkNotNull(fragmentActivity4);
                            String user_profile_img = modelInstagramResponse.getModelGraphshortcode().getShortcode_media().getOwner().getProfile_pic_url();
                            ID_DownloadFileMain.startDownloading(fragmentActivity4, this.myPhotoUrlIs, this.myInstaUsername + ID_Utils.getImageFilenameFromURL(this.myPhotoUrlIs), ".png", user_profile_img);
                            dismissMyDialogFrag();
                            this.myPhotoUrlIs = "";
                            return;
                        }
                    }
                    FragmentActivity fragmentActivity5 = this.myselectedActivity;
                    Intrinsics.checkNotNull(fragmentActivity5);
                    Toast.makeText(fragmentActivity5, getResources().getString(R.string.somthing), Toast.LENGTH_SHORT).show();
                    dismissMyDialogFrag();
                    return;
                } catch (Exception unused) {
                    FragmentActivity fragmentActivity6 = this.myselectedActivity;
                    Intrinsics.checkNotNull(fragmentActivity6);
                    fragmentActivity6.runOnUiThread(new Runnable() {
                        @Override 
                        public final void run() {
                            Intrinsics.checkNotNullParameter(this, "this");
                            getProgressDralogGenaratinglink().setMessage("Server 2 failed trying Server 3");
                        }
                    });
                    downloadInstagramImageOrVideo_tikinfApi(str);
                    return;
                }
            }
            FragmentActivity fragmentActivity7 = this.myselectedActivity;
            Intrinsics.checkNotNull(fragmentActivity7);
            fragmentActivity7.runOnUiThread(new Runnable() { 
                @Override 
                public final void run() {
                    Intrinsics.checkNotNullParameter(this, "this");
                    getProgressDralogGenaratinglink().setMessage("Server 2 failed trying Server 3");
                }
            });
            downloadInstagramImageOrVideo_tikinfApi(str);
        } catch (Throwable th2) {
            th2.printStackTrace();
            System.out.println((Object) ("The request has failed " + th2.getMessage()));
            FragmentActivity fragmentActivity8 = this.myselectedActivity;
            Intrinsics.checkNotNull(fragmentActivity8);
            fragmentActivity8.runOnUiThread(new Runnable() { 
                @Override 
                public final void run() {
                    Intrinsics.checkNotNullParameter(this, "this");
                    getProgressDralogGenaratinglink().setMessage("Server 2 failed trying Server 3");
                }
            });
            downloadInstagramImageOrVideo_tikinfApi(str);
        }
    }

    public static String replace$default(String str, String str2, String str3, boolean z, int i, Object obj) {
        if ((i & 4) != 0) {
            z = false;
        }
        return StringsKt.replace(str, str2, str3, z);
    }

    public static List split$default(CharSequence charSequence, String[] strArr, boolean z, int i, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            z = false;
        }
        if ((i2 & 4) != 0) {
            i = 0;
        }
        return StringsKt.split(charSequence, strArr, z, i);
    }

    public static boolean contains$default(CharSequence charSequence, CharSequence charSequence2, boolean z, int i, Object obj) {
        if ((i & 2) != 0) {
            z = false;
        }
        return StringsKt.contains(charSequence, charSequence2, z);
    }

    public static final CharSequence trim(CharSequence charSequence) {
        Intrinsics.checkNotNullParameter(charSequence, "<this>");
        int length = charSequence.length() - 1;
        int i = 0;
        boolean z = false;
        while (i <= length) {
            boolean isWhitespace = CharsKt.isWhitespace(charSequence.charAt(!z ? i : length));
            if (z) {
                if (!isWhitespace) {
                    break;
                }
                length--;
            } else if (isWhitespace) {
                i++;
            } else {
                z = true;
            }
        }
        return charSequence.subSequence(i, length + 1);
    }

    public static int indexOf$default(CharSequence charSequence, String str, int i, boolean z, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            i = 0;
        }
        if ((i2 & 4) != 0) {
            z = false;
        }
        return StringsKt.indexOf(charSequence, str, i, z);
    }

    @Override
    public void onResume() {
        super.onResume();
        sharedViewModel.getCopiedLink().observe(getActivity(), new Observer<String>() {
            @Override
            public void onChanged(String link) {
                Log.d("ssss", "onChanged: " + link);
                if (!link.equals(lastCopiedLink)) {
                    if (!ID_PreferenceManager.getdowloadbtn(getContext())) {
                        getInstance(getActivity()).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                ID_PreferenceManager.dowloadbtn(getContext(), true);
                                lastCopiedLink = link;
                                startInstaDownloadMethod(lastCopiedLink);
                            }
                        }, MAIN_CLICK);
                    }
                }
            }
        });
    }
}