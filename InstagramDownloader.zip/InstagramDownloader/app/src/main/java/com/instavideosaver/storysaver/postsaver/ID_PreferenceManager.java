package com.instavideosaver.storysaver.postsaver;

import android.content.Context;
import android.content.SharedPreferences;

public class ID_PreferenceManager {

    private static final String PREF_NAME = "MyPrefs";
    private static final String BOOLEAN_KEY = "isBooleanValue";

    public static void saveBooleanToPreferences(Context context, boolean value) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(BOOLEAN_KEY, value);
        editor.apply();
    }

    public static boolean getBooleanFromPreferences(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean(BOOLEAN_KEY, false);
    }

    public static void dowloadbtn(Context context, boolean value) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("dowloadbtn", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("dowloadbtn1", value);
        editor.apply();
    }

    public static boolean getdowloadbtn(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("dowloadbtn", Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean("dowloadbtn1", false);
    }

    public static void putPrefLanguage(Context context, String str) {
          SharedPreferences sharedPreferences = context.getSharedPreferences("language", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("language1", str);
        editor.apply();
    }

    public static String getPrefLanguage(Context context) {
       SharedPreferences sharedPreferences = context.getSharedPreferences("language", Context.MODE_PRIVATE);
        return sharedPreferences.getString("language1", "");
    }


    public static void putintro(Context context, boolean value) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("intro", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("intro1", value);
        editor.apply();
    }

    public static boolean getintro(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("intro", Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean("intro1", false);
    }

    public static void putloginuser(Context context, String str) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("loginuser", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("loginuser1", str);
        editor.apply();
    }

    public static String getloginuser(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("loginuser", Context.MODE_PRIVATE);
        return sharedPreferences.getString("loginuser1", "");
    }

    public static void putusername(Context context, String str) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("username", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("username1", str);
        editor.apply();
    }

    public static String getusername(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("username", Context.MODE_PRIVATE);
        return sharedPreferences.getString("username1", "");
    }




}