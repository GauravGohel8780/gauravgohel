package com.instavideosaver.storysaver.postsaver.ID_Activity;


import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.androidnetworking.BuildConfig;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.navigation.NavigationView;
import com.instavideosaver.storysaver.postsaver.Ads_Common.AdsBaseActivity;
import com.instavideosaver.storysaver.postsaver.Ads_Common.ExitActivity;
import com.instavideosaver.storysaver.postsaver.ID_PreferenceManager;
import com.instavideosaver.storysaver.postsaver.R;
import com.instavideosaver.storysaver.postsaver.ID_feedback.ID_FeedbackActivity;
import com.instavideosaver.storysaver.postsaver.ID_fragment.ID_DownloadFragment;
import com.instavideosaver.storysaver.postsaver.ID_fragment.ID_HomeFragment;
import com.instavideosaver.storysaver.postsaver.ID_fragment.ID_WebFragment;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_SharedPrefsForInstagram;
import com.instavideosaver.storysaver.postsaver.ID_language.ID_LanguageLocaleUtils;
import com.instavideosaver.storysaver.postsaver.ID_language.ID_LanguageActivity;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class MainActivity extends AdsBaseActivity {

    ImageView homeimg, webimg, downloadimg;
    TextView hometxt, webtxt, downloadtxt;
    View homeview, webview, downloadview;
    LinearLayout llhome, llweb, lldownload;
    NavigationView navigationView;
    private MenuItem navItem;
    DrawerLayout drawerLayout;
    String intentLogin;
    private static final int REQUEST_CODE_RUNNER = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ID_LanguageLocaleUtils.changeLocale(getBaseContext(), ID_PreferenceManager.getPrefLanguage(this));
        setStatusBarGradiant();
        SetSystemFullScreen();
        setContentView(R.layout.activity_main);


        MaterialCardView menu_btn = findViewById(R.id.menu_btn);
        MaterialCardView instaopen_btn = findViewById(R.id.instaopen_btn);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigation_view);
        homeimg = findViewById(R.id.homeimg);
        webimg = findViewById(R.id.webimg);
        downloadimg = findViewById(R.id.downloadimg);
        hometxt = findViewById(R.id.hometxt);
        webtxt = findViewById(R.id.webtxt);
        downloadtxt = findViewById(R.id.downloadtxt);
        homeview = findViewById(R.id.homeview);
        webview = findViewById(R.id.webview);
        downloadview = findViewById(R.id.downloadview);
        llhome = findViewById(R.id.llhome);
        llweb = findViewById(R.id.llweb);
        lldownload = findViewById(R.id.lldownload);


        menu_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        drawerLayout.openDrawer(GravityCompat.START);
                        navItem = navigationView.getMenu().findItem(R.id.logoutitem);
                        if (navItem != null) {
                            boolean retrievedBooleanValue = ID_PreferenceManager.getBooleanFromPreferences(MainActivity.this);
                            if (retrievedBooleanValue) {
                                navItem.setTitle(R.string.logout);
                            } else {
                                navItem.setTitle(R.string.login);
                            }
                        }
                    }
                }, MAIN_CLICK);
            }
        });

        instaopen_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    getPackageManager().getPackageInfo("com.instagram.android", 0);
                    Intent intent = getPackageManager().getLaunchIntentForPackage("com.instagram.android");
                    if (intent != null) {
                        startActivity(intent);
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Instagram is not installed. Please install Instagram.", Toast.LENGTH_LONG).show();
                }
            }
        });

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                int id = item.getItemId();
                drawerLayout.closeDrawer(GravityCompat.START);
                switch (id) {
                    case R.id.howtodownloaditem:
                        getInstance(MainActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                Intent intent = new Intent(MainActivity.this, ID_HowtoDownloadActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(intent);
                            }
                        }, MAIN_CLICK);
                        break;
                    case R.id.rateitem:
                        getInstance(MainActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                ID_RateingDialog rateingDialog = new ID_RateingDialog(MainActivity.this);
                                rateingDialog.getWindow().setBackgroundDrawable(new ColorDrawable(getResources().getColor(android.R.color.transparent)));
                                rateingDialog.setCancelable(false);
                                rateingDialog.show();
                            }
                        }, MAIN_CLICK);
                        break;
                    case R.id.shareitem:
                        try {
                            Intent shareIntent = new Intent(Intent.ACTION_SEND);
                            shareIntent.setType("text/plain");
                            shareIntent.putExtra(Intent.EXTRA_SUBJECT, getResources().getString(R.string.app_name));
                            String shareMessage = "\nLet me recommend you this application\n\n";
                            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "\n\n";
                            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                            startActivity(Intent.createChooser(shareIntent, "choose one"));
                        } catch (Exception e) {
                        }
                        break;
                    case R.id.feedbackitem:
                        getInstance(MainActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                Intent intent1 = new Intent(MainActivity.this, ID_FeedbackActivity.class);
                                startActivity(intent1);
                            }
                        }, MAIN_CLICK);
                        break;
                    case R.id.languageitem:
                        getInstance(MainActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                Intent intent1 = new Intent(MainActivity.this, ID_LanguageActivity.class);
                                startActivity(intent1);
                            }
                        }, MAIN_CLICK);
                        break;
                    case R.id.termsofuseritem:
                        getInstance(MainActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                Intent intent1 = new Intent(MainActivity.this, ID_PrivacyPolicyActivity.class);
                                intent1.putExtra("title", "toi");
                                startActivity(intent1);
                            }
                        }, MAIN_CLICK);
                        break;
                    case R.id.aboutitem:
                        getInstance(MainActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                Intent intent1 = new Intent(MainActivity.this, ID_AboutActivity.class);
                                startActivity(intent1);
                            }
                        }, MAIN_CLICK);
                        break;
                    case R.id.privacypolicyitem:
                        getInstance(MainActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                Intent intent1 = new Intent(MainActivity.this, ID_PrivacyPolicyActivity.class);
                                intent1.putExtra("title", "pp");
                                startActivity(intent1);
                            }
                        }, MAIN_CLICK);
                        break;
                    case R.id.logoutitem:
                        boolean retrievedBooleanValue = ID_PreferenceManager.getBooleanFromPreferences(MainActivity.this);
                        if (retrievedBooleanValue) {
                            final Dialog dialog2 = new Dialog(MainActivity.this);
                            dialog2.requestWindowFeature(1);
                            dialog2.setContentView(R.layout.dialog_logout);
                            dialog2.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                            dialog2.getWindow().setLayout(-1, -2);
                            dialog2.setCanceledOnTouchOutside(false);
                            dialog2.setCancelable(false);
                            dialog2.findViewById(R.id.btnyes).setOnClickListener(new View.OnClickListener() {
                                @Override
                                public final void onClick(View view) {
                                    getInstance(MainActivity.this).ShowAd(new HandleClick() {
                                        @Override
                                        public void Show(boolean adShow) {
                                            new ID_SharedPrefsForInstagram(MainActivity.this).clearSharePrefs();
                                            CookieManager.getInstance().removeAllCookies(null);
                                            ID_PreferenceManager.saveBooleanToPreferences(MainActivity.this, false);
                                            dialog2.dismiss();
                                        }
                                    }, MAIN_CLICK);

                                }
                            });
                            dialog2.findViewById(R.id.btnnotnow).setOnClickListener(new View.OnClickListener() {
                                @Override
                                public final void onClick(View view) {
                                    getInstance(MainActivity.this).ShowAd(new HandleClick() {
                                        @Override
                                        public void Show(boolean adShow) {
                                            dialog2.dismiss();
                                        }
                                    }, MAIN_CLICK);
                                }
                            });
                            dialog2.show();
                        } else {
                            homeimg.setImageDrawable(getDrawable(R.drawable.ic_navigation_home_icon));
                            webimg.setImageDrawable(getDrawable(R.drawable.ic_navigation_selectweb_icon));
                            downloadimg.setImageDrawable(getDrawable(R.drawable.ic_navigation_download_icon));
                            hometxt.setTextColor(getColor(R.color.textcolor));
                            webtxt.setTextColor(getColor(R.color.maincolor));
                            downloadtxt.setTextColor(getColor(R.color.textcolor));
                            homeview.setVisibility(View.GONE);
                            webview.setVisibility(View.VISIBLE);
                            downloadview.setVisibility(View.GONE);
                            loadFragment(new ID_WebFragment());
                        }
                        break;
                    default:
                        return true;
                }
                return true;
            }
        });


        homeimg.setImageDrawable(getDrawable(R.drawable.ic_navigation_selecthome_icon));
        webimg.setImageDrawable(getDrawable(R.drawable.ic_navigation_web_icon));
        downloadimg.setImageDrawable(getDrawable(R.drawable.ic_navigation_download_icon));
        hometxt.setTextColor(getColor(R.color.maincolor));
        webtxt.setTextColor(getColor(R.color.textcolor));
        downloadtxt.setTextColor(getColor(R.color.textcolor));
        homeview.setVisibility(View.VISIBLE);
        webview.setVisibility(View.GONE);
        downloadview.setVisibility(View.GONE);
        loadFragment(new ID_HomeFragment());

        llhome.setOnClickListener(v -> {
            getInstance(MainActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    homeimg.setImageDrawable(getDrawable(R.drawable.ic_navigation_selecthome_icon));
                    webimg.setImageDrawable(getDrawable(R.drawable.ic_navigation_web_icon));
                    downloadimg.setImageDrawable(getDrawable(R.drawable.ic_navigation_download_icon));
                    hometxt.setTextColor(getColor(R.color.maincolor));
                    webtxt.setTextColor(getColor(R.color.textcolor));
                    downloadtxt.setTextColor(getColor(R.color.textcolor));
                    homeview.setVisibility(View.VISIBLE);
                    webview.setVisibility(View.GONE);
                    downloadview.setVisibility(View.GONE);
                    loadFragment(new ID_HomeFragment());
                }
            }, MAIN_CLICK);
        });
        llweb.setOnClickListener(v -> {
            getInstance(MainActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    homeimg.setImageDrawable(getDrawable(R.drawable.ic_navigation_home_icon));
                    webimg.setImageDrawable(getDrawable(R.drawable.ic_navigation_selectweb_icon));
                    downloadimg.setImageDrawable(getDrawable(R.drawable.ic_navigation_download_icon));
                    hometxt.setTextColor(getColor(R.color.textcolor));
                    webtxt.setTextColor(getColor(R.color.maincolor));
                    downloadtxt.setTextColor(getColor(R.color.textcolor));
                    homeview.setVisibility(View.GONE);
                    webview.setVisibility(View.VISIBLE);
                    downloadview.setVisibility(View.GONE);
                    loadFragment(new ID_WebFragment());
                }
            }, MAIN_CLICK);
        });
        lldownload.setOnClickListener(v -> {
            getInstance(MainActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    homeimg.setImageDrawable(getDrawable(R.drawable.ic_navigation_home_icon));
                    webimg.setImageDrawable(getDrawable(R.drawable.ic_navigation_web_icon));
                    downloadimg.setImageDrawable(getDrawable(R.drawable.ic_navigation_selectdownload_icon));
                    hometxt.setTextColor(getColor(R.color.textcolor));
                    webtxt.setTextColor(getColor(R.color.textcolor));
                    downloadtxt.setTextColor(getColor(R.color.maincolor));
                    homeview.setVisibility(View.GONE);
                    webview.setVisibility(View.GONE);
                    downloadview.setVisibility(View.VISIBLE);
                    loadFragment(new ID_DownloadFragment());
                }
            }, MAIN_CLICK);
        });

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                Intent intent = new Intent(MainActivity.this, ExitActivity.class);
                startActivity(intent);
            }
        };

        getOnBackPressedDispatcher().addCallback(this, callback);
    }


    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public void setStatusBarGradiant() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            Drawable background = getDrawable(R.drawable.ic_main_bg_img);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getColor(android.R.color.transparent));
            window.setBackgroundDrawable(background);
        }
    }

    private void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fremlayout, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    public void SetSystemFullScreen() {
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) {
            View v = getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);

        if (!checkWriteExternalPermission()) {
            permisstion();
        }

        if (ID_PreferenceManager.getloginuser(this).equals("user")) {
            ID_PreferenceManager.putloginuser(this, "");
            homeimg.setImageDrawable(getDrawable(R.drawable.ic_navigation_home_icon));
            webimg.setImageDrawable(getDrawable(R.drawable.ic_navigation_selectweb_icon));
            downloadimg.setImageDrawable(getDrawable(R.drawable.ic_navigation_download_icon));
            hometxt.setTextColor(getColor(R.color.textcolor));
            webtxt.setTextColor(getColor(R.color.maincolor));
            downloadtxt.setTextColor(getColor(R.color.textcolor));
            homeview.setVisibility(View.GONE);
            webview.setVisibility(View.VISIBLE);
            downloadview.setVisibility(View.GONE);
            loadFragment(new ID_WebFragment());
        }
    }

    private void permisstion() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (!(ActivityCompat.checkSelfPermission(MainActivity.this, "android.permission.READ_MEDIA_VIDEO") == 0 && ActivityCompat.checkSelfPermission(MainActivity.this, "android.permission.READ_MEDIA_IMAGES") == 0 || ActivityCompat.checkSelfPermission(MainActivity.this, "android.permission.READ_MEDIA_AUDIO") == 0) && !(ActivityCompat.checkSelfPermission(MainActivity.this, "android.permission.READ_EXTERNAL_STORAGE") == 0)) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{"android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_AUDIO"}, REQUEST_CODE_RUNNER);
            }
        } else {
            if (ContextCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CODE_RUNNER);
            }
        }
    }

    private boolean checkWriteExternalPermission() {
        int res;
        if (Build.VERSION.SDK_INT >= 33) {
            String permission = android.Manifest.permission.READ_MEDIA_AUDIO;
            res = checkCallingOrSelfPermission(permission);
        } else {
            String permission = Manifest.permission.WRITE_EXTERNAL_STORAGE;
            res = checkCallingOrSelfPermission(permission);
        }
        return (res == PackageManager.PERMISSION_GRANTED);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ID_PreferenceManager.dowloadbtn(this, false);
    }

}