package com.instavideosaver.storysaver.postsaver;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class ID_SharedViewModel extends ViewModel {
    private final MutableLiveData<String> copiedLink = new MutableLiveData<>();

    public void setCopiedLink(String link) {
            copiedLink.setValue(link);
    }

    public LiveData<String> getCopiedLink() {
        return copiedLink;
    }

}