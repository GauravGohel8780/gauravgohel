package com.instavideosaver.storysaver.postsaver.ID_utils;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.instavideosaver.storysaver.postsaver.R;



public class ID_DialogUtils {

    public static void toastIconInfo(Activity activity, String str) {
        Toast toast = new Toast(activity);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setGravity(81, 0, 125);
        View inflate = activity.getLayoutInflater().inflate(R.layout.toast_icon_text, (ViewGroup) null);
        ((TextView) inflate.findViewById(R.id.message)).setText(str);
        toast.setView(inflate);
        toast.show();
    }
}
