package com.instavideosaver.storysaver.postsaver.ID_ktn.ID_storymodels;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;


public class ID_ModelGraphshortcode implements Serializable {
    @SerializedName("shortcode_media")
    private ID_ModelInstagramshortMediacode shortcode_media;

    public ID_ModelInstagramshortMediacode getShortcode_media() {
        return this.shortcode_media;
    }

    public void setShortcode_media(ID_ModelInstagramshortMediacode modelInstagramshortMediacode) {
        this.shortcode_media = modelInstagramshortMediacode;
    }
}
