package com.instavideosaver.storysaver.postsaver.ID_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.MyApplication.sharedPreferencesHelper;

import android.annotation.TargetApi;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import com.google.gson.Gson;
import com.instavideosaver.storysaver.postsaver.Ads_Common.AdsBaseActivity;
import com.instavideosaver.storysaver.postsaver.R;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.networking.AdsResponse;
import com.iten.tenoku.utils.AdUtils;

public class ID_PrivacyPolicyActivity extends AdsBaseActivity {
    AdsResponse appSettings;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStatusBarGradiant();
        setContentView(R.layout.activity_privacy_policy);

        String title = getIntent().getStringExtra("title");
        if (title.equals("toi")){
            ((TextView) findViewById(R.id.texttital)).setText(getResources().getString(R.string.terms_of_use));
            appSettings = new Gson().fromJson(sharedPreferencesHelper.getResponse(), AdsResponse.class);
            WebView webView = findViewById(R.id.webView);
            webView.loadUrl(appSettings.data.getObjAPPSETTINGS().getVPolicylink());
            webView.getSettings().setJavaScriptEnabled(true);
            webView.setWebViewClient(new WebViewClient());
        }else if (title.equals("pp")){
            ((TextView) findViewById(R.id.texttital)).setText(getResources().getString(R.string.privacy_policy));
            appSettings = new Gson().fromJson(sharedPreferencesHelper.getResponse(), AdsResponse.class);
            WebView webView = findViewById(R.id.webView);
                webView.loadUrl(appSettings.data.getObjAPPSETTINGS().getVPrivacyPolicy());
            webView.getSettings().setJavaScriptEnabled(true);
            webView.setWebViewClient(new WebViewClient());
        }

        findViewById(R.id.back_btn).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public void setStatusBarGradiant() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            Drawable background = getDrawable(R.drawable.ic_main_bg_img);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getColor(android.R.color.transparent));
            window.setBackgroundDrawable(background);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}