package com.instavideosaver.storysaver.postsaver.ID_ktn.ID_storymodels;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;


public class ID_ModelGetEdgetoNode implements Serializable {
    @SerializedName("edges")
    private List<ID_ModelEdNode> modelEdNodes;

    public List<ID_ModelEdNode> getModelEdNodes() {
        return this.modelEdNodes;
    }

    public void setModelEdNodes(List<ID_ModelEdNode> list) {
        this.modelEdNodes = list;
    }
}
