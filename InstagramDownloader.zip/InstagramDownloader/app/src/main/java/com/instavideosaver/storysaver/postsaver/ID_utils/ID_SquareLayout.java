package com.instavideosaver.storysaver.postsaver.ID_utils;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;


public class ID_SquareLayout extends RelativeLayout {
    public ID_SquareLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public ID_SquareLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public ID_SquareLayout(Context context) {
        super(context);
    }

    @Override
    public void onMeasure(int i, int i2) {
        setMeasuredDimension(getDefaultSize(0, i), getDefaultSize(0, i2));
        int makeMeasureSpec = MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
        super.onMeasure(makeMeasureSpec, makeMeasureSpec);
    }
}
