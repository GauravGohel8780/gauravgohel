package com.instavideosaver.storysaver.postsaver.ID_language;

public class ID_LanguageModel {
    private int imageResource;
    private String text;
    private String lngcode;

    public ID_LanguageModel(int imageResource, String text, String lngcode) {
        this.imageResource = imageResource;
        this.text = text;
        this.lngcode = lngcode;
    }

    public int getImageResource() {
        return imageResource;
    }

    public String getText() {
        return text;
    }

    public String getLngcode() {
        return lngcode;
    }
}
