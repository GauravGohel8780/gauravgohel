package com.instavideosaver.storysaver.postsaver.ID_Activity;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.instavideosaver.storysaver.postsaver.Ads_Common.AdsBaseActivity;
import com.instavideosaver.storysaver.postsaver.databinding.ActivityLoginInstagramBinding;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_SharedPrefsForInstagram;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin.ID_ModelInstagramPref;
import com.instavideosaver.storysaver.postsaver.ID_utils.ID_iUtils;

import java.util.HashMap;
import java.util.Map;


public class ID_InstagramLoginActivity extends AdsBaseActivity {
    private ActivityLoginInstagramBinding binding;
    Map<String, String> extraHeaders = new HashMap();
    int randomnumber = 0;


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ActivityLoginInstagramBinding inflate = ActivityLoginInstagramBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView(inflate.getRoot());
        this.randomnumber = ID_iUtils.getRandomNumber(ID_iUtils.UserAgentsListLogin.length);
        this.extraHeaders.put("x-requested-with", "XMLHttpRequest");
        LoadPage();
        this.binding.swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public final void onRefresh() {
                ID_InstagramLoginActivity.this.LoadPage();
            }
        });
    }

    public void LoadPage() {
        this.binding.webView.getSettings().setJavaScriptEnabled(true);
        this.binding.webView.clearCache(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(this.binding.webView, true);
        this.binding.webView.setWebViewClient(new MyWebviewClient());
        CookieSyncManager.createInstance(this);
        CookieManager.getInstance().removeAllCookie();
        try {
            this.binding.webView.getSettings().setUserAgentString(ID_iUtils.UserAgentsListLogin[this.randomnumber] + "");
        } catch (Exception e) {
            this.binding.webView.getSettings().setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36");
        }
        this.binding.webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView webView, int i) {
                ID_InstagramLoginActivity.this.binding.swipeRefreshLayout.setRefreshing(i != 100);
            }
        });
        this.binding.webView.loadUrl("http://www.instagram.com/accounts/login", this.extraHeaders);
    }

    public String getCookie(String str, String str2) {
        String[] split;
        String cookie = CookieManager.getInstance().getCookie(str);
        if (cookie != null && !cookie.isEmpty()) {
            for (String str3 : cookie.split(";")) {
                if (str3.contains(str2)) {
                    return str3.split("=")[1];
                }
            }
        }
        return null;
    }

    public class MyWebviewClient extends WebViewClient {
        private MyWebviewClient() {
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            try {
                webView.getSettings().setUserAgentString(ID_iUtils.UserAgentsListLogin[ID_InstagramLoginActivity.this.randomnumber] + "");
            } catch (Exception e) {
                System.out.println("dsakdjasdjasd " + e.getMessage());
                webView.getSettings().setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36");
            }
            webView.loadUrl(str, ID_InstagramLoginActivity.this.extraHeaders);
            return true;
        }

        @Override
        public void onLoadResource(WebView webView, String str) {
            super.onLoadResource(webView, str);
        }

        @Override
        public void onPageFinished(WebView webView, String str) {
            super.onPageFinished(webView, str);
            String cookie = CookieManager.getInstance().getCookie(str);
            try {
                String cookie2 = ID_InstagramLoginActivity.this.getCookie(str, "sessionid");
                String cookie3 = ID_InstagramLoginActivity.this.getCookie(str, "csrftoken");
                String cookie4 = ID_InstagramLoginActivity.this.getCookie(str, "ds_user_id");
                if (cookie2 == null || cookie3 == null || cookie4 == null) {
                    return;
                }
                new ID_SharedPrefsForInstagram(ID_InstagramLoginActivity.this).setPreference(new ID_ModelInstagramPref(cookie2, cookie4, cookie, cookie3, "true"));
                webView.destroy();
                Intent intent = new Intent();
                intent.putExtra("result", "result");
                ID_InstagramLoginActivity.this.setResult(-1, intent);
                ID_InstagramLoginActivity.this.finish();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onReceivedError(WebView webView, int i, String str, String str2) {
            super.onReceivedError(webView, i, str, str2);
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView webView, WebResourceRequest webResourceRequest) {
            return super.shouldInterceptRequest(webView, webResourceRequest);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
            return super.shouldOverrideUrlLoading(webView, webResourceRequest);
        }
    }
}
