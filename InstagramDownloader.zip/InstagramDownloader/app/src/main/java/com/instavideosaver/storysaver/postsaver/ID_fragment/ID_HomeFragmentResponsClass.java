package com.instavideosaver.storysaver.postsaver.ID_fragment;

import android.content.DialogInterface;
import android.content.Intent;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.FragmentActivity;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.instavideosaver.storysaver.postsaver.ID_Activity.ID_InstagramLoginActivity;
import com.instavideosaver.storysaver.postsaver.R;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_DownloadFileMain;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_SharedPrefsForInstagram;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin.ID_CarouselMedia;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin.ID_Item;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin.ID_ModelInstaWithLogin;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin.ID_ModelInstagramPref;
import com.instavideosaver.storysaver.postsaver.ID_utils.ID_Utils;

import java.lang.reflect.Type;
import java.util.List;

import kotlin.jvm.internal.Intrinsics;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public final class ID_HomeFragmentResponsClass implements Callback<JsonObject> {
    final String URL;
    final ID_HomeFragment homeFragment;


    public ID_HomeFragmentResponsClass(ID_HomeFragment pasteFragment, String str) {
        homeFragment = pasteFragment;
        this.URL = str;
    }

    @Override
    public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
        FragmentActivity fragmentActivity;
        ID_ModelInstagramPref preference;
        Intrinsics.checkNotNullParameter(call, "call");
        Intrinsics.checkNotNullParameter(response, "response");
        try {
            try {
                Type type = new TypeToken<ID_ModelInstaWithLogin>() {
                }.getType();
                Intrinsics.checkNotNullExpressionValue(type, "object : TypeToken<ModelInstaWithLogin?>() {}.type");
                Object fromJson = new Gson().fromJson(response.body(), type);
                Intrinsics.checkNotNullExpressionValue(fromJson, "Gson().fromJson(\n       …ype\n                    )");
                ID_ModelInstaWithLogin modelInstaWithLogin = (ID_ModelInstaWithLogin) fromJson;
                System.out.println((Object) ("workkkkk777 " + modelInstaWithLogin.getItems().get(0).getCode()));
                System.out.println((String) ("workkkkk777777" + modelInstaWithLogin.getItems().get(0).getUser().getProfile_pic_url()));
                if (modelInstaWithLogin.getItems().get(0).getMediaType() == 8) {
                    homeFragment.setMyInstaUsername(modelInstaWithLogin.getItems().get(0).getUser().getUsername());
                    List<ID_CarouselMedia> carouselMedia = modelInstaWithLogin.getItems().get(0).getCarouselMedia();
                    Intrinsics.checkNotNullExpressionValue(carouselMedia, "modelGetEdgetoNode.carouselMedia");
                    int size = carouselMedia.size();
                    for (int i = 0; i < size; i++) {
                        System.err.println("workkkkkkkkklogin issue " + carouselMedia.get(i).getMediaType());
                        if (carouselMedia.get(i).getMediaType() == 2) {
                            System.err.println("workkkkkkkkklogin issue vid " + carouselMedia.get(i).getVideoVersions().get(0).geditTextPasteUrl());
                            homeFragment.setMyVideoUrlIs(carouselMedia.get(i).getVideoVersions().get(0).geditTextPasteUrl());
                            ID_DownloadFileMain.startDownloading(homeFragment.getContext(), homeFragment.getMyVideoUrlIs(), homeFragment.getMyInstaUsername() , ".mp4",modelInstaWithLogin.getItems().get(0).getUser().getProfile_pic_url());
                            try {
                                homeFragment.dismissMyDialogFrag();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            homeFragment.setMyVideoUrlIs("");
                        } else {
                            System.err.println("workkkkkkkkklogin issue img " + carouselMedia.get(i).getImageVersions2().getCandidates().get(0).geditTextPasteUrl());
                            homeFragment.setMyPhotoUrlIs(carouselMedia.get(i).getImageVersions2().getCandidates().get(0).geditTextPasteUrl());
                            ID_DownloadFileMain.startDownloading(homeFragment.getContext(), homeFragment.getMyPhotoUrlIs(), homeFragment.getMyInstaUsername() , ".png",modelInstaWithLogin.getItems().get(0).getUser().getProfile_pic_url());
                            homeFragment.setMyPhotoUrlIs("");
                            try {
                                homeFragment.dismissMyDialogFrag();
                            } catch (Exception e2) {
                                e2.printStackTrace();
                            }
                        }
                    }
                    return;
                }
                ID_Item item = modelInstaWithLogin.getItems().get(0);
                homeFragment.setMyInstaUsername(modelInstaWithLogin.getItems().get(0).getUser().getUsername());
                if (item.getMediaType() == 2) {
                    homeFragment.setMyVideoUrlIs(item.getVideoVersions().get(0).geditTextPasteUrl());
                    ID_DownloadFileMain.startDownloading(homeFragment.getContext(), homeFragment.getMyVideoUrlIs(), homeFragment.getMyInstaUsername() , ".mp4",modelInstaWithLogin.getItems().get(0).getUser().getProfile_pic_url());
                    try {
                        homeFragment.dismissMyDialogFrag();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    homeFragment.setMyVideoUrlIs("");
                    return;
                }
                homeFragment.setMyPhotoUrlIs(item.getImageVersions2().getCandidates().get(0).geditTextPasteUrl());
                ID_DownloadFileMain.startDownloading(homeFragment.getContext(), homeFragment.getMyPhotoUrlIs(), homeFragment.getMyInstaUsername(), ".png",modelInstaWithLogin.getItems().get(0).getUser().getProfile_pic_url());
                try {
                    homeFragment.dismissMyDialogFrag();
                } catch (Exception e4) {
                    e4.printStackTrace();
                }
                homeFragment.setMyPhotoUrlIs("");
                return;
            } catch (Exception e5) {
                System.err.println("workkkkkkkkk 5nn errrr " + e5.getMessage());
                System.err.println("workkkkkkkkk 4");
                preference = new ID_SharedPrefsForInstagram(homeFragment.getContext()).getPreference();
                if (preference == null) {
                }
                homeFragment.dismissMyDialogFrag();
                System.err.println("workkkkkkkkk 5.1");
                e5.printStackTrace();
                ID_Utils.ShowToast(homeFragment.getContext(), homeFragment.getString(R.string.error_occ));
                return;
            }
        } catch (Exception e6) {
            try {
                homeFragment.dismissMyDialogFrag();
                System.err.println("workkkkkkkkk 5.1");
                e6.printStackTrace();
                ID_Utils.ShowToast(homeFragment.getContext(), homeFragment.getString(R.string.error_occ));
                return;
            } catch (Exception e7) {
                e7.printStackTrace();
                fragmentActivity = (FragmentActivity) homeFragment.getContext();
                Intrinsics.checkNotNull(fragmentActivity);
                final ID_HomeFragment pasteFragment = homeFragment;
                fragmentActivity.runOnUiThread(new Runnable() { 
                    @Override 
                    public final void run() {
                        FragmentActivity fragmentActivity;
                        FragmentActivity fragmentActivity2;
                        Intrinsics.checkNotNullParameter(homeFragment, "homeFragment");
                        homeFragment.dismissMyDialogFrag();
                        fragmentActivity = (FragmentActivity) homeFragment.getContext();
                        Intrinsics.checkNotNull(fragmentActivity);
                        if (fragmentActivity.isFinishing()) {
                            return;
                        }
                        fragmentActivity2 = (FragmentActivity) homeFragment.getContext();
                        Intrinsics.checkNotNull(fragmentActivity2);
                        AlertDialog create = new AlertDialog.Builder(fragmentActivity2).create();
                        Intrinsics.checkNotNullExpressionValue(create, "Builder(myselectedActivi…                .create()");
                        create.setTitle(homeFragment.getString(R.string.logininsta));
                        create.setMessage(homeFragment.getString(R.string.urlisprivate));
                        create.setButton(-1, homeFragment.getString(R.string.logininsta), new DialogInterface.OnClickListener() {
                            @Override
                            public final void onClick(DialogInterface dialogInterface, int i) {
                                Intrinsics.checkNotNullParameter(homeFragment, "homeFragment");
                                dialogInterface.dismiss();
                                homeFragment.startActivityForResult(new Intent(homeFragment.getContext(), ID_InstagramLoginActivity.class), 200);
                            }
                        });
                        create.setButton(-2, homeFragment.getString(R.string.cancel), new DialogInterface.OnClickListener() {
                            @Override
                            public final void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        });
                        create.show();
                    }
                });
                return;
            }
        }
    }


    @Override
    public void onFailure(Call<JsonObject> call, Throwable t) {
        Intrinsics.checkNotNullParameter(call, "call");
        Intrinsics.checkNotNullParameter(t, "t");
        System.out.println((Object) "response1122334455:   Failed0");
        try {
            homeFragment.dismissMyDialogFrag();
        } catch (Exception e) {
            e.printStackTrace();
        }
        Toast.makeText(homeFragment.getContext(), homeFragment.getResources().getString(R.string.somthing), Toast.LENGTH_SHORT).show();
    }
}
