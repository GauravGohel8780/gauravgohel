package com.instavideosaver.storysaver.postsaver.ID_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatRatingBar;
import androidx.cardview.widget.CardView;

import com.instavideosaver.storysaver.postsaver.ID_PreferenceManager;
import com.instavideosaver.storysaver.postsaver.R;
import com.instavideosaver.storysaver.postsaver.ID_feedback.ID_FeedbackActivity;
import com.instavideosaver.storysaver.postsaver.ID_language.ID_LanguageLocaleUtils;
import com.iten.tenoku.ad.HandleClick.HandleClick;

public class ID_RateingDialog extends Dialog {

    private float userrate = 5;
    Activity activity;

    public ID_RateingDialog(@NonNull Activity activity) {
        super(activity);
        this.activity = activity;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ID_LanguageLocaleUtils.changeLocale(getContext(), ID_PreferenceManager.getPrefLanguage(getContext()));
        setContentView(R.layout.rate_dialog);

        ImageView rateimg = findViewById(R.id.rateimg);
        ImageView dismissbtn = findViewById(R.id.dismissbtn);
        AppCompatRatingBar ratebtn = findViewById(R.id.ratebtn);
        CardView btnsubmit = findViewById(R.id.btnsubmit);


        ratebtn.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if (rating <= 1) {
                    rateimg.setImageResource(R.drawable.ic_star_1_image);
                } else if (rating <= 2) {
                    rateimg.setImageResource(R.drawable.ic_star_2_image);
                } else if (rating <= 3) {
                    rateimg.setImageResource(R.drawable.ic_star_3_image);
                } else if (rating <= 4) {
                    rateimg.setImageResource(R.drawable.ic_star_4_image);
                } else if (rating <= 5) {
                    rateimg.setImageResource(R.drawable.ic_star_5_image);
                }
                animateImage(rateimg);

                userrate = rating;
            }
        });

        btnsubmit.setOnClickListener(v -> {
            dismiss();
            if (userrate >= 4) {
                Uri uri = Uri.parse("market://details?id=" + getContext().getPackageName());
                Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
                try {
                    getContext().startActivity(myAppLinkToMarket);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), " unable to find market app", Toast.LENGTH_LONG).show();
                }
            } else {
                getInstance(activity).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent1 = new Intent(getContext(), ID_FeedbackActivity.class);
                        getContext().startActivity(intent1);
                    }
                }, MAIN_CLICK);
            }

        });
        dismissbtn.setOnClickListener(v -> {
            getInstance(activity).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    dismiss();
                }
            }, MAIN_CLICK);

        });
    }

    private void animateImage(ImageView rateimg) {
        ScaleAnimation scaleAnimation = new ScaleAnimation(0, 1f, 0, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        scaleAnimation.setFillAfter(true);
        scaleAnimation.setDuration(200);
        rateimg.startAnimation(scaleAnimation);
    }
}
