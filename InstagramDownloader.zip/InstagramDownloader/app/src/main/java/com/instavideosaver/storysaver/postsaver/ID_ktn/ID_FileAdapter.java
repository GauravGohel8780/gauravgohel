package com.instavideosaver.storysaver.postsaver.ID_ktn;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Activity;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.provider.BaseColumns;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.instavideosaver.storysaver.postsaver.ID_Activity.ID_PlayActivity;
import com.instavideosaver.storysaver.postsaver.R;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ID_FileAdapter extends RecyclerView.Adapter<ID_FileAdapter.ViewHolder> {
    private Activity context;
    private ArrayList<ID_VideoFileModel> files;

    public static final int DELETE_REQUEST_CODE = 13;

    public ID_FileAdapter(Activity context, ArrayList<ID_VideoFileModel> arrayList) {
        this.context = context;
        this.files = arrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_downloaded, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        ID_VideoFileModel file = this.files.get(i);
        try {
            if (file.getFileName().substring(file.getFileName().lastIndexOf(".")).equals(".mp4")) {
                viewHolder.imageViewPlay.setVisibility(View.VISIBLE);
                viewHolder.txtPlay.setVisibility(View.VISIBLE);
            } else {
                viewHolder.imageViewPlay.setVisibility(View.GONE);
                viewHolder.txtPlay.setVisibility(View.GONE);
            }
            Glide.with(this.context).load(file.getFilePath()).into(viewHolder.imageViewCover);
            viewHolder.maintext.setText(file.getFileName());
            viewHolder.txtPlay.setText(getVideoDuration(file.getFilePath()));
            viewHolder.usernamemain.setText(extractSubstring(file.getFileName()));
        } catch (Exception unused) {
        }
        viewHolder.relativeLayoutContent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(context).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(context, ID_PlayActivity.class);
                        intent.putExtra("path", file.getFilePath());
                        intent.putExtra("text", extractSubstring(file.getFileName()));
                        context.startActivity(intent);
                    }
                }, MAIN_CLICK);


            }
        });
        viewHolder.menubtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(context).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context);
                        View bottomSheetView = LayoutInflater.from(context).inflate(R.layout.bottom_seet_dialog, null);
                        bottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(context.getResources().getColor(android.R.color.transparent)));
                        bottomSheetDialog.setCancelable(false);
                        bottomSheetDialog.setContentView(bottomSheetView);
                        ImageView dismissbtn = bottomSheetView.findViewById(R.id.dismissbtn);
                        LinearLayout btnrepost = bottomSheetView.findViewById(R.id.btnrepost);
                        LinearLayout btnshare = bottomSheetView.findViewById(R.id.btnshare);
                        LinearLayout btndelete = bottomSheetView.findViewById(R.id.btndelete);
                        dismissbtn.setOnClickListener(v -> {
                            bottomSheetDialog.dismiss();
                        });
                        btnrepost.setOnClickListener(v -> {
                            shareToInstagram(file.getFilePath());
                            bottomSheetDialog.dismiss();
                        });
                        btnshare.setOnClickListener(v -> {
                            File file1 = new File(file.getFilePath());
                            Uri contentUri = FileProvider.getUriForFile(context, "com.instavideosaver.storysaver.postsaver.file_provider", file1);
                            Intent shareIntent = new Intent(Intent.ACTION_SEND);
                            if (isImageFile(file1)) {
                                shareIntent.setType("image/*");
                            } else if (isVideoFile(file1)) {
                                shareIntent.setType("video/*");
                            } else {
                                Toast.makeText(context, "Unsupported file type", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
                            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            shareIntent.putExtra("interactive_asset_uri", contentUri);
                            context.startActivity(shareIntent);
                            bottomSheetDialog.dismiss();
                        });
                        btndelete.setOnClickListener(v -> {
                            final Dialog dialog2 = new Dialog(context);
                            dialog2.requestWindowFeature(1);
                            dialog2.setContentView(R.layout.dialog_logout);
                            dialog2.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                            dialog2.getWindow().setLayout(-1, -2);
                            dialog2.setCanceledOnTouchOutside(false);
                            dialog2.setCancelable(false);

                            ((TextView) dialog2.findViewById(R.id.txtdelete)).setText(R.string.are_you_sure_you_want_to_ndelete);

                            dialog2.findViewById(R.id.btnyes).setOnClickListener(new View.OnClickListener() {
                                @Override
                                public final void onClick(View view) {
                                    Uri uri;
                                    if (file.getFileName().substring(file.getFileName().lastIndexOf(".")).equals(".mp4")) {
                                        uri = getvideourl(Uri.parse(file.getFilePath()));
                                    } else {
                                        uri = getimageurl(Uri.parse(file.getFilePath()));
                                    }
                                    try {
                                        deleteAPI28(uri, context);
                                    } catch (Exception e) {
                                        Toast.makeText(context, "Permission needed", Toast.LENGTH_SHORT).show();
                                        try {
                                            deleteAPI30(uri);
                                        } catch (IntentSender.SendIntentException e1) {
                                            e1.printStackTrace();
                                        }
                                    }
                                    files.remove(i);
                                    notifyItemRemoved(i);
                                    notifyDataSetChanged();
                                    dialog2.dismiss();
                                }
                            });
                            dialog2.findViewById(R.id.btnnotnow).setOnClickListener(new View.OnClickListener() {
                                @Override
                                public final void onClick(View view) {
                                    dialog2.dismiss();
                                }
                            });
                            dialog2.show();
                            bottomSheetDialog.dismiss();
                        });
                        bottomSheetDialog.show();
                    }
                }, MAIN_CLICK);
            }
        });
    }

    private void shareToInstagram(String filePath) {
        File file = new File(filePath);
        Uri contentUri = FileProvider.getUriForFile(context, "com.instavideosaver.storysaver.postsaver.file_provider", file);
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        if (isImageFile(file)) {
            shareIntent.setType("image/*");
        } else if (isVideoFile(file)) {
            shareIntent.setType("video/*");
        } else {
            Toast.makeText(context, "Unsupported file type", Toast.LENGTH_SHORT).show();
            return;
        }

        shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
        shareIntent.setPackage("com.instagram.android");
        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        shareIntent.putExtra("interactive_asset_uri", contentUri);
        context.startActivity(shareIntent);
    }

    private boolean isImageFile(File file) {
        String fileName = file.getName().toLowerCase();
        return fileName.endsWith(".jpg") || fileName.endsWith(".jpeg") || fileName.endsWith(".png");
    }

    private boolean isVideoFile(File file) {
        String fileName = file.getName().toLowerCase();
        return fileName.endsWith(".mp4") || fileName.endsWith(".3gp") || fileName.endsWith(".mkv");
    }

    private String getVideoDuration(String filePath) throws IOException {
        MediaMetadataRetriever retriever = null;
        try {
            retriever = new MediaMetadataRetriever();
            retriever.setDataSource(filePath);
            String duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if (duration != null && !duration.isEmpty()) {
                long durationInMillis = Long.parseLong(duration);
                long seconds = durationInMillis / 1000;
                long minutes = (seconds % 3600) / 60;
                long hours = seconds / 3600;
                return String.format("%02d:%02d", minutes, seconds % 60);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (retriever != null) {
                retriever.release();
            }
        }
        return "N/A";
    }

    public String extractSubstring(String inputText) {
        int startIndex = inputText.indexOf("ReelDownloader");
        if (startIndex != -1) {
            return inputText.substring(0, startIndex);
        } else {
            return "Substring not found";
        }
    }

    @Override
    public int getItemCount() {
        return files.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView imageViewPlay, imageViewCover, menubtn;
        public RelativeLayout relativeLayoutContent;
        TextView txtPlay, maintext, usernamemain;

        public ViewHolder(View view) {
            super(view);
            this.relativeLayoutContent = (RelativeLayout) view.findViewById(R.id.relativeLayoutContent);
            this.imageViewCover = (ImageView) view.findViewById(R.id.imageViewCover);
            this.imageViewPlay = (ImageView) view.findViewById(R.id.imageViewPlay);
            this.menubtn = (ImageView) view.findViewById(R.id.menubtn);
            this.txtPlay = (TextView) view.findViewById(R.id.txtPlay);
            this.usernamemain = (TextView) view.findViewById(R.id.usernamemain);
            this.maintext = (TextView) view.findViewById(R.id.textmain);
        }
    }

    private Uri getimageurl(Uri imageUri) {
        String[] projections = {MediaStore.MediaColumns._ID};
        Cursor cursor = context.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projections, MediaStore.MediaColumns.DATA + "=?", new String[]{imageUri.getPath()}, null);
        long id = 0;
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                id = cursor.getLong(cursor.getColumnIndexOrThrow(BaseColumns._ID));
            }
        }
        cursor.close();
        return Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, String.valueOf((int) id));
    }

    private Uri getvideourl(Uri imageUri) {
        String[] projections = {MediaStore.MediaColumns._ID};
        Cursor cursor = context.getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projections, MediaStore.MediaColumns.DATA + "=?", new String[]{imageUri.getPath()}, null);
        long id = 0;
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                id = cursor.getLong(cursor.getColumnIndexOrThrow(BaseColumns._ID));
            }
        }
        cursor.close();
        return Uri.withAppendedPath(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, String.valueOf((int) id));
    }


    public static int deleteAPI28(Uri uri, Context context1) {
        ContentResolver resolver = context1.getContentResolver();
        return resolver.delete(uri, null, null);
    }

    private void deleteAPI30(Uri imageUri) throws IntentSender.SendIntentException {
        ContentResolver contentResolver = context.getContentResolver();
        List<Uri> uriList = new ArrayList<>();
        Collections.addAll(uriList, imageUri);
        PendingIntent pendingIntent = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            pendingIntent = MediaStore.createDeleteRequest(contentResolver, uriList);
        }
        context.startIntentSenderForResult(pendingIntent.getIntentSender(), DELETE_REQUEST_CODE, null, 0, 0, 0, null);
    }
}