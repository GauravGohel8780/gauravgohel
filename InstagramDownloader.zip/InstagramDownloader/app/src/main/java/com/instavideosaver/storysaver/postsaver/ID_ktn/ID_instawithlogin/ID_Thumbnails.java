package com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;


public class ID_Thumbnails implements Serializable {
    @SerializedName("file_size_kb")
    private long fileSizekb;
    @SerializedName("max_thumbnails_per_sprite")
    private long maxThumbnailsPerSprite;
    @SerializedName("rendered_width")
    private long renderedWidth;
    @SerializedName("sprite_height")
    private long spriteHeight;
    @SerializedName("sprite_urls")
    private List<String> spriteUrls;
    @SerializedName("sprite_width")
    private long spriteWidth;
    @SerializedName("thumbnail_duration")
    private double thumbnailDuration;
    @SerializedName("thumbnail_height")
    private long thumbnailHeight;
    @SerializedName("thumbnail_width")
    private long thumbnailWidth;
    @SerializedName("thumbnails_per_row")
    private long thumbnailsPerRow;
    @SerializedName("total_thumbnail_num_per_sprite")
    private long totalThumbnailNumPerSprite;
    @SerializedName("video_length")
    private double videoLength;

    @SerializedName("video_length")
    public double getVideoLength() {
        return this.videoLength;
    }

    @SerializedName("video_length")
    public void setVideoLength(double d) {
        this.videoLength = d;
    }

    @SerializedName("thumbnail_width")
    public long getThumbnailWidth() {
        return this.thumbnailWidth;
    }

    @SerializedName("thumbnail_width")
    public void setThumbnailWidth(long j) {
        this.thumbnailWidth = j;
    }

    @SerializedName("thumbnail_height")
    public long getThumbnailHeight() {
        return this.thumbnailHeight;
    }

    @SerializedName("thumbnail_height")
    public void setThumbnailHeight(long j) {
        this.thumbnailHeight = j;
    }

    @SerializedName("thumbnail_duration")
    public double getThumbnailDuration() {
        return this.thumbnailDuration;
    }

    @SerializedName("thumbnail_duration")
    public void setThumbnailDuration(double d) {
        this.thumbnailDuration = d;
    }

    @SerializedName("sprite_urls")
    public List<String> getSpriteUrls() {
        return this.spriteUrls;
    }

    @SerializedName("sprite_urls")
    public void setSpriteUrls(List<String> list) {
        this.spriteUrls = list;
    }

    @SerializedName("thumbnails_per_row")
    public long getThumbnailsPerRow() {
        return this.thumbnailsPerRow;
    }

    @SerializedName("thumbnails_per_row")
    public void setThumbnailsPerRow(long j) {
        this.thumbnailsPerRow = j;
    }

    @SerializedName("total_thumbnail_num_per_sprite")
    public long getTotalThumbnailNumPerSprite() {
        return this.totalThumbnailNumPerSprite;
    }

    @SerializedName("total_thumbnail_num_per_sprite")
    public void setTotalThumbnailNumPerSprite(long j) {
        this.totalThumbnailNumPerSprite = j;
    }

    @SerializedName("max_thumbnails_per_sprite")
    public long getMaxThumbnailsPerSprite() {
        return this.maxThumbnailsPerSprite;
    }

    @SerializedName("max_thumbnails_per_sprite")
    public void setMaxThumbnailsPerSprite(long j) {
        this.maxThumbnailsPerSprite = j;
    }

    @SerializedName("sprite_width")
    public long getSpriteWidth() {
        return this.spriteWidth;
    }

    @SerializedName("sprite_width")
    public void setSpriteWidth(long j) {
        this.spriteWidth = j;
    }

    @SerializedName("sprite_height")
    public long getSpriteHeight() {
        return this.spriteHeight;
    }

    @SerializedName("sprite_height")
    public void setSpriteHeight(long j) {
        this.spriteHeight = j;
    }

    @SerializedName("rendered_width")
    public long getRenderedWidth() {
        return this.renderedWidth;
    }

    @SerializedName("rendered_width")
    public void setRenderedWidth(long j) {
        this.renderedWidth = j;
    }

    @SerializedName("file_size_kb")
    public long getFileSizekb() {
        return this.fileSizekb;
    }

    @SerializedName("file_size_kb")
    public void setFileSizekb(long j) {
        this.fileSizekb = j;
    }
}
