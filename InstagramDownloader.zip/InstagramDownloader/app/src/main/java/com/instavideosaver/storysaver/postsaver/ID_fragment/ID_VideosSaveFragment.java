package com.instavideosaver.storysaver.postsaver.ID_fragment;

import android.media.MediaMetadataRetriever;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.instavideosaver.storysaver.postsaver.R;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_FileAdapter;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_VideoFileModel;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ID_VideosSaveFragment extends Fragment {
    LinearLayout linearLayoutHolder;

    private RecyclerView recyclerView;
    private ID_FileAdapter fileAdapter;
    private ArrayList<ID_VideoFileModel> fileArrayList;
    ShimmerFrameLayout simmer;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View inflate = inflater.inflate(R.layout.fragment_videos_save, container, false);
        this.simmer = (ShimmerFrameLayout) inflate.findViewById(R.id.simmer);
        this.linearLayoutHolder = (LinearLayout) inflate.findViewById(R.id.linearLayoutPlaceHold);

        recyclerView = inflate.findViewById(R.id.recyclerViewStory);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        fileArrayList = new ArrayList<>();
        fileAdapter = new ID_FileAdapter(getActivity(), fileArrayList);
        recyclerView.setAdapter(fileAdapter);
        new LoadFilesTask().execute();
        return inflate;
    }

    private class LoadFilesTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            simmer.setVisibility(View.VISIBLE);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            String folderPath = Environment.getExternalStorageDirectory() + "/Download/ReelDownloader";
            File folder = new File(folderPath);

            if (folder.exists() && folder.isDirectory()) {
                File[] listFiles = folder.listFiles();
                if (listFiles != null) {
                    for (File file : listFiles) {
                        if (file.isFile() && (file.getName().endsWith(".mp4"))) {
                            long videoDuration = getVideoDuration(file);
                            fileArrayList.add(new ID_VideoFileModel(file.getName(), file.getAbsolutePath(), videoDuration));
                        }
                    }
                    if (!fileArrayList.isEmpty()) {
                        Collections.sort(fileArrayList, new Comparator<ID_VideoFileModel>() {
                            @Override
                            public int compare(ID_VideoFileModel model1, ID_VideoFileModel model2) {
                                File file1 = new File(model1.getFilePath());
                                File file2 = new File(model2.getFilePath());
                                long lastModified1 = file1.lastModified();
                                long lastModified2 = file2.lastModified();
                                return Long.compare(lastModified2, lastModified1);
                            }
                        });
                    }
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            // Update UI on the main thread
            if (!fileArrayList.isEmpty()) {
                fileAdapter.notifyDataSetChanged();
                linearLayoutHolder.setVisibility(View.GONE);
            } else {
                linearLayoutHolder.setVisibility(View.VISIBLE);
            }
            simmer.setVisibility(View.GONE);
        }
    }


    private long getVideoDuration(File videoFile) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(videoFile.getAbsolutePath());
            String durationString = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);

            if (durationString != null) {
                long durationMillis = Long.parseLong(durationString);
                return durationMillis / 1000;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                retriever.release();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return 0;
    }
}