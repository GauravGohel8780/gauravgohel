package com.instavideosaver.storysaver.postsaver.ID_language;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.instavideosaver.storysaver.postsaver.ID_PreferenceManager;
import com.instavideosaver.storysaver.postsaver.R;

import java.util.ArrayList;
public class ID_LanguageAdapter extends RecyclerView.Adapter<ID_LanguageAdapter.ViewHolder> {

    private ArrayList<ID_LanguageModel> dataList;
    private int selectedItemPosition = -1;
    Activity context;

    public ID_LanguageAdapter(ArrayList<ID_LanguageModel> dataList, Activity context) {
        this.dataList = dataList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_language, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        ID_LanguageModel currentItem = dataList.get(position);

        holder.imageView.setImageResource(currentItem.getImageResource());
        holder.textView.setText(currentItem.getText());


        if (ID_PreferenceManager.getPrefLanguage(context).equals(dataList.get(position).getLngcode())){
            holder.lll.setBackgroundColor(context.getResources().getColor(R.color.maincolor));
            holder.textView.setTextColor(context.getResources().getColor(R.color.white));
        }else {
            if (selectedItemPosition == position) {
                holder.lll.setBackgroundColor(context.getResources().getColor(R.color.maincolor));
                holder.textView.setTextColor(context.getResources().getColor(R.color.white));
            } else {
                holder.lll.setBackgroundColor(context.getResources().getColor(R.color.white));
                holder.textView.setTextColor(context.getResources().getColor(R.color.black));
            }
        }

        holder.lll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ID_PreferenceManager.putPrefLanguage(context, dataList.get(position).getLngcode());
                ID_LanguageLocaleUtils.changeLocale(context, ID_PreferenceManager.getPrefLanguage(context));
                selectedItemPosition = position;
                notifyDataSetChanged();


            }
        });


    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textView;
        LinearLayout lll;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            textView = itemView.findViewById(R.id.textView);
            lll = itemView.findViewById(R.id.lll);
        }
    }
}
