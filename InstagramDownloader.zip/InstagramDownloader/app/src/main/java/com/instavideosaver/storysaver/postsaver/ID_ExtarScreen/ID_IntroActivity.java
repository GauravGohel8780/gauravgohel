package com.instavideosaver.storysaver.postsaver.ID_ExtarScreen;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import com.instavideosaver.storysaver.postsaver.ID_Activity.MainActivity;
import com.instavideosaver.storysaver.postsaver.Ads_Common.AdsBaseActivity;
import com.instavideosaver.storysaver.postsaver.ID_PreferenceManager;
import com.instavideosaver.storysaver.postsaver.R;
import com.iten.tenoku.ad.AdShow;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;


public class ID_IntroActivity extends AdsBaseActivity {

    ViewPager viewpagerIntro;
    ID_IntroPagerAdapter introPagerAdapter;
    int focusPos = 0;
    TextView tvNextBtn;
    TextView tvDesc, tvPagerTitle;
    LinearLayout llindicator;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);

        viewpagerIntro = findViewById(R.id.ViewpagerIntro);
        llindicator = findViewById(R.id.llIndicator);

        tvNextBtn = findViewById(R.id.tvNextBtn);
        tvDesc = findViewById(R.id.tvDesc);

        tvPagerTitle = findViewById(R.id.tvPagerTitle);
        introPagerAdapter = new ID_IntroPagerAdapter(getSupportFragmentManager());
        viewpagerIntro.setPageTransformer(true, new ID_CubeOutTransformer());
        introPagerAdapter.add(new ID_FirstIntroFragment());
        introPagerAdapter.add(new ID_SecondIntroFragment());
        introPagerAdapter.add(new ID_ThirdIntroFragment());
        viewpagerIntro.setAdapter(introPagerAdapter);

        tvDesc.setText(R.string.intro_desc_1);
        tvPagerTitle.setText(R.string.intro_text_1);

        addIndicators(introPagerAdapter.getCount());

        tvNextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(ID_IntroActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        int currentItem = viewpagerIntro.getCurrentItem();
                        int lastItem = introPagerAdapter.getCount() - 1;

                        if (currentItem == lastItem) {
                            gotoLanguageSelection();
                        } else {
                            viewpagerIntro.setCurrentItem(currentItem + 1);
                        }
                    }
                }, MAIN_CLICK);
            }
        });

        viewpagerIntro.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                ID_IntroActivity.this.focusPos = position;
                int i = ID_IntroActivity.this.focusPos;
                if (i == 0) {
                    tvNextBtn.setText("Next");
                    tvPagerTitle.setText(R.string.intro_text_1);
                    tvDesc.setText(R.string.intro_desc_1);
                } else if (i == 1) {
                    tvNextBtn.setText("Next");
                    tvPagerTitle.setText(R.string.intro_text_2);
                    tvDesc.setText(R.string.intro_desc_2);
                } else {
                    tvNextBtn.setText("Start");
                    tvPagerTitle.setText(R.string.intro_text_3);
                    tvDesc.setText(R.string.intro_desc_3);
                }
            }

            @Override
            public void onPageSelected(int position) {
                updateIndicators(position);

                viewpagerIntro.setCurrentItem(position);
                Log.d("--viewpager--", "onPageSelected: getCurrentItem " + viewpagerIntro.getCurrentItem());
                Log.d("--viewpager--", "onPageSelected: position " + position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });


    }

    private void gotoLanguageSelection() {
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
        ID_PreferenceManager.putintro(ID_IntroActivity.this, true);
        finish();
    }


    private void addIndicators(int count) {
        for (int i = 0; i < count; i++) {
            ImageView indicator = new ImageView(this);
            indicator.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_selected_dot));
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            layoutParams.setMargins(8, 0, 8, 0);
            llindicator.addView(indicator, layoutParams);
        }
        updateIndicators(0);
    }

    private void updateIndicators(int position) {
        for (int i = 0; i < llindicator.getChildCount(); i++) {
            ImageView indicator = (ImageView) llindicator.getChildAt(i);
            if (position == 0) {
                indicator.setImageDrawable(ContextCompat.getDrawable(this, i == position ? R.drawable.ic_selected_dot : R.drawable.ic_unselected_dot));
            } else if (position == 1) {
                indicator.setImageDrawable(ContextCompat.getDrawable(this, i == position ? R.drawable.ic_selected_dot : R.drawable.ic_unselected_dot));
            } else {
                indicator.setImageDrawable(ContextCompat.getDrawable(this, i == position ? R.drawable.ic_selected_dot : R.drawable.ic_unselected_dot));
            }

        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        AdShow.getInstance(this).ShowNativeAd(findViewById(R.id.native_big_ad_layout).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}