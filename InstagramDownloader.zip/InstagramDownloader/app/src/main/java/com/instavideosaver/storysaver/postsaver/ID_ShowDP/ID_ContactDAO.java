package com.instavideosaver.storysaver.postsaver.ID_ShowDP;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class ID_ContactDAO {
    private SQLiteDatabase database;
    private ID_DatabaseHelper dbHelper;

    public ID_ContactDAO(Context context) {
        dbHelper = new ID_DatabaseHelper(context);
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public boolean isNameExists(String name) {
        String query = "SELECT * FROM " + ID_DatabaseHelper.TABLE_NAME +
                " WHERE " + ID_DatabaseHelper.COLUMN_NAME + " = ?";
        Cursor cursor = database.rawQuery(query, new String[]{name});

        boolean nameExists = cursor.getCount() > 0;

        cursor.close();

        return nameExists;
    }

    public long insertContact(ID_DpShowModel contact) {
        long insertedId;

        if (isNameExists(contact.getName())) {
            return -1;
        }else {
            ContentValues values = new ContentValues();
            values.put(ID_DatabaseHelper.COLUMN_NAME, contact.getName());
            values.put(ID_DatabaseHelper.COLUMN_IMAGE_PATH, contact.getImage());
            insertedId = database.insert(ID_DatabaseHelper.TABLE_NAME, null, values);
            if (insertedId != -1 ) {

            }
        }
        return insertedId;
    }


    @SuppressLint("Range")
    public List<ID_DpShowModel> getAllContacts() {
        List<ID_DpShowModel> contacts = new ArrayList<>();
        Cursor cursor = database.query(ID_DatabaseHelper.TABLE_NAME,
                null, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                ID_DpShowModel contact = new ID_DpShowModel();
                contact.setName(cursor.getString(cursor.getColumnIndex(ID_DatabaseHelper.COLUMN_NAME)));
                contact.setImage(cursor.getString(cursor.getColumnIndex(ID_DatabaseHelper.COLUMN_IMAGE_PATH)));
                contacts.add(contact);
            } while (cursor.moveToNext());

            cursor.close();
        }

        return contacts;
    }
}
