package com.instavideosaver.storysaver.postsaver.ID_ktn.ID_storymodels;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;


public class ID_ModelInstagramResponse implements Serializable {
    @SerializedName("graphql")
    private ID_ModelGraphshortcode modelGraphshortcode;

    public ID_ModelGraphshortcode getModelGraphshortcode() {
        return this.modelGraphshortcode;
    }

    public void setModelGraphshortcode(ID_ModelGraphshortcode modelGraphshortcode) {
        this.modelGraphshortcode = modelGraphshortcode;
    }
}
