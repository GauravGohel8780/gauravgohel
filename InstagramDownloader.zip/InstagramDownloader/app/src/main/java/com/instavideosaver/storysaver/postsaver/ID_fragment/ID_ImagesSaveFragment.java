package com.instavideosaver.storysaver.postsaver.ID_fragment;

import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.instavideosaver.storysaver.postsaver.R;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_FileAdapter;
import com.instavideosaver.storysaver.postsaver.ID_ktn.ID_VideoFileModel;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ID_ImagesSaveFragment extends Fragment {
    LinearLayout linearLayoutHolder;

    private RecyclerView recyclerView;
    private ID_FileAdapter fileAdapter;
    private ArrayList<ID_VideoFileModel> fileArrayList;
    ShimmerFrameLayout simmer;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View inflate = inflater.inflate(R.layout.fragment_images_save, container, false);
        this.simmer = (ShimmerFrameLayout) inflate.findViewById(R.id.simmer);

        this.linearLayoutHolder = (LinearLayout) inflate.findViewById(R.id.linearLayoutPlaceHold);


        recyclerView = inflate.findViewById(R.id.recyclerViewStory);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        fileArrayList = new ArrayList<>();
        fileAdapter = new ID_FileAdapter(getActivity(), fileArrayList);
        recyclerView.setAdapter(fileAdapter);
        new LoadFilesTask().execute();
        return inflate;
    }

    private class LoadFilesTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected void onPreExecute() {
            simmer.setVisibility(View.VISIBLE);
        }


        @Override
        protected Void doInBackground(Void... voids) {
            String folderPath = Environment.getExternalStorageDirectory() + "/Download/ReelDownloader";
            File folder = new File(folderPath);

            if (folder.exists() && folder.isDirectory()) {
                File[] listFiles = folder.listFiles();
                if (listFiles != null) {
                    for (File file : listFiles) {
                        if (Uri.fromFile(file).toString().endsWith(".png") || Uri.fromFile(file).toString().endsWith(".jpg")) {
                            fileArrayList.add(new ID_VideoFileModel(file.getName(), file.getAbsolutePath(), 0));
                        }
                    }
                    if (!fileArrayList.isEmpty()) {
                        Collections.sort(fileArrayList, new Comparator<ID_VideoFileModel>() {
                            @Override
                            public int compare(ID_VideoFileModel model1, ID_VideoFileModel model2) {
                                File file1 = new File(model1.getFilePath());
                                File file2 = new File(model2.getFilePath());
                                long lastModified1 = file1.lastModified();
                                long lastModified2 = file2.lastModified();
                                return Long.compare(lastModified2, lastModified1);
                            }
                        });
                    }
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            if (!fileArrayList.isEmpty()) {
                fileAdapter.notifyDataSetChanged();
                linearLayoutHolder.setVisibility(View.GONE);
            } else {
                linearLayoutHolder.setVisibility(View.VISIBLE);
            }
            simmer.setVisibility(View.GONE);
        }
    }
}