package com.instavideosaver.storysaver.postsaver.ID_ShowDP;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.instavideosaver.storysaver.postsaver.Ads_Common.AdsBaseActivity;
import com.instavideosaver.storysaver.postsaver.R;

import java.util.List;

public class ID_DpShowActivity extends AdsBaseActivity {

    private ID_ContactDAO contactDAO;
    private RecyclerView recyclerView;
    private ID_DpShowAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dp_show);

        contactDAO = new ID_ContactDAO(this);
        recyclerView = findViewById(R.id.rvdpshow);

        GridLayoutManager layoutManager = new GridLayoutManager(this,3);
        recyclerView.setLayoutManager(layoutManager);

        List<ID_DpShowModel> contacts = getContacts();
        adapter = new ID_DpShowAdapter(contacts,this);
        recyclerView.setAdapter(adapter);
    }

    private List<ID_DpShowModel> getContacts() {
        contactDAO.open();
        List<ID_DpShowModel> contacts = contactDAO.getAllContacts();
        contactDAO.close();
        return contacts;
    }

}