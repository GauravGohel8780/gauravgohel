package com.instavideosaver.storysaver.postsaver.ID_ktn;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.google.android.play.core.tasks.OnCompleteListener;
import com.google.android.play.core.tasks.OnFailureListener;
import com.google.android.play.core.tasks.Task;
import com.instavideosaver.storysaver.postsaver.R;
import com.instavideosaver.storysaver.postsaver.ID_ShowDP.ID_ContactDAO;
import com.instavideosaver.storysaver.postsaver.ID_ShowDP.ID_DpShowModel;
import com.instavideosaver.storysaver.postsaver.ID_utils.ID_Preference;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import kotlin.jvm.internal.Intrinsics;

public class ID_DownloadFileMain {
    private static final String TAG = "DownloadFileMain";
    public static long downloadID;
    public static DownloadManager downloadManager;

    public static void startDownloading(Context context, String str, String str2, String str3, String userimg) {
        try {
            ID_ContactDAO contactDAO = new ID_ContactDAO(context);
            contactDAO.open();

            ID_DpShowModel newContact = new ID_DpShowModel();
            newContact.setName(str2);
            newContact.setImage(userimg);

            contactDAO.close();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
            String timestamp = dateFormat.format(new Date());
            String fileName = generateFileName(str2, timestamp, str3);
            downloadFile(context, str, str2, fileName, str3);
            showToastMessage(context, context.getString(R.string.download_started));
            Intrinsics.checkNotNull((Activity) context);
            Activity activity2 = (Activity) context;
            ID_Preference preference = new ID_Preference(activity2);
            Integer inAppReviewToken = preference.getInAppReviewToken();
            Intrinsics.checkNotNullExpressionValue(inAppReviewToken, "sharedPref.inAppReviewToken");
            if (inAppReviewToken.intValue() <= 3) {
                preference.updateInAppReviewToken(preference.getInAppReviewToken().intValue() + 1);
            } else {
                final ReviewManager create = ReviewManagerFactory.create(activity2);
                Intrinsics.checkNotNullExpressionValue(create, "create(context)");
                Task<ReviewInfo> requestReviewFlow = create.requestReviewFlow();
                Intrinsics.checkNotNullExpressionValue(requestReviewFlow, "manager.requestReviewFlow()");
                requestReviewFlow.addOnCompleteListener(new OnCompleteListener() {
                    @Override
                    public void onComplete(Task task) {
                        Intrinsics.checkNotNullParameter(create, "$manager");
                        Intrinsics.checkNotNullParameter(task, "task");
                        if (task.isSuccessful()) {
                            Object result = task.getResult();
                            Intrinsics.checkNotNullExpressionValue(result, "task.result");
                            create.launchReviewFlow((Activity) context, (ReviewInfo) result).addOnCompleteListener(new OnCompleteListener() {
                                @Override
                                public void onComplete(Task task2) {
                                    Intrinsics.checkNotNullParameter(task2, "it");
                                    Log.d("ContentValues", "In-App Review Success");
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(Exception exc) {
                                    Log.d("ContentValues", "In-App Review Rating Failed");
                                }
                            });
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(Exception exc) {
                        Intrinsics.checkNotNullParameter(exc, "failure");
                    }
                });
            }
            Log.d("ContentValues", "in app review token : " + preference.getInAppReviewToken());
        } catch (Exception e) {
            Log.e(TAG, "Error downloading file", e);
            showToastMessage(context, context.getString(R.string.error_occ));
        }
    }

    private static String generateFileName(String str2, String timestamp, String str3) {
        String sanitizedFileName = (str2 + "ReelDownloader_" + timestamp)
                .replaceAll("[^\\p{L}\\p{M}\\p{N}\\p{P}\\p{Z}\\p{Cf}\\p{Cs}\\s]", "")
                .replaceAll("['+.^:,#\"]", "")
                .replace(" ", "-")
                .replace("!", "")
                .replace(":", "");

        String fileName = sanitizedFileName + str3;
        if (fileName.length() > 100) {
            fileName = fileName.substring(0, 100) + str3;
        }
        return fileName;
    }

    private static void downloadFile(Context context, String url, String title, String fileName, String extension) {
        downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url.replace("\"", "")));
        request.setTitle(title);
        request.setDescription(context.getString(R.string.download_started));
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "/ReelDownloader/");
        if (!directory.exists()) {
            directory.mkdir();
        }

        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/ReelDownloader/" + fileName);
        request.allowScanningByMediaScanner();

        downloadID = downloadManager.enqueue(request);
        Log.d(TAG, "Download ID: " + downloadID);
        Log.d(TAG, "Download FileName: " + fileName);
        expandNotificationBar(context);
    }

    private static void showToastMessage(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
    }

    @SuppressLint("WrongConstant")
    private static void expandNotificationBar(Context context) {
        if (ContextCompat.checkSelfPermission(context, "android.permission.EXPAND_STATUS_BAR") != 0) {
            return;
        }
        try {
            Class.forName("android.app.StatusBarManager")
                    .getMethod("expandNotificationsPanel")
                    .invoke(context.getSystemService("statusbar"));
        } catch (Exception e) {
            Log.e(TAG, "Error expanding notification bar", e);
            showToastMessage(context, "Expansion Not Working");
        }
    }
}
