package com.instavideosaver.storysaver.postsaver.ID_feedback;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.annotation.NonNull;

import android.annotation.TargetApi;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.instavideosaver.storysaver.postsaver.Ads_Common.AdsBaseActivity;
import com.instavideosaver.storysaver.postsaver.BuildConfig;
import com.instavideosaver.storysaver.postsaver.ID_PreferenceManager;
import com.instavideosaver.storysaver.postsaver.R;
import com.instavideosaver.storysaver.postsaver.ID_language.ID_LanguageLocaleUtils;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.io.IOException;
import java.util.Objects;
import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ID_FeedbackActivity extends AdsBaseActivity {

    EditText etName, etEmail, etfeedback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ID_LanguageLocaleUtils.changeLocale(getBaseContext(), ID_PreferenceManager.getPrefLanguage(this));
        setStatusBarGradiant();
        setContentView(R.layout.activity_feedback);




        findViewById(R.id.back_btn).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etfeedback = findViewById(R.id.etfeedback);
        String DeviceName = android.os.Build.BRAND + " " + android.os.Build.MODEL;
        int Version = Build.VERSION.SDK_INT;
        Log.w("--apiResponse--", "DeviceName  " + DeviceName);
        Log.w("--apiResponse--", "Version  " + Version);

        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://192.168.29.210:9000/").addConverterFactory(GsonConverterFactory.create()).build();

        ID_ApiService apiService = retrofit.create(ID_ApiService.class);

        findViewById(R.id.cvsubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(ID_FeedbackActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        String Name = Objects.requireNonNull(etName.getText()).toString();
                        String Email = Objects.requireNonNull(etEmail.getText()).toString();
                        String feedback = Objects.requireNonNull(etfeedback.getText()).toString();

                        if (TextUtils.isEmpty(Name)) {
                            Toast.makeText(ID_FeedbackActivity.this, "Please enter your Name...", Toast.LENGTH_SHORT).show();
                        } else if (TextUtils.isEmpty(Email)) {
                            Toast.makeText(ID_FeedbackActivity.this, "Please enter your Email...", Toast.LENGTH_SHORT).show();
                        } else if(!isValidEmailId(etEmail.getText().toString().trim())){
                            Toast.makeText(getApplicationContext(), "Please enter Valid Email Address...", Toast.LENGTH_SHORT).show();
                        } else if (TextUtils.isEmpty(feedback)) {
                            Toast.makeText(ID_FeedbackActivity.this, "Please enter your feedback...", Toast.LENGTH_SHORT).show();
                        } else {

                            String DeviceName = android.os.Build.BRAND + " " + android.os.Build.MODEL;
                            int Version = Build.VERSION.SDK_INT;
                            ID_FeedbackRequestModel userDetail = new ID_FeedbackRequestModel(Name, Email, feedback, BuildConfig.APPLICATION_ID, DeviceName, Version);


                            Call<ID_FeedBackResponseModel> call = apiService.feedbackUser(userDetail);

                            call.enqueue(new Callback<ID_FeedBackResponseModel>() {
                                @Override
                                public void onResponse(@NonNull Call<ID_FeedBackResponseModel> call, @NonNull Response<ID_FeedBackResponseModel> response) {
                                    ID_FeedBackResponseModel apiResponse = response.body();
                                    if (response.isSuccessful()) {
                                        Toast.makeText(ID_FeedbackActivity.this, "FeedBack Submit successfully...", Toast.LENGTH_SHORT).show();

                                        Log.w("--apiResponse--", "user_data---in USerDetails" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));
                                        ID_FeedbackDataModel userData = apiResponse.getFeedbackDataModel();
                                        Log.w("--apiResponse--", "onResponse:getArrLoginToken ---------->" + userData.getvFeedBackMessage());
                                    } else {
                                        try {
                                            Log.w("--apiResponse--", "Error: user detail " + response.errorBody().string());
                                        } catch (IOException e) {
                                            throw new RuntimeException(e);
                                        }
                                    }
                                    etName.getText().clear();
                                    etEmail.getText().clear();
                                    etfeedback.getText().clear();
                                }

                                @Override
                                public void onFailure(@NonNull Call<ID_FeedBackResponseModel> call, @NonNull Throwable t) {
                                    etName.getText().clear();
                                    etEmail.getText().clear();
                                    etfeedback.getText().clear();
                                    Log.e("--apiResponse--", "Error: user detail onFailure " + new Gson().toJson(t.getMessage()));
                                }
                            });

                        }
                    }
                }, MAIN_CLICK);
            }
        });
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public void setStatusBarGradiant() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            Drawable background = getDrawable(R.drawable.ic_main_bg_img);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getColor(android.R.color.transparent));
            window.setBackgroundDrawable(background);
        }
    }

    private boolean isValidEmailId(String email){

        return Pattern.compile("^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$").matcher(email).matches();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}