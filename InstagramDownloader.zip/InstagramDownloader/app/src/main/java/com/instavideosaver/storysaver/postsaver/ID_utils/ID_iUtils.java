package com.instavideosaver.storysaver.postsaver.ID_utils;

import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.webkit.URLUtil;


import java.net.URL;
import java.util.Random;


public class ID_iUtils {
    public static String[] UserAgentsList = {"Instagram 9.5.2 (iPhone7,2; iPhone OS 9_3_3; en_US; en-US; scale=2.00; 750x1334) AppleWebKit/420+", "Instagram 9.5.2 (iPhone7,2; iPhone OS 9_3_3; en_US; en-US; scale=2.00; 750x1334) AppleWebKit/420+"};
    public static String[] UserAgentsListLogin = {"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36"};


    public static int getRandomNumber(int i) {
        int nextInt = new Random().nextInt(i);
        Log.d("getRandomNumberTAG", "bound = " + i + " gennumberis = " + nextInt);
        return nextInt;
    }

    public static boolean checkURL(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            return false;
        }
        boolean matches = Patterns.WEB_URL.matcher(charSequence).matches();
        if (matches) {
            return matches;
        }
        String str = ((Object) charSequence) + "";
        if (URLUtil.isNetworkUrl(str)) {
            try {
                new URL(str);
                return true;
            } catch (Exception unused) {
                return matches;
            }
        }
        return matches;
    }
}
