package com.instavideosaver.storysaver.postsaver.ID_fragment;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.instavideosaver.storysaver.postsaver.R;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdConstant;

public class ID_DownloadFragment extends Fragment {
    LinearLayout reelsll, postll;
    TextView reelstxt, posttxt;
    ImageView reelsimg, postimg;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_download, container, false);

        reelsll = view.findViewById(R.id.reelsll);
        postll = view.findViewById(R.id.postll);
        reelstxt = view.findViewById(R.id.reelstxt);
        posttxt = view.findViewById(R.id.posttxt);
        reelsimg = view.findViewById(R.id.reelsimg);
        postimg = view.findViewById(R.id.postimg);

        reelsll.setBackground(getResources().getDrawable(R.drawable.ic_miancolor_gradient));
        postll.setBackground(getResources().getDrawable(R.drawable.ic_white_gradient));
        reelstxt.setTextColor(getContext().getColor(R.color.white));
        posttxt.setTextColor(getContext().getColor(R.color.bluecolor));
        reelsimg.setColorFilter(getContext().getResources().getColor(R.color.white));
        postimg.setColorFilter(getContext().getResources().getColor(R.color.bluecolor));
        loadFragment(new ID_VideosSaveFragment());

        reelsll.setOnClickListener(v -> {
            getInstance(getActivity()).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    reelsll.setBackground(getResources().getDrawable(R.drawable.ic_miancolor_gradient));
                    postll.setBackground(getResources().getDrawable(R.drawable.ic_white_gradient));
                    reelstxt.setTextColor(getContext().getColor(R.color.white));
                    posttxt.setTextColor(getContext().getColor(R.color.bluecolor));
                    reelsimg.setColorFilter(getContext().getResources().getColor(R.color.white));
                    postimg.setColorFilter(getContext().getResources().getColor(R.color.bluecolor));
                    loadFragment(new ID_VideosSaveFragment());
                }
            }, MAIN_CLICK);

        });
        postll.setOnClickListener(v -> {
            getInstance(getActivity()).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    reelsll.setBackground(getResources().getDrawable(R.drawable.ic_white_gradient));
                    postll.setBackground(getResources().getDrawable(R.drawable.ic_miancolor_gradient));
                    reelstxt.setTextColor(getContext().getColor(R.color.bluecolor));
                    posttxt.setTextColor(getContext().getColor(R.color.white));
                    reelsimg.setColorFilter(getContext().getResources().getColor(R.color.bluecolor));
                    postimg.setColorFilter(getContext().getResources().getColor(R.color.white));
                    loadFragment(new ID_ImagesSaveFragment());
                }
            }, MAIN_CLICK);
        });


        return view;
    }

    private void loadFragment(Fragment fragment) {
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.frem, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    @Override
    public void onStart() {
        super.onStart();
        AdConstant.isResume = true;
    }
}