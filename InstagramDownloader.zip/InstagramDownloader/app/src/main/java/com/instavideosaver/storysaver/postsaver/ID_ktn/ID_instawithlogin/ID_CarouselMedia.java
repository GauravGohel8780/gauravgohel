package com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;


public class ID_CarouselMedia implements Serializable {
    @SerializedName("can_see_insights_as_brand")
    private Boolean canSeeInsightsAsBrand;
    @SerializedName("carousel_parent_id")
    private String carouselParentid;
    @SerializedName("commerciality_status")
    private String commercialityStatus;
    @SerializedName("id")
    private String id;
    @SerializedName("image_versions2")
    private ID_ImageVersions2 imageVersions2;
    @SerializedName("is_commercial")
    private Boolean isCommercial;
    @SerializedName("media_type")
    private int mediaType;
    @SerializedName("original_height")
    private long originalHeight;
    @SerializedName("original_width")
    private long originalWidth;
    @SerializedName("pk")
    private double pk;
    @SerializedName("sharing_friction_info")
    private ID_SharingFrictionInfo sharingFrictionInfo;
    @SerializedName("video_codec")
    private String videoCodec;
    @SerializedName("video_dash_manifest")
    private String videoDashManifest;
    @SerializedName("video_duration")
    private Double videoDuration;
    @SerializedName("video_versions")
    private List<ID_VideoVersion> videoVersions;

    @SerializedName("video_versions")
    public List<ID_VideoVersion> getVideoVersions() {
        return this.videoVersions;
    }

    @SerializedName("video_versions")
    public void setVideoVersions(List<ID_VideoVersion> list) {
        this.videoVersions = list;
    }

    @SerializedName("video_duration")
    public Double getVideoDuration() {
        return this.videoDuration;
    }

    @SerializedName("video_duration")
    public void setVideoDuration(Double d) {
        this.videoDuration = d;
    }

    @SerializedName("video_dash_manifest")
    public String getVideoDashManifest() {
        return this.videoDashManifest;
    }

    @SerializedName("video_dash_manifest")
    public void setVideoDashManifest(String str) {
        this.videoDashManifest = str;
    }

    @SerializedName("video_codec")
    public String getVideoCodec() {
        return this.videoCodec;
    }

    @SerializedName("video_codec")
    public void setVideoCodec(String str) {
        this.videoCodec = str;
    }

    @SerializedName("id")
    public String getid() {
        return this.id;
    }

    @SerializedName("id")
    public void setid(String str) {
        this.id = str;
    }

    @SerializedName("media_type")
    public int getMediaType() {
        return this.mediaType;
    }

    @SerializedName("media_type")
    public void setMediaType(int i) {
        this.mediaType = i;
    }

    @SerializedName("image_versions2")
    public ID_ImageVersions2 getImageVersions2() {
        return this.imageVersions2;
    }

    @SerializedName("image_versions2")
    public void setImageVersions2(ID_ImageVersions2 imageVersions2) {
        this.imageVersions2 = imageVersions2;
    }

    @SerializedName("original_width")
    public long getOriginalWidth() {
        return this.originalWidth;
    }

    @SerializedName("original_width")
    public void setOriginalWidth(long j) {
        this.originalWidth = j;
    }

    @SerializedName("original_height")
    public long getOriginalHeight() {
        return this.originalHeight;
    }

    @SerializedName("original_height")
    public void setOriginalHeight(long j) {
        this.originalHeight = j;
    }

    @SerializedName("pk")
    public double getPk() {
        return this.pk;
    }

    @SerializedName("pk")
    public void setPk(double d) {
        this.pk = d;
    }

    @SerializedName("carousel_parent_id")
    public String getCarouselParentid() {
        return this.carouselParentid;
    }

    @SerializedName("carousel_parent_id")
    public void setCarouselParentid(String str) {
        this.carouselParentid = str;
    }

    @SerializedName("can_see_insights_as_brand")
    public Boolean getCanSeeInsightsAsBrand() {
        return this.canSeeInsightsAsBrand;
    }

    @SerializedName("can_see_insights_as_brand")
    public void setCanSeeInsightsAsBrand(Boolean bool) {
        this.canSeeInsightsAsBrand = bool;
    }

    @SerializedName("is_commercial")
    public Boolean getIsCommercial() {
        return this.isCommercial;
    }

    @SerializedName("is_commercial")
    public void setIsCommercial(Boolean bool) {
        this.isCommercial = bool;
    }

    @SerializedName("commerciality_status")
    public String getCommercialityStatus() {
        return this.commercialityStatus;
    }

    @SerializedName("commerciality_status")
    public void setCommercialityStatus(String str) {
        this.commercialityStatus = str;
    }

    @SerializedName("sharing_friction_info")
    public ID_SharingFrictionInfo getSharingFrictionInfo() {
        return this.sharingFrictionInfo;
    }

    @SerializedName("sharing_friction_info")
    public void setSharingFrictionInfo(ID_SharingFrictionInfo sharingFrictionInfo) {
        this.sharingFrictionInfo = sharingFrictionInfo;
    }
}
