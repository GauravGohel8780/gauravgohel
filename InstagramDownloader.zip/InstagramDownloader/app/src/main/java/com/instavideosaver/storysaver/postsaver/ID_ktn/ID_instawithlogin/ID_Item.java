package com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;


public class ID_Item implements Serializable {
    @SerializedName("carousel_media")
    private List<ID_CarouselMedia> carouselMedia;
    @SerializedName("carousel_media_count")
    private long carouselMediaCount;
    @SerializedName("client_cache_key")
    private String clientCacheKey;
    @SerializedName("code")
    private String code;
    @SerializedName("filter_type")
    private long filterType;
    @SerializedName("has_audio")
    private boolean hasAudio;
    @SerializedName("id")
    private String id;
    @SerializedName("igtv_exists_in_viewer_series")
    private boolean igtvExistsInViewerSeries;
    @SerializedName("image_versions2")
    private ID_ImageVersions2 imageVersions2;
    @SerializedName("inline_composer_display_condition")
    private String inlineComposerDisplayCondition;
    @SerializedName("is_post_live")
    private boolean isPostLive;
    @SerializedName("is_unified_video")
    private boolean isUnifiedVideo;
    @SerializedName("media_type")
    private int mediaType;
    @SerializedName("nearly_complete_copyright_match")
    private boolean nearlyCompleteCopyrightMatch;
    @SerializedName("next_max_id")
    private double nextMaxid;
    @SerializedName("number_of_qualities")
    private long numberOfQualities;
    @SerializedName("pk")
    private double pk;
    @SerializedName("product_type")
    private String productType;
    @SerializedName("taken_at")
    private long takenAt;
    @SerializedName("thumbnails")
    private ID_Thumbnails thumbnails;
    @SerializedName("title")
    private String title;
    @SerializedName("user")
    private ID_UsersInsta user;
    @SerializedName("video_codec")
    private String videoCodec;
    @SerializedName("video_duration")
    private double videoDuration;
    @SerializedName("video_versions")
    private List<ID_VideoVersion> videoVersions;

    public List<ID_CarouselMedia> getCarouselMedia() {
        return this.carouselMedia;
    }

    public void setCarouselMedia(List<ID_CarouselMedia> list) {
        this.carouselMedia = list;
    }

    public long getCarouselMediaCount() {
        return this.carouselMediaCount;
    }

    public void setCarouselMediaCount(long j) {
        this.carouselMediaCount = j;
    }

    public long getTakenAt() {
        return this.takenAt;
    }

    public void setTakenAt(long j) {
        this.takenAt = j;
    }

    public ID_UsersInsta getUser() {
        return this.user;
    }

    public void setUser(ID_UsersInsta usersInsta) {
        this.user = usersInsta;
    }

    public double getPk() {
        return this.pk;
    }

    public void setPk(double d) {
        this.pk = d;
    }

    public String getid() {
        return this.id;
    }

    public void setid(String str) {
        this.id = str;
    }

    public int getMediaType() {
        return this.mediaType;
    }

    public void setMediaType(int i) {
        this.mediaType = i;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String str) {
        this.code = str;
    }

    public String getClientCacheKey() {
        return this.clientCacheKey;
    }

    public void setClientCacheKey(String str) {
        this.clientCacheKey = str;
    }

    public long getFilterType() {
        return this.filterType;
    }

    public void setFilterType(long j) {
        this.filterType = j;
    }

    public boolean getIsUnifiedVideo() {
        return this.isUnifiedVideo;
    }

    public void setIsUnifiedVideo(boolean z) {
        this.isUnifiedVideo = z;
    }

    public double getNextMaxid() {
        return this.nextMaxid;
    }

    public void setNextMaxid(double d) {
        this.nextMaxid = d;
    }

    public String getInlineComposerDisplayCondition() {
        return this.inlineComposerDisplayCondition;
    }

    public void setInlineComposerDisplayCondition(String str) {
        this.inlineComposerDisplayCondition = str;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public String getProductType() {
        return this.productType;
    }

    public void setProductType(String str) {
        this.productType = str;
    }

    public boolean getNearlyCompleteCopyrightMatch() {
        return this.nearlyCompleteCopyrightMatch;
    }

    public void setNearlyCompleteCopyrightMatch(boolean z) {
        this.nearlyCompleteCopyrightMatch = z;
    }

    public ID_Thumbnails getThumbnails() {
        return this.thumbnails;
    }

    public void setThumbnails(ID_Thumbnails thumbnails) {
        this.thumbnails = thumbnails;
    }

    public boolean getIgtvExistsInViewerSeries() {
        return this.igtvExistsInViewerSeries;
    }

    public void setIgtvExistsInViewerSeries(boolean z) {
        this.igtvExistsInViewerSeries = z;
    }

    public boolean getIsPostLive() {
        return this.isPostLive;
    }

    public void setIsPostLive(boolean z) {
        this.isPostLive = z;
    }

    public ID_ImageVersions2 getImageVersions2() {
        return this.imageVersions2;
    }

    public void setImageVersions2(ID_ImageVersions2 imageVersions2) {
        this.imageVersions2 = imageVersions2;
    }

    public String getVideoCodec() {
        return this.videoCodec;
    }

    public void setVideoCodec(String str) {
        this.videoCodec = str;
    }

    public long getNumberOfQualities() {
        return this.numberOfQualities;
    }

    public void setNumberOfQualities(long j) {
        this.numberOfQualities = j;
    }

    public List<ID_VideoVersion> getVideoVersions() {
        return this.videoVersions;
    }

    public void setVideoVersions(List<ID_VideoVersion> list) {
        this.videoVersions = list;
    }

    public boolean getHasAudio() {
        return this.hasAudio;
    }

    public void setHasAudio(boolean z) {
        this.hasAudio = z;
    }

    public double getVideoDuration() {
        return this.videoDuration;
    }

    public void setVideoDuration(double d) {
        this.videoDuration = d;
    }
}
