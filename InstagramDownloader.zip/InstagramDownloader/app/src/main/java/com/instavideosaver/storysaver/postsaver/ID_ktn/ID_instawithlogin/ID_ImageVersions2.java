package com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;


public class ID_ImageVersions2 implements Serializable {
    @SerializedName("candidates")
    private List<ID_Candidate> candidates;

    @SerializedName("candidates")
    public List<ID_Candidate> getCandidates() {
        return this.candidates;
    }

    @SerializedName("candidates")
    public void setCandidates(List<ID_Candidate> list) {
        this.candidates = list;
    }
}
