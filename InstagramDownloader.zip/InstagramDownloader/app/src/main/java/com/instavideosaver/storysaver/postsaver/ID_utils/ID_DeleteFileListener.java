package com.instavideosaver.storysaver.postsaver.ID_utils;

/* compiled from: FileUtils.kt */
public interface ID_DeleteFileListener {
    void onFileDeleted(boolean z, int i);
}
