package com.instavideosaver.storysaver.postsaver.ID_utils;

import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;

import androidx.viewpager.widget.ViewPager;


public class ID_ViewPagerNoSwipe extends ViewPager {
    private boolean enabled;

    public ID_ViewPagerNoSwipe(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.enabled = false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.enabled) {
            return super.onTouchEvent(motionEvent);
        }
        return false;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        if (this.enabled) {
            return super.onInterceptTouchEvent(motionEvent);
        }
        return false;
    }

    @Override
    public boolean executeKeyEvent(KeyEvent keyEvent) {
        if (this.enabled)    {
            return super.executeKeyEvent(keyEvent);
        }
        return false;
    }
}
