package com.instavideosaver.storysaver.postsaver.ID_ShowDP;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.instavideosaver.storysaver.postsaver.ID_Activity.MainActivity;
import com.instavideosaver.storysaver.postsaver.ID_PreferenceManager;
import com.instavideosaver.storysaver.postsaver.R;

import java.util.List;

public class ID_DpShowAdapter extends RecyclerView.Adapter<ID_DpShowAdapter.ViewHolder> {

    private List<ID_DpShowModel> persons;
    private Activity activity;

    ID_DatabaseHelper databaseHelper;

    public ID_DpShowAdapter(List<ID_DpShowModel> persons, Activity activity) {
        this.persons = persons;
        this.activity = activity;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.dp_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        databaseHelper = new ID_DatabaseHelper(activity);
        ID_DpShowModel person = persons.get(position);
        holder.dp_txt.setText(person.getName());

        Glide.with(holder.itemView)
                .load(person.getImage())
                .placeholder(R.drawable.ic_logo)
                .into(holder.dpimage);

        holder.itemView.setOnClickListener(v -> {
            ID_PreferenceManager.putloginuser(activity,"user");
            ID_PreferenceManager.putusername(activity, person.getName());
            activity.startActivity(new Intent(activity, MainActivity.class));
        });
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                databaseHelper.deleteContact(person.getName());
                persons.remove(position);
                notifyDataSetChanged();
                return false;
            }
        });
    }



    @Override
    public int getItemCount() {
        return persons.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView dp_txt;
        ImageView dpimage;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            dp_txt = itemView.findViewById(R.id.dp_txt);
            dpimage = itemView.findViewById(R.id.dpimage);
        }
    }
}
