package com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;


public class ID_SharingFrictionInfo implements Serializable {
    Object bloks_app_url;
    boolean should_have_sharing_friction;

    @SerializedName("should_have_sharing_friction")
    public boolean getShould_have_sharing_friction() {
        return this.should_have_sharing_friction;
    }

    public void setShould_have_sharing_friction(boolean z) {
        this.should_have_sharing_friction = z;
    }

    @SerializedName("bloks_app_url")
    public Object getBloks_app_url() {
        return this.bloks_app_url;
    }

    public void setBloks_app_url(Object obj) {
        this.bloks_app_url = obj;
    }
}
