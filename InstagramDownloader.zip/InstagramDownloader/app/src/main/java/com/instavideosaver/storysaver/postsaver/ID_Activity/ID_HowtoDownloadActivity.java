package com.instavideosaver.storysaver.postsaver.ID_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.annotation.TargetApi;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

import com.instavideosaver.storysaver.postsaver.Ads_Common.AdsBaseActivity;
import com.instavideosaver.storysaver.postsaver.ID_PreferenceManager;
import com.instavideosaver.storysaver.postsaver.R;
import com.instavideosaver.storysaver.postsaver.ID_language.ID_LanguageLocaleUtils;
import com.iten.tenoku.ad.AdShow;
import com.iten.tenoku.ad.HandleClick.HandleClick;

public class ID_HowtoDownloadActivity extends AdsBaseActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ID_LanguageLocaleUtils.changeLocale(getBaseContext(), ID_PreferenceManager.getPrefLanguage(this));
        setStatusBarGradiant();
        setContentView(R.layout.activity_howto_download);


            AdShow.getInstance(this).ShowCollapseBanner(ID_HowtoDownloadActivity.this, findViewById(R.id.banner_view));

//        AdsUtil.addCollapsibleBanner(HowtoDownloadActivity.this, findViewById(R.id.banner_view), AdConstant.adcollapsiblekey);

        findViewById(R.id.back_btn).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public void setStatusBarGradiant() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            Drawable background = getDrawable(R.drawable.ic_main_bg_img);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getColor(android.R.color.transparent));
            window.setBackgroundDrawable(background);
        }
    }



}