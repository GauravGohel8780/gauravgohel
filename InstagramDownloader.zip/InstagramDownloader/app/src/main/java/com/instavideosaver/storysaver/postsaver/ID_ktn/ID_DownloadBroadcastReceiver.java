package com.instavideosaver.storysaver.postsaver.ID_ktn;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.util.Log;

import androidx.core.app.NotificationCompat;


public class ID_DownloadBroadcastReceiver extends BroadcastReceiver {
    public static boolean isFirstTimeDownload = false;

    @SuppressLint("Range")
    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            DownloadManager downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
            new IntentFilter("android.intent.action.DOWNLOAD_COMPLETE");
            long longExtra = intent.getLongExtra("extra_download_id", -1L);
            if (longExtra == -1) {
                return;
            }
            Cursor query = downloadManager.query(new DownloadManager.Query().setFilterById(longExtra));
            if (query.moveToFirst()) {
                if (query.getInt(query.getColumnIndex(NotificationCompat.CATEGORY_STATUS)) == 8) {
                    if (!isFirstTimeDownload) {
                        isFirstTimeDownload = true;
                    }
                } else {
                    Log.d("error", "error");
                }
            } else {
                Log.d("error", "error");
            }
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }
}
