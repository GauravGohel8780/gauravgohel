package com.instavideosaver.storysaver.postsaver.ID_feedback;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ID_ApiService {

    @POST("api/v1/feedBack/save")
    Call<ID_FeedBackResponseModel> feedbackUser(@Body ID_FeedbackRequestModel request);
}