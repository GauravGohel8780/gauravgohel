package com.instavideosaver.storysaver.postsaver.ID_ktn.ID_api;

import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Url;


public interface ID_RetrofitApiInterface {
    @GET
    Call<JsonObject> getInstagramData(@Url String str, @Header("Cookie") String str2, @Header("User-Agent") String str3);

    @GET
    Call<JsonObject> getInstagramProfileDataAllImagesAndVideosBulk(@Url String str, @Header("Cookie") String str2, @Header("User-Agent") String str3);

    @GET
    Call<JsonObject> getInstagramProfileDataBulk(@Url String str, @Header("Cookie") String str2, @Header("User-Agent") String str3);

    @GET
    Call<JsonObject> getInstagramSearchResults(@Url String str, @Header("Cookie") String str2, @Header("User-Agent") String str3);

    @POST
    Call<JsonObject> getInstagramSearchResultsPost(@Url String str, @Header("Cookie") String str2, @Header("User-Agent") String str3);
}
