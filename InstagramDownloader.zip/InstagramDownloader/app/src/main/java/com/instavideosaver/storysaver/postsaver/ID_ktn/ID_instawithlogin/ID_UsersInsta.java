package com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;


public class ID_UsersInsta implements Serializable {
    @SerializedName("profile_pic_url")
    private String profile_pic_url;
    @SerializedName("username")
    private String username;

    public String getUsername() {
        return this.username;
    }

    public String getProfile_pic_url() {
        return this.profile_pic_url;
    }

    public void setProfile_pic_url(String str) {
        this.profile_pic_url = str;
    }

    public void setUsername(String str) {
        this.username = str;
    }
}
