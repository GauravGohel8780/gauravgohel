package com.instavideosaver.storysaver.postsaver.ID_ktn.ID_storymodels;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;


public class ID_ModelEdNode implements Serializable {
    @SerializedName("node")
    private ID_ModelNode modelNode;

    public ID_ModelNode getModelNode() {
        return this.modelNode;
    }

    public void setModelNode(ID_ModelNode modelNode) {
        this.modelNode = modelNode;
    }
}
