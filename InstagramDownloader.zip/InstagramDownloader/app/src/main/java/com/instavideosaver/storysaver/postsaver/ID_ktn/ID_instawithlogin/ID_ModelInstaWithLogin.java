package com.instavideosaver.storysaver.postsaver.ID_ktn.ID_instawithlogin;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;


public class ID_ModelInstaWithLogin implements Serializable {
    @SerializedName("items")
    private List<ID_Item> items;
    @SerializedName("num_results")
    private long numResults;

    @SerializedName("items")
    public List<ID_Item> getItems() {
        return this.items;
    }

    @SerializedName("items")
    public void setItems(List<ID_Item> list) {
        this.items = list;
    }

    @SerializedName("num_results")
    public long getNumResults() {
        return this.numResults;
    }

    @SerializedName("num_results")
    public void setNumResults(long j) {
        this.numResults = j;
    }
}
