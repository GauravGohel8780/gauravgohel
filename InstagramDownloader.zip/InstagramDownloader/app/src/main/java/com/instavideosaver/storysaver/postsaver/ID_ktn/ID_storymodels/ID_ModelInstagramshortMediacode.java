package com.instavideosaver.storysaver.postsaver.ID_ktn.ID_storymodels;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;


public class ID_ModelInstagramshortMediacode implements Serializable {
    @SerializedName("accessibility_caption")
    private String accessibility_caption;
    @SerializedName("display_resources")
    private List<ID_ModelDispRes> display_resources;
    @SerializedName("display_url")
    private String display_url;
    @SerializedName("edge_sidecar_to_children")
    private ID_ModelGetEdgetoNode edge_sidecar_to_children;
    @SerializedName("is_video")
    private boolean is_video;
    @SerializedName("owner")
    private ID_OwnerData owner;
    @SerializedName("video_url")
    private String video_url;

    public String getDisplay_url() {
        return this.display_url;
    }

    public void setDisplay_url(String str) {
        this.display_url = str;
    }

    public List<ID_ModelDispRes> getDisplay_resources() {
        return this.display_resources;
    }

    public void setDisplay_resources(List<ID_ModelDispRes> list) {
        this.display_resources = list;
    }

    public ID_OwnerData getOwner() {
        return this.owner;
    }

    public void setOwner(ID_OwnerData ownerData) {
        this.owner = ownerData;
    }

    public boolean isIs_video() {
        return this.is_video;
    }

    public void setIs_video(boolean z) {
        this.is_video = z;
    }

    public String getVideo_url() {
        return this.video_url;
    }

    public void setVideo_url(String str) {
        this.video_url = str;
    }

    public ID_ModelGetEdgetoNode getEdge_sidecar_to_children() {
        return this.edge_sidecar_to_children;
    }

    public void setEdge_sidecar_to_children(ID_ModelGetEdgetoNode modelGetEdgetoNode) {
        this.edge_sidecar_to_children = modelGetEdgetoNode;
    }

    public String getAccessibility_caption() {
        return this.accessibility_caption;
    }

    public void setAccessibility_caption(String str) {
        this.accessibility_caption = str;
    }
}
