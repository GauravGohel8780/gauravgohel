package com.instavideosaver.storysaver.postsaver.ID_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.annotation.TargetApi;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.ui.PlayerView;
import com.instavideosaver.storysaver.postsaver.Ads_Common.AdsBaseActivity;
import com.instavideosaver.storysaver.postsaver.R;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.io.File;

public class ID_PlayActivity extends AdsBaseActivity {
    private SimpleExoPlayer exoPlayer;
    private PlayerView exoPlayerView;

    private ImageView showimg;

    String intentPath;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStatusBarGradiant();
        setContentView(R.layout.activity_play);

        findViewById(R.id.back_btn).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });

        getWindow().setNavigationBarColor(getResources().getColor(android.R.color.black));

        intentPath = getIntent().getStringExtra("path");
        String intenttext = getIntent().getStringExtra("text");
        exoPlayerView = findViewById(R.id.exo_player_view);
        showimg = findViewById(R.id.showimg);
        TextView txtname = findViewById(R.id.txtname);

        txtname.setText(intenttext);

        if (intentPath.substring(intentPath.lastIndexOf(".")).equals(".mp4")) {
            exoPlayerView.setVisibility(View.VISIBLE);
            showimg.setVisibility(View.GONE);
            exoPlayerView.setBackgroundColor(Color.BLACK);
            exoPlayer = new SimpleExoPlayer.Builder(this).build();
            exoPlayerView.setPlayer(exoPlayer);

            if (intentPath != null) {
                Uri videoUri = Uri.fromFile(new File(intentPath));
                exoPlayer.setMediaItem(MediaItem.fromUri(videoUri));
                exoPlayer.prepare();
                exoPlayer.setPlayWhenReady(true);
            } else {
                Toast.makeText(this, "Intent path is null", Toast.LENGTH_SHORT).show();
            }
        } else {
            exoPlayerView.setVisibility(View.GONE);
            showimg.setVisibility(View.VISIBLE);
            Glide.with(this)
                    .load(intentPath)
                    .placeholder(R.drawable.ic_logo)
                    .into(showimg);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (intentPath.substring(intentPath.lastIndexOf(".")).equals(".mp4")) {
            exoPlayer.setPlayWhenReady(false);
            exoPlayer.release();
        }
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public void setStatusBarGradiant() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            Drawable background = getDrawable(R.drawable.ic_main_bg_img);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getColor(android.R.color.transparent));
            window.setBackgroundDrawable(background);
        }
    }
}
