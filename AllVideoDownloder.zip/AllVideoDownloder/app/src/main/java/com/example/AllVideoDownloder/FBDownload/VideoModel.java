package com.example.AllVideoDownloder.FBDownload;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "VideoModel")
public class VideoModel {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String title;
    private String folderName;
    private String path;
    private long duration = 0L;
    private long size;
    private long date;
    private boolean isSelect = false;
    private String isFromWhich = "";

    public VideoModel(int id, String title, String folderName, String path, long duration, long size, long date, boolean isSelect, String isFromWhich) {
        this.id = id;
        this.title = title;
        this.folderName = folderName;
        this.path = path;
        this.duration = duration;
        this.size = size;
        this.date = date;
        this.isSelect = isSelect;
        this.isFromWhich = isFromWhich;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFolderName() {
        return folderName;
    }

    public void setFolderName(String folderName) {
        this.folderName = folderName;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public boolean isSelect() {
        return isSelect;
    }

    public void setSelect(boolean select) {
        isSelect = select;
    }

    public String getIsFromWhich() {
        return isFromWhich;
    }

    public void setIsFromWhich(String isFromWhich) {
        this.isFromWhich = isFromWhich;
    }
}
