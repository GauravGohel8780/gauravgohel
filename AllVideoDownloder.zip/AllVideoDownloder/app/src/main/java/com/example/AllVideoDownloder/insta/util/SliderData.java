package com.example.AllVideoDownloder.insta.util;

public class SliderData {

    private int imgUrl;


    public SliderData(int imgUrl) {
        this.imgUrl = imgUrl;
    }

    public int getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(int imgUrl) {
        this.imgUrl = imgUrl;
    }
}
