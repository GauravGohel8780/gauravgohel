package com.example.AllVideoDownloder.commons;

import android.os.Environment;


import com.example.AllVideoDownloder.FBDownload.Downlodvideo.VideoModel;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Constant {
    public static File commonDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getPath() + "/All In One Status Saver/"+"/");
    public static File WaDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getPath() + "/AllVideoDownloder/"+"/StatusWhatsApp/"+"/");
    public static String appname = "";

    public static Map<String, ArrayList<VideoModel>> listofFolder = new HashMap<>();
    public static Set<String> downloadPath = new HashSet<>();
}
