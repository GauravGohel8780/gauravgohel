package com.example.AllVideoDownloder.FBDownload;


public interface OnProgressListener {

    void onProgress(Progress progress);

}
