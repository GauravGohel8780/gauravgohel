package com.example.AllVideoDownloder.FBDownload;


public interface OnPauseListener {

    void onPause();

}
