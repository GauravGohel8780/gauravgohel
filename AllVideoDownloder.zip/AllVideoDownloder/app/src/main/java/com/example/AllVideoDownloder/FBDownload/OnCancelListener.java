package com.example.AllVideoDownloder.FBDownload;


public interface OnCancelListener {

    void onCancel();

}
