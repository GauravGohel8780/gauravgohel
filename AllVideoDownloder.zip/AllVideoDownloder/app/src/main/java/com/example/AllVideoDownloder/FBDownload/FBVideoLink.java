package com.example.AllVideoDownloder.FBDownload;

import android.content.Context;
import android.util.Log;

import com.loopj.android.http.AsyncHttpClient;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref.ObjectRef;
import kotlin.text.Regex;
import kotlin.text.StringsKt;


public final class FBVideoLink {
    public static String pathNameVideo;
    public final Context context;

    public OnGetUrlListener listener;

    public FBVideoLink(Context context2, OnGetUrlListener listener2) {
        Intrinsics.checkNotNullParameter(context2, "context");
        this.context = context2;
        this.listener = listener2;
    }

    public final void scrapDataFromURL(String URL) {
        Intrinsics.checkNotNullParameter(URL, "URL");
        ObjectRef url = new ObjectRef();
        url.element = URL;
        String str = (String) url.element;
        Locale locale = Locale.ROOT;
        String str2 = "ROOT";
        Intrinsics.checkNotNullExpressionValue(locale, str2);
        String str3 = "null cannot be cast to non-null type java.lang.String";

        if (str != null) {
            Log.e("TAG", "str..........33333......" + str);

            String lowerCase = str.toLowerCase(locale);
            String str4 = "(this as java.lang.String).toLowerCase(locale)";
            Intrinsics.checkNotNullExpressionValue(lowerCase, str4);
            boolean contains = StringsKt.contains((CharSequence) lowerCase, (CharSequence) "fb", false);
            String str5 = "facebook";
            if (!contains) {
                String str6 = (String) url.element;
                Locale locale2 = Locale.ROOT;
                Intrinsics.checkNotNullExpressionValue(locale2, str2);
                if (str6 != null) {
                    String lowerCase2 = str6.toLowerCase(locale2);
                    Intrinsics.checkNotNullExpressionValue(lowerCase2, str4);
                    if (!StringsKt.contains((CharSequence) lowerCase2, (CharSequence) str5, false)) {
                        OnGetUrlListener onGetUrlListener = this.listener;
                        if (onGetUrlListener != null) {
                            String string = "invalid_link";
                            Intrinsics.checkNotNullExpressionValue(string, "context.getString(R.string.str_enter_valid_url)");
                            Log.e("TAG", "str..........error...111..." + string);

                            onGetUrlListener.error(string);
                        }
                        return;
                    }
                } else {
                    Log.e("TAG", "str..........NullPointerException......" + str);

                    throw new NullPointerException(str3);
                }
            }
            if (StringsKt.contains((CharSequence) url.element, (CharSequence) str5, false)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("https://m.facebook.");
                stringBuilder.append(getBack((String) url.element, "(((?!.com).)+$)"));
                String sb = stringBuilder.toString();
                Intrinsics.checkNotNullExpressionValue(sb, "stringBuilder.toString()");
                url.element = sb;
            }
            url.element = getBack((String) url.element, "(http(s)?:\\/\\/(.+?\\.)?[^\\s\\.]+\\.[^\\s\\/]{1,9}(\\/[^\\s]+)?)");
            AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
            asyncHttpClient.setTimeout(60 * 1000);
            asyncHttpClient.setUserAgent("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36");
            asyncHttpClient.get((String) url.element, new FBVideoFromUri(url, this));
            return;
        }
        Log.e("TAG", "str..........NullPointerException...1111..." + str);

        throw new NullPointerException(str3);
    }


    public final void facebook(String str) {
        Log.e("TAG", "str..........facebook...1111..." + str);

        String str2 = "context.getString(R.string.str_something_went_wrong)";
        String escapeXml = escapeXml(getBack(str, "([^\"]+)\" data-sigil=\"inlineVideo"));
        try {
            if (escapeXml.length() > 0) {
                downloadMedia(new JSONObject(escapeXml).getString("src"));
                return;
            }
            OnGetUrlListener onGetUrlListener = this.listener;
            if (onGetUrlListener != null) {
                String string = "something_went_wrong";
                Intrinsics.checkNotNullExpressionValue(string, str2);
                Log.e("TAG", "str..........error...222..." + string);

                onGetUrlListener.error(string);
            }
        } catch (JSONException e) {
            e.printStackTrace();
            OnGetUrlListener onGetUrlListener2 = this.listener;
            if (onGetUrlListener2 != null) {
                String string2 = "something_went_wrong";
                Intrinsics.checkNotNullExpressionValue(string2, str2);
                onGetUrlListener2.error(string2);
            }
        }
    }

    private final void downloadMedia(String str)  {
        OnGetUrlListener onGetUrlListener = this.listener;
        if (onGetUrlListener != null) {
            if (str != null) {
                onGetUrlListener.getSampleUrl(str);
            }
        }
    }

    private final String escapeXml(String str) {
        return new Regex("&apos;").replace(new Regex("&quot;").replace(new Regex("&lt;").replace(new Regex("&gt;").replace(new Regex("&amp;").replace(new Regex("&#125;").replace(new Regex("&#123;").replace((CharSequence) str, "{"), "}"), "&"), ">"), "<"), "\""), "'");
    }

    private final String getBack(String str, String str2) {
        Matcher matcher = Pattern.compile(str2).matcher(str);
        String str3 = "";
        if (!matcher.find()) {
            return str3;
        }
        String group = matcher.group(1);
        return group == null ? str3 : group;
    }
}
