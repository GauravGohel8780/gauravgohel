package com.example.AllVideoDownloder.FBDownload;


public interface OnStartOrResumeListener {

    void onStartOrResume();

}
