package com.example.AllVideoDownloder.FBDownload.Activity;

import static android.content.ClipDescription.MIMETYPE_TEXT_PLAIN;
import static android.content.ContentValues.TAG;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.example.AllVideoDownloder.FBDownload.Downlodvideo.DownloadItemActivity;
import com.example.AllVideoDownloder.FBDownload.VideoDao;
import com.example.AllVideoDownloder.FBDownload.VideoDatabase;
import com.example.AllVideoDownloder.FBDownload.VideoModel;
import com.example.AllVideoDownloder.R;
import com.example.AllVideoDownloder.commons.Constant;
import com.example.AllVideoDownloder.commons.UtilityClass;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Insta_DownloaderActivity extends AppCompatActivity {
    EditText editSearch;
    RequestQueue queue = null;
    File path;
    private VideoDao videoDao = null;
    private ClipboardManager clipBoard;
    private ArrayList<VideoModel> downloadedList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insta_downloader);
        editSearch = findViewById(R.id.edtPastUrl);

        videoDao = VideoDatabase.getInstance(this).videoDao();

        if (videoDao != null) {
            List<VideoModel> videoList = videoDao.getAllInstagram("Instagram");
            downloadedList.addAll(videoList);
        }
        queue = Volley.newRequestQueue(this);
        findViewById(R.id.llappdata).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                launchSocialApp("com.instagram.android");
            }
        });
        findViewById(R.id.rlpasturl).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (clipboard.hasPrimaryClip()) {
                    ClipData.Item item = clipboard.getPrimaryClip().getItemAt(0);
                    String clipboardText = item.getText().toString();
                    editSearch.setText(clipboardText);
                }
            }
        });

        findViewById(R.id.imgdownload).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Insta_DownloaderActivity.this, DownloadItemActivity.class).putExtra("FBInst", "Inst"));

            }
        });

        findViewById(R.id.rldownload).setOnClickListener(view -> {
            String edtUrl = editSearch.getText().toString();
            if (!UtilityClass.isValidURL(edtUrl)) {
                Toast.makeText(Insta_DownloaderActivity.this, "Enter Valid Url", Toast.LENGTH_SHORT).show();
                editSearch.setText("");
            } else {
                downloadVideo(editSearch.getText().toString());
            }
        });
    }


    public void downloadVideo(String downloadUrl) {
//        Toast.makeText(Insta_DownloaderActivity.this, "Downlaod call", Toast.LENGTH_SHORT).show();
        if (Build.VERSION.SDK_INT > 31) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(Insta_DownloaderActivity.this, new String[]{Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_IMAGES}, 101);
            } else {
                if (UtilityClass.isValidationEmpty(downloadUrl)) {
                    Toast.makeText(getApplicationContext(), "Enter url", Toast.LENGTH_SHORT).show();
                    return;
                }
                getImageDwPath();
                if (UtilityClass.isNetworkAvailable(Insta_DownloaderActivity.this, true, false)) {
                    UtilityClass.showUrlFindDialog(Insta_DownloaderActivity.this, "Please wait....");
                    callApi(downloadUrl);
                }
                editSearch.setText("");
            }
        } else {
            if (ContextCompat.checkSelfPermission(Insta_DownloaderActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(Insta_DownloaderActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 101);
            } else {
                if (UtilityClass.isValidationEmpty(downloadUrl)) {
                    Toast.makeText(getApplicationContext(), "Enter url", Toast.LENGTH_SHORT).show();
                    return;
                }
                getImageDwPath();
                if (UtilityClass.isNetworkAvailable(Insta_DownloaderActivity.this, true, false)) {
                    UtilityClass.showUrlFindDialog(Insta_DownloaderActivity.this, "Please wait video downloading....");
                    callApi(downloadUrl);
                }
                editSearch.setText("");
            }
        }
    }

    private void callApi(String url) {
        Log.e("TAG", "binding.getPasteUrl().getText:-------" + editSearch.getText().toString());
        // checkPath();
        AndroidNetworking.post("http://hexanetwork.in:3011/api/webScraping/getVideoByScraping").addHeaders("key", "TXF2m7CVCnptctqYcLjWvQywsNXdJDdhalgsbhq3o8").addBodyParameter("app_url", url).addBodyParameter("app_name", "instagram").setTag("test").setPriority(Priority.HIGH).build().getAsJSONObject(new JSONObjectRequestListener() {
            @Override
            public void onResponse(JSONObject response) {
                if (response != null) {
                    if (!UtilityClass.isValidationEmpty(url)) {
                        try {
                            JSONObject data = response.getJSONObject("data");
                            String videoURL = data.getString("videoURL");
                            UtilityClass.newDownload(videoURL, Insta_DownloaderActivity.this, path);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                Log.e("okhttp", "getVideoByScraping--------onResponse---------" + response);
            }

            @Override
            public void onError(ANError anError) {
                UtilityClass.hideUrlDialog();
                Log.e("okhttp", "getVideoByScraping--------onError---------" + anError.getMessage());
            }
        });
    }



    public String getImageDwPath() {
        path = new File(Environment.getExternalStorageDirectory().toString() + "/"
                + Environment.DIRECTORY_DOWNLOADS + "/"
                + getResources().getString(R.string.app_name) + "/"
                + getResources().getString(R.string.Instagram) + "/");


        if (!path.exists()) {
            path.mkdirs();
        }
        return null;
    }

//    @Override
//    protected void onResume() {
//        super.onResume();
//        clipBoard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
//        if (PrefUtils.getfipath(Insta_DownloaderActivity.this).isEmpty()) {
//            pasteText();
//        } else {
//            editSearch.setText(PrefUtils.getfipath(Insta_DownloaderActivity.this));
//            new Handler().postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    downloadVideo(editSearch.getText().toString());
//                    editSearch.setText("");
//                    PrefUtils.setfipath(Insta_DownloaderActivity.this,"");
//                }
//            }, 1000);
//        }
//    }

    private void pasteText() {
        try {
            editSearch.setText("");
            String copyIntent = getIntent().getStringExtra("CopyIntent");
            copyIntent = extractUrls(copyIntent);
            if (copyIntent == null || copyIntent.equals("")) {
                if (!(clipBoard.hasPrimaryClip())) {
                    Log.d(TAG, "PasteText");
                } else if (!(clipBoard.getPrimaryClipDescription().hasMimeType(MIMETYPE_TEXT_PLAIN))) {
                    if (clipBoard.getPrimaryClip().getItemAt(0).getText().toString().contains("instagram")) {
                        editSearch.setText(clipBoard.getPrimaryClip().getItemAt(0).getText().toString());
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                downloadVideo(editSearch.getText().toString());
                                clearClipboard();
                            }
                        }, 1000);
                    }

                } else {
                    ClipData.Item item = clipBoard.getPrimaryClip().getItemAt(0);
                    if (item.getText().toString().contains("instagram")) {
                        editSearch.setText(item.getText().toString());
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                downloadVideo(editSearch.getText().toString());
                                clearClipboard();
                            }
                        }, 1000);
                    }

                }
            } else {
                if (copyIntent.contains("instagram")) {
                    editSearch.setText(copyIntent);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            downloadVideo(editSearch.getText().toString());
                            clearClipboard();
                        }
                    }, 1000);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void clearClipboard() {
        if (clipBoard != null) {
            ClipData emptyClip = ClipData.newPlainText("", "");
            clipBoard.setPrimaryClip(emptyClip);
        }
    }

    public static String extractUrls(String text) {
        try {
            List<String> containedUrls = new ArrayList<String>();
            String urlRegex = "((https?|ftp|gopher|telnet|file):((//)|(\\\\))+[\\w\\d:#@%/;$()~_?\\+-=\\\\\\.&]*)";
            Pattern pattern = Pattern.compile(urlRegex, Pattern.CASE_INSENSITIVE);
            Matcher urlMatcher = pattern.matcher(text);

            while (urlMatcher.find()) {
                containedUrls.add(text.substring(urlMatcher.start(0),
                        urlMatcher.end(0)));
            }

            return containedUrls.get(0);
        } catch (Exception e) {
            e.printStackTrace();
            return text;
        }
    }


    public void launchSocialApp(String pakagename) {
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage(pakagename);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Please Install " + Constant.appname + " First For Use This App.", Toast.LENGTH_SHORT).show();
        }
    }

}