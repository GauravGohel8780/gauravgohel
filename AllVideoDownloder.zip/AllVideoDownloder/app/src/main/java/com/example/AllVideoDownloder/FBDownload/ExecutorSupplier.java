package com.example.AllVideoDownloder.FBDownload;

import java.util.concurrent.Executor;

public interface ExecutorSupplier {

    DownloadExecutor forDownloadTasks();

    Executor forBackgroundTasks();

    Executor forMainThreadTasks();

}
