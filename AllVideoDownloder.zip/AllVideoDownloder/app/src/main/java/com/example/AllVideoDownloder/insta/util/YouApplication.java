package com.example.AllVideoDownloder.insta.util;

import android.app.Application;

public class YouApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }

}
