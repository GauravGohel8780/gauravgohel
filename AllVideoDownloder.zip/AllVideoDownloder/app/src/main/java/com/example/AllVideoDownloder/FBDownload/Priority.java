package com.example.AllVideoDownloder.FBDownload;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH,
    IMMEDIATE

}
