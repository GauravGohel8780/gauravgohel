package com.example.AllVideoDownloder.FBDownload.Downlodvideo;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class VideoModel implements Parcelable {
    String FolderName;
    String videpath;
    String duration;
    long size;
    String date;

    public VideoModel(String folderName, String videpath, String duration, long size, String date) {
        FolderName = folderName;
        this.videpath = videpath;
        this.duration = duration;
        this.size = size;
        this.date = date;
    }

    public VideoModel() {
    }

    protected VideoModel(Parcel in) {
        FolderName = in.readString();
        videpath = in.readString();
        duration = in.readString();
        size = in.readLong();
        date = in.readString();
    }

    public static final Creator<VideoModel> CREATOR = new Creator<VideoModel>() {
        @Override
        public VideoModel createFromParcel(Parcel in) {
            return new VideoModel(in);
        }

        @Override
        public VideoModel[] newArray(int size) {
            return new VideoModel[size];
        }
    };

    public String getVidepath() {
        return videpath;
    }

    public void setVidepath(String videpath) {
        this.videpath = videpath;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public String getFolderName() {
        return FolderName;
    }

    public void setFolderName(String folderName) {
        FolderName = folderName;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(FolderName);
        parcel.writeString(videpath);
        parcel.writeString(duration);
        parcel.writeLong(size);
        parcel.writeString(date);
    }
}
