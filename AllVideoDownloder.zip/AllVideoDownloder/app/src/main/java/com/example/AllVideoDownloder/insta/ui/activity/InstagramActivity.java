package com.example.AllVideoDownloder.insta.ui.activity;


import android.app.Dialog;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.content.ContextCompat;

import com.example.AllVideoDownloder.FBDownload.Activity.Insta_DownloaderActivity;
import com.example.AllVideoDownloder.FBDownload.Downlodvideo.DownloadItemActivity;
import com.example.AllVideoDownloder.R;
import com.example.AllVideoDownloder.insta.interfaces.GetData;
import com.example.AllVideoDownloder.insta.interfaces.OnClick;
import com.example.AllVideoDownloder.insta.service.DownloadService;
import com.example.AllVideoDownloder.insta.util.Constant;
import com.example.AllVideoDownloder.insta.util.FindData;
import com.example.AllVideoDownloder.insta.util.Method;

import java.io.File;

public class InstagramActivity extends AppCompatActivity {

    private Method method;
    private EditText editText;
    AppCompatButton  button, btnpaste;
    TextView btnOpenInstagram;
    private InputMethodManager inputMethodManager;
    ImageView download;
    private ClipboardManager clipBoard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instagram);



        File root = new File(Environment.getExternalStorageDirectory().toString() + "/"
                + Environment.DIRECTORY_DOWNLOADS + "/"
                + getResources().getString(R.string.app_name) + "/"
                + getResources().getString(R.string.Instagram) + "/");
        if (!root.exists()) {
            root.mkdir();
        }

        inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        download = findViewById(R.id.download);
        editText = findViewById(R.id.linkEdt);
        button = findViewById(R.id.downloadBtn);
        btnOpenInstagram = findViewById(R.id.btnOpenInstagram);
        btnpaste = findViewById(R.id.btnpaste);

        method = new Method(InstagramActivity.this, (OnClick) (position, type, data) -> {
            if (type.equals("getData")) {

//                ProgressDialog progressDialog = new ProgressDialog(MainActivity.this);
//                progressDialog.setMessage(getResources().getString(R.string.loading));
//                progressDialog.setCancelable(false);
//                progressDialog.show();

                Dialog dialog = new Dialog(this);
                dialog.setContentView(R.layout.dialog_loading);
                dialog.setCancelable(false);
                dialog.show();

                FindData findData = new FindData(getApplicationContext(), (GetData) (linkList, message, isData) -> {
                    if (isData) {
                        if (linkList.size() != 0) {
                            Constant.downloadArray.clear();
                            Constant.downloadArray.addAll(linkList);
                            Intent intent = new Intent(InstagramActivity.this, DownloadService.class);
                            intent.setAction("com.download.action.START");
                            startService(intent);
                        } else {
                            method.alertBox(getResources().getString(R.string.no_data_found));
                        }
                    } else {
                        method.alertBox(message);
                    }

                    editText.setText("");
                    dialog.dismiss();
//                    progressDialog.dismiss();

                });
                findData.data(data);
            }
        });


        //set gravity for tab bar

        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(InstagramActivity


                        .this, DownloadItemActivity.class).putExtra("FBInst", "Inst"));
            }
        });


        button.setOnClickListener(v -> {
            String url = editText.getText().toString();

            editText.clearFocus();
            inputMethodManager.hideSoftInputFromWindow(editText.getWindowToken(), 0);

            if (!url.equals("")) {
                method.onClick(0, "getData", url);
            } else {
                method.alertBox(getResources().getString(R.string.please_enter_url));
            }

        });

        btnpaste.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clipBoard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                try {
                    CharSequence textToPaste = clipBoard.getPrimaryClip().getItemAt(0).getText();
                    editText.setText(textToPaste);
                } catch (Exception e) {
                    return;
                }
            }
        });

        btnOpenInstagram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                launchInstagram();
            }
        });
    }

    public void launchInstagram() {
        String instagramApp = "com.instagram.android";
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage(instagramApp);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), R.string.instagram_not_found, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        onBack();
    }

    private void onBack() {
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
//        GlobalBus.getBus().unregister(this);
        super.onDestroy();
    }
}