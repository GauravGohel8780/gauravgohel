package com.example.AllVideoDownloder.FBDownload;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface VideoDao {

    // Insert into HistoryModel
    @Insert
    void insertHistory(HistoryModel historyModel);

    @Query("SELECT * FROM HistoryModel where url = :titles")
    boolean isInHistory(String titles);

    @Query("DELETE FROM HistoryModel where title = :title")
    void deleteFromHis(String title);

    @Query("SELECT * FROM HistoryModel")
    List<HistoryModel> getAllHistory();

    @Delete
    void deleteFromHistory(HistoryModel historyModel);

    @Update
    void updateHistory(HistoryModel historyModel);

    // Insert into BookmarkModel
    @Insert
    void insertBookmark(BookmarkModel historyModel);

    @Query("SELECT * FROM BookmarkModel where url = :strUrl")
    boolean isBookmark(String strUrl);

    @Delete
    void deleteFromBookmark(BookmarkModel bookmarkModel);

    @Update
    void updateBookmark(BookmarkModel bookmarkModel);

    @Query("SELECT * FROM BookmarkModel")
    List<BookmarkModel> getAllBookmark();

    @Query("SELECT * FROM VideoModel")
    List<VideoModel> getAllDownload();

    @Query("SELECT * FROM VideoModel where path = :path")
    boolean isDownload(String path);

    @Query("DELETE FROM VideoModel where path = :path")
    void deleteFromDownload(String path);

    @Query("UPDATE VideoModel SET path = :path, title = :title WHERE path = :oldPath")
    void updateDownload(String path, String title, String oldPath);

    @Query("SELECT * FROM VideoModel where isFromWhich = :instagram")
    List<VideoModel> getAllInstagram(String instagram);

    @Insert
    void insertDownload(VideoModel videoModel);
}
