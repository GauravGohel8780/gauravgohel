package com.example.AllVideoDownloder.insta.interfaces;

import java.io.Serializable;

public interface OnClick extends Serializable {

    void show(int position, String type, String data);

}
