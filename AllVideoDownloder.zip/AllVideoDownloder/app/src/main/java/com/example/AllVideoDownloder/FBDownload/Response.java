package com.example.AllVideoDownloder.FBDownload;

public class Response {

    private Error error;
    private boolean isSuccessful;
    private boolean isPaused;
    private boolean isNetworkIssue;
    private boolean isCancelled;

    public Error getError() {
        return null;
    }

    public void setError(Error error) {
    }

    public boolean isSuccessful() {
        return isSuccessful;
    }

    public void setSuccessful(boolean successful) {
        isSuccessful = successful;
    }

    public boolean isPaused() {
        return isPaused;
    }

    public void setPaused(boolean paused) {
        isPaused = paused;
    }

    public boolean isNetworkIssue() {
        return isNetworkIssue;
    }

    public void setNetworkIssue(boolean paused) {
        isNetworkIssue = paused;
    }

    public boolean isCancelled() {
        return isCancelled;
    }

    public void setCancelled(boolean cancelled) {
        isCancelled = cancelled;
    }

}
