package com.example.AllVideoDownloder.FBDownload;


public interface OnDownloadListener {

    void onDownloadComplete();

    void onError(Error error);

}
