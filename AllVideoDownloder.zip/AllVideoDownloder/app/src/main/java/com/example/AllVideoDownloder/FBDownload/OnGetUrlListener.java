package com.example.AllVideoDownloder.FBDownload;


public interface OnGetUrlListener {
    void error(String str);

    void getSampleUrl(String str) ;
}