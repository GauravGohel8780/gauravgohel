package com.example.AllVideoDownloder.FBDownload;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "BookmarkModel")
public class BookmarkModel {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String title;
    private String url;
    private byte[] thumb;

    public BookmarkModel(String title, String url, byte[] thumb) {
        this.title = title;
        this.url = url;
        this.thumb = thumb;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public byte[] getThumb() {
        return thumb;
    }

    public void setThumb(byte[] thumb) {
        this.thumb = thumb;
    }
}
