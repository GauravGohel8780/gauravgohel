package com.example.AllVideoDownloder.FBDownload;


public enum Status {

    QUEUED,

    RUNNING,

    PAUSED,

    COMPLETED,

    CANCELLED,

    FAILED,

    UNKNOWN

}
