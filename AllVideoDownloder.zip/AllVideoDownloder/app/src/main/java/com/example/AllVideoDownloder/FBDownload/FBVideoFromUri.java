package com.example.AllVideoDownloder.FBDownload;


import android.util.Log;

import com.loopj.android.http.TextHttpResponseHandler;

import cz.msebera.android.httpclient.Header;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref.ObjectRef;
import kotlin.text.StringsKt;


public final class FBVideoFromUri extends TextHttpResponseHandler {
    final  ObjectRef<String> url;
    final FBVideoLink this_0;

    FBVideoFromUri(ObjectRef<String> $url2, FBVideoLink $receiver) {
        this.url = $url2;
        this.this_0 = $receiver;
    }

    public void onStart() {
    }

    public void onFinish() {
    }

    public void onSuccess(int i, Header[] headerArr, String str) {
        Intrinsics.checkNotNullParameter(headerArr, "headerArr");
        Intrinsics.checkNotNullParameter(str, "str");
        int length = headerArr.length;
        int i2 = 0;
        while (i2 < length) {
            Header value = headerArr[i2];
            i2++;
            Log.e("header : ", value.getValue());
        }
        if (StringsKt.contains((CharSequence) this.url.element, (CharSequence) "facebook.com", false) || StringsKt.contains((CharSequence) this.url.element, (CharSequence) "fb", false)) {
            this.this_0.facebook(str);
            return;
        }
        OnGetUrlListener access_getListener_p = this.this_0.listener;
        if (access_getListener_p != null) {
            String string = "invalid_link";
            Intrinsics.checkNotNullExpressionValue(string, "context.getString(R.string.str_not_facebook_url)");
            Log.e("TAG", "str..........error...444..." + string);

            access_getListener_p.error(string);
        }
    }

    public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
        if ((throwable == null ? null : throwable.getMessage()) != null) {
            OnGetUrlListener access_getListener_p = this.this_0.listener;
            if (access_getListener_p != null) {
                String message = throwable.getMessage();
                if (message == null) {
                    message = "";
                }
                access_getListener_p.error(message);
                Log.e("TAG", "str..........error...5555..." + message);

                return;
            }
            return;
        }
        OnGetUrlListener access_getListener_p2 = this.this_0.listener;
        if (access_getListener_p2 != null) {
            String string = "invalid_link";
            Intrinsics.checkNotNullExpressionValue(string, "context.getString(R.string.str_invalid_url)");
            Log.e("TAG", "str..........error...6666..." + string);

            access_getListener_p2.error(string);
        }
    }
}
