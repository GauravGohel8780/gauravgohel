package com.example.AllVideoDownloder;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import com.example.AllVideoDownloder.FBDownload.Activity.Fb_DownloaderActivity;
import com.example.AllVideoDownloder.FBDownload.Activity.Insta_DownloaderActivity;
import com.example.AllVideoDownloder.insta.ui.activity.InstagramActivity;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_RUNNER = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.fb).setOnClickListener(v -> {
            if (!checkWriteExternalPermission()) {
                permisstion();
            } else {
                Intent intent = new Intent(this, Fb_DownloaderActivity.class);
                startActivity(intent);
            }
        });
        findViewById(R.id.insta).setOnClickListener(v -> {
            if (!checkWriteExternalPermission()) {
                permisstion();
            } else {
                Intent intent = new Intent(this, Insta_DownloaderActivity.class);
                startActivity(intent);
            }
        });
        findViewById(R.id.insta1).setOnClickListener(v -> {
            if (!checkWriteExternalPermission()) {
                permisstion();
            } else {
                Intent intent = new Intent(this, InstagramActivity.class);
                startActivity(intent);
            }
        });
    }

    private void permisstion() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (!(ActivityCompat.checkSelfPermission(MainActivity.this, "android.permission.READ_MEDIA_VIDEO") == 0 && ActivityCompat.checkSelfPermission(MainActivity.this, "android.permission.READ_MEDIA_IMAGES") == 0 || ActivityCompat.checkSelfPermission(MainActivity.this, "android.permission.READ_MEDIA_AUDIO") == 0) && !(ActivityCompat.checkSelfPermission(MainActivity.this, "android.permission.READ_EXTERNAL_STORAGE") == 0)) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{"android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_AUDIO"}, REQUEST_CODE_RUNNER);
            }
        } else {
            if (ContextCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CODE_RUNNER);
            }
        }
    }

    private boolean checkWriteExternalPermission() {
        int res;
        if (Build.VERSION.SDK_INT >= 33) {
            String permission = android.Manifest.permission.READ_MEDIA_AUDIO;
            res = checkCallingOrSelfPermission(permission);
        } else {
            String permission = Manifest.permission.WRITE_EXTERNAL_STORAGE;
            res = checkCallingOrSelfPermission(permission);
        }
        return (res == PackageManager.PERMISSION_GRANTED);
    }
}