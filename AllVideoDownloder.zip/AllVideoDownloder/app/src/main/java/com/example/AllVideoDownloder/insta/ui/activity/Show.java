package com.example.AllVideoDownloder.insta.ui.activity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.example.AllVideoDownloder.R;
import com.example.AllVideoDownloder.insta.ui.adapter.ShowAdapter;
import com.example.AllVideoDownloder.insta.util.Constant;
import com.example.AllVideoDownloder.insta.util.Events;
import com.example.AllVideoDownloder.insta.util.GlobalBus;
import com.example.AllVideoDownloder.insta.util.Method;
import com.example.AllVideoDownloder.insta.util.ZoomOutTransformation;

import org.greenrobot.eventbus.Subscribe;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Show extends AppCompatActivity {

    private String type;
    private Method method;
    private Animation myAnim;
    private ViewPager viewPager;
    private List<File> showArray;
    private ShowAdapter showAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_show);

        method = new Method(Show.this);
        method.changeStatusBarColor();

        GlobalBus.getBus().register(this);

        Intent in = getIntent();
        int selectedPosition = in.getIntExtra("position", 0);
        type = in.getStringExtra("type");

        showArray = new ArrayList<>();

        myAnim = AnimationUtils.loadAnimation(Show.this, R.anim.bounce);
        viewPager = findViewById(R.id.viewpager_imageShow);

        switch (type) {
            case "image":
                showArray = Constant.imageArray;
                break;
            case "video":
                showArray = Constant.videoArray;
                break;
        }

        ZoomOutTransformation zoomOutTransformation = new ZoomOutTransformation();
        viewPager.setPageTransformer(true, zoomOutTransformation);

        showAdapter = new ShowAdapter(Show.this, showArray, type);
        viewPager.setAdapter(showAdapter);
        viewPager.addOnPageChangeListener(viewPagerPageChangeListener);

        setCurrentItem(selectedPosition);


    }

    @Subscribe
    public void getNotify(Events.AdapterNotify adapterNotify) {
        if (showAdapter != null) {
            showAdapter.notifyDataSetChanged();
        }
    }

    private void setCurrentItem(int position) {
        viewPager.setCurrentItem(position, false);
    }

    //	page change listener
    ViewPager.OnPageChangeListener viewPagerPageChangeListener = new ViewPager.OnPageChangeListener() {

        @Override
        public void onPageSelected(int position) {

        }

        @Override
        public void onPageScrolled(int arg0, float arg1, int arg2) {

        }

        @Override
        public void onPageScrollStateChanged(int arg0) {

        }

    };

    private void deleteFile() {
        if (showArray.size() != 0) {
            try {
                File files = new File(showArray.get(viewPager.getCurrentItem()).toString());
                files.delete();
                showArray.remove(viewPager.getCurrentItem());
                showAdapter.notifyDataSetChanged();
                if (showArray.size() == 0) {
                    onBackPressed();
                }
                Events.AdapterNotify adapterNotify = new Events.AdapterNotify(type);
                GlobalBus.getBus().post(adapterNotify);
                Toast.makeText(Show.this, getResources().getString(R.string.delete), Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                method.alertBox(getResources().getString(R.string.wrong));
            }
        }
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
//        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
//            CropImage.ActivityResult result = CropImage.getActivityResult(data);
//            if (resultCode == RESULT_OK) {
//                Uri resultUri = result.getUri();
//                try {
//                    Bitmap myBitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(resultUri));
//                    WallpaperManager myWallpaperManager = WallpaperManager.getInstance(getApplicationContext());
//                    myWallpaperManager.setBitmap(myBitmap);
//                } catch (IOException e) {
//                    Log.d("data_app", e.toString());
//                }
//            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
//                Exception error = result.getError();
//                Log.d("data_app", error.toString());
//            }
//        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }


    @Override
    protected void onDestroy() {
        // Unregister the registered event.
        GlobalBus.getBus().unregister(this);
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        onBack();
    }

    private void onBack() {
        super.onBackPressed();
    }
}
