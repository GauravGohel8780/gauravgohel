package com.kidslearn.tracing.phonics;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.iten.tenoku.ad.AdShow;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.kidslearn.tracing.phonics.Ads_Common.AdsBaseActivity;

import java.io.File;
import java.util.List;

public class ABCKidsMainActivity extends AdsBaseActivity {
    ImageButton ibAlphabets, ibNumbers, ibPatterns, ibShapes;
    Animation Button1Animation,Button2Animation;
    MediaPlayer ButtonSelection,piano;
    String currentClicked;
    Handler handler;
    Typeface mTypeface;
    RelativeLayout rlMain;
    int width, height;
    public boolean isInSameActivity = true;


    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        SetSystemFullScreen();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        rlMain = (RelativeLayout) findViewById(R.id.rlMain);
        ibPatterns = (ImageButton) findViewById(R.id.ibPatterns);
        ibShapes = (ImageButton) findViewById(R.id.ibShapes);
        ibNumbers = (ImageButton) findViewById(R.id.ibNumbers);
        ibAlphabets = (ImageButton) findViewById(R.id.ibAlphabets);
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        width = displayMetrics.widthPixels;
        height = displayMetrics.heightPixels;
        rlMain.setBackground(new BitmapDrawable(getResources(), resizeImageToNewSize(BitmapFactory.decodeResource(getResources(), R.drawable.ic_screen_4), width, height)));
        piano = MediaPlayer.create(this, (int) R.raw.raw_random_piano);
        ButtonSelection = MediaPlayer.create(this, (int) R.raw.raw_button_selection);
        Button1Animation = AnimationUtils.loadAnimation(this, R.anim.anim_move);
        Button2Animation = AnimationUtils.loadAnimation(this, R.anim.anim_shake);
        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ibPatterns.startAnimation(Button1Animation);
                ibShapes.startAnimation(Button2Animation);
                ibAlphabets.startAnimation(Button2Animation);
                ibNumbers.startAnimation(Button1Animation);
            }
        }, 400L);


        ibPatterns.setOnClickListener(view -> {
            AdShow.getInstance(ABCKidsMainActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    ButtonSelection.start();
                    ibPatterns.setClickable(false);
                    currentClicked = "Patterns";
                    if (isApplicationSentToBackground(ABCKidsMainActivity.this)) {
                        return;
                    }
                    Intent intent = new Intent(ABCKidsMainActivity.this, ABCKidsTraceLayout.class);
                    intent.putExtra("Category", "Patterns");
                    startActivityForResult(intent, 3);
                    intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    isInSameActivity = false;
                    System.out.println("@@@@@@@#### Calling no Internet ibPatterns");
                }
            }, AdUtils.ClickType.MAIN_CLICK);
        });
        ibShapes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdShow.getInstance(ABCKidsMainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        ButtonSelection.start();
                        ibShapes.setClickable(false);
                        currentClicked = "Shapes";
                        if (isApplicationSentToBackground(ABCKidsMainActivity.this)) {
                            return;
                        }
                        Intent intent = new Intent(ABCKidsMainActivity.this, ABCKidsTraceLayout.class);
                        intent.putExtra("Category", "Shapes");
                        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivityForResult(intent, 3);
                        isInSameActivity = false;
                        System.out.println("@@@@@@@####  no Calling ibShapes");
                    }
                }, AdUtils.ClickType.MAIN_CLICK);

            }
        });
        ibNumbers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdShow.getInstance(ABCKidsMainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        ButtonSelection.start();
                        currentClicked = "123";
                        ibNumbers.setClickable(false);
                        if (isApplicationSentToBackground(ABCKidsMainActivity.this)) {
                            return;
                        }
                        Intent intent = new Intent(ABCKidsMainActivity.this, ABCKidsTraceLayout.class);
                        intent.putExtra("Category", "123");
                        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivityForResult(intent, 3);
                        isInSameActivity = false;
                        System.out.println("@@@@@@@#### no internte Calling ibNumbers");
                    }
                }, AdUtils.ClickType.MAIN_CLICK);
            }
        });
        ibAlphabets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdShow.getInstance(ABCKidsMainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        ButtonSelection.start();
                        currentClicked = "ABC";
                        ibAlphabets.setClickable(false);
                        if (isApplicationSentToBackground(ABCKidsMainActivity.this)) {
                            return;
                        }
                        Intent intent = new Intent(ABCKidsMainActivity.this, ABCKidsTraceLayout.class);
                        intent.putExtra("Category", "ABC");
                        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivityForResult(intent, 3);
                        isInSameActivity = false;
                        System.out.println("@@@@@@@#### Calling  no ibAlphabets");
                    }
                }, AdUtils.ClickType.MAIN_CLICK);
            }
        });
    }

    public Bitmap resizeImageToNewSize(Bitmap bitmap, int i, int i2) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        float f = i;
        float f2 = i2;
        if (height != i2 || width != i) {
            float f3 = width;
            float f4 = f / f3;
            float f5 = height;
            float f6 = f2 / f5;
            if (f4 < f6) {
                f6 = f4;
            }
            f = f3 * f6;
            f2 = f5 * f6;
        }
        return Bitmap.createScaledBitmap(bitmap, (int) f, (int) f2, true);
    }

    public void stopAnimation() {
        ibPatterns.clearAnimation();
        ibShapes.clearAnimation();
        ibAlphabets.clearAnimation();
        ibNumbers.clearAnimation();
    }

    @Override
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            return true;
        }
        return super.onTouchEvent(motionEvent);
    }

    public boolean isApplicationSentToBackground(Context context) {
        try {
            List<ActivityManager.RunningTaskInfo> runningTasks = ((ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE)).getRunningTasks(1);
            if (!runningTasks.isEmpty()) {
                if (!runningTasks.get(0).topActivity.getPackageName().equals(context.getPackageName())) {
                    return true;
                }
            }
        } catch (Exception unused) {
        }
        return false;
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            ABCKidsSoundService.pauseService();
        } catch (Exception unused) {
        }
    }

    @Override
    public void onResume() {
        System.out.println("~~~~~ onresume");
        isInSameActivity = true;
        ibPatterns.setClickable(true);
        ibShapes.setClickable(true);
        ibNumbers.setClickable(true);
        ibAlphabets.setClickable(true);
        try {
            if (ABCKidsStoreData.ismute) {
                ABCKidsSoundService.pauseService();
            } else {
                startService(new Intent(this, ABCKidsSoundService.class));
            }
        } catch (Exception unused) {

        }
        rlMain.setBackground(new BitmapDrawable(getResources(), resizeImageToNewSize(BitmapFactory.decodeResource(getResources(), R.drawable.ic_screen_4), width, height)));
        isInSameActivity = true;
        super.onResume();

        AdShow.getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }


    @Override
    protected void onRestart() {
        System.out.println("~~~~~ Restart");
        ibPatterns.setClickable(true);
        ibNumbers.setClickable(true);
        ibShapes.setClickable(true);
        ibAlphabets.setClickable(true);
        super.onRestart();
    }

    @Override
    protected void onStop() {
        System.out.println("~~~~~ onstop");
        rlMain.setBackground(null);
        super.onStop();
    }

    @Override
    protected void onActivityResult(int i, int i2, Intent intent) {
        System.out.println("~~~~~ onactivityresult");
        if (i == 3 && i2 == 3) {
            rlMain.setBackground(new BitmapDrawable(getResources(), resizeImageToNewSize(BitmapFactory.decodeResource(getResources(), R.drawable.ic_screen_4), width, height)));
        }
        ibPatterns.setClickable(true);
        ibNumbers.setClickable(true);
        ibShapes.setClickable(true);
        ibAlphabets.setClickable(true);
        super.onActivityResult(i, i2, intent);
    }


    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        setResult(2);
        finish();
    }

    @Override
    protected void onDestroy() {
        stopAnimation();
        handler.removeMessages(0);
        deleteCache(this);
        Runtime.getRuntime().runFinalization();
        Runtime.getRuntime().gc();
        super.onDestroy();
    }

    public static void deleteCache(Context context) {
        try {
            deleteDir(context.getCacheDir());
        } catch (Exception unused) {

        }
    }

    public static boolean deleteDir(File file) {
        if (file != null && file.isDirectory()) {
            for (String str : file.list()) {
                if (!deleteDir(new File(file, str))) {
                    return false;
                }
            }
            return file.delete();
        } else if (file == null || !file.isFile()) {
            return false;
        } else {
            return file.delete();
        }
    }
    public void SetSystemFullScreen() {
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) {
            View v = getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }
}
