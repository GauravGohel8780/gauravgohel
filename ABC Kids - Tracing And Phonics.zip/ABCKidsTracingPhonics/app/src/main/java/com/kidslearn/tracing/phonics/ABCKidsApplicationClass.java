package com.kidslearn.tracing.phonics;


public class ABCKidsApplicationClass {
    public static float pixelValue = 1.0f;

}
