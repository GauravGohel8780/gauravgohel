package com.kidslearn.tracing.phonics;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;

import java.io.PrintStream;


public class ABCKidsSoundService extends Service {
    public static MediaPlayer player;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        player = MediaPlayer.create(this, (int) R.raw.raw_random_piano);
        player.setLooping(true);
        player.setVolume(ABCKidsStoreData.bgSound, ABCKidsStoreData.bgSound);
        player.start();
        System.out.println("^^^^^^^^ on create service");
    }

    public static void playerSound(float f) {
        PrintStream printStream = System.out;
        printStream.println("##### volume" + f);
        player.setVolume(f, f);
    }

    public static void pauseService() {
        System.out.println("^^^^^^^^ on pause service");
        MediaPlayer mediaPlayer = player;
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
            return;
        }
        player.pause();
    }

    public static void restartService() {
        MediaPlayer mediaPlayer = player;
        if (mediaPlayer != null) {
            mediaPlayer.start();
            System.out.println("^^^^^^^^ on restart service");
        }
    }

    @Override
    public int onStartCommand(Intent intent, int i, int i2) {
        player.start();
        System.out.println("^^^^^^^^ start command");
        return Service.START_STICKY;
    }

    @Override
    public void onDestroy() {
        player.stop();
        player.release();
        System.out.println("^^^^^^^^ destroy service");
    }

    @Override
    public void onLowMemory() {
        player.release();
    }
}
