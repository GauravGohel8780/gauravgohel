package com.kidslearn.tracing.phonics;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;

public class ABCKidsService extends Service {
    public static MediaPlayer player;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        player = MediaPlayer.create(this, ABCKidsStoreData.music);
        player.setLooping(false);
        player.setVolume(ABCKidsStoreData.butSound, ABCKidsStoreData.butSound);
        player.start();
    }

    @Override
    public int onStartCommand(Intent intent, int i, int i2) {
        player.start();
        return Service.START_STICKY;
    }

    @Override
    public void onDestroy() {
        player.stop();
        player.release();
    }
}
