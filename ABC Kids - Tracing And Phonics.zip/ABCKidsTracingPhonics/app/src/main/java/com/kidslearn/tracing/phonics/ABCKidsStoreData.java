package com.kidslearn.tracing.phonics;


public class ABCKidsStoreData {
    public static float bgSound = 1.0f;
    public static float butSound = 1.0f;
    public static boolean isPlaying = true;
    public static boolean ismute = false;
    public static int music = 0;
    public static int seekbar_progress = 99;
    public static float temp_sound = 1.0f;

}
