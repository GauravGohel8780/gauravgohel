package com.kidslearn.tracing.phonics;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;

import java.io.PrintStream;

public class ABCKidsDrawingView extends View {
    private static final float TOUCH_TOLERANCE = 4.0f;
    static Bitmap mBitmap;
    Canvas bCanvas;
    private Paint bpaint;
    Context context;
    Bitmap drawingBitmap;
    int drawingPicHeight;
    int drawingPicOffset_x;
    int drawingPicOffset_y;
    int drawingPicWidth;
    private boolean drawingTouch;
    int drawingpic_x;
    int drawingpic_y;
    Handler handler;
    Path linePath;
    Canvas mCanvas;
    Paint mPaint;
    private Path mPath;
    private float mX;
    private float mY;
    boolean ontouch_canvas;
    int pathCont;
    PathMeasure pm;
    float x;
    private float x1;
    float y;
    private float y1;

    public ABCKidsDrawingView(Context context, Bitmap bitmap, int i) {
        super(context);
        this.ontouch_canvas = false;
        this.handler = new Handler();
        this.bpaint = new Paint(1);
        this.drawingBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_pencil1);
        this.drawingpic_x = 0;
        this.drawingpic_y = 0;
        this.drawingPicWidth = this.drawingBitmap.getWidth();
        this.drawingPicHeight = this.drawingBitmap.getHeight();
        this.drawingPicOffset_x = 0;
        this.drawingPicOffset_y = 0;
        this.pm = new PathMeasure(this.mPath, false);
        this.pathCont = 0;
        this.context = context;
        this.mPath = new Path();
        mBitmap = bitmap;
        this.mPaint = new Paint();
        this.mPaint.setAntiAlias(true);
        this.mPaint.setDither(true);
        this.mPaint.setColor(i);
        this.mPaint.setStyle(Paint.Style.STROKE);
        this.mPaint.setStrokeJoin(Paint.Join.ROUND);
        this.mPaint.descent();
        this.mPaint.setStrokeCap(Paint.Cap.ROUND);
        this.mPaint.setStrokeWidth(100.0f);
        this.mPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));
        this.linePath = new Path();
    }

    @Override
    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        mBitmap = Bitmap.createScaledBitmap(mBitmap, i, i2, true).copy(Bitmap.Config.ARGB_8888, true);
        this.mCanvas = new Canvas(mBitmap);
        this.bCanvas = new Canvas();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawBitmap(mBitmap, 0.0f, 0.0f, this.mPaint);
        if (this.ontouch_canvas) {
            if (this.mPaint.getColor() == Color.parseColor("#51db51")) {
                this.drawingBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_pencil2);
            } else if (this.mPaint.getColor() == Color.parseColor("#00a1db")) {
                this.drawingBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_pencil1);
            } else {
                this.drawingBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_pencil3);
            }
            canvas.drawBitmap(this.drawingBitmap, this.x1, this.y1, this.mPaint);
            this.mCanvas.drawPath(this.mPath, this.mPaint);
        }
    }

    @Override
    protected void onMeasure(int i, int i2) {
        setMeasuredDimension(MeasureSpec.getSize(i), MeasureSpec.getSize(i2));
    }

    private void touch_start(float f, float f2) {
        this.mPath.reset();
        this.mPath.moveTo(f, f2);
        this.mX = f;
        this.mY = f2;
    }

    private void touch_move(float f, float f2) {
        float abs = Math.abs(f - this.mX);
        float abs2 = Math.abs(f2 - this.mY);
        if (abs >= TOUCH_TOLERANCE || abs2 >= TOUCH_TOLERANCE) {
            Path path = this.mPath;
            float f3 = this.mX;
            float f4 = this.mY;
            path.quadTo(f3, f4, (f + f3) / 2.0f, (f2 + f4) / 2.0f);
            this.mX = f;
            this.mY = f2;
        }
    }

    private void touch_up() {
        this.mPath.lineTo(this.mX, this.mY);
        this.mCanvas.drawPath(this.mPath, this.mPaint);
        this.mPath.reset();
    }

    public void setPaintColor(String str) {
        if (str.equals("pink")) {
            this.mPaint.setColor(Color.parseColor("#ff5798"));
        } else if (str.equals("green")) {
            this.mPaint.setColor(Color.parseColor("#51db51"));
        } else if (str.equals("blue")) {
            this.mPaint.setColor(Color.parseColor("#00a1db"));
        } else {
            this.mPaint.setColor(Color.parseColor("#00a1db"));
        }

        this.ontouch_canvas = true;
        invalidate();
    }
    @Override
    public boolean onTouchEvent(MotionEvent motionEvent) {
        this.ontouch_canvas = true;
        this.x = motionEvent.getX();
        this.y = motionEvent.getY();
        int action = motionEvent.getAction();
        if (action == 0) {
            this.x1 = motionEvent.getX();
            this.y1 = motionEvent.getY();
            float f = this.x1;
            int i = this.drawingpic_x;
            if (f > i && f < this.drawingPicWidth + i) {
                float f2 = this.y1;
                int i2 = this.drawingpic_y;
                if (f2 > i2 && f2 < this.drawingPicHeight + i2) {
                    this.drawingPicOffset_x = ((int) f) - i;
                    this.drawingPicOffset_y = ((int) f2) - i2;
                    this.drawingTouch = true;
                }
            }
            touch_start(this.x1, this.y1);
            invalidate();
        } else if (action == 1) {
            this.ontouch_canvas = false;
            touch_up();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        ABCKidsApplicationClass.pixelValue = ABCKidsDrawingView.percentTransparent(ABCKidsDrawingView.mBitmap);
                        PrintStream printStream = System.out;
                        printStream.println("~~~~~ ONtouch up pixelValu " + ABCKidsApplicationClass.pixelValue);
                    } catch (Exception unused) {
                    }
                }
            }).start();
            invalidate();
        } else if (action == 2) {
            this.x1 = motionEvent.getX();
            this.y1 = motionEvent.getY();
            if (this.drawingTouch) {
                this.drawingpic_x = ((int) this.x1) - this.drawingPicOffset_x;
                this.drawingpic_y = ((int) this.y1) - this.drawingPicOffset_y;
            }
            touch_move(this.x1, this.y1);
            invalidate();
        } else {
            this.drawingTouch = false;
        }
        invalidate();
        return true;
    }

    public static float percentTransparent(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int i = 0;
        int i2 = 0;
        while (i < width) {
            int i3 = i2;
            for (int i4 = 0; i4 < height; i4++) {
                if (bitmap.getPixel(i, i4) == Color.parseColor("#ffef3a")) {
                    i3++;
                }
            }
            i++;
            i2 = i3;
        }
        return i2 / (width * height);
    }
}
