package com.kidslearn.tracing.phonics;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.iten.tenoku.ad.AdShow;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.kidslearn.tracing.phonics.Ads_Common.AdsBaseActivity;

import java.io.File;
import java.io.PrintStream;
import java.util.List;
import java.util.Locale;

import pl.droidsonroids.gif.GifImageView;


public class ABCKidsTraceLayout extends AdsBaseActivity {

    ImageButton ibBack, ibBefore, ibHome, ibMusic, ibNext, ibPencil1, ibPencil2, ibPencil3, ibRefresh;
    MediaPlayer button_selection, correct_answer, please_wait, try_again, wrong_answer;
    String category, currentString;
    Animation click_effect_anim, great1_anim, next_but_anim, star_one_anim;
    RelativeLayout rlCustomLayout, rlGif, rlGifNo, rlGreat1Layout, rlMain, rlMindBlowingLayout, rlStarOneLayout, rlStarThreeLayout, rlStarTwoLayout;
    ABCKidsDrawingView drawingView;
    ImageView ivGreat1, ivMindBlowing, ivStarOne, ivStarThree, ivStarTwo, ivVolume;
    Handler handler, handler1;
    int height;
    GifImageView givThinking, givNoWrong;
    AsyncCaller pixcelAsyncTask;
    Bitmap requiredBitmap;
    TextToSpeech textToSpeech;
    int width;
    int tempValue = 0;
    boolean isInSameActivity = true;
    boolean iscirrectPlaying = false;
    boolean isonpause = true;
    Boolean isInSameActivity_add = true;
    boolean bgMusic_playing = true;

    boolean full_volume = true;
    int correctAnsrTemp = -1;
    int colorCode = Color.parseColor("#00a1db");


    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_trace_layout);
        getWindow().addFlags(1024);

        try {
            if (ABCKidsStoreData.ismute) {
                ABCKidsSoundService.pauseService();
            } else {
                startService(new Intent(this, ABCKidsSoundService.class));
            }
        } catch (Exception unused) {
        }
        rlMain = (RelativeLayout) findViewById(R.id.rlMain);
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        width = displayMetrics.widthPixels;
        height = displayMetrics.heightPixels;
        rlMain.setBackground(new BitmapDrawable(getResources(), resizeImageToNewSize(BitmapFactory.decodeResource(getResources(), R.drawable.ic_screen_2), width, height)));
        bgMusic_playing = false;
        ivVolume = (ImageView) findViewById(R.id.ivVolume);
        ibHome = (ImageButton) findViewById(R.id.ibHome);
        rlStarOneLayout = (RelativeLayout) findViewById(R.id.rlStarOneLayout);
        rlStarTwoLayout = (RelativeLayout) findViewById(R.id.rlStarTwoLayout);
        rlStarThreeLayout = (RelativeLayout) findViewById(R.id.rlStarThreeLayout);
        rlGreat1Layout = (RelativeLayout) findViewById(R.id.rlGreat1Layout);
        rlMindBlowingLayout = (RelativeLayout) findViewById(R.id.rlMindBlowingLayout);
        ibRefresh = (ImageButton) findViewById(R.id.ibRefresh);
        ibMusic = (ImageButton) findViewById(R.id.ibMusic);
        ibPencil1 = (ImageButton) findViewById(R.id.ibPencil1);
        ibPencil2 = (ImageButton) findViewById(R.id.ibPencil2);
        ibPencil3 = (ImageButton) findViewById(R.id.ibPencil3);
        textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                if (i != -1) {
                    textToSpeech.setLanguage(Locale.CANADA);
                }
            }
        });
        if (!isConnectingToInternet()) {
            try {
                textStart();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        category = getIntent().getExtras().getString("Category");
        ivGreat1 = (ImageView) findViewById(R.id.ivGreat1);
        ivMindBlowing = (ImageView) findViewById(R.id.ivMindBlowing);
        ivStarOne = (ImageView) findViewById(R.id.ivStarOne);
        ivStarTwo = (ImageView) findViewById(R.id.ivStarTwo);
        ivStarThree = (ImageView) findViewById(R.id.ivStarThree);
        great1_anim = AnimationUtils.loadAnimation(this, R.anim.anim_great1);
        star_one_anim = AnimationUtils.loadAnimation(this, R.anim.anim_heartpulseanimation);
        rlGif = (RelativeLayout) findViewById(R.id.rlGif);
        givThinking = (GifImageView) findViewById(R.id.givThinking);
        rlGifNo = (RelativeLayout) findViewById(R.id.rlGifNo);
        givNoWrong = (GifImageView) findViewById(R.id.givNoWrong);
        handler = new Handler();
        requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_one);
        drawingView = new ABCKidsDrawingView(this, requiredBitmap, colorCode);
        ibBack = (ImageButton) findViewById(R.id.ibBack);
        button_selection = MediaPlayer.create(this, (int) R.raw.raw_button_selection);
        try_again = MediaPlayer.create(this, (int) R.raw.raw_try_again);
        wrong_answer = MediaPlayer.create(this, (int) R.raw.raw_wrong_ans);
        correct_answer = MediaPlayer.create(this, (int) R.raw.raw_correct_ans);
        please_wait = MediaPlayer.create(this, (int) R.raw.raw_please_wait);
        next_but_anim = AnimationUtils.loadAnimation(this, R.anim.anim_heartpulseanimation);
        click_effect_anim = AnimationUtils.loadAnimation(this, R.anim.anim_effect);
        click_effect_anim.setInterpolator(new ABCKidsBounceInterpolator(0.2d, 20.0d));
        ibNext = (ImageButton) findViewById(R.id.ibNext);
        ibBefore = (ImageButton) findViewById(R.id.ibBefore);
        ibHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clearAnimation();
                ibHome.startAnimation(click_effect_anim);
                button_selection.start();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        getInstance(ABCKidsTraceLayout.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                startActivity(new Intent(ABCKidsTraceLayout.this, ABCKidsStartActivity.class));
                            }
                        }, BACK_CLICK);

                    }
                }, 400L);
            }
        });
        rlCustomLayout = (RelativeLayout) findViewById(R.id.rlCustomLayout);
        if (ABCKidsStoreData.bgSound == 0.0f) {
            ivVolume.setImageResource(R.drawable.ic_mute);
            ABCKidsStoreData.ismute = true;
            full_volume = false;
        } else if (ABCKidsStoreData.isPlaying) {
            ABCKidsStoreData.ismute = false;
            ivVolume.setImageResource(R.drawable.ic_volume);
            full_volume = true;
        } else {
            ABCKidsStoreData.ismute = true;
            ivVolume.setImageResource(R.drawable.ic_mute);
            full_volume = false;
        }
        changeCustomView(1);
        ibNext.startAnimation(next_but_anim);
        ibMusic.startAnimation(next_but_anim);
        ibBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(ABCKidsTraceLayout.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        startActivity(new Intent(ABCKidsTraceLayout.this, ABCKidsMainActivity.class));
                    }
                }, BACK_CLICK);
            }
        });
        ibNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(ABCKidsTraceLayout.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        try {
                            ABCKidsSoundService.pauseService();
                        } catch (Exception e2) {
                            e2.printStackTrace();
                        }
                        ABCKidsTraceLayout traceLayout = ABCKidsTraceLayout.this;
                        traceLayout.isInSameActivity = false;
                        traceLayout.button_selection.start();
                        textToSpeech.setSpeechRate(1.0f);
                        textToSpeech.speak("Please Wait Let Me Check", 0, null);
                        ibNext.setVisibility(View.INVISIBLE);
                        ibNext.clearAnimation();
                        isClickable();
                        rlGif.setVisibility(View.VISIBLE);
                        Glide.with(ABCKidsTraceLayout.this).load(R.drawable.ic_sss).into(givThinking);
                        handler = new Handler();
                        PrintStream printStream = System.out;
                        printStream.println("~~~~~ pixel value before asyntask " + ABCKidsApplicationClass.pixelValue);
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                pixcelAsyncTask = new AsyncCaller();
                                pixcelAsyncTask.execute(new Void[0]);
                                if (isonpause) {
                                    try {
                                        System.out.println("Correct answer------------------");
                                        ABCKidsSoundService.restartService();
                                    } catch (Exception e3) {
                                        e3.printStackTrace();
                                    }
                                }
                            }
                        }, 5300L);
                    }
                }, MAIN_CLICK);
            }
        });
        ibMusic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(ABCKidsTraceLayout.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        if (currentString == "JOIN THE SLANTING LINES" || currentString == "JOIN THE SLANTING LINES FOR LETTER V" || currentString == "LEFT CURVE FOR LETTER C" || currentString == "CURVE FOR LETTER U" || currentString == "JOIN THE DOTS FOR LETTER O" || currentString == "JOIN TWO CURVES FOR LETTER S" || currentString == "JOIN THE DOTS FOR TICK MARK") {
                            textToSpeech.setSpeechRate(1.0f);
                        } else {
                            textToSpeech.setSpeechRate(0.01f);
                        }
                        textToSpeech.speak(currentString, 0, null);
                    }
                }, MAIN_CLICK);
            }
        });
        ibPencil1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(ABCKidsTraceLayout.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        clearAnimation();
                        ibPencil1.startAnimation(click_effect_anim);
                        textToSpeech.speak("Pink Color", 0, null);
                        colorCode = Color.parseColor("#ff5798");
                        drawingView.invalidate();
                        drawingView.setPaintColor("pink");
                        genericfuntion(requiredBitmap);
                    }
                }, MAIN_CLICK);
            }
        });
        ibPencil2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(ABCKidsTraceLayout.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        clearAnimation();
                        ibPencil2.startAnimation(click_effect_anim);
                        textToSpeech.speak("Green Color", 0, null);
                        colorCode = Color.parseColor("#51db51");
                        drawingView.invalidate();
                        drawingView.setPaintColor("green");
                        genericfuntion(requiredBitmap);
                    }
                }, MAIN_CLICK);
            }
        });
        ibPencil3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(ABCKidsTraceLayout.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        clearAnimation();
                        ibPencil3.startAnimation(click_effect_anim);
                        textToSpeech.speak("Blue Color", 0, null);
                        colorCode = Color.parseColor("#00a1db");
                        drawingView.invalidate();
                        drawingView.setPaintColor("blue");
                        genericfuntion(requiredBitmap);
                    }
                }, MAIN_CLICK);
            }
        });
        ibRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(ABCKidsTraceLayout.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        clearAnimation();
                        handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                PrintStream printStream = System.out;
                                printStream.println("~~~~~ MyApplicationClass.pixelValue ibRefresh" + ABCKidsApplicationClass.pixelValue);
                            }
                        }, 3000L);
                        button_selection.start();
                        ibRefresh.startAnimation(click_effect_anim);
                        switch (tempValue) {
                            case 1:
                                changeCustomView(1);
                                return;
                            case 2:
                                changeCustomView(2);
                                return;
                            case 3:
                                changeCustomView(3);
                                return;
                            case 4:
                                changeCustomView(4);
                                return;
                            case 5:
                                changeCustomView(5);
                                return;
                            case 6:
                                changeCustomView(6);
                                return;
                            case 7:
                                changeCustomView(7);
                                return;
                            case 8:
                                changeCustomView(8);
                                return;
                            case 9:
                                changeCustomView(9);
                                return;
                            case 10:
                                changeCustomView(10);
                                return;
                            case 11:
                                changeCustomView(11);
                                return;
                            case 12:
                                changeCustomView(12);
                                return;
                            case 13:
                                changeCustomView(13);
                                return;
                            case 14:
                                changeCustomView(14);
                                return;
                            case 15:
                                changeCustomView(15);
                                return;
                            case 16:
                                changeCustomView(16);
                                return;
                            case 17:
                                changeCustomView(17);
                                return;
                            case 18:
                                changeCustomView(18);
                                return;
                            case 19:
                                changeCustomView(19);
                                return;
                            case 20:
                                changeCustomView(20);
                                return;
                            case 21:
                                changeCustomView(21);
                                return;
                            case 22:
                                changeCustomView(22);
                                return;
                            case 23:
                                changeCustomView(23);
                                return;
                            case 24:
                                changeCustomView(24);
                                return;
                            case 25:
                                changeCustomView(25);
                                return;
                            case 26:
                                changeCustomView(26);
                                return;
                            default:
                                return;
                        }
                    }
                }, MAIN_CLICK);
            }
        });
        ibBefore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(ABCKidsTraceLayout.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        button_selection.start();
                        switch (tempValue) {
                            case 1:
                                changeCustomView(1);
                                return;
                            case 2:
                                changeCustomView(1);
                                return;
                            case 3:
                                changeCustomView(2);
                                return;
                            case 4:
                                changeCustomView(3);
                                return;
                            case 5:
                                changeCustomView(4);
                                return;
                            case 6:
                                changeCustomView(5);
                                return;
                            case 7:
                                changeCustomView(6);
                                return;
                            case 8:
                                changeCustomView(7);
                                return;
                            case 9:
                                changeCustomView(8);
                                return;
                            case 10:
                                changeCustomView(9);
                                return;
                            case 11:
                                changeCustomView(10);
                                return;
                            case 12:
                                changeCustomView(11);
                                return;
                            case 13:
                                changeCustomView(12);
                                return;
                            case 14:
                                changeCustomView(13);
                                return;
                            case 15:
                                changeCustomView(14);
                                return;
                            case 16:
                                changeCustomView(15);
                                return;
                            case 17:
                                changeCustomView(16);
                                return;
                            case 18:
                                changeCustomView(17);
                                return;
                            case 19:
                                changeCustomView(18);
                                return;
                            case 20:
                                changeCustomView(19);
                                return;
                            case 21:
                                changeCustomView(20);
                                return;
                            case 22:
                                changeCustomView(21);
                                return;
                            case 23:
                                changeCustomView(22);
                                return;
                            case 24:
                                changeCustomView(23);
                                return;
                            case 25:
                                changeCustomView(24);
                                return;
                            case 26:
                                changeCustomView(25);
                                return;
                            default:
                                return;
                        }
                    }
                }, MAIN_CLICK);
            }
        });
    }

    public void firstcall() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                String str = category;
                String speechText = null;

                if ("Patterns".equals(str)) {
                    speechText = "STANDING LINE";
                } else if ("Shapes".equals(str)) {
                    speechText = "SQUARE";
                } else if ("123".equals(str)) {
                    speechText = "ZERO";
                } else if ("ABC".equals(str)) {
                    speechText = "A";
                }

                if (speechText != null) {
                    textToSpeech.speak(speechText, 0, null);
                    currentString = speechText;
                }
            }
        }, 200L);
    }

    public void star_one_anim() {
        textToSpeech.setSpeechRate(1.0f);
        textToSpeech.speak("You goa One Star", 0, null);
        rlStarOneLayout.setVisibility(View.VISIBLE);
        ivStarOne.setVisibility(View.VISIBLE);
        ivStarOne.startAnimation(star_one_anim);
        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                rlStarOneLayout.setVisibility(View.INVISIBLE);
                ivStarOne.setVisibility(View.INVISIBLE);
                ivStarOne.clearAnimation();
                startNextBut_anim();
            }
        }, 4000L);
    }

    public void setTry_again() {
        makeAnimationInvisible();
        rlGifNo.setVisibility(View.VISIBLE);
        Glide.with(this).load(R.drawable.ic_parrot).into(givNoWrong);
        textToSpeech.setSpeechRate(1.0f);
        textToSpeech.speak("Oh! No No No No...... Try Again", 0, null);
        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                rlGifNo.setVisibility(View.INVISIBLE);
                startNextBut_anim();
            }
        }, 3500L);
        handler1 = new Handler();
    }

    public void startNextBut_anim() {
        ibNext.setVisibility(View.VISIBLE);
        ibNext.startAnimation(next_but_anim);
        ivStarOne.clearAnimation();
    }

    public void great1_anim() {
        textToSpeech.setSpeechRate(1.0f);
        textToSpeech.speak("Great Gob", 0, null);
        makeAnimationInvisible();
        rlGreat1Layout.setVisibility(View.VISIBLE);
        ivGreat1.setVisibility(View.VISIBLE);
        ivGreat1.startAnimation(great1_anim);
        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                rlGreat1Layout.setVisibility(View.INVISIBLE);
                ivGreat1.setVisibility(View.INVISIBLE);
                ivGreat1.clearAnimation();
                startNextBut_anim();
            }
        }, 4000L);
    }

    public void makeAnimationInvisible() {
        ivGreat1.clearAnimation();
        ivStarOne.clearAnimation();
        ivStarThree.clearAnimation();
        ivStarTwo.clearAnimation();
        ivMindBlowing.clearAnimation();
    }

    public void stars_great() {
        textToSpeech.setSpeechRate(1.0f);
        textToSpeech.speak(" You got three Stars", 0, null);
        makeAnimationInvisible();
        rlStarThreeLayout.setVisibility(View.VISIBLE);
        ivStarThree.setVisibility(View.VISIBLE);
        ivStarThree.startAnimation(star_one_anim);
        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                rlStarThreeLayout.setVisibility(View.INVISIBLE);
                ivStarThree.setVisibility(View.INVISIBLE);
                ivStarThree.clearAnimation();
                startNextBut_anim();
            }
        }, 4000L);
    }

    public void stars_two() {
        textToSpeech.setSpeechRate(1.0f);
        textToSpeech.speak(" You got two Stars", 0, null);
        makeAnimationInvisible();
        rlStarTwoLayout.setVisibility(View.VISIBLE);
        ivStarTwo.setVisibility(View.VISIBLE);
        ivStarTwo.startAnimation(star_one_anim);
        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                rlStarTwoLayout.setVisibility(View.INVISIBLE);
                ivStarTwo.setVisibility(View.INVISIBLE);
                ivStarTwo.clearAnimation();
                startNextBut_anim();
            }
        }, 4000L);
    }

    public void lovely_anim() {
        textToSpeech.speak("Awesome", 0, null);
    }

    public void mindblowing_anim() {
        textToSpeech.setSpeechRate(1.0f);
        textToSpeech.speak("Mind Blowing", 0, null);
        makeAnimationInvisible();
        rlMindBlowingLayout.setVisibility(View.VISIBLE);
        ivMindBlowing.setVisibility(View.VISIBLE);
        ivMindBlowing.startAnimation(great1_anim);
        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                rlMindBlowingLayout.setVisibility(View.INVISIBLE);
                ivMindBlowing.setVisibility(View.INVISIBLE);
                ivMindBlowing.clearAnimation();
                startNextBut_anim();
            }
        }, 4000L);
    }

    public void changeCustomView(int i) {
        rlCustomLayout = (RelativeLayout) findViewById(R.id.rlCustomLayout);
        if (category.equals("123")) {
            switch (i) {
                case 1:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("ZERO", 0, null);
                    currentString = "ZERO";
                    tempValue = 1;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_zero);
                    genericfuntion(requiredBitmap);
                    return;
                case 2:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("ONE", 0, null);
                    currentString = "ONE";
                    tempValue = 2;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_one);
                    genericfuntion(requiredBitmap);
                    return;
                case 3:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("TWO", 0, null);
                    currentString = "TWO";
                    tempValue = 3;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_two);
                    genericfuntion(requiredBitmap);
                    return;
                case 4:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("THREE", 0, null);
                    currentString = "THREE";
                    tempValue = 4;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_three);
                    genericfuntion(requiredBitmap);
                    return;
                case 5:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("FOUR", 0, null);
                    currentString = "FOUR";
                    tempValue = 5;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_four);
                    genericfuntion(requiredBitmap);
                    return;
                case 6:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("FIVE", 0, null);
                    currentString = "FIVE";
                    tempValue = 6;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_five);
                    genericfuntion(requiredBitmap);
                    return;
                case 7:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("SIX", 0, null);
                    currentString = "SIX";
                    tempValue = 7;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_six);
                    genericfuntion(requiredBitmap);
                    return;
                case 8:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("SEVEN", 0, null);
                    currentString = "SEVEN";
                    tempValue = 8;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_seven);
                    genericfuntion(requiredBitmap);
                    return;
                case 9:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("EIGHT", 0, null);
                    currentString = "EIGHT";
                    tempValue = 9;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_eight);
                    genericfuntion(requiredBitmap);
                    return;
                case 10:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("NINE", 0, null);
                    currentString = "NINE";
                    tempValue = 10;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_nine);
                    genericfuntion(requiredBitmap);
                    return;
                default:
                    return;
            }
        } else if (category.equals("ABC")) {
            switch (i) {
                case 1:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("A", 0, null);
                    currentString = "A";
                    tempValue = 1;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_a);
                    genericfuntion(requiredBitmap);
                    return;
                case 2:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("B", 0, null);
                    currentString = "B";
                    tempValue = 2;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_b);
                    genericfuntion(requiredBitmap);
                    return;
                case 3:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("C", 0, null);
                    currentString = "C";
                    tempValue = 3;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_c);
                    genericfuntion(requiredBitmap);
                    return;
                case 4:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("D", 0, null);
                    currentString = "D";
                    tempValue = 4;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_d);
                    genericfuntion(requiredBitmap);
                    return;
                case 5:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("E", 0, null);
                    currentString = "E";
                    tempValue = 5;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_e);
                    genericfuntion(requiredBitmap);
                    return;
                case 6:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("F", 0, null);
                    currentString = "F";
                    tempValue = 6;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_f);
                    genericfuntion(requiredBitmap);
                    return;
                case 7:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("G", 0, null);
                    currentString = "G";
                    tempValue = 7;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_g);
                    genericfuntion(requiredBitmap);
                    return;
                case 8:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("H", 0, null);
                    currentString = "H";
                    tempValue = 8;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_h);
                    genericfuntion(requiredBitmap);
                    return;
                case 9:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("I", 0, null);
                    currentString = "I";
                    tempValue = 9;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_i);
                    genericfuntion(requiredBitmap);
                    return;
                case 10:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("J", 0, null);
                    currentString = "J";
                    tempValue = 10;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_j);
                    genericfuntion(requiredBitmap);
                    return;
                case 11:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("K", 0, null);
                    currentString = "K";
                    tempValue = 11;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_k);
                    genericfuntion(requiredBitmap);
                    return;
                case 12:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("L", 0, null);
                    currentString = "L";
                    tempValue = 12;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_l);
                    genericfuntion(requiredBitmap);
                    return;
                case 13:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("M", 0, null);
                    currentString = "M";
                    tempValue = 13;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_m);
                    genericfuntion(requiredBitmap);
                    return;
                case 14:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("N", 0, null);
                    currentString = "N";
                    tempValue = 14;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_n);
                    genericfuntion(requiredBitmap);
                    return;
                case 15:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("O", 0, null);
                    currentString = "O";
                    tempValue = 15;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_o);
                    genericfuntion(requiredBitmap);
                    return;
                case 16:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("P", 0, null);
                    currentString = "P";
                    tempValue = 16;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_p);
                    genericfuntion(requiredBitmap);
                    return;
                case 17:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("Q", 0, null);
                    currentString = "Q";
                    tempValue = 17;
                    genericfuntion(BitmapFactory.decodeResource(getResources(), R.drawable.ic_q));
                    return;
                case 18:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("R", 0, null);
                    currentString = "R";
                    tempValue = 18;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_r);
                    genericfuntion(requiredBitmap);
                    return;
                case 19:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("S", 0, null);
                    currentString = "S";
                    tempValue = 19;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_s);
                    genericfuntion(requiredBitmap);
                    return;
                case 20:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("T", 0, null);
                    currentString = "T";
                    tempValue = 20;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_t);
                    genericfuntion(requiredBitmap);
                    return;
                case 21:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("U", 0, null);
                    currentString = "U";
                    tempValue = 21;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_u);
                    genericfuntion(requiredBitmap);
                    return;
                case 22:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("V", 0, null);
                    currentString = "V";
                    tempValue = 22;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_v);
                    genericfuntion(requiredBitmap);
                    return;
                case 23:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("W", 0, null);
                    currentString = "W";
                    tempValue = 23;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_w);
                    genericfuntion(requiredBitmap);
                    return;
                case 24:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("X", 0, null);
                    currentString = "X";
                    tempValue = 24;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_x);
                    genericfuntion(requiredBitmap);
                    return;
                case 25:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("Y", 0, null);
                    currentString = "Y";
                    tempValue = 25;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_y);
                    genericfuntion(requiredBitmap);
                    return;
                case 26:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("Z", 0, null);
                    currentString = "Z";
                    tempValue = 26;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_z);
                    genericfuntion(requiredBitmap);
                    return;
                default:
                    return;
            }
        } else if (category.equals("Patterns")) {
            switch (i) {
                case 1:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("STANDING LINE", 0, null);
                    currentString = "STANDING LINE";
                    tempValue = 1;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_shape_1);
                    genericfuntion(requiredBitmap);
                    return;
                case 2:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("SLEEPING LINE", 0, null);
                    currentString = "SLEEPING LINE";
                    tempValue = 2;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_shape_2);
                    genericfuntion(requiredBitmap);
                    return;
                case 3:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("SLANTING LINE", 0, null);
                    currentString = "SLANTING LINE";
                    tempValue = 3;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_shape_3);
                    genericfuntion(requiredBitmap);
                    return;
                case 4:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("SLANTING LINE", 0, null);
                    currentString = "SLANTING LINE";
                    tempValue = 4;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_shape_4);
                    genericfuntion(requiredBitmap);
                    return;
                case 5:
                    textToSpeech.setSpeechRate(1.0f);
                    textToSpeech.speak("JOIN THE SLANTING LINES", 0, null);
                    currentString = "JOIN THE SLANTING LINES";
                    tempValue = 5;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_shape_5);
                    genericfuntion(requiredBitmap);
                    return;
                case 6:
                    textToSpeech.setSpeechRate(1.0f);
                    textToSpeech.speak("JOIN THE SLANTING LINES", 0, null);
                    currentString = "JOIN THE SLANTING LINES";
                    tempValue = 6;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_shape_6);
                    genericfuntion(requiredBitmap);
                    return;
                case 7:
                    textToSpeech.setSpeechRate(1.0f);
                    textToSpeech.speak("JOIN THE SLANTING LINES FOR LETTER V", 0, null);
                    currentString = "JOIN THE SLANTING LINES FOR LETTER V";
                    tempValue = 7;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_shape_7);
                    genericfuntion(requiredBitmap);
                    return;
                case 8:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("SEMI CURVE", 0, null);
                    currentString = "SEMI CURVE";
                    tempValue = 8;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_shape_8);
                    genericfuntion(requiredBitmap);
                    return;
                case 9:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("SEMI CURVE", 0, null);
                    currentString = "SEMI CURVE";
                    tempValue = 9;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_shape_9);
                    genericfuntion(requiredBitmap);
                    return;
                case 10:
                    textToSpeech.setSpeechRate(1.0f);
                    textToSpeech.speak("LEFT CURVE FOR LETTER C", 0, null);
                    currentString = "LEFT CURVE FOR LETTER C";
                    tempValue = 10;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_shape_10);
                    genericfuntion(requiredBitmap);
                    return;
                case 11:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("RIGHT CURVE", 0, null);
                    currentString = "RIGHT CURVE";
                    tempValue = 11;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_shape_11);
                    genericfuntion(requiredBitmap);
                    return;
                case 12:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("CURVE", 0, null);
                    currentString = "CURVE";
                    tempValue = 12;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_shape_12);
                    genericfuntion(requiredBitmap);
                    return;
                case 13:
                    textToSpeech.setSpeechRate(1.0f);
                    textToSpeech.speak("CURVE FOR LETTER U", 0, null);
                    currentString = "CURVE FOR LETTER U";
                    tempValue = 13;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_shape_13);
                    genericfuntion(requiredBitmap);
                    return;
                case 14:
                    textToSpeech.setSpeechRate(1.0f);
                    textToSpeech.speak("JOIN THE DOTS FOR LETTER O", 0, null);
                    currentString = "JOIN THE DOTS FOR LETTER O";
                    tempValue = 14;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_shape_15);
                    genericfuntion(requiredBitmap);
                    return;
                case 15:
                    textToSpeech.setSpeechRate(1.0f);
                    textToSpeech.speak("JOIN TWO CURVES FOR LETTER S", 0, null);
                    currentString = "JOIN TWO CURVES FOR LETTER S";
                    tempValue = 15;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_shape_16);
                    genericfuntion(requiredBitmap);
                    return;
                case 16:
                    textToSpeech.setSpeechRate(1.0f);
                    textToSpeech.speak("JOIN THE DOTS FOR TICK MARK", 0, null);
                    currentString = "JOIN THE DOTS FOR TICK MARK";
                    tempValue = 16;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_shape_18);
                    genericfuntion(requiredBitmap);
                    return;
                default:
                    return;
            }
        } else if (category.equals("Shapes")) {
            switch (i) {
                case 1:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("SQUARE", 0, null);
                    currentString = "SQUARE";
                    tempValue = 1;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_square);
                    genericfuntion(requiredBitmap);
                    return;
                case 2:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("RECTANGLE", 0, null);
                    currentString = "RECTANGLE";
                    tempValue = 2;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_rectangle);
                    genericfuntion(requiredBitmap);
                    return;
                case 3:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("TRIANGLE", 0, null);
                    currentString = "TRIANGLE";
                    tempValue = 3;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_triangle);
                    genericfuntion(requiredBitmap);
                    return;
                case 4:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("CIRCLE", 0, null);
                    currentString = "CIRCLE";
                    tempValue = 4;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_circle);
                    genericfuntion(requiredBitmap);
                    return;
                case 5:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("OVAL", 0, null);
                    currentString = "OVAL";
                    tempValue = 5;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_ellipse);
                    genericfuntion(requiredBitmap);
                    return;
                case 6:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("DIAMOND", 0, null);
                    currentString = "DIAMOND";
                    tempValue = 6;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_rhombus);
                    genericfuntion(requiredBitmap);
                    return;
                case 7:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("STAR", 0, null);
                    currentString = "STAR";
                    tempValue = 7;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_star1);
                    genericfuntion(requiredBitmap);
                    return;
                case 8:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("PENTAGON", 0, null);
                    currentString = "PENTAGON";
                    tempValue = 8;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_pentagon);
                    genericfuntion(requiredBitmap);
                    return;
                case 9:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("HEXAGON", 0, null);
                    currentString = "HEXAGON";
                    tempValue = 9;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_hexagon);
                    genericfuntion(requiredBitmap);
                    return;
                case 10:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("OCTAGON", 0, null);
                    currentString = "OCTAGON";
                    tempValue = 10;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_octagon);
                    genericfuntion(requiredBitmap);
                    return;
                case 11:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("DECAGON", 0, null);
                    currentString = "DECAGON";
                    tempValue = 11;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_decagon);
                    genericfuntion(requiredBitmap);
                    return;
                case 12:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("PARALLELOGRAM", 0, null);
                    currentString = "PARALLELOGRAM";
                    tempValue = 12;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_parallelogram);
                    genericfuntion(requiredBitmap);
                    return;
                case 13:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("TRAPEZIUM", 0, null);
                    currentString = "TRAPEZIUM";
                    tempValue = 13;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_trapezium);
                    genericfuntion(requiredBitmap);
                    return;
                case 14:
                    textToSpeech.setSpeechRate(0.01f);
                    textToSpeech.speak("CRESCENT", 0, null);
                    currentString = "CRESCENT";
                    tempValue = 14;
                    requiredBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_crescent);
                    genericfuntion(requiredBitmap);
                    return;
                default:
                    return;
            }
        }
    }


    public void genericfuntion(Bitmap bitmap) {
        drawingView = new ABCKidsDrawingView(this, bitmap, colorCode);
        rlCustomLayout.removeAllViewsInLayout();
        rlCustomLayout.addView(drawingView);
    }

    public void clearAnimation() {
        ibPencil1.clearAnimation();
        ibPencil2.clearAnimation();
        ibPencil3.clearAnimation();
        ibHome.clearAnimation();
        ibRefresh.clearAnimation();
        ivVolume.clearAnimation();
    }

    public void isClickable() {
        ibBack.setClickable(false);
        ibNext.setClickable(false);
        ibMusic.setClickable(false);
        ibPencil1.setClickable(false);
        ibPencil2.setClickable(false);
        ibPencil3.setClickable(false);
        ibHome.setClickable(false);
        ibRefresh.setClickable(false);
        ivVolume.setClickable(false);
    }

    public void isClickableTrue() {
        ibBack.setClickable(true);
        ibNext.setClickable(true);
        ibMusic.setClickable(true);
        ibPencil1.setClickable(true);
        ibPencil2.setClickable(true);
        ibPencil3.setClickable(true);
        ibHome.setClickable(true);
        ibRefresh.setClickable(true);
        ivVolume.setClickable(true);
    }

    public void textStart() {
        textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                if (i != -1) {
                    textToSpeech.setLanguage(Locale.CANADA);
                    firstcall();
                }
            }
        });
    }

    public void textStop() {
        if (textToSpeech != null) {
            textToSpeech.stop();
        }
    }

    public void displayObjects_CorrectAns() {
        if (correctAnsrTemp >= 6) {
            correctAnsrTemp = 0;
        }
        int i = correctAnsrTemp;
        if (i == 0) {
            star_one_anim();
        } else if (i == 1) {
            great1_anim();
        } else if (i == 2) {
            stars_two();
        } else if (i == 3) {
            mindblowing_anim();
        } else if (i == 4) {
            stars_great();
        } else if (i != 5) {
        } else {
            great1_anim();
        }
    }

    public void stopAnimation() {
        givThinking.clearAnimation();
        givNoWrong.clearAnimation();
        ivGreat1.clearAnimation();
        ivMindBlowing.clearAnimation();
        ivStarThree.clearAnimation();
        ivStarOne.clearAnimation();
        ibPencil1.clearAnimation();
        ibPencil2.clearAnimation();
        ibPencil3.clearAnimation();
        ibMusic.clearAnimation();
        ibHome.clearAnimation();
        ibRefresh.clearAnimation();
        ivVolume.clearAnimation();
        ibNext.clearAnimation();
    }

    @Override
    protected void onPause() {
        if (textToSpeech != null) {
            try {
                textToSpeech.stop();
                textToSpeech.shutdown();
            } catch (Exception unused) {
            }
        }
        correct_answer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                mediaPlayer.release();
            }
        });
        Handler handler = handler1;
        if (handler != null) {
            handler.removeMessages(0);
        }
        Handler handler2 = handler;
        if (handler2 != null) {
            handler2.removeMessages(0);
        }
        GifImageView gifImageView = givThinking;
        if (gifImageView != null) {
            gifImageView.clearAnimation();
            rlGif.setVisibility(View.INVISIBLE);
        }
        GifImageView gifImageView2 = givNoWrong;
        if (gifImageView2 != null) {
            gifImageView2.clearAnimation();
            rlGifNo.setVisibility(View.INVISIBLE);
        }
        rlStarOneLayout.setVisibility(View.INVISIBLE);
        ivStarOne.setVisibility(View.INVISIBLE);
        ivStarOne.clearAnimation();
        rlGreat1Layout.setVisibility(View.INVISIBLE);
        ivGreat1.setVisibility(View.INVISIBLE);
        ivGreat1.clearAnimation();
        rlStarTwoLayout.setVisibility(View.INVISIBLE);
        ivStarTwo.setVisibility(View.INVISIBLE);
        ivStarTwo.clearAnimation();
        rlMindBlowingLayout.setVisibility(View.INVISIBLE);
        ivMindBlowing.setVisibility(View.INVISIBLE);
        ivMindBlowing.clearAnimation();
        rlStarThreeLayout.setVisibility(View.INVISIBLE);
        ivStarThree.setVisibility(View.INVISIBLE);
        ivStarThree.clearAnimation();
        isonpause = false;
        try {
            stopService(new Intent(this, ABCKidsSoundService.class));
        } catch (Exception unused2) {
        }
        System.out.println("^^^^^ on pause");
        super.onPause();
    }

    @Override
    protected void onResume() {
        textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                if (i != -1) {
                    textToSpeech.setLanguage(Locale.CANADA);
                }
            }
        });
        ibNext.setVisibility(View.VISIBLE);
        ibNext.startAnimation(next_but_anim);
        isClickableTrue();
        isonpause = true;
        try {
            if (ABCKidsStoreData.ismute) {
                ABCKidsSoundService.pauseService();
            } else {
                startService(new Intent(this, ABCKidsSoundService.class));
            }
        } catch (Exception unused) {
        }
        super.onResume();
        AdShow.getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }

    public boolean isApplicationSentToBackground(Context context) {
        try {
            List<ActivityManager.RunningTaskInfo> runningTasks = ((ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE)).getRunningTasks(1);
            if (!runningTasks.isEmpty()) {
                if (!runningTasks.get(0).topActivity.getPackageName().equals(context.getPackageName())) {
                    return true;
                }
            }
        } catch (Exception unused) {
        }
        return false;
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        if (rlGif.getVisibility() == View.VISIBLE) {
            rlGif.setVisibility(View.INVISIBLE);
            if (textToSpeech != null) {
                textToSpeech.stop();
                textToSpeech.shutdown();
            }
            MediaPlayer mediaPlayer = wrong_answer;
            if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                wrong_answer.stop();
                wrong_answer.reset();
            }
            MediaPlayer mediaPlayer2 = correct_answer;
            if (mediaPlayer2 != null && mediaPlayer2.isPlaying()) {
                correct_answer.stop();
                correct_answer.reset();
            }
            setResult(3);
            return;
        }
        if (!isApplicationSentToBackground(this)) {
            isInSameActivity_add = false;
            finish();
        }
        isInSameActivity_add = false;
        finish();
    }

    @Override
    protected void onDestroy() {
        stopAnimation();
        isInSameActivity_add = false;
        handler.removeMessages(0);
        Bitmap bitmap = requiredBitmap;
        if (bitmap != null) {
            bitmap.recycle();
        }

        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        GifImageView gifImageView = givThinking;
        if (gifImageView != null) {
            gifImageView.clearAnimation();
        }
        GifImageView gifImageView2 = givNoWrong;
        if (gifImageView2 != null) {
            gifImageView2.clearAnimation();
        }
        System.out.println("###################### ondestroy main");
        deleteCache(this);
        Runtime.getRuntime().runFinalization();
        Runtime.getRuntime().gc();
        super.onDestroy();
    }

    public static void deleteCache(Context context) {
        try {
            deleteDir(context.getCacheDir());
        } catch (Exception unused) {
        }
    }

    private boolean isMyServiceRunning(Class<?> cls) {
        for (ActivityManager.RunningServiceInfo runningServiceInfo : ((ActivityManager) getSystemService(Context.ACTIVITY_SERVICE)).getRunningServices(4)) {
            if (cls.getName().equals(runningServiceInfo.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public static boolean deleteDir(File file) {
        if (file != null && file.isDirectory()) {
            for (String str : file.list()) {
                if (!deleteDir(new File(file, str))) {
                    return false;
                }
            }
            return file.delete();
        } else if (file == null || !file.isFile()) {
            return false;
        } else {
            return file.delete();
        }
    }

    public Bitmap resizeImageToNewSize(Bitmap bitmap, int i, int i2) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        float f = i;
        float f2 = i2;
        if (height != i2 || width != i) {
            float f3 = width;
            float f4 = f / f3;
            float f5 = height;
            float f6 = f2 / f5;
            if (f4 < f6) {
                f6 = f4;
            }
            f = f3 * f6;
            f2 = f5 * f6;
        }
        return Bitmap.createScaledBitmap(bitmap, (int) f, (int) f2, true);
    }


    private class AsyncCaller extends AsyncTask<Void, Void, Void> {
        private AsyncCaller() {
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            PrintStream printStream = System.out;
            printStream.println("~~~~~ pixel value pre execute" + ABCKidsApplicationClass.pixelValue);
        }


        @Override
        public Void doInBackground(Void... voidArr) {
            PrintStream printStream = System.out;
            printStream.println("~~~~~ pixel value do in background" + ABCKidsApplicationClass.pixelValue);
            return null;
        }


        @Override
        public void onPostExecute(Void r7) {
            super.onPostExecute(r7);
            rlGif.setVisibility(View.INVISIBLE);
            PrintStream printStream = System.out;
            printStream.println("~~~~~ pixel value post execute " + ABCKidsApplicationClass.pixelValue);
            if (ABCKidsApplicationClass.pixelValue == 0.0f) {
                PrintStream printStream2 = System.out;
                printStream2.println("~~~~~ MyApplicationClass.pixelValue if " + ABCKidsApplicationClass.pixelValue);
                ABCKidsTraceLayout traceLayout = ABCKidsTraceLayout.this;
                traceLayout.bgMusic_playing = false;
                traceLayout.correct_answer = MediaPlayer.create(traceLayout, (int) R.raw.raw_correct_ans);
                correct_answer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    @Override
                    public void onPrepared(MediaPlayer mediaPlayer) {
                        mediaPlayer.start();
                    }
                });
                correct_answer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mediaPlayer) {
                        mediaPlayer.release();
                    }
                });
                ABCKidsTraceLayout traceLayout2 = ABCKidsTraceLayout.this;
                traceLayout2.iscirrectPlaying = true;
                traceLayout2.handler1 = new Handler();
                handler1.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        correctAnsrTemp++;
                        displayObjects_CorrectAns();
                    }
                }, 500L);
                handler1 = new Handler();
                handler1.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        switch (tempValue) {
                            case 1:
                                changeCustomView(2);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 2:
                                changeCustomView(3);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 3:
                                changeCustomView(4);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 4:
                                changeCustomView(5);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 5:
                                changeCustomView(6);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 6:
                                changeCustomView(7);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 7:
                                changeCustomView(8);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 8:
                                changeCustomView(9);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 9:
                                changeCustomView(10);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 10:
                                if (category.equals("123")) {
                                    changeCustomView(1);
                                } else {
                                    changeCustomView(11);
                                }
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 11:
                                changeCustomView(12);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 12:
                                changeCustomView(13);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 13:
                                changeCustomView(14);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 14:
                                if (category.equals("Shapes")) {
                                    changeCustomView(1);
                                } else {
                                    changeCustomView(15);
                                }
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 15:
                                changeCustomView(16);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 16:
                                if (category.equals("Patterns")) {
                                    changeCustomView(1);
                                } else {
                                    changeCustomView(17);
                                }
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 17:
                                changeCustomView(18);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 18:
                                changeCustomView(19);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 19:
                                changeCustomView(20);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 20:
                                changeCustomView(21);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 21:
                                changeCustomView(22);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 22:
                                changeCustomView(23);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 23:
                                changeCustomView(24);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 24:
                                changeCustomView(25);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 25:
                                changeCustomView(26);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            case 26:
                                changeCustomView(1);
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                            default:
                                ABCKidsApplicationClass.pixelValue = 1.0f;
                                return;
                        }
                    }
                }, 4000L);
            } else {
                PrintStream printStream3 = System.out;
                printStream3.println("~~~~~ MyApplicationClass.pixelValue else" + ABCKidsApplicationClass.pixelValue);
                ABCKidsTraceLayout traceLayout3 = ABCKidsTraceLayout.this;
                traceLayout3.wrong_answer = MediaPlayer.create(traceLayout3, (int) R.raw.raw_wrong_ans);
                wrong_answer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    @Override
                    public void onPrepared(MediaPlayer mediaPlayer) {
                        mediaPlayer.start();
                    }
                });
                wrong_answer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mediaPlayer) {
                        mediaPlayer.release();
                    }
                });
                handler1 = new Handler();
                handler1.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        setTry_again();
                    }
                }, 500L);
            }
            handler1 = new Handler();
            handler1.postDelayed(new Runnable() {
                @Override
                public void run() {
                    ibNext.setVisibility(View.VISIBLE);
                    ibNext.startAnimation(next_but_anim);
                    isClickableTrue();
                }
            }, 4000L);
        }
    }

    public void setVolume(View view) {
        if (full_volume) {
            ABCKidsStoreData.ismute = true;
            ivVolume.setImageResource(R.drawable.ic_mute);
            bgMusic_playing = true;
            ABCKidsStoreData.isPlaying = false;
            try {
                ABCKidsSoundService.playerSound(0.0f);
            } catch (Exception unused) {
            }
            PrintStream printStream = System.out;
            printStream.println(" if1 $$$$$$$$$$$$$$$ bgsound " + ABCKidsStoreData.bgSound);
            full_volume = false;
            return;
        }
        ABCKidsStoreData.ismute = false;
        startService(new Intent(this, ABCKidsSoundService.class));
        ivVolume.setImageResource(R.drawable.ic_volume);
        PrintStream printStream2 = System.out;
        printStream2.println("else1 $$$$$$$$$$$$$$$ bgsound " + ABCKidsStoreData.bgSound);
        bgMusic_playing = true;
        ABCKidsStoreData.isPlaying = true;
        if (ABCKidsStoreData.bgSound == 0.0f) {
            ABCKidsStoreData.bgSound = 0.8f;
            ABCKidsStoreData.temp_sound = 0.8f;
            ABCKidsStoreData.seekbar_progress = 80;
            ABCKidsSoundService.playerSound(ABCKidsStoreData.bgSound);
            PrintStream printStream3 = System.out;
            printStream3.println("if2 $$$$$$$$$$$$$$$ bgsound " + ABCKidsStoreData.bgSound);
        } else {
            PrintStream printStream4 = System.out;
            printStream4.println("else2 $$$$$$$$$$$$$$$ bgsound " + ABCKidsStoreData.bgSound);
            try {
                ABCKidsSoundService.playerSound(ABCKidsStoreData.bgSound);
            } catch (Exception unused2) {
            }
        }
        full_volume = true;
    }

    public boolean isConnectingToInternet() {
        NetworkInfo[] allNetworkInfo;
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager != null && (allNetworkInfo = connectivityManager.getAllNetworkInfo()) != null) {
            for (NetworkInfo networkInfo : allNetworkInfo) {
                if (networkInfo.getState() == NetworkInfo.State.CONNECTED) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    protected void onStop() {
        System.out.println("^^^^^ on stop");
        super.onStop();
    }
}
