package com.kidslearn.tracing.phonics;

import android.view.animation.Interpolator;


public class ABCKidsBounceInterpolator implements Interpolator {
    private double mAmplitude;
    private double mFrequency;

    ABCKidsBounceInterpolator(double d, double d2) {
        this.mAmplitude = d;
        this.mFrequency = d2;
    }

    @Override
    public float getInterpolation(float f) {
        double d = -f;
        double d2 = this.mAmplitude;
        Double.isNaN(d);
        double d3 = this.mFrequency;
        double d4 = f;
        Double.isNaN(d4);
        return (float) ((Math.pow(2.718281828459045d, d / d2) * (-1.0d) * Math.cos(d3 * d4)) + 1.0d);
    }
}
