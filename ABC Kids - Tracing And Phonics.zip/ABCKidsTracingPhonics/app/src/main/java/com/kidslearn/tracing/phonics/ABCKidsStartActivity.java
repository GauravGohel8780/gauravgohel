package com.kidslearn.tracing.phonics;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import com.iten.tenoku.ad.AdShow;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.kidslearn.tracing.phonics.Ads_Common.AdsBaseActivity;

import java.io.File;
import java.io.PrintStream;


public class ABCKidsStartActivity extends AdsBaseActivity {
    ImageView ivParachute, ivBaloon1, ivBaloon10, ivBaloon11, ivBaloon12, ivBaloon13, ivBaloon2, ivBaloon3, ivBaloon4, ivBaloon5, ivBaloon6, ivBaloon7, ivBaloon8, ivBaloon9, ivCloude1, ivCloude2, ivCloude3, ivCloude4, ivCloude5;
    Animation BaloonLayoutFourAnim, BaloonLayoutOneAnim, BaloonLayoutThreeAnim, BaloonLayoutTwoAnim, ButtonClickAnim, Cloude1Anim, Cloude2Anim, anPlayAnim;
    MediaPlayer button_selection;
    Handler handler;
    RelativeLayout rlMain, rlSettingsRel;
    Bitmap pbit;
    ImageButton ibStartPlay, ibSettings;
    SeekBar sbBgSounds;
    Button btnSettingPlay;
    float volume;
    int width, height;
    boolean isFirstPlaying = false;
    boolean isInseetings = false;

    @Override

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        SetSystemFullScreen();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (!isTaskRoot() && getIntent().hasCategory("android.intent.category.LAUNCHER") && getIntent().getAction() != null && getIntent().getAction().equals("android.intent.action.MAIN")) {
            finish();
            return;
        }
        setContentView(R.layout.activity_start_activity);
        rlMain = (RelativeLayout) findViewById(R.id.rlMain);
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        width = displayMetrics.widthPixels;
        height = displayMetrics.heightPixels;

        Bitmap decodeResource = BitmapFactory.decodeResource(getResources(), R.drawable.ic_screen_4);
        pbit = BitmapFactory.decodeResource(getResources(), R.drawable.ic_asset20);
        Bitmap resizeImageToNewSize = resizeImageToNewSize(decodeResource, width, height);
        pbit = resizeImageToNewSize(pbit, width, height);
        rlMain.setBackground(new BitmapDrawable(getResources(), resizeImageToNewSize));
        ibSettings = (ImageButton) findViewById(R.id.ibSettings);
        rlSettingsRel = (RelativeLayout) findViewById(R.id.rlSettingsRel);
        btnSettingPlay = (Button) findViewById(R.id.btnSettingPlay);
        sbBgSounds = (SeekBar) findViewById(R.id.sbBgSounds);
        ibStartPlay = (ImageButton) findViewById(R.id.ibStartPlay);
        button_selection = MediaPlayer.create(this, (int) R.raw.raw_button_selection);
        ButtonClickAnim = AnimationUtils.loadAnimation(this, R.anim.anim_effect);
        ButtonClickAnim.setInterpolator(new ABCKidsBounceInterpolator(0.2d, 20.0d));
        ABCKidsStoreData.isPlaying = true;
        ivCloude1 = (ImageView) findViewById(R.id.ivCloude1);
        ivCloude2 = (ImageView) findViewById(R.id.ivCloude2);
        ivCloude3 = (ImageView) findViewById(R.id.ivCloude3);
        ivCloude4 = (ImageView) findViewById(R.id.ivCloude4);
        ivCloude5 = (ImageView) findViewById(R.id.ivCloude5);
        ivBaloon1 = (ImageView) findViewById(R.id.ivBaloon1);
        ivBaloon2 = (ImageView) findViewById(R.id.ivBaloon2);
        ivBaloon3 = (ImageView) findViewById(R.id.ivBaloon3);
        ivBaloon4 = (ImageView) findViewById(R.id.ivBaloon4);
        ivBaloon5 = (ImageView) findViewById(R.id.ivBaloon5);
        ivBaloon6 = (ImageView) findViewById(R.id.ivBaloon6);
        ivBaloon7 = (ImageView) findViewById(R.id.ivBaloon7);
        ivBaloon8 = (ImageView) findViewById(R.id.ivBaloon8);
        ivBaloon9 = (ImageView) findViewById(R.id.ivBaloon9);
        ivBaloon10 = (ImageView) findViewById(R.id.ivBaloon10);
        ivBaloon11 = (ImageView) findViewById(R.id.ivBaloon11);
        ivBaloon12 = (ImageView) findViewById(R.id.ivBaloon12);
        ivBaloon13 = (ImageView) findViewById(R.id.ivBaloon13);
        ivParachute = (ImageView) findViewById(R.id.ivParachute);
        ivParachute.setImageBitmap(pbit);
        Cloude1Anim = AnimationUtils.loadAnimation(this, R.anim.anim_clouds);
        Cloude2Anim = AnimationUtils.loadAnimation(this, R.anim.anim_cloud2);
        BaloonLayoutOneAnim = AnimationUtils.loadAnimation(this, R.anim.anim_onebaloon);
        BaloonLayoutTwoAnim = AnimationUtils.loadAnimation(this, R.anim.anim_twobaloon);
        BaloonLayoutThreeAnim = AnimationUtils.loadAnimation(this, R.anim.anim_threebaloon);
        BaloonLayoutFourAnim = AnimationUtils.loadAnimation(this, R.anim.anim_fourbaloon);
        anPlayAnim = AnimationUtils.loadAnimation(this, R.anim.anim_heartpulseanimation);
        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ibStartPlay.startAnimation(anPlayAnim);
                ivCloude1.setVisibility(View.VISIBLE);
                ivCloude1.startAnimation(Cloude1Anim);
                ivCloude3.setVisibility(View.VISIBLE);
                ivCloude3.startAnimation(Cloude1Anim);
                ivBaloon1.startAnimation(BaloonLayoutOneAnim);
                ivBaloon6.startAnimation(BaloonLayoutOneAnim);
                ivBaloon3.startAnimation(BaloonLayoutTwoAnim);
                ivBaloon4.startAnimation(BaloonLayoutThreeAnim);
                ivBaloon7.startAnimation(BaloonLayoutFourAnim);
            }
        }, 200L);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ivCloude2.setVisibility(View.VISIBLE);
                ivCloude2.startAnimation(Cloude2Anim);
                ivCloude4.setVisibility(View.VISIBLE);
                ivCloude4.startAnimation(Cloude1Anim);
                ivCloude5.setVisibility(View.VISIBLE);
                ivCloude5.startAnimation(Cloude2Anim);
                ivBaloon2.startAnimation(BaloonLayoutOneAnim);
                ivBaloon5.startAnimation(BaloonLayoutTwoAnim);
                ivBaloon8.startAnimation(BaloonLayoutThreeAnim);
                ivBaloon9.startAnimation(BaloonLayoutFourAnim);
            }
        }, 1000L);
        if (!ServiceRunning(ABCKidsSoundService.class)) {
            System.out.println("ismyservirunning true");
            try {
                startService(new Intent(this, ABCKidsSoundService.class));
            } catch (Exception unused) {
            }
        }
        ibStartPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdShow.getInstance(ABCKidsStartActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        button_selection.start();
                        ABCKidsStartActivity launchScreen = ABCKidsStartActivity.this;
                        launchScreen.isFirstPlaying = true;
                        startActivityForResult(new Intent(launchScreen, ABCKidsMainActivity.class), 2);
                    }
                }, AdUtils.ClickType.MAIN_CLICK);
            }
        });
        ibSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdShow.getInstance(ABCKidsStartActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        ibSettings.startAnimation(ButtonClickAnim);
                        button_selection.start();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                rlSettingsRel.setVisibility(View.VISIBLE);
                                ibStartPlay.setClickable(false);
                                ibSettings.setClickable(false);
                            }
                        }, 500L);
                        isInseetings = true;
                    }
                }, AdUtils.ClickType.MAIN_CLICK);
            }
        });
        btnSettingPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                button_selection.start();
                rlSettingsRel.setVisibility(View.INVISIBLE);
                ABCKidsStoreData.bgSound = volume;
                ibStartPlay.setClickable(true);
                ibSettings.setClickable(true);
            }
        });
        sbBgSounds.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                volume = (float) (1.0d - (Math.log(100 - i) / Math.log(100.0d)));
                PrintStream printStream = System.out;
                printStream.println("########### progress " + i);
                ABCKidsStoreData.bgSound = volume;
                PrintStream printStream2 = System.out;
                printStream2.println("########### sound " + volume);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                ABCKidsSoundService.playerSound(ABCKidsStoreData.bgSound);
                ABCKidsStoreData.isPlaying = true;
                ABCKidsStoreData.seekbar_progress = 0;
            }
        });

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                AdShow.getInstance(ABCKidsStartActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        if (isInseetings) {
                            isInseetings = false;
                            rlSettingsRel.setVisibility(View.INVISIBLE);
                            ibStartPlay.setClickable(true);
                            ibSettings.setClickable(true);
                        }else {
                            startActivity(new Intent(ABCKidsStartActivity.this, ABCKidsExitActivity.class));
                        }
                    }
                }, AdUtils.ClickType.BACK_CLICK);
            }
        };

        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    public Bitmap resizeImageToNewSize(Bitmap bitmap, int i, int i2) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        float f = i;
        float f2 = i2;
        if (height != i2 || width != i) {
            float f3 = width;
            float f4 = f / f3;
            float f5 = height;
            float f6 = f2 / f5;
            if (f4 < f6) {
                f6 = f4;
            }
            f = f3 * f6;
            f2 = f5 * f6;
        }
        return Bitmap.createScaledBitmap(bitmap, (int) f, (int) f2, true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        AdShow.getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
        isFirstPlaying = false;
        try {
            if (ABCKidsStoreData.ismute) {
                ABCKidsSoundService.pauseService();
            } else {
                startService(new Intent(this, ABCKidsSoundService.class));
            }
        } catch (Exception unused) {
        }
        Bitmap decodeResource = BitmapFactory.decodeResource(getResources(), R.drawable.ic_screen_4);
        pbit = BitmapFactory.decodeResource(getResources(), R.drawable.ic_asset20);
        Bitmap resizeImageToNewSize = resizeImageToNewSize(decodeResource, width, height);
        pbit = resizeImageToNewSize(pbit, width, height);
        rlMain.setBackground(new BitmapDrawable(getResources(), resizeImageToNewSize));
        if (ABCKidsStoreData.seekbar_progress != 0) {
            sbBgSounds.setProgress(ABCKidsStoreData.seekbar_progress);
        }
    }

    @Override
    protected void onPause() {
        if (!isFirstPlaying) {
            try {
                ABCKidsSoundService.pauseService();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        super.onPause();
    }

    private boolean ServiceRunning(Class<?> cls) {
        for (ActivityManager.RunningServiceInfo runningServiceInfo : ((ActivityManager) getSystemService(Context.ACTIVITY_SERVICE)).getRunningServices(4)) {
            if (cls.getName().equals(runningServiceInfo.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public void stopAnimation() {
        ivCloude1.clearAnimation();
        ivCloude2.clearAnimation();
        ivCloude3.clearAnimation();
        ivCloude4.clearAnimation();
        ivCloude5.clearAnimation();
        ivBaloon1.clearAnimation();
        ivBaloon2.clearAnimation();
        ivBaloon3.clearAnimation();
        ivBaloon4.clearAnimation();
        ivBaloon5.clearAnimation();
        ivBaloon6.clearAnimation();
        ivBaloon7.clearAnimation();
        ivBaloon8.clearAnimation();
        ivBaloon9.clearAnimation();
        ibStartPlay.clearAnimation();
        ibSettings.clearAnimation();
    }

    @Override
    protected void onDestroy() {
        try {
            stopService(new Intent(this, ABCKidsSoundService.class));
        } catch (Exception unused) {
        }
        stopAnimation();
        handler.removeMessages(0);
        deleteCache(this);
        Runtime.getRuntime().runFinalization();
        Runtime.getRuntime().gc();
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        rlMain.setBackground(null);
        super.onStop();
    }

    public static void deleteCache(Context context) {
        try {
            deleteDir(context.getCacheDir());
        } catch (Exception unused) {

        }
    }

    public static boolean deleteDir(File file) {
        if (file != null && file.isDirectory()) {
            for (String str : file.list()) {
                if (!deleteDir(new File(file, str))) {
                    return false;
                }
            }
            return file.delete();
        } else if (file == null || !file.isFile()) {
            return false;
        } else {
            return file.delete();
        }
    }



    @Override
    protected void onActivityResult(int i, int i2, Intent intent) {
        if (i == 2 && i2 == 2) {
            rlMain.setBackground(new BitmapDrawable(getResources(), resizeImageToNewSize(BitmapFactory.decodeResource(getResources(), R.drawable.ic_screen_4), width, height)));
        }
        super.onActivityResult(i, i2, intent);
    }

    public void SetSystemFullScreen() {
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) {
            View v = getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }

}
