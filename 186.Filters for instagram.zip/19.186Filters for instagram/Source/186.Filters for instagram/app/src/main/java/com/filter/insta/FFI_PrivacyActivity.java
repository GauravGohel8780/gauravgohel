package com.filter.insta;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.MyApplication.sharedPreferencesHelper;

import android.os.Bundle;
import android.webkit.WebViewClient;

import com.filter.insta.Ads_Common.AdsBaseActivity;
import com.filter.insta.databinding.FfiActivityPrivacyBinding;
import com.iten.tenoku.model.ObjAPPSETTINGS;
import com.iten.tenoku.utils.AdUtils;

public class FFI_PrivacyActivity extends AdsBaseActivity {
    FfiActivityPrivacyBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = FfiActivityPrivacyBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        String Link = getIntent().getStringExtra("link");
        if (Link.equals("TremsCindition")){
            binding.web.loadUrl(new ObjAPPSETTINGS().getVPolicylink());
        }else if (Link.equals("Privacypolicy")){
            binding.web.loadUrl(sharedPreferencesHelper.getPrivacyPolicy());
        }

        binding.web.getSettings().setJavaScriptEnabled(true);

        binding.web.setWebViewClient(new WebViewClient());
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}