package com.filter.insta;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TextView;
import android.widget.Toast;

import com.filter.insta.Ads_Common.AdsBaseActivity;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class FFI_SettingActivity extends AdsBaseActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ffi_activity_setting);


        findViewById(R.id.llRateUs).setOnClickListener(v -> {
            Dialog dialog = new Dialog(FFI_SettingActivity.this, R.style.customDialog);
            dialog.setContentView(R.layout.ffi_dialog_rate_us);

            dialog.getWindow().setGravity(Gravity.CENTER);
            dialog.getWindow().setBackgroundDrawable(ContextCompat.getDrawable(FFI_SettingActivity.this, R.color.bg_app_20));

            dialog.getWindow().setStatusBarColor(ContextCompat.getColor(FFI_SettingActivity.this, R.color.bg_app_20));
            dialog.show();


            TextView tvDone = dialog.findViewById(R.id.btnDone);


            tvDone.setOnClickListener(view -> {
                dialog.dismiss();
                Uri uri = Uri.parse("market://details?id=" + getPackageName());
                Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
                try {
                    startActivity(myAppLinkToMarket);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(FFI_SettingActivity.this, " unable to find market app", Toast.LENGTH_LONG).show();
                }
            });
        });
        findViewById(R.id.llShareApp).setOnClickListener(v -> {
            try {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_SUBJECT, R.string.app_name);
                String shareMessage = "\nLet me recommend you this application\n\n";
                shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + getPackageName() + "\n\n";
                shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                startActivity(Intent.createChooser(shareIntent, "choose one"));
            } catch (Exception e) {

            }
        });
        findViewById(R.id.ivBack).setOnClickListener(v -> {
            getInstance(FFI_SettingActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });
        findViewById(R.id.llTremsCindition).setOnClickListener(v -> {
            getInstance(FFI_SettingActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    Intent intent = new Intent(FFI_SettingActivity.this, FFI_PrivacyActivity.class);
                    intent.putExtra("link", "TremsCindition");
                    startActivity(intent);
                    finish();
                }
            }, MAIN_CLICK);
        });
        findViewById(R.id.llPrivacypolicy).setOnClickListener(v -> {
            getInstance(FFI_SettingActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    Intent intent = new Intent(FFI_SettingActivity.this, FFI_PrivacyActivity.class);
                    intent.putExtra("link", "Privacypolicy");
                    startActivity(intent);
                    finish();
                }
            }, MAIN_CLICK);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BIG);
    }
}