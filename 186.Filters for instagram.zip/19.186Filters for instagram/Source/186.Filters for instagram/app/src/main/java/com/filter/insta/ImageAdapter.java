
package com.filter.insta;

import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.iten.tenoku.ad.AdShow;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.io.File;
import java.util.ArrayList;

public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.ImageViewHolder> {

    private Activity activity;
    private ArrayList<File> mImageFiles;

    public ImageAdapter(Activity context, ArrayList<File> imageFiles) {
        activity = context;
        mImageFiles = imageFiles;
    }

    @NonNull
    @Override
    public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(activity).inflate(R.layout.ffi_details_list_img, parent, false);
        return new ImageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ImageViewHolder holder, int position) {
        Glide.with(activity).load(mImageFiles.get(position)).into(holder.ivDetailsImg);


        holder.cvCardView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AdShow.getInstance(activity).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getItemId(position);
                        Intent intent = new Intent(activity, FFI_SaveActivity.class);
                        intent.putExtra("path", mImageFiles.get(position).getPath());
                        activity.startActivity(intent);
                    }
                }, MAIN_CLICK);

            }
        });

        holder.ivShareImgList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(activity);
                alertDialog.setTitle("Share File...");
                alertDialog.setMessage("Do you want to share this file?");
                alertDialog.setIcon(R.mipmap.ic_launcher);
                alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        shareImage("Filters for instagram" + " Created By : " + "https://play.google.com/store/apps/details?id=com.filter.insta", String.valueOf(mImageFiles.get(position)));
                    }
                });
                alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                alertDialog.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                alertDialog.show();
            }
        });


        holder.ivDeledtImgList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(activity);
                alertDialog.setTitle("Confirm Delete...");
                alertDialog.setMessage("Are you sure you want delete this?");
                alertDialog.setIcon(R.mipmap.ic_launcher);
                alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        File fD = new File(mImageFiles.get(position).toURI());
                        if (fD.exists()) {
                            fD.delete();
                        }
                        mImageFiles.remove(position);
                        notifyDataSetChanged();
                        if (mImageFiles.size() == 0) {
                            Toast.makeText(activity, "No Image Found..", Toast.LENGTH_LONG).show();
                        }
                    }
                });
                alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                alertDialog.show();
            }
        });


    }

    public void shareImage(final String title, String path) {
        MediaScannerConnection.scanFile(activity, new String[]{path}, null, new MediaScannerConnection.OnScanCompletedListener() {
            public void onScanCompleted(String path, Uri uri) {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("video/*");
                shareIntent.putExtra(Intent.EXTRA_TEXT, title);
                shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
                shareIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
                activity.startActivity(Intent.createChooser(shareIntent, "Share Video"));
            }
        });
    }

    @Override
    public int getItemCount() {
        return mImageFiles.size();
    }

    public static class ImageViewHolder extends RecyclerView.ViewHolder {
        CardView cvCardView1;
        ImageView ivDetailsImg, ivDeledtImgList, ivShareImgList;

        public ImageViewHolder(@NonNull View itemView) {
            super(itemView);
            cvCardView1 = itemView.findViewById(R.id.cvCardView1);
            ivDetailsImg = itemView.findViewById(R.id.ivDetailsImg);
            ivDeledtImgList = itemView.findViewById(R.id.ivDeledtImgList);
            ivShareImgList = itemView.findViewById(R.id.ivShareImgList);
        }


    }
}
