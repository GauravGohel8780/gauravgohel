package com.filter.insta.FFI_InroScreen;


public class FFI_ScreenItem {
    String Description;
    int ScreenImg;
    String Title;

    public FFI_ScreenItem(String str, String str2, int i) {
        this.Title = str;
        this.Description = str2;
        this.ScreenImg = i;
    }

    public void setTitle(String str) {
        this.Title = str;
    }

    public void setDescription(String str) {
        this.Description = str;
    }

    public void setScreenImg(int i) {
        this.ScreenImg = i;
    }

    public String getTitle() {
        return this.Title;
    }

    public String getDescription() {
        return this.Description;
    }

    public int getScreenImg() {
        return this.ScreenImg;
    }
}
