package com.filter.insta;

import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.filter.insta.Ads_Common.AdsBaseActivity;
import com.filter.insta.FFI_InroScreen.FFI_Intro_Activity;
import com.filter.insta.FFI_Tools.FFI_Constants;
import com.iten.tenoku.ad.AdShow;
import com.iten.tenoku.ad.HandleClick.HandleClick;


import java.io.File;
import java.io.PrintStream;

@SuppressWarnings("all")
public class FFI_SaveActivity extends AdsBaseActivity {
    Bitmap bitmap;
    Uri uri;
    ImageView facebook;
    ImageView insta;
    ImageView whatsup;
    ImageView share;
    ImageView mImageView;
    ImageView done;
    ImageView back;
    String s;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.ffi_save_activity);
        this.facebook = (ImageView) findViewById(R.id.ivFacebook);
        this.insta = (ImageView) findViewById(R.id.ivInsta);
        this.whatsup = (ImageView) findViewById(R.id.ivWhatsup);
        this.share = (ImageView) findViewById(R.id.ivShare);
        this.done = (ImageView) findViewById(R.id.ivDone);
        this.back = (ImageView) findViewById(R.id.ivBack);
        RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.rlFacebookll);
        RelativeLayout relativeLayout2 = (RelativeLayout) findViewById(R.id.rlInstall);
        RelativeLayout relativeLayout3 = (RelativeLayout) findViewById(R.id.rlWhatsupll);
        RelativeLayout relativeLayout4 = (RelativeLayout) findViewById(R.id.rlSharell);
        this.mImageView = (ImageView) findViewById(R.id.ivMain);
        Intent in = getIntent();
        BitmapFactory.Options option = new BitmapFactory.Options();
        option.inPreferredConfig = Bitmap.Config.ARGB_8888;
        String stringExtra = in.getStringExtra("path");
        this.s = stringExtra;
        Log.e("path", stringExtra);
        this.bitmap = BitmapFactory.decodeFile(this.s);
        this.bitmap = FFI_Constants.getBitmapFromUri(this, Uri.parse("file://" + this.s), this.bitmap.getWidth(), this.bitmap.getWidth());
        this.mImageView.setImageURI(Uri.parse(this.s));
        this.uri = Uri.parse(this.s);
        sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.parse("file://" + this.s)));
        this.done.setOnClickListener(v -> {
            AdShow.getInstance(FFI_SaveActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    saveImageBtnClicked();
                }
            }, MAIN_CLICK);
        });
        this.back.setOnClickListener(v -> {
            AdShow.getInstance(FFI_SaveActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    FFI_SaveActivity.this.backk();
                }
            }, BACK_CLICK);
        });

        this.facebook.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case 0:
                        Log.i("TAG", "touched down");
                        return false;
                    case 1:
                        Log.i("TAG", "touched up");
                        FFI_SaveActivity.this.facebook();
                        return false;
                    case 2:
                        Log.i("TAG", "moving: (16842924, 16842925)");
                        return false;
                    default:
                        return false;
                }
            }
        });
        this.whatsup.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case 0:
                        Log.i("TAG", "touched down");
                        return false;
                    case 1:
                        Log.i("TAG", "touched up");
                        FFI_SaveActivity.this.whatsup();
                        return false;
                    case 2:
                        Log.i("TAG", "moving: (16842924, 16842925)");
                        return false;
                    default:
                        return false;
                }
            }
        });
        this.insta.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case 0:
                        Log.i("TAG", "touched down");
                        return false;
                    case 1:
                        Log.i("TAG", "touched up");
                        FFI_SaveActivity.this.instagram();
                        return false;
                    case 2:
                        Log.i("TAG", "moving: (16842924, 16842925)");
                        return false;
                    default:
                        return false;
                }
            }
        });
        this.share.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case 0:
                        Log.i("TAG", "touched down");
                        return false;
                    case 1:
                        Log.i("TAG", "touched up");
                        FFI_SaveActivity.this.share();
                        return false;
                    case 2:
                        Log.i("TAG", "moving: (16842924, 16842925)");
                        return false;
                    default:
                        return false;
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    public void saveImageBtnClicked() {
        sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.parse("file://" + this.s)));
        Toast.makeText(this, "save image", Toast.LENGTH_SHORT).show();
        finish();
        startActivity(new Intent(this, FFI_MainActivity.class));
    }

    public void backk() {
        File fdelete = new File(this.uri.getPath());
        if (fdelete.exists()) {
            if (fdelete.delete()) {
                PrintStream printStream = System.out;
                printStream.println("file Deleted :" + this.uri.getPath());
            } else {
                PrintStream printStream2 = System.out;
                printStream2.println("file not Deleted :" + this.uri.getPath());
            }
        }
        finish();
    }

    public void facebook() {
        Uri data = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", new File(this.s));
        grantUriPermission(getPackageName(), data, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        Intent sendIntent = new Intent("android.intent.action.SEND");
        sendIntent.setType("image/*");
        sendIntent.putExtra("android.intent.extra.SUBJECT", "Image");
        sendIntent.setPackage("com.facebook.katana");
        sendIntent.putExtra("android.intent.extra.STREAM", data);
        sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        sendIntent.putExtra("android.intent.extra.TEXT", getResources().getString(R.string.app_name));
        startActivity(Intent.createChooser(sendIntent, "Share Image:"));
    }

    public void instagram() {
        Uri data = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", new File(this.s));
        grantUriPermission(getPackageName(), data, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        Intent sendIntent = new Intent("android.intent.action.SEND");
        sendIntent.setType("image/*");
        sendIntent.putExtra("android.intent.extra.SUBJECT", "Image");
        sendIntent.setPackage("com.instagram.android");
        sendIntent.putExtra("android.intent.extra.STREAM", data);
        sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        sendIntent.putExtra("android.intent.extra.TEXT", getResources().getString(R.string.app_name));
        startActivity(Intent.createChooser(sendIntent, "Share Image:"));
    }

    public void whatsup() {
        Uri data = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", new File(this.s));
        grantUriPermission(getPackageName(), data, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        Intent sendIntent = new Intent("android.intent.action.SEND");
        sendIntent.setType("image/*");
        sendIntent.putExtra("android.intent.extra.SUBJECT", "Image");
        sendIntent.setPackage("com.whatsapp");
        sendIntent.putExtra("android.intent.extra.STREAM", data);
        sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        sendIntent.putExtra("android.intent.extra.TEXT", getResources().getString(R.string.app_name));
        startActivity(Intent.createChooser(sendIntent, "Share Image:"));
    }

    public void share() {
        Uri data = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", new File(this.s));
        grantUriPermission(getPackageName(), data, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        Intent sendIntent = new Intent("android.intent.action.SEND");
        sendIntent.setType("image/*");
        sendIntent.putExtra("android.intent.extra.SUBJECT", "Image");
        sendIntent.putExtra("android.intent.extra.STREAM", data);
        sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        sendIntent.putExtra("android.intent.extra.TEXT", getResources().getString(R.string.app_name));
        startActivity(Intent.createChooser(sendIntent, "Share Image:"));
    }
}
