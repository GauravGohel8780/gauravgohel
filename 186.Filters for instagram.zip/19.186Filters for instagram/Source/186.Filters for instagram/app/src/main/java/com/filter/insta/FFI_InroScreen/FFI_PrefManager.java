package com.filter.insta.FFI_InroScreen;

import android.content.Context;
import android.content.SharedPreferences;


public class FFI_PrefManager {
    private static SharedPreferences mPreferences;
    public static final String FistTimeIntro = "FistTimeIntro";

    private static SharedPreferences getInstance(Context context) {
        if (mPreferences == null) {
            mPreferences = context.getApplicationContext()
                    .getSharedPreferences("all_saver_data", Context.MODE_PRIVATE);
        }
        return mPreferences;
    }


    public static void setFistTimeIntro(Context context, boolean value) {
        getInstance(context).edit().putBoolean(FistTimeIntro, value).apply();
    }

    public static boolean getFistTimeIntro(Context context) {
        return getInstance(context).getBoolean(FistTimeIntro, false);
    }
}
