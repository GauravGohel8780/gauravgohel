package com.filter.insta;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.filter.insta.Ads_Common.AdsBaseActivity;
import com.iten.tenoku.ad.AdShow;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

public class FFI_MyCreationActivity extends AdsBaseActivity {
    private RecyclerView recyclerView;
    private ImageAdapter imageAdapter;
    private ArrayList<File> imageFiles = new ArrayList<>();
    public ImageView Iv_back_creation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ffi_activity_my_creation_new);
        getWindow().setFlags(1024, 1024);
        Iv_back_creation = findViewById(R.id.ivBackCreation);
        Iv_back_creation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AdShow.getInstance(FFI_MyCreationActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        onBackPressed();
                    }
                }, AdUtils.ClickType.BACK_CLICK);

            }
        });

        recyclerView = findViewById(R.id.rvMyCreation);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        fetchImages();
    }

    private void fetchImages() {
        File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath() + "/" + "186.Filters for instagram" + "/");
        if (directory.exists() && directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files != null) {
                imageFiles.addAll(Arrays.asList(files));
                imageAdapter = new ImageAdapter(this, imageFiles);
                recyclerView.setAdapter(imageAdapter);
            }
        } else {
            Toast.makeText(this, "Directory not found", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        AdShow.getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
