package com.filter.insta.FFI_InroScreen;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.viewpager.widget.PagerAdapter;

import com.filter.insta.R;

import java.util.List;

public class FFI_IntroViewPagerAdapter extends PagerAdapter {
    Context mContext;
    List<FFI_ScreenItem> mListScreen;

    @Override
    public boolean isViewFromObject(View view, Object obj) {
        return view == obj;
    }

    public FFI_IntroViewPagerAdapter(Context context, List<FFI_ScreenItem> list) {
        this.mContext = context;
        this.mListScreen = list;
    }

    @Override
    public Object instantiateItem(ViewGroup viewGroup, int i) {
        View inflate = ((LayoutInflater) this.mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.ffi_intro_lay, (ViewGroup) null);
        ((TextView) inflate.findViewById(R.id.tvIntroTitle)).setText(this.mListScreen.get(i).getTitle());
        ((TextView) inflate.findViewById(R.id.tvIntroDescription)).setText(this.mListScreen.get(i).getDescription());
        ((ImageView) inflate.findViewById(R.id.ivIntroImg)).setImageResource(this.mListScreen.get(i).getScreenImg());
        viewGroup.addView(inflate);
        return inflate;
    }

    @Override
    public int getCount() {
        return this.mListScreen.size();
    }

    @Override
    public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
        viewGroup.removeView((View) obj);
    }
}
