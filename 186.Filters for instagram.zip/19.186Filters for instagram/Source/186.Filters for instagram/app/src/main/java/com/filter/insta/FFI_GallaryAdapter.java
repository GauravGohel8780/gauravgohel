package com.filter.insta;

import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;


import com.bumptech.glide.Glide;
import com.filter.insta.FFI_InroScreen.FFI_Intro_Activity;
import com.iten.tenoku.ad.AdShow;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.io.File;
import java.util.ArrayList;


public class FFI_GallaryAdapter extends BaseAdapter {

    public Activity activity;
    public static LayoutInflater inflater = null;
    ArrayList<String> imagegallary;

    public FFI_GallaryAdapter(Activity dAct, ArrayList<String> dUrl) {
        activity = dAct;
        imagegallary = dUrl;
        inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return imagegallary.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, final View convertView, ViewGroup parent) {
        View row = convertView;
        ViewHolder holder = null;
        DisplayMetrics metrics = activity.getResources().getDisplayMetrics();
        int width = metrics.widthPixels;
        if (row == null) {
            row = LayoutInflater.from(activity).inflate(R.layout.ffi_details_list_img, parent, false);
            holder = new ViewHolder();
            row.setLayoutParams(new GridView.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT));
            holder.imgIcon = row.findViewById(R.id.ivDetailsImg);
            holder.imgDelete = row.findViewById(R.id.ivDeledtImgList);
            holder.imgShare = row.findViewById(R.id.ivShareImgList);
            row.setTag(holder);
        } else {
            holder = (ViewHolder) row.getTag();
        }

        holder.imgIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AdShow.getInstance(activity).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getItemId(position);
                        Intent intent = new Intent(activity, FFI_SaveActivity.class);
                        intent.putExtra("path", imagegallary.get(position));
                        activity.startActivity(intent);
                    }
                }, MAIN_CLICK);

            }
        });

        holder.imgShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(activity);
                alertDialog.setTitle("Share File...");
                alertDialog.setMessage("Do you want to share this file?");
                alertDialog.setIcon(R.mipmap.ic_launcher);
                alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        shareImage("Filters for instagram" + " Created By : " + "https://play.google.com/store/apps/details?id=com.filter.insta", imagegallary.get(position));
                    }
                });
                alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                alertDialog.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                alertDialog.show();
            }
        });



        holder.imgDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(activity);
                alertDialog.setTitle("Confirm Delete...");
                alertDialog.setMessage("Are you sure you want delete this?");
                alertDialog.setIcon(R.mipmap.ic_launcher);
                alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        File fD = new File(imagegallary.get(position));
                        if (fD.exists()) {
                            fD.delete();
                        }
                        imagegallary.remove(position);
                        notifyDataSetChanged();
                        if (imagegallary.size() == 0) {
                            Toast.makeText(activity, "No Image Found..", Toast.LENGTH_LONG).show();
                        }
                    }
                });
                alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                alertDialog.show();
            }
        });
        Glide.with(activity).load(imagegallary.get(position)).centerCrop().into(holder.imgIcon);
        System.gc();
        return row;

    }

    static class ViewHolder {

        public ImageView imgIcon, imgDelete, imgShare;

    }

    public void shareImage(final String title, String path) {
        MediaScannerConnection.scanFile(activity, new String[]{path}, null, new MediaScannerConnection.OnScanCompletedListener() {
            public void onScanCompleted(String path, Uri uri) {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("video/*");
                shareIntent.putExtra(Intent.EXTRA_TEXT, title);
                shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
                shareIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
                activity.startActivity(Intent.createChooser(shareIntent, "Share Video"));
            }
        });
    }
}
