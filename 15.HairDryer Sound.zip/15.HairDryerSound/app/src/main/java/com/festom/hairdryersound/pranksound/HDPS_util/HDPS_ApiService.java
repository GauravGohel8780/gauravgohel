package com.festom.hairdryersound.pranksound.HDPS_util;


import com.festom.hairdryersound.pranksound.HDPS_model.HDPS_FeedBackResponseModel;
import com.festom.hairdryersound.pranksound.HDPS_model.HDPS_FeedbackRequestModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface HDPS_ApiService {

    @POST("api/v1/feedBack/save")
    Call<HDPS_FeedBackResponseModel> feedbackUser(@Body HDPS_FeedbackRequestModel request);
}