package com.festom.hairdryersound.pranksound.HDPS_util;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;

import com.festom.hairdryersound.pranksound.HDPS_preference.HDPS_SharePref;

import java.util.Locale;

public class HDPS_LanguageUtil {
    public static void setLanguage(Context context) {
        if (context == null) {
            return;
        }
        String prefLanguage = HDPS_SharePref.getPrefLanguage(context);
        if (prefLanguage == null) {
            prefLanguage = Locale.getDefault().getLanguage();
        }
        Locale locale = new Locale(prefLanguage.toLowerCase());
        Locale.setDefault(locale);
        Resources resources = context.getResources();
        Configuration configuration = resources.getConfiguration();
        configuration.setLocale(locale);
        resources.updateConfiguration(configuration, resources.getDisplayMetrics());
    }
}
