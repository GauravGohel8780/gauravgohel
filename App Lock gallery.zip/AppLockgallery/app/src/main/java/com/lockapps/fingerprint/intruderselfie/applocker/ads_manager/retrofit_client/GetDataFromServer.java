package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.retrofit_client;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import com.lockapps.fingerprint.intruderselfie.applocker.BuildConfig;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.app_open_ad.AppOpenManager;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.OnAdCallBack;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.ALT_InterstitialAds;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.FG_InterstitialAds;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.F_InterstitialAds;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.GF_InterstitialAds;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.G_InterstitialAds;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.InterstitialAdManager;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager.ALT_NativeAds;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager.FG_NativeAds;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager.F_NativeAds;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager.GF_NativeAds;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager.G_NativeAds;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.server.OnClearFromRecentService;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import unified.vpn.sdk.AuthMethod;
import unified.vpn.sdk.Callback;
import unified.vpn.sdk.ClientInfo;
import unified.vpn.sdk.CompletableCallback;
import unified.vpn.sdk.HydraTransport;
import unified.vpn.sdk.OpenVpnTransport;
import unified.vpn.sdk.SessionConfig;
import unified.vpn.sdk.TrackingConstants;
import unified.vpn.sdk.TrafficRule;
import unified.vpn.sdk.UnifiedSdk;
import unified.vpn.sdk.User;
import unified.vpn.sdk.VpnException;
import unified.vpn.sdk.VpnState;

public class GetDataFromServer {

    UnifiedSdk unifiedSDK;

    Activity activity;

    public GetDataFromServer(Activity activity) {
        this.activity = activity;
    }

    public void getAdDataUsingVolly(OnAdCallBack onAdCallBack) {
        AdsPreferences adsPreferences = new AdsPreferences(activity);

        adsPreferences.setIsAppLive(true); // Required
        adsPreferences.setBtnColorFlag(false); // Required
        adsPreferences.setBtnColor("#370B4A"); // Required
        adsPreferences.setIsTimer(false); // Required
        adsPreferences.setAdsClick(4); // Required
        adsPreferences.setAdsTime(15); // Required
        adsPreferences.setAdsPreload(true); // Required
        adsPreferences.setAdsOnback(false); // Required
        adsPreferences.setShowAdFirstPage(true); // Required
        adsPreferences.setIsAppsAdShow(false); // Required
        adsPreferences.setShowNativeBottom(false); // Required
        adsPreferences.setShowSplashInterstitial(false); // Required
        adsPreferences.setAdsPriority(CommonData.Google_Facebook); // Required

        RequestQueue queue = Volley.newRequestQueue(activity);
        StringRequest request = new StringRequest(Request.Method.GET, BuildConfig.JSON_URL, response -> {
            try {
                JSONObject respObj = new JSONObject(response);
                adsPreferences.setAppPackage(respObj.getString(adsPreferences.appPackage));
                adsPreferences.setIsAppLive(respObj.getBoolean(adsPreferences.isAppLive));
                adsPreferences.setAppRedirectLink(respObj.getString(adsPreferences.appRedirectLink));
                adsPreferences.setBtnColorFlag(respObj.getBoolean(adsPreferences.btnColorFlag));
                adsPreferences.setBtnColor(respObj.getString(adsPreferences.btnColor));
                adsPreferences.setIsTimer(respObj.getBoolean(adsPreferences.isTimer));
                adsPreferences.setAdsClick(respObj.getInt(adsPreferences.adsClick));
                adsPreferences.setAdsTime(respObj.getInt(adsPreferences.adsTime));
                adsPreferences.setAdsPreload(respObj.getBoolean(adsPreferences.adsPreload));
                adsPreferences.setLoaderTime(respObj.getInt(adsPreferences.loaderTime));
                adsPreferences.setIsNativeLoader(respObj.getBoolean(adsPreferences.isNativeLoader));
                adsPreferences.setNativeAdsPreload(respObj.getBoolean(adsPreferences.nativeAdsPreload));
                adsPreferences.setAdsOnback(respObj.getBoolean(adsPreferences.adsOnback));
                adsPreferences.setShowAdFirstPage(respObj.getBoolean(adsPreferences.showAdFirstPage));
                adsPreferences.setIsAppsAdShow(respObj.getBoolean(adsPreferences.isAppsAdShow));
                adsPreferences.setShowNativeBottom(respObj.getBoolean(adsPreferences.showNativeBottom));
                adsPreferences.setShowSplashInterstitial(respObj.getBoolean(adsPreferences.showSplashInterstitial));
                adsPreferences.setAdsPriority(respObj.getString(adsPreferences.adsPriority));
                adsPreferences.setPrivacyUrl(respObj.getString(adsPreferences.privacyUrl));
                adsPreferences.setIsAdOn(respObj.getBoolean(adsPreferences.isAdOn));
                adsPreferences.setisMediaOn(true);

                if (!new AdsPreferences(activity).getIsAppLive()) {
                    String appPackageName = new AdsPreferences(activity).getAppRedirectLink();
                    try {
                        activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
                    } catch (android.content.ActivityNotFoundException anfe) {
                        activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
                    }
                    return;
                }

                JSONObject admob = respObj.getJSONObject("Admob");
                adsPreferences.setAdmobAppOpen(admob.getString(adsPreferences.admobAppOpen));
                adsPreferences.setAdmobBanner(admob.getString(adsPreferences.admobBanner));
                adsPreferences.setAdmobInterstitial(admob.getString(adsPreferences.admobInterstitial));
                adsPreferences.setAdmobNative(admob.getString(adsPreferences.admobNative));
                adsPreferences.setAdmobNativeBanner(admob.getString(adsPreferences.admobNativeBanner));

                JSONObject adx = respObj.getJSONObject("Adx");
                adsPreferences.setAdxAppOpen(adx.getString(adsPreferences.adxAppOpen));
                adsPreferences.setAdxBanner(adx.getString(adsPreferences.adxBanner));
                adsPreferences.setAdxInterstitial(adx.getString(adsPreferences.adxInterstitial));
                adsPreferences.setAdxNative(adx.getString(adsPreferences.adxNative));
                adsPreferences.setAdxNativeBanner(adx.getString(adsPreferences.adxNativeBanner));

                JSONObject facebook = respObj.getJSONObject("Facebook");
                adsPreferences.setFacebookBanner(facebook.getString(adsPreferences.facebookBanner));
                adsPreferences.setFacebookInterstitial(facebook.getString(adsPreferences.facebookInterstitial));
                adsPreferences.setFacebookNative(facebook.getString(adsPreferences.facebookNative));
                adsPreferences.setFacebookNativeBanner(facebook.getString(adsPreferences.facebookNativeBanner));

                JSONObject apps = respObj.getJSONObject("Apps");
                adsPreferences.setAppsBanner(apps.getString(adsPreferences.appsBanner));
                adsPreferences.setAppsBody(apps.getString(adsPreferences.appsBody));
                adsPreferences.setAppsHeadline(apps.getString(adsPreferences.appsHeadline));
                adsPreferences.setAppsIcon(apps.getString(adsPreferences.appsIcon));
                adsPreferences.setAppsLink(apps.getString(adsPreferences.appsLink));

                JSONObject server = respObj.getJSONObject("server");
                adsPreferences.setServerFlag(server.getBoolean(adsPreferences.serverFlag));
                adsPreferences.setServerBaseUrl(server.getString(adsPreferences.serverBaseUrl));
                adsPreferences.setServerCarrierid(server.getString(adsPreferences.serverCarrierid));
                adsPreferences.setServerCountryList(server.getString(adsPreferences.serverCountryList));
                adsPreferences.setServerCountry(server.getString(adsPreferences.serverCountry));


                if (adsPreferences.getServerFlag()) {

                    final SharedPreferences prefs = getPrefs();
                    prefs.edit()
                            .putString(BuildConfig.STORED_HOST_URL_KEY, adsPreferences.getServerBaseUrl())
                            .putString(BuildConfig.STORED_CARRIER_ID_KEY, adsPreferences.getServerCarrierid())
                            .apply();

                    initSDK();


                    //============= Login into the server ============//

//                    if (unifiedSDK == null) {
//                        return;
//                    }
//                    if (!UnifiedSdk.getInstance().getBackend().isLoggedIn()) {
                    loginToVpn(onAdCallBack);
//                    }

                    //============= Login into the server ============//

                } else {
                    adsLoadMethode(onAdCallBack);
                }


            } catch (JSONException e) {
                e.printStackTrace();
            }
        }, error -> Log.i(CommonData.TAG, "postDataUsingVolley: " + "Fail to get response = " + error)) {

        };
        queue.getCache().clear();
        queue.add(request);
    }

    private void initSDK() {
        final SharedPreferences prefs = getPrefs();
        final String url = prefs.getString(BuildConfig.STORED_HOST_URL_KEY, BuildConfig.BASE_HOST);
        final String carrier = prefs.getString(BuildConfig.STORED_CARRIER_ID_KEY, "");

        if (!TextUtils.isEmpty(url) && !TextUtils.isEmpty(carrier)) {
            ClientInfo clientInfo = ClientInfo.newBuilder()
                    .addUrl(url)
                    .carrierId(carrier)
                    .build();

            UnifiedSdk.clearInstances();
            unifiedSDK = UnifiedSdk.getInstance(clientInfo);
        }
    }

    public SharedPreferences getPrefs() {
        return activity.getSharedPreferences(BuildConfig.SHARED_PREFS, Context.MODE_PRIVATE);
    }

    public void loginToVpn(OnAdCallBack onAdCallBack) {
        AuthMethod authMethod = AuthMethod.anonymous();
        UnifiedSdk.getInstance().getBackend().login(authMethod, new Callback<User>() {
            @Override
            public void success(User user) {
                connectToVpn(onAdCallBack);
            }

            @Override
            public void failure(VpnException e) {
            }
        });
    }

    public void disconnectFromVnp() {
        UnifiedSdk.getVpnState(new Callback<VpnState>() {
            @Override
            public void success(@NonNull VpnState vpnState) {
                if (vpnState == VpnState.CONNECTED) {
                    UnifiedSdk.getInstance().getVpn().stop(TrackingConstants.GprReasons.M_UI, new CompletableCallback() {
                        @Override
                        public void complete() {
                        }

                        @Override
                        public void error(VpnException e) {
                        }
                    });
                }
            }

            @Override
            public void failure(@NonNull VpnException e) {
            }
        });
    }

    public void logOutFromVnp() {
        UnifiedSdk.getInstance().getBackend().logout(new CompletableCallback() {
            @Override
            public void complete() {
            }

            @Override
            public void error(VpnException e) {
            }
        });
    }

    public void isConnected(Callback<Boolean> callback) {
        UnifiedSdk.getVpnState(new Callback<VpnState>() {
            @Override
            public void success(@NonNull VpnState vpnState) {
                callback.success(vpnState == VpnState.CONNECTED);
            }

            @Override
            public void failure(@NonNull VpnException e) {
                callback.success(false);
            }
        });
    }

    public void isLoggedIn(Callback<Boolean> callback) {
        UnifiedSdk.getInstance().getBackend().isLoggedIn(callback);
    }

    public void connectToVpn(OnAdCallBack onAdCallBack) {
        isLoggedIn(new Callback<Boolean>() {
            @Override
            public void success(@NonNull Boolean aBoolean) {
                if (aBoolean) {
                    List<String> fallbackOrder = new ArrayList<>();
                    fallbackOrder.add(HydraTransport.TRANSPORT_ID);
                    fallbackOrder.add(OpenVpnTransport.TRANSPORT_ID_TCP);
                    fallbackOrder.add(OpenVpnTransport.TRANSPORT_ID_UDP);
                    List<String> bypassDomains = new LinkedList<>();
                    bypassDomains.add("*domain1.com");
                    bypassDomains.add("*domain2.com");
                    UnifiedSdk.getInstance().getVpn().start(new SessionConfig.Builder()
                            .withReason(TrackingConstants.GprReasons.M_UI)
                            .withTransportFallback(fallbackOrder)
                            .withTransport(HydraTransport.TRANSPORT_ID)
                            .withVirtualLocation(new AdsPreferences(activity).getServerCountry())
                            .addDnsRule(TrafficRule.Builder.bypass().fromDomains(bypassDomains))
                            .build(), new CompletableCallback() {
                        @Override
                        public void complete() {
                            activity.startService(new Intent(activity, OnClearFromRecentService.class));
                            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                public void run() {
                                    adsLoadMethode(onAdCallBack);
                                }
                            }, 1000);
                        }

                        @Override
                        public void error(@NonNull VpnException e) {
                        }
                    });
                } else {
                }
            }

            @Override
            public void failure(@NonNull VpnException e) {

            }
        });
    }


    public void adsLoadMethode(OnAdCallBack onAdCallBack) {

        String adsPriority = new AdsPreferences(activity).getAdsPriority();

        if (new AdsPreferences(activity).getIsAdOn()) {
            if (new AdsPreferences(activity).getNativeAdsPreload()) {

                if (adsPriority.equalsIgnoreCase(CommonData.Google)) {

                    new G_NativeAds(activity).preLoadAdmobNative();
                    new G_NativeAds(activity).preLoadAdmobNativeBanner();
                    new G_NativeAds(activity).preLoadAdmobNativeBannerMid();
                    new G_NativeAds(activity).preLoadAdmobNativeBottomBanner();

                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook)) {

                    new F_NativeAds(activity).preLoadFbNative();
                    new F_NativeAds(activity).preLoadFbNativeBanner();
                    new F_NativeAds(activity).preLoadFbNativeBannerMid();
                    new F_NativeAds(activity).preLoadFbNativeBottomBanner();

                } else if (adsPriority.equalsIgnoreCase(CommonData.Google_Facebook)) {

                    new GF_NativeAds(activity).preLoadAdmobNative();
                    new GF_NativeAds(activity).preLoadAdmobNativeBanner();
                    new GF_NativeAds(activity).preLoadAdmobNativeBannerMid();
                    new GF_NativeAds(activity).preLoadAdmobNativeBottomBanner();

                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook_Google)) {

                    new FG_NativeAds(activity).preLoadFbNative();
                    new FG_NativeAds(activity).preLoadFbNativeBanner();
                    new FG_NativeAds(activity).preLoadFbNativeBannerMid();
                    new FG_NativeAds(activity).preLoadFbNativeBottomBanner();

                } else if (adsPriority.equalsIgnoreCase(CommonData.Alternate)) {

                    new ALT_NativeAds(activity).preLoadAdmobNative();
                    new ALT_NativeAds(activity).preLoadAdmobNativeBanner();
                    new ALT_NativeAds(activity).preLoadAdmobNativeBannerMid();
                    new ALT_NativeAds(activity).preLoadAdmobNativeBottomBanner();

                    new ALT_NativeAds(activity).preLoadFbNative();
                    new ALT_NativeAds(activity).preLoadFbNativeBanner();
                    new ALT_NativeAds(activity).preLoadFbNativeBannerMid();
                    new ALT_NativeAds(activity).preLoadFbNativeBottomBanner();

                } else {

                    new GF_NativeAds(activity).preLoadAdmobNative();
                    new GF_NativeAds(activity).preLoadAdmobNativeBanner();
                    new GF_NativeAds(activity).preLoadAdmobNativeBannerMid();
                    new GF_NativeAds(activity).preLoadAdmobNativeBottomBanner();

                }
            }

            if (new AdsPreferences(activity).getAdsPreload()) {
                if (adsPriority.equalsIgnoreCase(CommonData.Google)) {
                    new G_InterstitialAds(activity).preLoadAdMob();
                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook)) {
                    new F_InterstitialAds(activity).preLoadFacebook();
                } else if (adsPriority.equalsIgnoreCase(CommonData.Google_Facebook)) {
                    new GF_InterstitialAds(activity).preLoadAdMob();
                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook_Google)) {
                    new FG_InterstitialAds(activity).preLoadFacebook();
                } else if (adsPriority.equalsIgnoreCase(CommonData.Alternate)) {
                    new ALT_InterstitialAds(activity).preLoadAdMob();
                } else {
                    new GF_InterstitialAds(activity).preLoadAdMob();
                }
            }

            new AppOpenManager().loadAd_intent(activity, onAdCallBack);

        } else {
            new InterstitialAdManager(activity)._nextActivity(onAdCallBack);
        }

    }

}