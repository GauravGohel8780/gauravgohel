package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.internet;

public interface NetworkInterface {
    void onConnect();
}
