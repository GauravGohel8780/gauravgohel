package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager;

import android.app.Activity;

import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.OnAdCallBack;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;

import java.util.concurrent.TimeUnit;

public class InterstitialAdManager {

    Activity activity;

    public InterstitialAdManager(Activity activity) {
        this.activity = activity;
    }

    public void _nextActivity(OnAdCallBack onAdCallBack) {
        CommonData.aom_adCount = 0;
        onAdCallBack.onAdDismiss();
    }


    //====================== Show Interstitial Ads In Activity ==========================
    //====================== Show Interstitial Ads In Activity ==========================
    //====================== Show Interstitial Ads In Activity ==========================

    public void loadInterstitialCompulsory(OnAdCallBack onAdCallBack) {
        String adsPriority = new AdsPreferences(activity).getAdsPriority();
        if (new AdsPreferences(activity).getIsAdOn()) {
            try {
                if (adsPriority.equalsIgnoreCase(CommonData.Google)) {
                    pre_G_Inter_First(onAdCallBack);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook)) {
                    pre_F_Inter_First(onAdCallBack);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Google_Facebook)) {
                    pre_GF_Inter_First(onAdCallBack);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook_Google)) {
                    pre_FG_Inter_First(onAdCallBack);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Alternate)) {
                    pre_ALT_Inter_First(onAdCallBack);
                } else {
                    pre_FG_Inter_First(onAdCallBack);
                }
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }
        } else {
            _nextActivity(onAdCallBack);
        }
    }

    public void loadInterstitialFirst(OnAdCallBack onAdCallBack) {
        String adsPriority = new AdsPreferences(activity).getAdsPriority();
        if (new AdsPreferences(activity).getIsAdOn()) {
            try {
                if (CommonData.isShowFirstInterstitialAd) {
                    if (adsPriority.equalsIgnoreCase(CommonData.Google)) {
                        pre_G_Inter_All(onAdCallBack);
                    } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook)) {
                        pre_F_Inter_All(onAdCallBack);
                    } else if (adsPriority.equalsIgnoreCase(CommonData.Google_Facebook)) {
                        pre_GF_Inter_All(onAdCallBack);
                    } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook_Google)) {
                        pre_FG_Inter_All(onAdCallBack);
                    } else if (adsPriority.equalsIgnoreCase(CommonData.Alternate)) {
                        pre_ALT_Inter_All(onAdCallBack);
                    } else {
                        pre_FG_Inter_All(onAdCallBack);
                    }
                } else {
                    if (adsPriority.equalsIgnoreCase(CommonData.Google)) {
                        pre_G_Inter_First(onAdCallBack);
                    } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook)) {
                        pre_F_Inter_First(onAdCallBack);
                    } else if (adsPriority.equalsIgnoreCase(CommonData.Google_Facebook)) {
                        pre_GF_Inter_First(onAdCallBack);
                    } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook_Google)) {
                        pre_FG_Inter_First(onAdCallBack);
                    } else if (adsPriority.equalsIgnoreCase(CommonData.Alternate)) {
                        pre_ALT_Inter_First(onAdCallBack);
                    } else {
                        pre_FG_Inter_First(onAdCallBack);
                    }
                    CommonData.isShowFirstInterstitialAd = true;
                }
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }
        } else {
            _nextActivity(onAdCallBack);
        }
    }

    public void loadInterstitialAll(OnAdCallBack onAdCallBack) {
        String adsPriority = new AdsPreferences(activity).getAdsPriority();
        if (new AdsPreferences(activity).getIsAdOn()) {
            try {
                if (adsPriority.equalsIgnoreCase(CommonData.Google)) {
                    pre_G_Inter_All(onAdCallBack);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook)) {
                    pre_F_Inter_All(onAdCallBack);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Google_Facebook)) {
                    pre_GF_Inter_All(onAdCallBack);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook_Google)) {
                    pre_FG_Inter_All(onAdCallBack);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Alternate)) {
                    pre_ALT_Inter_All(onAdCallBack);
                } else {
                    pre_FG_Inter_All(onAdCallBack);
                }
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }
        } else {
            _nextActivity(onAdCallBack);
        }
    }

    //====================== Load & Show GA Interstitial Ads ==========================
    //====================== Load & Show GA Interstitial Ads ==========================
    //====================== Load & Show GA Interstitial Ads ==========================

    public void pre_G_Inter_All(OnAdCallBack onAdCallBack) {
        if (new AdsPreferences(activity).getAdsPreload()) {
            _nextActivity(onAdCallBack);
            if (new AdsPreferences(activity).getIsTimer()) {
                if ((TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()) - new AdsPreferences(activity).getAdsTimeCount()) >= new AdsPreferences(activity).getAdsTime()) {
                    if (CommonData._interstitial_google != null) {
                        CommonData.is_ShowingAd = true;
                        CommonData._interstitial_google.show(activity);
                    } else {
                        new G_InterstitialAds(activity).preLoadAdMob();
                    }
                }
            } else {
                if (new AdsPreferences(activity).getAdsClickCount() >= new AdsPreferences(activity).getAdsClick()) {
                    if (CommonData._interstitial_google != null) {
                        CommonData.is_ShowingAd = true;
                        CommonData._interstitial_google.show(activity);
                    } else {
                        new G_InterstitialAds(activity).preLoadAdMob();
                    }
                }
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        } else {
            if (new AdsPreferences(activity).getIsTimer()) {
                if (((int) TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()) - new AdsPreferences(activity).getAdsTimeCount()) >= new AdsPreferences(activity).getAdsTime()) {
                    new G_InterstitialAds(activity).clickLoadAdMob(onAdCallBack);
                } else {
                    _nextActivity(onAdCallBack);
                }
            } else {
                if (new AdsPreferences(activity).getAdsClickCount() >= new AdsPreferences(activity).getAdsClick()) {
                    new G_InterstitialAds(activity).clickLoadAdMob(onAdCallBack);
                } else {
                    _nextActivity(onAdCallBack);
                }
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        }
    }

    public void pre_G_Inter_First(OnAdCallBack onAdCallBack) {
        if (new AdsPreferences(activity).getAdsPreload()) {
            _nextActivity(onAdCallBack);
            if (new AdsPreferences(activity).getIsTimer()) {
                if (CommonData._interstitial_google != null) {
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_google.show(activity);
                } else {
                    new G_InterstitialAds(activity).preLoadAdMob();
                }
            } else {
                if (CommonData._interstitial_google != null) {
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_google.show(activity);
                } else {
                    new G_InterstitialAds(activity).preLoadAdMob();
                }
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        } else {
            if (new AdsPreferences(activity).getIsTimer()) {
                new G_InterstitialAds(activity).clickLoadAdMob(onAdCallBack);
            } else {
                new G_InterstitialAds(activity).clickLoadAdMob(onAdCallBack);
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        }
    }

    //====================== Load & Show FA Interstitial Ads ==========================
    //====================== Load & Show FA Interstitial Ads ==========================
    //====================== Load & Show FA Interstitial Ads ==========================

    public void pre_F_Inter_All(OnAdCallBack onAdCallBack) {
        if (new AdsPreferences(activity).getAdsPreload()) {
            _nextActivity(onAdCallBack);
            if (new AdsPreferences(activity).getIsTimer()) {
                if ((TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()) - new AdsPreferences(activity).getAdsTimeCount()) >= new AdsPreferences(activity).getAdsTime()) {
                    if (CommonData._interstitial_facebook != null) {
                        CommonData.is_ShowingAd = true;
                        CommonData._interstitial_facebook.show();
                    } else {
                        new F_InterstitialAds(activity).preLoadFacebook();
                    }
                }
            } else {
                if (new AdsPreferences(activity).getAdsClickCount() >= new AdsPreferences(activity).getAdsClick()) {
                    if (CommonData._interstitial_facebook != null) {
                        CommonData.is_ShowingAd = true;
                        CommonData._interstitial_facebook.show();
                    } else {
                        new F_InterstitialAds(activity).preLoadFacebook();
                    }
                }
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        } else {
            if (new AdsPreferences(activity).getIsTimer()) {
                if (((int) TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()) - new AdsPreferences(activity).getAdsTimeCount()) >= new AdsPreferences(activity).getAdsTime()) {
                    new F_InterstitialAds(activity).clickLoadFacebook(onAdCallBack);
                } else {
                    _nextActivity(onAdCallBack);
                }
            } else {
                if (new AdsPreferences(activity).getAdsClickCount() >= new AdsPreferences(activity).getAdsClick()) {
                    new F_InterstitialAds(activity).clickLoadFacebook(onAdCallBack);
                } else {
                    _nextActivity(onAdCallBack);
                }
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        }
    }

    public void pre_F_Inter_First(OnAdCallBack onAdCallBack) {
        if (new AdsPreferences(activity).getAdsPreload()) {
            _nextActivity(onAdCallBack);
            if (new AdsPreferences(activity).getIsTimer()) {
                if (CommonData._interstitial_facebook != null) {
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_facebook.show();
                } else {
                    new F_InterstitialAds(activity).preLoadFacebook();
                }
            } else {
                if (CommonData._interstitial_facebook != null) {
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_facebook.show();
                } else {
                    new F_InterstitialAds(activity).preLoadFacebook();
                }
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        } else {
            if (new AdsPreferences(activity).getIsTimer()) {
                new F_InterstitialAds(activity).clickLoadFacebook(onAdCallBack);
            } else {
                new F_InterstitialAds(activity).clickLoadFacebook(onAdCallBack);
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        }
    }

    //====================== Load & Show GFA Interstitial Ads ==========================
    //====================== Load & Show GFA Interstitial Ads ==========================
    //====================== Load & Show GFA Interstitial Ads ==========================

    public void pre_GF_Inter_All(OnAdCallBack onAdCallBack) {
        if (new AdsPreferences(activity).getAdsPreload()) {
            _nextActivity(onAdCallBack);
            if (new AdsPreferences(activity).getIsTimer()) {
                if ((TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()) - new AdsPreferences(activity).getAdsTimeCount()) >= new AdsPreferences(activity).getAdsTime()) {
                    if (CommonData._interstitial_google != null) {
                        CommonData.is_ShowingAd = true;
                        CommonData._interstitial_google.show(activity);
                    } else if (CommonData._interstitial_facebook != null) {
                        CommonData.is_ShowingAd = true;
                        CommonData._interstitial_facebook.show();
                    } else {
                        new GF_InterstitialAds(activity).preLoadAdMob();
                    }
                }
            } else {
                if (new AdsPreferences(activity).getAdsClickCount() >= new AdsPreferences(activity).getAdsClick()) {
                    if (CommonData._interstitial_google != null) {
                        CommonData.is_ShowingAd = true;
                        CommonData._interstitial_google.show(activity);
                    } else if (CommonData._interstitial_facebook != null) {
                        CommonData.is_ShowingAd = true;
                        CommonData._interstitial_facebook.show();
                    } else {
                        new GF_InterstitialAds(activity).preLoadAdMob();
                    }
                }
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        } else {
            if (new AdsPreferences(activity).getIsTimer()) {
                if (((int) TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()) - new AdsPreferences(activity).getAdsTimeCount()) >= new AdsPreferences(activity).getAdsTime()) {
                    new GF_InterstitialAds(activity).clickLoadAdMob(onAdCallBack);
                } else {
                    _nextActivity(onAdCallBack);
                }
            } else {
                if (new AdsPreferences(activity).getAdsClickCount() >= new AdsPreferences(activity).getAdsClick()) {
                    new GF_InterstitialAds(activity).clickLoadAdMob(onAdCallBack);
                } else {
                    _nextActivity(onAdCallBack);
                }
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        }
    }

    public void pre_GF_Inter_First(OnAdCallBack onAdCallBack) {
        if (new AdsPreferences(activity).getAdsPreload()) {
            _nextActivity(onAdCallBack);
            if (new AdsPreferences(activity).getIsTimer()) {
                if (CommonData._interstitial_google != null) {
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_google.show(activity);
                } else if (CommonData._interstitial_facebook != null) {
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_facebook.show();
                } else {
                    new GF_InterstitialAds(activity).preLoadAdMob();
                }
            } else {
                if (CommonData._interstitial_google != null) {
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_google.show(activity);
                } else if (CommonData._interstitial_facebook != null) {
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_facebook.show();
                } else {
                    new GF_InterstitialAds(activity).preLoadAdMob();
                }
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        } else {
            if (new AdsPreferences(activity).getIsTimer()) {
                new GF_InterstitialAds(activity).clickLoadAdMob(onAdCallBack);
            } else {
                new GF_InterstitialAds(activity).clickLoadAdMob(onAdCallBack);
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        }
    }

    //====================== Load & Show FGA Interstitial Ads ==========================
    //====================== Load & Show FGA Interstitial Ads ==========================
    //====================== Load & Show FGA Interstitial Ads ==========================

    public void pre_FG_Inter_All(OnAdCallBack onAdCallBack) {
        if (new AdsPreferences(activity).getAdsPreload()) {
            _nextActivity(onAdCallBack);
            if (new AdsPreferences(activity).getIsTimer()) {
                if ((TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()) - new AdsPreferences(activity).getAdsTimeCount()) >= new AdsPreferences(activity).getAdsTime()) {
                    if (CommonData._interstitial_facebook != null) {
                        CommonData.is_ShowingAd = true;
                        CommonData._interstitial_facebook.show();
                    } else if (CommonData._interstitial_google != null) {
                        CommonData.is_ShowingAd = true;
                        CommonData._interstitial_google.show(activity);
                    } else {
                        new FG_InterstitialAds(activity).preLoadFacebook();
                    }
                }
            } else {
                if (new AdsPreferences(activity).getAdsClickCount() >= new AdsPreferences(activity).getAdsClick()) {
                    if (CommonData._interstitial_facebook != null) {
                        CommonData.is_ShowingAd = true;
                        CommonData._interstitial_facebook.show();
                    } else if (CommonData._interstitial_google != null) {
                        CommonData.is_ShowingAd = true;
                        CommonData._interstitial_google.show(activity);
                    } else {
                        new FG_InterstitialAds(activity).preLoadFacebook();
                    }
                }
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        } else {
            if (new AdsPreferences(activity).getIsTimer()) {
                if (((int) TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()) - new AdsPreferences(activity).getAdsTimeCount()) >= new AdsPreferences(activity).getAdsTime()) {
                    new FG_InterstitialAds(activity).clickLoadFacebook(onAdCallBack);
                } else {
                    _nextActivity(onAdCallBack);
                }
            } else {
                if (new AdsPreferences(activity).getAdsClickCount() >= new AdsPreferences(activity).getAdsClick()) {
                    new FG_InterstitialAds(activity).clickLoadFacebook(onAdCallBack);
                } else {
                    _nextActivity(onAdCallBack);
                }
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        }
    }

    public void pre_FG_Inter_First(OnAdCallBack onAdCallBack) {
        if (new AdsPreferences(activity).getAdsPreload()) {
            _nextActivity(onAdCallBack);
            if (new AdsPreferences(activity).getIsTimer()) {
                if (CommonData._interstitial_facebook != null) {
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_facebook.show();
                } else if (CommonData._interstitial_google != null) {
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_google.show(activity);
                } else {
                    new FG_InterstitialAds(activity).preLoadFacebook();
                }
            } else {
                if (CommonData._interstitial_facebook != null) {
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_facebook.show();
                } else if (CommonData._interstitial_google != null) {
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_google.show(activity);
                } else {
                    new FG_InterstitialAds(activity).preLoadFacebook();
                }
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        } else {
            if (new AdsPreferences(activity).getIsTimer()) {
                new FG_InterstitialAds(activity).clickLoadFacebook(onAdCallBack);
            } else {
                new FG_InterstitialAds(activity).clickLoadFacebook(onAdCallBack);
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        }
    }

    //====================== Load & Show FGA Interstitial Ads ==========================
    //====================== Load & Show FGA Interstitial Ads ==========================
    //====================== Load & Show FGA Interstitial Ads ==========================

    public void pre_ALT_Inter_All(OnAdCallBack onAdCallBack) {
        if (new AdsPreferences(activity).getAdsPreload()) {
            _nextActivity(onAdCallBack);
            if (new AdsPreferences(activity).getIsTimer()) {
                if ((TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()) - new AdsPreferences(activity).getAdsTimeCount()) >= new AdsPreferences(activity).getAdsTime()) {
                    if (CommonData._interstitial_google != null) {
                        CommonData.is_ShowingAd = true;
                        CommonData._interstitial_google.show(activity);
                    } else if (CommonData._interstitial_facebook != null) {
                        CommonData.is_ShowingAd = true;
                        CommonData._interstitial_facebook.show();
                    } else {
                        new ALT_InterstitialAds(activity).preLoadAdMob();
                    }
                }
            } else {
                if (new AdsPreferences(activity).getAdsClickCount() >= new AdsPreferences(activity).getAdsClick()) {
                    if (CommonData._interstitial_google != null) {
                        CommonData.is_ShowingAd = true;
                        CommonData._interstitial_google.show(activity);
                    } else if (CommonData._interstitial_facebook != null) {
                        CommonData.is_ShowingAd = true;
                        CommonData._interstitial_facebook.show();
                    } else {
                        new ALT_InterstitialAds(activity).preLoadAdMob();
                    }
                }
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        } else {
            if (new AdsPreferences(activity).getIsTimer()) {
                if (((int) TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()) - new AdsPreferences(activity).getAdsTimeCount()) >= new AdsPreferences(activity).getAdsTime()) {
                    new ALT_InterstitialAds(activity).clickLoadAdMob(onAdCallBack);
                } else {
                    _nextActivity(onAdCallBack);
                }
            } else {
                if (new AdsPreferences(activity).getAdsClickCount() >= new AdsPreferences(activity).getAdsClick()) {
                    new ALT_InterstitialAds(activity).clickLoadAdMob(onAdCallBack);
                } else {
                    _nextActivity(onAdCallBack);
                }
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        }
    }

    public void pre_ALT_Inter_First(OnAdCallBack onAdCallBack) {
        if (new AdsPreferences(activity).getAdsPreload()) {
            _nextActivity(onAdCallBack);
            if (new AdsPreferences(activity).getIsTimer()) {
                if (CommonData._interstitial_google != null) {
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_google.show(activity);
                } else if (CommonData._interstitial_facebook != null) {
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_facebook.show();
                } else {
                    new ALT_InterstitialAds(activity).preLoadAdMob();
                }
            } else {
                if (CommonData._interstitial_google != null) {
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_google.show(activity);
                } else if (CommonData._interstitial_facebook != null) {
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_facebook.show();
                } else {
                    new ALT_InterstitialAds(activity).preLoadAdMob();
                }
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        } else {
            if (new AdsPreferences(activity).getIsTimer()) {
                new ALT_InterstitialAds(activity).clickLoadAdMob(onAdCallBack);
            } else {
                new ALT_InterstitialAds(activity).clickLoadAdMob(onAdCallBack);
                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
            }
        }
    }

    //====================== Load & Show AGF Interstitial Ads ==========================
    //====================== Load & Show AGF Interstitial Ads ==========================
    //====================== Load & Show AGF Interstitial Ads ==========================

//    public void pre_A_Inter_All(OnAdCallBack onAdCallBack) {
//        if (new AdsPreferences(activity).getAdsPreload()) {
//            _nextActivity(onAdCallBack);
//            if (new AdsPreferences(activity).getIsTimer()) {
//                if ((TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()) - new AdsPreferences(activity).getAdsTimeCount()) >= new AdsPreferences(activity).getAdsTime()) {
//                    if (CommonData.maxInterstitialAd.isReady()) {
//                        CommonData.is_ShowingAd = true;
//                        CommonData.maxInterstitialAd.showAd();
//                    } else {
//                        new A_InterstitialAds(activity).preLoadApplovin();
//                    }
//                }
//            } else {
//                if (new AdsPreferences(activity).getAdsClickCount() >= new AdsPreferences(activity).getAdsClick()) {
//                    if (CommonData.maxInterstitialAd.isReady()) {
//                        CommonData.is_ShowingAd = true;
//                        CommonData.maxInterstitialAd.showAd();
//                    } else {
//                        new A_InterstitialAds(activity).preLoadApplovin();
//                    }
//                }
//                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
//            }
//        } else {
//            if (new AdsPreferences(activity).getIsTimer()) {
//                if (((int) TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()) - new AdsPreferences(activity).getAdsTimeCount()) >= new AdsPreferences(activity).getAdsTime()) {
//                    new A_InterstitialAds(activity).clickLoadApplovin(onAdCallBack);
//                } else {
//                    _nextActivity(onAdCallBack);
//                }
//            } else {
//                if (new AdsPreferences(activity).getAdsClickCount() >= new AdsPreferences(activity).getAdsClick()) {
//                    new A_InterstitialAds(activity).clickLoadApplovin(onAdCallBack);
//                } else {
//                    _nextActivity(onAdCallBack);
//                }
//                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
//            }
//        }
//    }
//
//    public void pre_A_Inter_First(OnAdCallBack onAdCallBack) {
//        if (new AdsPreferences(activity).getAdsPreload()) {
//            _nextActivity(onAdCallBack);
//            if (new AdsPreferences(activity).getIsTimer()) {
//                if (CommonData.maxInterstitialAd.isReady()) {
//                    CommonData.is_ShowingAd = true;
//                    CommonData.maxInterstitialAd.showAd();
//                } else {
//                    new A_InterstitialAds(activity).preLoadApplovin();
//                }
//            } else {
//                if (CommonData.maxInterstitialAd.isReady()) {
//                    CommonData.is_ShowingAd = true;
//                    CommonData.maxInterstitialAd.showAd();
//                } else {
//                    new A_InterstitialAds(activity).preLoadApplovin();
//                }
//                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
//            }
//        } else {
//            if (new AdsPreferences(activity).getIsTimer()) {
//                new A_InterstitialAds(activity).clickLoadApplovin(onAdCallBack);
//            } else {
//                new A_InterstitialAds(activity).clickLoadApplovin(onAdCallBack);
//                new AdsPreferences(activity).setAdsClickCount(new AdsPreferences(activity).getAdsClickCount() + 1);
//            }
//        }
//    }

}


