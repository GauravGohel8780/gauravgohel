package com.lockapps.fingerprint.intruderselfie.applocker.Fragments;


import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.lockapps.fingerprint.intruderselfie.applocker.ItemClickListener;
import com.lockapps.fingerprint.intruderselfie.applocker.SharedPrefs;
import com.lockapps.fingerprint.intruderselfie.applocker.patternlockview.PatternLockView;
import com.lockapps.fingerprint.intruderselfie.applocker.patternlockview.listener.PatternLockViewListener;
import com.lockapps.fingerprint.intruderselfie.applocker.patternlockview.utils.PatternLockUtils;
import com.lockapps.fingerprint.intruderselfie.applocker.R;

import java.util.ArrayList;
import java.util.List;

public class Pattern extends Fragment implements View.OnClickListener {

    PatternLockView mPatternLockView;
    ItemClickListener itemClickListener;

    View view1, view2, view3, view4;
    Button btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn0;
    LinearLayout btnclear,pinlock,

    patternlock,swipe;
    TextView changeTopin;

    String passcode = "";
    String num1, num2, num3, num4;

    ArrayList<String> number_list = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_pattern, container, false);
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getActivity().getWindow().setNavigationBarColor(getResources().getColor(R.color.darkcolor));
        }
        itemClickListener = (ItemClickListener) getActivity();

        mPatternLockView = (PatternLockView) view.findViewById(R.id.pattern);
        pinlock = view.findViewById(R.id.pinlock);
        patternlock = view.findViewById(R.id.patternlock);
        swipe = view.findViewById(R.id.swipe);
        changeTopin = view.findViewById(R.id.changeTopin);



        if (SharedPrefs.getLockType(getContext()).equalsIgnoreCase("PIN")) {
            pinlock.setVisibility(View.VISIBLE);
            patternlock.setVisibility(View.GONE);
        } else {
            pinlock.setVisibility(View.GONE);
            patternlock.setVisibility(View.VISIBLE);
        }

        mPatternLockView.addPatternLockListener(new PatternLockViewListener() {
            @Override
            public void onStarted() {

            }

            @Override
            public void onProgress(List<PatternLockView.Dot> progressPattern) {

            }

            @Override
            public void onComplete(List<PatternLockView.Dot> pattern) {
                if (PatternLockUtils.patternToString(mPatternLockView, pattern).length() >= 4) {

                    SharedPrefs.setPatternData(getContext(),PatternLockUtils.patternToString(mPatternLockView, pattern));

                    itemClickListener.onItemClicked("Repattern");

                } else {
                    Toast.makeText(getContext(), "Please select 4 dot", Toast.LENGTH_SHORT).show();
                    mPatternLockView.clearPattern();
                }


            }

            @Override
            public void onCleared() {

            }
        });

        swipe.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if (patternlock.getVisibility() == View.VISIBLE){
                    patternlock.setVisibility(View.GONE);
                    pinlock.setVisibility(View.VISIBLE);
                    changeTopin.setText("Switch to Patten");

                    SharedPrefs.setLockType(getContext(),"PIN");
                }else {
                    patternlock.setVisibility(View.VISIBLE);
                    pinlock.setVisibility(View.GONE);
                    changeTopin.setText("Switch to PIN");

                    SharedPrefs.setLockType(getContext(),"Pattern");
                }
            }
        });

        initializecomponents(view);

        return view;
    }


    private void initializecomponents(View view) {
        view1 = view.findViewById(R.id.view1);
        view2 = view.findViewById(R.id.view2);
        view3 = view.findViewById(R.id.view3);
        view4 = view.findViewById(R.id.view4);


        btn1 = view.findViewById(R.id.btn1);
        btn2 = view.findViewById(R.id.btn2);
        btn3 = view.findViewById(R.id.btn3);
        btn4 = view.findViewById(R.id.btn4);
        btn5 = view.findViewById(R.id.btn5);
        btn6 = view.findViewById(R.id.btn6);
        btn7 = view.findViewById(R.id.btn7);
        btn8 = view.findViewById(R.id.btn8);
        btn9 = view.findViewById(R.id.btn9);
        btn0 = view.findViewById(R.id.btn0);
        btnclear = view.findViewById(R.id.btncancel);

        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        btn6.setOnClickListener(this);
        btn7.setOnClickListener(this);
        btn8.setOnClickListener(this);
        btn9.setOnClickListener(this);
        btn0.setOnClickListener(this);
        btnclear.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn1:
                number_list.add("1");
                passnumber(number_list);
                break;
            case R.id.btn2:
                number_list.add("2");
                passnumber(number_list);
                break;
            case R.id.btn3:
                number_list.add("3");
                passnumber(number_list);
                break;
            case R.id.btn4:
                number_list.add("4");
                passnumber(number_list);
                break;
            case R.id.btn5:
                number_list.add("5");
                passnumber(number_list);
                break;
            case R.id.btn6:
                number_list.add("6");
                passnumber(number_list);
                break;
            case R.id.btn7:
                number_list.add("7");
                passnumber(number_list);
                break;
            case R.id.btn8:
                number_list.add("8");
                passnumber(number_list);
                break;
            case R.id.btn9:
                number_list.add("9");
                passnumber(number_list);
                break;
            case R.id.btn0:
                number_list.add("0");
                passnumber(number_list);
                break;
            case R.id.btncancel:
                number_list.clear();
                passnumber(number_list);
                break;
        }
    }

    private void passnumber(ArrayList<String> number_list) {

        if (number_list.size() == 0) {
            view1.setBackgroundResource(R.drawable.bg_view);
            view2.setBackgroundResource(R.drawable.bg_view);
            view3.setBackgroundResource(R.drawable.bg_view);
            view4.setBackgroundResource(R.drawable.bg_view);
        } else {
            switch (number_list.size()) {
                case 1:
                    num1 = number_list.get(0);
                    view1.setBackgroundResource(R.drawable.bg_view_blue_oval);
                    break;
                case 2:
                    num2 = number_list.get(1);
                    view2.setBackgroundResource(R.drawable.bg_view_blue_oval);
                    break;
                case 3:
                    num3 = number_list.get(2);
                    view3.setBackgroundResource(R.drawable.bg_view_blue_oval);
                    break;
                case 4:
                    num4 = number_list.get(3);
                    view4.setBackgroundResource(R.drawable.bg_view_blue_oval);
                    passcode = num1 + num2 + num3 + num4;

                    SharedPrefs.setPinData(getContext(),passcode);

                    itemClickListener.onItemClicked("Repattern");

                    break;

            }
        }
    }
}