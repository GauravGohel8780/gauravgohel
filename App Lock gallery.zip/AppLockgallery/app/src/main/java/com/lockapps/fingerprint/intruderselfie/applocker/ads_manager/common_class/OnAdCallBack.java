package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class;

import android.app.Activity;

public interface OnAdCallBack {
    void onAdDismiss();
}
