package com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Photo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.TextView;
import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.app_open_ad.AOM_Activity;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.OnAdCallBack;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.internet.NetworkConnection;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.InterstitialAdManager;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager.NativeAdManager;
import com.lockapps.fingerprint.intruderselfie.applocker.galleryitemClickListener;

import java.util.ArrayList;

public class PhotoItemActivity extends AppCompatActivity implements galleryitemClickListener {

    RecyclerView recyclerView;
    ArrayList<PhotoItemModel> model = new ArrayList<>();
    String foldePath;
    int po;

    TextView foldername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_item);

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(getResources().getColor(R.color.darkcolor));
        }

        new NativeAdManager(this).show_NativeBannerAds(this.findViewById(R.id.apps_FrameLayout),
                this.findViewById(R.id.ad_FrameLayout), this.findViewById(R.id.applovin_FrameLayout), this.findViewById(R.id.nativeAdLayout),
                this.findViewById(R.id.ad_loading));

        new NativeAdManager(this).show_NativeBottomFlag(this.findViewById(R.id.bapps_FrameLayout),
                this.findViewById(R.id.bad_FrameLayout), this.findViewById(R.id.bapplovin_FrameLayout), this.findViewById(R.id.bnativeAdLayout),
                this.findViewById(R.id.bad_loading));

        foldePath = getIntent().getStringExtra("folderPath");

        foldername = findViewById(R.id.foldername);
        foldername.setText(getIntent().getStringExtra("foldername"));

        recyclerView = findViewById(R.id.rvphotoitem);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerView.hasFixedSize();
    }

    @Override
    protected void onResume() {
        model = getAllImagesByFolder(foldePath);
        recyclerView.setAdapter(new PhotoItemAdapter(model, this, this));
        super.onResume();
        new NetworkConnection().callNetworkConnection(this);
        new AOM_Activity().showAppOpenAdsActivity(this);
    }

    public ArrayList<PhotoItemModel> getAllImagesByFolder(String path) {
        ArrayList<PhotoItemModel> photos = new ArrayList<>();
        Uri allPhtossuri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Images.ImageColumns.DATA,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.SIZE};
        Cursor cursor = PhotoItemActivity.this.getContentResolver().query(allPhtossuri, projection, MediaStore.Images.Media.DATA + " like ? ", new String[]{"%" + path + "%"}, null);
        try {
            cursor.moveToFirst();
            do {
                PhotoItemModel pic = new PhotoItemModel();

                pic.setPicturName(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)));

                pic.setPicturePath(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)));

                pic.setPictureSize(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)));

                photos.add(pic);
            } while (cursor.moveToNext());
            cursor.close();
            ArrayList<PhotoItemModel> reSelection = new ArrayList<>();
            for (int i = photos.size() - 1; i > -1; i--) {
                reSelection.add(photos.get(i));
            }
            photos = reSelection;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return photos;
    }

    @Override
    public void onPicClicked(PhotoItemAdapter.PicHolder holder, int position, ArrayList<PhotoItemModel> pics) {
        po = holder.getAdapterPosition();

        new InterstitialAdManager(this).loadInterstitialAll(new OnAdCallBack() {
            @Override
            public void onAdDismiss() {
                Intent intent = new Intent(PhotoItemActivity.this, PhotoviewPagerActivity.class);
                Bundle args = new Bundle();
                args.putParcelableArrayList("arrayP", model);
                intent.putExtra("po", String.valueOf(po));
                intent.putExtras(args);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onPicClicked(String pictureFolderPath, String folderName) {

    }

    @Override
    public void onBackPressed() {
        if (new AdsPreferences(this).getAdsOnback()) {
            new InterstitialAdManager(this).loadInterstitialAll(new OnAdCallBack() {
                @Override
                public void onAdDismiss() {
                    onBack();
                }
            });
        } else {
            onBack();
        }
    }

    public void onBack() {
        super.onBackPressed();
        CommonData.aom_adCount = 0;
    }


}
