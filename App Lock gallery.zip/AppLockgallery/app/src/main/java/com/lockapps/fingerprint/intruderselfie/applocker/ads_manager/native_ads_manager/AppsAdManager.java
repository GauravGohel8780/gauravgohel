package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager;

import android.app.Activity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.facebook.ads.NativeAdLayout;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;

public class AppsAdManager {

    Activity activity;

    public AppsAdManager(Activity activity) {
        this.activity = activity;
    }


    public void onDemandLoadAppsNative(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        apps_FrameLayout.setVisibility(View.GONE);
        ad_FrameLayout.setVisibility(View.GONE);
        applovin_FrameLayout.setVisibility(View.GONE);
        nativeAdLayout.setVisibility(View.GONE);
        ad_loading.setVisibility(View.GONE);
        if (new AdsPreferences(activity).getIsAppsAdShow()) {
            apps_FrameLayout.setVisibility(View.VISIBLE);
            new AppsNativeAds(activity).loadAppsNative(apps_FrameLayout);
        } else {
            ad_loading.setVisibility(View.VISIBLE);
        }
    }


    public void onDemandLoadAppsNativeBanner(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        apps_FrameLayout.setVisibility(View.GONE);
        ad_FrameLayout.setVisibility(View.GONE);
        applovin_FrameLayout.setVisibility(View.GONE);
        nativeAdLayout.setVisibility(View.GONE);
        ad_loading.setVisibility(View.GONE);
        if (new AdsPreferences(activity).getIsAppsAdShow()) {
            apps_FrameLayout.setVisibility(View.VISIBLE);
            new AppsNativeAds(activity).loadAppsNativeBanner(apps_FrameLayout);
        } else {
            ad_loading.setVisibility(View.VISIBLE);
        }
    }


    public void onDemandLoadAppsNativeBannerMid(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        apps_FrameLayout.setVisibility(View.GONE);
        ad_FrameLayout.setVisibility(View.GONE);
        applovin_FrameLayout.setVisibility(View.GONE);
        nativeAdLayout.setVisibility(View.GONE);
        ad_loading.setVisibility(View.GONE);
        if (new AdsPreferences(activity).getIsAppsAdShow()) {
            apps_FrameLayout.setVisibility(View.VISIBLE);
            new AppsNativeAds(activity).loadAppsNativeBanner2(apps_FrameLayout);
        } else {
            ad_loading.setVisibility(View.VISIBLE);
        }
    }


    public void onDemandLoadAppsNativeBottomBanner(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        apps_FrameLayout.setVisibility(View.GONE);
        ad_FrameLayout.setVisibility(View.GONE);
        applovin_FrameLayout.setVisibility(View.GONE);
        nativeAdLayout.setVisibility(View.GONE);
        ad_loading.setVisibility(View.GONE);
        if (new AdsPreferences(activity).getIsAppsAdShow()) {
            apps_FrameLayout.setVisibility(View.VISIBLE);
            new AppsNativeAds(activity).loadAppsNativeBottomBanner(apps_FrameLayout);
        } else {
            ad_loading.setVisibility(View.VISIBLE);
        }
    }

}
