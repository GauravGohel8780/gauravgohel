package com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.activities.main;

import android.app.AppOpsManager;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.lockapps.fingerprint.intruderselfie.applocker.Activities.IntruderSelfie;
import com.lockapps.fingerprint.intruderselfie.applocker.Activities.MainLockActivity;
import com.lockapps.fingerprint.intruderselfie.applocker.Gallery.GalleryActivity;
import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.app_open_ad.AOM_Activity;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.OnAdCallBack;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.internet.NetworkConnection;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.InterstitialAdManager;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager.NativeAdManager;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.rateus.RateUsDialog;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.base.BaseActivity;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.model.CommLockInfo;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.mvp.contract.LockMainContract;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.mvp.p.LockMainPresenter;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.services.BackgroundManager;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.services.LockService;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.widget.DialogSearch;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

public class AppList extends BaseActivity implements LockMainContract.View, View.OnClickListener {


    private LinearLayout mBtnSetting, intruderSelfie, gallery;
    private ImageView mEditSearch;
    private TabLayout mTabLayout;
    private ViewPager mViewPager;
    private CommentPagerAdapter mPagerAdapter;
    private LockMainPresenter mLockMainPresenter;
    private DialogSearch mDialogSearch;
    BottomSheetDialog bottomSheetDialog;
    private List<String> titles;
    private List<Fragment> fragmentList;
    Dialog dialog;
    Button btntry;

    @Override
    public int getLayoutId() {
        return R.layout.applist;
    }

    @Override
    protected void initViews(Bundle savedInstanceState) {
        mBtnSetting = findViewById(R.id.setting);
        intruderSelfie = findViewById(R.id.intruderSelfie);
        gallery = findViewById(R.id.gallery);
        mEditSearch = findViewById(R.id.edit_search);
        mTabLayout = findViewById(R.id.tab_layout);
        mViewPager = findViewById(R.id.view_pager);
        mLockMainPresenter = new LockMainPresenter(this, this);
        mLockMainPresenter.loadAppInfo(this);
    }

    @Override
    protected void initData() {

        new NativeAdManager(this).show_NativeBottomFlag(this.findViewById(R.id.bapps_FrameLayout),
                this.findViewById(R.id.bad_FrameLayout), this.findViewById(R.id.bapplovin_FrameLayout), this.findViewById(R.id.bnativeAdLayout),
                this.findViewById(R.id.bad_loading));

        new NativeAdManager(this).show_NativeBottomFlag(this.findViewById(R.id.apps_FrameLayout),
                this.findViewById(R.id.ad_FrameLayout), this.findViewById(R.id.applovin_FrameLayout), this.findViewById(R.id.nativeAdLayout),
                this.findViewById(R.id.ad_loading));

        new NativeAdManager(this).showBottomNativeAdsDialog();

        mDialogSearch = new DialogSearch(this);
        bottomSheetDialog = new BottomSheetDialog(this);

//        if (!BackgroundManager.getInstance().init(this).isServiceRunning(LockService.class)) {
//            BackgroundManager.getInstance().init(this).startService(LockService.class);
//        }
//        BackgroundManager.getInstance().init(this).startAlarmManager();

        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.darkcolor));
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(getResources().getColor(R.color.darkcolor));
        }

    }


    @Override
    protected void initAction() {
        mBtnSetting.setOnClickListener(this);
        intruderSelfie.setOnClickListener(this);
        gallery.setOnClickListener(this);
        mEditSearch.setOnClickListener(this);
        mDialogSearch.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                mLockMainPresenter.loadAppInfo(AppList.this);
            }
        });

    }

    @Override
    public void loadAppInfoSuccess(@NonNull List<CommLockInfo> list) {
        int sysNum = 0;
        int userNum = 0;
        for (CommLockInfo info : list) {
            if (info.isSysApp()) {
                sysNum++;
            } else {
                userNum++;
            }
        }
        titles = new ArrayList<>();
        titles.add("System Apps" + " (" + sysNum + ")");
        titles.add("User Apps" + " (" + userNum + ")");

        SysAppFragment sysAppFragment = SysAppFragment.newInstance(list);
        UserAppFragment userAppFragment = UserAppFragment.newInstance(list);

        fragmentList = new ArrayList<>();
        fragmentList.add(sysAppFragment);
        fragmentList.add(userAppFragment);
        mPagerAdapter = new CommentPagerAdapter(getSupportFragmentManager(), fragmentList, titles);
        mViewPager.setAdapter(mPagerAdapter);
        mTabLayout.setupWithViewPager(mViewPager);
    }

    @Override
    public void onClick(@NonNull View view) {
        switch (view.getId()) {
            case R.id.setting:
                new InterstitialAdManager(AppList.this).loadInterstitialAll(new OnAdCallBack() {
                    @Override
                    public void onAdDismiss() {
                        startActivity(new Intent(AppList.this, com.lockapps.fingerprint.intruderselfie.applocker.Activities.Settings.class));
                    }
                });

                break;
            case R.id.edit_search:
                mDialogSearch.show();
                break;
            case R.id.intruderSelfie:
                new InterstitialAdManager(AppList.this).loadInterstitialAll(new OnAdCallBack() {
                    @Override
                    public void onAdDismiss() {
                        startActivity(new Intent(AppList.this, IntruderSelfie.class));
                    }
                });
                break;
            case R.id.gallery:
                new InterstitialAdManager(AppList.this).loadInterstitialAll(new OnAdCallBack() {
                    @Override
                    public void onAdDismiss() {
                        startActivity(new Intent(AppList.this, GalleryActivity.class));
                    }
                });
                break;
        }
    }


    public class CommentPagerAdapter extends FragmentStatePagerAdapter {

        private List<Fragment> fragmentList;
        private List<String> titles;


        public CommentPagerAdapter(FragmentManager fm, List<Fragment> fragmentList, List<String> titles) {
            super(fm);
            this.fragmentList = fragmentList;
            this.titles = titles;
        }

        @Override
        public Fragment getItem(int position) {
            return fragmentList.get(position);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return titles.get(position);
        }

        @Override
        public int getCount() {
            return titles.size();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        new NetworkConnection().callNetworkConnection(this);
        new AOM_Activity().showAppOpenAdsActivity(this);
        showBottomSheetDialog();

        if (isAccessGranted() && Settings.canDrawOverlays(this)) {
            bottomSheetDialog.dismiss();
        } else {
            bottomSheetDialog.show();
        }
    }


    private void showBottomSheetDialog() {
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_dialog);

        LinearLayout head = bottomSheetDialog.findViewById(R.id.head);
        RelativeLayout rl1 = bottomSheetDialog.findViewById(R.id.rl1);
        RelativeLayout rl2 = bottomSheetDialog.findViewById(R.id.rl2);
        AppCompatButton button = bottomSheetDialog.findViewById(R.id.button);
        ImageView checkBox = bottomSheetDialog.findViewById(R.id.check);
        ImageView checkBox1 = bottomSheetDialog.findViewById(R.id.check1);

        if (isAccessGranted()) {
            checkBox.setImageResource(R.drawable.ic_checkbox_selected);
        }

        if (Settings.canDrawOverlays(this)) {
            checkBox1.setImageResource(R.drawable.ic_checkbox_selected);
        }

        checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isAccessGranted()) {
                    checkBox.setImageResource(R.drawable.ic_checkbox_selected);
                } else {
                    bottomSheetDialog.dismiss();
                    startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
                }
            }
        });

        checkBox1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Settings.canDrawOverlays(AppList.this)) {
                    checkBox1.setImageResource(R.drawable.ic_checkbox_selected);
                } else {
                    bottomSheetDialog.dismiss();
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                    startActivityForResult(intent, 0);
                }
            }
        });

        bottomSheetDialog.setCancelable(false);

        if (isAccessGranted() && Settings.canDrawOverlays(this)) {
            bottomSheetDialog.dismiss();
        } /*else {
            bottomSheetDialog.show();
        }*/

    }

    private boolean isAccessGranted() {
        try {
            PackageManager packageManager = getPackageManager();
            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(getPackageName(), 0);
            AppOpsManager appOpsManager = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            int mode = 0;
            if (android.os.Build.VERSION.SDK_INT > android.os.Build.VERSION_CODES.KITKAT) {
                mode = appOpsManager.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                        applicationInfo.uid, applicationInfo.packageName);
            }
            return (mode == AppOpsManager.MODE_ALLOWED);

        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    @Override
    public void onBackPressed() {
        new RateUsDialog(this).ShowRateUsDialog(2);
    }
}
