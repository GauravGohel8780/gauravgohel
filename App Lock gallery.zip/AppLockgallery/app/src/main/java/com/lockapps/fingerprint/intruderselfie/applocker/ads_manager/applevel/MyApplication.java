package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.applevel;

import android.app.Activity;
import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import com.balsikandar.crashreporter.CrashReporter;
import com.facebook.ads.AudienceNetworkAds;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.lockapps.fingerprint.intruderselfie.applocker.BuildConfig;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.activities.lock.GestureUnlockActivity;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.base.BaseActivity;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.utils.SpUtil;

import org.litepal.LitePalApplication;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import unified.vpn.sdk.CompletableCallback;
import unified.vpn.sdk.HydraTransportConfig;
import unified.vpn.sdk.OpenVpnTransportConfig;
import unified.vpn.sdk.TransportConfig;
import unified.vpn.sdk.UnifiedSdk;

public class MyApplication extends LitePalApplication {


    private static final String CHANNEL_ID = "vpn";
    private static MyApplication application;
    private static List<BaseActivity> activityList;

    public static MyApplication getInstance() {
        return application;
    }



    @Override
    public void onCreate() {
        super.onCreate();
        application = this;

        //Crash reporter utility
        CrashReporter.initialize(this, getCacheDir().getPath());

        SpUtil.getInstance().init(application);

        activityList = new ArrayList<>();

        initHydraSdk();
//        Gson gson = new Gson();
//        String json = gson.toJson(DataUtils.getAdData().admob);
//        Log.i(CommonData.TAG,"loadAd_intent:" + json);

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(@NonNull InitializationStatus initializationStatus) {

            }
        });
        AudienceNetworkAds.initialize(this);


//        GetDataFromServer.getInstance().getAdData();

//        -------------------------Test Device Id---------------------------
//        List<String> testDeviceIds = Collections.singletonList("B3ACB83CEF0FB8CEE90169A8CB1AA6C8");
//        RequestConfiguration configuration = new RequestConfiguration.Builder().setTestDeviceIds(testDeviceIds).build();
//        MobileAds.setRequestConfiguration(configuration);
//        -------------------------Test Device Id---------------------------


    }

    public void doForCreate(BaseActivity activity) {
        activityList.add(activity);
    }

    public void doForFinish(BaseActivity activity) {
        activityList.remove(activity);
    }

    public void clearAllActivity() {
        try {
            for (BaseActivity activity : activityList) {
                if (activity != null && !clearAllWhiteList(activity))
                    activity.clear();
            }
            activityList.clear();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean clearAllWhiteList(BaseActivity activity) {
        return activity instanceof GestureUnlockActivity;
    }

    public void initHydraSdk() {
//        createNotificationChannel();
        SharedPreferences prefs = getPrefs();

        List<TransportConfig> transportConfigList = new ArrayList<>();
        transportConfigList.add(HydraTransportConfig.create());
        transportConfigList.add(OpenVpnTransportConfig.tcp());
        transportConfigList.add(OpenVpnTransportConfig.udp());
        UnifiedSdk.update(transportConfigList, CompletableCallback.EMPTY);

//        SdkNotificationConfig notificationConfig = SdkNotificationConfig.newBuilder()
//                .title(getResources().getString(R.string.app_name))
//                .channelId(CHANNEL_ID)
//                .build();
//        UnifiedSdk.update(notificationConfig);

        UnifiedSdk.setLoggingLevel(Log.VERBOSE);
    }

    public void setNewHostAndCarrier(String hostUrl, String carrierId) {
        SharedPreferences prefs = getPrefs();
        if (TextUtils.isEmpty(hostUrl)) {
            prefs.edit().remove(BuildConfig.STORED_HOST_URL_KEY).apply();
        } else {
            prefs.edit().putString(BuildConfig.STORED_HOST_URL_KEY, hostUrl).apply();
        }

        if (TextUtils.isEmpty(carrierId)) {
            prefs.edit().remove(BuildConfig.STORED_CARRIER_ID_KEY).apply();
        } else {
            prefs.edit().putString(BuildConfig.STORED_CARRIER_ID_KEY, carrierId).apply();
        }
        initHydraSdk();
    }

    public SharedPreferences getPrefs() {
        return getSharedPreferences(BuildConfig.SHARED_PREFS, Context.MODE_PRIVATE);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Sample VPN";
            String description = "VPN notification";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

}