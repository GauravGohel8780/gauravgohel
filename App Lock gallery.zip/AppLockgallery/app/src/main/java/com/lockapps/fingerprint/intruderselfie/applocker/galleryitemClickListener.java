package com.lockapps.fingerprint.intruderselfie.applocker;

import com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Photo.PhotoItemAdapter;
import com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Photo.PhotoItemModel;

import java.util.ArrayList;

public interface galleryitemClickListener {

    void onPicClicked(PhotoItemAdapter.PicHolder holder, int position, ArrayList<PhotoItemModel> pics);
    void onPicClicked(String pictureFolderPath,String folderName);
}
