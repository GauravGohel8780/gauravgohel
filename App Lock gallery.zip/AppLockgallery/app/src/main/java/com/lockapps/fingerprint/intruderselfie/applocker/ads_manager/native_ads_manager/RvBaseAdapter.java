package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.gms.ads.nativead.NativeAdViewHolder;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;

import java.util.ArrayList;

public abstract class RvBaseAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public abstract int setLayout(@NonNull ViewGroup viewGroup);

    public abstract int setAdLayoutContainer(@NonNull ViewGroup viewGroup);

    public abstract void itemBind(@NonNull RecyclerView.ViewHolder holder, int position);

    public abstract int itemCount();

    public abstract int itemPerAds();

    public abstract ArrayList<Object> nativePosition();

    public abstract RecyclerView.ViewHolder viewHolder(View view);

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        switch (viewType) {
            case CommonData.MENU_ITEM_VIEW_TYPE:
                View itemView = LayoutInflater.from(viewGroup.getContext()).inflate(setLayout(viewGroup), viewGroup, false);
                return viewHolder(itemView);
            case CommonData.BANNER_AD_VIEW_TYPE:
            default:
                View adView = LayoutInflater.from(viewGroup.getContext()).inflate(setAdLayoutContainer(viewGroup), viewGroup, false);
                return new NativeAdViewHolder(adView);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        int viewType = getItemViewType(position);
        switch (viewType) {
            case CommonData.MENU_ITEM_VIEW_TYPE:
                itemBind(holder, position);
                break;
            case CommonData.BANNER_AD_VIEW_TYPE:
            default:
                try {
                    NativeAdViewHolder nativeAdViewHolder = (NativeAdViewHolder) holder;
                    NativeAdView adView = (NativeAdView) nativePosition().get(position);
                    ViewGroup adCardView = (ViewGroup) nativeAdViewHolder.itemView;
                    if (adCardView.getChildCount() > 0) {
                        adCardView.removeAllViews();
                    }
                    if (adView.getParent() != null) {
                        ((ViewGroup) adView.getParent()).removeView(adView);
                    }
                    adCardView.addView(adView);
                } catch (ClassCastException e) {
                    e.printStackTrace();
                }
        }
    }

    @Override
    public int getItemCount() {
        return itemCount();
    }

    @Override
    public int getItemViewType(int position) {
        return (position % itemPerAds() == 0) ? CommonData.BANNER_AD_VIEW_TYPE : CommonData.MENU_ITEM_VIEW_TYPE;
    }

    public static class NativeAdViewHolder extends RecyclerView.ViewHolder {
        NativeAdViewHolder(View view) {
            super(view);
        }
    }

}
