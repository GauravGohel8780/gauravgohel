package com.lockapps.fingerprint.intruderselfie.applocker;

import com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Video.VideoItemAdapter;
import com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Video.VideoItemModel;

import java.util.ArrayList;

public interface galleryVideoitemClickListener {

    void onPicClicked(VideoItemAdapter.PicHolder holder, int position, ArrayList<VideoItemModel> pics);
    void onPicClicked(String pictureFolderPath,String folderName);
}
