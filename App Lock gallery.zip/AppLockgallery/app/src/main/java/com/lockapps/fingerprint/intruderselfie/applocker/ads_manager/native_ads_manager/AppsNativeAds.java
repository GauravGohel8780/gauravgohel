package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.graphics.drawable.DrawableCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;

public class AppsNativeAds implements View.OnClickListener {

    Activity activity;

    public AppsNativeAds(Activity activity) {
        this.activity = activity;
    }


    //=========================== (1) ==========================
    //=========================== (1) ==========================

    //=============== Load Apps Native Ad ===================
    //=============== Load Apps Native Ad ===================

    public void loadAppsNative(FrameLayout apps_FrameLayout) {
        LinearLayout adView = (LinearLayout) activity.getLayoutInflater().inflate(R.layout.apps_native_big, null);
        populateAppsNativeMedia(adView);
        apps_FrameLayout.removeAllViews();
        apps_FrameLayout.addView(adView);
    }


    //=========================== (2) ==========================
    //=========================== (2) ==========================

    //=============== Load Apps Native Banner Ad ===================
    //=============== Load Apps Native Banner Ad ===================

    public void loadAppsNativeBanner(FrameLayout qu_FrameLayout) {
        LinearLayout adView = (LinearLayout) activity.getLayoutInflater().inflate(R.layout.apps_native_media_banner, null);
        populateAppsNativeMedia(adView);
        qu_FrameLayout.removeAllViews();
        qu_FrameLayout.addView(adView);
    }


    //=========================== (3) ==========================
    //=========================== (3) ==========================

    //=============== Load Apps Native Banner2 Ad ===================
    //=============== Load Apps Native Banner2 Ad ===================

    public void loadAppsNativeBanner2(FrameLayout qu_FrameLayout) {
        LinearLayout adView = (LinearLayout) activity.getLayoutInflater().inflate(R.layout.apps_native_banner2, null);
        populateAppsNativeNoMedia(adView);
        qu_FrameLayout.removeAllViews();
        qu_FrameLayout.addView(adView);
    }


    //=========================== (4) ==========================
    //=========================== (4) ==========================

    //=============== Load Apps Native Bottom Banner Ad ===================
    //=============== Load Apps Native Bottom Banner Ad ===================

    public void loadAppsNativeBottomBanner(FrameLayout qu_FrameLayout) {
        LinearLayout adView = (LinearLayout) activity.getLayoutInflater().inflate(R.layout.apps_native_bottom_banner, null);
        populateAppsNativeNoMedia(adView);
        qu_FrameLayout.removeAllViews();
        qu_FrameLayout.addView(adView);
    }



    public void populateAppsNativeMedia(LinearLayout adView) {
        AppCompatImageView apps_media = adView.findViewById(R.id.apps_mediaImage);
        AppCompatImageView apps_app_icon = adView.findViewById(R.id.apps_app_icon);
        AppCompatTextView apps_headline = adView.findViewById(R.id.apps_headline);
        AppCompatTextView apps_advertiser = adView.findViewById(R.id.apps_advertiser);
        AppCompatTextView apps_body = adView.findViewById(R.id.apps_body);
        AppCompatButton apps_call_to_action = adView.findViewById(R.id.apps_call_to_action);

        // CallToAction Button Color
        if (new AdsPreferences(activity).getBtnColorFlag()) {
            Drawable tintDr = DrawableCompat.wrap(apps_call_to_action.getBackground());
            DrawableCompat.setTint(tintDr, Color.parseColor(new AdsPreferences(activity).getBtnColor()));
            apps_call_to_action.setBackground(tintDr);
        }


        // Apps Icon
        Glide.with(activity.getApplicationContext()).clear(apps_app_icon);
        Glide.with(activity.getApplicationContext())
                .load(new AdsPreferences(activity).getAppsIcon())
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true)
                .into(apps_app_icon);

        // Apps Media
        Glide.with(activity.getApplicationContext()).clear(apps_media);
        Glide.with(activity.getApplicationContext())
                .load(new AdsPreferences(activity).getAppsBanner())
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true)
                .into(apps_media);


        // Apps Headline
        apps_headline.setText(new AdsPreferences(activity).getAppsHeadline());
        // Apps Advertiser
        apps_advertiser.setText("Play Store");
        // Apps Body
        apps_body.setText(new AdsPreferences(activity).getAppsBody());
        // Apps Action
        apps_media.setOnClickListener(this);
        apps_app_icon.setOnClickListener(this);
        apps_headline.setOnClickListener(this);
        apps_advertiser.setOnClickListener(this);
        apps_body.setOnClickListener(this);
        apps_call_to_action.setOnClickListener(this);
    }

    public void populateAppsNativeNoMedia(LinearLayout adView) {
//        AppCompatImageView apps_mediaImage = adView.findViewById(R.id.apps_mediaImage);
        AppCompatImageView apps_app_icon = adView.findViewById(R.id.apps_app_icon);
        AppCompatTextView apps_headline = adView.findViewById(R.id.apps_headline);
        AppCompatTextView apps_advertiser = adView.findViewById(R.id.apps_advertiser);
        AppCompatTextView apps_body = adView.findViewById(R.id.apps_body);
        AppCompatButton apps_call_to_action = adView.findViewById(R.id.apps_call_to_action);

        // CallToAction Button Color
        if (new AdsPreferences(activity).getBtnColorFlag()) {
            Drawable tintDr = DrawableCompat.wrap(apps_call_to_action.getBackground());
            DrawableCompat.setTint(tintDr, Color.parseColor(new AdsPreferences(activity).getBtnColor()));
            apps_call_to_action.setBackground(tintDr);
        }

//        // Apps Media
//        Glide.with(activity.getApplicationContext()).clear(apps_mediaImage);
//        Glide.with(activity.getApplicationContext())
//                .load(new AdsPreferences(activity).getAppsBanner())
//                .diskCacheStrategy(DiskCacheStrategy.NONE)
//                .skipMemoryCache(true)
//                .into(apps_mediaImage);

        // //Apps Icon
//        Glide.with(activity.getApplicationContext()).clear(apps_app_icon);
//        Glide.with(activity.getApplicationContext())
//                .load(new AdsPreferences(activity).getAppsIcon())
//                .diskCacheStrategy(DiskCacheStrategy.NONE)
//                .skipMemoryCache(true)
//                .into(apps_app_icon);

        // Apps Headline
        apps_headline.setText(new AdsPreferences(activity).getAppsHeadline());
        // Apps Advertiser
        apps_advertiser.setText("Play Store");
        // Apps Body
        apps_body.setText(new AdsPreferences(activity).getAppsBody());
        // Apps Action
//        apps_mediaImage.setOnClickListener(this);
        apps_app_icon.setOnClickListener(this);
        apps_headline.setOnClickListener(this);
        apps_advertiser.setOnClickListener(this);
        apps_body.setOnClickListener(this);
        apps_call_to_action.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        try {
            if (view.getId() == R.id.apps_mediaImage || view.getId() == R.id.apps_app_icon || view.getId() == R.id.apps_headline || view.getId() == R.id.apps_advertiser || view.getId() == R.id.apps_body || view.getId() == R.id.apps_call_to_action) {
                try {
                    activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + new AdsPreferences(activity).getAppsLink())));
                } catch (ActivityNotFoundException unused) {
                    activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + new AdsPreferences(activity).getAppsLink())));
                }
            }
        } catch (ActivityNotFoundException e) {

        }
    }

}
