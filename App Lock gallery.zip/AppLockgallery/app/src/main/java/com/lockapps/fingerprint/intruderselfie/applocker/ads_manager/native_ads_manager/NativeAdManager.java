package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.facebook.ads.NativeAdLayout;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;

import java.util.Random;

public class NativeAdManager {

    Activity activity;
    public static Dialog adsDialog;
    BottomSheetDialog bottomSheetDialog;

    public NativeAdManager(Activity activity) {
        this.activity = activity;
    }

    public void nativeShow(int adsS1, int adsS2, boolean bottomAdShow) {

        if (adsS1 == 11) {
            new NativeAdManager(activity).show_NativeAds(activity.findViewById(R.id.apps_FrameLayout),
                    activity.findViewById(R.id.ad_FrameLayout), activity.findViewById(R.id.applovin_FrameLayout), activity.findViewById(R.id.nativeAdLayout),
                    activity.findViewById(R.id.ad_loading));
        } else if (adsS1 == 12) {
            new NativeAdManager(activity).show_NativeAds(activity.findViewById(R.id.apps_FrameLayout2),
                    activity.findViewById(R.id.ad_FrameLayout2), activity.findViewById(R.id.applovin_FrameLayout2), activity.findViewById(R.id.nativeAdLayout2),
                    activity.findViewById(R.id.ad_loading2));
        } else if (adsS1 == 21) {
            new NativeAdManager(activity).show_NativeBannerAds(activity.findViewById(R.id.apps_FrameLayout),
                    activity.findViewById(R.id.ad_FrameLayout), activity.findViewById(R.id.applovin_FrameLayout), activity.findViewById(R.id.nativeAdLayout),
                    activity.findViewById(R.id.ad_loading));
        } else if (adsS1 == 22) {
            new NativeAdManager(activity).show_NativeBannerAds(activity.findViewById(R.id.apps_FrameLayout2),
                    activity.findViewById(R.id.ad_FrameLayout2), activity.findViewById(R.id.applovin_FrameLayout2), activity.findViewById(R.id.nativeAdLayout2),
                    activity.findViewById(R.id.ad_loading2));
        } else if (adsS1 == 31) {
            new NativeAdManager(activity).show_NativeBannerAds2(activity.findViewById(R.id.apps_FrameLayout),
                    activity.findViewById(R.id.ad_FrameLayout), activity.findViewById(R.id.applovin_FrameLayout), activity.findViewById(R.id.nativeAdLayout),
                    activity.findViewById(R.id.ad_loading));
        } else if (adsS1 == 32) {
            new NativeAdManager(activity).show_NativeBannerAds2(activity.findViewById(R.id.apps_FrameLayout2),
                    activity.findViewById(R.id.ad_FrameLayout2), activity.findViewById(R.id.applovin_FrameLayout2), activity.findViewById(R.id.nativeAdLayout2),
                    activity.findViewById(R.id.ad_loading2));
        } else if (adsS1 == 41) {
            new NativeAdManager(activity).show_NativeBottomBannerAds(activity.findViewById(R.id.apps_FrameLayout),
                    activity.findViewById(R.id.ad_FrameLayout), activity.findViewById(R.id.applovin_FrameLayout), activity.findViewById(R.id.nativeAdLayout),
                    activity.findViewById(R.id.ad_loading));
        } else if (adsS1 == 42) {
            new NativeAdManager(activity).show_NativeBottomBannerAds(activity.findViewById(R.id.apps_FrameLayout2),
                    activity.findViewById(R.id.ad_FrameLayout2), activity.findViewById(R.id.applovin_FrameLayout2), activity.findViewById(R.id.nativeAdLayout2),
                    activity.findViewById(R.id.ad_loading2));
        }

        if (adsS2 == 11) {
            new NativeAdManager(activity).show_NativeAds(activity.findViewById(R.id.apps_FrameLayout),
                    activity.findViewById(R.id.ad_FrameLayout), activity.findViewById(R.id.applovin_FrameLayout), activity.findViewById(R.id.nativeAdLayout),
                    activity.findViewById(R.id.ad_loading));
        } else if (adsS2 == 12) {
            new NativeAdManager(activity).show_NativeAds(activity.findViewById(R.id.apps_FrameLayout2),
                    activity.findViewById(R.id.ad_FrameLayout2), activity.findViewById(R.id.applovin_FrameLayout2), activity.findViewById(R.id.nativeAdLayout2),
                    activity.findViewById(R.id.ad_loading2));
        } else if (adsS2 == 21) {
            new NativeAdManager(activity).show_NativeBannerAds(activity.findViewById(R.id.apps_FrameLayout),
                    activity.findViewById(R.id.ad_FrameLayout), activity.findViewById(R.id.applovin_FrameLayout), activity.findViewById(R.id.nativeAdLayout),
                    activity.findViewById(R.id.ad_loading));
        } else if (adsS2 == 22) {
            new NativeAdManager(activity).show_NativeBannerAds(activity.findViewById(R.id.apps_FrameLayout2),
                    activity.findViewById(R.id.ad_FrameLayout2), activity.findViewById(R.id.applovin_FrameLayout2), activity.findViewById(R.id.nativeAdLayout2),
                    activity.findViewById(R.id.ad_loading2));
        } else if (adsS2 == 31) {
            new NativeAdManager(activity).show_NativeBannerAds2(activity.findViewById(R.id.apps_FrameLayout),
                    activity.findViewById(R.id.ad_FrameLayout), activity.findViewById(R.id.applovin_FrameLayout), activity.findViewById(R.id.nativeAdLayout),
                    activity.findViewById(R.id.ad_loading));
        } else if (adsS2 == 32) {
            new NativeAdManager(activity).show_NativeBannerAds2(activity.findViewById(R.id.apps_FrameLayout2),
                    activity.findViewById(R.id.ad_FrameLayout2), activity.findViewById(R.id.applovin_FrameLayout2), activity.findViewById(R.id.nativeAdLayout2),
                    activity.findViewById(R.id.ad_loading2));
        } else if (adsS2 == 41) {
            new NativeAdManager(activity).show_NativeBottomBannerAds(activity.findViewById(R.id.apps_FrameLayout),
                    activity.findViewById(R.id.ad_FrameLayout), activity.findViewById(R.id.applovin_FrameLayout), activity.findViewById(R.id.nativeAdLayout),
                    activity.findViewById(R.id.ad_loading));
        } else if (adsS2 == 42) {
            new NativeAdManager(activity).show_NativeBottomBannerAds(activity.findViewById(R.id.apps_FrameLayout2),
                    activity.findViewById(R.id.ad_FrameLayout2), activity.findViewById(R.id.applovin_FrameLayout2), activity.findViewById(R.id.nativeAdLayout2),
                    activity.findViewById(R.id.ad_loading2));
        }

        if (bottomAdShow) {
            new NativeAdManager(activity).show_NativeBottomFlag(activity.findViewById(R.id.bapps_FrameLayout),
                    activity.findViewById(R.id.bad_FrameLayout), activity.findViewById(R.id.bapplovin_FrameLayout), activity.findViewById(R.id.bnativeAdLayout),
                    activity.findViewById(R.id.bad_loading));
        }

    }

    public void nativeShowFragment(View view, int adsS1, int adsS2, boolean bottomAdShow) {

        if (adsS1 == 11) {
            new NativeAdManager(activity).show_NativeAds(view.findViewById(R.id.apps_FrameLayout),
                    view.findViewById(R.id.ad_FrameLayout), view.findViewById(R.id.applovin_FrameLayout), view.findViewById(R.id.nativeAdLayout),
                    view.findViewById(R.id.ad_loading));
        } else if (adsS1 == 12) {
            new NativeAdManager(activity).show_NativeAds(view.findViewById(R.id.apps_FrameLayout2),
                    view.findViewById(R.id.ad_FrameLayout2), view.findViewById(R.id.applovin_FrameLayout2), view.findViewById(R.id.nativeAdLayout2),
                    view.findViewById(R.id.ad_loading2));
        } else if (adsS1 == 21) {
            new NativeAdManager(activity).show_NativeBannerAds(view.findViewById(R.id.apps_FrameLayout),
                    view.findViewById(R.id.ad_FrameLayout), view.findViewById(R.id.applovin_FrameLayout), view.findViewById(R.id.nativeAdLayout),
                    view.findViewById(R.id.ad_loading));
        } else if (adsS1 == 22) {
            new NativeAdManager(activity).show_NativeBannerAds(view.findViewById(R.id.apps_FrameLayout2),
                    view.findViewById(R.id.ad_FrameLayout2), view.findViewById(R.id.applovin_FrameLayout2), view.findViewById(R.id.nativeAdLayout2),
                    view.findViewById(R.id.ad_loading2));
        } else if (adsS1 == 31) {
            new NativeAdManager(activity).show_NativeBannerAds2(view.findViewById(R.id.apps_FrameLayout),
                    view.findViewById(R.id.ad_FrameLayout), view.findViewById(R.id.applovin_FrameLayout), view.findViewById(R.id.nativeAdLayout),
                    view.findViewById(R.id.ad_loading));
        } else if (adsS1 == 32) {
            new NativeAdManager(activity).show_NativeBannerAds2(view.findViewById(R.id.apps_FrameLayout2),
                    view.findViewById(R.id.ad_FrameLayout2), view.findViewById(R.id.applovin_FrameLayout2), view.findViewById(R.id.nativeAdLayout2),
                    view.findViewById(R.id.ad_loading2));
        } else if (adsS1 == 41) {
            new NativeAdManager(activity).show_NativeBottomBannerAds(view.findViewById(R.id.apps_FrameLayout),
                    view.findViewById(R.id.ad_FrameLayout), view.findViewById(R.id.applovin_FrameLayout), view.findViewById(R.id.nativeAdLayout),
                    view.findViewById(R.id.ad_loading));
        } else if (adsS1 == 42) {
            new NativeAdManager(activity).show_NativeBottomBannerAds(view.findViewById(R.id.apps_FrameLayout2),
                    view.findViewById(R.id.ad_FrameLayout2), view.findViewById(R.id.applovin_FrameLayout2), view.findViewById(R.id.nativeAdLayout2),
                    view.findViewById(R.id.ad_loading2));
        }

        if (adsS2 == 11) {
            new NativeAdManager(activity).show_NativeAds(view.findViewById(R.id.apps_FrameLayout),
                    view.findViewById(R.id.ad_FrameLayout), view.findViewById(R.id.applovin_FrameLayout), view.findViewById(R.id.nativeAdLayout),
                    view.findViewById(R.id.ad_loading));
        } else if (adsS2 == 12) {
            new NativeAdManager(activity).show_NativeAds(view.findViewById(R.id.apps_FrameLayout2),
                    view.findViewById(R.id.ad_FrameLayout2), view.findViewById(R.id.applovin_FrameLayout2), view.findViewById(R.id.nativeAdLayout2),
                    view.findViewById(R.id.ad_loading2));
        } else if (adsS2 == 21) {
            new NativeAdManager(activity).show_NativeBannerAds(view.findViewById(R.id.apps_FrameLayout),
                    view.findViewById(R.id.ad_FrameLayout), view.findViewById(R.id.applovin_FrameLayout), view.findViewById(R.id.nativeAdLayout),
                    view.findViewById(R.id.ad_loading));
        } else if (adsS2 == 22) {
            new NativeAdManager(activity).show_NativeBannerAds(view.findViewById(R.id.apps_FrameLayout2),
                    view.findViewById(R.id.ad_FrameLayout2), view.findViewById(R.id.applovin_FrameLayout2), view.findViewById(R.id.nativeAdLayout2),
                    view.findViewById(R.id.ad_loading2));
        } else if (adsS2 == 31) {
            new NativeAdManager(activity).show_NativeBannerAds2(view.findViewById(R.id.apps_FrameLayout),
                    view.findViewById(R.id.ad_FrameLayout), view.findViewById(R.id.applovin_FrameLayout), view.findViewById(R.id.nativeAdLayout),
                    view.findViewById(R.id.ad_loading));
        } else if (adsS2 == 32) {
            new NativeAdManager(activity).show_NativeBannerAds2(view.findViewById(R.id.apps_FrameLayout2),
                    view.findViewById(R.id.ad_FrameLayout2), view.findViewById(R.id.applovin_FrameLayout2), view.findViewById(R.id.nativeAdLayout2),
                    view.findViewById(R.id.ad_loading2));
        } else if (adsS2 == 41) {
            new NativeAdManager(activity).show_NativeBottomBannerAds(view.findViewById(R.id.apps_FrameLayout),
                    view.findViewById(R.id.ad_FrameLayout), view.findViewById(R.id.applovin_FrameLayout), view.findViewById(R.id.nativeAdLayout),
                    view.findViewById(R.id.ad_loading));
        } else if (adsS2 == 42) {
            new NativeAdManager(activity).show_NativeBottomBannerAds(view.findViewById(R.id.apps_FrameLayout2),
                    view.findViewById(R.id.ad_FrameLayout2), view.findViewById(R.id.applovin_FrameLayout2), view.findViewById(R.id.nativeAdLayout2),
                    view.findViewById(R.id.ad_loading2));
        }

        if (bottomAdShow) {
            new NativeAdManager(activity).show_NativeBottomFlag(view.findViewById(R.id.bapps_FrameLayout),
                    view.findViewById(R.id.bad_FrameLayout), view.findViewById(R.id.bapplovin_FrameLayout), view.findViewById(R.id.bnativeAdLayout),
                    view.findViewById(R.id.bad_loading));
        }

    }

    //==================== Native Ad =======================
    //==================== Native Ad =======================
    //==================== Native Ad =======================

    public void show_NativeAds(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (new AdsPreferences(activity).getIsAdOn()) {
            String adsPriority = new AdsPreferences(activity).getAdsPriority();
            if (new AdsPreferences(activity).getNativeAdsPreload()) {
                if (adsPriority.equalsIgnoreCase(CommonData.Google)) {
                    G_Native(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook)) {
                    F_Native(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Google_Facebook)) {
                    GF_Native(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook_Google)) {
                    FG_Native(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Alternate)) {
                    ALT_Native(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else {
                    GF_Native(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                }
            } else {
                NativeAdLoaderTimer();
                if (adsPriority.equalsIgnoreCase(CommonData.Google)) {
                    new G_NativeAds(activity).onDemandLoadAdmobNative(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook)) {
                    new F_NativeAds(activity).onDemandLoadFbNative(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Google_Facebook)) {
                    new GF_NativeAds(activity).onDemandLoadAdmobNative(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Alternate)) {
                    if (CommonData.isShowedAltAdmobNativeAds) {
                        new FG_NativeAds(activity).onDemandLoadFbNative(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                        CommonData.isShowedAltAdmobNativeAds = false;
                    } else {
                        new GF_NativeAds(activity).onDemandLoadAdmobNative(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                        CommonData.isShowedAltAdmobNativeAds = true;
                    }
                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook_Google)) {
                    new FG_NativeAds(activity).onDemandLoadFbNative(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else {
                    new GF_NativeAds(activity).onDemandLoadAdmobNative(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                }
            }
        } else {
            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
        }
    }

    public void G_Native(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.google_NativeAds != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.VISIBLE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            com.google.android.gms.ads.nativead.NativeAdView adView;
            if (getRandomLay() == 1) {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_1, null);
            } else if (getRandomLay() == 2) {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_2, null);
            } else if (getRandomLay() == 3) {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_3, null);
            } else {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_4, null);
            }
//            if (new AdsPreferences(activity).getNativeLay().equalsIgnoreCase("am_native_1")) {
//                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_1, null);
//            } else if (new AdsPreferences(activity).getNativeLay().equalsIgnoreCase("am_native_2")) {
//                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_2, null);
//            } else if (new AdsPreferences(activity).getNativeLay().equalsIgnoreCase("am_native_3")) {
//                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_3, null);
//            } else {
//                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_4, null);
//            }
            new NativeAdsPopulate(activity).populateNativeMedia(CommonData.google_NativeAds, adView);
            ad_FrameLayout.removeAllViews();
            ad_FrameLayout.addView(adView);

            new G_NativeAds(activity).preLoadAdmobNative();

        } else {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            if (new AdsPreferences(activity).getIsAppsAdShow()) {
                apps_FrameLayout.setVisibility(View.VISIBLE);
                new AppsNativeAds(activity).loadAppsNative(apps_FrameLayout);
            } else {
                ad_loading.setVisibility(View.VISIBLE);
            }
            CommonData.google_NativeAds = null;
            new G_NativeAds(activity).preLoadAdmobNative();
        }
    }

    public void F_Native(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.facebook_nativeAd != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.VISIBLE);
            ad_loading.setVisibility(View.GONE);
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
            LinearLayout adView;
            if (getRandomLay() == 1) {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_1, nativeAdLayout, false);
            } else if (getRandomLay() == 2) {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_2, nativeAdLayout, false);
            } else if (getRandomLay() == 3) {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_3, nativeAdLayout, false);
            } else {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_4, nativeAdLayout, false);
            }
            new NativeAdsPopulate(activity).inflateFbNative(CommonData.facebook_nativeAd, nativeAdLayout, adView);

            new F_NativeAds(activity).preLoadFbNative();

        } else {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            if (new AdsPreferences(activity).getIsAppsAdShow()) {
                apps_FrameLayout.setVisibility(View.VISIBLE);
                new AppsNativeAds(activity).loadAppsNative(apps_FrameLayout);
            } else {
                ad_loading.setVisibility(View.VISIBLE);
            }
            CommonData.facebook_nativeAd = null;
            new F_NativeAds(activity).preLoadFbNative();
        }
    }

    public void GF_Native(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.google_NativeAds != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.VISIBLE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            com.google.android.gms.ads.nativead.NativeAdView adView;
            if (getRandomLay() == 1) {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_1, null);
            } else if (getRandomLay() == 2) {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_2, null);
            } else if (getRandomLay() == 3) {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_3, null);
            } else {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_4, null);
            }
            new NativeAdsPopulate(activity).populateNativeMedia(CommonData.google_NativeAds, adView);
            ad_FrameLayout.removeAllViews();
            ad_FrameLayout.addView(adView);

            new GF_NativeAds(activity).preLoadAdmobNative();

        } else if (CommonData.facebook_nativeAd != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.VISIBLE);
            ad_loading.setVisibility(View.GONE);
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
            LinearLayout adView;
            if (getRandomLay() == 1) {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_1, nativeAdLayout, false);
            } else if (getRandomLay() == 2) {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_2, nativeAdLayout, false);
            } else if (getRandomLay() == 3) {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_3, nativeAdLayout, false);
            } else {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_4, nativeAdLayout, false);
            }
            new NativeAdsPopulate(activity).inflateFbNative(CommonData.facebook_nativeAd, nativeAdLayout, adView);

            CommonData.google_NativeAds = null;
            new GF_NativeAds(activity).preLoadAdmobNative();

        } else {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            if (new AdsPreferences(activity).getIsAppsAdShow()) {
                apps_FrameLayout.setVisibility(View.VISIBLE);
                new AppsNativeAds(activity).loadAppsNative(apps_FrameLayout);
            } else {
                ad_loading.setVisibility(View.VISIBLE);
            }

            CommonData.google_NativeAds = null;
            CommonData.facebook_nativeAd = null;
            new GF_NativeAds(activity).preLoadAdmobNative();
        }
    }

    public void FG_Native(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.facebook_nativeAd != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.VISIBLE);
            ad_loading.setVisibility(View.GONE);
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
            LinearLayout adView;
            if (getRandomLay() == 1) {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_1, nativeAdLayout, false);
            } else if (getRandomLay() == 2) {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_2, nativeAdLayout, false);
            } else if (getRandomLay() == 3) {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_3, nativeAdLayout, false);
            } else {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_4, nativeAdLayout, false);
            }
            new NativeAdsPopulate(activity).inflateFbNative(CommonData.facebook_nativeAd, nativeAdLayout, adView);

            new FG_NativeAds(activity).preLoadFbNative();

        } else if (CommonData.google_NativeAds != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.VISIBLE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            com.google.android.gms.ads.nativead.NativeAdView adView;
            if (getRandomLay() == 1) {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_1, null);
            } else if (getRandomLay() == 2) {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_2, null);
            } else if (getRandomLay() == 3) {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_3, null);
            } else {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_4, null);
            }
            new NativeAdsPopulate(activity).populateNativeMedia(CommonData.google_NativeAds, adView);
            ad_FrameLayout.removeAllViews();
            ad_FrameLayout.addView(adView);

            CommonData.facebook_nativeAd = null;
            new FG_NativeAds(activity).preLoadFbNative();

        } else {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            if (new AdsPreferences(activity).getIsAppsAdShow()) {
                apps_FrameLayout.setVisibility(View.VISIBLE);
                new AppsNativeAds(activity).loadAppsNative(apps_FrameLayout);
            } else {
                ad_loading.setVisibility(View.VISIBLE);
            }

            CommonData.google_NativeAds = null;
            CommonData.facebook_nativeAd = null;
            new FG_NativeAds(activity).preLoadFbNative();
        }
    }

    public void ALT_Native(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.isShowedAltAdmobNativeAds) {
            if (CommonData.facebook_nativeAd != null) {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.GONE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.VISIBLE);
                ad_loading.setVisibility(View.GONE);
                Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
                Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
                LinearLayout adView;
                if (getRandomLay() == 1) {
                    adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_1, nativeAdLayout, false);
                } else if (getRandomLay() == 2) {
                    adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_2, nativeAdLayout, false);
                } else if (getRandomLay() == 3) {
                    adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_3, nativeAdLayout, false);
                } else {
                    adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_4, nativeAdLayout, false);
                }
                new NativeAdsPopulate(activity).inflateFbNative(CommonData.facebook_nativeAd, nativeAdLayout, adView);

                new ALT_NativeAds(activity).preLoadFbNative();

            } else if (CommonData.google_NativeAds != null) {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.VISIBLE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.GONE);
                ad_loading.setVisibility(View.GONE);
                com.google.android.gms.ads.nativead.NativeAdView adView;
                if (getRandomLay() == 1) {
                    adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_1, null);
                } else if (getRandomLay() == 2) {
                    adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_2, null);
                } else if (getRandomLay() == 3) {
                    adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_3, null);
                } else {
                    adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_4, null);
                }
                new NativeAdsPopulate(activity).populateNativeMedia(CommonData.google_NativeAds, adView);
                ad_FrameLayout.removeAllViews();
                ad_FrameLayout.addView(adView);

                CommonData.facebook_nativeAd = null;
                new ALT_NativeAds(activity).preLoadFbNative();

            } else {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.GONE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.GONE);
                ad_loading.setVisibility(View.GONE);
                if (new AdsPreferences(activity).getIsAppsAdShow()) {
                    apps_FrameLayout.setVisibility(View.VISIBLE);
                    new AppsNativeAds(activity).loadAppsNative(apps_FrameLayout);
                } else {
                    ad_loading.setVisibility(View.VISIBLE);
                }

                CommonData.google_NativeAds = null;
                CommonData.facebook_nativeAd = null;
                new ALT_NativeAds(activity).preLoadFbNative();
            }
            CommonData.isShowedAltAdmobNativeAds = false;
        } else {
            if (CommonData.google_NativeAds != null) {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.VISIBLE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.GONE);
                ad_loading.setVisibility(View.GONE);
                com.google.android.gms.ads.nativead.NativeAdView adView;
                if (getRandomLay() == 1) {
                    adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_1, null);
                } else if (getRandomLay() == 2) {
                    adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_2, null);
                } else if (getRandomLay() == 3) {
                    adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_3, null);
                } else {
                    adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_4, null);
                }
                new NativeAdsPopulate(activity).populateNativeMedia(CommonData.google_NativeAds, adView);
                ad_FrameLayout.removeAllViews();
                ad_FrameLayout.addView(adView);

                new ALT_NativeAds(activity).preLoadFbNative();

            } else if (CommonData.facebook_nativeAd != null) {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.GONE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.VISIBLE);
                ad_loading.setVisibility(View.GONE);
                Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
                Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
                LinearLayout adView;
                if (getRandomLay() == 1) {
                    adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_1, nativeAdLayout, false);
                } else if (getRandomLay() == 2) {
                    adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_2, nativeAdLayout, false);
                } else if (getRandomLay() == 3) {
                    adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_3, nativeAdLayout, false);
                } else {
                    adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_4, nativeAdLayout, false);
                }
                new NativeAdsPopulate(activity).inflateFbNative(CommonData.facebook_nativeAd, nativeAdLayout, adView);

                CommonData.google_NativeAds = null;
                new ALT_NativeAds(activity).preLoadAdmobNative();

            } else {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.GONE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.GONE);
                ad_loading.setVisibility(View.GONE);
                if (new AdsPreferences(activity).getIsAppsAdShow()) {
                    apps_FrameLayout.setVisibility(View.VISIBLE);
                    new AppsNativeAds(activity).loadAppsNative(apps_FrameLayout);
                } else {
                    ad_loading.setVisibility(View.VISIBLE);
                }

                CommonData.google_NativeAds = null;
                CommonData.facebook_nativeAd = null;
                new ALT_NativeAds(activity).preLoadAdmobNative();
            }
            CommonData.isShowedAltAdmobNativeAds = true;
        }
    }


    //==================== Native Banner Ad =======================
    //==================== Native Banner Ad =======================
    //==================== Native Banner Ad =======================

    public void show_NativeBannerAds(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (new AdsPreferences(activity).getIsAdOn()) {

            String adsPriority = new AdsPreferences(activity).getAdsPriority();
            if (new AdsPreferences(activity).getNativeAdsPreload()) {
                if (adsPriority.equalsIgnoreCase(CommonData.Google)) {
                    G_NativeBannerAds(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook)) {
                    F_NativeBannerAds(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Google_Facebook)) {
                    GF_NativeBannerAds(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook_Google)) {
                    FG_NativeBannerAds(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Alternate)) {
                    ALT_NativeBannerAds(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else {
                    GF_NativeBannerAds(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                }
            } else {
                NativeAdLoaderTimer();
                if (adsPriority.equalsIgnoreCase(CommonData.Google)) {
                    new G_NativeAds(activity).onDemandLoadAdmobNativeBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook)) {
                    new F_NativeAds(activity).onDemandLoadFbNativeBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Google_Facebook)) {
                    new GF_NativeAds(activity).onDemandLoadAdmobNativeBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook_Google)) {
                    new FG_NativeAds(activity).onDemandLoadFbNativeBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Alternate)) {
                    if (CommonData.isShowedAltAdmobNativeBannerAds) {
                        new FG_NativeAds(activity).onDemandLoadFbNativeBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                        CommonData.isShowedAltAdmobNativeBannerAds = false;
                    } else {
                        new GF_NativeAds(activity).onDemandLoadAdmobNativeBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                        CommonData.isShowedAltAdmobNativeBannerAds = true;
                    }
                } else {
                    new GF_NativeAds(activity).onDemandLoadAdmobNativeBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                }
            }
        } else {
            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
        }
    }

    public void G_NativeBannerAds(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.google_NativeBannerAds != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.VISIBLE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            com.google.android.gms.ads.nativead.NativeAdView adView;
            if (getRandomLay() == 1) {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_1, null);
            } else if (getRandomLay() == 2) {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_2, null);
            } else {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_3, null);
            }
            new NativeAdsPopulate(activity).populateNativeBannerMedia(CommonData.google_NativeBannerAds, adView);
            ad_FrameLayout.removeAllViews();
            ad_FrameLayout.addView(adView);

            new G_NativeAds(activity).preLoadAdmobNativeBanner();

        } else {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            if (new AdsPreferences(activity).getIsAppsAdShow()) {
                apps_FrameLayout.setVisibility(View.VISIBLE);
                new AppsNativeAds(activity).loadAppsNativeBanner(apps_FrameLayout);
            } else {
                ad_loading.setVisibility(View.VISIBLE);
            }
            CommonData.google_NativeBannerAds = null;
            new G_NativeAds(activity).preLoadAdmobNativeBanner();
        }
    }

    public void F_NativeBannerAds(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.facebook_nativeBannerAd != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.VISIBLE);
            ad_loading.setVisibility(View.GONE);
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
            LinearLayout adView;
            if (getRandomLay() == 1) {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_1, nativeAdLayout, false);
            } else if (getRandomLay() == 2) {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_2, nativeAdLayout, false);
            } else {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_3, nativeAdLayout, false);
            }
            new NativeAdsPopulate(activity).inflateFbNativeBanner(CommonData.facebook_nativeBannerAd, nativeAdLayout, adView);

            new F_NativeAds(activity).preLoadFbNativeBanner();

        } else {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            if (new AdsPreferences(activity).getIsAppsAdShow()) {
                apps_FrameLayout.setVisibility(View.VISIBLE);
                new AppsNativeAds(activity).loadAppsNativeBanner(apps_FrameLayout);
            } else {
                ad_loading.setVisibility(View.VISIBLE);
            }
            CommonData.facebook_nativeBannerAd = null;
            new F_NativeAds(activity).preLoadFbNativeBanner();
        }
    }

    public void GF_NativeBannerAds(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.google_NativeBannerAds != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.VISIBLE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            com.google.android.gms.ads.nativead.NativeAdView adView;
            if (getRandomLay() == 1) {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_1, null);
            } else if (getRandomLay() == 2) {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_2, null);
            } else {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_3, null);
            }
            new NativeAdsPopulate(activity).populateNativeBannerMedia(CommonData.google_NativeBannerAds, adView);
            ad_FrameLayout.removeAllViews();
            ad_FrameLayout.addView(adView);

            new GF_NativeAds(activity).preLoadAdmobNativeBanner();

        } else if (CommonData.facebook_nativeBannerAd != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.VISIBLE);
            ad_loading.setVisibility(View.GONE);
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
            LinearLayout adView;
            if (getRandomLay() == 1) {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_1, nativeAdLayout, false);
            } else if (getRandomLay() == 2) {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_2, nativeAdLayout, false);
            } else {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_3, nativeAdLayout, false);
            }
            new NativeAdsPopulate(activity).inflateFbNativeBanner(CommonData.facebook_nativeBannerAd, nativeAdLayout, adView);

            CommonData.google_NativeBannerAds = null;
            new GF_NativeAds(activity).preLoadAdmobNativeBanner();

        } else {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            if (new AdsPreferences(activity).getIsAppsAdShow()) {
                apps_FrameLayout.setVisibility(View.VISIBLE);
                new AppsNativeAds(activity).loadAppsNativeBanner(apps_FrameLayout);
            } else {
                ad_loading.setVisibility(View.VISIBLE);
            }

            CommonData.google_NativeBannerAds = null;
            CommonData.facebook_nativeBannerAd = null;
            new GF_NativeAds(activity).preLoadAdmobNativeBanner();
        }
    }

    public void FG_NativeBannerAds(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.facebook_nativeBannerAd != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.VISIBLE);
            ad_loading.setVisibility(View.GONE);
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
            LinearLayout adView;
            if (getRandomLay() == 1) {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_1, nativeAdLayout, false);
            } else if (getRandomLay() == 2) {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_2, nativeAdLayout, false);
            } else {
                adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_3, nativeAdLayout, false);
            }
            new NativeAdsPopulate(activity).inflateFbNativeBanner(CommonData.facebook_nativeBannerAd, nativeAdLayout, adView);

            new FG_NativeAds(activity).preLoadFbNativeBanner();

        } else if (CommonData.google_NativeBannerAds != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.VISIBLE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            com.google.android.gms.ads.nativead.NativeAdView adView;
            if (getRandomLay() == 1) {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_1, null);
            } else if (getRandomLay() == 2) {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_2, null);
            } else {
                adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_3, null);
            }
            new NativeAdsPopulate(activity).populateNativeBannerMedia(CommonData.google_NativeBannerAds, adView);
            ad_FrameLayout.removeAllViews();
            ad_FrameLayout.addView(adView);

            CommonData.facebook_nativeBannerAd = null;
            new FG_NativeAds(activity).preLoadFbNativeBanner();

        } else {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            if (new AdsPreferences(activity).getIsAppsAdShow()) {
                apps_FrameLayout.setVisibility(View.VISIBLE);
                new AppsNativeAds(activity).loadAppsNativeBanner(apps_FrameLayout);
            } else {
                ad_loading.setVisibility(View.VISIBLE);
            }

            CommonData.google_NativeBannerAds = null;
            CommonData.facebook_nativeBannerAd = null;
            new FG_NativeAds(activity).preLoadFbNativeBanner();
        }
    }

    public void ALT_NativeBannerAds(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.isShowedAltAdmobNativeBannerAds) {
            if (CommonData.facebook_nativeBannerAd != null) {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.GONE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.VISIBLE);
                ad_loading.setVisibility(View.GONE);
                Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
                Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
                LinearLayout adView;
                if (getRandomLay() == 1) {
                    adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_1, nativeAdLayout, false);
                } else if (getRandomLay() == 2) {
                    adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_2, nativeAdLayout, false);
                } else {
                    adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_3, nativeAdLayout, false);
                }
                new NativeAdsPopulate(activity).inflateFbNativeBanner(CommonData.facebook_nativeBannerAd, nativeAdLayout, adView);

                new ALT_NativeAds(activity).preLoadFbNativeBanner();

            } else if (CommonData.google_NativeBannerAds != null) {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.VISIBLE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.GONE);
                ad_loading.setVisibility(View.GONE);
                com.google.android.gms.ads.nativead.NativeAdView adView;
                if (getRandomLay() == 1) {
                    adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_1, null);
                } else if (getRandomLay() == 2) {
                    adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_2, null);
                } else {
                    adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_3, null);
                }
                new NativeAdsPopulate(activity).populateNativeBannerMedia(CommonData.google_NativeBannerAds, adView);
                ad_FrameLayout.removeAllViews();
                ad_FrameLayout.addView(adView);

                CommonData.facebook_nativeBannerAd = null;
                new ALT_NativeAds(activity).preLoadFbNativeBanner();

            } else {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.GONE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.GONE);
                ad_loading.setVisibility(View.GONE);
                if (new AdsPreferences(activity).getIsAppsAdShow()) {
                    apps_FrameLayout.setVisibility(View.VISIBLE);
                    new AppsNativeAds(activity).loadAppsNativeBanner(apps_FrameLayout);
                } else {
                    ad_loading.setVisibility(View.VISIBLE);
                }

                CommonData.google_NativeBannerAds = null;
                CommonData.facebook_nativeBannerAd = null;
                new ALT_NativeAds(activity).preLoadFbNativeBanner();
            }
            CommonData.isShowedAltAdmobNativeBannerAds = false;
        } else {
            if (CommonData.google_NativeBannerAds != null) {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.VISIBLE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.GONE);
                ad_loading.setVisibility(View.GONE);
                com.google.android.gms.ads.nativead.NativeAdView adView;
                if (getRandomLay() == 1) {
                    adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_1, null);
                } else if (getRandomLay() == 2) {
                    adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_2, null);
                } else {
                    adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_3, null);
                }
                new NativeAdsPopulate(activity).populateNativeBannerMedia(CommonData.google_NativeBannerAds, adView);
                ad_FrameLayout.removeAllViews();
                ad_FrameLayout.addView(adView);

                new ALT_NativeAds(activity).preLoadFbNativeBanner();

            } else if (CommonData.facebook_nativeBannerAd != null) {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.GONE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.VISIBLE);
                ad_loading.setVisibility(View.GONE);
                Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
                Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
                LinearLayout adView;
                if (getRandomLay() == 1) {
                    adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_1, nativeAdLayout, false);
                } else if (getRandomLay() == 2) {
                    adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_2, nativeAdLayout, false);
                } else {
                    adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_3, nativeAdLayout, false);
                }
                new NativeAdsPopulate(activity).inflateFbNativeBanner(CommonData.facebook_nativeBannerAd, nativeAdLayout, adView);

                CommonData.google_NativeBannerAds = null;
                new ALT_NativeAds(activity).preLoadAdmobNativeBanner();

            } else {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.GONE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.GONE);
                ad_loading.setVisibility(View.GONE);
                if (new AdsPreferences(activity).getIsAppsAdShow()) {
                    apps_FrameLayout.setVisibility(View.VISIBLE);
                    new AppsNativeAds(activity).loadAppsNativeBanner(apps_FrameLayout);
                } else {
                    ad_loading.setVisibility(View.VISIBLE);
                }

                CommonData.google_NativeBannerAds = null;
                CommonData.facebook_nativeBannerAd = null;
                new ALT_NativeAds(activity).preLoadAdmobNativeBanner();
            }
            CommonData.isShowedAltAdmobNativeBannerAds = true;
        }
    }


    //==================== Native Banner Mid Ad =======================
    //==================== Native Banner Mid Ad =======================
    //==================== Native Banner Mid Ad =======================

    public void show_NativeBannerAds2(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (new AdsPreferences(activity).getIsAdOn()) {

            String adsPriority = new AdsPreferences(activity).getAdsPriority();
            if (new AdsPreferences(activity).getNativeAdsPreload()) {
                if (adsPriority.equalsIgnoreCase(CommonData.Google)) {
                    G_NativeBannerAdsMid(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook)) {
                    F_NativeBannerAdsMid(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Google_Facebook)) {
                    GF_NativeBannerAdsMid(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook_Google)) {
                    FG_NativeBannerAdsMid(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Alternate)) {
                    ALT_NativeBannerAdsMid(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else {
                    GF_NativeBannerAdsMid(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                }
            } else {
                NativeAdLoaderTimer();
                if (adsPriority.equalsIgnoreCase(CommonData.Google)) {
                    new G_NativeAds(activity).onDemandLoadAdmobNativeBannerMid(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook)) {
                    new F_NativeAds(activity).onDemandLoadFbNativeBannerMid(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Google_Facebook)) {
                    new GF_NativeAds(activity).onDemandLoadAdmobNativeBannerMid(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else if (adsPriority.equalsIgnoreCase(CommonData.Alternate)) {
                    if (CommonData.isShowedAltAdmobNativeBannerAds2) {
                        new FG_NativeAds(activity).onDemandLoadFbNativeBannerMid(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                        CommonData.isShowedAltAdmobNativeBannerAds2 = false;
                    } else {
                        new GF_NativeAds(activity).onDemandLoadAdmobNativeBannerMid(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                        CommonData.isShowedAltAdmobNativeBannerAds2 = true;
                    }
                } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook_Google)) {
                    new FG_NativeAds(activity).onDemandLoadFbNativeBannerMid(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                } else {
                    new GF_NativeAds(activity).onDemandLoadAdmobNativeBannerMid(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                }
            }
        } else {
            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
        }
    }

    public void G_NativeBannerAdsMid(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.google_NativeBannerAds2 != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.VISIBLE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            com.google.android.gms.ads.nativead.NativeAdView adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner2, null);
            new NativeAdsPopulate(activity).populateNativeNoMedia(CommonData.google_NativeBannerAds2, adView);
            ad_FrameLayout.removeAllViews();
            ad_FrameLayout.addView(adView);

            new G_NativeAds(activity).preLoadAdmobNativeBannerMid();

        } else {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            if (new AdsPreferences(activity).getIsAppsAdShow()) {
                apps_FrameLayout.setVisibility(View.VISIBLE);
                new AppsNativeAds(activity).loadAppsNativeBanner2(apps_FrameLayout);
            } else {
                ad_loading.setVisibility(View.VISIBLE);
            }
            CommonData.google_NativeBannerAds2 = null;
            new G_NativeAds(activity).preLoadAdmobNativeBannerMid();
        }
    }

    public void F_NativeBannerAdsMid(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.facebook_nativeBannerAd2 != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.VISIBLE);
            ad_loading.setVisibility(View.GONE);
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
            LinearLayout adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner2, nativeAdLayout, false);
            new NativeAdsPopulate(activity).inflateFbNativeBannerMid(CommonData.facebook_nativeBannerAd2, nativeAdLayout, adView);

            new F_NativeAds(activity).preLoadFbNativeBannerMid();

        } else {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            if (new AdsPreferences(activity).getIsAppsAdShow()) {
                apps_FrameLayout.setVisibility(View.VISIBLE);
                new AppsNativeAds(activity).loadAppsNativeBanner2(apps_FrameLayout);
            } else {
                ad_loading.setVisibility(View.VISIBLE);
            }
            CommonData.facebook_nativeBannerAd2 = null;
            new F_NativeAds(activity).preLoadFbNativeBannerMid();
        }
    }

    public void GF_NativeBannerAdsMid(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.google_NativeBannerAds2 != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.VISIBLE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            com.google.android.gms.ads.nativead.NativeAdView adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner2, null);
            new NativeAdsPopulate(activity).populateNativeNoMedia(CommonData.google_NativeBannerAds2, adView);
            ad_FrameLayout.removeAllViews();
            ad_FrameLayout.addView(adView);

            new GF_NativeAds(activity).preLoadAdmobNativeBannerMid();

        } else if (CommonData.facebook_nativeBannerAd2 != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.VISIBLE);
            ad_loading.setVisibility(View.GONE);
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
            LinearLayout adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner2, nativeAdLayout, false);
            new NativeAdsPopulate(activity).inflateFbNativeBannerMid(CommonData.facebook_nativeBannerAd2, nativeAdLayout, adView);

            CommonData.google_NativeBannerAds2 = null;
            new GF_NativeAds(activity).preLoadAdmobNativeBannerMid();

        } else {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            if (new AdsPreferences(activity).getIsAppsAdShow()) {
                apps_FrameLayout.setVisibility(View.VISIBLE);
                new AppsNativeAds(activity).loadAppsNativeBanner2(apps_FrameLayout);
            } else {
                ad_loading.setVisibility(View.VISIBLE);
            }

            CommonData.google_NativeBannerAds2 = null;
            CommonData.facebook_nativeBannerAd2 = null;
            new GF_NativeAds(activity).preLoadAdmobNativeBannerMid();
        }
    }

    public void FG_NativeBannerAdsMid(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.facebook_nativeBannerAd2 != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.VISIBLE);
            ad_loading.setVisibility(View.GONE);
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
            LinearLayout adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner2, nativeAdLayout, false);
            new NativeAdsPopulate(activity).inflateFbNativeBannerMid(CommonData.facebook_nativeBannerAd2, nativeAdLayout, adView);

            new FG_NativeAds(activity).preLoadFbNativeBannerMid();

        } else if (CommonData.google_NativeBannerAds2 != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.VISIBLE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            com.google.android.gms.ads.nativead.NativeAdView adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner2, null);
            new NativeAdsPopulate(activity).populateNativeNoMedia(CommonData.google_NativeBannerAds2, adView);
            ad_FrameLayout.removeAllViews();
            ad_FrameLayout.addView(adView);

            CommonData.facebook_nativeBannerAd2 = null;
            new FG_NativeAds(activity).preLoadFbNativeBannerMid();

        } else {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            if (new AdsPreferences(activity).getIsAppsAdShow()) {
                apps_FrameLayout.setVisibility(View.VISIBLE);
                new AppsNativeAds(activity).loadAppsNativeBanner2(apps_FrameLayout);
            } else {
                ad_loading.setVisibility(View.VISIBLE);
            }

            CommonData.google_NativeBannerAds2 = null;
            CommonData.facebook_nativeBannerAd2 = null;
            new FG_NativeAds(activity).preLoadFbNativeBannerMid();
        }
    }

    public void ALT_NativeBannerAdsMid(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.isShowedAltAdmobNativeBannerAds2) {
            if (CommonData.facebook_nativeBannerAd2 != null) {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.GONE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.VISIBLE);
                ad_loading.setVisibility(View.GONE);
                Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
                Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
                LinearLayout adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner2, nativeAdLayout, false);
                new NativeAdsPopulate(activity).inflateFbNativeBannerMid(CommonData.facebook_nativeBannerAd2, nativeAdLayout, adView);

                new ALT_NativeAds(activity).preLoadFbNativeBannerMid();

            } else if (CommonData.google_NativeBannerAds2 != null) {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.VISIBLE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.GONE);
                ad_loading.setVisibility(View.GONE);
                com.google.android.gms.ads.nativead.NativeAdView adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner2, null);
                new NativeAdsPopulate(activity).populateNativeNoMedia(CommonData.google_NativeBannerAds2, adView);
                ad_FrameLayout.removeAllViews();
                ad_FrameLayout.addView(adView);

                CommonData.facebook_nativeBannerAd2 = null;
                new ALT_NativeAds(activity).preLoadFbNativeBannerMid();

            } else {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.GONE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.GONE);
                ad_loading.setVisibility(View.GONE);
                if (new AdsPreferences(activity).getIsAppsAdShow()) {
                    apps_FrameLayout.setVisibility(View.VISIBLE);
                    new AppsNativeAds(activity).loadAppsNativeBanner2(apps_FrameLayout);
                } else {
                    ad_loading.setVisibility(View.VISIBLE);
                }

                CommonData.google_NativeBannerAds2 = null;
                CommonData.facebook_nativeBannerAd2 = null;
                new ALT_NativeAds(activity).preLoadFbNativeBannerMid();
            }
            CommonData.isShowedAltAdmobNativeBannerAds2 = false;
        } else {
            if (CommonData.google_NativeBannerAds2 != null) {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.VISIBLE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.GONE);
                ad_loading.setVisibility(View.GONE);
                com.google.android.gms.ads.nativead.NativeAdView adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner2, null);
                new NativeAdsPopulate(activity).populateNativeNoMedia(CommonData.google_NativeBannerAds2, adView);
                ad_FrameLayout.removeAllViews();
                ad_FrameLayout.addView(adView);

                new ALT_NativeAds(activity).preLoadFbNativeBannerMid();

            } else if (CommonData.facebook_nativeBannerAd2 != null) {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.GONE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.VISIBLE);
                ad_loading.setVisibility(View.GONE);
                Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
                Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
                LinearLayout adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner2, nativeAdLayout, false);
                new NativeAdsPopulate(activity).inflateFbNativeBannerMid(CommonData.facebook_nativeBannerAd2, nativeAdLayout, adView);

                CommonData.google_NativeBannerAds2 = null;
                new ALT_NativeAds(activity).preLoadAdmobNativeBannerMid();

            } else {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.GONE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.GONE);
                ad_loading.setVisibility(View.GONE);
                if (new AdsPreferences(activity).getIsAppsAdShow()) {
                    apps_FrameLayout.setVisibility(View.VISIBLE);
                    new AppsNativeAds(activity).loadAppsNativeBanner2(apps_FrameLayout);
                } else {
                    ad_loading.setVisibility(View.VISIBLE);
                }

                CommonData.google_NativeBannerAds2 = null;
                CommonData.facebook_nativeBannerAd2 = null;
                new ALT_NativeAds(activity).preLoadAdmobNativeBannerMid();
            }
            CommonData.isShowedAltAdmobNativeBannerAds2 = true;
        }
    }


    //==================== Native Bottom Banner Ad =======================
    //==================== Native Bottom Banner Ad =======================
    //==================== Native Bottom Banner Ad =======================

    public void show_NativeBottomFlag(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (new AdsPreferences(activity).getIsAdOn()) {
            if (new AdsPreferences(activity).getShowNativeBottom()) {
                show_NativeBottomBannerAds(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
            }
        } else {
            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
        }
    }

    public void show_NativeBottomBannerAds(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {

        String adsPriority = new AdsPreferences(activity).getAdsPriority();
        if (new AdsPreferences(activity).getNativeAdsPreload()) {
            if (adsPriority.equalsIgnoreCase(CommonData.Google)) {
                G_NativeBottomBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
            } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook)) {
                F_NativeBottomBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
            } else if (adsPriority.equalsIgnoreCase(CommonData.Google_Facebook)) {
                GF_NativeBottomBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
            } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook_Google)) {
                FG_NativeBottomBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
            } else if (adsPriority.equalsIgnoreCase(CommonData.Alternate)) {
                ALT_NativeBottomBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
            } else {
                GF_NativeBottomBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
            }
        } else {
            if (adsPriority.equalsIgnoreCase(CommonData.Google)) {
                new G_NativeAds(activity).onDemandLoadAdmobNativeBottomBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
            } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook)) {
                new F_NativeAds(activity).onDemandLoadFbNativeBottomBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
            } else if (adsPriority.equalsIgnoreCase(CommonData.Google_Facebook)) {
                new GF_NativeAds(activity).onDemandLoadAdmobNativeBottomBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
            } else if (adsPriority.equalsIgnoreCase(CommonData.Alternate)) {
                if (CommonData.isShowedAltAdmobNativeBottomBannerAds) {
                    new FG_NativeAds(activity).onDemandLoadFbNativeBottomBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                    CommonData.isShowedAltAdmobNativeBottomBannerAds = false;
                } else {
                    new GF_NativeAds(activity).onDemandLoadAdmobNativeBottomBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                    CommonData.isShowedAltAdmobNativeBottomBannerAds = true;
                }
            } else if (adsPriority.equalsIgnoreCase(CommonData.Facebook_Google)) {
                new FG_NativeAds(activity).onDemandLoadFbNativeBottomBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
            } else {
                new GF_NativeAds(activity).onDemandLoadAdmobNativeBottomBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
            }
        }
    }

    public void G_NativeBottomBanner(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.google_NativeBottomBannerAds != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.VISIBLE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            com.google.android.gms.ads.nativead.NativeAdView adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_bottom_banner, null);
            new NativeAdsPopulate(activity).populateNativeNoMedia(CommonData.google_NativeBottomBannerAds, adView);
            ad_FrameLayout.removeAllViews();
            ad_FrameLayout.addView(adView);

            new G_NativeAds(activity).preLoadAdmobNativeBottomBanner();

        } else {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            if (new AdsPreferences(activity).getIsAppsAdShow()) {
                apps_FrameLayout.setVisibility(View.VISIBLE);
                new AppsNativeAds(activity).loadAppsNativeBottomBanner(apps_FrameLayout);
            } else {
                ad_loading.setVisibility(View.VISIBLE);
            }
            CommonData.google_NativeBottomBannerAds = null;
            new G_NativeAds(activity).preLoadAdmobNativeBottomBanner();
        }
    }

    public void F_NativeBottomBanner(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.facebook_nativeBottomBannerAd != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.VISIBLE);
            ad_loading.setVisibility(View.GONE);
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
            LinearLayout adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_bottom_banner, nativeAdLayout, false);
            new NativeAdsPopulate(activity).inflateFbNativeBottomBanner(CommonData.facebook_nativeBottomBannerAd, nativeAdLayout, adView);

            new F_NativeAds(activity).preLoadFbNativeBottomBanner();

        } else {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            if (new AdsPreferences(activity).getIsAppsAdShow()) {
                apps_FrameLayout.setVisibility(View.VISIBLE);
                new AppsNativeAds(activity).loadAppsNativeBottomBanner(apps_FrameLayout);
            } else {
                ad_loading.setVisibility(View.VISIBLE);
            }
            CommonData.facebook_nativeBottomBannerAd = null;
            new F_NativeAds(activity).preLoadFbNativeBottomBanner();
        }
    }

    public void GF_NativeBottomBanner(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.google_NativeBottomBannerAds != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.VISIBLE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            com.google.android.gms.ads.nativead.NativeAdView adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_bottom_banner, null);
            new NativeAdsPopulate(activity).populateNativeNoMedia(CommonData.google_NativeBottomBannerAds, adView);
            ad_FrameLayout.removeAllViews();
            ad_FrameLayout.addView(adView);

            new GF_NativeAds(activity).preLoadAdmobNativeBottomBanner();

        } else if (CommonData.facebook_nativeBottomBannerAd != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.VISIBLE);
            ad_loading.setVisibility(View.GONE);
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
            LinearLayout adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_bottom_banner, nativeAdLayout, false);
            new NativeAdsPopulate(activity).inflateFbNativeBottomBanner(CommonData.facebook_nativeBottomBannerAd, nativeAdLayout, adView);

            CommonData.google_NativeBottomBannerAds = null;
            new GF_NativeAds(activity).preLoadAdmobNativeBottomBanner();

        } else {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            if (new AdsPreferences(activity).getIsAppsAdShow()) {
                apps_FrameLayout.setVisibility(View.VISIBLE);
                new AppsNativeAds(activity).loadAppsNativeBottomBanner(apps_FrameLayout);
            } else {
                ad_loading.setVisibility(View.VISIBLE);
            }

            CommonData.google_NativeBottomBannerAds = null;
            CommonData.facebook_nativeBottomBannerAd = null;
            new GF_NativeAds(activity).preLoadAdmobNativeBottomBanner();
        }
    }

    public void FG_NativeBottomBanner(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.facebook_nativeBottomBannerAd != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.VISIBLE);
            ad_loading.setVisibility(View.GONE);
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
            Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
            LinearLayout adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_bottom_banner, nativeAdLayout, false);
            new NativeAdsPopulate(activity).inflateFbNativeBottomBanner(CommonData.facebook_nativeBottomBannerAd, nativeAdLayout, adView);

            new FG_NativeAds(activity).preLoadFbNativeBottomBanner();

        } else if (CommonData.google_NativeBottomBannerAds != null) {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.VISIBLE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            com.google.android.gms.ads.nativead.NativeAdView adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_bottom_banner, null);
            new NativeAdsPopulate(activity).populateNativeNoMedia(CommonData.google_NativeBottomBannerAds, adView);
            ad_FrameLayout.removeAllViews();
            ad_FrameLayout.addView(adView);

            CommonData.facebook_nativeBottomBannerAd = null;
            new FG_NativeAds(activity).preLoadFbNativeBottomBanner();

        } else {

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.GONE);
            if (new AdsPreferences(activity).getIsAppsAdShow()) {
                apps_FrameLayout.setVisibility(View.VISIBLE);
                new AppsNativeAds(activity).loadAppsNativeBottomBanner(apps_FrameLayout);
            } else {
                ad_loading.setVisibility(View.VISIBLE);
            }

            CommonData.google_NativeBottomBannerAds = null;
            CommonData.facebook_nativeBottomBannerAd = null;
            new FG_NativeAds(activity).preLoadFbNativeBottomBanner();
        }
    }

    public void ALT_NativeBottomBanner(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        if (CommonData.isShowedAltAdmobNativeBottomBannerAds) {
            if (CommonData.facebook_nativeBottomBannerAd != null) {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.GONE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.VISIBLE);
                ad_loading.setVisibility(View.GONE);
                Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
                Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
                LinearLayout adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_bottom_banner, nativeAdLayout, false);
                new NativeAdsPopulate(activity).inflateFbNativeBottomBanner(CommonData.facebook_nativeBottomBannerAd, nativeAdLayout, adView);

                new ALT_NativeAds(activity).preLoadFbNativeBottomBanner();

            } else if (CommonData.google_NativeBottomBannerAds != null) {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.VISIBLE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.GONE);
                ad_loading.setVisibility(View.GONE);
                com.google.android.gms.ads.nativead.NativeAdView adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_bottom_banner, null);
                new NativeAdsPopulate(activity).populateNativeNoMedia(CommonData.google_NativeBottomBannerAds, adView);
                ad_FrameLayout.removeAllViews();
                ad_FrameLayout.addView(adView);

                CommonData.facebook_nativeBottomBannerAd = null;
                new ALT_NativeAds(activity).preLoadFbNativeBottomBanner();

            } else {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.GONE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.GONE);
                ad_loading.setVisibility(View.GONE);
                if (new AdsPreferences(activity).getIsAppsAdShow()) {
                    apps_FrameLayout.setVisibility(View.VISIBLE);
                    new AppsNativeAds(activity).loadAppsNativeBottomBanner(apps_FrameLayout);
                } else {
                    ad_loading.setVisibility(View.VISIBLE);
                }

                CommonData.google_NativeBottomBannerAds = null;
                CommonData.facebook_nativeBottomBannerAd = null;
                new ALT_NativeAds(activity).preLoadFbNativeBottomBanner();
            }
            CommonData.isShowedAltAdmobNativeBottomBannerAds = true;
        } else {
            if (CommonData.google_NativeBottomBannerAds != null) {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.VISIBLE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.GONE);
                ad_loading.setVisibility(View.GONE);
                com.google.android.gms.ads.nativead.NativeAdView adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_bottom_banner, null);
                new NativeAdsPopulate(activity).populateNativeNoMedia(CommonData.google_NativeBottomBannerAds, adView);
                ad_FrameLayout.removeAllViews();
                ad_FrameLayout.addView(adView);

                new ALT_NativeAds(activity).preLoadFbNativeBottomBanner();

            } else if (CommonData.facebook_nativeBottomBannerAd != null) {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.GONE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.VISIBLE);
                ad_loading.setVisibility(View.GONE);
                Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> pre_loadFacebook --> Show");
                Log.i(CommonData.TAG, "Ads Priority --> " + "Facebook_NativeAds --> -----");
                LinearLayout adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_bottom_banner, nativeAdLayout, false);
                new NativeAdsPopulate(activity).inflateFbNativeBottomBanner(CommonData.facebook_nativeBottomBannerAd, nativeAdLayout, adView);

                CommonData.google_NativeBottomBannerAds = null;
                new ALT_NativeAds(activity).preLoadAdmobNativeBottomBanner();

            } else {

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.GONE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.GONE);
                ad_loading.setVisibility(View.GONE);
                if (new AdsPreferences(activity).getIsAppsAdShow()) {
                    apps_FrameLayout.setVisibility(View.VISIBLE);
                    new AppsNativeAds(activity).loadAppsNativeBottomBanner(apps_FrameLayout);
                } else {
                    ad_loading.setVisibility(View.VISIBLE);
                }

                CommonData.google_NativeBottomBannerAds = null;
                CommonData.facebook_nativeBottomBannerAd = null;
                new ALT_NativeAds(activity).preLoadAdmobNativeBottomBanner();
            }
            CommonData.isShowedAltAdmobNativeBottomBannerAds = true;
        }
    }


    //================= Common Methodes ==========================//
    //================= Common Methodes ==========================//
    //================= Common Methodes ==========================//

    public Integer getRandomLay() {
        return new Random().nextInt(4);
    }

    public void NativeAdLoaderTimer() {
        if (new AdsPreferences(activity).getIsNativeLoader()) {
            if (new AdsPreferences(activity).getLoaderTime() != 0) {
                if (adsDialog != null) {
                    adsDialog.dismiss();
                }
                adsDialog = new Dialog(activity);
                adsDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                adsDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                adsDialog.setCancelable(false);
                adsDialog.setContentView(R.layout.ad_loading);
                adsDialog.show();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        adsDialog.dismiss();
                    }
                }, new AdsPreferences(activity).getLoaderTime() * 1000);
            }
        }
    }

    public void NativeAdLoaderOnLoad() {
        if (new AdsPreferences(activity).getLoaderTime() == 0) {
            if (adsDialog != null) {
                adsDialog.dismiss();
            }
            adsDialog = new Dialog(activity);
            adsDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            adsDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
            adsDialog.setCancelable(false);
            adsDialog.setContentView(R.layout.ad_loading);
            if (new AdsPreferences(activity).getIsNativeLoader()) {
                adsDialog.show();
            }
        }
    }

    public void NativeDialogDismiss() {
        if (new AdsPreferences(activity).getLoaderTime() == 0) {
            if (adsDialog != null) {
                adsDialog.dismiss();
            }
        }
    }



    public void showBottomNativeAdsDialog() {
        bottomSheetDialog = new BottomSheetDialog(activity);
        bottomSheetDialog = new BottomSheetDialog(activity, R.style.BottomSheetDialogTheme);

        bottomSheetDialog.setContentView(R.layout.buttomnbative_adsdilog);

        ImageView doun = bottomSheetDialog.findViewById(R.id.doun);

        doun.setOnClickListener(view -> {
            bottomSheetDialog.dismiss();
        });

        new NativeAdManager(activity).show_NativeAds(bottomSheetDialog.findViewById(R.id.apps_FrameLayout),
                bottomSheetDialog.findViewById(R.id.ad_FrameLayout), bottomSheetDialog.findViewById(R.id.applovin_FrameLayout), bottomSheetDialog.findViewById(R.id.nativeAdLayout),
                bottomSheetDialog.findViewById(R.id.ad_loading));

        if (!bottomSheetDialog.isShowing()) {
            bottomSheetDialog.show();
        }
        bottomSheetDialog.setCancelable(false);
    }

}
