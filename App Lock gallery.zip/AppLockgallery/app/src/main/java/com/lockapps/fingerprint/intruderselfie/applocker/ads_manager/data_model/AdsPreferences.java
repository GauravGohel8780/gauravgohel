package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public class AdsPreferences {

    public static final String USER_PREFS = "USER_PREFS";
    public SharedPreferences appSharedPref;
    public SharedPreferences.Editor prefEditor;

    public String adsClickCount = "ads_click_count";      //Integer
    public String adsTimeCount = "ads_time_count";      //Integer

    public String appPackage = "app_package";      //String
    public String isAppLive = "is_app_live";      //Boolean
    public String appRedirectLink = "app_redirect_link";      //String
    public String btnColorFlag = "btn_color_flag";      //String
    public String btnColor = "btn_color";      //String
    public String isTimer = "is_timer";      //Boolean
    public String isAdOn = "is_ad_on";      //Boolean
    public String isMediaOn = "is_media_on";      //Boolean
    public String adsClick = "ads_click";      //Integer
    public String adsTime = "ads_time";      //Integer
    public String adsPreload = "ads_preload";      //Boolean
    public String isNativeLoader = "is_native_loader";      //Boolean
    public String loaderTime = "loader_time";      //Boolean
    public String nativeAdsPreload = "native_ads_preload";      //Boolean
    public String adsOnback = "ads_onback";      //Boolean
    public String showAdFirstPage = "show_ad_first_page";      //Boolean
    public String isAppsAdShow = "is_apps_ad_show";      //Boolean
    public String showNativeBottom = "show_native_bottom";      //Boolean
    public String showSplashInterstitial = "show_splash_interstitial";      //Boolean
    public String adsPriority = "ads_priority";      //String
    public String privacyUrl = "privacy_url";      //String
    public String admobAppOpen = "admob_app_open";      //String
    public String admobBanner = "admob_banner";      //String
    public String admobInterstitial = "admob_interstitial";      //String
    public String admobNative = "admob_native";      //String
    public String admobNativeBanner = "admob_native_banner";      //String
    public String adxAppOpen = "adx_app_open";      //String
    public String adxBanner = "adx_banner";      //String
    public String adxInterstitial = "adx_interstitial";      //String
    public String adxNative = "adx_native";      //String
    public String adxNativeBanner = "adx_native_banner";      //String
    public String facebookBanner = "facebook_banner";      //String
    public String facebookInterstitial = "facebook_interstitial";      //String
    public String facebookNative = "facebook_native";      //String
    public String facebookNativeBanner = "facebook_native_banner";      //String
    public String appsBanner = "apps_banner";      //String
    public String appsBody = "apps_body";      //String
    public String appsHeadline = "apps_headline";      //String
    public String appsIcon = "apps_icon";      //String
    public String appsLink = "apps_link";      //String

    public String serverFlag = "server_flag";      //Boolean
    public String serverBaseUrl = "server_base_url";      //String
    public String serverCarrierid = "server_carrierid";      //String
    public String serverCountryList = "server_country_list";      //String
    public String serverCountry = "server_country";      //String


    public AdsPreferences(Context context) {
        appSharedPref = context.getSharedPreferences(USER_PREFS, Activity.MODE_PRIVATE);
        prefEditor = appSharedPref.edit();
    }


    public String getAppPackage() {
        return appSharedPref.getString(appPackage, "");
    }

    public void setAppPackage(String value) {
        prefEditor.putString(appPackage, value).apply();
    }

    public boolean getIsAppLive() {
        return appSharedPref.getBoolean(isAppLive, true);
    }

    public void setIsAppLive(boolean value) {
        prefEditor.putBoolean(isAppLive, value).apply();
    }

    public String getAppRedirectLink() {
        return appSharedPref.getString(appRedirectLink, "");
    }

    public void setAppRedirectLink(String value) {
        prefEditor.putString(appRedirectLink, value).apply();
    }

    public boolean getBtnColorFlag() {
        return appSharedPref.getBoolean(btnColorFlag, false);
    }

    public void setBtnColorFlag(boolean value) {
        prefEditor.putBoolean(btnColorFlag, value).apply();
    }

    public String getBtnColor() {
        return appSharedPref.getString(btnColor, "");
    }

    public void setBtnColor(String value) {
        prefEditor.putString(btnColor, value).apply();
        ;
    }

    public boolean getIsTimer() {
        return appSharedPref.getBoolean(isTimer, false);
    }

    public void setIsTimer(boolean value) {
        prefEditor.putBoolean(isTimer, value).apply();
    }

    public boolean getIsAdOn() {
        return appSharedPref.getBoolean(isAdOn, false);
    }

    public void setIsAdOn(boolean value) {
        prefEditor.putBoolean(isAdOn, value).apply();
    }

    public boolean getisMediaOn() {
        return appSharedPref.getBoolean(isMediaOn, false);
    }

    public void setisMediaOn(boolean value) {
        prefEditor.putBoolean(isMediaOn, value).apply();
    }

    public Integer getAdsClick() {
        return appSharedPref.getInt(adsClick, 0);
    }

    public void setAdsClick(Integer value) {
        prefEditor.putInt(adsClick, value).apply();
    }

    public Integer getAdsTime() {
        return appSharedPref.getInt(adsTime, 0);
    }

    public void setAdsTime(Integer value) {
        prefEditor.putInt(adsTime, value).apply();
    }

    public Integer getLoaderTime() {
        return appSharedPref.getInt(loaderTime, 0);
    }

    public void setLoaderTime(Integer value) {
        prefEditor.putInt(loaderTime, value).apply();
    }

    public boolean getAdsPreload() {
        return appSharedPref.getBoolean(adsPreload, false);
    }

    public void setAdsPreload(boolean value) {
        prefEditor.putBoolean(adsPreload, value).apply();
    }

    public boolean getIsNativeLoader() {
        return appSharedPref.getBoolean(isNativeLoader, false);
    }

    public void setIsNativeLoader(boolean value) {
        prefEditor.putBoolean(isNativeLoader, value).apply();
    }

    public boolean getNativeAdsPreload() {
        return appSharedPref.getBoolean(nativeAdsPreload, false);
    }

    public void setNativeAdsPreload(boolean value) {
        prefEditor.putBoolean(nativeAdsPreload, value).apply();
    }

    public boolean getAdsOnback() {
        return appSharedPref.getBoolean(adsOnback, false);
    }

    public void setAdsOnback(boolean value) {
        prefEditor.putBoolean(adsOnback, value).apply();
    }

    public boolean getShowAdFirstPage() {
        return appSharedPref.getBoolean(showAdFirstPage, false);
    }

    public void setShowAdFirstPage(boolean value) {
        prefEditor.putBoolean(showAdFirstPage, value).apply();
    }

    public boolean getIsAppsAdShow() {
        return appSharedPref.getBoolean(isAppsAdShow, false);
    }

    public void setIsAppsAdShow(boolean value) {
        prefEditor.putBoolean(isAppsAdShow, value).apply();
    }

    public boolean getShowNativeBottom() {
        return appSharedPref.getBoolean(showNativeBottom, false);
    }

    public void setShowNativeBottom(boolean value) {
        prefEditor.putBoolean(showNativeBottom, value).apply();
    }

    public boolean getShowSplashInterstitial() {
        return appSharedPref.getBoolean(showSplashInterstitial, false);
    }

    public void setShowSplashInterstitial(boolean value) {
        prefEditor.putBoolean(showSplashInterstitial, value).apply();
    }

    public String getAdsPriority() {
        return appSharedPref.getString(adsPriority, "");
    }

    public void setAdsPriority(String value) {
        prefEditor.putString(adsPriority, value).apply();
    }

    public String getPrivacyUrl() {
        return appSharedPref.getString(privacyUrl, "");
    }

    public void setPrivacyUrl(String value) {
        prefEditor.putString(privacyUrl, value).apply();
        ;
    }

    public String getAdmobAppOpen() {
        return appSharedPref.getString(admobAppOpen, "");
    }

    public void setAdmobAppOpen(String value) {
        prefEditor.putString(admobAppOpen, value).apply();
    }

    public String getAdmobBanner() {
        return appSharedPref.getString(admobBanner, "");
    }

    public void setAdmobBanner(String value) {
        prefEditor.putString(admobBanner, value).apply();
        ;
    }

    public String getAdmobInterstitial() {
        return appSharedPref.getString(admobInterstitial, "");
    }

    public void setAdmobInterstitial(String value) {
        prefEditor.putString(admobInterstitial, value).apply();
    }

    public String getAdmobNative() {
        return appSharedPref.getString(admobNative, "");
    }

    public void setAdmobNative(String value) {
        prefEditor.putString(admobNative, value).apply();
    }

    public String getAdmobNativeBanner() {
        return appSharedPref.getString(admobNativeBanner, "");
    }

    public void setAdmobNativeBanner(String value) {
        prefEditor.putString(admobNativeBanner, value).apply();
    }

    public String getAdxAppOpen() {
        return appSharedPref.getString(adxAppOpen, "");
    }

    public void setAdxAppOpen(String value) {
        prefEditor.putString(adxAppOpen, value).apply();
    }

    public String getAdxBanner() {
        return appSharedPref.getString(adxBanner, "");
    }

    public void setAdxBanner(String value) {
        prefEditor.putString(adxBanner, value).apply();
    }

    public String getAdxInterstitial() {
        return appSharedPref.getString(adxInterstitial, "");
    }

    public void setAdxInterstitial(String value) {
        prefEditor.putString(adxInterstitial, value).apply();
    }

    public String getAdxNative() {
        return appSharedPref.getString(adxNative, "");
    }

    public void setAdxNative(String value) {
        prefEditor.putString(adxNative, value).apply();
    }

    public String getAdxNativeBanner() {
        return appSharedPref.getString(adxNativeBanner, "");
    }

    public void setAdxNativeBanner(String value) {
        prefEditor.putString(adxNativeBanner, value).apply();
    }

    public String getFacebookBanner() {
        return appSharedPref.getString(facebookBanner, "");
    }

    public void setFacebookBanner(String value) {
        prefEditor.putString(facebookBanner, value).apply();
    }

    public String getFacebookInterstitial() {
        return appSharedPref.getString(facebookInterstitial, "");
    }

    public void setFacebookInterstitial(String value) {
        prefEditor.putString(facebookInterstitial, value).apply();
    }

    public String getFacebookNative() {
        return appSharedPref.getString(facebookNative, "");
    }

    public void setFacebookNative(String value) {
        prefEditor.putString(facebookNative, value).apply();
    }

    public String getFacebookNativeBanner() {
        return appSharedPref.getString(facebookNativeBanner, "");
    }

    public void setFacebookNativeBanner(String value) {
        prefEditor.putString(facebookNativeBanner, value).apply();
    }

    public String getAppsBanner() {
        return appSharedPref.getString(appsBanner, "");
    }

    public void setAppsBanner(String value) {
        prefEditor.putString(appsBanner, value).apply();
    }

    public String getAppsBody() {
        return appSharedPref.getString(appsBody, "");
    }

    public void setAppsBody(String value) {
        prefEditor.putString(appsBody, value).apply();
    }

    public String getAppsHeadline() {
        return appSharedPref.getString(appsHeadline, "");
    }

    public void setAppsHeadline(String value) {
        prefEditor.putString(appsHeadline, value).apply();
    }

    public String getAppsIcon() {
        return appSharedPref.getString(appsIcon, "");
    }

    public void setAppsIcon(String value) {
        prefEditor.putString(appsIcon, value).apply();
    }

    public String getAppsLink() {
        return appSharedPref.getString(appsLink, "");
    }

    public void setAppsLink(String value) {
        prefEditor.putString(appsLink, value).apply();
    }


    public Integer getAdsClickCount() {
        return appSharedPref.getInt(adsClickCount, 0);
    }

    public void setAdsClickCount(Integer value) {
        prefEditor.putInt(adsClickCount, value).apply();
    }

    public Integer getAdsTimeCount() {
        return appSharedPref.getInt(adsTimeCount, 0);
    }

    public void setAdsTimeCount(Integer value) {
        prefEditor.putInt(adsTimeCount, value).apply();
    }


    public boolean getServerFlag() {
        return appSharedPref.getBoolean(serverFlag, false);
    }

    public void setServerFlag(boolean value) {
        prefEditor.putBoolean(serverFlag, value).apply();
    }

    public String getServerBaseUrl() {
        return appSharedPref.getString(serverBaseUrl, "");
    }

    public void setServerBaseUrl(String value) {
        prefEditor.putString(serverBaseUrl, value).apply();
    }

    public String getServerCarrierid() {
        return appSharedPref.getString(serverCarrierid, "");
    }

    public void setServerCarrierid(String value) {
        prefEditor.putString(serverCarrierid, value).apply();
    }

    public String getServerCountryList() {
        return appSharedPref.getString(serverCountryList, "");
    }

    public void setServerCountryList(String value) {
        prefEditor.putString(serverCountryList, value).apply();
    }

    public String getServerCountry() {
        return appSharedPref.getString(serverCountry, "");
    }

    public void setServerCountry(String value) {
        prefEditor.putString(serverCountry, value).apply();
    }

}