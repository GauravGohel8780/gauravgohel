package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.internet;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.app_open_ad.AOM_Activity;


public class NetworkConnection extends BroadcastReceiver {

    Dialog dialog;

    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            if (!isNetworkConnected(context)) {

                dialog = new Dialog(context);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                dialog.setContentView(R.layout.no_internet);
                dialog.setCancelable(false);
                Window window = dialog.getWindow();
                WindowManager.LayoutParams attributes = window.getAttributes();
                attributes.gravity = Gravity.CENTER;
                window.setAttributes(attributes);

                dialog.show();

                TextView retry = dialog.findViewById(R.id.retry);

                retry.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        if (isNetworkConnected(context)) {
                            if (dialog != null) {
                                dialog.dismiss();
                            }
                        }
                    }
                });

            } else if (isNetworkConnected(context)) {
                int colorFrom = context.getResources().getColor(R.color.in_red);
                int colorTo = context.getResources().getColor(R.color.in_green);

                TextView offline = dialog.findViewById(R.id.offline);
                ValueAnimator colorAnimation = ValueAnimator.ofObject(new ArgbEvaluator(), colorFrom, colorTo);
                colorAnimation.setDuration(500); // milliseconds
                colorAnimation.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {

                    @Override
                    public void onAnimationUpdate(ValueAnimator animator) {
                        offline.setText("Internet Connected Successfully");
                        offline.setBackgroundColor((int) animator.getAnimatedValue());
                    }

                });
                colorAnimation.start();

                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    dialog.dismiss();
                }, 2000);

            }

        } catch (NullPointerException | WindowManager.BadTokenException | ActivityNotFoundException e) {
            e.printStackTrace();
        }

    }

    public boolean isNetworkConnected(Context context) {
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

            return networkInfo != null && networkInfo.isConnected();

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public void callNetworkConnection(Activity activity) {
        BroadcastReceiver broadcastReceiver;
        broadcastReceiver = new NetworkConnection();
        activity.registerReceiver(broadcastReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
    }

}
