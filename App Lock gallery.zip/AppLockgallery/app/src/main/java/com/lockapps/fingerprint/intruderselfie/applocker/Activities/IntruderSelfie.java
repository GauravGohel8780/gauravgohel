package com.lockapps.fingerprint.intruderselfie.applocker.Activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.lockapps.fingerprint.intruderselfie.applocker.CameraService;
import com.lockapps.fingerprint.intruderselfie.applocker.IntruderAdapter;
import com.lockapps.fingerprint.intruderselfie.applocker.IntruderModel;
import com.lockapps.fingerprint.intruderselfie.applocker.SharedPrefs;
import com.lockapps.fingerprint.intruderselfie.applocker.StoreAppDatabase;
import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.app_open_ad.AOM_Activity;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.OnAdCallBack;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.internet.NetworkConnection;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.InterstitialAdManager;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager.NativeAdManager;

import java.util.ArrayList;

public class IntruderSelfie extends AppCompatActivity {

    Switch IntruderSwitch;
    boolean cameraServiceRunning;

    StoreAppDatabase storeAppDatabase;
    SQLiteDatabase sqLiteDatabase;

    IntruderAdapter intruderAdapter;
    RecyclerView recyclerView;

    BottomSheetDialog bottomSheetDialog;
    ImageView lockAttempt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intruder_selfie);

        new NativeAdManager(this).showBottomNativeAdsDialog();

        new NativeAdManager(this).show_NativeBannerAds(this.findViewById(R.id.apps_FrameLayout),
                this.findViewById(R.id.ad_FrameLayout), this.findViewById(R.id.applovin_FrameLayout), this.findViewById(R.id.nativeAdLayout),
                this.findViewById(R.id.ad_loading));

        new NativeAdManager(this).show_NativeBottomFlag(this.findViewById(R.id.bapps_FrameLayout),
                this.findViewById(R.id.bad_FrameLayout), this.findViewById(R.id.bapplovin_FrameLayout), this.findViewById(R.id.bnativeAdLayout),
                this.findViewById(R.id.bad_loading));

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(getResources().getColor(R.color.darkcolor));
        }

        IntruderSwitch = findViewById(R.id.IntruderSwitch);

        recyclerView = findViewById(R.id.intruder_recycle);
        lockAttempt = findViewById(R.id.lockAttempt);

        storeAppDatabase = new StoreAppDatabase(this);


        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        displayData();

        bottomSheetDialog = new BottomSheetDialog(this);

        lockAttempt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showBottomSheetDialog();
            }
        });


        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.darkcolor));

        if (isCameraServiceRunning()) {
            cameraServiceRunning = true;
            SharedPrefs.getIntruderOnOff(getApplicationContext());
        } else {
            cameraServiceRunning = false;
        }

        IntruderSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    startBackgroundService();
                    SharedPrefs.setIntruderOnOff(getApplicationContext(), true);
                } else {
//                    stopBackgroundService();
                    SharedPrefs.setIntruderOnOff(getApplicationContext(), false);
                }
            }
        });

        IntruderSwitch.setChecked(SharedPrefs.getIntruderOnOff(getApplicationContext()));
    }

    private void showBottomSheetDialog() {

        bottomSheetDialog.setContentView(R.layout.lock_attempt_dialog);

        LinearLayout all_attempt = bottomSheetDialog.findViewById(R.id.all_attempt);
        AppCompatButton cancel = bottomSheetDialog.findViewById(R.id.cancel);
        AppCompatButton ok = bottomSheetDialog.findViewById(R.id.ok);
        RadioButton rb1 = bottomSheetDialog.findViewById(R.id.rb1);
        RadioButton rb2 = bottomSheetDialog.findViewById(R.id.rb2);
        RadioButton rb3 = bottomSheetDialog.findViewById(R.id.rb3);
        RadioButton rb4 = bottomSheetDialog.findViewById(R.id.rb4);
        RadioButton rb5 = bottomSheetDialog.findViewById(R.id.rb5);

        if (SharedPrefs.getPasswordCount(this) == 1) {
            rb1.setChecked(true);
            rb2.setChecked(false);
            rb3.setChecked(false);
            rb4.setChecked(false);
            rb5.setChecked(false);
        } else if (SharedPrefs.getPasswordCount(this) == 2) {
            rb1.setChecked(false);
            rb2.setChecked(true);
            rb3.setChecked(false);
            rb4.setChecked(false);
            rb5.setChecked(false);
        } else if (SharedPrefs.getPasswordCount(this) == 3) {
            rb1.setChecked(false);
            rb2.setChecked(false);
            rb3.setChecked(true);
            rb4.setChecked(false);
            rb5.setChecked(false);
        } else if (SharedPrefs.getPasswordCount(this) == 4) {
            rb1.setChecked(false);
            rb2.setChecked(false);
            rb3.setChecked(false);
            rb4.setChecked(true);
            rb5.setChecked(false);
        } else if (SharedPrefs.getPasswordCount(this) == 5) {
            rb1.setChecked(false);
            rb2.setChecked(false);
            rb3.setChecked(false);
            rb4.setChecked(false);
            rb5.setChecked(true);
        } else {
            rb1.setChecked(true);
            rb2.setChecked(false);
            rb3.setChecked(false);
            rb4.setChecked(false);
            rb5.setChecked(false);
        }

        rb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPrefs.setPasswordCount(getApplicationContext(), 1);
            }
        });

        rb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPrefs.setPasswordCount(getApplicationContext(), 2);
            }
        });

        rb3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPrefs.setPasswordCount(getApplicationContext(), 3);
            }
        });

        rb4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPrefs.setPasswordCount(getApplicationContext(), 4);
            }
        });

        rb5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPrefs.setPasswordCount(getApplicationContext(), 5);
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomSheetDialog.dismiss();
            }
        });

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomSheetDialog.dismiss();
            }
        });

        bottomSheetDialog.setCancelable(true);
        bottomSheetDialog.show();

    }

    private void startBackgroundService() {

        if (checkPermission()) {
            requestPermission();
        } else {
//            Intent i = new Intent(this, CameraService.class);
//            startService(i);
            cameraServiceRunning = true;
        }

    }


    private void stopBackgroundService() {
//        Intent i = new Intent(this, CameraService.class);
//        stopService(i);
    }

    private boolean checkPermission() {
        int cameraPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
        int storagePermission = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (cameraPermission == PackageManager.PERMISSION_DENIED || storagePermission == PackageManager.PERMISSION_DENIED) {
            return true;
        } else {
            return false;
        }
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 101:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                    startBackgroundService();
                    cameraServiceRunning = true;
                } else {
                    //not granted
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    private boolean isCameraServiceRunning() {
        Class<?> serviceClass = CameraService.class;
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    private void displayData() {
        sqLiteDatabase = storeAppDatabase.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select *from users ", null);
        ArrayList<IntruderModel> models = new ArrayList<>();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            byte[] image = cursor.getBlob(1);
            String appTime = cursor.getString(2);
            String appIcon = cursor.getString(3);
            String appName = cursor.getString(4);
            models.add(new IntruderModel(id, image, appIcon, appTime, appName));
        }
        cursor.close();
        intruderAdapter = new IntruderAdapter(models, this);
        recyclerView.setAdapter(intruderAdapter);
    }

    @Override
    public void onBackPressed() {

        if (new AdsPreferences(this).getAdsOnback()) {
            new InterstitialAdManager(this).loadInterstitialAll(new OnAdCallBack() {
                @Override
                public void onAdDismiss() {
                    onBack();
                }
            });
        } else {
            onBack();
        }
    }

    public void onBack() {
        super.onBackPressed();
        CommonData.aom_adCount = 0;
    }

//    @Override
//    public void onBackPressed() {
//        startActivity(new Intent(this, AppList.class));
//    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    protected void onResume() {
        super.onResume();
        new NetworkConnection().callNetworkConnection(this);
        new AOM_Activity().showAppOpenAdsActivity(this);
        intruderAdapter.notifyDataSetChanged();
        displayData();
    }

}