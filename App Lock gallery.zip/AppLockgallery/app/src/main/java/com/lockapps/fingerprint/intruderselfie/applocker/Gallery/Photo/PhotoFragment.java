package com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Photo;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager.RecycleviewAdManager;

import java.util.ArrayList;

public class PhotoFragment extends Fragment {

    RecyclerView recyclerView;
    ArrayList<Object> arrayList = new ArrayList<>();
    PhotoAdapter adapter;
    GridLayoutManager gridLayoutManager;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_photo, container, false);

        recyclerView = view.findViewById(R.id.recyclerphoto);
        recyclerView.setHasFixedSize(true);

        gridLayoutManager = new GridLayoutManager(getActivity(), 2);
        if (!new AdsPreferences(getActivity()).getisMediaOn()) {
            gridLayoutManager = new GridLayoutManager(getActivity(), 2);
            gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
                @Override
                public int getSpanSize(int position) {
                    if (adapter.getItemViewType(position) == 1)
                        return gridLayoutManager.getSpanCount();
                    else
                        return 1;
                }
            });
        }
        recyclerView.setLayoutManager(gridLayoutManager);
        arrayList = getPicturePaths();
        new RecycleviewAdManager(getActivity()).AddNativeAd(true, 2, arrayList, CommonData.ItemsPerAdsNormal);
        new RecycleviewAdManager(getActivity()).LoadNativeAd(2, arrayList, CommonData.ItemsPerAdsNormal);

        adapter = new PhotoAdapter( arrayList, getActivity());
        recyclerView.setAdapter(adapter);

        return view;
    }
    private ArrayList<Object> getPicturePaths() {

        ArrayList<String> picPaths = new ArrayList<>();
        Uri allImagesuri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Images.ImageColumns.DATA,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
                MediaStore.Images.Media.BUCKET_ID};

        Cursor cursor = getActivity().getContentResolver().query(allImagesuri, projection, null, null, null);

        try {
            if (cursor != null) {
                cursor.moveToFirst();
            }
            do {
                PhotoModel model = new PhotoModel();
                String name = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME));
                String folder = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME));
                String datapath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA));


                String folderpaths = datapath.substring(0, datapath.lastIndexOf(folder + "/"));
                folderpaths = folderpaths + folder + "/";
                if (!picPaths.contains(folderpaths)) {
                    picPaths.add(folderpaths);

                    model.setPath(folderpaths);
                    model.setFolderName(folder);
                    model.setFirstPic(datapath);
                    model.addpics();
                    arrayList.add(model);
                } else {
                    for (int i = 0; i < arrayList.size(); i++) {
                        model = (PhotoModel) arrayList.get(i);
                        if (model.getPath().equals(folderpaths)) {
                            model.setFirstPic(datapath);
                            model.addpics();
                        }
                    }
                }
            } while (cursor.moveToNext());
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return arrayList;
    }
}