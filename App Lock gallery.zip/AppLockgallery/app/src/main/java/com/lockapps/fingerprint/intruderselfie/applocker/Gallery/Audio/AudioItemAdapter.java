package com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Audio;


import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager.RvBaseAdapter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class AudioItemAdapter extends RvBaseAdapter {

    ArrayList<Object> arrayList;
    Context pictureContx;

    public AudioItemAdapter(ArrayList<Object> arrayList, Context pictureContx) {
        this.arrayList = arrayList;
        this.pictureContx = pictureContx;
    }

    public static MediaPlayer mediaPlayer;
    ScheduledExecutorService timer;
    private int checkedPosition = 0;
    String duration;



    @Override
    public int setLayout(@NonNull ViewGroup viewGroup) {
        return R.layout.audioitemlayout;
    }

    @Override
    public int setAdLayoutContainer(@NonNull ViewGroup viewGroup) {
        return R.layout.layout_ad_container;
    }

    @Override
    public void itemBind(@NonNull RecyclerView.ViewHolder holder, int position) {
        RecyclerViewHolder viewHolder = (RecyclerViewHolder) holder;
        AudioitemModel model = (AudioitemModel)arrayList.get(position);

        Glide.with(pictureContx).load(model.getPicturePath()).placeholder(R.drawable.audioplayicon).into(viewHolder.audioitemicon);
        viewHolder.audioitemname.setText(model.getPicturName());
        viewHolder.audioitemname.setSelected(true);

        viewHolder.seekbar.setVisibility(View.GONE);
        viewHolder.staraudio.setImageResource(R.drawable.playicon);

        viewHolder.seekTo.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                try {
                    if (mediaPlayer != null) {
                        int millis = mediaPlayer.getCurrentPosition();
                        long total_secs = TimeUnit.SECONDS.convert(millis, TimeUnit.MILLISECONDS);
                        long mins = TimeUnit.MINUTES.convert(total_secs, TimeUnit.SECONDS);
                        long secs = total_secs - (mins * 60);

                        if (duration.equalsIgnoreCase(mins + ":" + secs)){
                            viewHolder.seekbar.setVisibility(View.GONE);
                            viewHolder.staraudio.setImageResource(R.drawable.playicon);
                        }

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (mediaPlayer != null) {
                    mediaPlayer.seekTo(viewHolder.seekTo.getProgress());
                }
            }
        });


        viewHolder.staraudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (viewHolder.seekbar.getVisibility() == View.VISIBLE) {
                    if (mediaPlayer != null) {
                        viewHolder.seekbar.setVisibility(View.GONE);
                        viewHolder.staraudio.setImageResource(R.drawable.playicon);
                        mediaPlayer.stop();
                        mediaPlayer = null;
                    }
                } else {

                    playAudio(holder, model.getPicturePath());

                    if (checkedPosition != holder.getAdapterPosition()) {
                        notifyItemChanged(checkedPosition);
                        checkedPosition = holder.getAdapterPosition();
                    }

                    viewHolder.seekbar.setVisibility(View.VISIBLE);
                    viewHolder.staraudio.setImageResource(R.drawable.pushicon);
                }
            }
        });
    }

    @Override
    public int itemCount() {
        return arrayList.size();
    }

    @Override
    public int itemPerAds() {
        return CommonData.ItemsPerAdsNormal;
    }

    @Override
    public ArrayList<Object> nativePosition() {
        return arrayList;
    }

    @Override
    public RecyclerView.ViewHolder viewHolder(View view) {
        return new RecyclerViewHolder(view);
    }

    private class RecyclerViewHolder extends RecyclerView.ViewHolder {
        ImageView audioitemicon, staraudio;
        TextView audioitemname;
        RelativeLayout seekbar;
        SeekBar seekTo;

        public RecyclerViewHolder(View view) {
            super(view);
            audioitemicon = (ImageView) view.findViewById(R.id.audioitemicon);
            staraudio = (ImageView) view.findViewById(R.id.staraudio);
            audioitemname = (TextView) view.findViewById(R.id.audioitemname);
            seekbar = (RelativeLayout) view.findViewById(R.id.seekbar);
            seekTo = (SeekBar) view.findViewById(R.id.seekTo);
        }
    }

    private void playAudio(@NonNull RecyclerView.ViewHolder holder, String audioPath) {
        RecyclerViewHolder viewHolder = (RecyclerViewHolder) holder;
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer = null;

            mediaPlayer = new MediaPlayer();


            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            try {
                mediaPlayer.setDataSource(audioPath);
                mediaPlayer.prepare();
                mediaPlayer.start();

                timer = Executors.newScheduledThreadPool(1);
                timer.scheduleAtFixedRate(new Runnable() {
                    @Override
                    public void run() {
                        if (mediaPlayer != null) {
                            if (!viewHolder.seekTo.isPressed()) {
                                viewHolder.seekTo.setProgress(mediaPlayer.getCurrentPosition());
                            }
                        }
                    }
                }, 10, 10, TimeUnit.MILLISECONDS);


                int millis = mediaPlayer.getDuration();
                long total_secs = TimeUnit.SECONDS.convert(millis, TimeUnit.MILLISECONDS);
                long mins = TimeUnit.MINUTES.convert(total_secs, TimeUnit.SECONDS);
                long secs = total_secs - (mins * 60);
                duration = mins + ":" + secs;

                viewHolder.seekTo.setMax(millis);
                viewHolder.seekTo.setProgress(0);

            } catch (IllegalStateException | IOException e) {
                e.printStackTrace();
            }
        } else {
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            try {
                mediaPlayer.setDataSource(audioPath);
                mediaPlayer.prepare();
                mediaPlayer.start();

                timer = Executors.newScheduledThreadPool(1);
                timer.scheduleAtFixedRate(new Runnable() {
                    @Override
                    public void run() {
                        if (mediaPlayer != null) {
                            if (!viewHolder.seekTo.isPressed()) {
                                viewHolder.seekTo.setProgress(mediaPlayer.getCurrentPosition());
                            }
                        }
                    }
                }, 10, 10, TimeUnit.MILLISECONDS);

                int millis = mediaPlayer.getDuration();
                long total_secs = TimeUnit.SECONDS.convert(millis, TimeUnit.MILLISECONDS);
                long mins = TimeUnit.MINUTES.convert(total_secs, TimeUnit.SECONDS);
                long secs = total_secs - (mins * 60);
                duration = mins + ":" + secs;

                viewHolder.seekTo.setMax(millis);
                viewHolder.seekTo.setProgress(0);
            } catch (IllegalStateException | IOException e) {
                e.printStackTrace();
            }
        }
    }
}
