package com.lockapps.fingerprint.intruderselfie.applocker;

public class CommonClass {
    public static String FileName = "";
    public static String date = "";
}
