package com.lockapps.fingerprint.intruderselfie.applocker;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.lockapps.fingerprint.intruderselfie.applocker.Activities.IntruderPager;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.OnAdCallBack;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.InterstitialAdManager;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.activities.main.AppList;

import java.util.ArrayList;

public class IntruderAdapter extends RecyclerView.Adapter <IntruderAdapter.ViewHolder> {

    ArrayList<IntruderModel>list = new ArrayList<>();
    Activity context;
    Dialog dialog;

    public IntruderAdapter(ArrayList<IntruderModel> list, Activity context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.intruder_recycle_item,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        IntruderModel intruderModel = list.get(position);

        byte[]image = intruderModel.getAppIcon();
        Bitmap bitmap= BitmapFactory.decodeByteArray(image,0,image.length);
        holder.appIcon.setImageBitmap(bitmap);

        String path = Environment.getExternalStorageDirectory().getPath() + "/Pictures/iSelfie/" + intruderModel.getAppImage();

        Glide.with(context).load(path).into(holder.userImage);

        holder.appName.setText(intruderModel.getAppName());
        holder.appTime.setText(intruderModel.getAppTime());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new InterstitialAdManager(context).loadInterstitialAll(new OnAdCallBack() {
                    @Override
                    public void onAdDismiss() {
                        Intent intent = new Intent(context, IntruderPager.class);
                        Bundle bundle = new Bundle();
                        bundle.putParcelableArrayList("arrayPosition", list);
                        intent.putExtra("position", position);
                        intent.putExtras(bundle);
                        context.startActivity(intent);
                    }
                });
            }
        });


//        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View view) {
//
//                dialog = new Dialog(context);
//                dialog.setContentView(R.layout.delete_alert_box);
//                dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
//                dialog.setCancelable(false);
//                Button Yas = dialog.findViewById(R.id.yas);
//                Button No = dialog.findViewById(R.id.no);
//
//                Yas.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        StoreAppDatabase g = new StoreAppDatabase(context);
//                        int result = g.deleteCourse(intruderModel.getId());
//                        if (result>=0)
//                        {
//                            Toast.makeText(context, "Deleted", Toast.LENGTH_SHORT).show();
//                            list.remove(intruderModel);
//                            notifyDataSetChanged();
//                            dialog.cancel();
//
//
//                        }
//                        else
//                        {
//                            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
//                            dialog.cancel();
//                        }
//
//                    }
//                });
//
//                No.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//
//                        Toast.makeText(context, "Cancel", Toast.LENGTH_SHORT).show();
//                        dialog.dismiss();
//
//                    }
//                });
//
//                dialog.show();
//
//                return true;
//            }
//        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView appIcon,userImage;
        TextView appName,appTime;
        RelativeLayout delete_border;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            appIcon = itemView.findViewById(R.id.appIcon);
            userImage = itemView.findViewById(R.id.userImage);
            appName = itemView.findViewById(R.id.appName);
            appTime = itemView.findViewById(R.id.appTime);
            delete_border = itemView.findViewById(R.id.delete_border);
        }
    }
}
