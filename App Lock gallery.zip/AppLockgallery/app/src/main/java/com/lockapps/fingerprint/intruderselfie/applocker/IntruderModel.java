package com.lockapps.fingerprint.intruderselfie.applocker;

import android.os.Parcel;
import android.os.Parcelable;

public class IntruderModel implements Parcelable {

    private int id;
    private byte[] appIcon ;
    private String appImage,appTime,appName;

    public IntruderModel(int id, byte[] appIcon, String appImage, String appTime, String appName) {
        this.id = id;
        this.appIcon = appIcon;
        this.appImage = appImage;
        this.appTime = appTime;
        this.appName = appName;
    }

    protected IntruderModel(Parcel in) {
        id = in.readInt();
        appIcon = in.createByteArray();
        appImage = in.readString();
        appTime = in.readString();
        appName = in.readString();
    }

    public static final Creator<IntruderModel> CREATOR = new Creator<IntruderModel>() {
        @Override
        public IntruderModel createFromParcel(Parcel in) {
            return new IntruderModel(in);
        }

        @Override
        public IntruderModel[] newArray(int size) {
            return new IntruderModel[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public byte[] getAppIcon() {
        return appIcon;
    }

    public void setAppIcon(byte[] appIcon) {
        this.appIcon = appIcon;
    }

    public String getAppImage() {
        return appImage;
    }

    public void setAppImage(String appImage) {
        this.appImage = appImage;
    }

    public String getAppTime() {
        return appTime;
    }

    public void setAppTime(String appTime) {
        this.appTime = appTime;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(id);
        parcel.writeByteArray(appIcon);
        parcel.writeString(appImage);
        parcel.writeString(appTime);
        parcel.writeString(appName);
    }
}
