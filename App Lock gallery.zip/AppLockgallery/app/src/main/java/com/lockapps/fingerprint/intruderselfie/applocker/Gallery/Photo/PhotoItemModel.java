package com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Photo;

import android.os.Parcel;
import android.os.Parcelable;


public class PhotoItemModel implements Parcelable {

    /*normal model*/
    private String picturName;
    private String picturePath;
    private String pictureSize;

    public PhotoItemModel() {
    }

    public PhotoItemModel(String picturName, String picturePath, String pictureSize) {
        this.picturName = picturName;
        this.picturePath = picturePath;
        this.pictureSize = pictureSize;
    }

    protected PhotoItemModel(Parcel in) {
        picturName = in.readString();
        picturePath = in.readString();
        pictureSize = in.readString();
    }

    public static final Creator<PhotoItemModel> CREATOR = new Creator<PhotoItemModel>() {
        @Override
        public PhotoItemModel createFromParcel(Parcel in) {
            return new PhotoItemModel(in);
        }

        @Override
        public PhotoItemModel[] newArray(int size) {
            return new PhotoItemModel[size];
        }
    };

    public String getPicturName() {
        return picturName;
    }

    public void setPicturName(String picturName) {
        this.picturName = picturName;
    }

    public String getPicturePath() {
        return picturePath;
    }

    public void setPicturePath(String picturePath) {
        this.picturePath = picturePath;
    }

    public String getPictureSize() {
        return pictureSize;
    }

    public void setPictureSize(String pictureSize) {
        this.pictureSize = pictureSize;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(picturName);
        parcel.writeString(picturePath);
        parcel.writeString(pictureSize);
    }
}