package com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Audio;

import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.app_open_ad.AOM_Activity;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.OnAdCallBack;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.internet.NetworkConnection;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.InterstitialAdManager;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager.RecycleviewAdManager;

import java.util.ArrayList;

public class AudioItemActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<Object> arrayList = new ArrayList<>();
    String foldePath;
    TextView foldername;
    AudioItemAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_item);

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(getResources().getColor(R.color.darkcolor));
        }

        foldePath = getIntent().getStringExtra("folderPath");
        foldername = findViewById(R.id.foldername);
        foldername.setText(getIntent().getStringExtra("foldername"));

        recyclerView = findViewById(R.id.rvaudioitem);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        arrayList = getAllImagesByFolder(foldePath);
        new RecycleviewAdManager(this).AddNativeAd(false, 4, arrayList, CommonData.ItemsPerAdsNormal);
        new RecycleviewAdManager(this).LoadNativeAd(4, arrayList, CommonData.ItemsPerAdsNormal);

        adapter = new AudioItemAdapter(arrayList, this);
        recyclerView.setAdapter(adapter);

    }

    public ArrayList<Object> getAllImagesByFolder(String path) {
//        ArrayList<Object> audios = new ArrayList<>();
        Uri allVideosuri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Audio.AudioColumns.DATA,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.SIZE};
        Cursor cursor = this.getContentResolver().query(allVideosuri, projection, MediaStore.Audio.Media.DATA + " like ? ", new String[]{"%" + path + "%"}, null);
        try {
            cursor.moveToFirst();
            do {
                AudioitemModel pic = new AudioitemModel();

                pic.setPicturName(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)));

                pic.setPicturePath(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)));

                pic.setPictureSize(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)));

                arrayList.add(pic);
            } while (cursor.moveToNext());
            cursor.close();
            ArrayList<Object> reSelection = new ArrayList<>();
            for (int i = arrayList.size() - 1; i > -1; i--) {
                reSelection.add(arrayList.get(i));
            }
            arrayList = reSelection;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return arrayList;
    }

    @Override
    public void onBackPressed() {
        if (new AdsPreferences(this).getAdsOnback()) {
            new InterstitialAdManager(this).loadInterstitialAll(new OnAdCallBack() {
                @Override
                public void onAdDismiss() {
                    onBack();
                }
            });
        } else {
            onBack();
        }
    }

    public void onBack() {
        super.onBackPressed();
        CommonData.aom_adCount = 0;
    }

    @Override
    protected void onResume() {
        super.onResume();
        new NetworkConnection().callNetworkConnection(this);
        new AOM_Activity().showAppOpenAdsActivity(this);
    }
}