package com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Audio;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager.RecycleviewAdManager;

import java.util.ArrayList;


public class AudioFragment extends Fragment {

    RecyclerView recyclerView;
    ArrayList<Object> arrayList;
    AudioAdapter adapter;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_audio, container, false);

        recyclerView = view.findViewById(R.id.recycleraudio);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        arrayList = getPicturePaths();

        new RecycleviewAdManager(getActivity()).AddNativeAd(false, 4, arrayList, CommonData.ItemsPerAdsNormal);
        new RecycleviewAdManager(getActivity()).LoadNativeAd(4, arrayList, CommonData.ItemsPerAdsNormal);

        adapter = new AudioAdapter(arrayList, getActivity());

        recyclerView.setAdapter(adapter);
        return view;
    }

    private ArrayList<Object> getPicturePaths() {
        ArrayList<Object> arrayList = new ArrayList<>();

        ArrayList<String> picPaths = new ArrayList<>();
        Uri allImagesuri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Audio.AudioColumns.DATA,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.BUCKET_DISPLAY_NAME,
                MediaStore.Audio.Media.BUCKET_ID};

        Cursor cursor = getActivity().getContentResolver().query(allImagesuri, projection, null, null, null);

        try {
            if (cursor != null) {
                cursor.moveToFirst();
            }
            do {
                AudioModel model = new AudioModel();
                String name = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME));
                String folder = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.BUCKET_DISPLAY_NAME));
                String datapath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA));


                String folderpaths = datapath.substring(0, datapath.lastIndexOf(folder + "/"));
                folderpaths = folderpaths + folder + "/";
                if (!picPaths.contains(folderpaths)) {
                    picPaths.add(folderpaths);

                    model.setPath(folderpaths);
                    model.setFolderName(folder);
                    model.setFirstPic(datapath);
                    model.addpics();
                    arrayList.add(model);
                } else {
                    for (int i = 0; i < arrayList.size(); i++) {
                        model = (AudioModel) arrayList.get(i);
                        if (model.getPath().equals(folderpaths)) {
                            model.setFirstPic(datapath);
                            model.addpics();
                        }
                    }
                }
            } while (cursor.moveToNext());
            cursor.close();


        } catch (Exception e) {
            e.printStackTrace();
        }
        return arrayList;
    }

}