package com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.base;


import com.lockapps.fingerprint.intruderselfie.applocker.BuildConfig;

public class AppConstants {

    //intent constant
    public static final String APP_PACKAGE_NAME = BuildConfig.APPLICATION_ID;
    public static final String LOCK_PACKAGE_NAME = "lock_package_name";
    public static final String LOCK_FROM = "lock_from";
    public static final String LOCK_FROM_FINISH = "lock_from_finish";
    public static final String LOCK_FROM_LOCK_MAIN_ACITVITY = "lock_from_lock_main_activity";

    //shared prefs constant
    public static final String LOCK_STATE = "app_lock_state";//boolean
    public static final String LOCK_FAVITER_NUM = "lock_faviter_num";//int
    public static final String LOCK_IS_INIT_FAVITER = "lock_is_init_faviter";//boolean
    public static final String LOCK_IS_INIT_DB = "lock_is_init_db";//boolean
    public static final String LOCK_AUTO_SCREEN = "lock_auto_screen";//boolean
    public static final String LOCK_AUTO_SCREEN_TIME = "lock_auto_screen_time"; //boolean
    public static final String LOCK_CURR_MILLISECONDS = "lock_curr_milliseconds";//long
    public static final String LOCK_APART_MILLISECONDS = "lock_apart_milliseconds";//long
    public static final String LOCK_LAST_LOAD_PKG_NAME = "last_load_package_name";//string

}
