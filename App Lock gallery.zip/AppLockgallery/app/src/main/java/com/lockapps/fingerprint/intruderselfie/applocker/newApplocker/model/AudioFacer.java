package com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.model;

import android.os.Parcel;
import android.os.Parcelable;

public class AudioFacer implements Parcelable {

    private String AudioName;
    private String AudioPath;
    private  String AudioSize;
    private  String imageUri;
    private Boolean selected = false;

    public AudioFacer(){}

    public AudioFacer(String audioName, String audioPath, String audioSize, String imageUri, Boolean selected) {
        AudioName = audioName;
        AudioPath = audioPath;
        AudioSize = audioSize;
        this.imageUri = imageUri;
        this.selected = selected;
    }

    protected AudioFacer(Parcel in) {
        AudioName = in.readString();
        AudioPath = in.readString();
        AudioSize = in.readString();
        imageUri = in.readString();
        byte tmpSelected = in.readByte();
        selected = tmpSelected == 0 ? null : tmpSelected == 1;
    }

    public static final Creator<AudioFacer> CREATOR = new Creator<AudioFacer>() {
        @Override
        public AudioFacer createFromParcel(Parcel in) {
            return new AudioFacer(in);
        }

        @Override
        public AudioFacer[] newArray(int size) {
            return new AudioFacer[size];
        }
    };

    public String getAudioName() {
        return AudioName;
    }

    public void setAudioName(String audioName) {
        AudioName = audioName;
    }

    public String getAudioPath() {
        return AudioPath;
    }

    public void setAudioPath(String audioPath) {
        AudioPath = audioPath;
    }

    public String getAudioSize() {
        return AudioSize;
    }

    public void setAudioSize(String audioSize) {
        AudioSize = audioSize;
    }

    public String getImageUri() {
        return imageUri;
    }

    public void setImageUri(String imageUri) {
        this.imageUri = imageUri;
    }

    public Boolean getSelected() {
        return selected;
    }

    public void setSelected(Boolean selected) {
        this.selected = selected;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(AudioName);
        parcel.writeString(AudioPath);
        parcel.writeString(AudioSize);
        parcel.writeString(imageUri);
        parcel.writeByte((byte) (selected == null ? 0 : selected ? 1 : 2));
    }
}
