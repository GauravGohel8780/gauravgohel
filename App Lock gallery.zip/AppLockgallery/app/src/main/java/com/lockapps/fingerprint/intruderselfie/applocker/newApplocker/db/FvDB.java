package com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.model.FavItem;

import java.util.ArrayList;

public class FvDB extends SQLiteOpenHelper {

    private static int DB_VERSION = 1;
    private static String DATABASE_NAME = "FavDB";
    private static String TABLE_NAME = "favoriteTable";
    private static String ITEM_IMAGE = "image";
    private static String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + "(" + ITEM_IMAGE + " TEXT)";


    public FvDB(Context context) {
        super(context, DATABASE_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void insertIntoTheDatabase(String item_image) {
        if (!checkRecordIsExists(item_image)) {
            SQLiteDatabase db = this.getReadableDatabase();
            ContentValues cv = new ContentValues();
            cv.put(ITEM_IMAGE, item_image);
            db.insert(TABLE_NAME, null, cv);
        }
    }

    public Boolean checkRecordIsExists(String item_image) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        String sql = "SELECT * FROM " + TABLE_NAME + " WHERE " + ITEM_IMAGE + " = '" + item_image + "'";
        cursor = db.rawQuery(sql, null);
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        } else {
            cursor.close();
            return false;
        }
    }

    public ArrayList<FavItem> Showdata() {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + TABLE_NAME + "";
        Cursor cursor = db.rawQuery(sql, null);

        ArrayList<FavItem> list = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                String path = cursor.getString(0);
                list.add(new FavItem(0, path));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    public void remove_fav(String image) {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "DELETE FROM " + TABLE_NAME + " WHERE " + ITEM_IMAGE + " = '" + image + "'";
        db.execSQL(sql);
    }
}