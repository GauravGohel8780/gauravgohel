package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class;

import android.widget.FrameLayout;

import java.util.ArrayList;

public class CommonData {

    public static final String TAG = "AppTag";
    public static boolean is_ShowingAd, is_ShowingAdClose, is_last_native_failed;
    public static boolean isShowedAltAdmobNativeAds;
    public static boolean isShowedAltAdmobNativeBannerAds;;
    public static boolean isShowedAltAdmobNativeBannerAds2;;
    public static boolean isShowedAltAdmobNativeBottomBannerAds;;

    public static boolean isShowFirstInterstitialAd;

    // Google
    public static com.google.android.gms.ads.nativead.NativeAd google_NativeAds;
    public static com.google.android.gms.ads.nativead.NativeAd google_NativeBannerAds;
    public static com.google.android.gms.ads.nativead.NativeAd google_NativeBannerAds2;
    public static com.google.android.gms.ads.nativead.NativeAd google_NativeBottomBannerAds;
    public static com.google.android.gms.ads.interstitial.InterstitialAd _interstitial_google;

    // Facebook
    public static com.facebook.ads.NativeAd facebook_nativeAd;
    public static com.facebook.ads.NativeAd facebook_nativeBannerAd;
    public static com.facebook.ads.NativeBannerAd facebook_nativeBannerAd2;
    public static com.facebook.ads.NativeBannerAd facebook_nativeBottomBannerAd;
    public static com.facebook.ads.InterstitialAd _interstitial_facebook;


    //Ads Priiority

    public static final String Google = "Google";
    public static final String Google_Facebook = "Google_Facebook";
    public static final String Facebook = "Facebook";
    public static final String Facebook_Google = "Facebook_Google";
    public static final String Alternate = "Alternate";

//    //  AppLovin
//    public static MaxInterstitialAd maxInterstitialAd;
//
//    public static MaxNativeAdLoader al_nativeLoader;
//    public static MaxAd al_nativeAd;
//
//    public static MaxNativeAdLoader al_nativeBannerLoader;
//    public static MaxAd al_nativeBannerAd;
//
//    public static MaxNativeAdLoader al_nativeBannerLoader2;
//    public static MaxAd al_nativeBannerAd2;
//
//    public static MaxNativeAdLoader al_nativeBottomBannerLoader;
//    public static MaxAd al_nativeBottomBannerAd;




    public static ArrayList<Object> listWithAds = new ArrayList<>();
    public static ArrayList<Object> listWith_BigAds = new ArrayList<>();

    //    public static FrameLayout apps_FrameLayout;
//    public static FrameLayout applovin_FrameLayout;
    public static FrameLayout ad_loading;

    public static int ItemsPerAdsNormal = 7;
    public static int ItemsPerAdsGrid = 7;
    public static int GridCount = 3;

    public static final int MENU_ITEM_VIEW_TYPE = 0;
    public static final int BANNER_AD_VIEW_TYPE = 1;

    public static int aom_adCount;
}
