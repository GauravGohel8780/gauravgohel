package com.lockapps.fingerprint.intruderselfie.applocker.Activities;

import android.os.Build;
import android.os.Bundle;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.lockapps.fingerprint.intruderselfie.applocker.Fragments.Finger;
import com.lockapps.fingerprint.intruderselfie.applocker.Fragments.Pattern;
import com.lockapps.fingerprint.intruderselfie.applocker.Fragments.RePattern;
import com.lockapps.fingerprint.intruderselfie.applocker.ItemClickListener;
import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.internet.NetworkConnection;


public class Second extends AppCompatActivity implements ItemClickListener {

    FrameLayout frame;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.darkcolor));
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(getResources().getColor(R.color.darkcolor));
        }
        frame = findViewById(R.id.frame);

        init(new Finger());
    }

    public void init(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame, fragment).commit();
    }

    @Override
    public void onItemClicked(String item) {
        if (item.equalsIgnoreCase("pattern")) {
            init(new Pattern());
        } else {
            init(new RePattern());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        new NetworkConnection().callNetworkConnection(this);

    }
}