package com.lockapps.fingerprint.intruderselfie.applocker;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefs {

    public static final String PREF_NIGHT_MODE = "night_mode";

    public static final String LockType = "LockType";
    public static final String LockFinalType = "LockFinalType";
    public static final String PatternData = "PatternData";
    public static final String IsPatternSet = "IsPatternSet";
    public static final String PinData = "PinData";
    public static final String IsPinSet = "IsPinSet";
    public static final String SecurityQuestion = "SecurityQuestion";
    public static final String SecurityQuestionAnswer = "SecurityQuestionAnswer";
    public static final String IsPasswordSet = "IsPasswordSet";
    public static final String ISFingerUD = "ISFingerUD";
    public static final String IsRandomOnOff = "IsRandomOnOff";
    public static final String IntruderOnOff = "IntruderOnOff";
    public static final String VibrateOnOff = "VibrateOnOff";
    public static final String LockIsOnOff = "LockIsOnOff";
    public static final String ImmediateLock = "ImmediateLock";
    public static final String HidePatternPath = "HidePatternPath";
    public static final String PasswordCount = "PasswordCount";
    public static final String VoiceLock = "VoiceLock";
    public static final String VoiceLockIV = "VoiceLockIV";
    public static final String VoiceLockOnOff = "VoiceLockOnOff";
    public static final String IsAdOpenShow  = "IsAdOpenShow";


    private static SharedPreferences mPreferences;

    private static SharedPreferences getInstance(Context context) {
        if (mPreferences == null) {
            mPreferences = context.getApplicationContext().getSharedPreferences("stat_data", 0);
        }
        return mPreferences;
    }
    public static void setIsPatternSet(Context context, boolean str) {
        getInstance(context).edit().putBoolean(IsPatternSet, str).apply();
    }

    public static boolean getIsPatternSet(Context context) {
        return getInstance(context).getBoolean(IsPatternSet, false);
    }

    public static void setIsPinSet(Context context, boolean str) {
        getInstance(context).edit().putBoolean(IsPinSet, str).apply();
    }

    public static boolean getIsPinSet(Context context) {
        return getInstance(context).getBoolean(IsPinSet, false);
    }

    public static void setIsRandomOnOff(Context context, boolean str) {
        getInstance(context).edit().putBoolean(IsRandomOnOff, str).apply();
    }

    public static boolean getIsRandomOnOff(Context context) {
        return getInstance(context).getBoolean(IsRandomOnOff, false);
    }

    public static void setISFingerUD(Context context, boolean str) {
        getInstance(context).edit().putBoolean(ISFingerUD, str).apply();
    }

    public static boolean getISFingerUD(Context context) {
        return getInstance(context).getBoolean(ISFingerUD, false);
    }

    public static void setIsPasswordSet(Context context, boolean str) {
        getInstance(context).edit().putBoolean(IsPasswordSet, str).apply();
    }

    public static boolean getIsPasswordSet(Context context) {
        return getInstance(context).getBoolean(IsPasswordSet, false);
    }

    public static void setLockType(Context context, String str) {
        getInstance(context).edit().putString(LockType, str).apply();
    }

    public static String getLockType(Context context) {
        return getInstance(context).getString(LockType, "");
    }

    public static void setLockFinalType(Context context, String str) {
        getInstance(context).edit().putString(LockFinalType, str).apply();
    }

    public static String getLockFinalType(Context context) {
        return getInstance(context).getString(LockFinalType, "");
    }

    public static void setPatternData(Context context, String str) {
        getInstance(context).edit().putString(PatternData, str).apply();
    }

    public static String getPatternData(Context context) {
        return getInstance(context).getString(PatternData, "");
    }

    public static void setPinData(Context context, String str) {
        getInstance(context).edit().putString(PinData, str).apply();
    }

    public static String getPinData(Context context) {
        return getInstance(context).getString(PinData, "");
    }

    public static void setSecurityQuestion(Context context, String str) {
        getInstance(context).edit().putString(SecurityQuestion, str).apply();
    }

    public static String getSecurityQuestion(Context context) {
        return getInstance(context).getString(SecurityQuestion, "");
    }

    public static void setSecurityQuestionAnswer(Context context, String str) {
        getInstance(context).edit().putString(SecurityQuestionAnswer, str).apply();
    }

    public static String getSecurityQuestionAnswer(Context context) {
        return getInstance(context).getString(SecurityQuestionAnswer, "");
    }

    public static void setIntruderOnOff(Context context, boolean str) {
        getInstance(context).edit().putBoolean(IntruderOnOff, str).apply();
    }

    public static boolean getIntruderOnOff(Context context) {
        return getInstance(context).getBoolean(IntruderOnOff, false);
    }

    public static void setVibrateOnOff(Context context, boolean str) {
        getInstance(context).edit().putBoolean(VibrateOnOff, str).apply();
    }

    public static boolean getVibrateOnOff(Context context) {
        return getInstance(context).getBoolean(VibrateOnOff, false);
    }

    public static void setLockIsOnOff(Context context, boolean str) {
        getInstance(context).edit().putBoolean(LockIsOnOff, str).apply();
    }

    public static boolean getLockIsOnOff(Context context) {
        return getInstance(context).getBoolean(LockIsOnOff, false);
    }

    public static void setImmediateLock(Context context, boolean str) {
        getInstance(context).edit().putBoolean(ImmediateLock, str).apply();
    }

    public static boolean getImmediateLock(Context context) {
        return getInstance(context).getBoolean(ImmediateLock, false);
    }

    public static void setHidePatternPath(Context context, boolean str) {
        getInstance(context).edit().putBoolean(HidePatternPath, str).apply();
    }

    public static boolean getHidePatternPath(Context context) {
        return getInstance(context).getBoolean(HidePatternPath, false);
    }

    public static void setPasswordCount(Context context, int str) {
        getInstance(context).edit().putInt(PasswordCount, str).apply();
    }

    public static int getPasswordCount(Context context) {
        return getInstance(context).getInt(PasswordCount, 1);
    }

    public static void setVoiceLock(Context context, boolean str) {
        getInstance(context).edit().putBoolean(VoiceLock, str).apply();
    }

    public static boolean getVoiceLock(Context context) {
        return getInstance(context).getBoolean(VoiceLock, false);
    }

    public static void setVoiceLockIV(Context context, boolean str) {
        getInstance(context).edit().putBoolean(VoiceLockIV, str).apply();
    }

    public static boolean getVoiceLockIV(Context context) {
        return getInstance(context).getBoolean(VoiceLockIV, false);
    }

    public static void setVoiceLockOnOff(Context context, String str) {
        getInstance(context).edit().putString(VoiceLockOnOff, str).apply();
    }

    public static String getVoiceLockOnOff(Context context) {
        return getInstance(context).getString(VoiceLockOnOff, "");
    }

    public static boolean setIsAdOpenShow(Context context, boolean str) {
        getInstance(context).edit().putBoolean(IsAdOpenShow, str).apply();
        return str;
    }

    public static boolean getIsAdOpenShow(Context context) {
        return getInstance(context).getBoolean(IsAdOpenShow, false);
    }

}
