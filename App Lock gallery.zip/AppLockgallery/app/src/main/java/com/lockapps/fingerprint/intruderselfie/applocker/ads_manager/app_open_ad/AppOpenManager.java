package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.app_open_ad;

import android.app.Activity;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.OnAdCallBack;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.InterstitialAdManager;

public class AppOpenManager {

    private AppOpenAd appOpenAd = null;

    public void loadAd_intent(Activity activity, OnAdCallBack onAdCallBack) {
        if (CommonData.is_ShowingAd) {
            return;
        }

        try {

            AdRequest request = new AdRequest.Builder().build();

            AppOpenAd.load(activity,new AdsPreferences(activity).getAdmobAppOpen(), request, AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, new AppOpenAd.AppOpenAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull AppOpenAd ad) {
                    CommonData.is_ShowingAd = true;
                    appOpenAd = ad;
                    appOpenAd.show(activity);

                    appOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                        @Override
                        public void onAdDismissedFullScreenContent() {
                            appOpenAd = null;
                            CommonData.is_ShowingAd = false;
                            CommonData.is_ShowingAdClose = true;

                            new InterstitialAdManager(activity)._nextActivity(onAdCallBack);

                            Log.i(CommonData.TAG, "on Ad Dismiss Admob");
                        }

                        @Override
                        public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                            appOpenAd = null;
                            CommonData.is_ShowingAd = false;
//                            loadAdx_intent(activity, onAdCallBack);

                            Log.i(CommonData.TAG, "on Ad Failed To Show Admob");
                        }

                        @Override
                        public void onAdShowedFullScreenContent() {
                        }
                    });
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                    loadAdx_intent(activity, onAdCallBack);

                    Log.i(CommonData.TAG, "on Ad Failed To Load Admob");
                }
            });

        } catch (Exception e) {

            Log.i(CommonData.TAG, "Exception Admob: " + e);
        }
    }

    public void loadAdx_intent(Activity activity,OnAdCallBack onAdCallBack) {
        try {
            AdRequest request = new AdRequest.Builder().build();
            AppOpenAd.load(activity, new AdsPreferences(activity).getAdxAppOpen(), request, AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, new AppOpenAd.AppOpenAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull AppOpenAd ad) {
                    CommonData.is_ShowingAd = true;
                    appOpenAd = ad;
                    appOpenAd.show(activity);

                    appOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                        @Override
                        public void onAdDismissedFullScreenContent() {
                            appOpenAd = null;
                            CommonData.is_ShowingAd = false;
                            CommonData.is_ShowingAdClose = true;

                            new InterstitialAdManager(activity)._nextActivity(onAdCallBack);

                            Log.i(CommonData.TAG, "on Ad Dismiss Adx");
                        }

                        @Override
                        public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                            appOpenAd = null;
                            CommonData.is_ShowingAd = false;

//                            new InterstitialAdManager(activity)._nextActivity(onAdCallBack);

                            Log.i(CommonData.TAG, "on Ad Failed To Show Adx");
                        }

                        @Override
                        public void onAdShowedFullScreenContent() {
                        }
                    });
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    appOpenAd = null;
                    CommonData.is_ShowingAd = false;
                    CommonData.is_ShowingAdClose = true;

                    new InterstitialAdManager(activity)._nextActivity(onAdCallBack);

                    Log.i(CommonData.TAG, "on Ad Failed To Load Adx");
                }
            });

        } catch (Exception e) {

            Log.i(CommonData.TAG, "Exception Adx: " + e);
        }
    }

}
