package com.lockapps.fingerprint.intruderselfie.applocker.Activities;

import android.app.Application;
import android.content.pm.PackageInfo;

import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.utils.SpUtil;


public class AppData extends Application {

    PackageInfo packageInfo;

    private static AppData application;

    public static AppData getInstance() {
        return application;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        application = this;

        SpUtil.getInstance().init(application);
    }

    public PackageInfo getPackageInfo() {
        return packageInfo;
    }

    public void setPackageInfo(PackageInfo packageInfo) {
        this.packageInfo = packageInfo;
    }
}