package com.lockapps.fingerprint.intruderselfie.applocker.Activities;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.content.ContextCompat;

import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.lockapps.fingerprint.intruderselfie.applocker.SharedPrefs;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.app_open_ad.AOM_Activity;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.OnAdCallBack;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.internet.NetworkConnection;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.InterstitialAdManager;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager.NativeAdManager;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.base.AppConstants;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.services.BackgroundManager;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.services.LockService;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.utils.SpUtil;

import java.util.ArrayList;
import java.util.Locale;

public class Settings extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    LinearLayout lockTypeLL, ChangePassword, drawPath, randomNumber, SecurityQuestion, Share, Rate, Privacy, ChangeVoice;
    PopupWindow mypopupWindow;
    TextView password_type;
    Switch AppLock, ImmediateLock, fingerSwitch, RandomPin, VibrateSwitch, HidePattern, VoiceSwitch;
    TextView question;
    BottomSheetDialog bottomSheetDialog;

    public static final String LOCK_IS_HIDE_LINE = "lock_is_hide_line";//boolean

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(getResources().getColor(R.color.darkcolor));
        }

        lockTypeLL = findViewById(R.id.lockTypeLL);
        password_type = findViewById(R.id.password_type);
        fingerSwitch = findViewById(R.id.fingerSwitch);
        RandomPin = findViewById(R.id.RandomPin);
        VibrateSwitch = findViewById(R.id.VibrateSwitch);
        HidePattern = findViewById(R.id.HidePattern);
        AppLock = findViewById(R.id.AppLock);
        ChangeVoice = findViewById(R.id.ChangeVoice);
        VoiceSwitch = findViewById(R.id.VoiceSwitch);
//        ImmediateLock = findViewById(R.id.ImmediateLock);
        ChangePassword = findViewById(R.id.ChangePassword);
        drawPath = findViewById(R.id.drawPath);
        randomNumber = findViewById(R.id.randomNumber);
        SecurityQuestion = findViewById(R.id.SecurityQuestion);
        Share = findViewById(R.id.Share);
        Rate = findViewById(R.id.Rate);
        Privacy = findViewById(R.id.privacy);
        new NativeAdManager(this).showBottomNativeAdsDialog();


        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.darkcolor));

        bottomSheetDialog = new BottomSheetDialog(this);

        setPopUpWindow(this);
        new NativeAdManager(this).show_NativeBannerAds(this.findViewById(R.id.apps_FrameLayout),
                this.findViewById(R.id.ad_FrameLayout), this.findViewById(R.id.applovin_FrameLayout), this.findViewById(R.id.nativeAdLayout),
                this.findViewById(R.id.ad_loading));

        new NativeAdManager(this).show_NativeBottomFlag(this.findViewById(R.id.bapps_FrameLayout),
                this.findViewById(R.id.bad_FrameLayout), this.findViewById(R.id.bapplovin_FrameLayout), this.findViewById(R.id.bnativeAdLayout),
                this.findViewById(R.id.bad_loading));


        lockTypeLL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mypopupWindow.showAsDropDown(view, -153, 0);
            }
        });

        AppLock.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                SharedPrefs.setLockIsOnOff(getApplicationContext(), b);
                SpUtil.getInstance().putBoolean(AppConstants.LOCK_STATE, b);
                if (b) {
//                    BackgroundManager.getInstance().init(Settings.this).stopService(LockService.class);
                    BackgroundManager.getInstance().init(Settings.this).startService(LockService.class);

                    BackgroundManager.getInstance().init(Settings.this).startAlarmManager();

                } else {
                    BackgroundManager.getInstance().init(Settings.this).stopService(LockService.class);
                    BackgroundManager.getInstance().init(Settings.this).stopAlarmManager();
                }
            }
        });

        AppLock.setChecked(SharedPrefs.getLockIsOnOff(getApplicationContext()));

        fingerSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharedPrefs.setISFingerUD(getApplicationContext(), isChecked);
            }
        });

        fingerSwitch.setChecked(SharedPrefs.getISFingerUD(getApplicationContext()));

        RandomPin.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharedPrefs.setIsRandomOnOff(getApplicationContext(), isChecked);
            }
        });

        RandomPin.setChecked(SharedPrefs.getIsRandomOnOff(getApplicationContext()));

        VibrateSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharedPrefs.setVibrateOnOff(getApplicationContext(), isChecked);
            }
        });

        VibrateSwitch.setChecked(SharedPrefs.getVibrateOnOff(getApplicationContext()));

        HidePattern.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                SharedPrefs.setHidePatternPath(getApplicationContext(), b);
//                com.lockapps.fingerprint.intruderselfie.applockernewApplocker.utils.SpUtil.getInstance().putBoolean(AppConstants.LOCK_IS_HIDE_LINE, b);
            }
        });

        HidePattern.setChecked(SharedPrefs.getHidePatternPath(getApplicationContext()));

        VoiceSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    ChangeVoice.setVisibility(View.VISIBLE);
                } else {
                    ChangeVoice.setVisibility(View.GONE);
                }
                if (b) {
                    if (SharedPrefs.getVoiceLock(getApplicationContext())) {
                        SharedPrefs.setVoiceLockIV(getApplicationContext(), true);
                        VoiceSwitch.setChecked(true);
                    } else {
                        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

                        if (intent.resolveActivity(getPackageManager()) != null) {
                            startActivityForResult(intent, 10);

                            SharedPrefs.setVoiceLockIV(getApplicationContext(), true);
                        } else {
                            Toast.makeText(Settings.this, "Your device Don't Support Speech Input", Toast.LENGTH_SHORT).show();
                        }
                        VoiceSwitch.setChecked(false);
                    }
                } else {
                    SharedPrefs.setVoiceLockIV(getApplicationContext(), false);
                }
            }
        });

        VoiceSwitch.setChecked(SharedPrefs.getVoiceLockIV(getApplicationContext()));

        ChangeVoice.setOnClickListener(view -> {

            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivityForResult(intent, 10);
            } else {
                Toast.makeText(Settings.this, "Your device Don't Support Speech Input", Toast.LENGTH_SHORT).show();
            }

        });

        ChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (SharedPrefs.getLockFinalType(Settings.this).equalsIgnoreCase("Pattern")) {
                    SharedPrefs.setLockType(Settings.this, "Pattern");
                    new InterstitialAdManager(Settings.this).loadInterstitialAll(new OnAdCallBack() {
                        @Override
                        public void onAdDismiss() {
                            startActivity(new Intent(Settings.this, Third.class));
                        }
                    });


                } else {
                    SharedPrefs.setLockType(Settings.this, "PIN");
                    new InterstitialAdManager(Settings.this).loadInterstitialAll(new OnAdCallBack() {
                        @Override
                        public void onAdDismiss() {
                            startActivity(new Intent(Settings.this, Third.class));
                        }
                    });

                }
            }
        });

        SecurityQuestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showdialog();
            }
        });

        Share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, "http://play.google.com/store/apps/details?id=" + getPackageName());
                sendIntent.setType("text/plain");

                Intent shareIntent = Intent.createChooser(sendIntent, null);
                startActivity(shareIntent);
            }
        });

        Rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + getPackageName())));
                } catch (ActivityNotFoundException e) {
                    startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
                }
            }
        });

        Privacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPrefs.setLockType(Settings.this, "PIN");
                new InterstitialAdManager(Settings.this).loadInterstitialAll(new OnAdCallBack() {
                    @Override
                    public void onAdDismiss() {
                        startActivity(new Intent(Settings.this, webview.class));

                    }
                });
            }
        });
    }

    private void showdialog() {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setContentView(R.layout.security_question_dialog);

        RelativeLayout rlv = bottomSheetDialog.findViewById(R.id.rlv);
        ImageView down = bottomSheetDialog.findViewById(R.id.down);
        ImageView cancel = bottomSheetDialog.findViewById(R.id.cancel);
        question = bottomSheetDialog.findViewById(R.id.question);
        Spinner SpinnerTextSize = bottomSheetDialog.findViewById(R.id.SpinnerTextSize);
        AppCompatButton save = bottomSheetDialog.findViewById(R.id.save);
        EditText edit = bottomSheetDialog.findViewById(R.id.edit);

        SpinnerTextSize.setOnItemSelectedListener(this);

        String[] textsize = getResources().getStringArray(R.array.font_sizes);
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, textsize);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SpinnerTextSize.setAdapter(adapter);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomSheetDialog.dismiss();
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (edit.getText().toString().isEmpty()) {
                    Toast.makeText(Settings.this, "Please Enter Answer..", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Settings.this, "Saved Successfully.", Toast.LENGTH_SHORT).show();
                    bottomSheetDialog.dismiss();
                }

                String Question = edit.getText().toString();

                SharedPrefs.setSecurityQuestionAnswer(getApplicationContext(), Question);
            }
        });


        bottomSheetDialog.show();
    }

    private void setPopUpWindow(Context context) {
        LayoutInflater inflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.password_type_dialog, null);

        LinearLayout patternLL = view.findViewById(R.id.patternLL);
        LinearLayout pinLL = view.findViewById(R.id.pinLL);
        ImageView patternIV = view.findViewById(R.id.patternIV);
        ImageView pinIV = view.findViewById(R.id.pinIV);

        if (SharedPrefs.getLockFinalType(Settings.this).equalsIgnoreCase("PIN")) {
            patternIV.setImageResource(R.drawable.ic_checkbox_unchecked);
            pinIV.setImageResource(R.drawable.ic_checkbox_checked);
            password_type.setText("Pin");
            randomNumber.setVisibility(View.VISIBLE);
            drawPath.setVisibility(View.GONE);
        } else {
            patternIV.setImageResource(R.drawable.ic_checkbox_checked);
            pinIV.setImageResource(R.drawable.ic_checkbox_unchecked);
            password_type.setText("Pattern");
            randomNumber.setVisibility(View.GONE);
            drawPath.setVisibility(View.VISIBLE);
        }

        pinLL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (SharedPrefs.getLockFinalType(Settings.this).equalsIgnoreCase("Pattern")) {
                    if (SharedPrefs.getIsPinSet(Settings.this)) {
                        SharedPrefs.setLockFinalType(Settings.this, "PIN");
                        patternIV.setImageResource(R.drawable.ic_checkbox_unchecked);
                        pinIV.setImageResource(R.drawable.ic_checkbox_checked);
                        password_type.setText("Pin");
                        randomNumber.setVisibility(View.VISIBLE);
                        drawPath.setVisibility(View.GONE);
                        mypopupWindow.dismiss();

                    } else {
                        SharedPrefs.setLockType(Settings.this, "PIN");
                        new InterstitialAdManager(Settings.this).loadInterstitialAll(new OnAdCallBack() {
                            @Override
                            public void onAdDismiss() {
                                startActivity(new Intent(Settings.this, Third.class));
                            }
                        });

                    }
                }
            }
        });

        patternLL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (SharedPrefs.getLockFinalType(Settings.this).equalsIgnoreCase("PIN")) {
                    if (SharedPrefs.getIsPatternSet(Settings.this)) {
                        SharedPrefs.setLockFinalType(Settings.this, "Pattern");
                        patternIV.setImageResource(R.drawable.ic_checkbox_checked);
                        pinIV.setImageResource(R.drawable.ic_checkbox_unchecked);
                        password_type.setText("Pattern");
                        randomNumber.setVisibility(View.GONE);
                        drawPath.setVisibility(View.VISIBLE);
                        mypopupWindow.dismiss();
                    } else {
                        SharedPrefs.setLockType(Settings.this, "Pattern");
                        SharedPrefs.setLockType(Settings.this, "PIN");
                        new InterstitialAdManager(Settings.this).loadInterstitialAll(new OnAdCallBack() {
                            @Override
                            public void onAdDismiss() {
                                startActivity(new Intent(Settings.this, Third.class));
                            }
                        });
                    }
                }
            }
        });

        mypopupWindow = new PopupWindow(view, RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT, true);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
        if (parent.getId() == R.id.SpinnerTextSize) {
            String valueFromSpinner = parent.getItemAtPosition(i).toString();
            ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
            ((TextView) parent.getChildAt(0)).setTextSize(15);

            SharedPrefs.setSecurityQuestion(getApplicationContext(), valueFromSpinner);

        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case 10:
                if (resultCode == RESULT_OK && data != null) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    SharedPrefs.setVoiceLockOnOff(getApplicationContext(), result.get(0));
                    SharedPrefs.setVoiceLock(getApplicationContext(), true);
                    VoiceSwitch.setChecked(true);

                }
                break;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        new NetworkConnection().callNetworkConnection(this);
        new AOM_Activity().showAppOpenAdsActivity(this);
        CommonData.aom_adCount = 0;
    }


    @Override
    public void onBackPressed() {
        if (new AdsPreferences(this).getAdsOnback()) {
            new InterstitialAdManager(this).loadInterstitialAll(new OnAdCallBack() {
                @Override
                public void onAdDismiss() {
                    onBack();
                }
            });
        } else {
            onBack();
        }
    }

    public void onBack() {
        super.onBackPressed();
        CommonData.aom_adCount = 0;
    }

}