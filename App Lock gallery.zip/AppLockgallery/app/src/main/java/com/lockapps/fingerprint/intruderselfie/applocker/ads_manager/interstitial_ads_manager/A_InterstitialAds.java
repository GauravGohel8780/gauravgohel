package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager;

//package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager;
//
//import android.app.Activity;
//import android.app.Dialog;
//import android.content.ActivityNotFoundException;
//import android.graphics.drawable.ColorDrawable;
//import android.view.Window;
//import android.view.WindowManager;
//
//import com.adjust.sdk.Adjust;
//import com.adjust.sdk.AdjustAdRevenue;
//import com.adjust.sdk.AdjustConfig;
//import com.lockapps.fingerprint.intruderselfie.applocker.R;
//import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
//import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.OnAdCallBack;
//import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;
//import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.DataUtils;
//import com.applovin.mediation.MaxAd;
//import com.applovin.mediation.MaxAdListener;
//import com.applovin.mediation.MaxAdRevenueListener;
//import com.applovin.mediation.MaxError;
//import com.applovin.mediation.ads.MaxInterstitialAd;
//
//import java.util.concurrent.TimeUnit;
//
//public class A_InterstitialAds {
//
//    Activity activity;
//    private Dialog adsDialog;
//
//    public A_InterstitialAds(Activity activity) {
//        this.activity = activity;
//    }
//
//    //=============== Pre Load Applovin Ads ===================
//    //=============== Pre Load Applovin Ads ===================
//    //=============== Pre Load Applovin Ads ===================
//
//    public void preLoadApplovin() {
//        try {
//            CommonData.maxInterstitialAd = new MaxInterstitialAd(new AdsPreferences(activity).getAppLovinInterstitial(), activity);
//
//            CommonData.maxInterstitialAd.setListener(new MaxAdListener() {
//                @Override
//                public void onAdLoaded(final MaxAd ad) {
////                    if (CommonData.maxInterstitialAd.isReady()) {
////                        CommonData.maxInterstitialAd.showAd();
////                    }
//                }
//
//                @Override
//                public void onAdLoadFailed(final String adUnitId, final MaxError maxError) {
//                    preLoadApplovin2();
//                }
//
//                @Override
//                public void onAdDisplayFailed(final MaxAd ad, final MaxError maxError) {
//                    preLoadApplovin2();
//                }
//
//                @Override
//                public void onAdDisplayed(final MaxAd ad) {
//                }
//
//                @Override
//                public void onAdClicked(final MaxAd ad) {
//                }
//
//                @Override
//                public void onAdHidden(final MaxAd ad) {
//                    // Intent call
//                    CommonData.is_ShowingAd = false;
//                    new AdsPreferences(activity).setAdsTimeCount((int) TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()));
//                    new AdsPreferences(activity).setAdsClickCount(0);
//                    preLoadApplovin();
//                }
//            });
//
//            CommonData.maxInterstitialAd.setRevenueListener(new MaxAdRevenueListener() {
//                @Override
//                public void onAdRevenuePaid(MaxAd maxAd) {
//                    AdjustAdRevenue adjustAdRevenue = new AdjustAdRevenue(AdjustConfig.AD_REVENUE_APPLOVIN_MAX);
//                    adjustAdRevenue.setRevenue(maxAd.getRevenue(), "USD");
//                    adjustAdRevenue.setAdRevenueNetwork(maxAd.getNetworkName());
//                    adjustAdRevenue.setAdRevenueUnit(maxAd.getAdUnitId());
//                    adjustAdRevenue.setAdRevenuePlacement(maxAd.getPlacement());
//
//                    Adjust.trackAdRevenue(adjustAdRevenue);
//                }
//            });
//            CommonData.maxInterstitialAd.loadAd();
//        } catch (NullPointerException | WindowManager.BadTokenException | ActivityNotFoundException e) {
//            e.printStackTrace();
//        }
//    }
//
//    public void preLoadApplovin2() {
//        try {
//            CommonData.maxInterstitialAd = new MaxInterstitialAd(new AdsPreferences(activity).getAppLovinInterstitial(), activity);
//
//            CommonData.maxInterstitialAd.setListener(new MaxAdListener() {
//                @Override
//                public void onAdLoaded(final MaxAd ad) {
////                    if (CommonData.maxInterstitialAd.isReady()) {
////                        CommonData.maxInterstitialAd.showAd();
////                    }
//                }
//
//                @Override
//                public void onAdLoadFailed(final String adUnitId, final MaxError maxError) {
//
//                }
//
//                @Override
//                public void onAdDisplayFailed(final MaxAd ad, final MaxError maxError) {
//
//                }
//
//                @Override
//                public void onAdDisplayed(final MaxAd ad) {
//                }
//
//                @Override
//                public void onAdClicked(final MaxAd ad) {
//                }
//
//                @Override
//                public void onAdHidden(final MaxAd ad) {
//                    // Intent call
//                    CommonData.is_ShowingAd = false;
//                    new AdsPreferences(activity).setAdsTimeCount((int) TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()));
//                    new AdsPreferences(activity).setAdsClickCount(0);
//                    preLoadApplovin();
//                }
//            });
//
//            CommonData.maxInterstitialAd.setRevenueListener(new MaxAdRevenueListener() {
//                @Override
//                public void onAdRevenuePaid(MaxAd maxAd) {
//                    AdjustAdRevenue adjustAdRevenue = new AdjustAdRevenue(AdjustConfig.AD_REVENUE_APPLOVIN_MAX);
//                    adjustAdRevenue.setRevenue(maxAd.getRevenue(), "USD");
//                    adjustAdRevenue.setAdRevenueNetwork(maxAd.getNetworkName());
//                    adjustAdRevenue.setAdRevenueUnit(maxAd.getAdUnitId());
//                    adjustAdRevenue.setAdRevenuePlacement(maxAd.getPlacement());
//
//                    Adjust.trackAdRevenue(adjustAdRevenue);
//                }
//            });
//            CommonData.maxInterstitialAd.loadAd();
//        } catch (NullPointerException | WindowManager.BadTokenException | ActivityNotFoundException e) {
//            e.printStackTrace();
//        }
//    }
//
//    //=============== Click Load Applovin Ads ===================
//    //=============== Click Load Applovin Ads ===================
//    //=============== Click Load Applovin Ads ===================
//
//    public void clickLoadApplovin(OnAdCallBack onAdCallBack) {
//        try {
//            if (adsDialog != null) {
//                adsDialog.dismiss();
//            }
//            adsDialog = new Dialog(activity);
//            adsDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//            adsDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
//            adsDialog.setCancelable(false);
//            adsDialog.setContentView(R.layout.ad_loading);
//            adsDialog.show();
//            CommonData.maxInterstitialAd = new MaxInterstitialAd(new AdsPreferences(activity).getAppLovinInterstitial(), activity);
//
//            CommonData.maxInterstitialAd.setListener(new MaxAdListener() {
//                @Override
//                public void onAdLoaded(final MaxAd ad) {
//                    adsDialog.dismiss();
//                    if (CommonData.maxInterstitialAd.isReady()) {
//                        CommonData.maxInterstitialAd.showAd();
//                    }
//                }
//
//                @Override
//                public void onAdLoadFailed(final String adUnitId, final MaxError maxError) {
//                    clickLoadApplovin2(onAdCallBack);
//                }
//
//                @Override
//                public void onAdDisplayFailed(final MaxAd ad, final MaxError maxError) {
//                    clickLoadApplovin2(onAdCallBack);
//                }
//
//                @Override
//                public void onAdDisplayed(final MaxAd ad) {
//
//                }
//
//                @Override
//                public void onAdClicked(final MaxAd ad) {
//                }
//
//                @Override
//                public void onAdHidden(final MaxAd ad) {
//                    CommonData.is_ShowingAd = false;
//                    new AdsPreferences(activity).setAdsTimeCount((int) TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()));
//                    new AdsPreferences(activity).setAdsClickCount(0);
//                    new InterstitialAdManager(activity)._nextActivity(onAdCallBack);
//                }
//            });
//
//            CommonData.maxInterstitialAd.setRevenueListener(new MaxAdRevenueListener() {
//                @Override
//                public void onAdRevenuePaid(MaxAd maxAd) {
//                    AdjustAdRevenue adjustAdRevenue = new AdjustAdRevenue(AdjustConfig.AD_REVENUE_APPLOVIN_MAX);
//                    adjustAdRevenue.setRevenue(maxAd.getRevenue(), "USD");
//                    adjustAdRevenue.setAdRevenueNetwork(maxAd.getNetworkName());
//                    adjustAdRevenue.setAdRevenueUnit(maxAd.getAdUnitId());
//                    adjustAdRevenue.setAdRevenuePlacement(maxAd.getPlacement());
//
//                    Adjust.trackAdRevenue(adjustAdRevenue);
//                }
//            });
//            CommonData.maxInterstitialAd.loadAd();
//        } catch (NullPointerException | WindowManager.BadTokenException | ActivityNotFoundException e) {
//            e.printStackTrace();
//        }
//    }
//
//    public void clickLoadApplovin2(OnAdCallBack onAdCallBack) {
//        try {
//            CommonData.maxInterstitialAd = new MaxInterstitialAd(new AdsPreferences(activity).getAppLovinInterstitial(), activity);
//
//            CommonData.maxInterstitialAd.setListener(new MaxAdListener() {
//                @Override
//                public void onAdLoaded(final MaxAd ad) {
//                    adsDialog.dismiss();
//                    if (CommonData.maxInterstitialAd.isReady()) {
//                        CommonData.maxInterstitialAd.showAd();
//                    }
//                }
//
//                @Override
//                public void onAdLoadFailed(final String adUnitId, final MaxError maxError) {
//                    adsDialog.dismiss();
//                    new InterstitialAdManager(activity)._nextActivity(onAdCallBack);
//                }
//
//                @Override
//                public void onAdDisplayFailed(final MaxAd ad, final MaxError maxError) {
//
//                }
//
//                @Override
//                public void onAdDisplayed(final MaxAd ad) {
////                preLoadApplovin(activity);
//                }
//
//                @Override
//                public void onAdClicked(final MaxAd ad) {
//                }
//
//                @Override
//                public void onAdHidden(final MaxAd ad) {
//                    // Intent call
//                    new InterstitialAdManager(activity)._nextActivity(onAdCallBack);
//                    CommonData.is_ShowingAd = false;
//                    new AdsPreferences(activity).setAdsTimeCount((int) TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()));
//                    new AdsPreferences(activity).setAdsClickCount(0);
//                }
//            });
//
//            CommonData.maxInterstitialAd.setRevenueListener(new MaxAdRevenueListener() {
//                @Override
//                public void onAdRevenuePaid(MaxAd maxAd) {
//                    AdjustAdRevenue adjustAdRevenue = new AdjustAdRevenue(AdjustConfig.AD_REVENUE_APPLOVIN_MAX);
//                    adjustAdRevenue.setRevenue(maxAd.getRevenue(), "USD");
//                    adjustAdRevenue.setAdRevenueNetwork(maxAd.getNetworkName());
//                    adjustAdRevenue.setAdRevenueUnit(maxAd.getAdUnitId());
//                    adjustAdRevenue.setAdRevenuePlacement(maxAd.getPlacement());
//
//                    Adjust.trackAdRevenue(adjustAdRevenue);
//                }
//            });
//            CommonData.maxInterstitialAd.loadAd();
//        } catch (NullPointerException | WindowManager.BadTokenException | ActivityNotFoundException e) {
//            e.printStackTrace();
//        }
//    }
//
//}
