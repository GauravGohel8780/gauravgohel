package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.app_open_ad;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;

public class AOM_Activity {

    private AppOpenAd appOpenAd = null;

    public void loadAd_intent(Activity activity) {
        if (CommonData.is_ShowingAd) {
            Log.i(CommonData.TAG, "AOM_Activity: Admob --> Already Show()");
            return;
        }

        AdRequest request = new AdRequest.Builder().build();
        AppOpenAd.load(activity, new AdsPreferences(activity).getAdmobAppOpen(), request, AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, new AppOpenAd.AppOpenAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull AppOpenAd ad) {
                Log.i(CommonData.TAG, "AOM_Activity: Admob --> onAdLoaded() -->" + CommonData.aom_adCount);

                CommonData.is_ShowingAd = true;
                appOpenAd = ad;
                appOpenAd.show(activity);

                Log.i(CommonData.TAG, "AOM_Activity: Admob --> onAdShow() -->" + CommonData.aom_adCount);

                appOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        appOpenAd = null;
                        CommonData.aom_adCount = 0;
                        CommonData.is_ShowingAd = false;
                        CommonData.is_ShowingAdClose = true;

                        Log.i(CommonData.TAG, "AOM_Activity: Admob --> setFullScreenContentCallback() -->" + CommonData.aom_adCount);
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                        appOpenAd = null;
                        CommonData.aom_adCount = 0;
                        CommonData.is_ShowingAd = false;
                        loadAdx_intent(activity);

                        Log.i(CommonData.TAG, "AOM_Activity: Admob --> onAdFailedToShowFullScreenContent() -->" + CommonData.aom_adCount);
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                    }
                });
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                Log.i(CommonData.TAG, "AOM_Activity: Admob --> onAdLoaded() -->" + CommonData.aom_adCount);

                loadAdx_intent(activity);
            }
        });
    }

    public void loadAdx_intent(Activity activity) {
        if (CommonData.is_ShowingAd) {
            Log.i(CommonData.TAG, "AOM_Activity: ADX --> Already Show()");
            return;
        }

        AdRequest request = new AdRequest.Builder().build();
        AppOpenAd.load(activity, new AdsPreferences(activity).getAdxAppOpen(), request, AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, new AppOpenAd.AppOpenAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull AppOpenAd ad) {
                Log.i(CommonData.TAG, "AOM_Activity: ADX --> onAdLoaded() -->" + CommonData.aom_adCount);

                CommonData.is_ShowingAd = true;
                appOpenAd = ad;
                appOpenAd.show(activity);

                Log.i(CommonData.TAG, "AOM_Activity: ADX --> onAdShow() -->" + CommonData.aom_adCount);

                appOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        appOpenAd = null;
                        CommonData.aom_adCount = 0;
                        CommonData.is_ShowingAd = false;
                        CommonData.is_ShowingAdClose = true;

                        Log.i(CommonData.TAG, "AOM_Activity: ADX --> onAdDismissedFullScreenContent() -->" + CommonData.aom_adCount);
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                        appOpenAd = null;
                        CommonData.aom_adCount = 1;
                        CommonData.is_ShowingAd = false;

                        Log.i(CommonData.TAG, "AOM_Activity: ADX --> onAdFailedToShowFullScreenContent() -->" + CommonData.aom_adCount);
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                    }
                });
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                appOpenAd = null;
                CommonData.aom_adCount = 1;
                CommonData.is_ShowingAd = false;

                Log.i(CommonData.TAG, "AOM_Activity: ADX --> onAdFailedToLoad() -->" + CommonData.aom_adCount);
            }
        });
    }

    public void showAppOpenAdsActivity(Activity activity) {
        CommonData.aom_adCount = CommonData.aom_adCount + 1;
        Log.i(CommonData.TAG, "AOM_Activity: onResume: " + CommonData.aom_adCount);
        if (CommonData.aom_adCount >= 2) {
            CommonData.aom_adCount = 1;
            Log.i(CommonData.TAG, "AOM_Activity: onResume: Match" + CommonData.aom_adCount);
            loadAd_intent(activity);
        }
    }
}
