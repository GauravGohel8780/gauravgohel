package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.internet.NetworkConnection;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.retrofit_client.GetDataFromServer;


public abstract class SplashBaseActivity extends AppCompatActivity {

    public abstract int setLayout();

    public abstract Class className();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        new CommonAppMethodes(this).SetSystemFullScreen();
        setContentView(setLayout());

        new NetworkConnection().callNetworkConnection(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (new NetworkConnection().isNetworkConnected(this)) {
            new GetDataFromServer(this).getAdDataUsingVolly(new OnAdCallBack() {
                @Override
                public void onAdDismiss() {
                    startActivity(new Intent(getApplicationContext(), className()));
                }
            });
        }

//        HomeWatcher.startWatching(this);
    }
}
