package com.lockapps.fingerprint.intruderselfie.applocker.Activities;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.content.ContextCompat;

import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.SharedPrefs;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.OnAdCallBack;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.internet.NetworkConnection;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.InterstitialAdManager;

public class MainActivity extends AppCompatActivity {

    AppCompatButton start;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SetSystemFullScreen();
        setContentView(R.layout.activity_main);

        start = findViewById(R.id.start);

        SharedPrefs.setLockType(getApplicationContext(), "Pattern");

        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.black));

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Second.class));
//                SharedPrefs.setLockIsOnOff(getApplicationContext(), true);
            }
        });
    }

    @Override
    public void onBackPressed() {
        finishAffinity();
    }

    public void SetSystemFullScreen() {
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) { // lower api
            View v = getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }
}
