package com.lockapps.fingerprint.intruderselfie.applocker.Gallery;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Audio.AudioFragment;
import com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Photo.PhotoFragment;
import com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Video.VideoFragment;
import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.app_open_ad.AOM_Activity;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.OnAdCallBack;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.internet.NetworkConnection;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.InterstitialAdManager;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager.NativeAdManager;

public class GalleryActivity extends AppCompatActivity {

    LinearLayout photo, video, audio, ll1;
    FrameLayout main_container;
    Button permission;
    NestedScrollView svgallery;

    private static final int REQUEST_CODE_RUNNER = 123;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);

        photo = findViewById(R.id.photo);
        video = findViewById(R.id.video);
        audio = findViewById(R.id.audio);
        main_container = findViewById(R.id.main_container);
        permission = findViewById(R.id.permission);
        svgallery = findViewById(R.id.svgallery);
        ll1 = findViewById(R.id.ll1);

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(getResources().getColor(R.color.darkcolor));
        }

        if (checkWriteExternalPermission()) {
            new NativeAdManager(this).showBottomNativeAdsDialog();
        }


        if (checkWriteExternalPermission()) {
            ll1.setVisibility(View.GONE);
            svgallery.setVisibility(View.VISIBLE);
            showFragment(new PhotoFragment());
        } else {
            ll1.setVisibility(View.VISIBLE);
            svgallery.setVisibility(View.GONE);
        }


        video.setOnClickListener(view -> {
            displayView(0);
        });

        photo.setOnClickListener(view -> {
            displayView(1);
        });

        audio.setOnClickListener(view -> {
            displayView(2);
        });


        permission.setOnClickListener(view -> {
            if (ContextCompat.checkSelfPermission(GalleryActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(GalleryActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        REQUEST_CODE_RUNNER);
            }
        });
    }

    /*storeg permission*/

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_RUNNER) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                permissiondialog();
            }
        }
    }

    private void permissiondialog() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.permissiondillog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setCancelable(false);
        Window window = dialog.getWindow();
        WindowManager.LayoutParams attributes = window.getAttributes();
        attributes.gravity = Gravity.CENTER;
        window.setAttributes(attributes);
        dialog.show();

        Button permissiondilog = dialog.findViewById(R.id.permission);
        permissiondilog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });
    }

    private boolean checkWriteExternalPermission() {
        String permission = Manifest.permission.WRITE_EXTERNAL_STORAGE;
        int res = checkCallingOrSelfPermission(permission);
        return (res == PackageManager.PERMISSION_GRANTED);
    }


    @Override
    protected void onResume() {
        super.onResume();

        new NetworkConnection().callNetworkConnection(this);
        new AOM_Activity().showAppOpenAdsActivity(this);

        if (checkWriteExternalPermission()) {
            ll1.setVisibility(View.GONE);
            svgallery.setVisibility(View.VISIBLE);
        }
    }


    /*storeg show*/


    private void displayView(int position) {
        switch (position) {
            case 0:
                showFragment(new VideoFragment());
                break;
            case 1:
                showFragment(new PhotoFragment());
                break;
            case 2:
                showFragment(new AudioFragment());
                break;
        }
    }

    public void showFragment(Fragment fragment) {
        FragmentTransaction mTransactiont = getSupportFragmentManager().beginTransaction();
        mTransactiont.replace(R.id.main_container, fragment, fragment.getClass().getName());
        mTransactiont.commit();
    }

    @Override
    public void onBackPressed() {
        if (new AdsPreferences(this).getAdsOnback()) {
            new InterstitialAdManager(this).loadInterstitialAll(new OnAdCallBack() {
                @Override
                public void onAdDismiss() {
                    onBack();
                }
            });
        } else {
            onBack();
        }
    }

    public void onBack() {
        super.onBackPressed();
        CommonData.aom_adCount = 0;

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        showFragment(new PhotoFragment());
    }
}