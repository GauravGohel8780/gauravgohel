package com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Photo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;
import com.lockapps.fingerprint.intruderselfie.applocker.R;

import java.util.ArrayList;
import java.util.Objects;

public class PhotoViewPagerAdapter extends PagerAdapter {


    Context context;
    private ArrayList<PhotoItemModel> images;
    LayoutInflater mLayoutInflater;


    public PhotoViewPagerAdapter(Context context, ArrayList<PhotoItemModel> images) {
        this.context = context;
        this.images = images;
        mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }


    @Override
    public int getCount() {
        return images.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }


    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, final int position) {

        PhotoItemModel model = images.get(position);

        View itemView = mLayoutInflater.inflate(R.layout.picture_browser_pager, container, false);

        ImageView imageView = itemView.findViewById(R.id.image);

        Glide.with(context).load(model.getPicturePath()).into(imageView);



        Objects.requireNonNull(container).addView(itemView);

        return itemView;
    }


    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((RelativeLayout) object);
    }

}
