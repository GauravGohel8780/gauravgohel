package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager;//package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager;
//
//import android.app.Activity;
//
//import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
//import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;
//import com.applovin.mediation.MaxAd;
//import com.applovin.mediation.MaxError;
//import com.applovin.mediation.nativeAds.MaxNativeAdListener;
//import com.applovin.mediation.nativeAds.MaxNativeAdLoader;
//import com.applovin.mediation.nativeAds.MaxNativeAdView;
//
//public class A_NativeAds {
//
//    Activity activity;
//
//    public A_NativeAds(Activity activity) {
//        this.activity = activity;
//    }
//
//
//    //=========================== (1) ==========================
//    //=========================== (1) ==========================
//
//    //=============== Pre Load GA Native Ad ===================
//    //=============== Pre Load GA Native Ad ===================
//
//    public void preLoadApplovinAds() {
//        CommonData.al_nativeLoader = new MaxNativeAdLoader(new AdsPreferences(activity).getAppLovinNative(), activity);
//        CommonData.al_nativeLoader.setNativeAdListener(new MaxNativeAdListener() {
//            @Override
//            public void onNativeAdLoaded(final MaxNativeAdView nativeAdView, final MaxAd ad) {
//
//                // Cleanup any pre-existing native ad to prevent memory leaks.
//                if (CommonData.al_nativeAd != null) {
//                    CommonData.al_nativeLoader.destroy(CommonData.al_nativeAd);
//                }
//
//                // Save ad to be rendered later.
//                CommonData.al_nativeAd = ad;
//
//            }
//
//            @Override
//            public void onNativeAdLoadFailed(final String adUnitId, final MaxError error) {
//                preLoadApplovinAds2();
//            }
//
//            @Override
//            public void onNativeAdClicked(final MaxAd ad) {
//            }
//        });
//        CommonData.al_nativeLoader.loadAd();
//    }
//
//    public void preLoadApplovinAds2() {
//        CommonData.al_nativeLoader = new MaxNativeAdLoader(new AdsPreferences(activity).getAppLovinNative(), activity);
//        CommonData.al_nativeLoader.setNativeAdListener(new MaxNativeAdListener() {
//            @Override
//            public void onNativeAdLoaded(final MaxNativeAdView nativeAdView, final MaxAd ad) {
//
//                // Cleanup any pre-existing native ad to prevent memory leaks.
//                if (CommonData.al_nativeAd != null) {
//                    CommonData.al_nativeLoader.destroy(CommonData.al_nativeAd);
//                }
//
//                // Save ad to be rendered later.
//                CommonData.al_nativeAd = ad;
//
//            }
//
//            @Override
//            public void onNativeAdLoadFailed(final String adUnitId, final MaxError error) {
//                CommonData.is_last_native_failed = true;
//            }
//
//            @Override
//            public void onNativeAdClicked(final MaxAd ad) {
//            }
//        });
//        CommonData.al_nativeLoader.loadAd();
//    }
//
//
//    //=========================== (2) ==========================
//    //=========================== (2) ==========================
//
//    //=============== Pre Load GA Native Banner Ad ===================
//    //=============== Pre Load GA Native Banner Ad ===================
//
//    public void preLoadApplovinNativebanner() {
//        CommonData.al_nativeBannerLoader = new MaxNativeAdLoader(new AdsPreferences(activity).getAppLovinNativeBanner(), activity);
//        CommonData.al_nativeBannerLoader.setNativeAdListener(new MaxNativeAdListener() {
//            @Override
//            public void onNativeAdLoaded(final MaxNativeAdView nativeAdView, final MaxAd ad) {
//
//                // Cleanup any pre-existing native ad to prevent memory leaks.
//                if (CommonData.al_nativeBannerAd != null) {
//                    CommonData.al_nativeBannerLoader.destroy(CommonData.al_nativeBannerAd);
//                }
//
//                // Save ad to be rendered later.
//                CommonData.al_nativeBannerAd = ad;
//
//            }
//
//            @Override
//            public void onNativeAdLoadFailed(final String adUnitId, final MaxError error) {
//                preLoadApplovinNativebanner2();
//            }
//
//            @Override
//            public void onNativeAdClicked(final MaxAd ad) {
//            }
//        });
//        CommonData.al_nativeBannerLoader.loadAd();
//    }
//
//    public void preLoadApplovinNativebanner2() {
//        CommonData.al_nativeBannerLoader = new MaxNativeAdLoader(new AdsPreferences(activity).getAppLovinNativeBanner(), activity);
//        CommonData.al_nativeBannerLoader.setNativeAdListener(new MaxNativeAdListener() {
//            @Override
//            public void onNativeAdLoaded(final MaxNativeAdView nativeAdView, final MaxAd ad) {
//
//                // Cleanup any pre-existing native ad to prevent memory leaks.
//                if (CommonData.al_nativeBannerAd != null) {
//                    CommonData.al_nativeBannerLoader.destroy(CommonData.al_nativeBannerAd);
//                }
//
//                // Save ad to be rendered later.
//                CommonData.al_nativeBannerAd = ad;
//
//            }
//
//            @Override
//            public void onNativeAdLoadFailed(final String adUnitId, final MaxError error) {
//                CommonData.is_last_native_failed = true;
//            }
//
//            @Override
//            public void onNativeAdClicked(final MaxAd ad) {
//            }
//        });
//        CommonData.al_nativeBannerLoader.loadAd();
//    }
//
//
//
//    //=========================== (3) ==========================
//    //=========================== (3) ==========================
//
//
//    //=============== Pre Load GA Native Banner Mid Ad ===================
//    //=============== Pre Load GA Native Banner Mid Ad ===================
//
//    public void preLoadApplovinNativebannerMid() {
//        CommonData.al_nativeBannerLoader2 = new MaxNativeAdLoader(new AdsPreferences(activity).getAppLovinNativeBanner(), activity);
//        CommonData.al_nativeBannerLoader2.setNativeAdListener(new MaxNativeAdListener() {
//            @Override
//            public void onNativeAdLoaded(final MaxNativeAdView nativeAdView, final MaxAd ad) {
//
//                // Cleanup any pre-existing native ad to prevent memory leaks.
//                if (CommonData.al_nativeBannerAd2 != null) {
//                    CommonData.al_nativeBannerLoader2.destroy(CommonData.al_nativeBannerAd2);
//                }
//
//                // Save ad to be rendered later.
//                CommonData.al_nativeBannerAd2 = ad;
//
//            }
//
//            @Override
//            public void onNativeAdLoadFailed(final String adUnitId, final MaxError error) {
//                preLoadApplovinNativebannerMid2();
//            }
//
//            @Override
//            public void onNativeAdClicked(final MaxAd ad) {
//            }
//        });
//        CommonData.al_nativeBannerLoader2.loadAd();
//    }
//
//    public void preLoadApplovinNativebannerMid2() {
//        CommonData.al_nativeBannerLoader2 = new MaxNativeAdLoader(new AdsPreferences(activity).getAppLovinNativeBanner(), activity);
//        CommonData.al_nativeBannerLoader2.setNativeAdListener(new MaxNativeAdListener() {
//            @Override
//            public void onNativeAdLoaded(final MaxNativeAdView nativeAdView, final MaxAd ad) {
//
//                // Cleanup any pre-existing native ad to prevent memory leaks.
//                if (CommonData.al_nativeBannerAd2 != null) {
//                    CommonData.al_nativeBannerLoader2.destroy(CommonData.al_nativeBannerAd2);
//                }
//
//                // Save ad to be rendered later.
//                CommonData.al_nativeBannerAd2 = ad;
//
//            }
//
//            @Override
//            public void onNativeAdLoadFailed(final String adUnitId, final MaxError error) {
//                CommonData.is_last_native_failed = true;
//            }
//
//            @Override
//            public void onNativeAdClicked(final MaxAd ad) {
//            }
//        });
//        CommonData.al_nativeBannerLoader2.loadAd();
//    }
//
//
//    //=========================== (4) ==========================
//    //=========================== (4) ==========================
//
//
//    //=============== Pre Load GA Native Bottom Banner Ad ===================
//    //=============== Pre Load GA Native Bottom Banner Ad ===================
//
//    public void preLoadApplovinNativeBottombanner() {
//        CommonData.al_nativeBottomBannerLoader = new MaxNativeAdLoader(new AdsPreferences(activity).getAppLovinNativeBanner(), activity);
//        CommonData.al_nativeBottomBannerLoader.setNativeAdListener(new MaxNativeAdListener() {
//            @Override
//            public void onNativeAdLoaded(final MaxNativeAdView nativeAdView, final MaxAd ad) {
//
//                // Cleanup any pre-existing native ad to prevent memory leaks.
//                if (CommonData.al_nativeBottomBannerAd != null) {
//                    CommonData.al_nativeBottomBannerLoader.destroy(CommonData.al_nativeBottomBannerAd);
//                }
//
//                // Save ad to be rendered later.
//                CommonData.al_nativeBottomBannerAd = ad;
//
//            }
//
//            @Override
//            public void onNativeAdLoadFailed(final String adUnitId, final MaxError error) {
//                preLoadApplovinNativeBottombanner2();
//            }
//
//            @Override
//            public void onNativeAdClicked(final MaxAd ad) {
//            }
//        });
//        CommonData.al_nativeBottomBannerLoader.loadAd();
//    }
//
//    public void preLoadApplovinNativeBottombanner2() {
//        CommonData.al_nativeBottomBannerLoader = new MaxNativeAdLoader(new AdsPreferences(activity).getAppLovinNativeBanner(), activity);
//        CommonData.al_nativeBottomBannerLoader.setNativeAdListener(new MaxNativeAdListener() {
//            @Override
//            public void onNativeAdLoaded(final MaxNativeAdView nativeAdView, final MaxAd ad) {
//
//                // Cleanup any pre-existing native ad to prevent memory leaks.
//                if (CommonData.al_nativeBottomBannerAd != null) {
//                    CommonData.al_nativeBottomBannerLoader.destroy(CommonData.al_nativeBottomBannerAd);
//                }
//
//                // Save ad to be rendered later.
//                CommonData.al_nativeBottomBannerAd = ad;
//
//            }
//
//            @Override
//            public void onNativeAdLoadFailed(final String adUnitId, final MaxError error) {
//                CommonData.is_last_native_failed = true;
//            }
//
//            @Override
//            public void onNativeAdClicked(final MaxAd ad) {
//            }
//        });
//        CommonData.al_nativeBottomBannerLoader.loadAd();
//    }
//}
