package com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.adapters;

import android.content.Context;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;
import com.lockapps.fingerprint.intruderselfie.applocker.IntruderModel;
import com.lockapps.fingerprint.intruderselfie.applocker.R;

import java.util.ArrayList;
import java.util.Objects;

public class IntruderPagerAdapter extends PagerAdapter {

    Context context;
    private ArrayList<IntruderModel> images;
    LayoutInflater mLayoutInflater;

    public IntruderPagerAdapter(Context context, ArrayList<IntruderModel> images) {
        this.context = context;
        this.images = images;
        mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return images.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == ((RelativeLayout) object);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {

        IntruderModel model = (IntruderModel) images.get(position);

        View itemView = mLayoutInflater.inflate(R.layout.intruder_pager_browser, container, false);

        ImageView imageView = (ImageView) itemView.findViewById(R.id.image);


        String path = Environment.getExternalStorageDirectory().getPath() + "/Pictures/iSelfie/" + model.getAppImage();


        Glide.with(context).load(path).into(imageView);


        Objects.requireNonNull(container).addView(itemView);

        return itemView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {

        container.removeView((RelativeLayout) object);
    }
}
