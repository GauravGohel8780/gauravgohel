package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;

public class FG_NativeAds {

    Activity activity;

    public FG_NativeAds(Activity activity) {
        this.activity = activity;
    }


    //=========================== (1) ==========================
    //=========================== (1) ==========================

    //=============== Pre Load GA Native Ad ===================

    //=============== Pre Load GA Native Ad ===================

    public void preLoadFbNative() {
        Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeAds --> pre_loadFacebook() --> Start");
        CommonData.facebook_nativeAd = new NativeAd(activity, new AdsPreferences(activity).getFacebookNative());
        NativeAdListener nativeAdListener = new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeAds --> pre_loadFacebook() --> onError");
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeAds --> ***");
                CommonData.facebook_nativeAd = null;
                preLoadFbNative2();
            }

            @Override
            public void onAdLoaded(Ad ad) {
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeAds --> pre_loadFacebook() --> onAdLoaded");
//                inflateAd(CommonData.facebook_nativeAd);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        };
        CommonData.facebook_nativeAd.loadAd(CommonData.facebook_nativeAd.buildLoadAdConfig()
                .withAdListener(nativeAdListener)
                .build());
    }

    public void preLoadFbNative2() {
        Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeAds --> pre_loadFacebook1() --> Start");
        CommonData.facebook_nativeAd = new NativeAd(activity, new AdsPreferences(activity).getFacebookNative());
        NativeAdListener nativeAdListener = new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeAds --> pre_loadFacebook1() --> onError");
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeAds --> ***");
                CommonData.facebook_nativeAd = null;
                preLoadAdmobNative();
            }

            @Override
            public void onAdLoaded(Ad ad) {
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeAds --> pre_loadFacebook1() --> onAdLoaded");
//                inflateAd(CommonData.facebook_nativeAd);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        };
        CommonData.facebook_nativeAd.loadAd(CommonData.facebook_nativeAd.buildLoadAdConfig()
                .withAdListener(nativeAdListener)
                .build());
    }

    public void preLoadAdmobNative() {
        AdLoader.Builder builder = new AdLoader.Builder(activity, new AdsPreferences(activity).getAdmobNative());
        builder.forNativeAd(nativeAd -> {
            CommonData.google_NativeAds = nativeAd;
        });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError errorCode) {
                Log.i(CommonData.TAG, "google_ads --> Google_NativeAds --> preload_Admob() --> onAdFailedToLoad");
                Log.i(CommonData.TAG, "google_ads --> Google_NativeAds --> ***");
                preLoadAdxNative();
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void preLoadAdxNative() {
        Log.i(CommonData.TAG, "google_ads --> Google_NativeAds --> preload_Adx() --> Start");
        AdLoader.Builder builder = new AdLoader.Builder(activity, new AdsPreferences(activity).getAdxNative());
        builder.forNativeAd(nativeAd -> {
            Log.i(CommonData.TAG, "google_ads --> Google_NativeAds --> preload_Adx() --> Loaded");
//            if (CommonData.google_NativeAds1 != null) {
//                CommonData.google_NativeAds1.destroy();
//            }
            CommonData.google_NativeAds = nativeAd;
        });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError errorCode) {
                Log.i(CommonData.TAG, "google_ads --> Google_NativeAds --> preload_Adx() --> onAdFailedToLoad");
                Log.i(CommonData.TAG, "google_ads --> Google_NativeAds --> ***");
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void onDemandLoadFbNative(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        try {
            new NativeAdManager(activity).NativeAdLoaderOnLoad();

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.VISIBLE);

            CommonData.facebook_nativeAd = new NativeAd(activity, new AdsPreferences(activity).getFacebookNative());
            NativeAdListener nativeAdListener = new NativeAdListener() {
                @Override
                public void onMediaDownloaded(Ad ad) {
                }

                @Override
                public void onError(Ad ad, AdError adError) {
                    onDemandLoadFbNative2(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    if (CommonData.facebook_nativeAd == null || CommonData.facebook_nativeAd != ad) {
                        return;
                    }

                    new NativeAdManager(activity).NativeDialogDismiss();

                    apps_FrameLayout.setVisibility(View.GONE);
                    ad_FrameLayout.setVisibility(View.GONE);
                    applovin_FrameLayout.setVisibility(View.GONE);
                    nativeAdLayout.setVisibility(View.VISIBLE);
                    ad_loading.setVisibility(View.GONE);

                    LinearLayout adView;
                    if (new NativeAdManager(activity).getRandomLay() == 1) {
                        adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_1, nativeAdLayout, false);
                    } else if (new NativeAdManager(activity).getRandomLay() == 2) {
                        adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_2, nativeAdLayout, false);
                    } else if (new NativeAdManager(activity).getRandomLay() == 3) {
                        adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_3, nativeAdLayout, false);
                    } else {
                        adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_4, nativeAdLayout, false);
                    }
                    new NativeAdsPopulate(activity).inflateFbNative(CommonData.facebook_nativeAd, nativeAdLayout, adView);
                }

                @Override
                public void onAdClicked(Ad ad) {
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                }
            };

            CommonData.facebook_nativeAd.loadAd(CommonData.facebook_nativeAd.buildLoadAdConfig()
                    .withAdListener(nativeAdListener).build());
        } catch (WindowManager.BadTokenException | ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void onDemandLoadFbNative2(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        try {

            CommonData.facebook_nativeAd = new NativeAd(activity, new AdsPreferences(activity).getFacebookNative());
            NativeAdListener nativeAdListener = new NativeAdListener() {
                @Override
                public void onMediaDownloaded(Ad ad) {
                }

                @Override
                public void onError(Ad ad, AdError adError) {
                    onDemandLoadAdmobNative(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    if (CommonData.facebook_nativeAd == null || CommonData.facebook_nativeAd != ad) {
                        return;
                    }

                    new NativeAdManager(activity).NativeDialogDismiss();

                    apps_FrameLayout.setVisibility(View.GONE);
                    ad_FrameLayout.setVisibility(View.GONE);
                    applovin_FrameLayout.setVisibility(View.GONE);
                    nativeAdLayout.setVisibility(View.VISIBLE);
                    ad_loading.setVisibility(View.GONE);

                    LinearLayout adView;
                    if (new NativeAdManager(activity).getRandomLay() == 1) {
                        adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_1, nativeAdLayout, false);
                    } else if (new NativeAdManager(activity).getRandomLay() == 2) {
                        adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_2, nativeAdLayout, false);
                    } else if (new NativeAdManager(activity).getRandomLay() == 3) {
                        adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_3, nativeAdLayout, false);
                    } else {
                        adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_big_4, nativeAdLayout, false);
                    }
                    new NativeAdsPopulate(activity).inflateFbNative(CommonData.facebook_nativeAd, nativeAdLayout, adView);
                }

                @Override
                public void onAdClicked(Ad ad) {
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                }
            };

            CommonData.facebook_nativeAd.loadAd(CommonData.facebook_nativeAd.buildLoadAdConfig()
                    .withAdListener(nativeAdListener).build());
        } catch (WindowManager.BadTokenException | ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void onDemandLoadAdmobNative(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        try {
            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.VISIBLE);

            AdLoader.Builder builder = new AdLoader.Builder(activity, new AdsPreferences(activity).getAdmobNative());
            builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {
                @Override
                public void onNativeAdLoaded(com.google.android.gms.ads.nativead.NativeAd nativeAd) {

                    new NativeAdManager(activity).NativeDialogDismiss();

                    boolean isDestroyed = false;
                    isDestroyed = activity.isDestroyed();
                    if (isDestroyed || activity.isFinishing() || activity.isChangingConfigurations()) {
                        nativeAd.destroy();
                        return;
                    }
                    if (CommonData.google_NativeAds != null) {
                        CommonData.google_NativeAds.destroy();
                    }
                    CommonData.google_NativeAds = nativeAd;

                    apps_FrameLayout.setVisibility(View.GONE);
                    ad_FrameLayout.setVisibility(View.VISIBLE);
                    applovin_FrameLayout.setVisibility(View.GONE);
                    nativeAdLayout.setVisibility(View.GONE);
                    ad_loading.setVisibility(View.GONE);

                    com.google.android.gms.ads.nativead.NativeAdView adView;
                    if (new NativeAdManager(activity).getRandomLay() == 1) {
                        adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_1, null);
                    } else if (new NativeAdManager(activity).getRandomLay() == 2) {
                        adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_2, null);
                    } else if (new NativeAdManager(activity).getRandomLay() == 3) {
                        adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_3, null);
                    } else {
                        adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_4, null);
                    }

                    new NativeAdsPopulate(activity).populateNativeMedia(nativeAd, adView);
                    ad_FrameLayout.removeAllViews();
                    ad_FrameLayout.addView(adView);
                }
            });

            VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(false).build();

            NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();

            builder.withNativeAdOptions(adOptions);

            AdLoader adLoader = builder.withAdListener(new AdListener() {
                @Override
                public void onAdFailedToLoad(LoadAdError loadAdError) {
                    onDemandLoadAdxNative(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                }
            }).build();

            adLoader.loadAd(new AdRequest.Builder().build());
        } catch (WindowManager.BadTokenException | ActivityNotFoundException e) {
            e.printStackTrace();
        }

    }

    public void onDemandLoadAdxNative(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        try {

            AdLoader.Builder builder = new AdLoader.Builder(activity, new AdsPreferences(activity).getAdxNative());
            builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {
                @Override
                public void onNativeAdLoaded(com.google.android.gms.ads.nativead.NativeAd nativeAd) {

                    new NativeAdManager(activity).NativeDialogDismiss();
                    boolean isDestroyed = false;
                    isDestroyed = activity.isDestroyed();
                    if (isDestroyed || activity.isFinishing() || activity.isChangingConfigurations()) {
                        nativeAd.destroy();
                        return;
                    }
                    if (CommonData.google_NativeAds != null) {
                        CommonData.google_NativeAds.destroy();
                    }
                    CommonData.google_NativeAds = nativeAd;

                    apps_FrameLayout.setVisibility(View.GONE);
                    ad_FrameLayout.setVisibility(View.VISIBLE);
                    applovin_FrameLayout.setVisibility(View.GONE);
                    nativeAdLayout.setVisibility(View.GONE);
                    ad_loading.setVisibility(View.GONE);

                    com.google.android.gms.ads.nativead.NativeAdView adView;
                    if (new NativeAdManager(activity).getRandomLay() == 1) {
                        adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_1, null);
                    } else if (new NativeAdManager(activity).getRandomLay() == 2) {
                        adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_2, null);
                    } else if (new NativeAdManager(activity).getRandomLay() == 3) {
                        adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_3, null);
                    } else {
                        adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_big_4, null);
                    }

                    new NativeAdsPopulate(activity).populateNativeMedia(nativeAd, adView);
                    ad_FrameLayout.removeAllViews();
                    ad_FrameLayout.addView(adView);
                }
            });

            VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(false).build();

            NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();

            builder.withNativeAdOptions(adOptions);

            AdLoader adLoader = builder.withAdListener(new AdListener() {
                @Override
                public void onAdFailedToLoad(LoadAdError loadAdError) {

                    new NativeAdManager(activity).NativeDialogDismiss();
                    new AppsAdManager(activity).onDemandLoadAppsNative(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                }
            }).build();

            adLoader.loadAd(new AdRequest.Builder().build());
        } catch (WindowManager.BadTokenException | ActivityNotFoundException e) {
            e.printStackTrace();
        }

    }


    //=========================== (2) ==========================
    //=========================== (2) ==========================

    //=============== Pre Load GA Native Banner Ad ===================
    //=============== Pre Load GA Native Banner Ad ===================

    public void preLoadFbNativeBanner() {
        Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBannerAds --> pre_loadFacebook() --> Start");
        CommonData.facebook_nativeBannerAd = new NativeAd(activity, new AdsPreferences(activity).getFacebookNativeBanner());
        NativeAdListener nativeAdListener = new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBannerAds --> pre_loadFacebook() --> onError");
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBannerAds --> ***");
                CommonData.facebook_nativeBannerAd = null;
                preLoadFbNativeBanner2();
            }

            @Override
            public void onAdLoaded(Ad ad) {
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBannerAds --> pre_loadFacebook() --> onAdLoaded");
//                inflateAd(CommonData.facebook_nativeBannerAd);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        };
        CommonData.facebook_nativeBannerAd.loadAd(CommonData.facebook_nativeBannerAd.buildLoadAdConfig()
                .withAdListener(nativeAdListener)
                .build());
    }

    public void preLoadFbNativeBanner2() {
        Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBannerAds --> load_Facebook1() --> Start");
        CommonData.facebook_nativeBannerAd = new NativeAd(activity, new AdsPreferences(activity).getFacebookNativeBanner());
        NativeAdListener nativeAdListener = new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBannerAds --> load_Facebook1() --> onError");
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBannerAds --> ***");
                CommonData.facebook_nativeBannerAd = null;
                preLoadAdmobNativeBanner();
            }

            @Override
            public void onAdLoaded(Ad ad) {
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBannerAds --> load_Facebook1() --> onAdLoaded");
//                inflateAd(CommonData.facebook_nativeBannerAd);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        };
        CommonData.facebook_nativeBannerAd.loadAd(CommonData.facebook_nativeBannerAd.buildLoadAdConfig()
                .withAdListener(nativeAdListener)
                .build());
    }

    public void preLoadAdmobNativeBanner() {
        Log.i(CommonData.TAG, "google_ads --> Google_NativeBannerAds --> preload_Admob() --> Start");
        AdLoader.Builder builder = new AdLoader.Builder(activity, new AdsPreferences(activity).getAdmobNativeBanner());
        builder.forNativeAd(nativeAd -> {
            Log.i(CommonData.TAG, "google_ads --> Google_NativeBannerAds --> preload_Admob() --> Loaded");
//            if (CommonData.google_NativeBannerAds != null) {
//                CommonData.google_NativeBannerAds.destroy();
//            }
            CommonData.google_NativeBannerAds = nativeAd;
        });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError errorCode) {
                Log.i(CommonData.TAG, "google_ads --> Google_NativeBannerAds --> preload_Admob() --> onAdFailedToLoad");
                Log.i(CommonData.TAG, "google_ads --> Google_NativeBannerAds --> ***");
                preLoadAdxNativeBanner();
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void preLoadAdxNativeBanner() {
        Log.i(CommonData.TAG, "google_ads --> Google_NativeBannerAds --> preload_Adx() --> Start");
        AdLoader.Builder builder = new AdLoader.Builder(activity, new AdsPreferences(activity).getAdxNativeBanner());
        builder.forNativeAd(nativeAd -> {
            Log.i(CommonData.TAG, "google_ads --> Google_NativeBannerAds --> preload_Adx() --> Loaded");
//            if (CommonData.google_NativeBannerAds1 != null) {
//                CommonData.google_NativeBannerAds1.destroy();
//            }
            CommonData.google_NativeBannerAds = nativeAd;
        });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError errorCode) {
                Log.i(CommonData.TAG, "google_ads --> Google_NativeBannerAds --> preload_Adx() --> onAdFailedToLoad");
                Log.i(CommonData.TAG, "google_ads --> Google_NativeBannerAds --> ***");
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void onDemandLoadFbNativeBanner(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        try {
            new NativeAdManager(activity).NativeAdLoaderOnLoad();

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.VISIBLE);

            CommonData.facebook_nativeBannerAd = new NativeAd(activity, new AdsPreferences(activity).getFacebookNative());
            NativeAdListener nativeAdListener = new NativeAdListener() {
                @Override
                public void onMediaDownloaded(Ad ad) {
                }

                @Override
                public void onError(Ad ad, AdError adError) {
                    onDemandLoadFbNativeBanner2(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    if (CommonData.facebook_nativeBannerAd == null || CommonData.facebook_nativeBannerAd != ad) {
                        return;
                    }

                    new NativeAdManager(activity).NativeDialogDismiss();

                    apps_FrameLayout.setVisibility(View.GONE);
                    ad_FrameLayout.setVisibility(View.GONE);
                    applovin_FrameLayout.setVisibility(View.GONE);
                    nativeAdLayout.setVisibility(View.VISIBLE);
                    ad_loading.setVisibility(View.GONE);

                    LinearLayout adView;
                    if (new NativeAdManager(activity).getRandomLay() == 1) {
                        adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_1, nativeAdLayout, false);
                    } else if (new NativeAdManager(activity).getRandomLay() == 2) {
                        adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_2, nativeAdLayout, false);
                    } else {
                        adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_3, nativeAdLayout, false);
                    }
                    new NativeAdsPopulate(activity).inflateFbNativeBanner(CommonData.facebook_nativeBannerAd, nativeAdLayout, adView);
                }

                @Override
                public void onAdClicked(Ad ad) {
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                }
            };

            CommonData.facebook_nativeBannerAd.loadAd(CommonData.facebook_nativeBannerAd.buildLoadAdConfig()
                    .withAdListener(nativeAdListener).build());
        } catch (WindowManager.BadTokenException | ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void onDemandLoadFbNativeBanner2(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        try {

            CommonData.facebook_nativeBannerAd = new NativeAd(activity, new AdsPreferences(activity).getFacebookNative());
            NativeAdListener nativeAdListener = new NativeAdListener() {
                @Override
                public void onMediaDownloaded(Ad ad) {
                }

                @Override
                public void onError(Ad ad, AdError adError) {
                    onDemandLoadAdmobNativeBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    if (CommonData.facebook_nativeBannerAd == null || CommonData.facebook_nativeBannerAd != ad) {
                        return;
                    }

                    new NativeAdManager(activity).NativeDialogDismiss();

                    apps_FrameLayout.setVisibility(View.GONE);
                    ad_FrameLayout.setVisibility(View.GONE);
                    applovin_FrameLayout.setVisibility(View.GONE);
                    nativeAdLayout.setVisibility(View.VISIBLE);
                    ad_loading.setVisibility(View.GONE);

                    LinearLayout adView;
                    if (new NativeAdManager(activity).getRandomLay() == 1) {
                        adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_1, nativeAdLayout, false);
                    } else if (new NativeAdManager(activity).getRandomLay() == 2) {
                        adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_2, nativeAdLayout, false);
                    } else {
                        adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner_3, nativeAdLayout, false);
                    }
                    new NativeAdsPopulate(activity).inflateFbNativeBanner(CommonData.facebook_nativeBannerAd, nativeAdLayout, adView);
                }

                @Override
                public void onAdClicked(Ad ad) {
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                }
            };

            CommonData.facebook_nativeBannerAd.loadAd(CommonData.facebook_nativeBannerAd.buildLoadAdConfig()
                    .withAdListener(nativeAdListener).build());
        } catch (WindowManager.BadTokenException | ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void onDemandLoadAdmobNativeBanner(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        try {
            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.VISIBLE);

            AdLoader.Builder builder = new AdLoader.Builder(activity, new AdsPreferences(activity).getAdmobNative());
            builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {
                @Override
                public void onNativeAdLoaded(com.google.android.gms.ads.nativead.NativeAd nativeAd) {

                    new NativeAdManager(activity).NativeDialogDismiss();
                    boolean isDestroyed = false;
                    isDestroyed = activity.isDestroyed();
                    if (isDestroyed || activity.isFinishing() || activity.isChangingConfigurations()) {
                        nativeAd.destroy();
                        return;
                    }
                    if (CommonData.google_NativeBannerAds != null) {
                        CommonData.google_NativeBannerAds.destroy();
                    }
                    CommonData.google_NativeBannerAds = nativeAd;

                    apps_FrameLayout.setVisibility(View.GONE);
                    ad_FrameLayout.setVisibility(View.VISIBLE);
                    applovin_FrameLayout.setVisibility(View.GONE);
                    nativeAdLayout.setVisibility(View.GONE);
                    ad_loading.setVisibility(View.GONE);

                    com.google.android.gms.ads.nativead.NativeAdView adView;
                    if (new NativeAdManager(activity).getRandomLay() == 1) {
                        adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_1, null);
                    } else if (new NativeAdManager(activity).getRandomLay() == 2) {
                        adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_2, null);
                    } else {
                        adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_3, null);
                    }

                    new NativeAdsPopulate(activity).populateNativeBannerMedia(nativeAd, adView);
                    ad_FrameLayout.removeAllViews();
                    ad_FrameLayout.addView(adView);
                }
            });

            VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(false).build();

            NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();

            builder.withNativeAdOptions(adOptions);

            AdLoader adLoader = builder.withAdListener(new AdListener() {
                @Override
                public void onAdFailedToLoad(LoadAdError loadAdError) {
                    onDemandLoadAdxNativeBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                }
            }).build();

            adLoader.loadAd(new AdRequest.Builder().build());
        } catch (WindowManager.BadTokenException | ActivityNotFoundException e) {
            e.printStackTrace();
        }

    }

    public void onDemandLoadAdxNativeBanner(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        try {

            AdLoader.Builder builder = new AdLoader.Builder(activity, new AdsPreferences(activity).getAdxNative());
            builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {
                @Override
                public void onNativeAdLoaded(com.google.android.gms.ads.nativead.NativeAd nativeAd) {

                    new NativeAdManager(activity).NativeDialogDismiss();

                    boolean isDestroyed = false;
                    isDestroyed = activity.isDestroyed();
                    if (isDestroyed || activity.isFinishing() || activity.isChangingConfigurations()) {
                        nativeAd.destroy();
                        return;
                    }
                    if (CommonData.google_NativeBannerAds != null) {
                        CommonData.google_NativeBannerAds.destroy();
                    }
                    CommonData.google_NativeBannerAds = nativeAd;

                    apps_FrameLayout.setVisibility(View.GONE);
                    ad_FrameLayout.setVisibility(View.VISIBLE);
                    applovin_FrameLayout.setVisibility(View.GONE);
                    nativeAdLayout.setVisibility(View.GONE);
                    ad_loading.setVisibility(View.GONE);

                    com.google.android.gms.ads.nativead.NativeAdView adView;
                    if (new NativeAdManager(activity).getRandomLay() == 1) {
                        adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_1, null);
                    } else if (new NativeAdManager(activity).getRandomLay() == 2) {
                        adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_2, null);
                    } else {
                        adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_3, null);
                    }

                    new NativeAdsPopulate(activity).populateNativeBannerMedia(nativeAd, adView);
                    ad_FrameLayout.removeAllViews();
                    ad_FrameLayout.addView(adView);
                }
            });

            VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(false).build();

            NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();

            builder.withNativeAdOptions(adOptions);

            AdLoader adLoader = builder.withAdListener(new AdListener() {
                @Override
                public void onAdFailedToLoad(LoadAdError loadAdError) {

                    new NativeAdManager(activity).NativeDialogDismiss();
                    new AppsAdManager(activity).onDemandLoadAppsNativeBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                }
            }).build();

            adLoader.loadAd(new AdRequest.Builder().build());
        } catch (WindowManager.BadTokenException | ActivityNotFoundException e) {
            e.printStackTrace();
        }

    }


    //=========================== (3) ==========================
    //=========================== (3) ==========================


    //=============== Pre Load GA Native Banner Mid Ad ===================
    //=============== Pre Load GA Native Banner Mid Ad ===================

    public void preLoadFbNativeBannerMid() {
        Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBottomBannerAds --> pre_loadFacebook() --> Start");
        CommonData.facebook_nativeBannerAd2 = new NativeBannerAd(activity, new AdsPreferences(activity).getFacebookNativeBanner());
        NativeAdListener nativeAdListener = new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBottomBannerAds --> pre_loadFacebook() --> onError");
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBottomBannerAds --> ***");
                CommonData.facebook_nativeBannerAd2 = null;
                preLoadFbNativeBannerMid2();
            }

            @Override
            public void onAdLoaded(Ad ad) {
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBottomBannerAds --> pre_loadFacebook() --> onAdLoaded");
//                inflateAd(CommonData.facebook_nativeBannerAd2);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        };
        CommonData.facebook_nativeBannerAd2.loadAd(CommonData.facebook_nativeBannerAd2.buildLoadAdConfig()
                .withAdListener(nativeAdListener)
                .build());
    }

    public void preLoadFbNativeBannerMid2() {
        Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBottomBannerAds --> load_Facebook1() --> Start");
        CommonData.facebook_nativeBannerAd2 = new NativeBannerAd(activity, new AdsPreferences(activity).getFacebookNativeBanner());
        NativeAdListener nativeAdListener = new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBottomBannerAds --> load_Facebook1() --> onError");
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBottomBannerAds --> ***");
                CommonData.facebook_nativeBannerAd2 = null;
                preLoadAdmobNativeBannerMid();
            }

            @Override
            public void onAdLoaded(Ad ad) {
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBottomBannerAds --> load_Facebook1() --> onAdLoaded");
//                inflateAd(CommonData.facebook_nativeBannerAd2);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        };
        CommonData.facebook_nativeBannerAd2.loadAd(CommonData.facebook_nativeBannerAd2.buildLoadAdConfig()
                .withAdListener(nativeAdListener)
                .build());
    }

    public void preLoadAdmobNativeBannerMid() {
        Log.i(CommonData.TAG, "google_ads --> Google_NativeBottomBannerAds --> preload_Admob() --> Start");
        AdLoader.Builder builder = new AdLoader.Builder(activity, new AdsPreferences(activity).getAdmobNativeBanner());
        builder.forNativeAd(nativeAd -> {
            Log.i(CommonData.TAG, "google_ads --> Google_NativeBottomBannerAds --> preload_Admob() --> Loaded");
//            if (CommonData.google_NativeBannerAds2 != null) {
//                CommonData.google_NativeBannerAds2.destroy();
//            }
            CommonData.google_NativeBannerAds2 = nativeAd;
        });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError errorCode) {
                Log.i(CommonData.TAG, "google_ads --> Google_NativeBottomBannerAds --> preload_Admob() --> onAdFailedToLoad");
                Log.i(CommonData.TAG, "google_ads --> Google_NativeBottomBannerAds --> ***");
                preLoadAdxNativeBannerMid();
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void preLoadAdxNativeBannerMid() {
        Log.i(CommonData.TAG, "google_ads --> Google_NativeBottomBannerAds --> preload_Adx() --> Start");
        AdLoader.Builder builder = new AdLoader.Builder(activity, new AdsPreferences(activity).getAdxNativeBanner());
        builder.forNativeAd(nativeAd -> {
            Log.i(CommonData.TAG, "google_ads --> Google_NativeBottomBannerAds --> preload_Adx() --> Loaded");
//            if (CommonData.google_NativeBannerAds21 != null) {
//                CommonData.google_NativeBannerAds21.destroy();
//            }
            CommonData.google_NativeBannerAds2 = nativeAd;
        });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError errorCode) {
                Log.i(CommonData.TAG, "google_ads --> Google_NativeBottomBannerAds --> preload_Adx() --> onAdFailedToLoad");
                Log.i(CommonData.TAG, "google_ads --> Google_NativeBottomBannerAds --> ***");
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void onDemandLoadFbNativeBannerMid(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        try {
            new NativeAdManager(activity).NativeAdLoaderOnLoad();

            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.VISIBLE);

            CommonData.facebook_nativeBannerAd2 = new NativeBannerAd(activity, new AdsPreferences(activity).getFacebookNative());
            NativeAdListener nativeAdListener = new NativeAdListener() {
                @Override
                public void onMediaDownloaded(Ad ad) {
                }

                @Override
                public void onError(Ad ad, AdError adError) {
                    onDemandLoadFbNativeBannerMid2(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    if (CommonData.facebook_nativeBannerAd2 == null || CommonData.facebook_nativeBannerAd2 != ad) {
                        return;
                    }

                    new NativeAdManager(activity).NativeDialogDismiss();

                    apps_FrameLayout.setVisibility(View.GONE);
                    ad_FrameLayout.setVisibility(View.GONE);
                    applovin_FrameLayout.setVisibility(View.GONE);
                    nativeAdLayout.setVisibility(View.VISIBLE);
                    ad_loading.setVisibility(View.GONE);

                    LinearLayout adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner2, nativeAdLayout, false);
                    new NativeAdsPopulate(activity).inflateFbNativeBannerMid(CommonData.facebook_nativeBannerAd2, nativeAdLayout, adView);
                }

                @Override
                public void onAdClicked(Ad ad) {
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                }
            };

            CommonData.facebook_nativeBannerAd2.loadAd(CommonData.facebook_nativeBannerAd2.buildLoadAdConfig()
                    .withAdListener(nativeAdListener).build());
        } catch (WindowManager.BadTokenException | ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void onDemandLoadFbNativeBannerMid2(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        try {
            CommonData.facebook_nativeBannerAd2 = new NativeBannerAd(activity, new AdsPreferences(activity).getFacebookNative());
            NativeAdListener nativeAdListener = new NativeAdListener() {
                @Override
                public void onMediaDownloaded(Ad ad) {
                }

                @Override
                public void onError(Ad ad, AdError adError) {
                    onDemandLoadAdmobNativeBannerMid(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    if (CommonData.facebook_nativeBannerAd2 == null || CommonData.facebook_nativeBannerAd2 != ad) {
                        return;
                    }

                    new NativeAdManager(activity).NativeDialogDismiss();

                    apps_FrameLayout.setVisibility(View.GONE);
                    ad_FrameLayout.setVisibility(View.GONE);
                    applovin_FrameLayout.setVisibility(View.GONE);
                    nativeAdLayout.setVisibility(View.VISIBLE);
                    ad_loading.setVisibility(View.GONE);

                    LinearLayout adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_banner2, nativeAdLayout, false);
                    new NativeAdsPopulate(activity).inflateFbNativeBannerMid(CommonData.facebook_nativeBannerAd2, nativeAdLayout, adView);
                }

                @Override
                public void onAdClicked(Ad ad) {
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                }
            };

            CommonData.facebook_nativeBannerAd2.loadAd(CommonData.facebook_nativeBannerAd2.buildLoadAdConfig()
                    .withAdListener(nativeAdListener).build());
        } catch (WindowManager.BadTokenException | ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void onDemandLoadAdmobNativeBannerMid(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        try {
            apps_FrameLayout.setVisibility(View.GONE);
            ad_FrameLayout.setVisibility(View.GONE);
            applovin_FrameLayout.setVisibility(View.GONE);
            nativeAdLayout.setVisibility(View.GONE);
            ad_loading.setVisibility(View.VISIBLE);

            AdLoader.Builder builder = new AdLoader.Builder(activity, new AdsPreferences(activity).getAdmobNative());
            builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {
                @Override
                public void onNativeAdLoaded(com.google.android.gms.ads.nativead.NativeAd nativeAd) {

                    new NativeAdManager(activity).NativeDialogDismiss();

                    boolean isDestroyed = false;
                    isDestroyed = activity.isDestroyed();
                    if (isDestroyed || activity.isFinishing() || activity.isChangingConfigurations()) {
                        nativeAd.destroy();
                        return;
                    }
                    if (CommonData.google_NativeBannerAds2 != null) {
                        CommonData.google_NativeBannerAds2.destroy();
                    }
                    CommonData.google_NativeBannerAds2 = nativeAd;

                    apps_FrameLayout.setVisibility(View.GONE);
                    ad_FrameLayout.setVisibility(View.VISIBLE);
                    applovin_FrameLayout.setVisibility(View.GONE);
                    nativeAdLayout.setVisibility(View.GONE);
                    ad_loading.setVisibility(View.GONE);

                    com.google.android.gms.ads.nativead.NativeAdView adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner2, null);

                    new NativeAdsPopulate(activity).populateNativeNoMedia(nativeAd, adView);
                    ad_FrameLayout.removeAllViews();
                    ad_FrameLayout.addView(adView);
                }
            });

            VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(false).build();

            NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();

            builder.withNativeAdOptions(adOptions);

            AdLoader adLoader = builder.withAdListener(new AdListener() {
                @Override
                public void onAdFailedToLoad(LoadAdError loadAdError) {
                    onDemandLoadAdxNativeBannerMid(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                }
            }).build();

            adLoader.loadAd(new AdRequest.Builder().build());
        } catch (WindowManager.BadTokenException | ActivityNotFoundException e) {
            e.printStackTrace();
        }

    }

    public void onDemandLoadAdxNativeBannerMid(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        try {

            AdLoader.Builder builder = new AdLoader.Builder(activity, new AdsPreferences(activity).getAdxNative());
            builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {
                @Override
                public void onNativeAdLoaded(com.google.android.gms.ads.nativead.NativeAd nativeAd) {

                    new NativeAdManager(activity).NativeDialogDismiss();

                    boolean isDestroyed = false;
                    isDestroyed = activity.isDestroyed();
                    if (isDestroyed || activity.isFinishing() || activity.isChangingConfigurations()) {
                        nativeAd.destroy();
                        return;
                    }
                    if (CommonData.google_NativeBannerAds2 != null) {
                        CommonData.google_NativeBannerAds2.destroy();
                    }
                    CommonData.google_NativeBannerAds2 = nativeAd;

                    apps_FrameLayout.setVisibility(View.GONE);
                    ad_FrameLayout.setVisibility(View.VISIBLE);
                    applovin_FrameLayout.setVisibility(View.GONE);
                    nativeAdLayout.setVisibility(View.GONE);
                    ad_loading.setVisibility(View.GONE);

                    com.google.android.gms.ads.nativead.NativeAdView adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner2, null);

                    new NativeAdsPopulate(activity).populateNativeNoMedia(nativeAd, adView);
                    ad_FrameLayout.removeAllViews();
                    ad_FrameLayout.addView(adView);
                }
            });

            VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(false).build();

            NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();

            builder.withNativeAdOptions(adOptions);

            AdLoader adLoader = builder.withAdListener(new AdListener() {
                @Override
                public void onAdFailedToLoad(LoadAdError loadAdError) {

                    new NativeAdManager(activity).NativeDialogDismiss();
                    new AppsAdManager(activity).onDemandLoadAppsNativeBannerMid(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
                }
            }).build();

            adLoader.loadAd(new AdRequest.Builder().build());
        } catch (WindowManager.BadTokenException | ActivityNotFoundException e) {
            e.printStackTrace();
        }

    }


    //=========================== (4) ==========================
    //=========================== (4) ==========================


    //=============== Pre Load GA Native Bottom Banner Ad ===================
    //=============== Pre Load GA Native Bottom Banner Ad ===================

    public void preLoadFbNativeBottomBanner() {
        Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBottomBannerAds --> pre_loadFacebook() --> Start");
        CommonData.facebook_nativeBottomBannerAd = new NativeBannerAd(activity, new AdsPreferences(activity).getFacebookNativeBanner());
        NativeAdListener nativeAdListener = new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBottomBannerAds --> pre_loadFacebook() --> onError");
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBottomBannerAds --> ***");
                CommonData.facebook_nativeBottomBannerAd = null;
                preLoadFbNativeBottomBanner2();
            }

            @Override
            public void onAdLoaded(Ad ad) {
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBottomBannerAds --> pre_loadFacebook() --> onAdLoaded");
//                inflateAd(CommonData.facebook_nativeBottomBannerAd);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        };
        CommonData.facebook_nativeBottomBannerAd.loadAd(CommonData.facebook_nativeBottomBannerAd.buildLoadAdConfig()
                .withAdListener(nativeAdListener)
                .build());
    }

    public void preLoadFbNativeBottomBanner2() {
        Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBottomBannerAds --> load_Facebook1() --> Start");
        CommonData.facebook_nativeBottomBannerAd = new NativeBannerAd(activity, new AdsPreferences(activity).getFacebookNativeBanner());
        NativeAdListener nativeAdListener = new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBottomBannerAds --> load_Facebook1() --> onError");
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBottomBannerAds --> ***");
                CommonData.facebook_nativeBottomBannerAd = null;
                preLoadAdmobNativeBottomBanner();
            }

            @Override
            public void onAdLoaded(Ad ad) {
                Log.i(CommonData.TAG, "facebook_ads --> Facebook_NativeBottomBannerAds --> load_Facebook1() --> onAdLoaded");
//                inflateAd(CommonData.facebook_nativeBottomBannerAd);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        };
        CommonData.facebook_nativeBottomBannerAd.loadAd(CommonData.facebook_nativeBottomBannerAd.buildLoadAdConfig()
                .withAdListener(nativeAdListener)
                .build());
    }

    public void preLoadAdmobNativeBottomBanner() {
        Log.i(CommonData.TAG, "google_ads --> Google_NativeBottomBannerAds --> preload_Admob() --> Start");
        AdLoader.Builder builder = new AdLoader.Builder(activity, new AdsPreferences(activity).getAdmobNativeBanner());
        builder.forNativeAd(nativeAd -> {
            Log.i(CommonData.TAG, "google_ads --> Google_NativeBottomBannerAds --> preload_Admob() --> Loaded");
//            if (CommonData.google_NativeBottomBannerAds != null) {
//                CommonData.google_NativeBottomBannerAds.destroy();
//            }
            CommonData.google_NativeBottomBannerAds = nativeAd;
        });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError errorCode) {
                Log.i(CommonData.TAG, "google_ads --> Google_NativeBottomBannerAds --> preload_Admob() --> onAdFailedToLoad");
                Log.i(CommonData.TAG, "google_ads --> Google_NativeBottomBannerAds --> ***");
                preLoadAdxNativeBottomBanner();
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void preLoadAdxNativeBottomBanner() {
        Log.i(CommonData.TAG, "google_ads --> Google_NativeBottomBannerAds --> preload_Adx() --> Start");
        AdLoader.Builder builder = new AdLoader.Builder(activity, new AdsPreferences(activity).getAdxNativeBanner());
        builder.forNativeAd(nativeAd -> {
            Log.i(CommonData.TAG, "google_ads --> Google_NativeBottomBannerAds --> preload_Adx() --> Loaded");
//            if (CommonData.google_NativeBottomBannerAds1 != null) {
//                CommonData.google_NativeBottomBannerAds1.destroy();
//            }
            CommonData.google_NativeBottomBannerAds = nativeAd;
        });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError errorCode) {
                Log.i(CommonData.TAG, "google_ads --> Google_NativeBottomBannerAds --> preload_Adx() --> onAdFailedToLoad");
                Log.i(CommonData.TAG, "google_ads --> Google_NativeBottomBannerAds --> ***");
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void onDemandLoadFbNativeBottomBanner(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        apps_FrameLayout.setVisibility(View.GONE);
        ad_FrameLayout.setVisibility(View.GONE);
        applovin_FrameLayout.setVisibility(View.GONE);
        nativeAdLayout.setVisibility(View.GONE);
        ad_loading.setVisibility(View.VISIBLE);

        CommonData.facebook_nativeBottomBannerAd = new NativeBannerAd(activity, new AdsPreferences(activity).getFacebookNative());
        NativeAdListener nativeAdListener = new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                onDemandLoadFbNativeBottomBanner2(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
            }

            @Override
            public void onAdLoaded(Ad ad) {
                if (CommonData.facebook_nativeBottomBannerAd == null || CommonData.facebook_nativeBottomBannerAd != ad) {
                    return;
                }

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.GONE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.VISIBLE);
                ad_loading.setVisibility(View.GONE);

                LinearLayout adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_bottom_banner, nativeAdLayout, false);
                new NativeAdsPopulate(activity).inflateFbNativeBottomBanner(CommonData.facebook_nativeBottomBannerAd, nativeAdLayout, adView);
            }

            @Override
            public void onAdClicked(Ad ad) {
            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        };

        CommonData.facebook_nativeBottomBannerAd.loadAd(CommonData.facebook_nativeBottomBannerAd.buildLoadAdConfig()
                .withAdListener(nativeAdListener).build());
    }

    public void onDemandLoadFbNativeBottomBanner2(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {

        CommonData.facebook_nativeBottomBannerAd = new NativeBannerAd(activity, new AdsPreferences(activity).getFacebookNative());
        NativeAdListener nativeAdListener = new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                onDemandLoadAdmobNativeBottomBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
            }

            @Override
            public void onAdLoaded(Ad ad) {
                if (CommonData.facebook_nativeBottomBannerAd == null || CommonData.facebook_nativeBottomBannerAd != ad) {
                    return;
                }

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.GONE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.VISIBLE);
                ad_loading.setVisibility(View.GONE);

                LinearLayout adView = (LinearLayout) LayoutInflater.from(activity).inflate(R.layout.fb_native_bottom_banner, nativeAdLayout, false);
                new NativeAdsPopulate(activity).inflateFbNativeBottomBanner(CommonData.facebook_nativeBottomBannerAd, nativeAdLayout, adView);
            }

            @Override
            public void onAdClicked(Ad ad) {
            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        };

        CommonData.facebook_nativeBottomBannerAd.loadAd(CommonData.facebook_nativeBottomBannerAd.buildLoadAdConfig()
                .withAdListener(nativeAdListener).build());
    }

    public void onDemandLoadAdmobNativeBottomBanner(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {
        apps_FrameLayout.setVisibility(View.GONE);
        ad_FrameLayout.setVisibility(View.GONE);
        applovin_FrameLayout.setVisibility(View.GONE);
        nativeAdLayout.setVisibility(View.GONE);
        ad_loading.setVisibility(View.VISIBLE);

        AdLoader.Builder builder = new AdLoader.Builder(activity, new AdsPreferences(activity).getAdmobNative());
        builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {
            @Override
            public void onNativeAdLoaded(com.google.android.gms.ads.nativead.NativeAd nativeAd) {
                boolean isDestroyed = false;
                isDestroyed = activity.isDestroyed();
                if (isDestroyed || activity.isFinishing() || activity.isChangingConfigurations()) {
                    nativeAd.destroy();
                    return;
                }
                if (CommonData.google_NativeBottomBannerAds != null) {
                    CommonData.google_NativeBottomBannerAds.destroy();
                }
                CommonData.google_NativeBottomBannerAds = nativeAd;

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.VISIBLE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.GONE);
                ad_loading.setVisibility(View.GONE);

                com.google.android.gms.ads.nativead.NativeAdView adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_bottom_banner, null);

                new NativeAdsPopulate(activity).populateNativeNoMedia(nativeAd, adView);
                ad_FrameLayout.removeAllViews();
                ad_FrameLayout.addView(adView);
            }
        });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(false).build();

        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
                onDemandLoadAdxNativeBottomBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
            }
        }).build();

        adLoader.loadAd(new AdRequest.Builder().build());

    }

    public void onDemandLoadAdxNativeBottomBanner(FrameLayout apps_FrameLayout, FrameLayout ad_FrameLayout, FrameLayout applovin_FrameLayout, NativeAdLayout nativeAdLayout, LinearLayout ad_loading) {

        AdLoader.Builder builder = new AdLoader.Builder(activity, new AdsPreferences(activity).getAdxNative());
        builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {
            @Override
            public void onNativeAdLoaded(com.google.android.gms.ads.nativead.NativeAd nativeAd) {
                boolean isDestroyed = false;
                isDestroyed = activity.isDestroyed();
                if (isDestroyed || activity.isFinishing() || activity.isChangingConfigurations()) {
                    nativeAd.destroy();
                    return;
                }
                if (CommonData.google_NativeBottomBannerAds != null) {
                    CommonData.google_NativeBottomBannerAds.destroy();
                }
                CommonData.google_NativeBottomBannerAds = nativeAd;

                apps_FrameLayout.setVisibility(View.GONE);
                ad_FrameLayout.setVisibility(View.VISIBLE);
                applovin_FrameLayout.setVisibility(View.GONE);
                nativeAdLayout.setVisibility(View.GONE);
                ad_loading.setVisibility(View.GONE);

                com.google.android.gms.ads.nativead.NativeAdView adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_bottom_banner, null);

                new NativeAdsPopulate(activity).populateNativeNoMedia(nativeAd, adView);
                ad_FrameLayout.removeAllViews();
                ad_FrameLayout.addView(adView);
            }
        });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(false).build();

        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
                new AppsAdManager(activity).onDemandLoadAppsNativeBottomBanner(apps_FrameLayout, ad_FrameLayout, applovin_FrameLayout, nativeAdLayout, ad_loading);
            }
        }).build();

        adLoader.loadAd(new AdRequest.Builder().build());

    }


}
