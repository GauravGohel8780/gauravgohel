package com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.base;


public interface BasePresenter {
}
