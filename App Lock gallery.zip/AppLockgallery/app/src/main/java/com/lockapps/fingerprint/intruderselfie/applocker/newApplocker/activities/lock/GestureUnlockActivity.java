package com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.activities.lock;

import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import com.lockapps.fingerprint.intruderselfie.applocker.Activities.MainLockActivity;
import com.lockapps.fingerprint.intruderselfie.applocker.CameraManager;
import com.lockapps.fingerprint.intruderselfie.applocker.CommonClass;
import com.lockapps.fingerprint.intruderselfie.applocker.SharedPrefs;
import com.lockapps.fingerprint.intruderselfie.applocker.StoreAppDatabase;
import com.lockapps.fingerprint.intruderselfie.applocker.R;;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.internet.NetworkConnection;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager.NativeAdManager;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.activities.main.AppList;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.base.AppConstants;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.base.BaseActivity;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.db.CommLockInfoManager;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.services.LockService;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.utils.SpUtil;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.widget.UnLockMenuPopWindow;
import com.lockapps.fingerprint.intruderselfie.applocker.patternlockview.PatternLockView;
import com.lockapps.fingerprint.intruderselfie.applocker.patternlockview.listener.PatternLockViewListener;
import com.lockapps.fingerprint.intruderselfie.applocker.patternlockview.utils.PatternLockUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.Executor;

public class GestureUnlockActivity extends BaseActivity implements View.OnClickListener {

    public static final String FINISH_UNLOCK_THIS_APP = "finish_unlock_this_app";
    private ImageView mUnLockIcon, finger, microphone;
    private PackageManager packageManager;
    private String pkgName;
    private String actionFrom;
    private CommLockInfoManager mLockInfoManager;
    private UnLockMenuPopWindow mPopWindow;
    private GestureUnlockReceiver mGestureUnlockReceiver;
    private ApplicationInfo appInfo;
    private Drawable iconDrawable;
    RelativeLayout mUnLockLayout;
    PatternLockView patternLockView;
    String password;
    LinearLayout btnclear, pinlock, patternlock;
    BiometricPrompt biometricPrompt;
    BiometricPrompt.PromptInfo promptInfo;
    StoreAppDatabase g;

    View view1, view2, view3, view4;
    Button btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn0;

    String passcode = "";
    String num1, num2, num3, num4;
    int count = 0;
    int patternCount = 0;

    ArrayList<String> number_list = new ArrayList<>();
    List<Integer> generated = new ArrayList<Integer>();


    @Override
    public int getLayoutId() {
        return R.layout.activity_gesture_unlock;
    }

    @Override
    protected void initViews(Bundle savedInstanceState) {

        new NativeAdManager(this).show_NativeBottomFlag(this.findViewById(R.id.bapps_FrameLayout),
                this.findViewById(R.id.bad_FrameLayout), this.findViewById(R.id.bapplovin_FrameLayout), this.findViewById(R.id.bnativeAdLayout),
                this.findViewById(R.id.bad_loading));
        new NetworkConnection().callNetworkConnection(this);
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.darkcolor));
        patternLockView = findViewById(R.id.pattern);
        patternlock = findViewById(R.id.patternlock);
        pinlock = findViewById(R.id.pinlock);
        finger = findViewById(R.id.finger);
        microphone = findViewById(R.id.microphone);

        mUnLockLayout = findViewById(R.id.unlock_layout);
        mUnLockIcon = findViewById(R.id.unlock_icon);

        view1 = findViewById(R.id.view1);
        view2 = findViewById(R.id.view2);
        view3 = findViewById(R.id.view3);
        view4 = findViewById(R.id.view4);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);
        btn6 = findViewById(R.id.btn6);
        btn7 = findViewById(R.id.btn7);
        btn8 = findViewById(R.id.btn8);
        btn9 = findViewById(R.id.btn9);
        btn0 = findViewById(R.id.btn0);
        btnclear = findViewById(R.id.btncancel);

        g = new StoreAppDatabase(this);

        btnclear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                number_list.clear();
                passnumber(number_list);
            }
        });

        randomnumber();

        if (SharedPrefs.getIsRandomOnOff(getApplicationContext())) {
            int one0 = generated.get(0);
            int one1 = generated.get(1);
            int one2 = generated.get(2);
            int one3 = generated.get(3);
            int one4 = generated.get(4);
            int one5 = generated.get(5);
            int one6 = generated.get(6);
            int one7 = generated.get(7);
            int one8 = generated.get(8);
            int one9 = generated.get(9);

            btn0.setText(String.valueOf(one0));
            btn1.setText(String.valueOf(one1));
            btn2.setText(String.valueOf(one2));
            btn3.setText(String.valueOf(one3));
            btn4.setText(String.valueOf(one4));
            btn5.setText(String.valueOf(one5));
            btn6.setText(String.valueOf(one6));
            btn7.setText(String.valueOf(one7));
            btn8.setText(String.valueOf(one8));
            btn9.setText(String.valueOf(one9));

            addRandomNumber(btn0, one0);
            addRandomNumber(btn1, one1);
            addRandomNumber(btn2, one2);
            addRandomNumber(btn3, one3);
            addRandomNumber(btn4, one4);
            addRandomNumber(btn5, one5);
            addRandomNumber(btn6, one6);
            addRandomNumber(btn7, one7);
            addRandomNumber(btn8, one8);
            addRandomNumber(btn9, one9);
        } else {
            addNumber(btn0, "0");
            addNumber(btn1, "1");
            addNumber(btn2, "2");
            addNumber(btn3, "3");
            addNumber(btn4, "4");
            addNumber(btn5, "5");
            addNumber(btn6, "6");
            addNumber(btn7, "7");
            addNumber(btn8, "8");
            addNumber(btn9, "9");
        }

        finger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fingerPrintDialog();
            }
        });

        microphone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(intent, 10);
                } else {
                    Toast.makeText(getApplicationContext(), "Your Device Don't Support Speech Input", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    public void fingerPrintDialog() {
        androidx.biometric.BiometricManager biometricManager = androidx.biometric.BiometricManager.from(this);

        switch (biometricManager.canAuthenticate()) {
            case androidx.biometric.BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
                Toast.makeText(this, "Device Doesn't have fingerprint", Toast.LENGTH_SHORT).show();
                break;

            case androidx.biometric.BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
                Toast.makeText(this, "Not Working", Toast.LENGTH_SHORT).show();

            case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
                Toast.makeText(this, "No Fingerprint Assigned", Toast.LENGTH_SHORT).show();
        }

        Executor executor = ContextCompat.getMainExecutor(this);

        biometricPrompt = new BiometricPrompt(this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                startActivity(new Intent(GestureUnlockActivity.this, GestureUnlockActivity.class));
                finish();
            }

            @Override
            public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                Toast.makeText(GestureUnlockActivity.this, "Finger Match Successfully.", Toast.LENGTH_SHORT).show();
                SpUtil.getInstance().putLong(AppConstants.LOCK_CURR_MILLISECONDS, System.currentTimeMillis());
                SpUtil.getInstance().putString(AppConstants.LOCK_LAST_LOAD_PKG_NAME, pkgName);

                //Send the last unlocked time to the app lock service
                Intent intent = new Intent(LockService.UNLOCK_ACTION);
                intent.putExtra(LockService.LOCK_SERVICE_LASTTIME, System.currentTimeMillis());
                intent.putExtra(LockService.LOCK_SERVICE_LASTAPP, pkgName);
                sendBroadcast(intent);

                mLockInfoManager.unlockCommApplication(pkgName);
                finish();
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                Toast.makeText(GestureUnlockActivity.this, "Finger Authentication Failed.", Toast.LENGTH_SHORT).show();
//                startActivity(new Intent(GestureUnlockActivity.this, MainLockActivity.class));
                finish();
            }
        });

        promptInfo = new BiometricPrompt.PromptInfo.Builder().setTitle("Voice Lock").setDescription("Use FingerPrint To Login").setDeviceCredentialAllowed(true).build();
        biometricPrompt.authenticate(promptInfo);
    }

    @Override
    protected void initData() {
        pkgName = getIntent().getStringExtra(AppConstants.LOCK_PACKAGE_NAME);
        actionFrom = getIntent().getStringExtra(AppConstants.LOCK_FROM);
        packageManager = getPackageManager();
        mLockInfoManager = new CommLockInfoManager(this);
        mPopWindow = new UnLockMenuPopWindow(this, pkgName, true);


        initLayoutBackground();
        initLockPatternView();


        mGestureUnlockReceiver = new GestureUnlockReceiver();
        IntentFilter filter = new IntentFilter();
        //  filter.addAction(UnLockMenuPopWindow.UPDATE_LOCK_VIEW);
        filter.addAction(FINISH_UNLOCK_THIS_APP);
        registerReceiver(mGestureUnlockReceiver, filter);

        if (SharedPrefs.getLockFinalType(getApplicationContext()).equalsIgnoreCase("PIN")) {
            pinlock.setVisibility(View.VISIBLE);
            patternlock.setVisibility(View.GONE);
        } else {
            pinlock.setVisibility(View.GONE);
            patternlock.setVisibility(View.VISIBLE);
        }

    }

    private void initLayoutBackground() {
        try {
            appInfo = packageManager.getApplicationInfo(pkgName, PackageManager.GET_UNINSTALLED_PACKAGES);
            if (appInfo != null) {
                iconDrawable = packageManager.getApplicationIcon(appInfo);
//                appLabel = packageManager.getApplicationLabel(appInfo).toString();
                mUnLockIcon.setImageDrawable(iconDrawable);

            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void initLockPatternView() {
        password = SharedPrefs.getPatternData(getApplicationContext());

        if (SharedPrefs.getISFingerUD(getApplicationContext())) {
            finger.setVisibility(View.VISIBLE);
            microphone.setVisibility(View.VISIBLE);
        } else {
            finger.setVisibility(View.GONE);
            microphone.setVisibility(View.GONE);
        }

        if (SharedPrefs.getVoiceLockIV(getApplicationContext())) {
            microphone.setVisibility(View.VISIBLE);
        } else {
            microphone.setVisibility(View.GONE);
        }


        patternLockView.addPatternLockListener(new PatternLockViewListener() {
            @Override
            public void onStarted() {
            }

            @Override
            public void onProgress(List<PatternLockView.Dot> progressPattern) {
            }

            public void onComplete(List<PatternLockView.Dot> pattern) {

                if (PatternLockUtils.patternToString(patternLockView, pattern).length() >= 4) {
                    if (password.equals(PatternLockUtils.patternToString(patternLockView, pattern))) {

                        SpUtil.getInstance().putLong(AppConstants.LOCK_CURR_MILLISECONDS, System.currentTimeMillis());
                        SpUtil.getInstance().putString(AppConstants.LOCK_LAST_LOAD_PKG_NAME, pkgName);

                        //Send the last unlocked time to the app lock service
                        Intent intent = new Intent(LockService.UNLOCK_ACTION);
                        intent.putExtra(LockService.LOCK_SERVICE_LASTTIME, System.currentTimeMillis());
                        intent.putExtra(LockService.LOCK_SERVICE_LASTAPP, pkgName);
                        sendBroadcast(intent);

                        mLockInfoManager.unlockCommApplication(pkgName);
                        finish();

                    } else {

                        Toast.makeText(GestureUnlockActivity.this, "Wrong password !", Toast.LENGTH_SHORT).show();
                        patternLockView.clearPattern();
                        patternCount++;

                        if (patternCount == SharedPrefs.getPasswordCount(getApplicationContext())) {
                            patternCount = 0;
                            if (SharedPrefs.getIntruderOnOff(getApplicationContext())) {
                                CameraManager mgr = new CameraManager(GestureUnlockActivity.this);
                                mgr.takePhoto();
                                Toast.makeText(GestureUnlockActivity.this, "Photo saved to Pictures\\iSelfie", Toast.LENGTH_SHORT).show();

                                SimpleDateFormat imagename = new SimpleDateFormat("yyyyMMddhhmmss", Locale.getDefault());
                                CommonClass.FileName = "iselfieapp_" + imagename.format(new Date()) + ".jpg";

                                SimpleDateFormat dateTime = new SimpleDateFormat("dd-MM-yy hh:mm aa", Locale.getDefault());
                                String currentDateTime = dateTime.format(new Date());

                                g.addData(drawableToBitmap(iconDrawable), currentDateTime, CommonClass.FileName, packageManager.getApplicationLabel(appInfo).toString());
                            }
                        }
                    }
                } else {
                    Toast.makeText(GestureUnlockActivity.this, "Please Connect 4 dots..", Toast.LENGTH_SHORT).show();
                    pattern.clear();
                }


            }

            @Override
            public void onCleared() {
            }

        });

    }

    public static Bitmap drawableToBitmap(Drawable drawable) {
        Bitmap bitmap = null;

        if (drawable instanceof BitmapDrawable) {
            BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;
            if (bitmapDrawable.getBitmap() != null) {
                return bitmapDrawable.getBitmap();
            }
        }

        if (drawable.getIntrinsicWidth() <= 0 || drawable.getIntrinsicHeight() <= 0) {
            bitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888); // Single color bitmap will be created of 1x1 pixel
        } else {
            bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        }

        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return bitmap;
    }


    @Override
    public void onBackPressed() {
        if (actionFrom.equals(AppConstants.LOCK_FROM_FINISH)) {
//            LockUtil.goHome(this);
        } else if (actionFrom.equals(AppConstants.LOCK_FROM_LOCK_MAIN_ACITVITY)) {
            finish();
        } else {
            startActivity(new Intent(this, AppList.class));
        }
    }

    @Override
    protected void initAction() {
    }

    @Override
    public void onClick(@NonNull View view) {

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mGestureUnlockReceiver);
    }

    private class GestureUnlockReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, @NonNull Intent intent) {
            String action = intent.getAction();
//            if (action.equals(UnLockMenuPopWindow.UPDATE_LOCK_VIEW)) {
//                mLockPatternView.initRes();
//            } else
            if (action.equals(FINISH_UNLOCK_THIS_APP)) {
                finish();
            }
        }
    }


    private void randomnumber() {
        Random rng = new Random();
        for (int i = 0; i < 10; i++) {
            while (true) {
                Integer next = rng.nextInt(10);
                if (!generated.contains(next)) {
                    generated.add(next);
                    break;
                }
            }
        }

    }

    public void addRandomNumber(Button button, int randomNumber) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (SharedPrefs.getVibrateOnOff(getApplicationContext())) {
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE));

                    } else {
                        //deprecated in API 26
                        v.vibrate(50);
                    }
                    number_list.add(String.valueOf(randomNumber));
                    passnumber(number_list);
                } else {
                    number_list.add(String.valueOf(randomNumber));
                    passnumber(number_list);
                }
            }
        });
    }

    public void addNumber(Button button, String number) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (SharedPrefs.getVibrateOnOff(getApplicationContext())) {
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE));

                    } else {
                        //deprecated in API 26
                        v.vibrate(50);
                    }
                    number_list.add(number);
                    passnumber(number_list);
                } else {
                    number_list.add(number);
                    passnumber(number_list);
                }
            }
        });
    }

    private void passnumber(ArrayList<String> number_list) {

        if (number_list.size() == 0) {
            view1.setBackgroundResource(R.drawable.bg_view);
            view2.setBackgroundResource(R.drawable.bg_view);
            view3.setBackgroundResource(R.drawable.bg_view);
            view4.setBackgroundResource(R.drawable.bg_view);
        } else {
            switch (number_list.size()) {
                case 1:
                    num1 = number_list.get(0);
                    view1.setBackgroundResource(R.drawable.bg_view_blue_oval);
                    break;
                case 2:
                    num2 = number_list.get(1);
                    view2.setBackgroundResource(R.drawable.bg_view_blue_oval);
                    break;
                case 3:
                    num3 = number_list.get(2);
                    view3.setBackgroundResource(R.drawable.bg_view_blue_oval);
                    break;
                case 4:
                    num4 = number_list.get(3);
                    view4.setBackgroundResource(R.drawable.bg_view_blue_oval);
                    passcode = num1 + num2 + num3 + num4;

                    count++;

                    if (passcode.equals(SharedPrefs.getPinData(getApplicationContext()))) {

                        SpUtil.getInstance().putLong(AppConstants.LOCK_CURR_MILLISECONDS, System.currentTimeMillis());
                        SpUtil.getInstance().putString(AppConstants.LOCK_LAST_LOAD_PKG_NAME, pkgName);

                        //Send the last unlocked time to the app lock service
                        Intent intent = new Intent(LockService.UNLOCK_ACTION);
                        intent.putExtra(LockService.LOCK_SERVICE_LASTTIME, System.currentTimeMillis());
                        intent.putExtra(LockService.LOCK_SERVICE_LASTAPP, pkgName);
                        sendBroadcast(intent);

                        mLockInfoManager.unlockCommApplication(pkgName);
                        finish();


                    } else {

                        patternCount++;

                        Toast.makeText(this, "Enter a Valid PIN", Toast.LENGTH_SHORT).show();

                        if (patternCount == SharedPrefs.getPasswordCount(getApplicationContext())) {
                            patternCount = 0;
                            if (SharedPrefs.getIntruderOnOff(getApplicationContext())) {
                                CameraManager mgr = new CameraManager(GestureUnlockActivity.this);
                                mgr.takePhoto();
                                Toast.makeText(GestureUnlockActivity.this, "Photo saved to Pictures\\iSelfie", Toast.LENGTH_SHORT).show();

                                SimpleDateFormat imagename = new SimpleDateFormat("yyyyMMddhhmmss", Locale.getDefault());
                                CommonClass.FileName = "iselfieapp_" + imagename.format(new Date()) + ".jpg";

                                SimpleDateFormat dateTime = new SimpleDateFormat("dd-MM-yy hh:mm aa", Locale.getDefault());
                                String currentDateTime = dateTime.format(new Date());

                                g.addData(drawableToBitmap(iconDrawable), currentDateTime, CommonClass.FileName, packageManager.getApplicationLabel(appInfo).toString());
                            }
                        }
                    }

                    break;

            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case 10:
                if (resultCode == RESULT_OK && data != null) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    if (SharedPrefs.getVoiceLockOnOff(this).equalsIgnoreCase(result.get(0))) {
                        Intent intent = new Intent(LockService.UNLOCK_ACTION);
                        intent.putExtra(LockService.LOCK_SERVICE_LASTTIME, System.currentTimeMillis());
                        intent.putExtra(LockService.LOCK_SERVICE_LASTAPP, pkgName);
                        sendBroadcast(intent);

                        mLockInfoManager.unlockCommApplication(pkgName);
                        finish();
                    } else {
                        Toast.makeText(GestureUnlockActivity.this, "Wrong Voice Password", Toast.LENGTH_SHORT).show();
                    }
                }
                break;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        new NetworkConnection().callNetworkConnection(this);

    }
}
