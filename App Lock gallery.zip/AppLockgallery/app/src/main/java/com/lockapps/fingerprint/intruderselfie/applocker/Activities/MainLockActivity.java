package com.lockapps.fingerprint.intruderselfie.applocker.Activities;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import com.lockapps.fingerprint.intruderselfie.applocker.CameraManager;
import com.lockapps.fingerprint.intruderselfie.applocker.CommonClass;
import com.lockapps.fingerprint.intruderselfie.applocker.SharedPrefs;
import com.lockapps.fingerprint.intruderselfie.applocker.StoreAppDatabase;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.app_open_ad.AOM_Activity;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.OnAdCallBack;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.internet.NetworkConnection;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.G_InterstitialAds;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.InterstitialAdManager;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager.NativeAdManager;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.activities.main.AppList;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.activities.main.SplashActivity;
import com.lockapps.fingerprint.intruderselfie.applocker.patternlockview.PatternLockView;
import com.lockapps.fingerprint.intruderselfie.applocker.patternlockview.listener.PatternLockViewListener;
import com.lockapps.fingerprint.intruderselfie.applocker.patternlockview.utils.PatternLockUtils;
import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.Executor;

public class MainLockActivity extends AppCompatActivity {

    PatternLockView patternLockView;
    String password;
    ImageView finger, voice;
    private ImageView mUnLockIcon;
    TextView forgetPassword;
    StoreAppDatabase g;


    View view1, view2, view3, view4;
    Button btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn0;
    LinearLayout btnclear, patternlock, pinlock;

    String passcode = "";
    String num1, num2, num3, num4;
    private String pkgName;
    int count = 0;
    int patternCount = 0;

    ArrayList<String> number_list = new ArrayList<>();
    List<Integer> generated = new ArrayList<Integer>();
    BiometricPrompt biometricPrompt;
    BiometricPrompt.PromptInfo promptInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_lock);
        new NativeAdManager(this).show_NativeBottomFlag(this.findViewById(R.id.bapps_FrameLayout),
                this.findViewById(R.id.bad_FrameLayout), this.findViewById(R.id.bapplovin_FrameLayout), this.findViewById(R.id.bnativeAdLayout),
                this.findViewById(R.id.bad_loading));

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(getResources().getColor(R.color.darkcolor));
        }


        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.darkcolor));

        g = new StoreAppDatabase(this);

        patternLockView = findViewById(R.id.pattern);
        patternlock = findViewById(R.id.patternlock);
        pinlock = findViewById(R.id.pinlock);
        finger = findViewById(R.id.finger);
        voice = findViewById(R.id.voice);
        forgetPassword = findViewById(R.id.forgetPassword);
        mUnLockIcon = findViewById(R.id.unlock_icon);

        view1 = findViewById(R.id.view1);
        view2 = findViewById(R.id.view2);
        view3 = findViewById(R.id.view3);
        view4 = findViewById(R.id.view4);


        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);
        btn6 = findViewById(R.id.btn6);
        btn7 = findViewById(R.id.btn7);
        btn8 = findViewById(R.id.btn8);
        btn9 = findViewById(R.id.btn9);
        btn0 = findViewById(R.id.btn0);
        btnclear = findViewById(R.id.btncancel);

        btnclear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                number_list.clear();
                passnumber(number_list);
            }
        });

        forgetPassword.setPaintFlags(forgetPassword.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);

        forgetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmDialog();
            }
        });

        if (SharedPrefs.getISFingerUD(getApplicationContext())) {
            finger.setVisibility(View.VISIBLE);
        } else {
            finger.setVisibility(View.GONE);
        }

        if (SharedPrefs.getVoiceLockIV(getApplicationContext())) {
            voice.setVisibility(View.VISIBLE);
        } else {
            voice.setVisibility(View.GONE);
        }

        voice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(intent, 10);
                } else {
                    Toast.makeText(MainLockActivity.this, "Your device Don't Support Speech Input", Toast.LENGTH_SHORT).show();
                }
            }
        });

        password = SharedPrefs.getPatternData(getApplicationContext());

        patternLockView.addPatternLockListener(new PatternLockViewListener() {
            @Override
            public void onStarted() {

            }

            @Override
            public void onProgress(List<PatternLockView.Dot> progressPattern) {

            }

            @Override
            public void onComplete(List<PatternLockView.Dot> pattern) {
                count++;
                if (PatternLockUtils.patternToString(patternLockView, pattern).length() >= 4) {
                    if (password.equals(PatternLockUtils.patternToString(patternLockView, pattern))) {
                        Intent intent = new Intent(MainLockActivity.this, AppList.class);
                        startActivity(intent);
                        patternLockView.clearPattern();
                    } else {
                        patternCount++;
                        Toast.makeText(MainLockActivity.this, "Wrong password !", Toast.LENGTH_SHORT).show();
                        patternLockView.clearPattern();

                        if (patternCount >= SharedPrefs.getPasswordCount(getApplicationContext())) {
                            patternCount = 0;
                            if (SharedPrefs.getIntruderOnOff(getApplicationContext())) {
                                CameraManager mgr = new CameraManager(MainLockActivity.this);
                                mgr.takePhoto();
                                Toast.makeText(MainLockActivity.this, "Photo saved to Pictures\\iSelfie", Toast.LENGTH_SHORT).show();

                                SimpleDateFormat imagename = new SimpleDateFormat("yyyyMMddhhmmss", Locale.getDefault());
                                CommonClass.FileName = "iselfieapp_" + imagename.format(new Date()) + ".jpg";

                                SimpleDateFormat dateTime = new SimpleDateFormat("dd-MM-yy hh:mm aa", Locale.getDefault());
                                String currentDateTime = dateTime.format(new Date());

                                g.addData(drawableToBitmap(getDrawable(R.mipmap.ic_launcher)), currentDateTime, CommonClass.FileName, getResources().getString(R.string.app_name));

                            }
                        }


                    }
                } else {
                    Toast.makeText(MainLockActivity.this, "Plz Connect 4 dot..", Toast.LENGTH_SHORT).show();
                    patternLockView.clearPattern();
                }


                if (count == 3) {
                    forgetPassword.setVisibility(View.VISIBLE);
                } else {
                    forgetPassword.setVisibility(View.GONE);
                }

            }

            @Override
            public void onCleared() {

            }

        });


        randomnumber();

        if (SharedPrefs.getIsRandomOnOff(getApplicationContext())) {
            int one0 = generated.get(0);
            int one1 = generated.get(1);
            int one2 = generated.get(2);
            int one3 = generated.get(3);
            int one4 = generated.get(4);
            int one5 = generated.get(5);
            int one6 = generated.get(6);
            int one7 = generated.get(7);
            int one8 = generated.get(8);
            int one9 = generated.get(9);

            btn0.setText(String.valueOf(one0));
            btn1.setText(String.valueOf(one1));
            btn2.setText(String.valueOf(one2));
            btn3.setText(String.valueOf(one3));
            btn4.setText(String.valueOf(one4));
            btn5.setText(String.valueOf(one5));
            btn6.setText(String.valueOf(one6));
            btn7.setText(String.valueOf(one7));
            btn8.setText(String.valueOf(one8));
            btn9.setText(String.valueOf(one9));

            addRandomNumber(btn0, one0);
            addRandomNumber(btn1, one1);
            addRandomNumber(btn2, one2);
            addRandomNumber(btn3, one3);
            addRandomNumber(btn4, one4);
            addRandomNumber(btn5, one5);
            addRandomNumber(btn6, one6);
            addRandomNumber(btn7, one7);
            addRandomNumber(btn8, one8);
            addRandomNumber(btn9, one9);
        } else {
            addNumber(btn0, "0");
            addNumber(btn1, "1");
            addNumber(btn2, "2");
            addNumber(btn3, "3");
            addNumber(btn4, "4");
            addNumber(btn5, "5");
            addNumber(btn6, "6");
            addNumber(btn7, "7");
            addNumber(btn8, "8");
            addNumber(btn9, "9");
        }


        if (SharedPrefs.getLockFinalType(getApplicationContext()).equalsIgnoreCase("PIN")) {
            pinlock.setVisibility(View.VISIBLE);
            patternlock.setVisibility(View.GONE);
        } else {
            pinlock.setVisibility(View.GONE);
            patternlock.setVisibility(View.VISIBLE);
        }

        finger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fingerPrintDialog();
            }
        });


    }

    public static Bitmap drawableToBitmap(Drawable drawable) {
        Bitmap bitmap = null;

        if (drawable instanceof BitmapDrawable) {
            BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;
            if (bitmapDrawable.getBitmap() != null) {
                return bitmapDrawable.getBitmap();
            }
        }

        if (drawable.getIntrinsicWidth() <= 0 || drawable.getIntrinsicHeight() <= 0) {
            bitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888); // Single color bitmap will be created of 1x1 pixel
        } else {
            bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        }

        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return bitmap;
    }


    public void fingerPrintDialog() {
        androidx.biometric.BiometricManager biometricManager = androidx.biometric.BiometricManager.from(this);

        switch (biometricManager.canAuthenticate()) {
            case androidx.biometric.BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
                Toast.makeText(this, "Device Doesn't have fingerprint", Toast.LENGTH_SHORT).show();
                break;

            case androidx.biometric.BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
                Toast.makeText(this, "Not Working", Toast.LENGTH_SHORT).show();

            case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
                Toast.makeText(this, "No Fingerprint Assigned", Toast.LENGTH_SHORT).show();
        }

        Executor executor = ContextCompat.getMainExecutor(this);

        biometricPrompt = new BiometricPrompt(MainLockActivity.this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                new InterstitialAdManager(MainLockActivity.this).loadInterstitialAll(new OnAdCallBack() {
                    @Override
                    public void onAdDismiss() {
                        startActivity(new Intent(MainLockActivity.this, MainLockActivity.class));
                    }
                });
                finish();
            }

            @Override
            public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                Toast.makeText(MainLockActivity.this, "Finger Match Successfully.", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MainLockActivity.this, AppList.class));
                finish();

            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                Toast.makeText(MainLockActivity.this, "Finger Authentication Failed.", Toast.LENGTH_SHORT).show();
                new InterstitialAdManager(MainLockActivity.this).loadInterstitialAll(new OnAdCallBack() {
                    @Override
                    public void onAdDismiss() {
                        startActivity(new Intent(MainLockActivity.this, MainLockActivity.class));
                    }
                });
                finish();
            }
        });

        promptInfo = new BiometricPrompt.PromptInfo.Builder().setTitle("Voice Lock").setDescription("Use FingerPrint To Login").setDeviceCredentialAllowed(true).build();
        biometricPrompt.authenticate(promptInfo);
    }

    private void confirmDialog() {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setContentView(R.layout.security_confirm_dialog);

        RelativeLayout rlv = bottomSheetDialog.findViewById(R.id.rlv);
        ImageView cancel = bottomSheetDialog.findViewById(R.id.cancel);
        TextView ConfirmQuestion = bottomSheetDialog.findViewById(R.id.ConfirmQuestion);
        EditText ConfirmEdit = bottomSheetDialog.findViewById(R.id.ConfirmEdit);
        AppCompatButton confirm = bottomSheetDialog.findViewById(R.id.confirm);


        ConfirmQuestion.setText(SharedPrefs.getSecurityQuestion(getApplicationContext()));

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomSheetDialog.dismiss();
            }
        });

        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ConfirmEdit.getText().toString().equals(SharedPrefs.getSecurityQuestionAnswer(getApplicationContext()))) {
                    Toast.makeText(MainLockActivity.this, "SuccessFully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(MainLockActivity.this, Third.class));
                    if (SharedPrefs.getLockFinalType(MainLockActivity.this).equalsIgnoreCase("Pattern")) {
                        SharedPrefs.setLockType(MainLockActivity.this, "Pattern");
                        startActivity(new Intent(MainLockActivity.this, Third.class));
                    } else {
                        SharedPrefs.setLockType(MainLockActivity.this, "PIN");
                        startActivity(new Intent(MainLockActivity.this, Third.class));
                    }
                } else {
                    Toast.makeText(MainLockActivity.this, "Enter a Valid answer", Toast.LENGTH_SHORT).show();
                }
            }
        });

        bottomSheetDialog.show();
    }


    private void randomnumber() {
        Random rng = new Random();
        for (int i = 0; i < 10; i++) {
            while (true) {
                Integer next = rng.nextInt(10);
                if (!generated.contains(next)) {
                    generated.add(next);
                    break;
                }
            }
        }

    }

    public void addRandomNumber(Button button, int randomNumber) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (SharedPrefs.getVibrateOnOff(getApplicationContext())) {
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE));

                    } else {
                        //deprecated in API 26
                        v.vibrate(50);
                    }
                    number_list.add(String.valueOf(randomNumber));
                    passnumber(number_list);
                } else {
                    number_list.add(String.valueOf(randomNumber));
                    passnumber(number_list);
                }
            }
        });
    }

    public void addNumber(Button button, String number) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (SharedPrefs.getVibrateOnOff(getApplicationContext())) {
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE));

                    } else {
                        //deprecated in API 26
                        v.vibrate(50);
                    }
                    number_list.add(number);
                    passnumber(number_list);
                } else {
                    number_list.add(number);
                    passnumber(number_list);
                }
            }
        });
    }

    private void passnumber(ArrayList<String> number_list) {

        if (number_list.size() == 0) {
            view1.setBackgroundResource(R.drawable.bg_view);
            view2.setBackgroundResource(R.drawable.bg_view);
            view3.setBackgroundResource(R.drawable.bg_view);
            view4.setBackgroundResource(R.drawable.bg_view);
        } else {
            switch (number_list.size()) {
                case 1:
                    num1 = number_list.get(0);
                    view1.setBackgroundResource(R.drawable.bg_view_blue_oval);
                    break;
                case 2:
                    num2 = number_list.get(1);
                    view2.setBackgroundResource(R.drawable.bg_view_blue_oval);
                    break;
                case 3:
                    num3 = number_list.get(2);
                    view3.setBackgroundResource(R.drawable.bg_view_blue_oval);
                    break;
                case 4:
                    num4 = number_list.get(3);
                    view4.setBackgroundResource(R.drawable.bg_view_blue_oval);
                    passcode = num1 + num2 + num3 + num4;

                    count++;

                    if (passcode.equals(SharedPrefs.getPinData(getApplicationContext()))) {

                        Intent intent = new Intent(MainLockActivity.this, AppList.class);
                        startActivity(intent);

                    } else {
                        patternCount++;
                        if (patternCount == SharedPrefs.getPasswordCount(getApplicationContext())) {
                            patternCount = 0;
                            if (SharedPrefs.getIntruderOnOff(getApplicationContext())) {
                                CameraManager mgr = new CameraManager(MainLockActivity.this);
                                mgr.takePhoto();
                                Toast.makeText(MainLockActivity.this, "Photo saved to Pictures\\iSelfie", Toast.LENGTH_SHORT).show();

                                SimpleDateFormat imagename = new SimpleDateFormat("yyyyMMddhhmmss", Locale.getDefault());
                                CommonClass.FileName = "iselfieapp_" + imagename.format(new Date()) + ".jpg";

                                SimpleDateFormat dateTime = new SimpleDateFormat("dd-MM-yy hh:mm aa", Locale.getDefault());
                                String currentDateTime = dateTime.format(new Date());

                                g.addData(drawableToBitmap(getResources().getDrawable(R.mipmap.ic_launcher)), currentDateTime, CommonClass.FileName, getResources().getString(R.string.app_name));
                            }

                        }

                        Toast.makeText(this, "Enter a Valid PIN", Toast.LENGTH_SHORT).show();
                    }

                    if (count == 3) {
                        forgetPassword.setVisibility(View.VISIBLE);
                    } else {
                        forgetPassword.setVisibility(View.GONE);
                    }

                    break;

            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null) {
            ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

//            SharedPreferences myPrefs;
//            myPrefs = getSharedPreferences("MySharedPref", MODE_PRIVATE);
//            String StoredValue = myPrefs.getString("name", "");
            startActivity(new Intent(MainLockActivity.this, AppList.class));
            finish();
        } else {

            Toast.makeText(this, "Your voice is doesn't match...", Toast.LENGTH_SHORT).show();
        }

    }


    @Override
    protected void onResume() {
        super.onResume();
        new NetworkConnection().callNetworkConnection(this);
    }
}