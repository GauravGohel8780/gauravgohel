package com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.model;

import android.os.Parcel;
import android.os.Parcelable;

public class FavItem implements Parcelable {
    private int _id;
    private String path;


    public FavItem(String path) {
    }

    public FavItem(int _id, String path) {
        this._id = _id;
        this.path = path;
    }

    protected FavItem(Parcel in) {
        _id = in.readInt();
        path = in.readString();
    }

    public static final Creator<FavItem> CREATOR = new Creator<FavItem>() {
        @Override
        public FavItem createFromParcel(Parcel in) {
            return new FavItem(in);
        }

        @Override
        public FavItem[] newArray(int size) {
            return new FavItem[size];
        }
    };

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(_id);
        parcel.writeString(path);
    }
}
