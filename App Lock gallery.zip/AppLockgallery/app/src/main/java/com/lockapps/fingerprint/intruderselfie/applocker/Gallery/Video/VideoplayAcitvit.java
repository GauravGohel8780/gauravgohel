package com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Video;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.internet.NetworkConnection;

public class VideoplayAcitvit extends AppCompatActivity {

    VideoView videoshow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videoplay_acitvit);

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(getResources().getColor(R.color.darkcolor));
        }

        videoshow = findViewById(R.id.videoshow);

        Intent i = getIntent();
        Uri uri = Uri.parse(i.getExtras().get("Videoshow").toString());
        videoshow.setVideoURI(uri);

        MediaController mediaController = new MediaController(this);

        mediaController.setAnchorView(videoshow);

        mediaController.setMediaPlayer(videoshow);

        videoshow.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                finish();
            }
        });

        videoshow.setMediaController(mediaController);

        videoshow.start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        new NetworkConnection().callNetworkConnection(this);
    }
}