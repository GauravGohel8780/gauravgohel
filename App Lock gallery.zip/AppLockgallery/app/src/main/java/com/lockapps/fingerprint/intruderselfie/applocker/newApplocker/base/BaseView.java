package com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.base;


public interface BaseView<T extends BasePresenter> {
}
