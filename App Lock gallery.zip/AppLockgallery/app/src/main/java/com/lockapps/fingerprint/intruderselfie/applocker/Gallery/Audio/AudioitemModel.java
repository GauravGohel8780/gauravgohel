package com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Audio;

import android.os.Parcel;
import android.os.Parcelable;

public class AudioitemModel implements Parcelable {
    private String picturName;
    private String picturePath;
    private String pictureSize;

    public AudioitemModel() {
    }

    public AudioitemModel(String picturName, String picturePath, String pictureSize) {
        this.picturName = picturName;
        this.picturePath = picturePath;
        this.pictureSize = pictureSize;
    }

    protected AudioitemModel(Parcel in) {
        picturName = in.readString();
        picturePath = in.readString();
        pictureSize = in.readString();
    }

    public static final Creator<AudioitemModel> CREATOR = new Creator<AudioitemModel>() {
        @Override
        public AudioitemModel createFromParcel(Parcel in) {
            return new AudioitemModel(in);
        }

        @Override
        public AudioitemModel[] newArray(int size) {
            return new AudioitemModel[size];
        }
    };

    public String getPicturName() {
        return picturName;
    }

    public void setPicturName(String picturName) {
        this.picturName = picturName;
    }

    public String getPicturePath() {
        return picturePath;
    }

    public void setPicturePath(String picturePath) {
        this.picturePath = picturePath;
    }

    public String getPictureSize() {
        return pictureSize;
    }

    public void setPictureSize(String pictureSize) {
        this.pictureSize = pictureSize;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(picturName);
        parcel.writeString(picturePath);
        parcel.writeString(pictureSize);
    }
}

