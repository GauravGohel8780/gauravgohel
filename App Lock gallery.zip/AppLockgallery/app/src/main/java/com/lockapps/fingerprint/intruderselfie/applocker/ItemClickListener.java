package com.lockapps.fingerprint.intruderselfie.applocker;

public interface ItemClickListener {

    void onItemClicked(String item);

}
