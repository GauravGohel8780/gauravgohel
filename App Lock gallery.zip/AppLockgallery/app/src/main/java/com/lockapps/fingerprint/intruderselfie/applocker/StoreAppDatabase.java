package com.lockapps.fingerprint.intruderselfie.applocker;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;

import androidx.annotation.Nullable;

import java.io.ByteArrayOutputStream;

public class StoreAppDatabase extends SQLiteOpenHelper {
    private static final String dbname = "dbSqlite.db";
    private static final String tablename = "users";
    byte[] imageInBytes;

    SQLiteDatabase a1;

    public StoreAppDatabase(@Nullable Context context) {
        super(context, dbname, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String db = "Create table " + tablename + "(_id integer primary key autoincrement, image blob, date text, path text, appName text)";
        sqLiteDatabase.execSQL(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String db = "drop table if exists " + tablename + "";
        sqLiteDatabase.execSQL(db);
    }

    public boolean addData(Bitmap image, String date, String path, String appName) {

        SQLiteDatabase db = this.getWritableDatabase();
        ByteArrayOutputStream objectByteOutputStream = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.JPEG, 100, objectByteOutputStream);
        imageInBytes = objectByteOutputStream.toByteArray();
        ContentValues c = new ContentValues();
        c.put("image", imageInBytes);
        c.put("date", date);
        c.put("path", path);
        c.put("appName", appName);
        long r = db.insert(tablename, null, c);
        if (r == -1) return false;
        else
            return true;

    }


    public boolean deleteTitle(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("users", "path=?", new String[]{name}) > 0;
    }

}