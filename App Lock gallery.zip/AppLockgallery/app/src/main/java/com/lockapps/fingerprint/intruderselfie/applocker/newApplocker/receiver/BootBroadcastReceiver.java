package com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.annotation.NonNull;

import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.base.AppConstants;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.services.BackgroundManager;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.services.LoadAppListService;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.services.LockService;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.utils.LogUtil;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.utils.SpUtil;


public class BootBroadcastReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(@NonNull Context context, Intent intent) {
        LogUtil.i("Boot service....");
        //TODO: pie compatable done
        context.startService(new Intent(context, LoadAppListService.class));
        BackgroundManager.getInstance().init(context).startService(LoadAppListService.class);
        if (SpUtil.getInstance().getBoolean(AppConstants.LOCK_STATE, false)) {
            BackgroundManager.getInstance().init(context).startService(LockService.class);
            BackgroundManager.getInstance().init(context).startAlarmManager();
        }
    }
}
