package com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Audio;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.OnAdCallBack;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.InterstitialAdManager;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager.RvBaseAdapter;

import java.util.ArrayList;

public class AudioAdapter extends RvBaseAdapter {

    private ArrayList<Object> arrayList;
    private Activity context;

    public AudioAdapter(ArrayList<Object> arrayList, Activity context) {
        this.arrayList = arrayList;
        this.context = context;
    }

    @Override
    public int setLayout(@NonNull ViewGroup viewGroup) {
        return R.layout.audiolayout;
    }

    @Override
    public int setAdLayoutContainer(@NonNull ViewGroup viewGroup) {
        return R.layout.layout_ad_container;
    }

    @Override
    public void itemBind(@NonNull RecyclerView.ViewHolder holder, int position) {
        RecyclerViewHolder viewHolder = (RecyclerViewHolder) holder;
        AudioModel model = (AudioModel) arrayList.get(position);

        Glide.with(context).load(model.getFirstPic()).placeholder(R.drawable.audioicon).into(viewHolder.folderPic);

        String text = model.getFolderName();
        viewHolder.folderName.setText(text);
        viewHolder.foldercoutn.setText("(" + model.getNumberOfPics() + ") ");

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new InterstitialAdManager(context).loadInterstitialAll(new OnAdCallBack() {
                    @Override
                    public void onAdDismiss() {
                        Intent intent = new Intent(context, AudioItemActivity.class);
                        intent.putExtra("folderPath", model.getPath());
                        intent.putExtra("foldername", model.getFolderName());
                        context.startActivity(intent);
                    }
                });
            }
        });
    }

    @Override
    public int itemCount() {
        return arrayList.size();
    }

    @Override
    public int itemPerAds() {
        return CommonData.ItemsPerAdsNormal;
    }

    @Override
    public ArrayList<Object> nativePosition() {
        return arrayList;
    }

    @Override
    public RecyclerView.ViewHolder viewHolder(View view) {
        return new RecyclerViewHolder(view);
    }

    private class RecyclerViewHolder extends RecyclerView.ViewHolder {
        private ImageView folderPic;
        private TextView folderName, foldercoutn;

        public RecyclerViewHolder(View view) {
            super(view);
            folderPic = (ImageView) view.findViewById(R.id.audioicon);
            folderName = (TextView) view.findViewById(R.id.audioname);
            foldercoutn = (TextView) view.findViewById(R.id.audionumber);
        }
    }
}