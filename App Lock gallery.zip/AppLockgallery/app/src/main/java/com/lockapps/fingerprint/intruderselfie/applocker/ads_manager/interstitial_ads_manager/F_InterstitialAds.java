package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.graphics.drawable.ColorDrawable;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;

import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.OnAdCallBack;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;

import java.util.concurrent.TimeUnit;

public class F_InterstitialAds {

    Activity activity;
    private Dialog adsDialog;

    public F_InterstitialAds(Activity activity) {
        this.activity = activity;
    }

    //=============== Pre Load FacebookAds ===================
    //=============== Pre Load FacebookAds ===================
    //=============== Pre Load FacebookAds ===================

    public void preLoadFacebook() {
        try {
            Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> load_Facebook() --> Start");
            CommonData._interstitial_facebook = new com.facebook.ads.InterstitialAd(activity, new AdsPreferences(activity).getFacebookInterstitial());

            com.facebook.ads.InterstitialAdListener interstitialAdListener = new com.facebook.ads.InterstitialAdListener() {
                @Override
                public void onInterstitialDisplayed(com.facebook.ads.Ad ad) {
                }

                @Override
                public void onInterstitialDismissed(com.facebook.ads.Ad ad) {
                    CommonData.aom_adCount = 0;
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> load_Facebook() --> onInterstitialDismissed");
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> ---");
                    CommonData.is_ShowingAd = false;
                    new AdsPreferences(activity).setAdsTimeCount((int) TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()));
                    new AdsPreferences(activity).setAdsClickCount(0);
                    preLoadFacebook();
                }

                @Override
                public void onError(com.facebook.ads.Ad ad, com.facebook.ads.AdError adError) {
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> load_Facebook() --> onError");
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> ***");
                    CommonData._interstitial_facebook = null;
                    preLoadFacebook2();
                }

                @Override
                public void onAdLoaded(com.facebook.ads.Ad ad) {
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> load_Facebook() --> onAdLoaded");
                }

                @Override
                public void onAdClicked(com.facebook.ads.Ad ad) {
                }

                @Override
                public void onLoggingImpression(com.facebook.ads.Ad ad) {
                }
            };

            CommonData._interstitial_facebook.loadAd(CommonData._interstitial_facebook.buildLoadAdConfig()
                    .withAdListener(interstitialAdListener)
                    .build());
        } catch (NullPointerException e) {

        }
    }

    public void preLoadFacebook2() {
        try {
            Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> load_Facebook1() --> Start");
            CommonData._interstitial_facebook = new com.facebook.ads.InterstitialAd(activity, new AdsPreferences(activity).getFacebookInterstitial());

            com.facebook.ads.InterstitialAdListener interstitialAdListener = new com.facebook.ads.InterstitialAdListener() {
                @Override
                public void onInterstitialDisplayed(com.facebook.ads.Ad ad) {
                }

                @Override
                public void onInterstitialDismissed(com.facebook.ads.Ad ad) {
                    CommonData.aom_adCount = 0;
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> load_Facebook1() --> onInterstitialDismissed");
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> ---");
                    CommonData.is_ShowingAd = false;
                    new AdsPreferences(activity).setAdsTimeCount((int) TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()));
                    new AdsPreferences(activity).setAdsClickCount(0);
                    preLoadFacebook();
                }

                @Override
                public void onError(com.facebook.ads.Ad ad, com.facebook.ads.AdError adError) {
                    CommonData.aom_adCount = 0;
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> load_Facebook1() --> onError");
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> ***");
                    CommonData._interstitial_facebook = null;
                }

                @Override
                public void onAdLoaded(com.facebook.ads.Ad ad) {
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> load_Facebook1() --> onAdLoaded");
                }

                @Override
                public void onAdClicked(com.facebook.ads.Ad ad) {
                }

                @Override
                public void onLoggingImpression(com.facebook.ads.Ad ad) {
                }
            };

            CommonData._interstitial_facebook.loadAd(CommonData._interstitial_facebook.buildLoadAdConfig()
                    .withAdListener(interstitialAdListener)
                    .build());
        } catch (NullPointerException e) {

        }
    }

    //=============== Click Load FacebookAds ===================
    //=============== Click Load FacebookAds ===================
    //=============== Click Load FacebookAds ===================

    public void clickLoadFacebook(OnAdCallBack onAdCallBack) {
        try {
            if (adsDialog != null) {
                adsDialog.dismiss();
            }

            adsDialog = new Dialog(activity);
            adsDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            adsDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
            adsDialog.setCancelable(false);
            adsDialog.setContentView(R.layout.ad_loading);
            adsDialog.show();
            //---
            Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> click_loadFacebook() --> Start");
            CommonData._interstitial_facebook = new com.facebook.ads.InterstitialAd(activity, new AdsPreferences(activity).getFacebookInterstitial());

            com.facebook.ads.InterstitialAdListener interstitialAdListener = new com.facebook.ads.InterstitialAdListener() {
                @Override
                public void onInterstitialDisplayed(com.facebook.ads.Ad ad) {
                }

                @Override
                public void onInterstitialDismissed(com.facebook.ads.Ad ad) {
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> click_loadFacebook() --> onInterstitialDismissed");
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> ---");
                    CommonData.is_ShowingAd = false;
                    new AdsPreferences(activity).setAdsTimeCount((int) TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()));
                    new AdsPreferences(activity).setAdsClickCount(0);
                    new InterstitialAdManager(activity)._nextActivity(onAdCallBack);
                }

                @Override
                public void onError(com.facebook.ads.Ad ad, com.facebook.ads.AdError adError) {
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> click_loadFacebook() --> onError");
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> ***");
                    CommonData._interstitial_facebook = null;
                    clickLoadFacebook1(onAdCallBack);
                }

                @Override
                public void onAdLoaded(com.facebook.ads.Ad ad) {
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> click_loadFacebook() --> onAdLoaded");
                    if (adsDialog != null) {
                        adsDialog.dismiss();
                    }
                    if (CommonData._interstitial_facebook == null || !CommonData._interstitial_facebook.isAdLoaded()) {
                        return;
                    }
                    if (CommonData._interstitial_facebook.isAdInvalidated()) {
                        return;
                    }
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_facebook.show();
                }

                @Override
                public void onAdClicked(com.facebook.ads.Ad ad) {
                }

                @Override
                public void onLoggingImpression(com.facebook.ads.Ad ad) {
                }
            };

            CommonData._interstitial_facebook.loadAd(CommonData._interstitial_facebook.buildLoadAdConfig()
                    .withAdListener(interstitialAdListener)
                    .build());
        } catch (NullPointerException | WindowManager.BadTokenException | ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void clickLoadFacebook1(OnAdCallBack onAdCallBack) {
        try {
            Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> click_loadFacebook1() --> Start");
            CommonData._interstitial_facebook = new com.facebook.ads.InterstitialAd(activity, new AdsPreferences(activity).getFacebookInterstitial());

            com.facebook.ads.InterstitialAdListener interstitialAdListener = new com.facebook.ads.InterstitialAdListener() {
                @Override
                public void onInterstitialDisplayed(com.facebook.ads.Ad ad) {
                }

                @Override
                public void onInterstitialDismissed(com.facebook.ads.Ad ad) {
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> click_loadFacebook1() --> onInterstitialDismissed");
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> ---");
                    CommonData.is_ShowingAd = false;
                    new AdsPreferences(activity).setAdsTimeCount((int) TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()));
                    new AdsPreferences(activity).setAdsClickCount(0);
                    new InterstitialAdManager(activity)._nextActivity(onAdCallBack);
                }

                @Override
                public void onError(com.facebook.ads.Ad ad, com.facebook.ads.AdError adError) {
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> click_loadFacebook1() --> onError");
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> ***");
                    if (adsDialog != null) {
                        adsDialog.dismiss();
                    }
                    CommonData._interstitial_facebook = null;
                    new InterstitialAdManager(activity)._nextActivity(onAdCallBack);
                }

                @Override
                public void onAdLoaded(com.facebook.ads.Ad ad) {
                    Log.i(CommonData.TAG, "facebook_ads --> Facebook_InterstitialAds --> click_loadFacebook1() --> onAdLoaded");
                    if (adsDialog != null) {
                        adsDialog.dismiss();
                    }
                    if (CommonData._interstitial_facebook == null || !CommonData._interstitial_facebook.isAdLoaded()) {
                        return;
                    }
                    if (CommonData._interstitial_facebook.isAdInvalidated()) {
                        return;
                    }
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_facebook.show();
                }

                @Override
                public void onAdClicked(com.facebook.ads.Ad ad) {
                }

                @Override
                public void onLoggingImpression(com.facebook.ads.Ad ad) {
                }
            };

            CommonData._interstitial_facebook.loadAd(CommonData._interstitial_facebook.buildLoadAdConfig()
                    .withAdListener(interstitialAdListener)
                    .build());
        } catch (NullPointerException | WindowManager.BadTokenException | ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }

}
