package com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Video;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;
import com.lockapps.fingerprint.intruderselfie.applocker.R;

import java.util.ArrayList;
import java.util.Objects;

public class VideoViewPagerAdapter extends PagerAdapter {

    Context context;
    private ArrayList<VideoItemModel> video;
    LayoutInflater mLayoutInflater;


    public VideoViewPagerAdapter(Context context, ArrayList<VideoItemModel> video) {
        this.context = context;
        this.video = video;
        mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    ImageView imageView, playitemvideo;

    @Override
    public int getCount() {
        return video.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, final int position) {

        VideoItemModel model = video.get(position);

        View itemView = mLayoutInflater.inflate(R.layout.video_browser_pager, container, false);

        imageView = itemView.findViewById(R.id.image);
        playitemvideo = itemView.findViewById(R.id.playitmevideo);

        Glide.with(context).load(model.getPicturePath()).into(imageView);

        playitemvideo.setOnClickListener(view -> {
            Intent intent = new Intent(context, VideoplayAcitvit.class).putExtra("Videoshow", model.getPicturePath());
            context.startActivity(intent);
        });


        Objects.requireNonNull(container).addView(itemView);

        return itemView;
    }


    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((RelativeLayout) object);
    }
}
