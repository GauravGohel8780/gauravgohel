package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.graphics.drawable.ColorDrawable;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.OnAdCallBack;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;

import java.util.concurrent.TimeUnit;

public class G_InterstitialAds {

    Activity activity;
    private Dialog adsDialog;

    public G_InterstitialAds(Activity activity) {
        this.activity = activity;
    }

    //=============== Pre Load GoogleAds ===================
    //=============== Pre Load GoogleAds ===================
    //=============== Pre Load GoogleAds ===================

    public void preLoadAdMob() {
            AdRequest adRequest = new AdRequest.Builder().build();
            InterstitialAd.load(activity, new AdsPreferences(activity).getAdmobInterstitial(), adRequest, new InterstitialAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                    CommonData._interstitial_google = interstitialAd;
                    interstitialAd.setFullScreenContentCallback(
                            new FullScreenContentCallback() {
                                @Override
                                public void onAdDismissedFullScreenContent() {
                                    CommonData._interstitial_google = null;
                                    CommonData.is_ShowingAd = false;
                                    CommonData.aom_adCount = 0;
                                    new AdsPreferences(activity).setAdsTimeCount((int) TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()));
                                    new AdsPreferences(activity).setAdsClickCount(0);
                                    preLoadAdMob();
                                }

                                @Override
                                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                                    CommonData._interstitial_google = null;
                                    preLoadAdx(); // optional
                                }

                                @Override
                                public void onAdShowedFullScreenContent() {
                                }
                            });
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    CommonData._interstitial_google = null;
                    preLoadAdx();
                }
            });
    }

    public void preLoadAdx() {
            AdRequest adRequest = new AdRequest.Builder().build();
            InterstitialAd.load(activity, new AdsPreferences(activity).getAdxInterstitial(), adRequest, new InterstitialAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                    CommonData._interstitial_google = interstitialAd;
                    interstitialAd.setFullScreenContentCallback(
                            new FullScreenContentCallback() {
                                @Override
                                public void onAdDismissedFullScreenContent() {
                                    CommonData._interstitial_google = null;
                                    CommonData.is_ShowingAd = false;
                                    CommonData.aom_adCount = 0;
                                    new AdsPreferences(activity).setAdsTimeCount((int) TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()));
                                    new AdsPreferences(activity).setAdsClickCount(0);
                                    preLoadAdMob();
                                }

                                @Override
                                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                                    CommonData._interstitial_google = null;
                                    CommonData.aom_adCount = 0;
                                }

                                @Override
                                public void onAdShowedFullScreenContent() {
                                }
                            });
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    CommonData.aom_adCount = 0;
                    CommonData._interstitial_google = null;
                }
            });
    }

    //=============== Click Load GoogleAds ===================
    //=============== Click Load GoogleAds ===================
    //=============== Click Load GoogleAds ===================

    public void clickLoadAdMob(OnAdCallBack onAdCallBack) {
        try {
            if (adsDialog != null) {
                adsDialog.dismiss();
            }
            adsDialog = new Dialog(activity);
            adsDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            adsDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
            adsDialog.setCancelable(false);
            adsDialog.setContentView(R.layout.ad_loading);
            adsDialog.show();

            AdRequest adRequest = new AdRequest.Builder().build();
            InterstitialAd.load(activity, new AdsPreferences(activity).getAdmobInterstitial(), adRequest, new InterstitialAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                    adsDialog.dismiss();
                    CommonData._interstitial_google = interstitialAd;
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_google.show(activity);

                    interstitialAd.setFullScreenContentCallback(
                            new FullScreenContentCallback() {
                                @Override
                                public void onAdDismissedFullScreenContent() {
                                    CommonData._interstitial_google = null;
                                    CommonData.is_ShowingAd = false;
                                    new AdsPreferences(activity).setAdsTimeCount((int) TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()));
                                    new AdsPreferences(activity).setAdsClickCount(0);
                                    new InterstitialAdManager(activity)._nextActivity(onAdCallBack);
                                }

                                @Override
                                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                                    CommonData._interstitial_google = null;
                                }

                                @Override
                                public void onAdShowedFullScreenContent() {
                                }
                            });
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    CommonData._interstitial_google = null;
                    clickLoadAdx(onAdCallBack);
                }
            });
        } catch (WindowManager.BadTokenException | ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void clickLoadAdx(OnAdCallBack onAdCallBack) {
        try {
            AdRequest adRequest = new AdRequest.Builder().build();
            InterstitialAd.load(activity, new AdsPreferences(activity).getAdxInterstitial(), adRequest, new InterstitialAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                    adsDialog.dismiss();
                    CommonData._interstitial_google = interstitialAd;
                    CommonData.is_ShowingAd = true;
                    CommonData._interstitial_google.show(activity);

                    interstitialAd.setFullScreenContentCallback(
                            new FullScreenContentCallback() {
                                @Override
                                public void onAdDismissedFullScreenContent() {
                                    CommonData._interstitial_google = null;
                                    CommonData.is_ShowingAd = false;
                                    new AdsPreferences(activity).setAdsTimeCount((int) TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()));
                                    new AdsPreferences(activity).setAdsClickCount(0);
                                    new InterstitialAdManager(activity)._nextActivity(onAdCallBack);
                                }

                                @Override
                                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                                    CommonData._interstitial_google = null;
                                }

                                @Override
                                public void onAdShowedFullScreenContent() {
                                }
                            });
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    adsDialog.dismiss();
                    CommonData._interstitial_google = null;
                    new InterstitialAdManager(activity)._nextActivity(onAdCallBack);
                }
            });
        } catch (WindowManager.BadTokenException | ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }

}
