package com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.activities.main;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

import androidx.core.content.ContextCompat;

import com.lockapps.fingerprint.intruderselfie.applocker.Activities.MainActivity;
import com.lockapps.fingerprint.intruderselfie.applocker.Activities.MainLockActivity;
import com.lockapps.fingerprint.intruderselfie.applocker.SharedPrefs;
import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonAppMethodes;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.OnAdCallBack;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.internet.NetworkConnection;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.retrofit_client.GetDataFromServer;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.base.AppConstants;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.base.BaseActivity;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.services.BackgroundManager;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.services.LoadAppListService;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.services.LockService;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.utils.SpUtil;

public class SplashActivity extends BaseActivity {


    @Override
    public int getLayoutId() {

        SetSystemFullScreen();
        return R.layout.activity_splash;
    }

    @Override
    protected void initViews(Bundle savedInstanceState) {
        new CommonAppMethodes(this).SetSystemFullScreen();
        new NetworkConnection().callNetworkConnection(this);
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.darkcolor));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        new GetDataFromServer(this).disconnectFromVnp();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    public void SetSystemFullScreen() {
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) { // lower api
            View v = getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }

    @Override
    protected void initData() {
        BackgroundManager.getInstance().init(SplashActivity.this).startService(LoadAppListService.class);

        new GetDataFromServer(this).getAdDataUsingVolly(new OnAdCallBack() {
            @Override
            public void onAdDismiss() {
                if (SpUtil.getInstance().getBoolean(AppConstants.LOCK_STATE, false)) {
                    BackgroundManager.getInstance().init(SplashActivity.this).startService(LockService.class);
                }

                if (SharedPrefs.getIsPasswordSet(getApplicationContext())) {
                    Intent intent = new Intent(SplashActivity.this, MainLockActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();


                }
            }
        });

    }

    @Override
    protected void initAction() {
    }
}