package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.graphics.drawable.DrawableCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;

public class RecycleviewAdManager implements View.OnClickListener {

    Activity activity;

    public RecycleviewAdManager(Activity activity) {
        this.activity = activity;
    }


    //=============== Load NativeAd In Recycleview =======================
    //=============== Load NativeAd In Recycleview =======================


    public void AddNativeAd(boolean isMedia, int adSize, ArrayList<Object> mainList, int itemPerAd) {

        if (new AdsPreferences(activity).getisMediaOn()) {
            if (isMedia) {
                if (adSize == 2) {
                    int adLayout = R.layout.native_mediaview;
                    for (int i = 0; i <= mainList.size(); i += itemPerAd) {
                        NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(adLayout, null);

                        mainList.add(i, adView);
                    }
                }
            } else {
                int adLayout;
                if (adSize == 1) {
                    if (getRandomLay() == 1) {
                        adLayout = R.layout.am_native_big_1;
                    } else if (getRandomLay() == 2) {
                        adLayout = R.layout.am_native_big_2;
                    } else if (getRandomLay() == 3) {
                        adLayout = R.layout.am_native_big_3;
                    } else {
                        adLayout = R.layout.am_native_big_4;
                    }
                } else if (adSize == 2) {
                    if (new AdsPreferences(activity).getisMediaOn()) {
                        adLayout = R.layout.native_mediaview;
                    } else {
                        if (getRandomLay() == 1) {
                            adLayout = R.layout.am_native_banner_1;
                        } else if (getRandomLay() == 2) {
                            adLayout = R.layout.am_native_banner_2;
                        } else {
                            adLayout = R.layout.am_native_banner_3;
                        }
                    }
                } else if (adSize == 3) {
                    adLayout = R.layout.am_native_banner2;
                } else if (adSize == 4) {
                    adLayout = R.layout.am_native_bottom_banner;
                } else {
                    if (new AdsPreferences(activity).getisMediaOn()) {
                        adLayout = R.layout.native_mediaview;
                    } else {
                        if (getRandomLay() == 1) {
                            adLayout = R.layout.am_native_banner_1;
                        } else if (getRandomLay() == 2) {
                            adLayout = R.layout.am_native_banner_2;
                        } else {
                            adLayout = R.layout.am_native_banner_3;
                        }
                    }
                }
                for (int i = 0; i <= mainList.size(); i += itemPerAd) {
                    NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(adLayout, null);

                    mainList.add(i, adView);

                    TextView ad_headline = adView.findViewById(R.id.ad_headline);
                    if (ad_headline.getText().toString().isEmpty()) {
                        populateLoadingViewShow(adView);
                    } else {
                        populateLoadingViewGone(adView);
                    }
                }
            }
        } else{
            int adLayout;
            if (adSize == 1) {
                if (getRandomLay() == 1) {
                    adLayout = R.layout.am_native_big_1;
                } else if (getRandomLay() == 2) {
                    adLayout = R.layout.am_native_big_2;
                } else if (getRandomLay() == 3) {
                    adLayout = R.layout.am_native_big_3;
                } else {
                    adLayout = R.layout.am_native_big_4;
                }
            } else if (adSize == 2) {
                if (new AdsPreferences(activity).getisMediaOn()) {
                    adLayout = R.layout.native_mediaview;
                } else {
                    if (getRandomLay() == 1) {
                        adLayout = R.layout.am_native_banner_1;
                    } else if (getRandomLay() == 2) {
                        adLayout = R.layout.am_native_banner_2;
                    } else {
                        adLayout = R.layout.am_native_banner_3;
                    }
                }
            } else if (adSize == 3) {
                adLayout = R.layout.am_native_banner2;
            } else if (adSize == 4) {
                adLayout = R.layout.am_native_bottom_banner;
            } else {
                if (new AdsPreferences(activity).getisMediaOn()) {
                    adLayout = R.layout.native_mediaview;
                } else {
                    if (getRandomLay() == 1) {
                        adLayout = R.layout.am_native_banner_1;
                    } else if (getRandomLay() == 2) {
                        adLayout = R.layout.am_native_banner_2;
                    } else {
                        adLayout = R.layout.am_native_banner_3;
                    }
                }
            }
            for (int i = 0; i <= mainList.size(); i += itemPerAd) {
                NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(adLayout, null);

                mainList.add(i, adView);

                TextView ad_headline = adView.findViewById(R.id.ad_headline);
                if (ad_headline.getText().toString().isEmpty()) {
                    populateLoadingViewShow(adView);
                } else {
                    populateLoadingViewGone(adView);
                }
            }
        }
    }

    public void LoadNativeAd(int adSize, ArrayList<Object> mainList, int itemPerAd) {
        LoadNativeAdRv(adSize, mainList, itemPerAd, 0);
    }

    public void LoadNativeAdRv(int adSize, ArrayList<Object> mainList, int itemPerAd, final int index) {
        try {
            if (index >= mainList.size()) {
                return;
            }

            Object item = mainList.get(index);
            if (!(item instanceof NativeAdView)) {
                throw new ClassCastException("Expected item at index " + index + " to be a banner ad" + " ad.");
            }

            final NativeAdView adView = (NativeAdView) item;

            com.google.android.gms.ads.AdLoader.Builder builder = new com.google.android.gms.ads.AdLoader.Builder(activity, new AdsPreferences(activity).getAdmobNativeBanner());
            builder.forNativeAd(nativeAd -> {
//                if (Objects.requireNonNull(nativeAd.getBody()).equalsIgnoreCase("")){
//                    populateLoadingViewShow(adView);
//                } else {
//                    populateLoadingViewGone(adView);
//                }
                populateNativeAdSize(adSize, nativeAd, adView);
                LoadNativeAdRv(adSize, mainList, itemPerAd, index + itemPerAd);
            });
            com.google.android.gms.ads.VideoOptions videoOptions = new com.google.android.gms.ads.VideoOptions.Builder().setStartMuted(true).build();//false
            com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new com.google.android.gms.ads.nativead.NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
            builder.withNativeAdOptions(adOptions);

            com.google.android.gms.ads.AdLoader adLoader = builder.withAdListener(new com.google.android.gms.ads.AdListener() {
                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError errorCode) {
                    com.google.android.gms.ads.AdLoader.Builder builder = new com.google.android.gms.ads.AdLoader.Builder(activity, new AdsPreferences(activity).getAdxNativeBanner());
                    builder.forNativeAd(nativeAd -> {
                        populateNativeAdSize(adSize, nativeAd, adView);
                        LoadNativeAdRv(adSize, mainList, itemPerAd, index + itemPerAd);
                    });
                    com.google.android.gms.ads.VideoOptions videoOptions = new com.google.android.gms.ads.VideoOptions.Builder().setStartMuted(true).build();//false
                    com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new com.google.android.gms.ads.nativead.NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
                    builder.withNativeAdOptions(adOptions);

                    com.google.android.gms.ads.AdLoader adLoader = builder.withAdListener(new com.google.android.gms.ads.AdListener() {
                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError errorCode) {
                            if (new AdsPreferences(activity).getIsAppsAdShow()) {
                                populateAppsAdSize(adSize, adView);
                                LoadNativeAdRv(adSize, mainList, itemPerAd, index + itemPerAd);
                            } else {
                                populateLoadingViewShow(adView);
                                LoadNativeAdRv(adSize, mainList, itemPerAd, index + itemPerAd);
                            }
                        }
                    }).build();
                    adLoader.loadAd(new AdRequest.Builder().build());
                }
            }).build();
            adLoader.loadAd(new AdRequest.Builder().build());
        } catch (NullPointerException | ClassCastException e) {
            e.printStackTrace();
        }
    }


    //=============== RecyclerView Native Ad With Pager =======================
    //=============== RecyclerView Native Ad With Pager =======================

    public void AddNativeAdWithPager(int adSize, ArrayList<Object> noramalAds, ArrayList<Object> bigAds, int itemPerAd) {
        int adLayout;
        if (adSize == 1) {
            if (getRandomLay() == 1) {
                adLayout = R.layout.am_native_big_1;
            } else if (getRandomLay() == 2) {
                adLayout = R.layout.am_native_big_2;
            } else if (getRandomLay() == 3) {
                adLayout = R.layout.am_native_big_3;
            } else {
                adLayout = R.layout.am_native_big_4;
            }
        } else if (adSize == 2) {
            if (getRandomLay() == 1) {
                adLayout = R.layout.am_native_banner_1;
            } else if (getRandomLay() == 2) {
                adLayout = R.layout.am_native_banner_2;
            } else {
                adLayout = R.layout.am_native_banner_3;
            }
        } else if (adSize == 3) {
            adLayout = R.layout.am_native_banner2;
        } else if (adSize == 4) {
            adLayout = R.layout.am_native_bottom_banner;
        } else {
            if (getRandomLay() == 1) {
                adLayout = R.layout.am_native_banner_1;
            } else if (getRandomLay() == 2) {
                adLayout = R.layout.am_native_banner_2;
            } else {
                adLayout = R.layout.am_native_banner_3;
            }
        }

        for (int i = 0; i <= noramalAds.size(); i += itemPerAd) {
            NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(adLayout, null);
            NativeAdView adView2 = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.am_native_banner_full_screen, null);
            noramalAds.add(i, adView);
            bigAds.add(i, adView2);

            TextView ad_headline = adView.findViewById(R.id.ad_headline);
            if (ad_headline.getText().toString().isEmpty()) {
                populateLoadingViewShow(adView);
            } else {
                populateLoadingViewGone(adView);
            }
        }
    }


    //=============== Populate Ad Size Validation =======================
    //=============== Populate Ad Size Validation =======================


    public void populateNativeAdSize(int adSize, NativeAd nativeAd, NativeAdView adView) {
        if (adSize == 1) {
            populateAmNativeAdView(nativeAd, adView);
        } else if (adSize == 2) {
            if (new AdsPreferences(activity).getisMediaOn()) {
                populateAmNativeBannerMediaAdView(nativeAd, adView);
            } else {
                populateAmNativeBannerAdView(nativeAd, adView);
            }
        } else if (adSize == 3) {
            populateAmNativeBannerAdView2(nativeAd, adView);
        } else if (adSize == 4) {
            populateAmNativeBannerAdView2(nativeAd, adView);
        } else {
            populateAmNativeBannerMediaAdView(nativeAd, adView);
        }
    }

    public void populateAppsAdSize(int adSize, NativeAdView adView) {
        if (adSize == 1) {
            populateAppsAdView(adView);
        } else if (adSize == 2) {
            if (new AdsPreferences(activity).getisMediaOn()) {
                populateAppsBannerMediaAdView(adView);
            } else {
                populateAppsBannerAdView(adView);
            }
        } else if (adSize == 3) {
            populateAppsBannerAdView2(adView);
        } else if (adSize == 4) {
            populateAppsBannerAdView2(adView);
        } else {
            populateAppsBannerMediaAdView(adView);
        }
    }


    //=============== Populate NativeAd =======================
    //=============== Populate NativeAd =======================

    public void populateAmNativeAdView(NativeAd nativeAd, NativeAdView adView) {
        LinearLayout adContainer = adView.findViewById(R.id.adContainer);
        LinearLayout loadingContainer = adView.findViewById(R.id.loadingContainer);

        adContainer.setVisibility(View.VISIBLE);
        loadingContainer.setVisibility(View.GONE);

        adView.setMediaView(adView.findViewById(R.id.ad_media));
        adView.setImageView(adView.findViewById(R.id.ad_mediaImage));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        adView.getMediaView().setVisibility(View.VISIBLE);
//        adView.getImageView().setVisibility(View.GONE);

        // CallToAction Button Color
        if (new AdsPreferences(activity).getBtnColorFlag()) {
            Drawable tintDr = DrawableCompat.wrap(adView.getCallToActionView().getBackground());
            DrawableCompat.setTint(tintDr, Color.parseColor(new AdsPreferences(activity).getBtnColor()));
            adView.getCallToActionView().setBackground(tintDr);
        }

        ((AppCompatTextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        adView.getMediaView().setMediaContent(nativeAd.getMediaContent());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((AppCompatTextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((AppCompatButton) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        //   HideAds: Icon
        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            adView.getIconView().setVisibility(View.VISIBLE);
            ((AppCompatImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.GONE);
        } else {
            ((AppCompatTextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.GONE);
        }

        adView.setNativeAd(nativeAd);
        com.google.android.gms.ads.VideoController vc = Objects.requireNonNull(nativeAd.getMediaContent()).getVideoController();
        if (vc.hasVideoContent()) {
            vc.setVideoLifecycleCallbacks(new com.google.android.gms.ads.VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        }
    }

    public void populateAppsAdView(NativeAdView adView) {
        LinearLayout adContainer = adView.findViewById(R.id.adContainer);
        LinearLayout loadingContainer = adView.findViewById(R.id.loadingContainer);

        adContainer.setVisibility(View.VISIBLE);
        loadingContainer.setVisibility(View.GONE);

        adView.setMediaView(adView.findViewById(R.id.ad_media));
        adView.setImageView(adView.findViewById(R.id.ad_mediaImage));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));

        Objects.requireNonNull(adView.getImageView()).setVisibility(View.VISIBLE);
        Objects.requireNonNull(adView.getMediaView()).setVisibility(View.GONE);

        //  CallToAction Button Color
        if (new AdsPreferences(activity).getBtnColorFlag()) {
            Drawable tintDr = DrawableCompat.wrap(Objects.requireNonNull(adView.getCallToActionView()).getBackground());
            DrawableCompat.setTint(tintDr, Color.parseColor(new AdsPreferences(activity).getBtnColor()));
            adView.getCallToActionView().setBackground(tintDr);
        }

        //  //  Apps Icon
        //  //  HideAds: Icon
        Objects.requireNonNull(adView.getIconView()).setVisibility(View.VISIBLE);
        Glide.with(activity).clear((AppCompatImageView) Objects.requireNonNull(adView.getIconView()));
        Glide.with(activity)
                .load(new AdsPreferences(activity).getAppsIcon())
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true)
                .into((AppCompatImageView) adView.getIconView());

        // Apps Image
        Glide.with(activity).clear((AppCompatImageView) Objects.requireNonNull(adView.getImageView()));
        Glide.with(activity)
                .load(new AdsPreferences(activity).getAppsBanner())
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true)
                .into((AppCompatImageView) adView.getImageView());

        ((AppCompatTextView) Objects.requireNonNull(adView.getHeadlineView())).setText(new AdsPreferences(activity).getAppsHeadline());
        ((AppCompatTextView) Objects.requireNonNull(adView.getBodyView())).setText(new AdsPreferences(activity).getAppsBody());
        ((AppCompatTextView) Objects.requireNonNull(adView.getAdvertiserView())).setVisibility(View.GONE);

        adView.getHeadlineView().setOnClickListener(this);
        adView.getBodyView().setOnClickListener(this);
        adView.getIconView().setOnClickListener(this);
        adView.getImageView().setOnClickListener(this);
        adView.getAdvertiserView().setOnClickListener(this);
        Objects.requireNonNull(adView.getCallToActionView()).setOnClickListener(this);

    }


    //=============== Populate Native Banner Ad =======================
    //=============== Populate Native Banner Ad =======================

    public void populateAmNativeBannerAdView(NativeAd nativeAd, NativeAdView adView) {
        LinearLayout adContainer = adView.findViewById(R.id.adContainer);
        LinearLayout loadingContainer = adView.findViewById(R.id.loadingContainer);

        adContainer.setVisibility(View.VISIBLE);
        loadingContainer.setVisibility(View.GONE);

        adView.setMediaView(adView.findViewById(R.id.ad_media));
        adView.setImageView(adView.findViewById(R.id.ad_mediaImage));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        adView.getMediaView().setVisibility(View.VISIBLE);
        adView.getImageView().setVisibility(View.GONE);

        // CallToAction Button Color
        if (new AdsPreferences(activity).getBtnColorFlag()) {
            Drawable tintDr = DrawableCompat.wrap(adView.getCallToActionView().getBackground());
            DrawableCompat.setTint(tintDr, Color.parseColor(new AdsPreferences(activity).getBtnColor()));
            adView.getCallToActionView().setBackground(tintDr);
        }

        ((AppCompatTextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        adView.getMediaView().setMediaContent(nativeAd.getMediaContent());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((AppCompatTextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((AppCompatButton) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        //   HideAds: Icon
        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            adView.getIconView().setVisibility(View.GONE);
            ((AppCompatImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.GONE);
        } else {
            ((AppCompatTextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.GONE);
        }

        adView.setNativeAd(nativeAd);
        com.google.android.gms.ads.VideoController vc = Objects.requireNonNull(nativeAd.getMediaContent()).getVideoController();
        if (vc.hasVideoContent()) {
            vc.setVideoLifecycleCallbacks(new com.google.android.gms.ads.VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        }
    }

    public void populateAppsBannerAdView(NativeAdView adView) {
        LinearLayout adContainer = adView.findViewById(R.id.adContainer);
        LinearLayout loadingContainer = adView.findViewById(R.id.loadingContainer);

        adContainer.setVisibility(View.VISIBLE);
        loadingContainer.setVisibility(View.GONE);

        adView.setMediaView(adView.findViewById(R.id.ad_media));
        adView.setImageView(adView.findViewById(R.id.ad_mediaImage));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));

        Objects.requireNonNull(adView.getImageView()).setVisibility(View.VISIBLE);
        Objects.requireNonNull(adView.getMediaView()).setVisibility(View.GONE);

        //  CallToAction Button Color
        if (new AdsPreferences(activity).getBtnColorFlag()) {
            Drawable tintDr = DrawableCompat.wrap(Objects.requireNonNull(adView.getCallToActionView()).getBackground());
            DrawableCompat.setTint(tintDr, Color.parseColor(new AdsPreferences(activity).getBtnColor()));
            adView.getCallToActionView().setBackground(tintDr);
        }

        //  //  Apps Icon
        //  //  HideAds: Icon
        Objects.requireNonNull(adView.getIconView()).setVisibility(View.GONE);
        Glide.with(activity).clear((AppCompatImageView) Objects.requireNonNull(adView.getIconView()));
        Glide.with(activity)
                .load(new AdsPreferences(activity).getAppsIcon())
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true)
                .into((AppCompatImageView) adView.getIconView());

        // Apps Image
        Glide.with(activity).clear((AppCompatImageView) Objects.requireNonNull(adView.getImageView()));
        Glide.with(activity)
                .load(new AdsPreferences(activity).getAppsBanner())
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true)
                .into((AppCompatImageView) adView.getImageView());

        ((AppCompatTextView) Objects.requireNonNull(adView.getHeadlineView())).setText(new AdsPreferences(activity).getAppsHeadline());
        ((AppCompatTextView) Objects.requireNonNull(adView.getBodyView())).setText(new AdsPreferences(activity).getAppsBody());
        ((AppCompatTextView) Objects.requireNonNull(adView.getAdvertiserView())).setVisibility(View.GONE);

        adView.getHeadlineView().setOnClickListener(this);
        adView.getBodyView().setOnClickListener(this);
        adView.getIconView().setOnClickListener(this);
        adView.getImageView().setOnClickListener(this);
        adView.getAdvertiserView().setOnClickListener(this);
        Objects.requireNonNull(adView.getCallToActionView()).setOnClickListener(this);

    }


    //=============== Populate Native Banner Media Ad =======================
    //=============== Populate Native Banner Media Ad =======================

    public void populateAmNativeBannerMediaAdView(NativeAd nativeAd, NativeAdView adView) {

        LinearLayout adContainer = adView.findViewById(R.id.adContainer);
        LinearLayout loadingContainer = adView.findViewById(R.id.loadingContainer);

        adContainer.setVisibility(View.VISIBLE);
        loadingContainer.setVisibility(View.GONE);

        adView.setMediaView(adView.findViewById(R.id.ad_media));
        adView.setImageView(adView.findViewById(R.id.ad_mediaImage));
//        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
//        adView.setBodyView(adView.findViewById(R.id.ad_body));
//        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
//        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
//        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        adView.getMediaView().setVisibility(View.VISIBLE);
        adView.getImageView().setVisibility(View.GONE);

        // CallToAction Button Color
//        if (new AdsPreferences(activity).getBtnColorFlag()) {
//            Drawable tintDr = DrawableCompat.wrap(adView.getCallToActionView().getBackground());
//            DrawableCompat.setTint(tintDr, Color.parseColor(new AdsPreferences(activity).getBtnColor()));
//            adView.getCallToActionView().setBackground(tintDr);
//        }

//        ((AppCompatTextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
//        adView.getMediaView().setMediaContent(nativeAd.getMediaContent());
//        if (nativeAd.getBody() == null) {
//            adView.getBodyView().setVisibility(View.INVISIBLE);
//        } else {
//            adView.getBodyView().setVisibility(View.VISIBLE);
//            ((AppCompatTextView) adView.getBodyView()).setText(nativeAd.getBody());
//        }

//        if (nativeAd.getCallToAction() == null) {
//            adView.getCallToActionView().setVisibility(View.INVISIBLE);
//        } else {
//            adView.getCallToActionView().setVisibility(View.VISIBLE);
//            ((AppCompatButton) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
//        }

        //   HideAds: Icon
//        if (nativeAd.getIcon() == null) {
//            adView.getIconView().setVisibility(View.GONE);
//        } else {
//            adView.getIconView().setVisibility(View.GONE);
//            ((AppCompatImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
//        }

//        if (nativeAd.getAdvertiser() == null) {
//            adView.getAdvertiserView().setVisibility(View.GONE);
//        } else {
//            ((AppCompatTextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
//            adView.getAdvertiserView().setVisibility(View.GONE);
//        }

        adView.setNativeAd(nativeAd);
        com.google.android.gms.ads.VideoController vc = Objects.requireNonNull(nativeAd.getMediaContent()).getVideoController();
        if (vc.hasVideoContent()) {
            vc.setVideoLifecycleCallbacks(new com.google.android.gms.ads.VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        }
    }

    public void populateAppsBannerMediaAdView(NativeAdView adView) {
        LinearLayout adContainer = adView.findViewById(R.id.adContainer);
        LinearLayout loadingContainer = adView.findViewById(R.id.loadingContainer);

        adContainer.setVisibility(View.VISIBLE);
        loadingContainer.setVisibility(View.GONE);

        adView.setMediaView(adView.findViewById(R.id.ad_media));
        adView.setImageView(adView.findViewById(R.id.ad_mediaImage));

        Objects.requireNonNull(adView.getImageView()).setVisibility(View.VISIBLE);
        Objects.requireNonNull(adView.getMediaView()).setVisibility(View.GONE);


        adView.getImageView().setOnClickListener(this);

    }


    //=============== Populate Native Banner Ad 2 =======================
    //=============== Populate Native Banner Ad 2 =======================

    public void populateAmNativeBannerAdView2(NativeAd nativeAd, NativeAdView adView) {
        LinearLayout adContainer = adView.findViewById(R.id.adContainer);
        LinearLayout loadingContainer = adView.findViewById(R.id.loadingContainer);

        adContainer.setVisibility(View.VISIBLE);
        loadingContainer.setVisibility(View.GONE);

//        adView.setMediaView(adView.findViewById(R.id.ad_media));
//        adView.setImageView(adView.findViewById(R.id.ad_mediaImage));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

//        adView.getMediaView().setVisibility(View.VISIBLE);
//        adView.getImageView().setVisibility(View.GONE);

        // CallToAction Button Color
        if (new AdsPreferences(activity).getBtnColorFlag()) {
            Drawable tintDr = DrawableCompat.wrap(adView.getCallToActionView().getBackground());
            DrawableCompat.setTint(tintDr, Color.parseColor(new AdsPreferences(activity).getBtnColor()));
            adView.getCallToActionView().setBackground(tintDr);
        }

        ((AppCompatTextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
//        adView.getMediaView().setMediaContent(nativeAd.getMediaContent());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((AppCompatTextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((AppCompatButton) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        //   HideAds: Icon
        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            adView.getIconView().setVisibility(View.VISIBLE);
            ((AppCompatImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.GONE);
        } else {
            ((AppCompatTextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.GONE);
        }

        adView.setNativeAd(nativeAd);
        com.google.android.gms.ads.VideoController vc = Objects.requireNonNull(nativeAd.getMediaContent()).getVideoController();
        if (vc.hasVideoContent()) {
            vc.setVideoLifecycleCallbacks(new com.google.android.gms.ads.VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        }
    }

    public void populateAppsBannerAdView2(NativeAdView adView) {
        LinearLayout adContainer = adView.findViewById(R.id.adContainer);
        LinearLayout loadingContainer = adView.findViewById(R.id.loadingContainer);

        adContainer.setVisibility(View.VISIBLE);
        loadingContainer.setVisibility(View.GONE);

//        adView.setMediaView(adView.findViewById(R.id.ad_media));
//        adView.setImageView(adView.findViewById(R.id.ad_mediaImage));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));

//        Objects.requireNonNull(adView.getImageView()).setVisibility(View.VISIBLE);
//        Objects.requireNonNull(adView.getMediaView()).setVisibility(View.GONE);

        //  CallToAction Button Color
        if (new AdsPreferences(activity).getBtnColorFlag()) {
            Drawable tintDr = DrawableCompat.wrap(Objects.requireNonNull(adView.getCallToActionView()).getBackground());
            DrawableCompat.setTint(tintDr, Color.parseColor(new AdsPreferences(activity).getBtnColor()));
            adView.getCallToActionView().setBackground(tintDr);
        }

        //  //  Apps Icon
        //  //  HideAds: Icon
        Objects.requireNonNull(adView.getIconView()).setVisibility(View.VISIBLE);
        Glide.with(activity).clear((AppCompatImageView) Objects.requireNonNull(adView.getIconView()));
        Glide.with(activity)
                .load(new AdsPreferences(activity).getAppsIcon())
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true)
                .into((AppCompatImageView) adView.getIconView());

        // Apps Image
//        Glide.with(activity).clear((AppCompatImageView) Objects.requireNonNull(adView.getImageView()));
//        Glide.with(activity)
//                .load(new AdsPreferences(activity).getAppsBanner())
//                .diskCacheStrategy(DiskCacheStrategy.NONE)
//                .skipMemoryCache(true)
//                .into((AppCompatImageView) adView.getImageView());

        ((AppCompatTextView) Objects.requireNonNull(adView.getHeadlineView())).setText(new AdsPreferences(activity).getAppsHeadline());
        ((AppCompatTextView) Objects.requireNonNull(adView.getBodyView())).setText(new AdsPreferences(activity).getAppsBody());
        ((AppCompatTextView) Objects.requireNonNull(adView.getAdvertiserView())).setVisibility(View.GONE);

        adView.getHeadlineView().setOnClickListener(this);
        adView.getBodyView().setOnClickListener(this);
        adView.getIconView().setOnClickListener(this);
//        adView.getImageView().setOnClickListener(this);
        adView.getAdvertiserView().setOnClickListener(this);
        Objects.requireNonNull(adView.getCallToActionView()).setOnClickListener(this);

    }


    //=============== Populate Loading View =======================
    //=============== Populate Loading View =======================

    public void populateLoadingViewShow(NativeAdView adView) {
        LinearLayout adContainer = adView.findViewById(R.id.adContainer);
        LinearLayout loadingContainer = adView.findViewById(R.id.loadingContainer);

        adContainer.setVisibility(View.GONE);
        loadingContainer.setVisibility(View.VISIBLE);
    }

    public void populateLoadingViewGone(NativeAdView adView) {
        LinearLayout adContainer = adView.findViewById(R.id.adContainer);
        LinearLayout loadingContainer = adView.findViewById(R.id.loadingContainer);

        adContainer.setVisibility(View.VISIBLE);
        loadingContainer.setVisibility(View.GONE);
    }


    //=============== Apps Ad Click Listener =======================
    //=============== Apps Ad Click Listener =======================

    @Override
    public void onClick(View view) {
        try {
            if (view.getId() == R.id.apps_mediaImage || view.getId() == R.id.apps_app_icon || view.getId() == R.id.apps_headline || view.getId() == R.id.apps_advertiser || view.getId() == R.id.apps_body || view.getId() == R.id.apps_call_to_action) {
                try {
                    activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + new AdsPreferences(activity).getAppsLink())));
                } catch (ActivityNotFoundException unused) {
                    activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + new AdsPreferences(activity).getAppsLink())));
                }
            }
        } catch (ActivityNotFoundException | NullPointerException e) {
            e.printStackTrace();
        }
    }

    public Integer getRandomLay() {
        return new Random().nextInt(4);
    }

}
