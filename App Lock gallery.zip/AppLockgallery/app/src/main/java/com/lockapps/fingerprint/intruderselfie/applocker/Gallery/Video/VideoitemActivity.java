package com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Video;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.app_open_ad.AOM_Activity;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.OnAdCallBack;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.internet.NetworkConnection;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.InterstitialAdManager;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager.NativeAdManager;
import com.lockapps.fingerprint.intruderselfie.applocker.galleryVideoitemClickListener;

import java.util.ArrayList;

public class VideoitemActivity extends AppCompatActivity implements galleryVideoitemClickListener {

    RecyclerView recyclerView;
    ArrayList<VideoItemModel> model = new ArrayList<>();
    String foldePath;
    int po;

    TextView foldername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videoitem);

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(getResources().getColor(R.color.darkcolor));
        }

        new NativeAdManager(this).show_NativeBannerAds(this.findViewById(R.id.apps_FrameLayout),
                this.findViewById(R.id.ad_FrameLayout), this.findViewById(R.id.applovin_FrameLayout), this.findViewById(R.id.nativeAdLayout),
                this.findViewById(R.id.ad_loading));

        new NativeAdManager(this).show_NativeBottomFlag(this.findViewById(R.id.bapps_FrameLayout),
                this.findViewById(R.id.bad_FrameLayout), this.findViewById(R.id.bapplovin_FrameLayout), this.findViewById(R.id.bnativeAdLayout),
                this.findViewById(R.id.bad_loading));

        foldePath = getIntent().getStringExtra("folderPath");

        foldername =findViewById(R.id.foldername);
        foldername.setText(getIntent().getStringExtra("foldername"));

        recyclerView = findViewById(R.id.rvvideoitem);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerView.hasFixedSize();
    }
    @Override
    protected void onResume() {
        new NetworkConnection().callNetworkConnection(this);
        new AOM_Activity().showAppOpenAdsActivity(this);
        model = getAllImagesByFolder(foldePath);
        recyclerView.setAdapter(new VideoItemAdapter(model, this,this));
        super.onResume();
    }

    public ArrayList<VideoItemModel> getAllImagesByFolder(String path) {
        ArrayList<VideoItemModel> videos = new ArrayList<>();
        Uri allVideosuri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Video.VideoColumns.DATA,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.SIZE};
        Cursor cursor = VideoitemActivity.this.getContentResolver().query(allVideosuri, projection, MediaStore.Video.Media.DATA + " like ? ", new String[]{"%" + path + "%"}, null);
        try {
            cursor.moveToFirst();
            do {
                VideoItemModel pic = new VideoItemModel();

                pic.setPicturName(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)));

                pic.setPicturePath(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)));

                pic.setPictureSize(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)));

                videos.add(pic);
            } while (cursor.moveToNext());
            cursor.close();
            ArrayList<VideoItemModel> reSelection = new ArrayList<>();
            for (int i = videos.size() - 1; i > -1; i--) {
                reSelection.add(videos.get(i));
            }
            videos = reSelection;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return videos;
    }

    @Override
    public void onPicClicked(VideoItemAdapter.PicHolder holder, int position, ArrayList<VideoItemModel> pics) {

        new InterstitialAdManager(this).loadInterstitialAll(new OnAdCallBack() {
            @Override
            public void onAdDismiss() {
                po = holder.getAdapterPosition();
                Intent intent = new Intent(VideoitemActivity.this, VideoviewPagerActivity.class);
                Bundle args = new Bundle();
                args.putParcelableArrayList("arrayP", model);
                intent.putExtra("po", String.valueOf(po));
                intent.putExtras(args);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onPicClicked(String pictureFolderPath, String folderName) {

    }
    public void back(View view) {
        onBackPressed();
    }
    @Override
    public void onBackPressed() {
        if (new AdsPreferences(this).getAdsOnback()) {
            new InterstitialAdManager(this).loadInterstitialAll(new OnAdCallBack() {
                @Override
                public void onAdDismiss() {
                    onBack();
                }
            });
        } else {
            onBack();
        }
    }

    public void onBack() {
        super.onBackPressed();
        CommonData.aom_adCount = 0;
    }
}