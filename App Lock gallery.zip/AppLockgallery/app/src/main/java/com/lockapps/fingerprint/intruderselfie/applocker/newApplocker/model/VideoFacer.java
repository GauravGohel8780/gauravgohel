package com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.model;

import android.os.Parcel;
import android.os.Parcelable;

public class VideoFacer implements Parcelable {

    private String VideoName;
    private String VideoPath;
    private  String VideoSize;
    private  String imageUri;
    private Boolean selected = false;

    public VideoFacer(){ }

    public VideoFacer(String videoName, String videoPath, String videoSize, String imageUri, Boolean selected) {
        VideoName = videoName;
        VideoPath = videoPath;
        VideoSize = videoSize;
        this.imageUri = imageUri;
        this.selected = selected;
    }

    protected VideoFacer(Parcel in) {
        VideoName = in.readString();
        VideoPath = in.readString();
        VideoSize = in.readString();
        imageUri = in.readString();
        byte tmpSelected = in.readByte();
        selected = tmpSelected == 0 ? null : tmpSelected == 1;
    }

    public static final Creator<VideoFacer> CREATOR = new Creator<VideoFacer>() {
        @Override
        public VideoFacer createFromParcel(Parcel in) {
            return new VideoFacer(in);
        }

        @Override
        public VideoFacer[] newArray(int size) {
            return new VideoFacer[size];
        }
    };

    public String getVideoName() {
        return VideoName;
    }

    public void setVideoName(String videoName) {
        VideoName = videoName;
    }

    public String getVideoPath() {
        return VideoPath;
    }

    public void setVideoPath(String videoPath) {
        VideoPath = videoPath;
    }

    public String getVideoSize() {
        return VideoSize;
    }

    public void setVideoSize(String videoSize) {
        VideoSize = videoSize;
    }

    public String getImageUri() {
        return imageUri;
    }

    public void setImageUri(String imageUri) {
        this.imageUri = imageUri;
    }

    public Boolean getSelected() {
        return selected;
    }

    public void setSelected(Boolean selected) {
        this.selected = selected;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(VideoName);
        parcel.writeString(VideoPath);
        parcel.writeString(VideoSize);
        parcel.writeString(imageUri);
        parcel.writeByte((byte) (selected == null ? 0 : selected ? 1 : 2));
    }
}
