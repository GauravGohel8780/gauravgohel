package com.lockapps.fingerprint.intruderselfie.applocker.Activities;

import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.BaseColumns;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import com.lockapps.fingerprint.intruderselfie.applocker.IntruderModel;
import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.StoreAppDatabase;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.app_open_ad.AOM_Activity;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonData;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.OnAdCallBack;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.internet.NetworkConnection;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.interstitial_ads_manager.InterstitialAdManager;
import com.lockapps.fingerprint.intruderselfie.applocker.newApplocker.adapters.IntruderPagerAdapter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class IntruderPager extends AppCompatActivity {

    ArrayList<IntruderModel> allImages = new ArrayList<>();

    ViewPager intruderPager;
    IntruderPagerAdapter intruderPagerAdapter;
    ImageView Share, Delete;
    IntruderModel model;
    TextView appName;
    TextView appTime;
    ImageView appIcon;


    StoreAppDatabase g;
    String imageUrl;

    public static final int DELETE_REQUEST_CODE = 13;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intruder_pager);
        g = new StoreAppDatabase(this);

        Share = (ImageView) findViewById(R.id.Share);
        Delete = (ImageView) findViewById(R.id.Delete);

        appName = (TextView) findViewById(R.id.appName);
        appTime = (TextView) findViewById(R.id.appTime);
        appIcon = (ImageView) findViewById(R.id.appIcon);


        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.black));

        Bundle bundle = getIntent().getExtras();

        int position = bundle.getInt("position");

            allImages = getIntent().getExtras().getParcelableArrayList("arrayPosition");

        intruderPager = (ViewPager) findViewById(R.id.imagePager);
        intruderPagerAdapter = new IntruderPagerAdapter(this, allImages);
        intruderPager.setAdapter(intruderPagerAdapter);
        intruderPager.setCurrentItem(position);

        model = (IntruderModel) allImages.get(position);

        appName.setText(model.getAppName());
        appTime.setText(model.getAppTime());

        byte[] image = model.getAppIcon();
        Bitmap bitmap = BitmapFactory.decodeByteArray(image, 0, image.length);
        appIcon.setImageBitmap(bitmap);

        intruderPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                model = (IntruderModel) allImages.get(position);

                appName.setText(model.getAppName());
                appTime.setText(model.getAppTime());

                byte[] image = model.getAppIcon();
                Bitmap bitmap = BitmapFactory.decodeByteArray(image, 0, image.length);
                appIcon.setImageBitmap(bitmap);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        Share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String path = Environment.getExternalStorageDirectory().getPath() + "/Pictures/iSelfie/" + model.getAppImage();
                Uri imageUri = Uri.parse(path);
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("image/png");

                intent.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(intent, "Share"));
            }
        });

        Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder alert = new AlertDialog.Builder(IntruderPager.this);
                alert.setTitle("Delete Photo");
                alert.setMessage("Are you sure you want to delete?");
                alert.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String path = Environment.getExternalStorageDirectory().getPath() + "/Pictures/iSelfie/" + model.getAppImage();
                        if (g.deleteTitle(model.getAppImage())) {
                            List<Uri> pathuri = new ArrayList<>();
                            Uri Uri_one = ContentUris.withAppendedId(MediaStore.Images.Media.getContentUri("external"), getFilePathToMediaID(path, IntruderPager.this));
                            pathuri.add(Uri_one);
                            requestDeletePermission(pathuri);
                        }
                    }
                });
                alert.setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                alert.show();
            }
        });


    }


    private void requestDeletePermission(List<Uri> pathuri) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            PendingIntent pi = MediaStore.createDeleteRequest(getContentResolver(), pathuri);
            try {
                startIntentSenderForResult(pi.getIntentSender(), 100, null, 0, 0, 0);
            } catch (IntentSender.SendIntentException e) {
            }
        }
    }

    private long getFilePathToMediaID(String path, IntruderPager intruderPager) {
        long id = 0;
        ContentResolver cr = getContentResolver();

        Uri uri = MediaStore.Files.getContentUri("external");
        String selection = MediaStore.Audio.Media.DATA;
        String[] selectionArgs = {path};
        String[] projection = {MediaStore.Audio.Media._ID};
        String sortOrder = MediaStore.Audio.Media.TITLE + " ASC";

        Cursor cursor = cr.query(uri, projection, selection + "=?", selectionArgs, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int idIndex = cursor.getColumnIndex(MediaStore.Audio.Media._ID);
                id = Long.parseLong(cursor.getString(idIndex));
            }
        }

        return id;
    }


    public static int deleteAPI28(Uri uri, Context context) {
        ContentResolver resolver = context.getContentResolver();
        return resolver.delete(uri, null, null);
    }

    private void deleteAPI30(Uri imageUri) throws IntentSender.SendIntentException {
        ContentResolver contentResolver = getContentResolver();
        // API 30

        List<Uri> uriList = new ArrayList<>();
        Collections.addAll(uriList, imageUri);
        PendingIntent pendingIntent = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            pendingIntent = MediaStore.createDeleteRequest(contentResolver, uriList);
        }
        ((this)).startIntentSenderForResult(pendingIntent.getIntentSender(),
                DELETE_REQUEST_CODE, null, 0,
                0, 0, null);

    }

    private Uri getContentUriId(Uri imageUri) {
        String[] projections = {MediaStore.MediaColumns._ID};
        Cursor cursor = getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projections,
                MediaStore.MediaColumns.DATA + "=?",
                new String[]{imageUri.getPath()}, null);
        long id = 0;
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                id = cursor.getLong(cursor.getColumnIndexOrThrow(BaseColumns._ID));
            }
        }
        cursor.close();
        return Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, String.valueOf((int) id));
    }

    @Override
    protected void onResume() {
        super.onResume();
        new NetworkConnection().callNetworkConnection(this);
        new AOM_Activity().showAppOpenAdsActivity(this);
    }

    @Override
    public void onBackPressed() {
        if (new AdsPreferences(this).getAdsOnback()) {
            new InterstitialAdManager(this).loadInterstitialAll(new OnAdCallBack() {
                @Override
                public void onAdDismiss() {
                    onBack();
                }
            });
        } else {
            onBack();
        }
    }

    public void onBack() {
        super.onBackPressed();
        CommonData.aom_adCount = 0;
    }
    //    @Override
//    public void onBackPressed() {
//        startActivity(new Intent(this, IntruderSelfie.class));
//    }
}