package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.server;

import android.app.Activity;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.IBinder;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;


import androidx.annotation.NonNull;

import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;

import unified.vpn.sdk.Callback;
import unified.vpn.sdk.ClientInfo;
import unified.vpn.sdk.CompletableCallback;
import unified.vpn.sdk.TrackingConstants;
import unified.vpn.sdk.UnifiedSdk;
import unified.vpn.sdk.VpnException;
import unified.vpn.sdk.VpnState;

public class OnClearFromRecentService extends Service {

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("ClearFromRecentService", "Service Started");
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("ClearFromRecentService", "Service Destroyed");
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        Network[] networks = cm.getAllNetworks();
        boolean is_vpn_connect = false;

        for (int i = 0; i < networks.length; i++) {
            NetworkCapabilities caps = cm.getNetworkCapabilities(networks[i]);
            Log.i("Xxxxx", "Network " + i + ": " + networks[i].toString());
            Log.i("Xxxxx", "VPN transport is: " + caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN));
            Log.i("Xxxxx", "NOT_VPN capability is: " + caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN));
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                is_vpn_connect = true;
            }
        }

        if (new AdsPreferences(this).getServerFlag() && is_vpn_connect) {
            Log.i("Xxxxx", "onTaskRemoved: " + new AdsPreferences(this).getServerFlag() + " : " + is_vpn_connect);
            UnifiedSdk.getInstance().getVpn().stop(TrackingConstants.GprReasons.M_UI, new CompletableCallback() {
                @Override
                public void complete() {
                }

                @Override
                public void error(@NonNull VpnException e) {
                    e.printStackTrace();
                }
            });
        }

        stopSelf();
        try {
            Thread.sleep(1500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        super.onTaskRemoved(rootIntent);
    }

}