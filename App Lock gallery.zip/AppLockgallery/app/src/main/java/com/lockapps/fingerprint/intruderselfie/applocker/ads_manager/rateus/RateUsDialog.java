package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.rateus;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.cardview.widget.CardView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.common_class.CommonAppMethodes;

public class RateUsDialog {

    Activity activity;

    public RateUsDialog(Activity activity) {
        this.activity = activity;
    }

    public void ShowRateUsDialog(int type) {
        if (type == 1) {
            ShowRatingDialog();
        } else {
            ShowRatingBottomSheet();
        }
    }

    public void ShowRatingDialog() {

        Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setContentView(R.layout.rate_us_dialog);
        dialog.setCancelable(true);
        Window window = dialog.getWindow();
        WindowManager.LayoutParams attributes = window.getAttributes();
        attributes.gravity = Gravity.CENTER;
        window.setAttributes(attributes);

        dialog.show();

        CardView rateUsCard = dialog.findViewById(R.id.rateUsCard);
        CardView exitCard = dialog.findViewById(R.id.exitCard);
        RatingBar ratingBar = dialog.findViewById(R.id.ratingBar);
        ImageView rating_emoji = dialog.findViewById(R.id.rating_emoji);

        rateUsCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new CommonAppMethodes(activity).RateApp();
            }
        });

        exitCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.finishAffinity();
                System.exit(0);
            }
        });

        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if (rating <= 1) {
                    rating_emoji.setImageResource(R.drawable.rateus_one_star);
                } else if (rating <= 2) {
                    rating_emoji.setImageResource(R.drawable.rateus_two_star);
                } else if (rating <= 3) {
                    rating_emoji.setImageResource(R.drawable.rateus_three_star);
                } else if (rating <= 4) {
                    rating_emoji.setImageResource(R.drawable.rateus_four_star);
                } else if (rating <= 5) {
                    rating_emoji.setImageResource(R.drawable.rateus_five_star);
                }

                animateImage(rating_emoji);

            }
        });
    }

    public void ShowRatingBottomSheet() {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(activity, R.style.BottomSheetDialogTheme);
        View view = LayoutInflater.from(activity).inflate(R.layout.rate_us_dialog, (ViewGroup) null);

        CardView rateUsCard = view.findViewById(R.id.rateUsCard);
        CardView exitCard = view.findViewById(R.id.exitCard);
        RatingBar ratingBar = view.findViewById(R.id.ratingBar);
        ImageView rating_emoji = view.findViewById(R.id.rating_emoji);

        rateUsCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new CommonAppMethodes(activity).RateApp();
            }
        });

        exitCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.finishAffinity();
                System.exit(0);
            }
        });

        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if (rating <= 1) {
                    rating_emoji.setImageResource(R.drawable.rateus_one_star);
                } else if (rating <= 2) {
                    rating_emoji.setImageResource(R.drawable.rateus_two_star);
                } else if (rating <= 3) {
                    rating_emoji.setImageResource(R.drawable.rateus_three_star);
                } else if (rating <= 4) {
                    rating_emoji.setImageResource(R.drawable.rateus_four_star);
                } else if (rating <= 5) {
                    rating_emoji.setImageResource(R.drawable.rateus_five_star);
                }

                animateImage(rating_emoji);

            }
        });
        bottomSheetDialog.setContentView(view);
        bottomSheetDialog.show();
    }


    private void animateImage(ImageView rating_emoji) {
        ScaleAnimation scaleAnimation = new ScaleAnimation(0,1f, 0,1f,
                Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);

        scaleAnimation.setFillAfter(true);
        scaleAnimation.setDuration(200);
        rating_emoji.startAnimation(scaleAnimation);
    }
}
