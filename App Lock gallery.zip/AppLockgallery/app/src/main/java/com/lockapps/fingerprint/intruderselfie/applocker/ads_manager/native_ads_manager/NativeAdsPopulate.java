package com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.native_ads_manager;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.graphics.drawable.DrawableCompat;

import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeBannerAd;
import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.ads_manager.data_model.AdsPreferences;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class NativeAdsPopulate {

    Activity activity;

    public NativeAdsPopulate(Activity activity) {
        this.activity = activity;
    }


    //=============== Populate Google Native Ads ===================
    //=============== Populate Google Native Ads ===================

    public void populateNativeMedia(com.google.android.gms.ads.nativead.NativeAd nativeAd, com.google.android.gms.ads.nativead.NativeAdView adView) {
        adView.setMediaView(adView.findViewById(R.id.ad_media));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));
        TextView ad_adAttribution = adView.findViewById(R.id.ad_adAttribution);

        // CallToAction Button Color
        if (new AdsPreferences(activity).getBtnColorFlag()) {
            Drawable tintDr = DrawableCompat.wrap(Objects.requireNonNull(adView.getCallToActionView()).getBackground());
            DrawableCompat.setTint(tintDr, Color.parseColor(new AdsPreferences(activity).getBtnColor()));
            adView.getCallToActionView().setBackground(tintDr);
        }

        Objects.requireNonNull(adView.getMediaView()).setMediaContent(Objects.requireNonNull(nativeAd.getMediaContent()));


        if (nativeAd.getHeadline() == null) {
            adView.getHeadlineView().setVisibility(View.INVISIBLE);
        } else {
            adView.getHeadlineView().setVisibility(View.VISIBLE);
            ad_adAttribution.setVisibility(View.VISIBLE);
            ((AppCompatTextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        }

        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((AppCompatTextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((AppCompatButton) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        //   HideAds: Icon
        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            adView.getIconView().setVisibility(View.VISIBLE);
            ((AppCompatImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.GONE);
        } else {
            ((AppCompatTextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);
        com.google.android.gms.ads.VideoController vc = nativeAd.getMediaContent().getVideoController();
        if (vc.hasVideoContent()) {
            vc.setVideoLifecycleCallbacks(new com.google.android.gms.ads.VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        }
    }

    public void populateNativeBannerMedia(com.google.android.gms.ads.nativead.NativeAd nativeAd, com.google.android.gms.ads.nativead.NativeAdView adView) {
        adView.setMediaView(adView.findViewById(R.id.ad_media));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
//        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));
        TextView ad_adAttribution = adView.findViewById(R.id.ad_adAttribution);

        // CallToAction Button Color
        if (new AdsPreferences(activity).getBtnColorFlag()) {
            Drawable tintDr = DrawableCompat.wrap(Objects.requireNonNull(adView.getCallToActionView()).getBackground());
            DrawableCompat.setTint(tintDr, Color.parseColor(new AdsPreferences(activity).getBtnColor()));
            adView.getCallToActionView().setBackground(tintDr);
        }

        Objects.requireNonNull(adView.getMediaView()).setMediaContent(Objects.requireNonNull(nativeAd.getMediaContent()));


        if (nativeAd.getHeadline() == null) {
            adView.getHeadlineView().setVisibility(View.INVISIBLE);
        } else {
            adView.getHeadlineView().setVisibility(View.VISIBLE);
            ad_adAttribution.setVisibility(View.VISIBLE);
            ((AppCompatTextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        }

        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((AppCompatTextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((AppCompatButton) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        //   HideAds: Icon
//        if (nativeAd.getIcon() == null) {
//            adView.getIconView().setVisibility(View.GONE);
//        } else {
//            adView.getIconView().setVisibility(View.VISIBLE);
//            ((AppCompatImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
//        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.GONE);
        } else {
            ((AppCompatTextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);
        com.google.android.gms.ads.VideoController vc = nativeAd.getMediaContent().getVideoController();
        if (vc.hasVideoContent()) {
            vc.setVideoLifecycleCallbacks(new com.google.android.gms.ads.VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        }
    }

    public void populateNativeNoMedia(com.google.android.gms.ads.nativead.NativeAd nativeAd, com.google.android.gms.ads.nativead.NativeAdView adView) {
//        adView.setMediaView(adView.findViewById(R.id.ad_media));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));
        TextView ad_adAttribution = adView.findViewById(R.id.ad_adAttribution);

        // CallToAction Button Color
        if (new AdsPreferences(activity).getBtnColorFlag()) {
            Drawable tintDr = DrawableCompat.wrap(Objects.requireNonNull(adView.getCallToActionView()).getBackground());
            DrawableCompat.setTint(tintDr, Color.parseColor(new AdsPreferences(activity).getBtnColor()));
            adView.getCallToActionView().setBackground(tintDr);
        }

//        Objects.requireNonNull(adView.getMediaView()).setMediaContent(Objects.requireNonNull(nativeAd.getMediaContent()));


        if (nativeAd.getHeadline() == null) {
            adView.getHeadlineView().setVisibility(View.INVISIBLE);
        } else {
            adView.getHeadlineView().setVisibility(View.VISIBLE);
            ad_adAttribution.setVisibility(View.VISIBLE);
            ((AppCompatTextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        }

        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((AppCompatTextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((AppCompatButton) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        //   HideAds: Icon
        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            adView.getIconView().setVisibility(View.VISIBLE);
            ((AppCompatImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.GONE);
        } else {
            ((AppCompatTextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.GONE);
        }


        adView.setNativeAd(nativeAd);
        com.google.android.gms.ads.VideoController vc = nativeAd.getMediaContent().getVideoController();
        if (vc.hasVideoContent()) {
            vc.setVideoLifecycleCallbacks(new com.google.android.gms.ads.VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        }
    }


    //=============== Populate Facebook Native Ads ===================
    //=============== Populate Facebook Native Ads ===================

    public void inflateFbNative(NativeAd nativeAd, NativeAdLayout nativeAdLayout, LinearLayout adView) {
        nativeAd.unregisterView();

        nativeAdLayout.removeAllViews();
        nativeAdLayout.addView(adView);

        LinearLayout adChoicesContainer = adView.findViewById(R.id.ad_choices_container);
        com.facebook.ads.AdOptionsView adOptionsView = new com.facebook.ads.AdOptionsView(activity, nativeAd, nativeAdLayout);
        adChoicesContainer.removeAllViews();

        MediaView nativeAdIcon = adView.findViewById(R.id.native_ad_icon);
        TextView nativeAdTitle = adView.findViewById(R.id.native_ad_title);
        MediaView nativeAdMedia = adView.findViewById(R.id.native_ad_media);
        TextView nativeAdSocialContext = adView.findViewById(R.id.native_ad_social_context);
        TextView nativeAdBody = adView.findViewById(R.id.native_ad_body);
        TextView sponsoredLabel = adView.findViewById(R.id.native_ad_sponsored_label);
        Button nativeAdCallToAction = adView.findViewById(R.id.native_ad_call_to_action);

        if (new AdsPreferences(activity).getBtnColorFlag()) {
            Drawable tintDr = DrawableCompat.wrap(nativeAdCallToAction.getBackground());
            DrawableCompat.setTint(tintDr, Color.parseColor(new AdsPreferences(activity).getBtnColor()));
            nativeAdCallToAction.setBackground(tintDr);
        }

        if (nativeAdTitle == null) {
            nativeAdTitle.setVisibility(View.INVISIBLE);
        } else {
            nativeAdTitle.setVisibility(View.VISIBLE);
            adChoicesContainer.addView(adOptionsView, 0);
            nativeAdTitle.setText(nativeAd.getAdvertiserName());
        }

        nativeAdBody.setText(nativeAd.getAdBodyText());
        nativeAdSocialContext.setText(nativeAd.getAdSocialContext());
        nativeAdCallToAction.setVisibility(nativeAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
        nativeAdCallToAction.setText(nativeAd.getAdCallToAction());
        sponsoredLabel.setText(nativeAd.getSponsoredTranslation());
//        sponsoredLabel.setVisibility(View.GONE);

        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(nativeAdTitle);
        clickableViews.add(nativeAdCallToAction);

        nativeAd.registerViewForInteraction(adView, nativeAdMedia, nativeAdIcon, clickableViews);
    }

    public void inflateFbNativeBanner(NativeAd nativeAd, NativeAdLayout nativeAdLayout, LinearLayout adView) {
        nativeAd.unregisterView();

        nativeAdLayout.removeAllViews();
        nativeAdLayout.addView(adView);

        LinearLayout adChoicesContainer = adView.findViewById(R.id.ad_choices_container);
        com.facebook.ads.AdOptionsView adOptionsView = new com.facebook.ads.AdOptionsView(activity, nativeAd, nativeAdLayout);
        adChoicesContainer.removeAllViews();

        MediaView nativeAdIcon = adView.findViewById(R.id.native_ad_icon);
        TextView nativeAdTitle = adView.findViewById(R.id.native_ad_title);
        MediaView nativeAdMedia = adView.findViewById(R.id.native_ad_media);
        TextView nativeAdSocialContext = adView.findViewById(R.id.native_ad_social_context);
        TextView nativeAdBody = adView.findViewById(R.id.native_ad_body);
        TextView sponsoredLabel = adView.findViewById(R.id.native_ad_sponsored_label);
        Button nativeAdCallToAction = adView.findViewById(R.id.native_ad_call_to_action);

        if (new AdsPreferences(activity).getBtnColorFlag()) {
            Drawable tintDr = DrawableCompat.wrap(nativeAdCallToAction.getBackground());
            DrawableCompat.setTint(tintDr, Color.parseColor(new AdsPreferences(activity).getBtnColor()));
            nativeAdCallToAction.setBackground(tintDr);
        }

        if (nativeAdTitle == null) {
            nativeAdTitle.setVisibility(View.INVISIBLE);
        } else {
            nativeAdTitle.setVisibility(View.VISIBLE);
            adChoicesContainer.addView(adOptionsView, 0);
            nativeAdTitle.setText(nativeAd.getAdvertiserName());
        }

        nativeAdBody.setText(nativeAd.getAdBodyText());
        nativeAdSocialContext.setText(nativeAd.getAdSocialContext());
        nativeAdCallToAction.setVisibility(nativeAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
        nativeAdCallToAction.setText(nativeAd.getAdCallToAction());
        sponsoredLabel.setText(nativeAd.getSponsoredTranslation());
//        sponsoredLabel.setVisibility(View.GONE);

        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(nativeAdTitle);
        clickableViews.add(nativeAdCallToAction);

        nativeAd.registerViewForInteraction(adView, nativeAdMedia, nativeAdIcon, clickableViews);
    }

    public void inflateFbNativeBannerMid(NativeBannerAd nativeBannerAd, NativeAdLayout nativeAdLayout, LinearLayout adView) {
        nativeBannerAd.unregisterView();

//        LayoutInflater inflater = LayoutInflater.from(activity);
//        LinearLayout adView = (LinearLayout) inflater.inflate(R.layout.fb_native_bottom_banner, nativeAdLayout, false);
        nativeAdLayout.removeAllViews();
        nativeAdLayout.addView(adView);

        LinearLayout adChoicesContainer = adView.findViewById(R.id.ad_choices_container);
        com.facebook.ads.AdOptionsView adOptionsView = new com.facebook.ads.AdOptionsView(activity, nativeBannerAd, nativeAdLayout);
        adChoicesContainer.removeAllViews();

        TextView nativeAdTitle = adView.findViewById(R.id.native_ad_title);
        TextView nativeAdSocialContext = adView.findViewById(R.id.native_ad_social_context);
        TextView sponsoredLabel = adView.findViewById(R.id.native_ad_sponsored_label);
        MediaView nativeAdIconView = adView.findViewById(R.id.native_icon_view);
        Button nativeAdCallToAction = adView.findViewById(R.id.native_ad_call_to_action);

        if (new AdsPreferences(activity).getBtnColorFlag()) {
            Drawable tintDr = DrawableCompat.wrap(nativeAdCallToAction.getBackground());
            DrawableCompat.setTint(tintDr, Color.parseColor(new AdsPreferences(activity).getBtnColor()));
            nativeAdCallToAction.setBackground(tintDr);
        }

        if (nativeAdTitle == null) {
            nativeAdTitle.setVisibility(View.INVISIBLE);
        } else {
            nativeAdTitle.setVisibility(View.VISIBLE);
            adChoicesContainer.addView(adOptionsView, 0);
            nativeAdTitle.setText(nativeBannerAd.getAdvertiserName());
        }

        nativeAdCallToAction.setText(nativeBannerAd.getAdCallToAction());
        nativeAdCallToAction.setVisibility(nativeBannerAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
        nativeAdTitle.setText(nativeBannerAd.getAdvertiserName());
        nativeAdSocialContext.setText(nativeBannerAd.getAdSocialContext());
        sponsoredLabel.setText(nativeBannerAd.getSponsoredTranslation());
//        sponsoredLabel.setVisibility(View.GONE);

        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(nativeAdTitle);
        clickableViews.add(nativeAdCallToAction);

        nativeBannerAd.registerViewForInteraction(adView, nativeAdIconView, clickableViews);
    }

    public void inflateFbNativeBottomBanner(NativeBannerAd nativeBannerAd, NativeAdLayout nativeAdLayout, LinearLayout adView) {
        nativeBannerAd.unregisterView();

//        LayoutInflater inflater = LayoutInflater.from(activity);
//        LinearLayout adView = (LinearLayout) inflater.inflate(R.layout.fb_native_bottom_banner, nativeAdLayout, false);
        nativeAdLayout.removeAllViews();
        nativeAdLayout.addView(adView);

        LinearLayout adChoicesContainer = adView.findViewById(R.id.ad_choices_container);
        com.facebook.ads.AdOptionsView adOptionsView = new com.facebook.ads.AdOptionsView(activity, nativeBannerAd, nativeAdLayout);
        adChoicesContainer.removeAllViews();

        TextView nativeAdTitle = adView.findViewById(R.id.native_ad_title);
        TextView nativeAdSocialContext = adView.findViewById(R.id.native_ad_social_context);
        TextView sponsoredLabel = adView.findViewById(R.id.native_ad_sponsored_label);
        MediaView nativeAdIconView = adView.findViewById(R.id.native_icon_view);
        Button nativeAdCallToAction = adView.findViewById(R.id.native_ad_call_to_action);


        if (new AdsPreferences(activity).getBtnColorFlag()) {
            Drawable tintDr = DrawableCompat.wrap(nativeAdCallToAction.getBackground());
            DrawableCompat.setTint(tintDr, Color.parseColor(new AdsPreferences(activity).getBtnColor()));
            nativeAdCallToAction.setBackground(tintDr);
        }

        if (nativeAdTitle == null) {
            nativeAdTitle.setVisibility(View.INVISIBLE);
        } else {
            nativeAdTitle.setVisibility(View.VISIBLE);
            adChoicesContainer.addView(adOptionsView, 0);
            nativeAdTitle.setText(nativeBannerAd.getAdvertiserName());
        }

        nativeAdCallToAction.setText(nativeBannerAd.getAdCallToAction());
        nativeAdCallToAction.setVisibility(nativeBannerAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
        nativeAdTitle.setText(nativeBannerAd.getAdvertiserName());
        nativeAdSocialContext.setText(nativeBannerAd.getAdSocialContext());
        sponsoredLabel.setText(nativeBannerAd.getSponsoredTranslation());
//        sponsoredLabel.setVisibility(View.GONE);

        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(nativeAdTitle);
        clickableViews.add(nativeAdCallToAction);

        nativeBannerAd.registerViewForInteraction(adView, nativeAdIconView, clickableViews);
    }


}
