package com.lockapps.fingerprint.intruderselfie.applocker.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;

import com.lockapps.fingerprint.intruderselfie.applocker.ItemClickListener;
import com.lockapps.fingerprint.intruderselfie.applocker.R;

public class Finger extends Fragment {

    AppCompatButton ok,cancel;
    ItemClickListener itemClickListener;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_finger, container, false);

        ok = view.findViewById(R.id.ok);
        cancel = view.findViewById(R.id.cancel);

        itemClickListener = (ItemClickListener) getActivity();


        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                itemClickListener.onItemClicked("pattern");
            }
        });

        return view;
    }
}