package com.lockapps.fingerprint.intruderselfie.applocker.Gallery.Video;


import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.lockapps.fingerprint.intruderselfie.applocker.R;
import com.lockapps.fingerprint.intruderselfie.applocker.galleryVideoitemClickListener;

import java.util.ArrayList;

public class VideoItemAdapter extends RecyclerView.Adapter<VideoItemAdapter.PicHolder> {

    ArrayList<VideoItemModel> pictureList;
    Context pictureContx;
    galleryVideoitemClickListener picListerner;

    public VideoItemAdapter(ArrayList<VideoItemModel> pictureList, Context pictureContx, galleryVideoitemClickListener picListerner) {
        this.pictureList = pictureList;
        this.pictureContx = pictureContx;
        this.picListerner = picListerner;
    }

    @NonNull
    @Override
    public PicHolder onCreateViewHolder(@NonNull ViewGroup container, int position) {
        LayoutInflater inflater = LayoutInflater.from(container.getContext());
        View view = inflater.inflate(R.layout.videoitemlayout, container, false);
        return new PicHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final PicHolder holder, @SuppressLint("RecyclerView") final int position) {
        VideoItemModel model = pictureList.get(position);

        Glide.with(pictureContx)
                .load(model.getPicturePath())
                .into(holder.picture);

//        setTransitionName(holder.picture, position + "_image");

        holder.tvname.setText(model.getPicturName());
        holder.tvname.setSelected(true);

        holder.picture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    picListerner.onPicClicked(holder,position, pictureList);
            }
        });
    }

    @Override
    public int getItemCount() {
        return pictureList.size();
    }

    public class PicHolder extends RecyclerView.ViewHolder {

        ImageView picture;
        TextView tvname;

        public PicHolder(@NonNull View itemView) {
            super(itemView);

            picture = itemView.findViewById(R.id.folderphoto);
            tvname = itemView.findViewById(R.id.tvname);
        }
    }
}