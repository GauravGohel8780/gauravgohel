package com.iten.tenoku.ad.HandleClick;

public interface HandleRewardedAd {
    void Show(boolean adShow);
}
