package com.cricketapp.livecricket.livescore.Auction.ActionModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AuctionDitail {

    @SerializedName("sold")
    @Expose
    private Sold sold;
    @SerializedName("unsold")
    @Expose
    private Unsold unsold;

    public Sold getSold() {
        return sold;
    }

    public void setSold(Sold sold) {
        this.sold = sold;
    }

    public Unsold getUnsold() {
        return unsold;
    }

    public void setUnsold(Unsold unsold) {
        this.unsold = unsold;
    }

}
