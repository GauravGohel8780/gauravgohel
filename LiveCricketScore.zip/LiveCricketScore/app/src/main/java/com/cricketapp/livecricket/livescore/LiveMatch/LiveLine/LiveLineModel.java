package com.cricketapp.livecricket.livescore.LiveMatch.LiveLine;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LiveLineModel {

    @SerializedName("batsman")
    @Expose
    private String batsman;
    @SerializedName("s4")
    @Expose
    private String s4;
    @SerializedName("s6")
    @Expose
    private String s6;
    @SerializedName("ns4")
    @Expose
    private String ns4;
    @SerializedName("ns6")
    @Expose
    private String ns6;
    @SerializedName("oversA")
    @Expose
    private String oversA;
    @SerializedName("oversB")
    @Expose
    private String oversB;
    @SerializedName("bowler")
    @Expose
    private String bowler;
    @SerializedName("title")
    @Expose
    private String title;

    public String getBatsman() {
        return batsman;
    }

    public void setBatsman(String batsman) {
        this.batsman = batsman;
    }

    public String getS4() {
        return s4;
    }

    public void setS4(String s4) {
        this.s4 = s4;
    }

    public String getS6() {
        return s6;
    }

    public void setS6(String s6) {
        this.s6 = s6;
    }

    public String getNs4() {
        return ns4;
    }

    public void setNs4(String ns4) {
        this.ns4 = ns4;
    }

    public String getNs6() {
        return ns6;
    }

    public void setNs6(String ns6) {
        this.ns6 = ns6;
    }

    public String getOversA() {
        return oversA;
    }

    public void setOversA(String oversA) {
        this.oversA = oversA;
    }

    public String getOversB() {
        return oversB;
    }

    public void setOversB(String oversB) {
        this.oversB = oversB;
    }

    public String getBowler() {
        return bowler;
    }

    public void setBowler(String bowler) {
        this.bowler = bowler;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
