package com.cricketapp.livecricket.livescore.IPLList;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ObjPurpleCap {
    @SerializedName("vPlayerName")
    @Expose
    private String vPlayerName;
    @SerializedName("vTeam")
    @Expose
    private String vTeam;
    @SerializedName("iMatches")
    @Expose
    private Integer iMatches;
    @SerializedName("iWickets")
    @Expose
    private Integer iWickets;

    public String getvPlayerName() {
        return vPlayerName;
    }

    public void setvPlayerName(String vPlayerName) {
        this.vPlayerName = vPlayerName;
    }

    public String getvTeam() {
        return vTeam;
    }

    public void setvTeam(String vTeam) {
        this.vTeam = vTeam;
    }

    public Integer getiMatches() {
        return iMatches;
    }

    public void setiMatches(Integer iMatches) {
        this.iMatches = iMatches;
    }

    public Integer getiWickets() {
        return iWickets;
    }

    public void setiWickets(Integer iWickets) {
        this.iWickets = iWickets;
    }
}
