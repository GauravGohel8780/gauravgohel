package com.cricketapp.livecricket.livescore.LiveMatch.ScoreCard;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cricketapp.livecricket.livescore.R;
import com.cricketapp.livecricket.livescore.utils.ApiService;
import com.cricketapp.livecricket.livescore.utils.RetrofitClient;
import com.google.android.material.tabs.TabLayout;

import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ScoreCradFragment extends Fragment {

    View v1, v2;
    RelativeLayout rl1, rl2;
    TextView txt1, txt2;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_score_crad, container, false);

        v1 = view.findViewById(R.id.v1);
        v2 = view.findViewById(R.id.v2);
        rl1 = view.findViewById(R.id.rl1);
        rl2 = view.findViewById(R.id.rl2);
        txt1 = view.findViewById(R.id.txt1);
        txt2 = view.findViewById(R.id.txt2);

        txt1.setSelected(true);
        txt2.setSelected(true);


        ApiService apiService = RetrofitClient.getApiService();
        Call<ScoreCardAipRespons> call = apiService.getScoreCardData(String.valueOf(requireActivity().getIntent().getIntExtra("LiveMatchId", 0)));
        call.enqueue(new Callback<ScoreCardAipRespons>() {
            @Override
            public void onResponse(Call<ScoreCardAipRespons> call, Response<ScoreCardAipRespons> response) {
                if (response.isSuccessful()) {
                    ScoreCardAipRespons scoreCardResponse = response.body();
                    ArrayList<ProgressModel> arrayList = scoreCardResponse.getData();

                    ArrayList<ProgressModel> teamAData = new ArrayList<>();
                    ArrayList<ProgressModel> teamBData = new ArrayList<>();


                    for (ProgressModel data : arrayList) {
                        if (data.getvTeamSide().equals("Team A")) {
                            teamAData.add(data);
                        } else if (data.getvTeamSide().equals("Team B")) {
                            teamBData.add(data);
                        }
                    }


                    for (ProgressModel data : teamAData) {
                        txt1.setText(""+data.getvTeamName()+" "+data.getvTeamRuns());
                    }

                    for (ProgressModel data : teamBData) {
                        txt2.setText(""+data.getvTeamName()+" "+data.getvTeamRuns());
                    }
                } else {
                    try {
                        Log.e("www", "Response not successful. Code: " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(Call<ScoreCardAipRespons> call, Throwable t) {
                Log.e("www", "Failed to fetch schedule details: " + t.getMessage());
            }
        });


        v1.setVisibility(View.VISIBLE);
        v2.setVisibility(View.GONE);
        loadFragment(new Progress1Fragment());
        rl1.setOnClickListener(v -> {
            v1.setVisibility(View.VISIBLE);
            v2.setVisibility(View.GONE);
            loadFragment(new Progress1Fragment());
        });
        rl2.setOnClickListener(v -> {

            v1.setVisibility(View.GONE);
            v2.setVisibility(View.VISIBLE);
            loadFragment(new Progress2Fragment());
        });

        return view;
    }

    private void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.flscorecard, fragment);
        transaction.commit();
    }
}