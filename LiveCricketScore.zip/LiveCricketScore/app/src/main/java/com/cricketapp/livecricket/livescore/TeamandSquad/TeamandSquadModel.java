package com.cricketapp.livecricket.livescore.TeamandSquad;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class TeamandSquadModel {

    @SerializedName("vTeameName")
    @Expose
    private String vTeameName;
    @SerializedName("vCoach")
    @Expose
    private String vCoach;
    @SerializedName("vOwner")
    @Expose
    private String vOwner;
    @SerializedName("vCaptain")
    @Expose
    private String vCaptain;
    @SerializedName("vImage")
    @Expose
    private String vImage;
    @SerializedName("arrTeamePlayer")
    @Expose
    private ArrayList<TeamandSquadDetailModel> arrTeamePlayer;

    public String getvTeameName() {
        return vTeameName;
    }

    public void setvTeameName(String vTeameName) {
        this.vTeameName = vTeameName;
    }

    public String getvCoach() {
        return vCoach;
    }

    public void setvCoach(String vCoach) {
        this.vCoach = vCoach;
    }

    public String getvOwner() {
        return vOwner;
    }

    public void setvOwner(String vOwner) {
        this.vOwner = vOwner;
    }

    public String getvCaptain() {
        return vCaptain;
    }

    public void setvCaptain(String vCaptain) {
        this.vCaptain = vCaptain;
    }

    public String getvImage() {
        return vImage;
    }

    public void setvImage(String vImage) {
        this.vImage = vImage;
    }

    public ArrayList<TeamandSquadDetailModel> getArrTeamePlayer() {
        return arrTeamePlayer;
    }

    public void setArrTeamePlayer(ArrayList<TeamandSquadDetailModel> arrTeamePlayer) {
        this.arrTeamePlayer = arrTeamePlayer;
    }

}
