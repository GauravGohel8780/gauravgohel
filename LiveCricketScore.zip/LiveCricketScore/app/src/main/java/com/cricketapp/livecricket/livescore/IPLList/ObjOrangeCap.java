package com.cricketapp.livecricket.livescore.IPLList;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ObjOrangeCap {
    @SerializedName("vPlayerName")
    @Expose
    private String vPlayerName;
    @SerializedName("iInnings")
    @Expose
    private Integer iInnings;
    @SerializedName("iRuns")
    @Expose
    private Integer iRuns;
    @SerializedName("iHighestScore")
    @Expose
    private Integer iHighestScore;
    @SerializedName("iAverage")
    @Expose
    private Double iAverage;
    @SerializedName("iStrikeRate")
    @Expose
    private Double iStrikeRate;
    @SerializedName("iFifty")
    @Expose
    private Integer iFifty;
    @SerializedName("iCenturies")
    @Expose
    private Integer iCenturies;
    @SerializedName("four")
    @Expose
    private Integer four;
    @SerializedName("sixes")
    @Expose
    private Integer sixes;

    public String getvPlayerName() {
        return vPlayerName;
    }

    public void setvPlayerName(String vPlayerName) {
        this.vPlayerName = vPlayerName;
    }

    public Integer getiInnings() {
        return iInnings;
    }

    public void setiInnings(Integer iInnings) {
        this.iInnings = iInnings;
    }

    public Integer getiRuns() {
        return iRuns;
    }

    public void setiRuns(Integer iRuns) {
        this.iRuns = iRuns;
    }

    public Integer getiHighestScore() {
        return iHighestScore;
    }

    public void setiHighestScore(Integer iHighestScore) {
        this.iHighestScore = iHighestScore;
    }

    public Double getiAverage() {
        return iAverage;
    }

    public void setiAverage(Double iAverage) {
        this.iAverage = iAverage;
    }

    public Double getiStrikeRate() {
        return iStrikeRate;
    }

    public void setiStrikeRate(Double iStrikeRate) {
        this.iStrikeRate = iStrikeRate;
    }

    public Integer getiFifty() {
        return iFifty;
    }

    public void setiFifty(Integer iFifty) {
        this.iFifty = iFifty;
    }

    public Integer getiCenturies() {
        return iCenturies;
    }

    public void setiCenturies(Integer iCenturies) {
        this.iCenturies = iCenturies;
    }

    public Integer getFour() {
        return four;
    }

    public void setFour(Integer four) {
        this.four = four;
    }

    public Integer getSixes() {
        return sixes;
    }

    public void setSixes(Integer sixes) {
        this.sixes = sixes;
    }
}
