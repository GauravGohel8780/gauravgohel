package com.cricketapp.livecricket.livescore.Auction.ActionModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class AuctionDitailModel {
    @SerializedName("vPlayerName")
    @Expose
    private String vPlayerName;
    @SerializedName("vBasePrice")
    @Expose
    private String vBasePrice;
    @SerializedName("vSellPrice")
    @Expose
    private String vSellPrice;
    @SerializedName("vTeam")
    @Expose
    private String vTeam;

    public String getvPlayerName() {
        return vPlayerName;
    }

    public void setvPlayerName(String vPlayerName) {
        this.vPlayerName = vPlayerName;
    }

    public String getvBasePrice() {
        return vBasePrice;
    }

    public void setvBasePrice(String vBasePrice) {
        this.vBasePrice = vBasePrice;
    }

    public String getvSellPrice() {
        return vSellPrice;
    }

    public void setvSellPrice(String vSellPrice) {
        this.vSellPrice = vSellPrice;
    }

    public String getvTeam() {
        return vTeam;
    }

    public void setvTeam(String vTeam) {
        this.vTeam = vTeam;
    }

}