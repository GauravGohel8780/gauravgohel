package com.cricketapp.livecricket.livescore.RecordCorner;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.cricketapp.livecricket.livescore.Ads_Common.AdsBaseActivity;
import com.cricketapp.livecricket.livescore.R;
import com.iten.tenoku.ad.AdShow;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdConstant;

import java.util.ArrayList;

public class RecordCornerDetailActivity extends AdsBaseActivity {

    RecyclerView rvRecordCorner;
    ArrayList<RecordCornerDetailModel> arrayList = new ArrayList<>();

    TextView tvScore;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_corner_detail);

//        AdsUtil.addCollapsibleBanner(this, findViewById(R.id.banner_view), AdConstant.adcollapsiblekey);

        AdShow.getInstance(this).ShowCollapseBanner(RecordCornerDetailActivity.this, findViewById(R.id.layout_ads));

        findViewById(R.id.ivBack).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);

        });

        tvScore = findViewById(R.id.tvScore);

        String intentRecordCorner = getIntent().getStringExtra("RecordCorner");

        if (intentRecordCorner.equals("MostRun")){
            tvScore.setText(R.string.mostrun);
            arrayList.add(new RecordCornerDetailModel(1, "chris Gayle", 337));
            arrayList.add(new RecordCornerDetailModel(2, "Rohit Sharma", 251));
            arrayList.add(new RecordCornerDetailModel(3, "MS Dhoni", 234));
            arrayList.add(new RecordCornerDetailModel(4, "Virat Kohli", 222));
            arrayList.add(new RecordCornerDetailModel(5, "Shane Watson", 205));
            arrayList.add(new RecordCornerDetailModel(6, "Robin Uthappa", 182));
            arrayList.add(new RecordCornerDetailModel(7, "David Warner", 160));
            arrayList.add(new RecordCornerDetailModel(8, "chris Gayle", 156));
            arrayList.add(new RecordCornerDetailModel(9, "Rohit Sharma", 192));
            arrayList.add(new RecordCornerDetailModel(10, "Virat Kohli", 201));
        }else if (intentRecordCorner.equals("MostSixes")){
            tvScore.setText(R.string.mostsixes);
            arrayList.add(new RecordCornerDetailModel(1, "chris Gayle", 337));
            arrayList.add(new RecordCornerDetailModel(2, "Rohit Sharma", 251));
            arrayList.add(new RecordCornerDetailModel(3, "MS Dhoni", 234));
        }else if (intentRecordCorner.equals("HightestScores")){
            tvScore.setText(R.string.hightestscores);
            arrayList.add(new RecordCornerDetailModel(1, "chris Gayle", 337));
            arrayList.add(new RecordCornerDetailModel(2, "Rohit Sharma", 251));
            arrayList.add(new RecordCornerDetailModel(3, "MS Dhoni", 234));
        }else if (intentRecordCorner.equals("BestBattingStrikeRate")){
            tvScore.setText(R.string.bestbattingstrikerate);
            arrayList.add(new RecordCornerDetailModel(1, "chris Gayle", 337));
            arrayList.add(new RecordCornerDetailModel(2, "Rohit Sharma", 251));
            arrayList.add(new RecordCornerDetailModel(3, "MS Dhoni", 234));
        }else if (intentRecordCorner.equals("MostFifties")){
            tvScore.setText(R.string.mostfifties);
            arrayList.add(new RecordCornerDetailModel(1, "chris Gayle", 337));
            arrayList.add(new RecordCornerDetailModel(2, "Rohit Sharma", 251));
            arrayList.add(new RecordCornerDetailModel(3, "MS Dhoni", 234));
        }else if (intentRecordCorner.equals("BWHNOWickets")){
            tvScore.setText(R.string.bowlerswithhighestnoofwickets);
            arrayList.add(new RecordCornerDetailModel(1, "chris Gayle", 337));
            arrayList.add(new RecordCornerDetailModel(2, "Rohit Sharma", 251));
            arrayList.add(new RecordCornerDetailModel(3, "MS Dhoni", 234));
        }else if (intentRecordCorner.equals("TWHIScore")){
            tvScore.setText(R.string.teamwithhightestinningsscore);
            arrayList.add(new RecordCornerDetailModel(1, "chris Gayle", 337));
            arrayList.add(new RecordCornerDetailModel(2, "Rohit Sharma", 251));
            arrayList.add(new RecordCornerDetailModel(3, "MS Dhoni", 234));
        }else if (intentRecordCorner.equals("BWMCenturies")){
            tvScore.setText(R.string.batsmanwithmostcenturies);
            arrayList.add(new RecordCornerDetailModel(1, "chris Gayle", 337));
            arrayList.add(new RecordCornerDetailModel(2, "Rohit Sharma", 251));
            arrayList.add(new RecordCornerDetailModel(3, "MS Dhoni", 234));
        }


        rvRecordCorner = findViewById(R.id.rvRecordCorner);
        RecordCornerDetailAdapter adapter = new RecordCornerDetailAdapter(arrayList);
        rvRecordCorner.setLayoutManager(new LinearLayoutManager(this));
        rvRecordCorner.setAdapter(adapter);

    }

    public class RecordCornerDetailAdapter extends RecyclerView.Adapter<RecordCornerDetailAdapter.ViewHolder> {
        private ArrayList<RecordCornerDetailModel> items;

        public RecordCornerDetailAdapter(ArrayList<RecordCornerDetailModel> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.record_corner_layout, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            RecordCornerDetailModel item = items.get(position);
            holder.tvPOS.setText(""+item.getPos());
            holder.tvPlayerName.setText(item.getPlayerName());
            holder.tvScore.setText("" + item.getScore());

        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            TextView tvPOS, tvPlayerName, tvScore;


            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvPOS = itemView.findViewById(R.id.tvPOS);
                tvPlayerName = itemView.findViewById(R.id.tvPlayerName);
                tvScore = itemView.findViewById(R.id.tvScore);
            }
        }
    }
}