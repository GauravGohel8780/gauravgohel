package com.cricketapp.livecricket.livescore;

// Model class
public class MainItemModel {
    private int rlimageResource;
    private String cardbgColor;
    private String cardstrokeColor;
    private String tvtitle;
    private String tvtitlecolor;
    private int imageResource;

    public MainItemModel(int rlimageResource, String cardbgColor, String cardstrokeColor, String tvtitle, String tvtitlecolor, int imageResource) {
        this.rlimageResource = rlimageResource;
        this.cardbgColor = cardbgColor;
        this.cardstrokeColor = cardstrokeColor;
        this.tvtitle = tvtitle;
        this.tvtitlecolor = tvtitlecolor;
        this.imageResource = imageResource;
    }

    public int getRlimageResource() {
        return rlimageResource;
    }

    public void setRlimageResource(int rlimageResource) {
        this.rlimageResource = rlimageResource;
    }

    public String getCardbgColor() {
        return cardbgColor;
    }

    public void setCardbgColor(String cardbgColor) {
        this.cardbgColor = cardbgColor;
    }

    public String getCardstrokeColor() {
        return cardstrokeColor;
    }

    public void setCardstrokeColor(String cardstrokeColor) {
        this.cardstrokeColor = cardstrokeColor;
    }

    public String getTvtitle() {
        return tvtitle;
    }

    public void setTvtitle(String tvtitle) {
        this.tvtitle = tvtitle;
    }

    public String getTvtitlecolor() {
        return tvtitlecolor;
    }

    public void setTvtitlecolor(String tvtitlecolor) {
        this.tvtitlecolor = tvtitlecolor;
    }

    public int getImageResource() {
        return imageResource;
    }

    public void setImageResource(int imageResource) {
        this.imageResource = imageResource;
    }
}
