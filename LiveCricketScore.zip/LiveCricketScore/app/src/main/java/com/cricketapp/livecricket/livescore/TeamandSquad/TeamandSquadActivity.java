package com.cricketapp.livecricket.livescore.TeamandSquad;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;
import static com.iten.tenoku.utils.MyApplication.sharedPreferencesHelper;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.cricketapp.livecricket.livescore.Ads_Common.AdsBaseActivity;
import com.cricketapp.livecricket.livescore.R;
import com.cricketapp.livecricket.livescore.Schedule.UpcomingFragment;
import com.cricketapp.livecricket.livescore.utils.ApiService;
import com.cricketapp.livecricket.livescore.utils.RetrofitClient;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdConstant;
import com.iten.tenoku.utils.AdUtils;

import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TeamandSquadActivity extends AdsBaseActivity {

    RecyclerView rvTeamandSquad;
    ArrayList<TeamandSquadModel> arrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teamand_squad);


        findViewById(R.id.ivBack).setOnClickListener(v -> {
            getInstance(TeamandSquadActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);

        });

        ApiService apiService = RetrofitClient.getApiService();
        Call<TeamAndSquadAipRespons> call = apiService.getTeamAndSquadData("team&sqaud");
        call.enqueue(new Callback<TeamAndSquadAipRespons>() {
            @Override
            public void onResponse(Call<TeamAndSquadAipRespons> call, Response<TeamAndSquadAipRespons> response) {
                if (response.isSuccessful()) {
                    findViewById(R.id.mainProgress).setVisibility(View.GONE);
                    TeamAndSquadAipRespons responseData = response.body();
                    ArrayList<TeamandSquadModel> teamList = responseData.getData();
                    Log.w("--apiResponse--", "" + new GsonBuilder().setPrettyPrinting().create().toJson(teamList));
                    rvTeamandSquad = findViewById(R.id.rvTeamandSquad);
                    TeamandSquadAdapter adapter = new TeamandSquadAdapter(teamList);
                    rvTeamandSquad.setLayoutManager(new LinearLayoutManager(TeamandSquadActivity.this));
                    rvTeamandSquad.setAdapter(adapter);

                } else {
                    try {
                        Log.e("--apiResponse--", "Error: PlanDetailResponse " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(Call<TeamAndSquadAipRespons> call, Throwable t) {
                Log.e("--apiResponse--", "Error:" + t.getMessage());
            }
        });


    }

    public class TeamandSquadAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private ArrayList<TeamandSquadModel> items;


        public TeamandSquadAdapter(ArrayList<TeamandSquadModel> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.teamandsquadlayout, parent, false);
            return new ViewHolder(view);

        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

            TeamandSquadModel item = (TeamandSquadModel) items.get(position);
            Glide.with(TeamandSquadActivity.this).load(item.getvImage()).into(((ViewHolder) holder).ivTeamimg);

            ((ViewHolder) holder).tvTeamName.setText(item.getvTeameName());
            ((ViewHolder) holder).tvCaptainName.setText(getResources().getString(R.string.captain) + " : " + item.getvCaptain());
            ((ViewHolder) holder).tvCoach.setText(getResources().getString(R.string.coach) + " : " + item.getvCoach());
            ((ViewHolder) holder).tvOwner.setText(getResources().getString(R.string.owner) + " : " + item.getvOwner());

            holder.itemView.setOnClickListener(v -> {
                getInstance(TeamandSquadActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(TeamandSquadActivity.this, TeamandSquadDetailActivity.class);
                        intent.putExtra("TeamandSquadname", item.getvTeameName());
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            });
        }

        @Override
        public int getItemCount() {
            return items.size();
        }


        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvTeamName, tvCaptainName, tvCoach, tvOwner;
            ImageView ivTeamimg;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                ivTeamimg = itemView.findViewById(R.id.ivTeamimg);
                tvTeamName = itemView.findViewById(R.id.tvTeamName);
                tvCaptainName = itemView.findViewById(R.id.tvCaptainName);
                tvCoach = itemView.findViewById(R.id.tvCoach);
                tvOwner = itemView.findViewById(R.id.tvOwner);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}