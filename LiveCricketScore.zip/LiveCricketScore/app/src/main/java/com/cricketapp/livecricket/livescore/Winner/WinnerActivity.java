package com.cricketapp.livecricket.livescore.Winner;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.MyApplication.sharedPreferencesHelper;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.cricketapp.livecricket.livescore.Ads_Common.AdsBaseActivity;
import com.cricketapp.livecricket.livescore.Auction.ActionModel.AuctionDitail;
import com.cricketapp.livecricket.livescore.Auction.ActionModel.AuctionDitailApiResponse;
import com.cricketapp.livecricket.livescore.Auction.AuctionDitailAdapter;
import com.cricketapp.livecricket.livescore.R;
import com.cricketapp.livecricket.livescore.utils.ApiService;
import com.cricketapp.livecricket.livescore.utils.RetrofitClient;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WinnerActivity extends AdsBaseActivity {
    RecyclerView rvWinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_winner);

        findViewById(R.id.ivBack).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });

        ApiService apiService = RetrofitClient.getApiService();
        Call<WinnerApiResponse> call = apiService.getWinnerData("winner");
        call.enqueue(new Callback<WinnerApiResponse>() {
            @Override
            public void onResponse(Call<WinnerApiResponse> call, Response<WinnerApiResponse> response) {
                if (response.isSuccessful()) {
                    findViewById(R.id.mainProgress).setVisibility(View.GONE);
                    WinnerApiResponse responseData = response.body();
                    ArrayList<WinnerModel> teamList = responseData.getData();
                    rvWinner = findViewById(R.id.rvWinner);
                    WinnerAdapter adapter = new WinnerAdapter(teamList);
                    rvWinner.setLayoutManager(new LinearLayoutManager(WinnerActivity.this));
                    rvWinner.setAdapter(adapter);
                } else {
                    try {
                        Log.e("--apiResponse--", "Error: PlanDetailResponse " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(Call<WinnerApiResponse> call, Throwable t) {
                Log.e("--apiResponse--", "Error:" + t.getMessage());
            }
        });
    }


    public class WinnerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private ArrayList<WinnerModel> items;

        public WinnerAdapter(ArrayList<WinnerModel> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.winnerlayout, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

            WinnerModel item = (WinnerModel) items.get(position);
            Glide.with(WinnerActivity.this).load(item.getvWinTeamImage()).into(((ViewHolder) holder).ivWinTeamimg);
            ((ViewHolder) holder).tvWinTeamName.setText(item.getvYear() + " : " + item.getvWinTeamName());
            ((ViewHolder) holder).tvRUT.setText(item.getvRunnerupTeam());
            ((ViewHolder) holder).tvOC.setText(item.getvOrangeCap());
            ((ViewHolder) holder).tvPC.setText(item.getvPurpleCap());
            ((ViewHolder) holder).tvMTM.setText(item.getvManofTheMatch());
            ((ViewHolder) holder).tvV.setText(item.getvVenue());
            ((ViewHolder) holder).tvMD.setText(item.getvMatchDate());
            ((ViewHolder) holder).tvPOT.setText(item.getvPlayerOfTournament());
            ((ViewHolder) holder).tvDitails.setText(item.getvDetails());
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            ImageView ivWinTeamimg;

            TextView tvWinTeamName, tvRUT, tvOC, tvPC, tvMTM, tvV, tvMD, tvPOT, tvDitails;


            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                ivWinTeamimg = itemView.findViewById(R.id.ivWinTeamimg);
                tvWinTeamName = itemView.findViewById(R.id.tvWinTeamName);
                tvRUT = itemView.findViewById(R.id.tvRUT);
                tvOC = itemView.findViewById(R.id.tvOC);
                tvPC = itemView.findViewById(R.id.tvPC);
                tvMTM = itemView.findViewById(R.id.tvMTM);
                tvV = itemView.findViewById(R.id.tvV);
                tvMD = itemView.findViewById(R.id.tvMD);
                tvPOT = itemView.findViewById(R.id.tvPOT);
                tvDitails = itemView.findViewById(R.id.tvDitails);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}