package com.cricketapp.livecricket.livescore.TeamandSquad.BowlingPlayer;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.MyApplication.sharedPreferencesHelper;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.cricketapp.livecricket.livescore.R;
import com.cricketapp.livecricket.livescore.TeamandSquad.BattingPlayer.BattingPlayerFragment;
import com.cricketapp.livecricket.livescore.TeamandSquad.TeamAndSquadAipRespons;
import com.cricketapp.livecricket.livescore.TeamandSquad.TeamandSquadActivity;
import com.cricketapp.livecricket.livescore.TeamandSquad.TeamandSquadDetailModel;
import com.cricketapp.livecricket.livescore.TeamandSquad.TeamandSquadModel;
import com.cricketapp.livecricket.livescore.utils.ApiService;
import com.cricketapp.livecricket.livescore.utils.RetrofitClient;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.utils.AdUtils;

import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BowlingPlayerFragment extends Fragment {

    RecyclerView rvbowlingplayer;
    ArrayList<BowlingPlayerModel> arrayList = new ArrayList<>();
    String teamPlayerName;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_bowling_player, container, false);

        teamPlayerName = getActivity().getIntent().getStringExtra("teamPlayerName");

        ApiService apiService = RetrofitClient.getApiService();
        Call<TeamAndSquadAipRespons> call = apiService.getTeamAndSquadData("team&sqaud");
        call.enqueue(new Callback<TeamAndSquadAipRespons>() {
            @Override
            public void onResponse(Call<TeamAndSquadAipRespons> call, Response<TeamAndSquadAipRespons> response) {
                if (response.isSuccessful()) {
                    view.findViewById(R.id.mainProgress).setVisibility(View.GONE);
                    TeamAndSquadAipRespons responseData = response.body();
                    ArrayList<TeamandSquadModel> teamList = responseData.getData();
                    ArrayList<TeamandSquadDetailModel> teamandSquadDetailModels = teamList.get(0).getArrTeamePlayer();
                    arrayList = teamandSquadDetailModels.get(0).getArrBowling();
                    for (TeamandSquadDetailModel item : teamList.get(0).getArrTeamePlayer()) {
                        if (item.getvName().equals(teamPlayerName)) {
                            rvbowlingplayer = view.findViewById(R.id.rvbowlingplayer);
                            BowlingPlayerAdapter adapter = new BowlingPlayerAdapter(arrayList);
                            rvbowlingplayer.setLayoutManager(new LinearLayoutManager(getContext()));
                            rvbowlingplayer.setAdapter(adapter);
                        }
                    }

                    Log.w("--apiResponse--", "" + new GsonBuilder().setPrettyPrinting().create().toJson(arrayList));

                } else {
                    try {
                        Log.e("--apiResponse--", "Error: PlanDetailResponse " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(Call<TeamAndSquadAipRespons> call, Throwable t) {
                Log.e("--apiResponse--", "Error:" + t.getMessage());
            }
        });

        return view;

    }


    public class BowlingPlayerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private ArrayList<BowlingPlayerModel> items;

        public BowlingPlayerAdapter(ArrayList<BowlingPlayerModel> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(getContext()).inflate(R.layout.bowling_player_layout, parent, false);
            return new ViewHolder(view);

        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

            BowlingPlayerModel item = (BowlingPlayerModel) items.get(position);
            if (item.getYear().isEmpty()) {
                ((ViewHolder) holder).tvTitleName.setText("Total Match : " + item.getvTotalMatch());
            } else {
                ((ViewHolder) holder).tvTitleName.setText("Year : " + item.getYear() + "  Match : " + item.getvTotalMatch());
            }
            ((ViewHolder) holder).tvBalls.setText("" + item.getvBall());
            ((ViewHolder) holder).tvRuns.setText("" + item.getvRun());
            ((ViewHolder) holder).tvWKTS.setText("" + item.getvWkts());
            ((ViewHolder) holder).tvBBM.setText("" + item.getvBbm());
            ((ViewHolder) holder).tvAve.setText("" + item.getvAve());
            ((ViewHolder) holder).tvEcon.setText("" + item.getvEcon());
            ((ViewHolder) holder).tvSR.setText("" + item.getvSr());
            ((ViewHolder) holder).tvb4W.setText("" + item.getV4w());
            ((ViewHolder) holder).tvb5W.setText("" + item.getV5w());
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvTitleName, tvBalls, tvRuns, tvWKTS, tvBBM, tvAve, tvEcon, tvSR, tvb4W, tvb5W;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvTitleName = itemView.findViewById(R.id.tvTitleName);
                tvBalls = itemView.findViewById(R.id.tvBalls);
                tvRuns = itemView.findViewById(R.id.tvRuns);
                tvWKTS = itemView.findViewById(R.id.tvWKTS);
                tvBBM = itemView.findViewById(R.id.tvBBM);
                tvAve = itemView.findViewById(R.id.tvAve);
                tvEcon = itemView.findViewById(R.id.tvEcon);
                tvSR = itemView.findViewById(R.id.tvSR);
                tvb4W = itemView.findViewById(R.id.tvb4W);
                tvb5W = itemView.findViewById(R.id.tvb5W);
            }
        }
    }
}