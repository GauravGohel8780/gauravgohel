package com.cricketapp.livecricket.livescore.LiveMatch.LiveLine;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.cricketapp.livecricket.livescore.LiveMatch.LiveMatchActivity;
import com.cricketapp.livecricket.livescore.LiveMatch.LiveMatchAipRespons;
import com.cricketapp.livecricket.livescore.LiveMatch.LiveMatchModel;
import com.cricketapp.livecricket.livescore.R;
import com.cricketapp.livecricket.livescore.TeamandSquad.TeamandSquadDetailModel;
import com.cricketapp.livecricket.livescore.TeamandSquad.TeamandSquadModel;
import com.cricketapp.livecricket.livescore.utils.ApiService;
import com.cricketapp.livecricket.livescore.utils.RetrofitClient;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LiveLineFragment extends Fragment {
    ArrayList<LiveMatchModel> arrayList = new ArrayList<>();
    int LiveMatchId;
    SwipeRefreshLayout swipeRefreshLayout;
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_live_line, container, false);

        LiveMatchId = requireActivity().getIntent().getIntExtra("LiveMatchId", 0);

        
        RefreshData();
        
        swipeRefreshLayout = view.findViewById(R.id.refreshLayout);

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                RefreshData();
                swipeRefreshLayout.setRefreshing(false);
            }
        });

        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.d("sss", "run: "+"5000");
                RefreshData();
                handler.postDelayed(this, 5000);
            }
        }, 0);
        return view;
    }

    private void RefreshData() {
        ApiService apiService = RetrofitClient.getApiService();
        Call<LiveMatchAipRespons> call = apiService.getLiveMatchDetails();
        call.enqueue(new Callback<LiveMatchAipRespons>() {
            @Override
            public void onResponse(Call<LiveMatchAipRespons> call, Response<LiveMatchAipRespons> response) {
                if (response.isSuccessful()) {
                    LiveMatchAipRespons LiveMatchAipRespons = response.body();
                    arrayList = LiveMatchAipRespons.getData();
                    for (LiveMatchModel item : arrayList) {
                        if (item.getMatchId().equals(LiveMatchId)) {
                            String batsmanName = item.getInnerData().getBatsman(); // Assuming this is your input string
                            String[] batsmanvalues = batsmanName.split("\\|");

                            if (batsmanvalues.length > 0) {
                                ((TextView) view.findViewById(R.id.tvsPlayname)).setText(batsmanvalues[0]);
                            } else {
                                ((TextView) view.findViewById(R.id.tvsPlayname)).setText("----");
                            }


                            if (batsmanvalues.length > 1) {
                                ((TextView) view.findViewById(R.id.tvnsPlayname)).setText(batsmanvalues[1]);
                            }else {
                                ((TextView) view.findViewById(R.id.tvnsPlayname)).setText("----");
                            }

                            ((TextView) view.findViewById(R.id.tvLiveBord)).setText(item.getScore());

                            String oversBVlaue = item.getInnerData().getOversB();
                            String[] oversBvalues = oversBVlaue.split("\\|");
                            String[] sRunBoll = oversBvalues[0].split(",");
                            String[] nsRunBoll = oversBvalues[1].split(",");

                            ((TextView) view.findViewById(R.id.tvsRun)).setText(sRunBoll[1]);
                            ((TextView) view.findViewById(R.id.tvsBoll)).setText(nsRunBoll[1]);

                            float srunBoll0 = Float.parseFloat(sRunBoll[1]);
                            float srunBoll1 = Float.parseFloat(nsRunBoll[1]);
                            float srate = (srunBoll0 / srunBoll1) * 100;
                            ((TextView) view.findViewById(R.id.tvsSR)).setText("" + String.format("%.2f", srate));

                            ((TextView) view.findViewById(R.id.tvnsRun)).setText(sRunBoll[0]);
                            ((TextView) view.findViewById(R.id.tvnsBoll)).setText(nsRunBoll[0]);

                            float nsrunBoll0 = Float.parseFloat(sRunBoll[0]);
                            float nsrunBoll1 = Float.parseFloat(nsRunBoll[0]);
                            float nsrate = (nsrunBoll0 / nsrunBoll1) * 100;
                            ((TextView) view.findViewById(R.id.tvnsSR)).setText("" + String.format("%.2f", nsrate));

                            ((TextView) view.findViewById(R.id.tvOversA)).setText("Overs(" + item.getInnerData().getOversA() + ")");

                            ((TextView) view.findViewById(R.id.TeamA)).setText(item.getTeamA());
                            ((TextView) view.findViewById(R.id.tvwicketA)).setText(item.getWicketA());
                            if (getActivity() != null && !getActivity().isDestroyed() && !getActivity().isFinishing()) {
                                Glide.with(getActivity()).load(item.getTeamABannerA()).into((ImageView) view.findViewById(R.id.ivTeamABannerA));
                                Glide.with(getActivity()).load(item.getTeamABannerB()).into((ImageView) view.findViewById(R.id.ivTeamABannerB));
                            }
                            ((TextView) view.findViewById(R.id.tvTeamB)).setText(item.getTeamB());
                            ((TextView) view.findViewById(R.id.tvwicketB)).setText(item.getWicketB());
                            ((TextView) view.findViewById(R.id.tvBowler)).setText("Bowler : " + item.getInnerData().getBowler());
                            ((TextView) view.findViewById(R.id.tvSummary)).setText(item.getInnerData().getTitle());
                            ((TextView) view.findViewById(R.id.tvs4)).setText(item.getInnerData().getS4());
                            ((TextView) view.findViewById(R.id.tvs6)).setText(item.getInnerData().getS6());
                            ((TextView) view.findViewById(R.id.tvns4)).setText(item.getInnerData().getNs4());
                            ((TextView) view.findViewById(R.id.tvns6)).setText(item.getInnerData().getNs6());

                        }
                    }

                    Log.w("--apiResponse--", "" + new GsonBuilder().setPrettyPrinting().create().toJson(LiveMatchAipRespons));

                } else {
                    try {
                        Log.e("www", "Response not successful. Code: " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(Call<LiveMatchAipRespons> call, Throwable t) {
                Log.e("www", "Failed to fetch schedule details: " + t.getMessage());
            }
        });
    }
}