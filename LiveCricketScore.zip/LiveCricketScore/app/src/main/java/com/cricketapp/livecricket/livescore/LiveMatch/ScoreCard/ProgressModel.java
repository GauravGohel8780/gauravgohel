package com.cricketapp.livecricket.livescore.LiveMatch.ScoreCard;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ProgressModel {

    @SerializedName("vTeamName")
    @Expose
    private String vTeamName;
    @SerializedName("vPlayerName")
    @Expose
    private String vPlayerName;
    @SerializedName("iMatchId")
    @Expose
    private Integer iMatchId;
    @SerializedName("vTeamRuns")
    @Expose
    private String vTeamRuns;
    @SerializedName("vPlayerImage")
    @Expose
    private String vPlayerImage;
    @SerializedName("iRuns")
    @Expose
    private Integer iRuns;
    @SerializedName("vTeamSide")
    @Expose
    private String vTeamSide;
    @SerializedName("iBalls")
    @Expose
    private Integer iBalls;
    @SerializedName("ifour")
    @Expose
    private Integer ifour;
    @SerializedName("isix")
    @Expose
    private Integer isix;
    @SerializedName("iseqno")
    @Expose
    private Integer iseqno;
    @SerializedName("voutby")
    @Expose
    private String voutby;
    @SerializedName("iInning")
    @Expose
    private Integer iInning;
    @SerializedName("iIsnotout")
    @Expose
    private Integer iIsnotout;
    @SerializedName("sr")
    @Expose
    private Object sr;

    public String getvTeamName() {
        return vTeamName;
    }

    public void setvTeamName(String vTeamName) {
        this.vTeamName = vTeamName;
    }

    public String getvPlayerName() {
        return vPlayerName;
    }

    public void setvPlayerName(String vPlayerName) {
        this.vPlayerName = vPlayerName;
    }

    public Integer getiMatchId() {
        return iMatchId;
    }

    public void setiMatchId(Integer iMatchId) {
        this.iMatchId = iMatchId;
    }

    public String getvTeamRuns() {
        return vTeamRuns;
    }

    public void setvTeamRuns(String vTeamRuns) {
        this.vTeamRuns = vTeamRuns;
    }

    public String getvPlayerImage() {
        return vPlayerImage;
    }

    public void setvPlayerImage(String vPlayerImage) {
        this.vPlayerImage = vPlayerImage;
    }

    public Integer getiRuns() {
        return iRuns;
    }

    public void setiRuns(Integer iRuns) {
        this.iRuns = iRuns;
    }

    public String getvTeamSide() {
        return vTeamSide;
    }

    public void setvTeamSide(String vTeamSide) {
        this.vTeamSide = vTeamSide;
    }

    public Integer getiBalls() {
        return iBalls;
    }

    public void setiBalls(Integer iBalls) {
        this.iBalls = iBalls;
    }

    public Integer getIfour() {
        return ifour;
    }

    public void setIfour(Integer ifour) {
        this.ifour = ifour;
    }

    public Integer getIsix() {
        return isix;
    }

    public void setIsix(Integer isix) {
        this.isix = isix;
    }

    public Integer getIseqno() {
        return iseqno;
    }

    public void setIseqno(Integer iseqno) {
        this.iseqno = iseqno;
    }

    public String getVoutby() {
        return voutby;
    }

    public void setVoutby(String voutby) {
        this.voutby = voutby;
    }

    public Integer getiInning() {
        return iInning;
    }

    public void setiInning(Integer iInning) {
        this.iInning = iInning;
    }

    public Integer getiIsnotout() {
        return iIsnotout;
    }

    public void setiIsnotout(Integer iIsnotout) {
        this.iIsnotout = iIsnotout;
    }

    public Object getSr() {
        return sr;
    }

    public void setSr(Object sr) {
        this.sr = sr;
    }
}
