package com.cricketapp.livecricket.livescore.IccRanking;

import android.content.Context;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.cricketapp.livecricket.livescore.IccRanking.AllRounders.AllRoundersFragment;
import com.cricketapp.livecricket.livescore.IccRanking.Bowler.BowlerFragment;
import com.cricketapp.livecricket.livescore.IccRanking.Team.TeamFragment;
import com.cricketapp.livecricket.livescore.IccRanking.batter.BatterFragment;

public class IccRankingAdapter extends FragmentPagerAdapter {
  
    private Context myContext;
    int totalTabs;  
  
    public IccRankingAdapter(Context context, FragmentManager fm, int totalTabs) {
        super(fm);  
        myContext = context;  
        this.totalTabs = totalTabs;  
    }  

    @Override  
    public Fragment getItem(int position) {
        switch (position) {  
            case 0:
                TeamFragment teamFragment = new TeamFragment();
                return teamFragment;
            case 1:
                BatterFragment batterFragment = new BatterFragment();
                return batterFragment;
            case 2:
                BowlerFragment bowlerFragment = new BowlerFragment();
                return bowlerFragment;
            case 3:
                AllRoundersFragment allroundersFragment = new AllRoundersFragment();
                return allroundersFragment;
            default:  
                return null;  
        }  
    }
    @Override  
    public int getCount() {  
        return totalTabs;  
    }  
}  