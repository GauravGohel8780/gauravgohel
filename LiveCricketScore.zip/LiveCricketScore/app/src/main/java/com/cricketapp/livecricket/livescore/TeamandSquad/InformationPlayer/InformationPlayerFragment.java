package com.cricketapp.livecricket.livescore.TeamandSquad.InformationPlayer;

import static com.iten.tenoku.ad.AdShow.getInstance;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.cricketapp.livecricket.livescore.IPLList.IPLListModel;
import com.cricketapp.livecricket.livescore.R;
import com.cricketapp.livecricket.livescore.TeamandSquad.TeamAndSquadAipRespons;
import com.cricketapp.livecricket.livescore.TeamandSquad.TeamandSquadDetailActivity;
import com.cricketapp.livecricket.livescore.TeamandSquad.TeamandSquadDetailModel;
import com.cricketapp.livecricket.livescore.TeamandSquad.TeamandSquadModel;
import com.cricketapp.livecricket.livescore.utils.ApiService;
import com.cricketapp.livecricket.livescore.utils.RetrofitClient;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.utils.AdUtils;

import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InformationPlayerFragment extends Fragment {

    String teamPlayerName;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_information_player, container, false);

        teamPlayerName = getActivity().getIntent().getStringExtra("teamPlayerName");

        ApiService apiService = RetrofitClient.getApiService();
        Call<TeamAndSquadAipRespons> call = apiService.getTeamAndSquadData("team&sqaud");
        call.enqueue(new Callback<TeamAndSquadAipRespons>() {
            @Override
            public void onResponse(Call<TeamAndSquadAipRespons> call, Response<TeamAndSquadAipRespons> response) {
                if (response.isSuccessful()) {
                    TeamAndSquadAipRespons responseData = response.body();
                    ArrayList<TeamandSquadModel> teamList = responseData.getData();
                    ArrayList<TeamandSquadDetailModel> teamList1 = teamList.get(0).getArrTeamePlayer();
                    for (TeamandSquadDetailModel item : teamList1) {
                        if (item.getvName().equals(teamPlayerName)) {
                            Glide.with(getActivity()).load(item.getvImage()).into(((ImageView) view.findViewById(R.id.ivPlayerimg)));
                            ((TextView) view.findViewById(R.id.tvPlayerName)).setText("" + item.getvName());
                            ((TextView) view.findViewById(R.id.tvBorn)).setText("" + item.getDtDob());
                            ((TextView) view.findViewById(R.id.tvRole)).setText("" + item.getvRole());
                            ((TextView) view.findViewById(R.id.tvBattingStyle)).setText("" + item.getvBattingStyle());
                            ((TextView) view.findViewById(R.id.tvBowlingStyle)).setText("" + item.getvBowlingStyle());
                        }
                    }
                } else {
                    try {
                        Log.e("--apiResponse--", "Error: PlanDetailResponse " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(Call<TeamAndSquadAipRespons> call, Throwable t) {
                Log.e("--apiResponse--", "Error:" + t.getMessage());
            }
        });
        return view;
    }
}