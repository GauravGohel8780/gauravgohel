package com.cricketapp.livecricket.livescore.IccRanking.ApiModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TeamModel {

@SerializedName("vRank")
@Expose
private String vRank;
@SerializedName("vTeam")
@Expose
private String vTeam;
@SerializedName("vMatches")
@Expose
private String vMatches;
@SerializedName("vPoint")
@Expose
private String vPoint;
@SerializedName("vRatings")
@Expose
private String vRatings;

public String getvRank() {
return vRank;
}

public void setvRank(String vRank) {
this.vRank = vRank;
}

public String getvTeam() {
return vTeam;
}

public void setvTeam(String vTeam) {
this.vTeam = vTeam;
}

public String getvMatches() {
return vMatches;
}

public void setvMatches(String vMatches) {
this.vMatches = vMatches;
}

public String getvPoint() {
return vPoint;
}

public void setvPoint(String vPoint) {
this.vPoint = vPoint;
}

public String getvRatings() {
return vRatings;
}

public void setvRatings(String vRatings) {
this.vRatings = vRatings;
}

}