package com.cricketapp.livecricket.livescore.Winner;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class WinnerApiResponse {
    @SerializedName("iStatusCode")
    @Expose
    private Integer iStatusCode;
    @SerializedName("isStatus")
    @Expose
    private Boolean isStatus;
    @SerializedName("data")
    @Expose
    private ArrayList<WinnerModel> data;
    @SerializedName("vMessage")
    @Expose
    private String vMessage;

    public Integer getiStatusCode() {
        return iStatusCode;
    }

    public void setiStatusCode(Integer iStatusCode) {
        this.iStatusCode = iStatusCode;
    }

    public Boolean getIsStatus() {
        return isStatus;
    }

    public void setIsStatus(Boolean isStatus) {
        this.isStatus = isStatus;
    }

    public ArrayList<WinnerModel> getData() {
        return data;
    }

    public void setData(ArrayList<WinnerModel> data) {
        this.data = data;
    }

    public String getvMessage() {
        return vMessage;
    }

    public void setvMessage(String vMessage) {
        this.vMessage = vMessage;
    }
}
