package com.cricketapp.livecricket.livescore.Schedule;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;
import static com.iten.tenoku.utils.MyApplication.sharedPreferencesHelper;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.cricketapp.livecricket.livescore.R;
import com.cricketapp.livecricket.livescore.utils.ApiService;
import com.cricketapp.livecricket.livescore.utils.RetrofitClient;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ResultFragment extends Fragment {
    ArrayList<UpcomingModel> arrayList = new ArrayList<>();
    ResultAdapter adapter;
    LinearLayoutManager linearLayoutManager;
    RecyclerView rv;
    private int currentPage = 01;
    private int plushitemsize = 30;

    NestedScrollView myScrollview;
    View view;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_result, container, false);

        myScrollview =  view.findViewById(R.id.myScrollview);
        rv = (RecyclerView) view.findViewById(R.id.rvResult);

        adapter = new ResultAdapter(arrayList);

        linearLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        rv.setLayoutManager(linearLayoutManager);

        rv.setItemAnimator(new DefaultItemAnimator());

        rv.setAdapter(adapter);



      myScrollview.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
          @Override
          public void onScrollChange(@NonNull NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
              if(scrollY == v.getChildAt(0).getMeasuredHeight() - v.getMeasuredHeight())
              {
                  loadNextPage();
              }
          }
      });

        loadFirstPage();
        return view;
    }


    private void loadFirstPage() {
        ApiService apiService = RetrofitClient.getApiService();
        Call<UpcomingAipRespons> call = apiService.getTopRatedMovies(String.valueOf(currentPage), String.valueOf(plushitemsize));
        call.enqueue(new Callback<UpcomingAipRespons>() {
            @Override
            public void onResponse(Call<UpcomingAipRespons> call, Response<UpcomingAipRespons> response) {
                view.findViewById(R.id.mainProgress).setVisibility(View.GONE);
                ArrayList<UpcomingModel> results = response.body().getData();
                adapter.addAll(results);

            }

            @Override
            public void onFailure(Call<UpcomingAipRespons> call, Throwable t) {
                t.printStackTrace();
            }
        });

    }

    private void loadNextPage() {
        int startNextPage = plushitemsize + 1;
        int endNextPage = plushitemsize + 30;
        ApiService apiService = RetrofitClient.getApiService();
        Call<UpcomingAipRespons> call = apiService.getTopRatedMovies(String.valueOf(startNextPage), String.valueOf(endNextPage));
        call.enqueue(new Callback<UpcomingAipRespons>() {
            @Override
            public void onResponse(Call<UpcomingAipRespons> call, Response<UpcomingAipRespons> response) {
                plushitemsize = endNextPage;
                view.findViewById(R.id.mainProgress).setVisibility(View.GONE);
                ArrayList<UpcomingModel> results = response.body().getData();
                adapter.addAll(results);

            }

            @Override
            public void onFailure(Call<UpcomingAipRespons> call, Throwable t) {
                t.printStackTrace();

            }
        });
    }


    public class ResultAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private ArrayList<UpcomingModel> items;
        private static final int ITEM = 0;
        private static final int LOADING = 1;

        public ResultAdapter(ArrayList<UpcomingModel> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            RecyclerView.ViewHolder viewHolder = null;
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());

            switch (viewType) {
                case ITEM:
                    viewHolder = getViewHolder(parent, inflater);
                    break;
                case LOADING:
                    View v2 = inflater.inflate(R.layout.dataload_layout, parent, false);
                    viewHolder = new LoadingVH(v2);
                    break;
            }
            return viewHolder;

        }

        @NonNull
        private RecyclerView.ViewHolder getViewHolder(ViewGroup parent, LayoutInflater inflater) {
            RecyclerView.ViewHolder viewHolder;
            View v1 = inflater.inflate(R.layout.schedule_layout, parent, false);
            viewHolder = new ViewHolder(v1);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

            switch (getItemViewType(position)) {
                case ITEM:

                    UpcomingModel item = (UpcomingModel) items.get(position);
                    ((ViewHolder) holder).tvTitleMatch.setText(item.getTitle());
                    ((ViewHolder) holder).tvTitleMatch.setSelected(true);
                    ((ViewHolder) holder).tvMatchName1.setText(item.getTeamA());
                    ((ViewHolder) holder).tvMatchName2.setText(item.getTeamB());
                    ((ViewHolder) holder).tvMatchDatetime.setText(item.getMatchtime());
                    ((ViewHolder) holder).tvMatchCityName.setText(item.getVenue());
                    ((ViewHolder) holder).tvMatchCityName.setSelected(true);
                    Glide.with(getContext()).load(item.getImageUrl() + item.getTeamAImage()).into(((ViewHolder) holder).ivMatchImg1);
                    Glide.with(getContext()).load(item.getImageUrl() + item.getTeamBImage()).into(((ViewHolder) holder).ivMatchImg2);


                    if (item.getResult() == null) {
                        ((ViewHolder) holder).tvMatchWon.setVisibility(View.GONE);
                    } else {
                        ((ViewHolder) holder).tvMatchWon.setVisibility(View.VISIBLE);
                        ((ViewHolder) holder).tvMatchWon.setText("won : " + item.getResult());
                        ((ViewHolder) holder).tvMatchWon.setSelected(true);
                    }

                    holder.itemView.setOnClickListener(v -> {
                        getInstance(getActivity()).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                Intent intent = new Intent(requireContext(), ResultDitailActivity.class);
                                intent.putExtra("LiveMatchId", item.getMatchId());
                                intent.putExtra("LiveMatchtitle", item.getTitle());
                                startActivity(intent);
                            }
                        }, MAIN_CLICK);
                    });

                    break;

                case LOADING:
                    break;
            }
        }

        @Override
        public int getItemCount() {
            return items == null ? 0 : items.size();
        }

        @Override
        public int getItemViewType(int position) {
            return (position == items.size() - 1) ? LOADING : ITEM;
        }

        public void add(UpcomingModel r) {
            items.add(r);
            notifyItemInserted(items.size() - 1);
        }

        public void addAll(List<UpcomingModel> moveResults) {
            for (UpcomingModel result : moveResults) {
                add(result);
            }
        }




        public class ViewHolder extends RecyclerView.ViewHolder {

            TextView tvTitleMatch, tvMatchName1, tvMatchName2, tvMatchDatetime, tvMatchCityName, tvMatchWon;
            ImageView ivMatchImg1, ivMatchImg2;


            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvTitleMatch = itemView.findViewById(R.id.tvTitleMatch);
                tvMatchName1 = itemView.findViewById(R.id.tvMatchName1);
                tvMatchName2 = itemView.findViewById(R.id.tvMatchName2);
                tvMatchDatetime = itemView.findViewById(R.id.tvMatchDatetime);
                tvMatchCityName = itemView.findViewById(R.id.tvMatchCityName);
                ivMatchImg1 = itemView.findViewById(R.id.ivMatchImg1);
                ivMatchImg2 = itemView.findViewById(R.id.ivMatchImg2);
                tvMatchWon = itemView.findViewById(R.id.tvMatchWon);
            }
        }
    }

    protected class LoadingVH extends RecyclerView.ViewHolder {

        public LoadingVH(View itemView) {
            super(itemView);
        }
    }

}