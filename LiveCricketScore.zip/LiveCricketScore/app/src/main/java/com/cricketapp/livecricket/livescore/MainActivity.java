package com.cricketapp.livecricket.livescore;

import static androidx.databinding.DataBindingUtil.setContentView;
import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;
import static com.iten.tenoku.utils.MyApplication.sharedPreferencesHelper;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.cricketapp.livecricket.livescore.Ads_Common.AdsBaseActivity;
import com.cricketapp.livecricket.livescore.Ads_Common.ExitActivity;
import com.cricketapp.livecricket.livescore.Auction.AuctionActivity;
import com.cricketapp.livecricket.livescore.IPLList.IPLListActivity;
import com.cricketapp.livecricket.livescore.IccRanking.IccRankingActivity;
import com.cricketapp.livecricket.livescore.LiveMatch.LiveMatchActivity;
import com.cricketapp.livecricket.livescore.PointTable.PointTableActivity;
import com.cricketapp.livecricket.livescore.RecordCorner.RecordCornerActivity;
import com.cricketapp.livecricket.livescore.Schedule.ScheduleActivity;
import com.cricketapp.livecricket.livescore.TeamandSquad.TeamandSquadActivity;
import com.cricketapp.livecricket.livescore.Venues.VenuesActivity;
import com.cricketapp.livecricket.livescore.Winner.WinnerActivity;
import com.cricketapp.livecricket.livescore.feedback.FeedbackActivity;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.navigation.NavigationView;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.util.ArrayList;

public class MainActivity extends AdsBaseActivity {
    RecyclerView rvmainitems;
    ImageView iv_menubtn;
    NavigationView navigationView;
    DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.ivLiveMatch).setOnClickListener(v -> {
            getInstance(MainActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    Intent intent = new Intent(MainActivity.this, LiveMatchActivity.class);
                    startActivity(intent);
                }
            }, MAIN_CLICK);
        });


        ArrayList<MainItemModel> items = new ArrayList<>();
        items.add(new MainItemModel(R.drawable.ic_schedule_bg, "#BDDCFE", "#7FB5F1", getResources().getString(R.string.schedule), "#002855", R.drawable.ic_schedule_img));
//        items.add(new MainItemModel(R.drawable.ic_pointtable_bg, "#E3BDFF", "#C17AF6", getResources().getString(R.string.pointable), "#202020", R.drawable.ic_pointtable_img));
//        items.add(new MainItemModel(R.drawable.ic_recordcorner_bg, "#FFA0B5", "#FA5A7D", getResources().getString(R.string.recordcorner), "#730019", R.drawable.ic_recordcorner_img));
        items.add(new MainItemModel(R.drawable.ic_teamandsqaud_bg, "#56F1FE", "#00BBCB", getResources().getString(R.string.teamsqaud), "#002855", R.drawable.ic_teamandsqaud_img));
        items.add(new MainItemModel(R.drawable.ic_winner_bg, "#FFD586", "#FFC24D", getResources().getString(R.string.winner), "#513500", R.drawable.ic_winner_img));
        items.add(new MainItemModel(R.drawable.ic_venues_bg, "#FF9E84", "#F6623A", getResources().getString(R.string.venues), "#513500", R.drawable.ic_venues_img));
        items.add(new MainItemModel(R.drawable.ic_iccranking_man_bg, "#C3A9FF", "#9160FF", getResources().getString(R.string.iccrankingman), "#1A0055", R.drawable.ic_iccranking_man_img));
        items.add(new MainItemModel(R.drawable.ic_iccranking_woman_bg, "#AAF7DF", "#68E0BA", getResources().getString(R.string.iccrankingwoman), "#002016", R.drawable.ic_iccranking_woman_img));
        items.add(new MainItemModel(R.drawable.ic_auction_bg, "#FF8E92", "#F65257", getResources().getString(R.string.auction), "#3C0002", R.drawable.ic_auction_img));

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigation_view);
        iv_menubtn = findViewById(R.id.iv_menubtn);
        rvmainitems = findViewById(R.id.rvmainitems);

        MainItemAdapter adapter = new MainItemAdapter(items);
        rvmainitems.setLayoutManager(new GridLayoutManager(this, 2));
        rvmainitems.setAdapter(adapter);

        iv_menubtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        drawerLayout.openDrawer(GravityCompat.START);
                    }
                }, MAIN_CLICK);
            }
        });

        findViewById(R.id.cvIplList).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(MainActivity.this, IPLListActivity.class);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                int id = item.getItemId();
                drawerLayout.closeDrawer(GravityCompat.START);
                switch (id) {
                    case R.id.homeitem:

                        break;
                    case R.id.livescoreitem:
                        getInstance(MainActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                Intent intent = new Intent(MainActivity.this, LiveMatchActivity.class);
                                startActivity(intent);
                            }
                        }, MAIN_CLICK);
                        break;
                    case R.id.scheduleitem:
                        getInstance(MainActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                Intent intent = new Intent(MainActivity.this, ScheduleActivity.class);
                                startActivity(intent);
                            }
                        }, MAIN_CLICK);
                        break;
                    case R.id.teamsqauditem:
                        getInstance(MainActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                Intent intent = new Intent(MainActivity.this, TeamandSquadActivity.class);
                                startActivity(intent);
                            }
                        }, MAIN_CLICK);
                        break;
                    case R.id.winneritem:
                        getInstance(MainActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                Intent intent = new Intent(MainActivity.this, WinnerActivity.class);
                                startActivity(intent);
                            }
                        }, MAIN_CLICK);
                        break;
//                    case R.id.pointableitem:
//                        getInstance(MainActivity.this).ShowAd(new HandleClick() {
//                            @Override
//                            public void Show(boolean adShow) {
//                                Intent intent = new Intent(MainActivity.this, PointTableActivity.class);
//                                startActivity(intent);
//                            }
//                        }, MAIN_CLICK);
//                        break;
                    case R.id.venuesitem:
                        getInstance(MainActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                Intent intent = new Intent(MainActivity.this, VenuesActivity.class);
                                startActivity(intent);
                            }
                        }, MAIN_CLICK);
                        break;
//                    case R.id.recordcorneritem:
//                        getInstance(MainActivity.this).ShowAd(new HandleClick() {
//                            @Override
//                            public void Show(boolean adShow) {
//                                Intent intent = new Intent(MainActivity.this, RecordCornerActivity.class);
//                                startActivity(intent);
//                            }
//                        }, MAIN_CLICK);
//                        break;
                    case R.id.shareitem:
                        try {
                            Intent shareIntent = new Intent(Intent.ACTION_SEND);
                            shareIntent.setType("text/plain");
                            shareIntent.putExtra(Intent.EXTRA_SUBJECT, getResources().getString(R.string.app_name));
                            String shareMessage = "\nLet me recommend you this application\n\n";
                            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "\n\n";
                            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                            startActivity(Intent.createChooser(shareIntent, "choose one"));
                        } catch (Exception e) {
                        }
                        break;
                    case R.id.rateusitem:
                        getInstance(MainActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                RateingDialog rateingDialog = new RateingDialog(MainActivity.this);
                                rateingDialog.getWindow().setBackgroundDrawable(new ColorDrawable(getResources().getColor(android.R.color.transparent)));
                                rateingDialog.setCancelable(true);
                                rateingDialog.show();
                            }
                        }, MAIN_CLICK);
                        break;
                    default:
                        return true;
                }
                return true;
            }
        });


        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                Intent intent = new Intent(MainActivity.this, ExitActivity.class);
                startActivity(intent);
            }
        };

        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    public class MainItemAdapter extends RecyclerView.Adapter<MainItemAdapter.ViewHolder> {
        private ArrayList<MainItemModel> items;

        public MainItemAdapter(ArrayList<MainItemModel> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.main_item_layout, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            MainItemModel item = items.get(position);
            holder.ivimg.setImageResource(item.getImageResource());
            holder.rlbgimg.setBackgroundResource(item.getRlimageResource());
            holder.txttitle.setText(item.getTvtitle());
            holder.txttitle.setTextColor(Color.parseColor(item.getTvtitlecolor()));
            holder.mcvcolors.setCardBackgroundColor(Color.parseColor(item.getCardbgColor()));
            holder.mcvcolors.setStrokeColor(Color.parseColor(item.getCardstrokeColor()));

            holder.itemView.setOnClickListener(v -> {
                getInstance(MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        if (position == 0) {
                            Intent intent = new Intent(MainActivity.this, ScheduleActivity.class);
                            startActivity(intent);
                        }
//                        else if (position == 1) {
//                            Intent intent = new Intent(MainActivity.this, PointTableActivity.class);
//                            startActivity(intent);
//                        }
//                        else if (position == 1) {
//                            Intent intent = new Intent(MainActivity.this, RecordCornerActivity.class);
//                            startActivity(intent);
//                        }
                        else if (position == 1) {
                            Intent intent = new Intent(MainActivity.this, TeamandSquadActivity.class);
                            startActivity(intent);
                        }
                        else if (position == 2) {
                            Intent intent = new Intent(MainActivity.this, WinnerActivity.class);
                            startActivity(intent);
                        }
                        else if (position == 3) {
                            Intent intent = new Intent(MainActivity.this, VenuesActivity.class);
                            startActivity(intent);
                        } else if (position == 4) {
                            Intent intent = new Intent(MainActivity.this, IccRankingActivity.class);
                            intent.putExtra("IccRanking", "men");
                            startActivity(intent);
                        } else if (position == 5) {
                            Intent intent = new Intent(MainActivity.this, IccRankingActivity.class);
                            intent.putExtra("IccRanking", "women");
                            startActivity(intent);
                        } else if (position == 6) {
                            Intent intent = new Intent(MainActivity.this, AuctionActivity.class);
                            intent.putExtra("IccRanking", "Woman");
                            startActivity(intent);
                        }
                    }
                }, MAIN_CLICK);
            });
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            RelativeLayout rlbgimg;
            MaterialCardView mcvcolors;
            ImageView ivimg;
            TextView txttitle;


            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                rlbgimg = itemView.findViewById(R.id.rlbgimg);
                mcvcolors = itemView.findViewById(R.id.mcvcolors);
                ivimg = itemView.findViewById(R.id.ivimg);
                txttitle = itemView.findViewById(R.id.txttitle);
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall1).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);

    }
}