package com.cricketapp.livecricket.livescore.IccRanking.ApiModel;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class IccRankingApiResponse {
    @SerializedName("iStatusCode")
    @Expose
    private Integer iStatusCode;
    @SerializedName("isStatus")
    @Expose
    private Boolean isStatus;
    @SerializedName("data")
    @Expose
    private ArrayList<ObjMain> data;
    @SerializedName("vMessage")
    @Expose
    private String vMessage;

    public Integer getiStatusCode() {
        return iStatusCode;
    }

    public void setiStatusCode(Integer iStatusCode) {
        this.iStatusCode = iStatusCode;
    }

    public Boolean getIsStatus() {
        return isStatus;
    }

    public void setIsStatus(Boolean isStatus) {
        this.isStatus = isStatus;
    }

    public ArrayList<ObjMain> getData() {
        return data;
    }

    public void setData(ArrayList<ObjMain> data) {
        this.data = data;
    }

    public String getvMessage() {
        return vMessage;
    }

    public void setvMessage(String vMessage) {
        this.vMessage = vMessage;
    }

}
