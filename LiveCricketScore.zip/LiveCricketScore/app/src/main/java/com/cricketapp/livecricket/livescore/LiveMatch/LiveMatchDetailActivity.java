package com.cricketapp.livecricket.livescore.LiveMatch;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.graphics.PorterDuff;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.cricketapp.livecricket.livescore.Ads_Common.AdsBaseActivity;
import com.cricketapp.livecricket.livescore.LiveMatch.LiveLine.LiveLineFragment;
import com.cricketapp.livecricket.livescore.LiveMatch.ScoreCard.ScoreCradFragment;
import com.cricketapp.livecricket.livescore.R;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class LiveMatchDetailActivity extends AdsBaseActivity {

    CardView cvLiveLine, cvScoreCard;
    ImageView ivLiveLine_img, ivScoreCard_img;
    TextView tvLiveLine_text, tvScoreCard_text;
    LinearLayout llLiveLine, llScoreCard;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_match_detail);

        String LiveMatchtitle = getIntent().getStringExtra("LiveMatchtitle");
        ((TextView)findViewById(R.id.tvTitle)).setText(LiveMatchtitle);


        cvLiveLine = findViewById(R.id.cvLiveLine);
        cvScoreCard = findViewById(R.id.cvScoreCard);
        ivLiveLine_img = findViewById(R.id.ivLiveLine_img);
        ivScoreCard_img = findViewById(R.id.ivScoreCard_img);
        tvLiveLine_text = findViewById(R.id.tvLiveLine_text);
        tvScoreCard_text = findViewById(R.id.tvScoreCard_text);
        llLiveLine = findViewById(R.id.llLiveLine);
        llScoreCard = findViewById(R.id.llScoreCard);

        findViewById(R.id.ivBack).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });


        tvScoreCard_text.setTextColor(getColor(R.color.black));
        llScoreCard.setBackgroundColor(getColor(R.color.white));
        ivScoreCard_img.setColorFilter(getColor(R.color.black), PorterDuff.Mode.SRC_IN);
        tvLiveLine_text.setTextColor(getColor(R.color.white));
        llLiveLine.setBackground(getDrawable(R.drawable.ic_blue_gradiant_bg));
        ivLiveLine_img.setColorFilter(getColor(R.color.white), PorterDuff.Mode.SRC_IN);
        loadFragment(new LiveLineFragment());

        cvLiveLine.setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    tvScoreCard_text.setTextColor(getColor(R.color.black));
                    llScoreCard.setBackgroundColor(getColor(R.color.white));
                    ivScoreCard_img.setColorFilter(getColor(R.color.black), PorterDuff.Mode.SRC_IN);
                    tvLiveLine_text.setTextColor(getColor(R.color.white));
                    llLiveLine.setBackground(getDrawable(R.drawable.ic_blue_gradiant_bg));
                    ivLiveLine_img.setColorFilter(getColor(R.color.white), PorterDuff.Mode.SRC_IN);
                    loadFragment(new LiveLineFragment());
                }
            }, MAIN_CLICK);
        });
        cvScoreCard.setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    tvLiveLine_text.setTextColor(getColor(R.color.black));
                    llLiveLine.setBackgroundColor(getColor(R.color.white));
                    ivLiveLine_img.setColorFilter(getColor(R.color.black), PorterDuff.Mode.SRC_IN);
                    tvScoreCard_text.setTextColor(getColor(R.color.white));
                    llScoreCard.setBackground(getDrawable(R.drawable.ic_blue_gradiant_bg));
                    ivScoreCard_img.setColorFilter(getColor(R.color.white), PorterDuff.Mode.SRC_IN);
                    loadFragment(new ScoreCradFragment());
                }
            }, MAIN_CLICK);
        });
    }

    private void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.flLivematch, fragment);
        transaction.commit();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}