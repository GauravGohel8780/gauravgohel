package com.cricketapp.livecricket.livescore.Auction;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;


import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.widget.TextView;

import com.cricketapp.livecricket.livescore.Ads_Common.AdsBaseActivity;
import com.cricketapp.livecricket.livescore.IccRanking.IccRankingAdapter;
import com.cricketapp.livecricket.livescore.R;
import com.google.android.material.tabs.TabLayout;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class AuctionDitailActivity extends AdsBaseActivity {
    String intentAuction;

    TabLayout tabLayout;
    ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auction_ditail);



        intentAuction = getIntent().getStringExtra("Auction");

        if (intentAuction.equals("SoldPlayer")) {
            ((TextView) findViewById(R.id.tvTitle)).setText(getResources().getString(R.string.soldplayer));
        } else if (intentAuction.equals("UnsoldPlayer")) {
            ((TextView) findViewById(R.id.tvTitle)).setText(getResources().getString(R.string.unsoldplayer));
        }

        findViewById(R.id.ivBack).setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);

        });

        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        viewPager = (ViewPager) findViewById(R.id.viewPager);

        tabLayout.addTab(tabLayout.newTab().setText(getResources().getString(R.string.team)));
        tabLayout.addTab(tabLayout.newTab().setText(getResources().getString(R.string.better)));
        tabLayout.addTab(tabLayout.newTab().setText(getResources().getString(R.string.wicketkeeper)));
        tabLayout.addTab(tabLayout.newTab().setText(getResources().getString(R.string.allrounders)));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        final AuctionViewPagerAdapter adapter = new AuctionViewPagerAdapter(this, getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}