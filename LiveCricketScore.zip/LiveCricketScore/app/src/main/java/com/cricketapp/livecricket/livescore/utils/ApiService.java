package com.cricketapp.livecricket.livescore.utils;

import com.cricketapp.livecricket.livescore.Auction.ActionModel.AuctionDitailApiResponse;
import com.cricketapp.livecricket.livescore.IPLList.IplListAipRespons;
import com.cricketapp.livecricket.livescore.IccRanking.ApiModel.IccRankingApiResponse;
import com.cricketapp.livecricket.livescore.LiveMatch.LiveMatchAipRespons;
import com.cricketapp.livecricket.livescore.LiveMatch.ScoreCard.ScoreCardAipRespons;
import com.cricketapp.livecricket.livescore.Schedule.UpcomingAipRespons;
import com.cricketapp.livecricket.livescore.TeamandSquad.TeamAndSquadAipRespons;
import com.cricketapp.livecricket.livescore.Winner.WinnerApiResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiService {
    @FormUrlEncoded
    @POST("api/v1/saveRecord/list/")
    Call<IccRankingApiResponse> getIccRankingData(@Field("vName") String vName);

    @FormUrlEncoded
    @POST("api/v1/saveRecord/list/")
    Call<IplListAipRespons> getIplListData(@Field("vName") String vName);

    @FormUrlEncoded
    @POST("api/v1/saveRecord/list/")
    Call<TeamAndSquadAipRespons> getTeamAndSquadData(@Field("vName") String vName);

    @FormUrlEncoded
    @POST("api/v1/saveRecord/list/")
    Call<AuctionDitailApiResponse> getAuctionData(@Field("vName") String vName);


    @FormUrlEncoded
    @POST("api/v1/saveRecord/list/")
    Call<WinnerApiResponse> getWinnerData(@Field("vName") String vName);

    @FormUrlEncoded
    @POST("api/v1/liveMatch/result")
    Call<UpcomingAipRespons> getTopRatedMovies(@Field("vStart") String vStart, @Field("vEnd") String vEnd);

    @POST("api/v1/schedule/details")
    Call<UpcomingAipRespons> getScheduleDetails();

    @POST("api/v1/liveMatch/details")
    Call<LiveMatchAipRespons> getLiveMatchDetails();

    @FormUrlEncoded
    @POST("api/v1/liveMatch/scoreCard")
    Call<ScoreCardAipRespons> getScoreCardData(@Field("MatchId") String vName);

}


