package com.cricketapp.livecricket.livescore.TeamandSquad;

import android.content.Context;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.cricketapp.livecricket.livescore.Auction.AllRoundersAuction.AllRoundersAuctionFragment;
import com.cricketapp.livecricket.livescore.Auction.BatterAuction.BatterAuctionFragment;
import com.cricketapp.livecricket.livescore.Auction.TeamAuction.TeamAuctionFragment;
import com.cricketapp.livecricket.livescore.Auction.WicketkeeperAuction.WicketkeeperAuctionFragment;
import com.cricketapp.livecricket.livescore.TeamandSquad.BattingPlayer.BattingPlayerFragment;
import com.cricketapp.livecricket.livescore.TeamandSquad.BowlingPlayer.BowlingPlayerFragment;
import com.cricketapp.livecricket.livescore.TeamandSquad.InformationPlayer.InformationPlayerFragment;

public class TeamAndSquadViewPagerAdapter extends FragmentPagerAdapter {

    private Context myContext;
    int totalTabs;

    public TeamAndSquadViewPagerAdapter(Context context, FragmentManager fm, int totalTabs) {
        super(fm);  
        myContext = context;  
        this.totalTabs = totalTabs;  
    }  
  
    // this is for fragment tabs  
    @Override  
    public Fragment getItem(int position) {
        switch (position) {  
            case 0:
                InformationPlayerFragment informationPlayerFragment = new InformationPlayerFragment();
                return informationPlayerFragment;
            case 1:
                BattingPlayerFragment battingPlayerFragment = new BattingPlayerFragment();
                return battingPlayerFragment;
            case 2:
                BowlingPlayerFragment bowlingPlayerFragment = new BowlingPlayerFragment();
                return bowlingPlayerFragment;
            default:  
                return null;  
        }  
    }
    @Override  
    public int getCount() {  
        return totalTabs;  
    }  
}  