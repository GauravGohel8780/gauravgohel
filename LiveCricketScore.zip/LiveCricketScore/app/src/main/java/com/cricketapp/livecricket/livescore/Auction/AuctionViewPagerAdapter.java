package com.cricketapp.livecricket.livescore.Auction;

import android.content.Context;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.cricketapp.livecricket.livescore.Auction.AllRoundersAuction.AllRoundersAuctionFragment;
import com.cricketapp.livecricket.livescore.Auction.BatterAuction.BatterAuctionFragment;
import com.cricketapp.livecricket.livescore.Auction.TeamAuction.TeamAuctionFragment;
import com.cricketapp.livecricket.livescore.Auction.WicketkeeperAuction.WicketkeeperAuctionFragment;
import com.cricketapp.livecricket.livescore.IccRanking.AllRounders.AllRoundersFragment;
import com.cricketapp.livecricket.livescore.IccRanking.Bowler.BowlerFragment;
import com.cricketapp.livecricket.livescore.IccRanking.Team.TeamFragment;
import com.cricketapp.livecricket.livescore.IccRanking.batter.BatterFragment;

public class AuctionViewPagerAdapter extends FragmentPagerAdapter {
    private Context myContext;
    int totalTabs;

    public AuctionViewPagerAdapter(Context context, FragmentManager fm, int totalTabs) {
        super(fm);  
        myContext = context;  
        this.totalTabs = totalTabs;  
    }  
  

    @Override  
    public Fragment getItem(int position) {
        switch (position) {  
            case 0:
                TeamAuctionFragment teamAuctionFragment = new TeamAuctionFragment();
                return teamAuctionFragment;
            case 1:
                BatterAuctionFragment batterAuctionFragment = new BatterAuctionFragment();
                return batterAuctionFragment;
            case 2:
                WicketkeeperAuctionFragment wicketkeeperAuctionFragment = new WicketkeeperAuctionFragment();
                return wicketkeeperAuctionFragment;
            case 3:
                AllRoundersAuctionFragment allRoundersAuctionFragment = new AllRoundersAuctionFragment();
                return allRoundersAuctionFragment;
            default:  
                return null;  
        }  
    }
    @Override  
    public int getCount() {  
        return totalTabs;  
    }  
}  