package com.cricketapp.livecricket.livescore.LiveMatch.ScoreCard;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.cricketapp.livecricket.livescore.R;
import com.cricketapp.livecricket.livescore.utils.ApiService;
import com.cricketapp.livecricket.livescore.utils.RetrofitClient;

import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Progress2Fragment extends Fragment {

    RecyclerView rvprogrees2;
    int LiveMatchId;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_progress2, container, false);
        LiveMatchId = requireActivity().getIntent().getIntExtra("LiveMatchId", 0);

        ApiService apiService = RetrofitClient.getApiService();
        Call<ScoreCardAipRespons> call = apiService.getScoreCardData(String.valueOf(LiveMatchId));
        call.enqueue(new Callback<ScoreCardAipRespons>() {
            @Override
            public void onResponse(Call<ScoreCardAipRespons> call, Response<ScoreCardAipRespons> response) {
                if (response.isSuccessful()) {
                    view.findViewById(R.id.mainProgress).setVisibility(View.GONE);
                    ScoreCardAipRespons scoreCardApiResponse = response.body();
                    ArrayList<ProgressModel> teamAPlayers = new ArrayList<>();

                    for (ProgressModel item : scoreCardApiResponse.getData()) {
                        if (item.getvTeamSide().equals("Team B")) {
                            teamAPlayers.add(item);
                        }
                    }

                    rvprogrees2 = view.findViewById(R.id.rvprogrees2);
                    Progress2Adapter adapter = new Progress2Adapter(teamAPlayers);
                    rvprogrees2.setLayoutManager(new LinearLayoutManager(getContext()));
                    rvprogrees2.setAdapter(adapter);
                } else {
                    try {
                        Log.e("www", "Response not successful. Code: " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(Call<ScoreCardAipRespons> call, Throwable t) {
                Log.e("www", "Failed to fetch schedule details: " + t.getMessage());
            }
        });


        return view;
    }


    public class Progress2Adapter extends RecyclerView.Adapter<Progress2Adapter.ViewHolder> {
        private ArrayList<ProgressModel> items;

        public Progress2Adapter(ArrayList<ProgressModel> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.scorecard_layout, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            ProgressModel item = items.get(position);

            holder.tvPlayername.setText("" + item.getvPlayerName());
            holder.tvR.setText("" + item.getiRuns());
            holder.tvB.setText("" + item.getiBalls());
            holder.tv4s.setText("" + item.getIfour());
            holder.tv6s.setText("" + item.getIsix());
            if (item.getSr() == null){
                holder.tvSR.setText("0.00");
            }else {
                holder.tvSR.setText("" + String.format("%.2f", item.getSr()));
            }

            if (item.getVoutby().isEmpty()) {
                holder.tvVoutby.setVisibility(View.GONE);
                holder.vView.setVisibility(View.GONE);
            } else {
                holder.tvVoutby.setText("" + item.getVoutby());
            }


            holder.tvVoutby.setSelected(true);

            Glide.with(getActivity()).load(item.getvPlayerImage()).into(holder.ivPlayerimg);

        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvPlayername, tvR, tvB, tv4s, tv6s, tvSR, tvVoutby;
            ImageView ivPlayerimg;
            View vView;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvPlayername = itemView.findViewById(R.id.tvPlayername);
                tvR = itemView.findViewById(R.id.tvR);
                tvB = itemView.findViewById(R.id.tvB);
                tv4s = itemView.findViewById(R.id.tv4s);
                tv6s = itemView.findViewById(R.id.tv6s);
                tvSR = itemView.findViewById(R.id.tvSR);
                ivPlayerimg = itemView.findViewById(R.id.ivPlayerimg);
                tvVoutby = itemView.findViewById(R.id.tvVoutby);
                vView = itemView.findViewById(R.id.vView);
            }
        }
    }
}