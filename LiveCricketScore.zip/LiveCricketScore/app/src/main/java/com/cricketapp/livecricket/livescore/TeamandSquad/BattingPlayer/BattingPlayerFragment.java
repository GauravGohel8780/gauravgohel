package com.cricketapp.livecricket.livescore.TeamandSquad.BattingPlayer;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.MyApplication.sharedPreferencesHelper;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.cricketapp.livecricket.livescore.R;
import com.cricketapp.livecricket.livescore.TeamandSquad.BowlingPlayer.BowlingPlayerFragment;
import com.cricketapp.livecricket.livescore.TeamandSquad.TeamAndSquadAipRespons;
import com.cricketapp.livecricket.livescore.TeamandSquad.TeamandSquadDetailActivity;
import com.cricketapp.livecricket.livescore.TeamandSquad.TeamandSquadDetailModel;
import com.cricketapp.livecricket.livescore.TeamandSquad.TeamandSquadModel;
import com.cricketapp.livecricket.livescore.Venues.VenuesActivity;
import com.cricketapp.livecricket.livescore.Venues.VenuesModel;
import com.cricketapp.livecricket.livescore.utils.ApiService;
import com.cricketapp.livecricket.livescore.utils.RetrofitClient;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.utils.AdUtils;

import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BattingPlayerFragment extends Fragment {

    RecyclerView rvbatingplayer;
    ArrayList<BattingPlayerModel> arrayList = new ArrayList<>();

    String teamPlayerName;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_batting_player, container, false);

        teamPlayerName = getActivity().getIntent().getStringExtra("teamPlayerName");


        ApiService apiService = RetrofitClient.getApiService();
        Call<TeamAndSquadAipRespons> call = apiService.getTeamAndSquadData("team&sqaud");
        call.enqueue(new Callback<TeamAndSquadAipRespons>() {
            @Override
            public void onResponse(Call<TeamAndSquadAipRespons> call, Response<TeamAndSquadAipRespons> response) {
                if (response.isSuccessful()) {
                    view.findViewById(R.id.mainProgress).setVisibility(View.GONE);
                    TeamAndSquadAipRespons responseData = response.body();
                    ArrayList<TeamandSquadModel> teamList = responseData.getData();
                    ArrayList<TeamandSquadDetailModel> teamandSquadDetailModels = teamList.get(0).getArrTeamePlayer();
                    arrayList = teamandSquadDetailModels.get(0).getArrBatting();
                    for (TeamandSquadDetailModel item : teamList.get(0).getArrTeamePlayer()) {
                        if (item.getvName().equals(teamPlayerName)) {
                            rvbatingplayer = view.findViewById(R.id.rvbatingplayer);
                            BattingPlayerAdapter adapter = new BattingPlayerAdapter(arrayList);
                            rvbatingplayer.setLayoutManager(new LinearLayoutManager(getContext()));
                            rvbatingplayer.setAdapter(adapter);
                        }
                    }

                    Log.w("--apiResponse--", "" + new GsonBuilder().setPrettyPrinting().create().toJson(arrayList));

                } else {
                    try {
                        Log.e("--apiResponse--", "Error: PlanDetailResponse " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(Call<TeamAndSquadAipRespons> call, Throwable t) {
                Log.e("--apiResponse--", "Error:" + t.getMessage());
            }
        });


        return view;
    }


    public class BattingPlayerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private ArrayList<BattingPlayerModel> items;

        public BattingPlayerAdapter(ArrayList<BattingPlayerModel> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(getContext()).inflate(R.layout.batting_player_layout, parent, false);
            return new ViewHolder(view);

        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

            BattingPlayerModel item = (BattingPlayerModel) items.get(position);
            if (item.getYear().isEmpty()) {
                ((ViewHolder) holder).tvTitleName.setText("Total Match : " + item.getvTotalMatch());
            } else {
                ((ViewHolder) holder).tvTitleName.setText("Year : " + item.getYear() + "  Match : " + item.getvTotalMatch());
            }
            ((ViewHolder) holder).tvNotOut.setText("" + item.getvNotOut());
            ((ViewHolder) holder).tvRun.setText("" + item.getvRun());
            ((ViewHolder) holder).tvAve.setText("" + item.getvAve());
            ((ViewHolder) holder).tvHS.setText("" + item.getvHs());
            ((ViewHolder) holder).tvST.setText("" + item.getvSt());
            ((ViewHolder) holder).tvBallFaced.setText("" + item.getvBallFaced());
            ((ViewHolder) holder).tvSR.setText("" + item.getvSr());
            ((ViewHolder) holder).tv100.setText("" + item.getV100());
            ((ViewHolder) holder).tv50.setText("" + item.getV50());
            ((ViewHolder) holder).tv4s.setText("" + item.getV4s());
            ((ViewHolder) holder).tv6s.setText("" + item.getV6s());
            ((ViewHolder) holder).tvCT.setText("" + item.getvCt());
        }

        @Override
        public int getItemCount() {
            return items.size();
        }


        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvTitleName, tvNotOut, tvRun, tvAve, tvHS, tvST, tvBallFaced, tvSR, tv100, tv50, tv4s, tv6s, tvCT;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvTitleName = itemView.findViewById(R.id.tvTitleName);
                tvNotOut = itemView.findViewById(R.id.tvNotOut);
                tvRun = itemView.findViewById(R.id.tvRun);
                tvAve = itemView.findViewById(R.id.tvAve);
                tvHS = itemView.findViewById(R.id.tvHS);
                tvST = itemView.findViewById(R.id.tvST);
                tvBallFaced = itemView.findViewById(R.id.tvBallFaced);
                tvSR = itemView.findViewById(R.id.tvSR);
                tv100 = itemView.findViewById(R.id.tv100);
                tv50 = itemView.findViewById(R.id.tv50);
                tv4s = itemView.findViewById(R.id.tv4s);
                tv6s = itemView.findViewById(R.id.tv6s);
                tvCT = itemView.findViewById(R.id.tvCT);
            }
        }
    }
}