package com.cricketapp.livecricket.livescore.IccRanking.ApiModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ObjPlayer {

@SerializedName("objBatter")
@Expose
private ObjBatter objBatter;
@SerializedName("objBowler")
@Expose
private ObjBowler objBowler;
@SerializedName("objAllRounder")
@Expose
private ObjAllRounder objAllRounder;

public ObjBatter getObjBatter() {
return objBatter;
}

public void setObjBatter(ObjBatter objBatter) {
this.objBatter = objBatter;
}

public ObjBowler getObjBowler() {
return objBowler;
}

public void setObjBowler(ObjBowler objBowler) {
this.objBowler = objBowler;
}

public ObjAllRounder getObjAllRounder() {
return objAllRounder;
}

public void setObjAllRounder(ObjAllRounder objAllRounder) {
this.objAllRounder = objAllRounder;
}

}