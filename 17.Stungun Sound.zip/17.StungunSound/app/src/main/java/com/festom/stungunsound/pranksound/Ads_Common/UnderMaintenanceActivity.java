package com.festom.stungunsound.pranksound.Ads_Common;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

import com.festom.stungunsound.pranksound.R;
import com.festom.stungunsound.pranksound.databinding.ActivityUnderMaintenanceBinding;
import com.iten.tenoku.utils.MyApplication;

import java.util.Random;

public class UnderMaintenanceActivity extends AdsBaseActivity {

    String TAG = getClass().getSimpleName();
    boolean doubleBackToExitPressedOnce = false;
    ActivityUnderMaintenanceBinding x;
    Boolean aBoolean;

    Activity activity;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        x = ActivityUnderMaintenanceBinding.inflate(getLayoutInflater());
        setContentView(x.getRoot());
        activity = this;

        int i = new Random().nextInt(3);
        Log.e(TAG, "onCreate: " + i);

        if (i == 1) {
            x.animationView.setAnimation(com.iten.tenoku.R.raw.app_update1);
            x.textTitle.setTextColor(getResources().getColor(R.color.app_update_1));
            x.textTitle.setText(getResources().getString(R.string.maintenance_1));
        } else if (i == 2) {
            x.animationView.setAnimation(com.iten.tenoku.R.raw.app_update2);
            x.textTitle.setTextColor(getResources().getColor(R.color.app_update_2));
            x.textTitle.setText(getResources().getString(R.string.maintenance_2));
        } else {
            x.animationView.setAnimation(com.iten.tenoku.R.raw.app_update3);
            x.textTitle.setTextColor(getResources().getColor(R.color.app_update_3));
            x.textTitle.setText(getResources().getString(R.string.maintenance_3));
        }
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        if (MyApplication.sharedPreferencesHelper.getExitScreen()) {
            final Dialog dialog = new Dialog(this);
            dialog.requestWindowFeature(1);
            dialog.setCancelable(false);
            dialog.setContentView(R.layout.exit_dailog_layout);
            Window window = dialog.getWindow();

            window.setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
            aBoolean = getIntent().getBooleanExtra("Under", false);
            ((TextView) dialog.findViewById(R.id.tvYes)).setOnClickListener(new View.OnClickListener() {
                @Override
                public final void onClick(View view) {
                    dialog.dismiss();
                    finishAffinity();
                    System.exit(0);
                }
            });
            ((TextView) dialog.findViewById(R.id.tvNo)).setOnClickListener(new View.OnClickListener() {
                @Override
                public final void onClick(View view) {
                    if (Boolean.TRUE.equals(aBoolean)) {
                        startActivity(new Intent(activity, UnderMaintenanceActivity.class));
                    }
                }
            });
            dialog.show();
        } else {
            promises_DoubleExit();
        }
    }

    public void promises_DoubleExit() {
        if (!doubleBackToExitPressedOnce) {
            doubleBackToExitPressedOnce = true;
            Toast.makeText(this, "Please click BACK again to exit.", Toast.LENGTH_SHORT).show();
            new Handler().postDelayed(() -> doubleBackToExitPressedOnce = false, 2000);

        } else {
            doubleBackToExitPressedOnce = false;
            finishAffinity();
        }
    }
}