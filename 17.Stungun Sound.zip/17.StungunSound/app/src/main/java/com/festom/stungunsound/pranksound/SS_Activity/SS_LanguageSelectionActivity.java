package com.festom.stungunsound.pranksound.SS_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.festom.stungunsound.pranksound.SS_Adapter.SS_LanguageSelectionAdapter;
import com.festom.stungunsound.pranksound.Ads_Common.AdsBaseActivity;
import com.festom.stungunsound.pranksound.R;
import com.festom.stungunsound.pranksound.SS_model.SS_LanguageModel;
import com.festom.stungunsound.pranksound.SS_preference.SS_SharePref;
import com.festom.stungunsound.pranksound.SS_util.SS_LanguageUtil;
import com.festom.stungunsound.pranksound.SS_util.SS_Utils;
import com.google.gson.Gson;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.util.ArrayList;

public class SS_LanguageSelectionActivity extends AdsBaseActivity {

    RecyclerView rvLanguages;
    ArrayList<SS_LanguageModel> arrayList = new ArrayList<>();
    SS_LanguageSelectionAdapter adapter;
    TextView tvNext;
    TextView tvSkip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language_selection);
        SS_Utils.setStatusBarGradiant(this);

        rvLanguages = findViewById(R.id.rvLanguages);
        tvNext = findViewById(R.id.tvNext);
        tvSkip = findViewById(R.id.tvSkip);

        rvLanguages.setLayoutManager(new LinearLayoutManager(this));

        arrayList.add(new SS_LanguageModel(R.drawable.ic_english, getString(R.string.English), "en"));
        arrayList.add(new SS_LanguageModel(R.drawable.ic_india_flag, getString(R.string.hindi), "hi"));
        arrayList.add(new SS_LanguageModel(R.drawable.ic_afrikaans, getString(R.string.afrikaans), "af"));
        arrayList.add(new SS_LanguageModel(R.drawable.ic_chinese, getString(R.string.Chinese), "zh"));
        arrayList.add(new SS_LanguageModel(R.drawable.ic_german, getString(R.string.German), "de"));
        arrayList.add(new SS_LanguageModel(R.drawable.ic_spanish, getString(R.string.spanish), "es"));
        arrayList.add(new SS_LanguageModel(R.drawable.ic_french, getString(R.string.french), "fr"));
        arrayList.add(new SS_LanguageModel(R.drawable.ic_vietnam, getString(R.string.vietnam), "vi"));
        arrayList.add(new SS_LanguageModel(R.drawable.ic_portugal, getString(R.string.portugal), "pt"));


        Log.d("--languages--", "onCreate: MainAct. " + new Gson().toJson(arrayList));

        adapter = new SS_LanguageSelectionAdapter(this, arrayList);
        rvLanguages.setAdapter(adapter);


        tvNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(SS_LanguageSelectionActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        SS_SharePref.saveSelectedPosition(SS_LanguageSelectionActivity.this, adapter.selectedPosition);
                        SS_LanguageUtil.setLanguage(SS_LanguageSelectionActivity.this);
                        Intent intent = new Intent(SS_LanguageSelectionActivity.this, SS_MainActivity.class);
                        SS_SharePref.putPrefLanguage(SS_LanguageSelectionActivity.this, arrayList.get(adapter.selectedPosition).getLangCode());
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });

        int savedSelectedPosition = SS_SharePref.loadSelectedPosition(this);
        if (savedSelectedPosition != -1) {

            adapter.selectedPosition = savedSelectedPosition;

            Log.d("--selection--", "onClick: MainActivity " + savedSelectedPosition);

        } else {
            adapter.selectedPosition = 0;
        }

        tvSkip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(SS_LanguageSelectionActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(SS_LanguageSelectionActivity.this, SS_MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }, MAIN_CLICK);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}