package com.festom.clocksound.pranksound.CS_util;


import com.festom.clocksound.pranksound.CS_model.CS_FeedBackResponseModel;
import com.festom.clocksound.pranksound.CS_model.CS_FeedbackRequestModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface CS_ApiService {

    @POST("api/v1/feedBack/save")
    Call<CS_FeedBackResponseModel> feedbackUser(@Body CS_FeedbackRequestModel request);
}