package com.festom.clocksound.pranksound.CS_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import com.festom.clocksound.pranksound.CS_Adapter.CS_IntroPagerAdapter;
import com.festom.clocksound.pranksound.Ads_Common.AdsBaseActivity;
import com.festom.clocksound.pranksound.R;
import com.festom.clocksound.pranksound.CS_fragement.CS_FirstIntroFragment;
import com.festom.clocksound.pranksound.CS_fragement.CS_SecondIntroFragment;
import com.festom.clocksound.pranksound.CS_fragement.CS_ThirdIntroFragment;
import com.festom.clocksound.pranksound.CS_preference.CS_SharePref;
import com.festom.clocksound.pranksound.CS_util.CS_CubeOutTransformer;
import com.festom.clocksound.pranksound.CS_util.CS_Utils;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class CS_IntroActivity extends AdsBaseActivity {
    ViewPager vpIntro;
    CS_IntroPagerAdapter introPagerAdapter;
    int focusPos = 0;
    ImageView ivNextBtn;
    TextView tvDetail;
    private LinearLayout llDotIndicator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);
        CS_Utils.setStatusBarGradiant(this);

        vpIntro = findViewById(R.id.vpIntro);
        llDotIndicator = findViewById(R.id.llDotIndicator);

        ivNextBtn = findViewById(R.id.ivNextBtn);
        tvDetail = findViewById(R.id.tvDetail);

        introPagerAdapter = new CS_IntroPagerAdapter(getSupportFragmentManager());
        vpIntro.setPageTransformer(true, new CS_CubeOutTransformer());
        introPagerAdapter.add(new CS_FirstIntroFragment());
        introPagerAdapter.add(new CS_SecondIntroFragment());
        introPagerAdapter.add(new CS_ThirdIntroFragment());
        vpIntro.setAdapter(introPagerAdapter);

        tvDetail.setText(R.string.intro_text_1);


        addIndicators(introPagerAdapter.getCount());

        ivNextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(CS_IntroActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        int currentItem = vpIntro.getCurrentItem();
                        int lastItem = introPagerAdapter.getCount() - 1;

                        if (currentItem == lastItem) {
                            gotoLanguageSelection();
                        } else {
                            vpIntro.setCurrentItem(currentItem + 1);
                        }
                    }
                }, MAIN_CLICK);
            }
        });

        vpIntro.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                CS_IntroActivity.this.focusPos = position;
                int i = CS_IntroActivity.this.focusPos;
                if (i == 0) {
                    tvDetail.setText(R.string.intro_text_1);
                } else if (i == 1) {
                    tvDetail.setText(R.string.intro_text_2);
                } else {
                    tvDetail.setText(R.string.intro_text_3);
                }
            }

            @Override
            public void onPageSelected(int position) {
                updateIndicators(position);
                vpIntro.setCurrentItem(position);
                Log.d("--viewpager--", "onPageSelected: getCurrentItem " + vpIntro.getCurrentItem());
                Log.d("--viewpager--", "onPageSelected: position " + position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private void gotoLanguageSelection() {
        startActivity(new Intent(CS_IntroActivity.this, CS_LanguageSelectionActivity.class));
        CS_SharePref.setIsFirstLaunch(CS_IntroActivity.this, true);
        finish();
    }


    private void addIndicators(int count) {
        for (int i = 0; i < count; i++) {
            ImageView indicator = new ImageView(this);
            indicator.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_selected_dot));
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            layoutParams.setMargins(8, 0, 8, 0);
            llDotIndicator.addView(indicator, layoutParams);
        }
        updateIndicators(0);
    }

    private void updateIndicators(int position) {
        for (int i = 0; i < llDotIndicator.getChildCount(); i++) {
            ImageView indicator = (ImageView) llDotIndicator.getChildAt(i);
            if (position == 0) {
                indicator.setImageDrawable(ContextCompat.getDrawable(this,
                        i == position ? R.drawable.ic_selected_dot : R.drawable.ic_unselected_dot));
            } else if (position == 1) {
                indicator.setImageDrawable(ContextCompat.getDrawable(this,
                        i == position ? R.drawable.ic_selected_dot : R.drawable.ic_unselected_dot));
            } else {
                indicator.setImageDrawable(ContextCompat.getDrawable(this,
                        i == position ? R.drawable.ic_selected_dot : R.drawable.ic_unselected_dot));
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}