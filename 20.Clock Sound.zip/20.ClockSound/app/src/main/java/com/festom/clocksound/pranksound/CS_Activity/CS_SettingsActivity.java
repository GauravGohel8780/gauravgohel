package com.festom.clocksound.pranksound.CS_Activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.SwitchCompat;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import com.festom.clocksound.pranksound.Ads_Common.AdsBaseActivity;
import com.festom.clocksound.pranksound.R;
import com.festom.clocksound.pranksound.CS_util.CS_LanguageUtil;
import com.festom.clocksound.pranksound.CS_util.CS_Utils;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class CS_SettingsActivity extends AdsBaseActivity {

    SwitchCompat switchVibrate;
    SharedPreferences sharedPreferences;
    ConstraintLayout clLanguage;
    ConstraintLayout clShareApp;
    ConstraintLayout clRateUs;
    ConstraintLayout clPolicy;
    ConstraintLayout clFeedback;

    private float userrate = 0;
    RatingBar rb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        CS_LanguageUtil.setLanguage(CS_SettingsActivity.this);
        switchVibrate = findViewById(R.id.switchVibrate);

        clLanguage = findViewById(R.id.clLanguage);
        clShareApp = findViewById(R.id.cShareApp);
        clRateUs = findViewById(R.id.clRateUs);
        clPolicy = findViewById(R.id.clPolicy);
        clFeedback = findViewById(R.id.clFeedback);


        CS_Utils.setStatusBarGradiant(this);


        sharedPreferences = getSharedPreferences("spCheck", MODE_PRIVATE);
        boolean isSwitched = sharedPreferences.getBoolean("isVibrate", false);
        switchVibrate.setChecked(isSwitched);
        setSwitchStyle(isSwitched);

        switchVibrate.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                getInstance(CS_SettingsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        SharedPreferences sharedPreferences = getSharedPreferences("spCheck", MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putBoolean("isVibrate", isChecked);
                        editor.apply();

                        setSwitchStyle(isChecked);
                    }
                }, MAIN_CLICK);
            }
        });

        findViewById(R.id.cvBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(CS_SettingsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

        clLanguage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(CS_SettingsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(CS_SettingsActivity.this, CS_LanguageSelectionActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }, MAIN_CLICK);
            }
        });

        clShareApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("text/plain");
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, R.string.app_name);
                    String shareMessage = "\nLet me recommend you this application\n\n";
                    shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + getPackageName() + "\n\n";
                    shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                    startActivity(Intent.createChooser(shareIntent, "choose one"));
                } catch (Exception e) {

                }
            }
        });

        clRateUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Dialog dialog = new Dialog(CS_SettingsActivity.this, R.style.customDialog);
                dialog.setContentView(R.layout.dialog_rate_us);

                dialog.getWindow().setGravity(Gravity.CENTER);
                dialog.getWindow().setBackgroundDrawable(ContextCompat.getDrawable(CS_SettingsActivity.this, R.color.bg_app_20));

                dialog.getWindow().setStatusBarColor(ContextCompat.getColor(CS_SettingsActivity.this, R.color.bg_app_20));
                dialog.show();

                rb = (RatingBar) dialog.findViewById(R.id.ratebtn);

                TextView tvDone = dialog.findViewById(R.id.btnDone);

                rb.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                    @Override
                    public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                        userrate = rating;
                    }
                });


                tvDone.setOnClickListener(view -> {
                    if (userrate >= 4) {
                        dialog.dismiss();
                        Uri uri = Uri.parse("market://details?id=" + getPackageName());
                        Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
                        try {
                            startActivity(myAppLinkToMarket);
                        } catch (ActivityNotFoundException e) {
                            Toast.makeText(CS_SettingsActivity.this, " unable to find market app", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        getInstance(CS_SettingsActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                dialog.dismiss();
                                CS_Utils.setStatusBarGradiant(CS_SettingsActivity.this);
                                Intent intent1 = new Intent(CS_SettingsActivity.this, CS_FeedbackActivity.class);
                                startActivity(intent1);
                            }
                        }, MAIN_CLICK);
                    }
                });

                dialog.findViewById(R.id.ic_close).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        getInstance(CS_SettingsActivity.this).ShowAd(new HandleClick() {
                            @Override
                            public void Show(boolean adShow) {
                                dialog.dismiss();
                                CS_Utils.setStatusBarGradiant(CS_SettingsActivity.this);
                            }
                        }, MAIN_CLICK);
                    }
                });
            }
        });

        clFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(CS_SettingsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(CS_SettingsActivity.this, CS_FeedbackActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }, MAIN_CLICK);
            }
        });

        clPolicy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(CS_SettingsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(CS_SettingsActivity.this, CS_PrivacyActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }, MAIN_CLICK);
            }
        });
    }

    private void setSwitchStyle(boolean isChecked) {
        if (isChecked) {
            setSwitchCustomStyle(R.drawable.ic_thumb, R.drawable.bg_switch_track_checked);
        } else {
            setSwitchCustomStyle(R.drawable.ic_thumb, R.drawable.bg_switch_track);
        }
    }

    private void setSwitchCustomStyle(int thumbDrawableRes, int trackDrawableRes) {

        Drawable thumbDrawable = ContextCompat.getDrawable(this, thumbDrawableRes);
        Drawable trackDrawable = ContextCompat.getDrawable(this, trackDrawableRes);

        switchVibrate.setThumbDrawable(thumbDrawable);
        switchVibrate.setTrackDrawable(trackDrawable);

    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}