package com.iten.tenoku.ad.HandleClick;

public interface HandleClick {
    void Show(boolean adShow);
}
