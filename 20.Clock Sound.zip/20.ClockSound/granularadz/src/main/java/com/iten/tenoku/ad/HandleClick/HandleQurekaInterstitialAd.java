package com.iten.tenoku.ad.HandleClick;

public interface HandleQurekaInterstitialAd {
    void Show(boolean adShow);
}
