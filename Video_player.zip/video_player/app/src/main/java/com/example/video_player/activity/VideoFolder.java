package com.example.video_player.activity;

import static com.example.video_player.activity.VideoPlayer.convertIntoTime;

import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.PorterDuff;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.video_player.R;
import com.example.video_player.VideoModel;
import com.example.video_player.adapter.VideosAdapter;

import java.io.File;
import java.util.ArrayList;
import java.util.Locale;


public class VideoFolder extends AppCompatActivity implements SearchView.OnQueryTextListener, View.OnLongClickListener {

    private static final String MY_SORT_PREF = "SortOrder";
    private RecyclerView recyclerView;
    private String name;
    private ArrayList<VideoModel> videoModelArrayList = new ArrayList<>();
    ArrayList<Uri> uris = new ArrayList<>();
    private VideosAdapter videosAdapter;


    Toolbar toolbar;
    public boolean is_selectable = false;
    TextView countText;
    ArrayList<VideoModel> selectionArrayList = new ArrayList<>();
    int count = 0;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_folder);

        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.black));

        recyclerView = findViewById(R.id.video_recyclerview);
        countText = findViewById(R.id.counter_textView);
        name = getIntent().getStringExtra("folderName");
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(getResources().getDrawable(R.drawable.go_back));
        int index = name.lastIndexOf("/");
        String onlyFolderName = name.substring(index + 1);
        countText.setText(onlyFolderName);

        loadVideos();


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_toolbar, menu);
        MenuItem menuItem = menu.findItem(R.id.search);
        SearchView searchView = (SearchView) menuItem.getActionView();
        ImageView ivClose = searchView.findViewById(androidx.appcompat.R.id.search_close_btn);
        ivClose.setColorFilter(ContextCompat.getColor(getApplicationContext(), R.color.white),
                PorterDuff.Mode.SRC_IN);
        searchView.setQueryHint("Search file name");
        searchView.setOnQueryTextListener(this);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        String input = newText.toLowerCase();
        ArrayList<VideoModel> searchList = new ArrayList<>();
        for (VideoModel model : videoModelArrayList) {
            if (model.getTitle().toLowerCase().contains(input)) {
                searchList.add(model);
            }
        }
        videosAdapter.updateSearchList(searchList);

        return false;
    }

    private void loadVideos() {
        videoModelArrayList = getallVideoFromFolder(this, name);
        if (name != null && videoModelArrayList.size() > 0) {
            videosAdapter = new VideosAdapter(videoModelArrayList, this);
            recyclerView.setAdapter(videosAdapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        } else {
            Toast.makeText(this, "can't find any videos", Toast.LENGTH_SHORT).show();
        }
    }

    private ArrayList<VideoModel> getallVideoFromFolder(Context context, String name) {
        SharedPreferences sharedPreferences = getSharedPreferences(MY_SORT_PREF, MODE_PRIVATE);
        String sort = sharedPreferences.getString("sorting", "sortByDate");
        String order = null;
        switch (sort) {
            case "sortByDate":
                order = MediaStore.MediaColumns.DATE_ADDED + " ASC";
                break;

            case "sortByName":
                order = MediaStore.MediaColumns.DISPLAY_NAME + " ASC";
                break;

            case "sortBySize":
                order = MediaStore.MediaColumns.SIZE     + " DESC";
                break;
        }

        ArrayList<VideoModel> list = new ArrayList<>();

        Uri uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {

                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DATA,
                MediaStore.Video.Media.TITLE,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.HEIGHT,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
                MediaStore.Video.Media.RESOLUTION

        };

        String selection = MediaStore.Video.Media.DATA + " like?";
        String[] selectionArgs = new String[]{"%" + name + "%"};

        Cursor cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs, order);

        if (cursor != null) {
            while (cursor.moveToNext()) {

                String id = cursor.getString(0);
                String path = cursor.getString(1);
                String title = cursor.getString(2);
                long size = cursor.getLong(3);
                String resolution = cursor.getString(4);
                int duration = cursor.getInt(5);
                String disName = cursor.getString(6);
                String bucked_display_name = cursor.getString(7);
                String width_height = cursor.getString(8);





                VideoModel files = new VideoModel(id, path, title, fileReadableSize(size), resolution, convertIntoTime(duration), disName, width_height);
                if (name.endsWith(bucked_display_name))
                    list.add(files);


            }
            cursor.close();
        }
        return list;
    }

    public static String fileReadableSize(long size){
        String s = "";
        long kilobyte = 1024;
        long megabyte = kilobyte * kilobyte;
        long gigabyte = megabyte * kilobyte;
        long terabyte = gigabyte * kilobyte;

        double kb = (double) size/kilobyte;
        double mb = kb / kilobyte;
        double gb = mb / kilobyte;
        double tb = gb / kilobyte;

        if (size<kilobyte){
            s=size+"bytes";
        }else if (size>=kilobyte && size< megabyte){
            s = String.format("%.2f", kb)+"KB";
        }else if (size>=megabyte && size< gigabyte){
            s = String.format("%.2f", mb)+"MB";
        }else if (size>=gigabyte && size< terabyte){
            s = String.format("%.2f", gb)+"GB";
        }else if (size>=terabyte ){
            s = String.format("%.2f", tb)+"tB";
        }

        return s;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        SharedPreferences.Editor editor = getSharedPreferences(MY_SORT_PREF, MODE_PRIVATE).edit();
        switch (item.getItemId()) {

            case R.id.sort_by_date:
                editor.putString("sorting", "sortByDate");
                editor.apply();
                this.recreate();
                break;

            case R.id.sort_by_name:
                editor.putString("sorting", "sortByName");
                editor.apply();
                this.recreate();
                break;

            case R.id.sort_by_size:
                editor.putString("sorting", "sortBySize");
                editor.apply();
                this.recreate();
                break;

            case R.id.refresh:
                refresh();
                break;

            case android.R.id.home:
                if (is_selectable) {
                    clearSelectingToolbar();
                    videosAdapter.notifyDataSetChanged();
                } else {
                    onBackPressed();
                }
                break;

            case R.id.delete_selected:
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        boolean isDeleted = selectedFile(selectionArrayList, true);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (isDeleted) {
                                    clearSelectingToolbar();
                                    refresh();
                                    Toast.makeText(VideoFolder.this, "Delete Success", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(VideoFolder.this, "Delete Fail     ", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

                    }
                });
                thread.start();
                break;

            case R.id.share_selected:
                boolean isSuccess = selectedFile(selectionArrayList, false);
                if (isSuccess) {
                    clearSelectingToolbar();
                    refresh();
                    Toast.makeText(this, "Loading", Toast.LENGTH_SHORT).show();
                }
                break;
        }

        return super.onOptionsItemSelected(item);
    }


    private void refresh() {
        if (name != null && videoModelArrayList.size() > 0) {
            videoModelArrayList.clear();

            loadVideos();
            videosAdapter.notifyDataSetChanged();
            Toast.makeText(VideoFolder.this, "Refreshed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Folder is Empty", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onLongClick(View view) {
        toolbar.getMenu().clear();
        toolbar.inflateMenu(R.menu.item_selected_menu);
        is_selectable = true;
        videosAdapter.notifyDataSetChanged();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(getResources().getDrawable(R.drawable.go_back));
        return true;
    }

    public void prepareSelection(View view, int position) {
        if (((CheckBox) view).isChecked()) {
            selectionArrayList.add(videoModelArrayList.get(position));
            count = count + 1;
            updateCount(count);
        } else {
            selectionArrayList.remove(videoModelArrayList.get(position));
            count = count - 1;
            updateCount(count);
        }
    }

    private void updateCount(int counts) {
        if (counts == 0) {
            countText.setText("0  selected");
        } else {
            countText.setText(counts + " selected");
        }
    }

    private void clearSelectingToolbar() {
        is_selectable = false;
        toolbar.getMenu().clear();
        toolbar.inflateMenu(R.menu.main_toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(getResources().getDrawable(R.drawable.go_back));
        int index = name.lastIndexOf("/");
        String onlyFolderName = name.substring(index + 1);
        countText.setText(onlyFolderName);
        count = 0;
        selectionArrayList.clear();
    }

    private boolean selectedFile(ArrayList<VideoModel> list, boolean canIDelete) {
        for (int i = 0; i < list.size(); i++) {
            String id = list.get(i).getId();
            String path = list.get(i).getPath();
            uris.add(Uri.parse(path));
            if (canIDelete) {
                Uri contentUris = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, Long.parseLong(id));
                File file = new File(path);
                boolean isDeleted = file.delete();
                if (isDeleted) {
                    getApplicationContext().getContentResolver().delete(contentUris, null, null);
                }
            }
        }
        if (!canIDelete) {
            MediaScannerConnection.scanFile(getApplicationContext(), new String[]{String.valueOf(uris)}, null,
                    new MediaScannerConnection.OnScanCompletedListener() {
                        @Override
                        public void onScanCompleted(String s, Uri uri) {
                            Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
                            intent.setType("video/*");
                            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
                            startActivity(Intent.createChooser(intent, "share"));
                        }
                    });
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        if (is_selectable) {
            clearSelectingToolbar();
            videosAdapter.notifyDataSetChanged();
        } else {

            super.onBackPressed();
        }
    }
}