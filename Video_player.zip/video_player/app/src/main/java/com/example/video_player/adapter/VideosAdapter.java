package com.example.video_player.adapter;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.video_player.R;
import com.example.video_player.VideoModel;
import com.example.video_player.activity.VideoFolder;
import com.example.video_player.activity.VideoPlayer;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.snackbar.Snackbar;

import java.io.File;
import java.util.ArrayList;

public class VideosAdapter extends RecyclerView.Adapter<VideosAdapter.Holder> {


    public static ArrayList<VideoModel> videoFolder = new ArrayList<>();
    private Context context;
    VideoFolder videoFolderActivity;

    public VideosAdapter(ArrayList<VideoModel> videoFolder, Context context) {
        this.videoFolder = videoFolder;
        this.context = context;
        videoFolderActivity = (VideoFolder) context;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.files_view, parent, false);
        Holder holder = new Holder(view,videoFolderActivity);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, @SuppressLint("RecyclerView") int position) {

        Glide.with(context).load(videoFolder.get(position).getPath()).into(holder.thumbnail);
        holder.title.setText(videoFolder.get(position).getTitle());
        holder.size.setText(videoFolder.get(position).getSize());
        holder.duration.setText(videoFolder.get(position).getDuration());
        holder.resolution.setText(videoFolder.get(position).getResolution());
        holder.manu.setOnClickListener(view -> {
            BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context, R.style.BottomSheetDialogTheme);
            View bottomSheetView = LayoutInflater.from(context).inflate(R.layout.file_menu, null);
            bottomSheetDialog.setContentView(bottomSheetView);
            bottomSheetDialog.show();

            bottomSheetView.findViewById(R.id.menu_down).setOnClickListener(view1 -> {
                bottomSheetDialog.dismiss();
            });

            bottomSheetView.findViewById(R.id.manu_share).setOnClickListener(view2 -> {
                bottomSheetDialog.dismiss();
                shareFile(position);
            });

            bottomSheetView.findViewById(R.id.manu_rename).setOnClickListener(view3 -> {
                bottomSheetDialog.dismiss();
                renameFiles(position, view);
            });

            bottomSheetView.findViewById(R.id.manu_delete).setOnClickListener(view4 -> {
                bottomSheetDialog.dismiss();
                deleteFiles(position, view);
            });

            bottomSheetView.findViewById(R.id.manu_properties).setOnClickListener(view5 -> {
                bottomSheetDialog.dismiss();
                showProperties(position);
            });
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, VideoPlayer.class);
                intent.putExtra("p",position);
                context.startActivity(intent);
            }
        });

        if (videoFolderActivity.is_selectable){
            holder.checkBox.setVisibility(View.VISIBLE);
            holder.manu.setVisibility(View.GONE);
            holder.checkBox.setChecked(false);
        }else {
            holder.checkBox.setVisibility(View.GONE);
            holder.manu.setVisibility(View.VISIBLE);
        }
    }



    private void shareFile(int p) {
        Uri uri = Uri.parse(videoFolder.get(p).getPath());
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("Video/*");
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        context.startActivity(Intent.createChooser(intent, "Share"));
        Toast.makeText(context, "loading..", Toast.LENGTH_SHORT).show();
    }

    private void deleteFiles(int p, View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("delete");
        builder.setMessage(videoFolder.get(p).getTitle());
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        }).setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Uri contentUri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        Long.parseLong(videoFolder.get(p).getId()));
                File file = new File(videoFolder.get(p).getPath());
                boolean deleted = file.delete();
                if (deleted) {
                    context.getApplicationContext().getContentResolver().delete(contentUri, null, null);
                    videoFolder.remove(p);
                    notifyItemRemoved(p);
                    notifyItemRangeChanged(p, videoFolder.size());
                    Snackbar.make(view, "File deleted Success", Snackbar.LENGTH_SHORT).show();
                } else {
                    Snackbar.make(view, "File deleted Fail", Snackbar.LENGTH_SHORT).show();
                }
            }
        }).show();
    }

    private void renameFiles(int position, View view) {
        final Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.rename_layout);
        final EditText editText = dialog.findViewById(R.id.rename_edit_text);
        Button cancel = dialog.findViewById(R.id.cancel_rename_button);
        Button rename_btn = dialog.findViewById(R.id.rename_button);
        final File renameFile = new File(videoFolder.get(position).getPath());
        String nameText = renameFile.getName();
        nameText = nameText.substring(0, nameText.lastIndexOf("."));
        editText.setText(nameText);
        editText.clearFocus();
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        rename_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String onlypath = renameFile.getParentFile().getAbsolutePath();
                String ext = renameFile.getAbsolutePath();
                ext = ext.substring(ext.lastIndexOf("."));
                String newPath = onlypath + "/" + editText.getText() + ext;
                File newFile = new File(newPath);
                boolean rename = renameFile.renameTo(newFile);
                if (rename) {
                    context.getApplicationContext().getContentResolver().delete(MediaStore.Files.getContentUri("external"),
                            MediaStore.MediaColumns.DATA + "=?",
                            new String[]{renameFile.getAbsolutePath()});
                    Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                    intent.setData(Uri.fromFile(newFile));
                    context.getApplicationContext().sendBroadcast(intent);
                    Snackbar.make(view, "Rename Success", Snackbar.LENGTH_SHORT).show();
                } else {
                    Snackbar.make(view, "Rename Failed", Snackbar.LENGTH_SHORT).show();
                }
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void showProperties(int p) {
        Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.file_properties);

        String name = videoFolder.get(p).getTitle();
        String path = videoFolder.get(p).getPath();
        String size = videoFolder.get(p).getSize();
        String duration = videoFolder.get(p).getDuration();
        String resolution = videoFolder.get(p).getResolution();

        TextView tit = dialog.findViewById(R.id.pro_title);
        TextView st = dialog.findViewById(R.id.pro_storage);
        TextView siz = dialog.findViewById(R.id.pro_size);
        TextView dur = dialog.findViewById(R.id.pro_duration);
        TextView res = dialog.findViewById(R.id.pro_resolution);

        tit.setText(name);
        st.setText(path);
        siz.setText(size);
        dur.setText(duration);
        res.setText(resolution + "p");

        dialog.show();
    }

    @Override
    public int getItemCount() {
        return videoFolder.size();
    }

    public void updateSearchList(ArrayList<VideoModel> searchList) {
        videoFolder = new ArrayList<>();
        videoFolder.addAll(searchList);
        notifyDataSetChanged();
    }

    public class Holder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView thumbnail, manu;
        TextView title, size, duration, resolution;
        CheckBox  checkBox;
        VideoFolder videoFolderActicity;

        public Holder(@NonNull View itemView, VideoFolder videoFolderActicity) {
            super(itemView);

            thumbnail = itemView.findViewById(R.id.thumbnail);
            title = itemView.findViewById(R.id.video_title);
            size = itemView.findViewById(R.id.video_size);
            duration = itemView.findViewById(R.id.video_duration);
            resolution = itemView.findViewById(R.id.video_quality);
            manu = itemView.findViewById(R.id.video_menu);
            checkBox = itemView.findViewById(R.id.video_folder_checkbox);
            this.videoFolderActicity = videoFolderActicity;

            itemView.setOnLongClickListener(videoFolderActicity);
            checkBox.setOnClickListener(this);

        }

        @Override
        public void onClick(View view) {
            videoFolderActicity.prepareSelection(view,getAdapterPosition());
        }
    }
}
