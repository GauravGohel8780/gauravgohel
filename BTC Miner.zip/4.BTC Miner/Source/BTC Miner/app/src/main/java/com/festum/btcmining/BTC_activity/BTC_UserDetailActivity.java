package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.RadioButton;
import android.widget.Toast;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.R;
import com.festum.btcmining.SharedPrefs;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ApiResponse;
import com.festum.btcmining.BTC_api.model.BTC_UserData;
import com.festum.btcmining.BTC_api.model.BTC_UserDetail;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.databinding.ActivityUserDetailBinding;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.Objects;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_UserDetailActivity extends AdsBaseActivity {

    ActivityUserDetailBinding binding;
    SharedPreferences sharedpreferences;
    BTC_ApiResponse apiResponseGlobal;
    BTC_UserData userData;
    String userToken;
    String firstName;
    String lastName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUserDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        userToken = getIntent().getStringExtra(BTC_Constants.USER_TOKEN);
        binding.rbMale.setChecked(true);

        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");
        firstName = sharedpreferences.getString(BTC_Constants.FIRST_NAME, "");
        lastName = sharedpreferences.getString(BTC_Constants.LAST_NAME, "");

        Log.d("--token--", "Login:  user details---->" + userToken);

        Gson gson = new Gson();
        String json = sharedpreferences.getString(BTC_Constants.API_RESPONSE, "");
        apiResponseGlobal = gson.fromJson(json, BTC_ApiResponse.class);


        if (!TextUtils.isEmpty(json)) {
            apiResponseGlobal = gson.fromJson(json, BTC_ApiResponse.class);

            if (apiResponseGlobal != null) {
                userData = apiResponseGlobal.getData();

                if (userData != null) {
                    Log.d("--apiResponse--", "onCreate: ");


                    Log.d("--token--", "onCreate: user detail token " + userToken);
                }
            }

            SharedPreferences.Editor editor = sharedpreferences.edit();
            editor.putString(BTC_Constants.USER_TOKEN, userData.getUserToken());
            gson = new Gson();
            json = gson.toJson(apiResponseGlobal);

            editor.putString(BTC_Constants.API_RESPONSE, json);

            editor.apply();
        }

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @NotNull
            @Override
            public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                Request original = chain.request();
                Request.Builder requestBuilder = original.newBuilder()
                        .header("Authorization", "Bearer " + userToken)
                        .method(original.method(), original.body());

                Request request = requestBuilder.build();

                Log.d("--apiResponse--", "URL: " + request.url());
                Log.d("--apiResponse--", "Headers: " + request.headers());
                Log.d("--apiResponse--", "Body: " + request.body());

                return chain.proceed(request);
            }
        });

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BTC_Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        BTC_ApiService apiService = retrofit.create(BTC_ApiService.class);


        String[] countryArray = BTC_Constants.country;

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.simple_spinner_item, countryArray);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        binding.sCountrySpinner.setAdapter(adapter);


        binding.tvContinues.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                firstName = Objects.requireNonNull(binding.etFirstName.getText()).toString();
                lastName = Objects.requireNonNull(binding.etLastName.getText()).toString();

                if (TextUtils.isEmpty(firstName)) {
                    Toast.makeText(BTC_UserDetailActivity.this, "Please enter your first name.", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(lastName)) {
                    Toast.makeText(BTC_UserDetailActivity.this, "Please enter your last name.", Toast.LENGTH_SHORT).show();
                } else {
                    binding.clProgressBar.setVisibility(View.VISIBLE);

                    int selected = binding.radioSexGroup.getCheckedRadioButtonId();
                    RadioButton radio = (RadioButton) findViewById(selected);

                    String gender = radio.getText().toString();
                    String selectedCountry = binding.sCountrySpinner.getSelectedItem().toString();

                    BTC_UserDetail userDetail = new BTC_UserDetail(firstName, lastName, selectedCountry, gender);

                    Call<BTC_ApiResponse> call = apiService.updateUserDetail(userDetail);

                    call.enqueue(new Callback<BTC_ApiResponse>() {
                        @Override
                        public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                            BTC_ApiResponse apiResponse = response.body();
                            if (response.isSuccessful()) {

                                Log.w("--apiResponse--", "user_data---in USerDetails" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));

                                userData = apiResponse.getData();
                                Log.w("--apiResponse--", "onResponse:getArrLoginToken ---------->" + userData.getArrLoginToken().get(0).getvToken());
                                SharedPreferences.Editor editor = sharedpreferences.edit();
                                editor.putString(BTC_Constants.USER_TOKEN, userData.getArrLoginToken().get(0).getvToken());
                                Gson gson = new Gson();
                                String json = gson.toJson(apiResponse);

                                editor.putString(BTC_Constants.API_RESPONSE, json);

                                editor.apply();

                                binding.clProgressBar.setVisibility(View.GONE);

                                getInstance(BTC_UserDetailActivity.this).ShowAd(new HandleClick() {
                                    @Override
                                    public void Show(boolean adShow) {
                                        if (SharedPrefs.getFirstTimeStartScreen(BTC_UserDetailActivity.this)){
                                            Intent intent = new Intent(BTC_UserDetailActivity.this, BTC_HomeActivity.class);
                                            startActivity(intent);
                                        }else {
                                            SharedPrefs.setFirstTimeStartScreen(BTC_UserDetailActivity.this,true);
                                            Intent intent = new Intent(BTC_UserDetailActivity.this, BTC_StartActivity.class);
                                            startActivity(intent);
                                        }
                                    }
                                }, MAIN_CLICK);
                            } else {
                                binding.clProgressBar.setVisibility(View.GONE);
                                try {
                                    binding.clProgressBar.setVisibility(View.GONE);
                                    Log.w("--apiResponse--", "Error: user detail " + response.errorBody().string());
                                } catch (IOException e) {
                                    throw new RuntimeException(e);
                                }
                            }
                        }

                        @Override
                        public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {
                            binding.clProgressBar.setVisibility(View.GONE);
                            Log.e("--apiResponse--", "Error: user detail onFailure " + new Gson().toJson(t.getMessage()));
                        }
                    });

                }
            }
        });
    }


    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}