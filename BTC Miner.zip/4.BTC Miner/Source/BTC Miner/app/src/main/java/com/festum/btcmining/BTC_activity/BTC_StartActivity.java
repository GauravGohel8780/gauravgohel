package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.Commen;
import com.festum.btcmining.R;
import com.festum.btcmining.databinding.ActivityStartBinding;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class BTC_StartActivity extends AdsBaseActivity {

    ActivityStartBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Commen.SetSystemFullScreen(this);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        binding = ActivityStartBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.tvStart.setOnClickListener(v -> {
            getInstance(BTC_StartActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    startActivity(new Intent(BTC_StartActivity.this, BTC_HomeActivity.class));
                }
            }, MAIN_CLICK);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}