package com.festum.btcmining.BTC_api.model;

public class BTC_EmailVerificationRequest {
    private String vEmail;

    public BTC_EmailVerificationRequest(String vEmail) {
        this.vEmail = vEmail;
    }

    public String getvEmail() {
        return vEmail;
    }

    public void setvEmail(String vEmail) {
        this.vEmail = vEmail;
    }
}

