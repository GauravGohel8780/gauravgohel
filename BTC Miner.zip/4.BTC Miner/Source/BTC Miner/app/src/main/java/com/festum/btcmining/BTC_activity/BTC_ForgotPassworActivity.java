package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ApiResponse;
import com.festum.btcmining.BTC_api.model.BTC_ResetForgotPassword;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.databinding.ActivityForgotPassworBinding;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_ForgotPassworActivity extends AdsBaseActivity {
    ActivityForgotPassworBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityForgotPassworBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BTC_Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        BTC_ApiService apiService = retrofit.create(BTC_ApiService.class);


        binding.tvContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = Objects.requireNonNull(binding.etEmail.getText()).toString().trim();

                if (!isValidEmail(email)) {
                    Toast.makeText(BTC_ForgotPassworActivity.this, getString(R.string.invalid_email_address), Toast.LENGTH_SHORT).show();
                } else {
                    binding.clProgressBar.setVisibility(View.VISIBLE);

                    BTC_ResetForgotPassword resetForgotPassword = new BTC_ResetForgotPassword();
                    resetForgotPassword.setvEmail(email);

                    Call<BTC_ApiResponse> call = apiService.resetPassword(resetForgotPassword);

                    call.enqueue(new Callback<BTC_ApiResponse>() {
                        @Override
                        public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                            BTC_ApiResponse apiResponse = response.body();

                            binding.clProgressBar.setVisibility(View.VISIBLE);

                            if (apiResponse != null) {

                                Log.w("--forgotPass--", "onResponse: code " + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));
                                Log.d("--forgotPass--", "onResponse: code " + apiResponse.getData().getvEmail());


                                if (apiResponse.getiStatusCode() == 200) {
                                    binding.clProgressBar.setVisibility(View.GONE);

                                    Dialog dialog = new Dialog(BTC_ForgotPassworActivity.this, R.style.customDialog);

                                    dialog.setContentView(R.layout.dialog_register_successful);
                                    dialog.setCancelable(false);

                                    Objects.requireNonNull(dialog.getWindow()).setGravity(Gravity.CENTER);

                                    dialog.getWindow().setLayout(-1, -2);

                                    Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(ContextCompat.getDrawable(BTC_ForgotPassworActivity.this, android.R.color.transparent));

                                    ImageView ivCancel = dialog.findViewById(R.id.ivCancel);
                                    CardView cvOk = dialog.findViewById(R.id.cvOk);
                                    TextView email_description = dialog.findViewById(R.id.email_description);

                                    email_description.setText(getString(R.string.password_reset_desc));

                                    dialog.show();

                                    ivCancel.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            dialog.dismiss();
                                            binding.clProgressBar.setVisibility(View.GONE);
                                        }
                                    });


                                    cvOk.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            getInstance(BTC_ForgotPassworActivity.this).ShowAd(new HandleClick() {
                                                @Override
                                                public void Show(boolean adShow) {
                                                    dialog.dismiss();
                                                    binding.clProgressBar.setVisibility(View.GONE);

                                                    Intent intent = new Intent(BTC_ForgotPassworActivity.this, BTC_ChangePasswordActivity.class);
                                                    intent.putExtra("email", binding.etEmail.getText().toString());
                                                    startActivity(intent);
                                                    finish();
                                                }
                                            }, MAIN_CLICK);
                                        }
                                    });

                                }


                            } else {
                                Toast.makeText(BTC_ForgotPassworActivity.this, "Something went wrong. Please try again after sometime.", Toast.LENGTH_SHORT).show();
                                binding.clProgressBar.setVisibility(View.GONE);
                            }
                        }

                        @Override
                        public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {

                        }
                    });
                }
            }
        });
    }


    private boolean isValidEmail(CharSequence target) {
        return Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}
