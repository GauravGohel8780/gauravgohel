package com.festum.btcmining.BTC_api.model;

import java.util.List;

public class BTC_AllUsersResponse {

    private int iStatusCode;
    private boolean isStatus;
    private List<BTC_AllUsersDataRequest> data;
    private int iCount;
    private String vMessage;

    public int getiStatusCode() {
        return iStatusCode;
    }

    public void setiStatusCode(int iStatusCode) {
        this.iStatusCode = iStatusCode;
    }

    public boolean isStatus() {
        return isStatus;
    }

    public void setStatus(boolean status) {
        isStatus = status;
    }

    public List<BTC_AllUsersDataRequest> getData() {
        return data;
    }

    public void setData(List<BTC_AllUsersDataRequest> data) {
        this.data = data;
    }

    public String getvMessage() {
        return vMessage;
    }

    public void setvMessage(String vMessage) {
        this.vMessage = vMessage;
    }

    public int getiCount() {
        return iCount;
    }

    public void setiCount(int iCount) {
        this.iCount = iCount;
    }
}
