package com.festum.btcmining.BTC_adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.model.BTC_ContestsData;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

public class BTC_ContestsAdapter extends RecyclerView.Adapter<BTC_ContestsAdapter.ViewHolder> {

    ArrayList<BTC_ContestsData> contestsModelArrayList;

    OnItemClickListener onItemClickListener;

    public interface OnItemClickListener {
        void onClick(int position);
    }

    public BTC_ContestsAdapter(ArrayList<BTC_ContestsData> contestsModelArrayList, OnItemClickListener onItemClickListener) {
        this.contestsModelArrayList = contestsModelArrayList;
        this.onItemClickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.allcontests_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BTC_ContestsData contestsModel = contestsModelArrayList.get(position);

        int value = contestsModel.getDtExpiryDate();

        holder.tv_contest_name.setText(contestsModel.getvContestName());
        holder.tv_left_time.setText(formatDate(value));
        holder.tv_total_joins.setText(contestsModel.getiTotalUser() + " Joins");
        holder.tv_total_tickets.setText(String.valueOf(contestsModel.getdContestTicket()));
        holder.tv_time_type.setText(contestsModel.getvContestType());
        holder.tv_ranking.setText(String.valueOf(contestsModel.getdContestPoint()));


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClickListener.onClick(holder.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return contestsModelArrayList.size();
    }

    private String formatDate(long milliseconds) /* This is your topStory.getTime()*1000 */ {
        DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy' 'HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliseconds);
        TimeZone tz = TimeZone.getDefault();
        sdf.setTimeZone(tz);
        return sdf.format(calendar.getTime());
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv_contest_name;
        TextView tv_total_joins;
        TextView tv_total_tickets;
        TextView tv_left_time;
        TextView tv_time_type;
        TextView tv_ranking;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tv_contest_name = itemView.findViewById(R.id.tv_contest_name);
            tv_total_joins = itemView.findViewById(R.id.tv_total_joins);
            tv_total_tickets = itemView.findViewById(R.id.tv_tickets);
            tv_left_time = itemView.findViewById(R.id.tv_left_time);
            tv_time_type = itemView.findViewById(R.id.tv_time_type);
            tv_ranking = itemView.findViewById(R.id.tv_contest_point);
        }
    }
}
