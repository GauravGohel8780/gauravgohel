package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ConsumeParams;
import com.android.billingclient.api.ConsumeResponseListener;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.ProductDetailsResponseListener;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesResponseListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;
import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ApiResponse;
import com.festum.btcmining.BTC_api.model.BTC_PlanDetailResponse;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.R;
import com.festum.btcmining.databinding.ActivityPlanPaymentDetailBinding;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_PlanPaymentDetailActivity extends AdsBaseActivity {

    String planId;
    BillingClient billingClient;
    SharedPreferences sharedpreferences;
    String userToken;
    private int tries;
    private int maxTries;
    private boolean isConnectionEstablished;

    ActivityPlanPaymentDetailBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityPlanPaymentDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        billingClient = BillingClient.newBuilder(this)
                .enablePendingPurchases()
                .setListener(
                        (billingResult, list) -> {
                            if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && list != null) {
                                for (Purchase purchase : list) {
                                    String orderId = purchase.getOrderId();
                                    Log.d("--premium--", "Response is OK " + orderId);
                                    handlePurchase(purchase);
                                }
                            } else {

                                Log.d("--premium--", "Response NOT OK");
                            }
                        }
                ).build();


        planId = getIntent().getStringExtra(BTC_Constants.PLAN_ID);

        binding.clProgressBar.setVisibility(View.VISIBLE);

        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");


        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BTC_Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        BTC_ApiService apiService = retrofit.create(BTC_ApiService.class);

        Call<BTC_PlanDetailResponse> call = apiService.getPlanDetails(planId);

        call.enqueue(new Callback<BTC_PlanDetailResponse>() {
            @Override
            public void onResponse(@NonNull Call<BTC_PlanDetailResponse> call, @NonNull Response<BTC_PlanDetailResponse> response) {

                if (response.isSuccessful()) {
                    BTC_PlanDetailResponse apiResponse = response.body();

                    if (apiResponse != null) {
                        Log.w("--apiResponse--", "PlanDetailResponse" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));
                        binding.clProgressBar.setVisibility(View.GONE);
                        binding.tvPlanName.setText(apiResponse.getData().getvPlanName());
                        binding.tvPlanSpeed.setText(String.valueOf(apiResponse.getData().getdSpeed()));
                        binding.tvPlanAvailability.setText(String.valueOf(apiResponse.getData().isAvailability()));
                        binding.tvTotalWithdrawal.setText(String.valueOf(apiResponse.getData().getiWithdrawal()));
                        binding.tvPlanValidity.setText(String.valueOf(apiResponse.getData().getiValidity()));
                        binding.tvPlanPrice.setText(String.valueOf(apiResponse.getData().getdPrice()));
                        binding.tvPayPrice.setText(apiResponse.getData().getdPrice() + "  (₹)");
                    }

                } else {
                    try {
                        Log.e("--apiResponse--", "Error: PlanDetailResponse " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<BTC_PlanDetailResponse> call, @NonNull Throwable t) {
            }
        });


        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_PlanPaymentDetailActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

        binding.tvPayPrice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_PlanPaymentDetailActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        establishConnection();
                    }
                }, MAIN_CLICK);
            }
        });
    }

    private void establishConnection() {
        billingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(@NonNull BillingResult billingResult) {
                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    Log.e("err", String.valueOf(billingResult.getResponseCode()));
                    Log.e("err", "baglamtı başarılı");

                    queryExistingPurchases();

                    // Bağlantı başarıyla kuruldu
                    // The BillingClient is ready. You can query purchases here.
                    //Use any of function below to get details upon successful connection
                    GetSingleInAppDetail();
                    //GetListsInAppDetail();
                } else {
                    // Bağlantı başarısız oldu 3 kere tekrar dene
                    retryBillingServiceConnection();
                }
            }

            @Override
            public void onBillingServiceDisconnected() {

                retryBillingServiceConnection();
            }
        });
    }

    void retryBillingServiceConnection() {
        tries = 1;
        maxTries = 3;
        isConnectionEstablished = false;
        do {
            try {
                billingClient.startConnection(new BillingClientStateListener() {
                    @Override
                    public void onBillingServiceDisconnected() {
                        retryBillingServiceConnection();
                    }

                    @Override
                    public void onBillingSetupFinished(@NonNull BillingResult billingResult) {
                        tries++;
                        if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                            isConnectionEstablished = true;

                        } else if (tries == maxTries) {
                            handleBillingError(billingResult.getResponseCode());
                        }
                    }
                });
            } catch (Exception e) {
                tries++;
            }
        }
        while (tries <= maxTries && !isConnectionEstablished);

        if (!isConnectionEstablished) {
            handleBillingError(-1);
        }

    }


    void GetSingleInAppDetail() {
        ArrayList<QueryProductDetailsParams.Product> productList = new ArrayList<>();

        //Set your In App Product ID in setProductId()
        productList.add(
                QueryProductDetailsParams.Product.newBuilder()
                        .setProductId("silver")
                        .setProductType(BillingClient.ProductType.INAPP)
                        .build()
        );

        productList.add(
                QueryProductDetailsParams.Product.newBuilder()
                        .setProductId("android.test.purchased")
                        .setProductType(BillingClient.ProductType.INAPP)
                        .build()
        );

        productList.add(
                QueryProductDetailsParams.Product.newBuilder()
                        .setProductId("platinum")
                        .setProductType(BillingClient.ProductType.INAPP)
                        .build()
        );


        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
                .setProductList(productList)
                .build();

        billingClient.queryProductDetailsAsync(params, new ProductDetailsResponseListener() {

            @Override
            public void onProductDetailsResponse(@NonNull BillingResult billingResult, @NonNull List<ProductDetails> list) {

                //Do Anything that you want with requested product details

                //Calling this function here so that once products are verified we can start the purchase behavior.
                //You can save this detail in separate variable or list to call them from any other location
                //Create another function if you want to call this in establish connections' success state
                LaunchPurchaseFlow(list.get(0));


            }
        });
    }

    void LaunchPurchaseFlow(ProductDetails productDetails) {
        ArrayList<BillingFlowParams.ProductDetailsParams> productList = new ArrayList<>();

        productList.add(
                BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(productDetails)
                        .build());

        BillingFlowParams billingFlowParams = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(productList)
                .build();

        billingClient.launchBillingFlow(this, billingFlowParams);
    }

    void handlePurchase(Purchase purchases) {

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @NotNull
            @Override
            public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                Request original = chain.request();
                Request.Builder requestBuilder = original.newBuilder()
                        .header("Authorization", "Bearer " + userToken)
                        .method(original.method(), original.body());

                Request request = requestBuilder.build();

                Log.d("--apiResponse--", "URL: " + request.url());
                Log.d("--apiResponse--", "Headers: " + request.headers());
                Log.d("--apiResponse--", "Body: " + request.body());

                return chain.proceed(request);
            }
        });

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BTC_Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        BTC_ApiService apiService = retrofit.create(BTC_ApiService.class);

        if (!purchases.isAcknowledged()) {

            billingClient.acknowledgePurchase(AcknowledgePurchaseParams
                    .newBuilder()
                    .setPurchaseToken(purchases.getPurchaseToken())
                    .build(), billingResult -> {

                ConsumeResponseListener listener = new ConsumeResponseListener() {
                    @Override
                    public void onConsumeResponse(@NonNull BillingResult billingResult, @NonNull String purchaseToken) {
                        if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                            // Handle the success of the consume operation.
                        }
                    }
                };

          /*      ConsumeParams consumeParams =
                        ConsumeParams.newBuilder()
                                .setPurchaseToken(purchases.getPurchaseToken())
                                .build();
                                *
           */

                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    for (String pur : purchases.getProducts()) {
                        if (pur.equalsIgnoreCase("android.test.purchased")) {
                            Log.d("--premium--", "Purchase is successful");

                            //Calling Consume to consume the current purchase
                            // so user will be able to buy same product again
                            //   billingClient.consumeAsync(consumeParams, listener); // you should have listener method !


                            Call<BTC_ApiResponse> call = apiService.upgradeUserPlan(planId);

                            call.enqueue(new Callback<BTC_ApiResponse>() {

                                @Override
                                public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                                    if (response.isSuccessful()) {
                                        BTC_ApiResponse apiResponse = response.body();

                                        if (apiResponse != null) {
                                            Log.w("--planPay--", "onResponse: PlanPayment success " + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));

                                            Toast.makeText(BTC_PlanPaymentDetailActivity.this, "Congratulations! Your plan has been upgraded now.", Toast.LENGTH_LONG).show();
                                            Intent intent = new Intent(BTC_PlanPaymentDetailActivity.this, BTC_HomeActivity.class);
                                            startActivity(intent);
                                        }
                                    } else {

                                        try {
                                            Log.w("--planPay--", "Error: PlanPayment errorBody " + new GsonBuilder().setPrettyPrinting().create().toJson(response.errorBody().string()));

                                        } catch (IOException e) {
                                            throw new RuntimeException(e);
                                        }
                                    }
                                }

                                @Override
                                public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {

                                }
                            });


                            // TODO: 11.04.2023 bu kısım backend tarafında yapılacak
                            ConsumePurchase(purchases);
                        } /*else if (pur.equalsIgnoreCase("golden")) {
                            Log.d("--premium--", " golden Purchase is successful");
//                            tv_status.setText("Yay! golden");
                        } else {
                            Log.d("--premium--", " platinum Purchase is successful");
//                            tv_status.setText("Yay! platinum");
                        }*/
                    }
                } else {
                    handleBillingError(billingResult.getResponseCode());
                }
            });
        }
    }

    void ConsumePurchase(Purchase purchase) {

        ConsumeParams params = ConsumeParams.newBuilder()
                .setPurchaseToken(purchase.getPurchaseToken())
                .build();
        billingClient.consumeAsync(params, new ConsumeResponseListener() {
            @Override
            public void onConsumeResponse(@NonNull BillingResult billingResult, @NonNull String s) {

                Log.d("--premium--", "Consuming Successful: " + s);
//                tv_status.setText("Product Consumed");
            }
        });
    }

    private void handleBillingError(int responseCode) {
        String errorMessage;
        switch (responseCode) {
            case BillingClient.BillingResponseCode.BILLING_UNAVAILABLE:
            case BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE:
                errorMessage = "Billing service is currently unavailable. Please try again later.";
                break;
            case BillingClient.BillingResponseCode.DEVELOPER_ERROR:
                errorMessage = "An error occurred while processing the request. Please try again later.";
                break;
            case BillingClient.BillingResponseCode.FEATURE_NOT_SUPPORTED:
                errorMessage = "This feature is not supported on your device.";
                break;
            case BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED:
                errorMessage = "You already own this item.";
                break;
            case BillingClient.BillingResponseCode.ITEM_NOT_OWNED:
                errorMessage = "You do not own this item.";
                break;
            case BillingClient.BillingResponseCode.ITEM_UNAVAILABLE:
                errorMessage = "This item is not available for purchase.";
                break;
            case BillingClient.BillingResponseCode.SERVICE_DISCONNECTED:
                errorMessage = "Billing service has been disconnected. Please try again later.";
                break;
            case BillingClient.BillingResponseCode.SERVICE_TIMEOUT:
                errorMessage = "Billing service timed out. Please try again later.";
                break;
            case BillingClient.BillingResponseCode.USER_CANCELED:
                errorMessage = "The purchase has been canceled.";
                break;
            default:
                errorMessage = "An unknown error occurred.";
                break;
        }
        Log.e("--premium--", "Error: " + errorMessage);
    }


    private void queryExistingPurchases() {
        billingClient.queryPurchasesAsync(
                QueryPurchasesParams.newBuilder()
                        .setProductType(BillingClient.ProductType.INAPP)
                        .build(),
                new PurchasesResponseListener() {
                    public void onQueryPurchasesResponse(BillingResult billingResult, List<Purchase> purchases) {
                        Log.d("--premium--", "onQueryPurchasesResponse: getResponseCode() " + billingResult.getResponseCode());
                        Log.d("--premium--", "onQueryPurchasesResponse: getResponseCode() " + billingResult.getDebugMessage());

                        if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
                            // Handle existing purchases
                            for (Purchase purchase : purchases) {
                                handlePurchase(purchase);
                            }
                        } else {
                            // Handle the case where querying existing purchases fails
                            Log.e("--premium--", "Failed to query existing purchases: " + billingResult.getResponseCode());
                        }
                    }
                }
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}