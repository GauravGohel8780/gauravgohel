package com.festum.btcmining.BTC_api.model;

public class BTC_ArrParticipateList {

    public int iTotalTicket;
    public int iTotalAmount;
    public String _id;
    public String vUserId;
    public long dtCreatedAt;

    public int getiTotalTicket() {
        return iTotalTicket;
    }

    public void setiTotalTicket(int iTotalTicket) {
        this.iTotalTicket = iTotalTicket;
    }

    public int getiTotalAmount() {
        return iTotalAmount;
    }

    public void setiTotalAmount(int iTotalAmount) {
        this.iTotalAmount = iTotalAmount;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getvUserId() {
        return vUserId;
    }

    public void setvUserId(String vUserId) {
        this.vUserId = vUserId;
    }

    public long getDtCreatedAt() {
        return dtCreatedAt;
    }

    public void setDtCreatedAt(long dtCreatedAt) {
        this.dtCreatedAt = dtCreatedAt;
    }
}
