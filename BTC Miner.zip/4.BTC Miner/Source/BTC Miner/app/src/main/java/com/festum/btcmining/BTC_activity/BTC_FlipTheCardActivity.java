package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.Toast;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ApiResponse;
import com.festum.btcmining.BTC_api.model.BTC_ScratchCardData;
import com.festum.btcmining.BTC_api.model.BTC_ScratchCardResponse;
import com.festum.btcmining.BTC_api.model.BTC_UpdatePoints;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.databinding.ActivityFlipTheCardBinding;
import com.festum.btcmining.BTC_preference.BTC_TimerPreference;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Random;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_FlipTheCardActivity extends AdsBaseActivity {

    ActivityFlipTheCardBinding binding;
    int[] imageArray = {R.drawable.ic_card_j, R.drawable.ic_card_queen, R.drawable.ic_card_king, R.drawable.ic_card_a};
    boolean isFront = true;
    ArrayList<ImageView> frontImageViewList;
    ArrayList<ImageView> imageViewFlipped;
    int clickedPosition = -1;
    int cardPosition = -1;
    ImageView[] imageViews;
    String place_bet_point;
    String userToken;
    int availableFlipBets = 0;
    int entered_bet_point;
    int totalPoints;
    SharedPreferences sharedpreferences;
    BTC_ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityFlipTheCardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
        totalPoints = sharedpreferences.getInt(BTC_Constants.TOTAL_POINTS, 0);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");
        availableFlipBets = sharedpreferences.getInt(BTC_Constants.AVAILABLE_FLIPS, 0);

        binding.tvAvailableCard.setText("Your Today Available Flip Left = " + availableFlipBets);


        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @NotNull
            @Override
            public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                Request original = chain.request();
                Request.Builder requestBuilder = original.newBuilder().header("Authorization", "Bearer " + userToken).method(original.method(), original.body());

                Request request = requestBuilder.build();

                Log.d("--apiResponse--", "URL: " + request.url());
                Log.d("--apiResponse--", "Headers: " + request.headers());
                Log.d("--apiResponse--", "Body: " + request.body());

                return chain.proceed(request);
            }
        });

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder().baseUrl(BTC_Constants.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(client).build();

        apiService = retrofit.create(BTC_ApiService.class);


        frontImageViewList = new ArrayList<>();
        frontImageViewList.add(findViewById(R.id.ic_flip_card1));
        frontImageViewList.add(findViewById(R.id.ic_flip_card2));
        frontImageViewList.add(findViewById(R.id.ic_flip_card3));
        frontImageViewList.add(findViewById(R.id.ic_flip_card4));

        imageViewFlipped = new ArrayList<>();
        imageViewFlipped.add(findViewById(R.id.ic_flipped_card1));
        imageViewFlipped.add(findViewById(R.id.ic_flipped_card2));
        imageViewFlipped.add(findViewById(R.id.ic_flipped_card3));
        imageViewFlipped.add(findViewById(R.id.ic_flipped_card4));


        for (int i = 0; i < frontImageViewList.size(); i++) {
            final int position = i;
            frontImageViewList.get(i).setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onClick(View v) {

                    frontImageViewList.get(position).setForeground(ContextCompat.getDrawable(BTC_FlipTheCardActivity.this, R.drawable.ic_card_select));

                    for (int j = 0; j < frontImageViewList.size(); j++) {
                        if (j != position) {
                            frontImageViewList.get(j).setForeground(null);
                        }
                    }

                    clickedPosition = position;
                }
            });
        }


        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_FlipTheCardActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

        Log.d("--flipbets--", "onCreate: " + availableFlipBets);

        Call<BTC_ScratchCardResponse> call = apiService.scratchCardList();

        call.enqueue(new Callback<BTC_ScratchCardResponse>() {
            @Override
            public void onResponse(@NonNull Call<BTC_ScratchCardResponse> call, @NonNull Response<BTC_ScratchCardResponse> response) {
                if (response.isSuccessful()) {

                    BTC_ScratchCardResponse apiResponse = response.body();

                    if (BTC_TimerPreference.isFlipDayPassed(BTC_FlipTheCardActivity.this)) {

                        ArrayList<BTC_ScratchCardData> scratchCardData = apiResponse.getData();

                        BTC_ScratchCardData cardData = scratchCardData.get(0);

                        Log.w("--apiResponse--", "FlipTheCard resposne-------> " + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));

                        availableFlipBets = cardData.getiTotalOneDayScratch();

                        SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putInt(BTC_Constants.AVAILABLE_FLIPS, availableFlipBets);
                        editor.apply();

                        binding.tvAvailableCard.setText("Your Today Available Flip Left = " + availableFlipBets);

                        binding.tvPress.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                place_bet_point = Objects.requireNonNull(binding.etPlaceBetPoint.getText()).toString();

                                if (!TextUtils.isEmpty(place_bet_point)) {

//                                    if (availableFlipBets >= 1) {

                                    entered_bet_point = Integer.parseInt(place_bet_point);

                                    if (totalPoints >= entered_bet_point) {

                                        if (entered_bet_point >= 10 && entered_bet_point <= 500) {
                                            availableFlipBets--;

                                            SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
                                            SharedPreferences.Editor editor = sharedPreferences.edit();
                                            editor.putInt(BTC_Constants.AVAILABLE_FLIPS, availableFlipBets);
                                            editor.apply();

                                            binding.tvAvailableCard.setText("Your Today Available Flip Left : " + availableFlipBets);

                                            Random random = new Random();
                                            int randomImage = getImageList().get(random.nextInt(getImageList().size()));


                                            if (clickedPosition != -1 && cardPosition != -1) {

                                                final ObjectAnimator oa1 = ObjectAnimator.ofFloat(frontImageViewList.get(clickedPosition), "scaleX", 1f, 0f);
                                                final ObjectAnimator oa2 = ObjectAnimator.ofFloat(imageViewFlipped.get(clickedPosition), "scaleX", 0f, 1f);

                                                oa1.setInterpolator(new DecelerateInterpolator());
                                                oa2.setInterpolator(new AccelerateDecelerateInterpolator());

                                                oa1.addListener(new AnimatorListenerAdapter() {
                                                    @Override
                                                    public void onAnimationEnd(Animator animation) {
                                                        super.onAnimationEnd(animation);

                                                        imageViewFlipped.get(clickedPosition).setImageResource(randomImage);
                                                        imageViewFlipped.get(clickedPosition).setTag(randomImage);

                                                        oa2.start();
                                                        isFront = false;

                                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                            checkForMatch(clickedPosition);
                                                        }

                                                    }
                                                });
                                                oa1.start();
                                                setNewImage(clickedPosition);
                                            } else {
                                                Toast.makeText(BTC_FlipTheCardActivity.this, "Please select the card to bet.", Toast.LENGTH_SHORT).show();
                                            }
                                        } else {
                                            Toast.makeText(BTC_FlipTheCardActivity.this, "Please enter the points between 10-500.", Toast.LENGTH_SHORT).show();
                                        }
                                    } else {
                                        Toast.makeText(BTC_FlipTheCardActivity.this, "You must have point greater than bet point in your account", Toast.LENGTH_SHORT).show();
                                    }
//                                    } else {
//                                        Toast.makeText(FlipTheCardActivity.this, "Insufficient bet points, cannot bet now", Toast.LENGTH_SHORT).show();
//                                    }

                                } else {
                                    Toast.makeText(BTC_FlipTheCardActivity.this, "Please enter the bet points.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

                        BTC_TimerPreference.updateFlipLastCallTime(BTC_FlipTheCardActivity.this);
                    } else {
                        Log.d("--isDayPassed--", "isDayPassed: FlipTheCard else " + BTC_TimerPreference.isFlipDayPassed(BTC_FlipTheCardActivity.this) + "-------> availableFlipBets--" + availableFlipBets);
                        Log.d("--isDayPassed--", "isDayPassed: FlipTheCard else " + BTC_TimerPreference.isFlipDayPassed(BTC_FlipTheCardActivity.this) + "-------> availableFlipBets --" + availableFlipBets);

                        availableFlipBets = sharedpreferences.getInt(BTC_Constants.AVAILABLE_FLIPS, 0);

                        binding.tvAvailableCard.setText("Your Today Available Flip Left = " + availableFlipBets);

                        binding.tvPress.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                place_bet_point = Objects.requireNonNull(binding.etPlaceBetPoint.getText()).toString();

                                if (!TextUtils.isEmpty(place_bet_point)) {

                                    if (availableFlipBets >= 1) {

                                        entered_bet_point = Integer.parseInt(place_bet_point);

                                        if (totalPoints >= entered_bet_point) {

                                            if (entered_bet_point >= 10 && entered_bet_point <= 500) {
                                                availableFlipBets--;

                                                SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
                                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                                editor.putInt(BTC_Constants.AVAILABLE_FLIPS, availableFlipBets);
                                                editor.apply();

                                                binding.tvAvailableCard.setText("Your Today Available Flip Left : " + availableFlipBets);

                                                Random random = new Random();
                                                int randomImage = getImageList().get(random.nextInt(getImageList().size()));


                                                if (clickedPosition != -1 && cardPosition != -1) {

                                                    final ObjectAnimator oa1 = ObjectAnimator.ofFloat(frontImageViewList.get(clickedPosition), "scaleX", 1f, 0f);
                                                    final ObjectAnimator oa2 = ObjectAnimator.ofFloat(imageViewFlipped.get(clickedPosition), "scaleX", 0f, 1f);

                                                    oa1.setInterpolator(new DecelerateInterpolator());
                                                    oa2.setInterpolator(new AccelerateDecelerateInterpolator());

                                                    oa1.addListener(new AnimatorListenerAdapter() {
                                                        @Override
                                                        public void onAnimationEnd(Animator animation) {
                                                            super.onAnimationEnd(animation);

                                                            imageViewFlipped.get(clickedPosition).setImageResource(randomImage);
                                                            imageViewFlipped.get(clickedPosition).setTag(randomImage);

                                                            oa2.start();
                                                            isFront = false;

                                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                                checkForMatch(clickedPosition);
                                                            }
                                                        }
                                                    });
                                                    oa1.start();
                                                    setNewImage(clickedPosition);
                                                } else {
                                                    Toast.makeText(BTC_FlipTheCardActivity.this, "Please select the card to bet.", Toast.LENGTH_SHORT).show();
                                                }
                                            } else {
                                                Toast.makeText(BTC_FlipTheCardActivity.this, "Please enter the points between 10-500.", Toast.LENGTH_SHORT).show();
                                            }
                                        } else {
                                            Toast.makeText(BTC_FlipTheCardActivity.this, "You must have point greater than bet point in your account.", Toast.LENGTH_SHORT).show();
                                        }
                                    } else {
                                        Toast.makeText(BTC_FlipTheCardActivity.this, "Insufficient bet points, cannot bet now", Toast.LENGTH_SHORT).show();
                                    }

                                } else {
                                    Toast.makeText(BTC_FlipTheCardActivity.this, "Please enter the bet points.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

                    }
                } else {
                    try {
                        Log.e("--apiResponse--", "Error: FlipTheCard -------> " + new GsonBuilder().setPrettyPrinting().create().toJson(response.errorBody().string()));
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }

                }
            }

            @Override
            public void onFailure(@NonNull Call<BTC_ScratchCardResponse> call, @NonNull Throwable t) {
                Log.e("--apiResponse--", "Error: FlipTheCard onFailure-------> " + t.getMessage());

            }
        });


        binding.tvHowToPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayHowToPlayDialog();
            }
        });


        imageViews = new ImageView[4];

        imageViews[0] = findViewById(R.id.ic_card_1);
        imageViews[1] = findViewById(R.id.ic_card_2);
        imageViews[2] = findViewById(R.id.ic_card_3);
        imageViews[3] = findViewById(R.id.ic_card_4);

        for (int i = 0; i < imageArray.length; i++) {
            imageViews[i].setImageResource(imageArray[i]);

            final int position = i;
            imageViews[i].setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onClick(View v) {
                    for (ImageView imageView : imageViews) {
                        imageView.setForeground(null);
                    }
                    Drawable drawable = ContextCompat.getDrawable(BTC_FlipTheCardActivity.this, R.drawable.foregground_card);
                    imageViews[position].setForeground(drawable);

                    cardPosition = position;

                }
            });
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkForMatch(int clickedPosition) {
        shuffleImages();

        int clickedImageTag = (int) imageViewFlipped.get(clickedPosition).getTag();

        Log.d("--images-", "checkForMatch: clickedImageTag " + clickedImageTag);

        int listImage = imageArray[cardPosition];

        Log.d("--images-", "checkForMatch: listImage " + listImage);

        Handler h = new Handler();

        BTC_UpdatePoints updatePoints = new BTC_UpdatePoints("Flip bet Point Deduction", entered_bet_point, false);

        Call<BTC_ApiResponse> callDeductBetPoints = apiService.updateUserPoint(updatePoints);

        callDeductBetPoints.enqueue(new Callback<BTC_ApiResponse>() {
            @Override
            public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {

                if (response.isSuccessful()) {
                    BTC_ApiResponse apiResponse = response.body();

                    Log.d("--apiResponse--", "onResponse: Flip the Card points deduct ------> " + apiResponse);
                }
            }

            @Override
            public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {

            }
        });


        if (clickedImageTag == listImage) {
            Toast.makeText(BTC_FlipTheCardActivity.this, "Cards are matched", Toast.LENGTH_SHORT).show();
            Toast.makeText(BTC_FlipTheCardActivity.this, "Congratulations! You've got " + entered_bet_point * 2 + " 2x Points", Toast.LENGTH_SHORT).show();

            BTC_UpdatePoints rewardPoint = new BTC_UpdatePoints("Flip the Card 2x bet Points", entered_bet_point * 2, true);

            Call<BTC_ApiResponse> callReward = apiService.updateUserPoint(rewardPoint);

            callReward.enqueue(new Callback<BTC_ApiResponse>() {
                @Override
                public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {

                    if (response.isSuccessful()) {
                        BTC_ApiResponse apiResponse = response.body();

                        Log.d("--apiResponse--", "onResponse: Flip the Card points deduct ------> " + apiResponse);
                    }

                }

                @Override
                public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {

                }
            });

            h.postDelayed(new Runnable() {

                @Override
                public void run() {

                    getInstance(BTC_FlipTheCardActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            startActivity(new Intent(BTC_FlipTheCardActivity.this, BTC_HomeActivity.class));
                        }
                    }, MAIN_CLICK);


                }
            }, 2000);

        } else {
            Toast.makeText(BTC_FlipTheCardActivity.this, "Cards Not matched", Toast.LENGTH_SHORT).show();
            Toast.makeText(BTC_FlipTheCardActivity.this, "Sorry! You lose.", Toast.LENGTH_LONG).show();

            h.postDelayed(new Runnable() {

                @Override
                public void run() {
                    getInstance(BTC_FlipTheCardActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            startActivity(new Intent(BTC_FlipTheCardActivity.this, BTC_HomeActivity.class));
                        }
                    }, MAIN_CLICK);
                }
            }, 2000);


        }

        imageViews[cardPosition].setForeground(null);
    }

    private void setNewImage(int position) {
        if (position < getImageList().size()) {

            frontImageViewList.get(position).setImageResource(getImageList().get(position));
            frontImageViewList.get(position).setTag(getImageList().get(position));
        }
    }

    private List<Integer> getImageList() {
        List<Integer> imageList = new ArrayList<>();
        imageList.add(R.drawable.ic_card_j);
        imageList.add(R.drawable.ic_card_king);
        imageList.add(R.drawable.ic_card_queen);
        imageList.add(R.drawable.ic_card_a);

        return imageList;
    }

    private void shuffleImages() {

        List<Integer> imageList = getImageList();
        Collections.shuffle(imageList);
    }

    private void displayHowToPlayDialog() {
        Dialog dialog = new Dialog(this, R.style.customDialog);

        dialog.setContentView(R.layout.dialog_how_to_play);

        Window window = dialog.getWindow();
        window.setGravity(Gravity.CENTER);
        dialog.getWindow().setLayout(-1, -2);

        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(ContextCompat.getDrawable(BTC_FlipTheCardActivity.this, android.R.color.transparent));

        CardView cvOk = dialog.findViewById(R.id.cvOk);
        ImageView ivCancel = dialog.findViewById(R.id.ivCancel);

        cvOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_FlipTheCardActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        dialog.dismiss();
                    }
                }, MAIN_CLICK);

            }
        });

        ivCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_FlipTheCardActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        dialog.dismiss();
                    }
                }, MAIN_CLICK);

            }
        });


        dialog.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}