package com.festum.btcmining.BTC_api.model;

import java.util.ArrayList;

public class BTC_MinerData {

    public ArrayList<BTC_MinerDataList> dataList;
    public int dTotalPoint;

    public ArrayList<BTC_MinerDataList> getDataList() {
        return dataList;
    }

    public void setDataList(ArrayList<BTC_MinerDataList> dataList) {
        this.dataList = dataList;
    }

    public int getdTotalPoint() {
        return dTotalPoint;
    }

    public void setdTotalPoint(int dTotalPoint) {
        this.dTotalPoint = dTotalPoint;
    }
}
