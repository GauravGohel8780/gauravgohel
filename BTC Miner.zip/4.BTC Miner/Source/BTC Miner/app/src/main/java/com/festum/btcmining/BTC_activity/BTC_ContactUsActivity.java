package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Toast;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ContactUsRequest;
import com.festum.btcmining.BTC_api.model.BTC_ContactUsResponse;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.databinding.ActivityContactUsBinding;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_ContactUsActivity extends AdsBaseActivity {

    ActivityContactUsBinding binding;
    SharedPreferences sharedpreferences;
    String email;
    String firstName;
    String lastName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityContactUsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BTC_Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        BTC_ApiService apiService = retrofit.create(BTC_ApiService.class);


        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
        email = sharedpreferences.getString(BTC_Constants.EMAIL_KEY, "");
        firstName = sharedpreferences.getString(BTC_Constants.FIRST_NAME, "");
        lastName = sharedpreferences.getString(BTC_Constants.LAST_NAME, "");

        binding.etEmail.setText(email);
        binding.etName.setText(firstName + " " + lastName);

        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_ContactUsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

        binding.tvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = Objects.requireNonNull(binding.etName.getText()).toString();
                String email = Objects.requireNonNull(binding.etEmail.getText()).toString().trim();
                String subject = Objects.requireNonNull(binding.etSubject.getText()).toString().trim();
                String message = Objects.requireNonNull(binding.etMessage.getText()).toString().trim();

                if (TextUtils.isEmpty(name)) {
                    Toast.makeText(BTC_ContactUsActivity.this, "Please enter your full name", Toast.LENGTH_SHORT).show();
                } else if (!isValidEmail(email)) {
                    Toast.makeText(BTC_ContactUsActivity.this, getString(R.string.invalid_email_address), Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(subject)) {
                    Toast.makeText(BTC_ContactUsActivity.this, "Please enter the subject about your issue or query.", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(message)) {
                    Toast.makeText(BTC_ContactUsActivity.this, "Please enter the message about your issue or query.", Toast.LENGTH_SHORT).show();
                } else {

                    binding.clProgressBar.setVisibility(View.VISIBLE);

                    binding.clProgressBar.setVisibility(View.VISIBLE);

                    BTC_ContactUsRequest contactUsRequest = new BTC_ContactUsRequest(name, email, message, subject);

                    Call<BTC_ContactUsResponse> call = apiService.contactUs(contactUsRequest);

                    call.enqueue(new Callback<BTC_ContactUsResponse>() {
                        @Override
                        public void onResponse(@NonNull Call<BTC_ContactUsResponse> call, @NonNull Response<BTC_ContactUsResponse> response) {

                            if (response.isSuccessful()) {
                                BTC_ContactUsResponse apiResponse = response.body();

                                if (apiResponse != null) {
                                    getInstance(BTC_ContactUsActivity.this).ShowAd(new HandleClick() {
                                        @Override
                                        public void Show(boolean adShow) {
                                            Log.w("--apiResponse--", "ContactUsResponse" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));

                                            binding.clProgressBar.setVisibility(View.GONE);

                                            Toast.makeText(BTC_ContactUsActivity.this, "Ok! Message has been submitted. Will will contact you soon.", Toast.LENGTH_SHORT).show();

                                            getOnBackPressedDispatcher().onBackPressed();
                                        }
                                    }, MAIN_CLICK);


                                } else {
                                    binding.clProgressBar.setVisibility(View.GONE);
                                }
                            } else {
                                binding.clProgressBar.setVisibility(View.GONE);
                            }
                        }

                        @Override
                        public void onFailure(@NonNull Call<BTC_ContactUsResponse> call, @NonNull Throwable t) {

                        }
                    });


                }
            }
        });
    }

    private boolean isValidEmail(CharSequence target) {
        return Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);

    }
}