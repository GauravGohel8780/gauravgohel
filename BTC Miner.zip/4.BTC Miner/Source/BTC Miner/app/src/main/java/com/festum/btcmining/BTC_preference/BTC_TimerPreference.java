package com.festum.btcmining.BTC_preference;

import android.content.Context;
import android.content.SharedPreferences;

import com.festum.btcmining.BTC_constants.BTC_Constants;


public class BTC_TimerPreference {

    public static boolean isScratchDayPassed(Context context) {
        SharedPreferences sharedpreferences = context.getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        long lastCallTime = sharedpreferences.getLong(BTC_Constants.lastScratchCallTime, 0);
        long currentTime = System.currentTimeMillis();
        long oneDayInMillis = 24 * 60 * 60 * 1000;

        return (currentTime - lastCallTime) >= oneDayInMillis;
    }

    public static boolean isJackpotDayPassed(Context context) {
        SharedPreferences sharedpreferences = context.getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        long lastCallTime = sharedpreferences.getLong(BTC_Constants.lastJackpotCallTime, 0);
        long currentTime = System.currentTimeMillis();
        long oneDayInMillis = 24 * 60 * 60 * 1000;

        return (currentTime - lastCallTime) >= oneDayInMillis;
    }

    public static boolean isFlipDayPassed(Context context) {
        SharedPreferences sharedpreferences = context.getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        long lastCallTime = sharedpreferences.getLong(BTC_Constants.flipLastCallTime, 0);
        long currentTime = System.currentTimeMillis();
        long oneDayInMillis = 24 * 60 * 60 * 1000;

        return (currentTime - lastCallTime) >= oneDayInMillis;
    }

    public static boolean isSilverDayPassed(Context context) {
        SharedPreferences sharedpreferences = context.getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        long lastCallTime = sharedpreferences.getLong(BTC_Constants.silverLastCallTime, 0);
        long currentTime = System.currentTimeMillis();
        long oneDayInMillis = 24 * 60 * 60 * 1000;

        return (currentTime - lastCallTime) >= oneDayInMillis;
    }

    public static boolean isPlatinumDayPassed(Context context) {
        SharedPreferences sharedpreferences = context.getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        long lastCallTime = sharedpreferences.getLong(BTC_Constants.platinumLastCallTime, 0);
        long currentTime = System.currentTimeMillis();
        long oneDayInMillis = 24 * 60 * 60 * 1000;

        return (currentTime - lastCallTime) >= oneDayInMillis;
    }

    public static boolean isGoldenDayPassed(Context context) {
        SharedPreferences sharedpreferences = context.getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        long lastCallTime = sharedpreferences.getLong(BTC_Constants.goldenLastCallTime, 0);
        long currentTime = System.currentTimeMillis();
        long oneDayInMillis = 24 * 60 * 60 * 1000;

        return (currentTime - lastCallTime) >= oneDayInMillis;
    }


    public static void updateScratchLastCallTime(Context context) {
        SharedPreferences sharedpreferences = context.getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putLong(BTC_Constants.lastScratchCallTime, System.currentTimeMillis());
        editor.apply();
    }

    public static void updateSilverLastCallTime(Context context) {
        SharedPreferences sharedpreferences = context.getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putLong(BTC_Constants.silverLastCallTime, System.currentTimeMillis());
        editor.apply();
    }

    public static void updatePlatinumLastCallTime(Context context) {
        SharedPreferences sharedpreferences = context.getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putLong(BTC_Constants.platinumLastCallTime, System.currentTimeMillis());
        editor.apply();
    }

    public static void updateGoldenLastCallTime(Context context) {
        SharedPreferences sharedpreferences = context.getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putLong(BTC_Constants.goldenLastCallTime, System.currentTimeMillis());
        editor.apply();
    }

    public static void updateJackpotLastCallTime(Context context) {
        SharedPreferences sharedpreferences = context.getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putLong(BTC_Constants.lastJackpotCallTime, System.currentTimeMillis());
        editor.apply();
    }
    public static void updateFlipLastCallTime(Context context) {
        SharedPreferences sharedpreferences = context.getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putLong(BTC_Constants.flipLastCallTime, System.currentTimeMillis());
        editor.apply();
    }
}
