package com.festum.btcmining.BTC_fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.festum.btcmining.R;
import com.festum.btcmining.BTC_adapter.BTC_GlobalRankingAdapter;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_AllUsersDataRequest;
import com.festum.btcmining.BTC_api.model.BTC_AllUsersResponse;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_GlobalRankingFragment extends Fragment {

    RecyclerView rv_global_ranking;
    ArrayList<BTC_AllUsersDataRequest> leaderboardList = new ArrayList<>();
    SharedPreferences sharedpreferences;
    String userToken;
    ProgressBar progressBar;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_global_ranking, container, false);
        progressBar = view.findViewById(R.id.progress_bar);


        progressBar.setVisibility(View.VISIBLE);

        rv_global_ranking = view.findViewById(R.id.rv_global_ranking);

        sharedpreferences = requireActivity().getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @NotNull
            @Override
            public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                Request original = chain.request();
                Request.Builder requestBuilder = original.newBuilder()
                        .header("Authorization", "Bearer " + userToken)
                        .method(original.method(), original.body());

                Request request = requestBuilder.build();

                Log.d("--apiResponse--", "URL: " + request.url());
                Log.d("--apiResponse--", "Headers: " + request.headers());
                Log.d("--apiResponse--", "Body: " + request.body());

                return chain.proceed(request);
            }
        });

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BTC_Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        BTC_ApiService apiService = retrofit.create(BTC_ApiService.class);

        Call<BTC_AllUsersResponse> call = apiService.allUserRankList(true);

        call.enqueue(new Callback<BTC_AllUsersResponse>() {
            @Override
            public void onResponse(@NonNull Call<BTC_AllUsersResponse> call, @NonNull Response<BTC_AllUsersResponse> response) {
                progressBar.setVisibility(View.GONE);

                if (response.isSuccessful()) {
                    BTC_AllUsersResponse apiResponse = response.body();

                    if (apiResponse != null) {
                        List<BTC_AllUsersDataRequest> dataList = apiResponse.getData();

                        leaderboardList.addAll(dataList);

                        rv_global_ranking.setLayoutManager(new LinearLayoutManager(requireActivity()));
                        BTC_GlobalRankingAdapter adapter = new BTC_GlobalRankingAdapter(leaderboardList, "global");
                        rv_global_ranking.setAdapter(adapter);

                        Log.w("--apiResponse--", "leaderboard Fragment" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));
                    } else {
                        Log.e("--apiResponse--", "Error: Response body is null");
                    }
                } else {
                    try {
                        Log.e("--apiResponse--", "Error: user detail " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }

            }

            @Override
            public void onFailure(@NonNull Call<BTC_AllUsersResponse> call, @NonNull Throwable t) {
                Log.e("--apiResponse--", "Error: user detail onFailure " + new Gson().toJson(t.getMessage()));
            }
        });


        return view;
    }
}