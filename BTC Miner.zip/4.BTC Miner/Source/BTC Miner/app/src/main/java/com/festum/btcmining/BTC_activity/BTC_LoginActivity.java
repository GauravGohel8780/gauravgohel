package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.LinkMovementMethod;
import android.text.method.PasswordTransformationMethod;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.util.Patterns;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.R;
import com.festum.btcmining.SharedPrefs;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ApiResponse;
import com.festum.btcmining.BTC_api.model.BTC_EmailModel;
import com.festum.btcmining.BTC_api.model.BTC_LoginRequest;
import com.festum.btcmining.BTC_api.model.BTC_UserData;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.databinding.ActivityLoginBinding;
import com.google.android.material.card.MaterialCardView;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_LoginActivity extends AdsBaseActivity {

    ActivityLoginBinding binding;
    boolean isPasswordVisible = false;
    SharedPreferences sharedpreferences;
    String userToken;
    String pref_email;
    String pref_pass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        binding.tvForgotPassword.setOnClickListener(v -> {
            startActivity(new Intent(BTC_LoginActivity.this, BTC_ForgotPassworActivity.class));
        });

        String fullText1 = getResources().getString(R.string.new_to_foxcrypto_create_an_account);
        String signUpText = " Create an account";

        SpannableString login = new SpannableString(fullText1);

        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                startActivity(new Intent(BTC_LoginActivity.this, BTC_SignUpActivity.class));
            }

            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                super.updateDrawState(ds);
                ds.setUnderlineText(false);
                ds.setColor(getResources().getColor(R.color.orange));
                ds.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

            }
        };

        int startIndex = fullText1.indexOf(signUpText);
        int endIndex = startIndex + signUpText.length();
        login.setSpan(clickableSpan, startIndex, endIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        binding.tvSingUp.setText(login);
        binding.tvSingUp.setMovementMethod(LinkMovementMethod.getInstance());

        binding.tvLogIn.setOnClickListener(v -> {
            Dialog newDialog = new Dialog(BTC_LoginActivity.this, R.style.customDialog);

            newDialog.setContentView(R.layout.dialog_confirmation_link);
            newDialog.setCancelable(false);

            Objects.requireNonNull(newDialog.getWindow()).setGravity(Gravity.CENTER);
            newDialog.getWindow().setLayout(-1, -2);

            Objects.requireNonNull(newDialog.getWindow()).setBackgroundDrawable(ContextCompat.getDrawable(BTC_LoginActivity.this, android.R.color.transparent));

            newDialog.show();

            CardView cvCancel = newDialog.findViewById(R.id.cvCancel);
            ImageView ivCancel = newDialog.findViewById(R.id.ivCancel);
            CardView cvOk = newDialog.findViewById(R.id.cvOk);
            MaterialCardView mcvReSend = newDialog.findViewById(R.id.mcvReSend);
            LinearLayout ll = newDialog.findViewById(R.id.ll);


            ivCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    newDialog.dismiss();
                }
            });
            cvCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    newDialog.dismiss();
                }
            });


            mcvReSend.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    cvOk.setVisibility(View.VISIBLE);
                    ll.setVisibility(View.GONE);
                }
            });
            cvOk.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    getInstance(BTC_LoginActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            newDialog.dismiss();
                            startActivity(new Intent(BTC_LoginActivity.this, BTC_UserDetailActivity.class));
                        }
                    }, MAIN_CLICK);

                }
            });
        });


        Retrofit retrofit = new Retrofit.Builder().baseUrl(BTC_Constants.BASE_URL).addConverterFactory(GsonConverterFactory.create()).build();

        BTC_ApiService apiService = retrofit.create(BTC_ApiService.class);

        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);

        pref_email = sharedpreferences.getString(BTC_Constants.EMAIL_KEY, null);
        pref_pass = sharedpreferences.getString(BTC_Constants.PASSWORD_KEY, null);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");


        Log.d("--token--", "Login: userToken " + userToken);

        if (userToken != null) {
            if (pref_email != null && pref_pass != null) {

                OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

                httpClient.addInterceptor(new Interceptor() {
                    @NotNull
                    @Override
                    public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                        Request original = chain.request();
                        Request.Builder requestBuilder = original.newBuilder().header("Authorization", "Bearer " + userToken).method(original.method(), original.body());

                        Request request = requestBuilder.build();

                        Log.d("--apiResponse--", "URL: " + request.url());
                        Log.d("--apiResponse--", "Headers: " + request.headers());
                        Log.d("--apiResponse--", "Body: " + request.body());

                        return chain.proceed(request);
                    }
                });

                OkHttpClient client = httpClient.build();

                Retrofit loginRetrofit = new Retrofit.Builder().baseUrl(BTC_Constants.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(client).build();

                BTC_ApiService loginService = loginRetrofit.create(BTC_ApiService.class);

            }

        }


        binding.tvLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = Objects.requireNonNull(binding.edtEmail.getText()).toString().trim();
                String password = Objects.requireNonNull(binding.etPassword.getText()).toString();

                if (!isValidEmail(email)) {
                    Toast.makeText(BTC_LoginActivity.this, getString(R.string.invalid_email_address), Toast.LENGTH_SHORT).show();
                } else if (!isStrongPassword(password)) {
                    Toast.makeText(BTC_LoginActivity.this, R.string.password_validation_error, Toast.LENGTH_SHORT).show();
                } else {
                    binding.clProgressBar.setVisibility(View.VISIBLE);

                    BTC_LoginRequest request = new BTC_LoginRequest();
                    request.setvEmail(email);
                    request.setvPassword(password);

                    Call<BTC_ApiResponse> call = apiService.loginUser(request);


                    call.enqueue(new Callback<BTC_ApiResponse>() {
                        @Override
                        public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                            binding.clProgressBar.setVisibility(View.VISIBLE);
                            if (response.isSuccessful()) {

                                binding.clProgressBar.setVisibility(View.GONE);


                                BTC_ApiResponse apiResponse = response.body();

                                String token = apiResponse.getData().getUserToken();


                                Log.d("--token--", "Login--->: " + token);


                                Log.d("--apiResponse--", "onResponse: code " + apiResponse.getiStatusCode());
                                Log.d("--apiResponse--", "onResponse: data " + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse.getData()));
                                Log.d("--apiResponse--", "onResponse: " + token);


                                SharedPreferences.Editor editor = sharedpreferences.edit();

                                editor.putString(BTC_Constants.EMAIL_KEY, email);
                                editor.putString(BTC_Constants.PASSWORD_KEY, password);
                                editor.putString(BTC_Constants.USER_TOKEN, token);

                                editor.apply();


                                OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

                                userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");

                                httpClient.addInterceptor(new Interceptor() {
                                    @NotNull
                                    @Override
                                    public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                                        Request original = chain.request();
                                        Request.Builder requestBuilder = original.newBuilder().header("Authorization", "Bearer " + userToken).method(original.method(), original.body());

                                        Request request = requestBuilder.build();

                                        Log.d("--apiResponse--", "URL: " + request.url());
                                        Log.d("--apiResponse--", "Headers: " + request.headers());
                                        Log.d("--apiResponse--", "Body: " + request.body());

                                        return chain.proceed(request);
                                    }
                                });

                                OkHttpClient client = httpClient.build();

                                Retrofit loginRetrofit = new Retrofit.Builder().baseUrl(BTC_Constants.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(client).build();

                                BTC_ApiService loginService = loginRetrofit.create(BTC_ApiService.class);


                                Call<BTC_ApiResponse> loginCall = loginService.getUserDetails();

                                loginCall.enqueue(new Callback<BTC_ApiResponse>() {
                                    @Override
                                    public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                                        binding.clProgressBar.setVisibility(View.VISIBLE);

                                        if (response.isSuccessful()) {

                                            BTC_ApiResponse apiResponse = response.body();


                                            if (apiResponse != null) {
                                                BTC_UserData userData = apiResponse.getData();

                                                Log.w("--user_details--", "onResponse: " + new GsonBuilder().setPrettyPrinting().create().toJson(userData));

                                                SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
                                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                                editor.putString(BTC_Constants.FIRST_NAME, userData.getvFirstName());
                                                editor.putString(BTC_Constants.LAST_NAME, userData.getvLastName());
                                                editor.putString(BTC_Constants.COUNTRY_NAME, userData.getvCountry());
                                                editor.apply();

                                                getInstance(BTC_LoginActivity.this).ShowAd(new HandleClick() {
                                                    @Override
                                                    public void Show(boolean adShow) {
                                                        if (userData.getvFirstName() != null && userData.getvLastName() != null && userData.getvCountry() != null && userData.getvGender() != null) {
                                                            binding.clProgressBar.setVisibility(View.GONE);
                                                            if (SharedPrefs.getFirstTimeStartScreen(BTC_LoginActivity.this)) {
                                                                Intent intent = new Intent(BTC_LoginActivity.this, BTC_HomeActivity.class);
                                                                startActivity(intent);
                                                            } else {
                                                                SharedPrefs.setFirstTimeStartScreen(BTC_LoginActivity.this, true);
                                                                Intent intent = new Intent(BTC_LoginActivity.this, BTC_StartActivity.class);
                                                                startActivity(intent);
                                                            }

                                                        } else {
                                                            Intent i = new Intent(BTC_LoginActivity.this, BTC_UserDetailActivity.class);
                                                            startActivity(i);
                                                            finish();
                                                        }
                                                    }
                                                }, MAIN_CLICK);

                                            } else {
                                                binding.clProgressBar.setVisibility(View.GONE);
                                            }
                                        } else {
                                            binding.clProgressBar.setVisibility(View.GONE);
                                        }
                                    }

                                    @Override
                                    public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {
                                    }
                                });

                            } else {
                                binding.clProgressBar.setVisibility(View.GONE);

                                Log.d("--apiResponse--", "body else:  ");

                                try {
                                    assert response.errorBody() != null;
                                    if (response.errorBody().string().contains("Please verify email")) {


                                        Toast.makeText(BTC_LoginActivity.this, "Please verify email", Toast.LENGTH_SHORT).show();

                                        Log.d("--apiResponse--", "onResponse: link" + response.errorBody().string());


                                        Dialog newDialog = new Dialog(BTC_LoginActivity.this, R.style.customDialog);

                                        newDialog.setContentView(R.layout.dialog_confirmation_link);
                                        newDialog.setCancelable(false);

                                        Objects.requireNonNull(newDialog.getWindow()).setGravity(Gravity.CENTER);
                                        newDialog.getWindow().setLayout(-1, -2);

                                        Objects.requireNonNull(newDialog.getWindow()).setBackgroundDrawable(ContextCompat.getDrawable(BTC_LoginActivity.this, android.R.color.transparent));

                                        newDialog.show();

                                        ImageView ivCancel = newDialog.findViewById(R.id.ivCancel);
                                        CardView cvCancel = newDialog.findViewById(R.id.cvCancel);
                                        MaterialCardView mcvReSend = newDialog.findViewById(R.id.mcvReSend);
                                        CardView cvOk = newDialog.findViewById(R.id.cvOk);
                                        LinearLayout ll = newDialog.findViewById(R.id.ll);


                                        cvCancel.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                newDialog.dismiss();
                                                binding.clProgressBar.setVisibility(View.GONE);
                                            }
                                        });
                                        ivCancel.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                newDialog.dismiss();
                                                binding.clProgressBar.setVisibility(View.GONE);
                                            }
                                        });


                                        BTC_EmailModel emailModel = new BTC_EmailModel();
                                        emailModel.setEmail(email);
                                        Log.d("--apiResponse--", "onClick: getting Emila From MOdel" + emailModel.getEmail());
                                        Call<BTC_ApiResponse> apiResponseCall = apiService.resentLink(email);

                                        mcvReSend.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {

                                                binding.clProgressBar.setVisibility(View.VISIBLE);

                                                Log.d("--apiResponse--", "onClick: email" + email);

                                                apiResponseCall.enqueue(new Callback<BTC_ApiResponse>() {
                                                    @Override
                                                    public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {

                                                        if (response.isSuccessful()) {
                                                            binding.clProgressBar.setVisibility(View.GONE);
                                                            newDialog.dismiss();

                                                            Log.d("--apiResponse--", "Success: isSuccessful ");

                                                        } else {

                                                            binding.clProgressBar.setVisibility(View.GONE);
                                                            try {
                                                                binding.clProgressBar.setVisibility(View.GONE);

                                                                Log.e("--apiResponse--", "Error: else " + response.errorBody().string());
                                                            } catch (IOException e) {
                                                                throw new RuntimeException(e);
                                                            }
                                                        }
                                                    }

                                                    @Override
                                                    public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {
                                                        Log.e("--apiResponse--", "Error: onFailure " + new Gson().toJson(t.getMessage()));
                                                    }
                                                });

                                                cvOk.setVisibility(View.VISIBLE);
                                                ll.setVisibility(View.GONE);

                                                cvOk.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View v) {
                                                        newDialog.dismiss();
                                                    }
                                                });

                                                Toast.makeText(BTC_LoginActivity.this, "Link has been re-sent to your email", Toast.LENGTH_SHORT).show();
                                            }
                                        });

                                        Log.d("--apiResponse--", "verify mail  ");
                                    } else {
                                        Log.d("--apiResponse--", "onResponse: passwrod" + response.errorBody().string());
                                        Toast.makeText(BTC_LoginActivity.this, getString(R.string.email_or_password_is_incorrect), Toast.LENGTH_SHORT).show();
                                    }
                                } catch (IOException e) {
                                    throw new RuntimeException(e);
                                }
                            }
                        }

                        @Override
                        public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {
                            Log.e("--apiResponse--", "onFailure: " + t.getMessage());
                            Toast.makeText(BTC_LoginActivity.this, "failure", Toast.LENGTH_SHORT).show();
                            Toast.makeText(BTC_LoginActivity.this, "Error in request", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });

        binding.icPasswordVisibility.setImageDrawable(getDrawable(R.drawable.ic_unselect_eye));
        binding.etPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());

        binding.icPasswordVisibility.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isPasswordVisible = !isPasswordVisible;
                if (isPasswordVisible) {
                    binding.etPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    binding.icPasswordVisibility.setImageDrawable(getDrawable(R.drawable.ic_select_eye));
                } else {
                    binding.icPasswordVisibility.setImageDrawable(getDrawable(R.drawable.ic_unselect_eye));
                    binding.etPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
                binding.etPassword.setSelection(Objects.requireNonNull(binding.etPassword.getText()).length());
            }
        });

    }

    private boolean isValidEmail(CharSequence target) {
        return Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

    private boolean isStrongPassword(String password) {
        String regex = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }


    @Override
    protected void onStart() {
        super.onStart();
        Log.d("--token--", "Login: userToken " + userToken);
    }
}