package com.festum.btcmining.BTC_api.model;

public class BTC_ApiResponse {
    private int iStatusCode;
    private boolean isStatus;
    private BTC_UserData data;
    private String vMessage;

    public BTC_ApiResponse() {
    }

    public BTC_ApiResponse(int iStatusCode, boolean isStatus, BTC_UserData data, String vMessage) {
        this.iStatusCode = iStatusCode;
        this.isStatus = isStatus;
        this.data = data;
        this.vMessage = vMessage;
    }

    public int getiStatusCode() {
        return iStatusCode;
    }

    public void setiStatusCode(int iStatusCode) {
        this.iStatusCode = iStatusCode;
    }

    public boolean isStatus() {
        return isStatus;
    }

    public void setStatus(boolean status) {
        isStatus = status;
    }

    public BTC_UserData getData() {
        return data;
    }

    public void setData(BTC_UserData data) {
        this.data = data;
    }

    public String getvMessage() {
        return vMessage;
    }

    public void setvMessage(String vMessage) {
        this.vMessage = vMessage;
    }
}
