package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.View;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.R;
import com.festum.btcmining.databinding.ActivityContestBinding;
import com.festum.btcmining.BTC_fragment.BTC_AllContestsFragment;
import com.festum.btcmining.BTC_fragment.BTC_TransactionHistoryFragment;
import com.festum.btcmining.BTC_fragment.BTC_WinnerHistoryFragment;
import com.festum.btcmining.BTC_fragment.BTC_YouwinHistoryFragment;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class BTC_ContestActivity extends AdsBaseActivity {
    ActivityContestBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityContestBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.ivBack.setOnClickListener(v -> {
            getInstance(BTC_ContestActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    Intent intent = new Intent(BTC_ContestActivity.this, BTC_HomeActivity.class);
                    startActivity(intent);
                }
            }, BACK_CLICK);

        });


        tranferFragmnet(new BTC_AllContestsFragment());
        binding.tvWinnersHistory.setBackgroundTintList(ColorStateList.valueOf(getColor(R.color.toolbarcolor)));
        binding.tvTransactionHistory.setBackgroundTintList(ColorStateList.valueOf(getColor(R.color.toolbarcolor)));
        binding.tvYouWinHistory.setBackgroundTintList(ColorStateList.valueOf(getColor(R.color.toolbarcolor)));

        binding.tvWinnersHistory.setOnClickListener(v -> {
            getInstance(BTC_ContestActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    tranferFragmnet(new BTC_WinnerHistoryFragment());
                    binding.tvWinnersHistory.setBackgroundTintList(ColorStateList.valueOf(getColor(R.color.orange)));
                    binding.tvTransactionHistory.setBackgroundTintList(ColorStateList.valueOf(getColor(R.color.toolbarcolor)));
                    binding.tvYouWinHistory.setBackgroundTintList(ColorStateList.valueOf(getColor(R.color.toolbarcolor)));
                }
            }, MAIN_CLICK);
        });
        binding.tvTransactionHistory.setOnClickListener(v -> {
            getInstance(BTC_ContestActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    tranferFragmnet(new BTC_TransactionHistoryFragment());
                    binding.tvWinnersHistory.setBackgroundTintList(ColorStateList.valueOf(getColor(R.color.toolbarcolor)));
                    binding.tvTransactionHistory.setBackgroundTintList(ColorStateList.valueOf(getColor(R.color.orange)));
                    binding.tvYouWinHistory.setBackgroundTintList(ColorStateList.valueOf(getColor(R.color.toolbarcolor)));
                }
            }, MAIN_CLICK);
        });
        binding.tvYouWinHistory.setOnClickListener(v -> {
            getInstance(BTC_ContestActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    tranferFragmnet(new BTC_YouwinHistoryFragment());
                    binding.tvWinnersHistory.setBackgroundTintList(ColorStateList.valueOf(getColor(R.color.toolbarcolor)));
                    binding.tvTransactionHistory.setBackgroundTintList(ColorStateList.valueOf(getColor(R.color.toolbarcolor)));
                    binding.tvYouWinHistory.setBackgroundTintList(ColorStateList.valueOf(getColor(R.color.orange)));
                }
            }, MAIN_CLICK);
        });
    }

    private void tranferFragmnet(Fragment fragment) {
        getSupportFragmentManager().beginTransaction().replace(R.id.flContests, fragment).addToBackStack(null).commit();
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        getInstance(BTC_ContestActivity.this).ShowAd(new HandleClick() {
            @Override
            public void Show(boolean adShow) {
                Intent intent = new Intent(BTC_ContestActivity.this, BTC_HomeActivity.class);
                startActivity(intent);
            }
        }, BACK_CLICK);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}