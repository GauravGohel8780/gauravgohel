package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.BTC_adapter.BTC_GlobalRankingAdapter;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_AllUsersDataRequest;
import com.festum.btcmining.BTC_api.model.BTC_AllUsersResponse;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.R;
import com.festum.btcmining.databinding.ActivityActivemMinersBinding;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_ActivemMinersActivity extends AdsBaseActivity {
    ActivityActivemMinersBinding binding;
    ArrayList<BTC_AllUsersDataRequest> activeMinersList = new ArrayList<>();
    SharedPreferences sharedpreferences;
    String userToken;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityActivemMinersBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.clProgressBar.setVisibility(View.VISIBLE);

        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");


        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @NotNull
            @Override
            public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                Request original = chain.request();
                Request.Builder requestBuilder = original.newBuilder()
                        .header("Authorization", "Bearer " + userToken)
                        .method(original.method(), original.body());

                Request request = requestBuilder.build();

                Log.d("--apiResponse--", "URL: " + request.url());
                Log.d("--apiResponse--", "Headers: " + request.headers());
                Log.d("--apiResponse--", "Body: " + request.body());

                return chain.proceed(request);
            }
        });

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BTC_Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        BTC_ApiService apiService = retrofit.create(BTC_ApiService.class);

        Call<BTC_AllUsersResponse> call = apiService.activeMinersList();

        call.enqueue(new Callback<BTC_AllUsersResponse>() {
            @Override
            public void onResponse(@NonNull Call<BTC_AllUsersResponse> call, @NonNull Response<BTC_AllUsersResponse> response) {


                if (response.isSuccessful()) {
                    binding.clProgressBar.setVisibility(View.GONE);
                    BTC_AllUsersResponse apiResponse = response.body();

                    if (apiResponse != null) {
                        List<BTC_AllUsersDataRequest> dataList = apiResponse.getData();

                        activeMinersList.addAll(dataList);

                        binding.rvActiveMinersList.setLayoutManager(new LinearLayoutManager(BTC_ActivemMinersActivity.this));
                        BTC_GlobalRankingAdapter adapter = new BTC_GlobalRankingAdapter(activeMinersList, "");
                        binding.rvActiveMinersList.setAdapter(adapter);

                        Log.w("--apiResponse--", "Active miners" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));
                    } else {
                        Log.e("--apiResponse--", "Error: Response body is null");
                    }
                } else {
                    try {
                        Log.e("--apiResponse--", "Error: user detail " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<BTC_AllUsersResponse> call, @NonNull Throwable t) {
                Log.e("--apiResponse--", "Error: user detail onFailure " + new Gson().toJson(t.getMessage()));
            }
        });

        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_ActivemMinersActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}