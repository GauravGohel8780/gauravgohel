package com.festum.btcmining.BTC_receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;


public class BTC_CountdownReceiver extends BroadcastReceiver {

    private TextView hoursTextView, minutesTextView, secondsTextView, start_mining;
    LinearLayout ll_timing;
    private Handler handler;

    public BTC_CountdownReceiver(TextView hoursTextView, TextView minutesTextView, TextView secondsTextView, LinearLayout ll_timing, TextView start_mining) {
        this.hoursTextView = hoursTextView;
        this.minutesTextView = minutesTextView;
        this.secondsTextView = secondsTextView;
        this.ll_timing = ll_timing;
        this.start_mining = start_mining;

        this.handler = new Handler(Looper.getMainLooper());
    }

    @Override
    public void onReceive(Context context, Intent intent) {

        if (intent.getAction() != null && intent.getAction().equals("countdown_update_action")) {
            final long remainingTimeMillis = intent.getLongExtra("remainingTimeMillis", 0);

            handler.post(new Runnable() {
                @Override
                public void run() {
                    // Convert remaining time to hours, minutes, and seconds
                    long hours = remainingTimeMillis / (60 * 60 * 1000);
                    long minutes = (remainingTimeMillis % (60 * 60 * 1000)) / (60 * 1000);
                    long seconds = (remainingTimeMillis % (60 * 1000)) / 1000;

                    hoursTextView.setText(String.valueOf(hours));
                    minutesTextView.setText(String.valueOf(minutes));
                    secondsTextView.setText(String.valueOf(seconds));

                    ll_timing.setVisibility(View.VISIBLE);
                    start_mining.setVisibility(View.GONE);
                    start_mining.setText("Mining running");
                }
            });

            if (remainingTimeMillis == 0) {
                ll_timing.setVisibility(View.GONE);
                start_mining.setVisibility(View.VISIBLE);
                start_mining.setText("Start Mining");
            } else {
                ll_timing.setVisibility(View.VISIBLE);
                start_mining.setVisibility(View.GONE);
                start_mining.setText("Mining Running");
            }
        }
    }
}
