package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.Commen;
import com.festum.btcmining.databinding.ActivityMainBinding;
import com.iten.tenoku.ad.HandleClick.HandleClick;

public class BTC_MainActivity extends AdsBaseActivity {

    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Commen.SetSystemFullScreen(this);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.tvLogin.setOnClickListener(v -> {
            getInstance(BTC_MainActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    Intent intent = new Intent(BTC_MainActivity.this, BTC_LoginActivity.class);
                    startActivity(intent);
                }
            }, MAIN_CLICK);
        });
        binding.tvSignup.setOnClickListener(v -> {
            getInstance(BTC_MainActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    Intent intent = new Intent(BTC_MainActivity.this, BTC_SignUpActivity.class);
                    startActivity(intent);
                }
            }, MAIN_CLICK);
        });

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                Intent intent = new Intent(BTC_MainActivity.this, BTC_ExitActivity.class);
                startActivity(intent);
            }
        };

        getOnBackPressedDispatcher().addCallback(this, callback);
    }
}