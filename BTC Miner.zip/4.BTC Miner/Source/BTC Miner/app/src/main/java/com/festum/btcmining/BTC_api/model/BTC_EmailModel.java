package com.festum.btcmining.BTC_api.model;

public class BTC_EmailModel {

    String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
