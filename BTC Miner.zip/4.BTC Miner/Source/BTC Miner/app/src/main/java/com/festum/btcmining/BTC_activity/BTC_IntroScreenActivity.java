package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.Commen;
import com.festum.btcmining.R;
import com.festum.btcmining.SharedPrefs;
import com.festum.btcmining.databinding.ActivityIntroScreenBinding;
import com.festum.btcmining.BTC_fragment.BTC_FirstIntroFragment;
import com.festum.btcmining.BTC_fragment.BTC_SecondIntroFragment;
import com.festum.btcmining.BTC_fragment.BTC_ThirdIntroFragment;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.util.ArrayList;
import java.util.List;

public class BTC_IntroScreenActivity extends AdsBaseActivity {
    IntroPagerAdapter introPagerAdapter;
    LinearLayout llindicator;
    ActivityIntroScreenBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Commen.SetSystemFullScreen(this);
        binding = ActivityIntroScreenBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        llindicator = findViewById(R.id.llIndicator);

        introPagerAdapter = new IntroPagerAdapter(getSupportFragmentManager());
        introPagerAdapter.add(new BTC_FirstIntroFragment());
        introPagerAdapter.add(new BTC_SecondIntroFragment());
        introPagerAdapter.add(new BTC_ThirdIntroFragment());
        binding.vpIntro.setAdapter(introPagerAdapter);

        addIndicators(introPagerAdapter.getCount());

        binding.ivNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(BTC_IntroScreenActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        int currentItem = binding.vpIntro.getCurrentItem();
                        int lastItem = introPagerAdapter.getCount() - 1;
                        if (currentItem == lastItem) {
                            gotoLanguageSelection();
                        } else {
                            binding.vpIntro.setCurrentItem(currentItem + 1);
                        }
                    }
                }, MAIN_CLICK);
            }
        });

        binding.vpIntro.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                updateIndicators(position);
                binding.vpIntro.setCurrentItem(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });

    }


    private void gotoLanguageSelection() {
        SharedPrefs.setIntroScreenActivity(BTC_IntroScreenActivity.this, true);
        startActivity(new Intent(getApplicationContext(), BTC_MainActivity.class));
        finish();
    }


    private void addIndicators(int count) {
        for (int i = 0; i < count; i++) {
            ImageView indicator = new ImageView(this);
            indicator.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_selected_intro_dot));
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            layoutParams.setMargins(8, 0, 8, 0);
            llindicator.addView(indicator, layoutParams);
        }
        updateIndicators(0);
    }

    private void updateIndicators(int position) {
        for (int i = 0; i < llindicator.getChildCount(); i++) {
            ImageView indicator = (ImageView) llindicator.getChildAt(i);
            if (position == 0) {
                indicator.setImageDrawable(ContextCompat.getDrawable(this, i == position ? R.drawable.ic_selected_intro_dot : R.drawable.ic_unselected_intro_dot));
            } else if (position == 1) {
                indicator.setImageDrawable(ContextCompat.getDrawable(this, i == position ? R.drawable.ic_selected_intro_dot : R.drawable.ic_unselected_intro_dot));
            } else {
                indicator.setImageDrawable(ContextCompat.getDrawable(this, i == position ? R.drawable.ic_selected_intro_dot : R.drawable.ic_unselected_intro_dot));
            }

        }
    }

    public class IntroPagerAdapter extends FragmentPagerAdapter {

        private final List<Fragment> fragments;

        public IntroPagerAdapter(@NonNull FragmentManager fm) {
            super(fm, FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
            this.fragments = new ArrayList();
        }

        @Override
        public Fragment getItem(int position) {
            return this.fragments.get(position);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return super.getPageTitle(position);
        }

        public void add(Fragment fragment) {
            this.fragments.add(fragment);
        }

        @Override
        public int getCount() {
            return this.fragments.size();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}