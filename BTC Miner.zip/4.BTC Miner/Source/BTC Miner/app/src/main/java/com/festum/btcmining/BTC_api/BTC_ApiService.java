package com.festum.btcmining.BTC_api;

import com.festum.btcmining.BTC_api.model.BTC_ActiveMinersListResponse;
import com.festum.btcmining.BTC_api.model.BTC_AllUsersResponse;
import com.festum.btcmining.BTC_api.model.BTC_ApiResponse;
import com.festum.btcmining.BTC_api.model.BTC_ChangePassword;
import com.festum.btcmining.BTC_api.model.BTC_ContactUsRequest;
import com.festum.btcmining.BTC_api.model.BTC_ContactUsResponse;
import com.festum.btcmining.BTC_api.model.BTC_ContestParticipateResponse;
import com.festum.btcmining.BTC_api.model.BTC_ContestResponse;
import com.festum.btcmining.BTC_api.model.BTC_LoginRequest;
import com.festum.btcmining.BTC_api.model.BTC_MinerHistoryResponse;
import com.festum.btcmining.BTC_api.model.BTC_ParticipateContest;
import com.festum.btcmining.BTC_api.model.BTC_PlanApiResponse;
import com.festum.btcmining.BTC_api.model.BTC_PlanDetailResponse;
import com.festum.btcmining.BTC_api.model.BTC_QuestionAnsResponse;
import com.festum.btcmining.BTC_api.model.BTC_ReferralResponse;
import com.festum.btcmining.BTC_api.model.BTC_RegisterRequest;
import com.festum.btcmining.BTC_api.model.BTC_ResetForgotPassword;
import com.festum.btcmining.BTC_api.model.BTC_ScratchCardResponse;
import com.festum.btcmining.BTC_api.model.BTC_SpinWheelResponse;
import com.festum.btcmining.BTC_api.model.BTC_TransactionResponse;
import com.festum.btcmining.BTC_api.model.BTC_UpdatePoints;
import com.festum.btcmining.BTC_api.model.BTC_UserDetail;
import com.festum.btcmining.BTC_api.model.BTC_UserRegionResponse;
import com.festum.btcmining.BTC_api.model.BTC_WinnersHistoryResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface BTC_ApiService {

    @POST("api/v1/user/signUp")
    Call<BTC_ApiResponse> registerUser(@Body BTC_RegisterRequest request);

    @POST("api/v1/user/login")
    Call<BTC_ApiResponse> loginUser(@Body BTC_LoginRequest request);

    @POST("api/v1/user/forgot")
    Call<BTC_ApiResponse> resetPassword(@Body BTC_ResetForgotPassword request);

    @FormUrlEncoded
    @POST("api/v1/user/reSentLink")
    Call<BTC_ApiResponse> resentLink(@Field("vEmail") String email);


    @POST("api/v1/user/updateUserProfile")
    Call<BTC_ApiResponse> updateUserDetail(@Body BTC_UserDetail request);

    @POST("api/v1/user/changePassword")
    Call<BTC_ApiResponse> changePassword(@Body BTC_ChangePassword changePassword);

    @FormUrlEncoded
    @POST("api/v1/user/allUserRankList")
    Call<BTC_AllUsersResponse> allUserRankList(@Field("isGlobalRank") boolean isGlobalRank);

    @FormUrlEncoded
    @POST("api/v1/user/allUserRankList")
    Call<BTC_UserRegionResponse> usersByRegion(@Field("isGlobalRank") boolean isGlobalRank);

    @POST("api/v1/user/activeMinersList")
    Call<BTC_AllUsersResponse> activeMinersList();

    @POST("api/v1/plan/list")
    Call<BTC_PlanApiResponse> planList();

    @FormUrlEncoded
    @POST("api/v1/plan/getPlanDetails")
    Call<BTC_PlanDetailResponse> getPlanDetails(@Field("vPlanId") String planId);

    @POST("api/v1/contact/save")
    Call<BTC_ContactUsResponse> contactUs(@Body BTC_ContactUsRequest contactUsRequest);

    @POST("api/v1/contests/list")
    Call<BTC_ContestResponse> contestList();

    @POST("api/v1/contests/transactionHistory")
    Call<BTC_TransactionResponse> transactionHistory();

    @FormUrlEncoded
    @POST("api/v1/contests/getContestsDetails")
    Call<BTC_ContestResponse> getContestsDetails(@Field("vContestsId") String vContestsId);

    @FormUrlEncoded
    @POST("api/v1/contests/winnerHistory")
    Call<BTC_WinnersHistoryResponse> winnerHistory(@Field("vContestType") String vContestType);

    @POST("api/v1/question/list")
    Call<BTC_QuestionAnsResponse> questionsList();

    @POST("api/v1/spinWheel/list")
    Call<BTC_SpinWheelResponse> spinTheWheelList();

    @FormUrlEncoded
    @POST("api/v1/user/updateUserPoint")
    Call<BTC_ApiResponse> updateUserPoint(@Field("iTotalPoint") int iTotalPoint);

    @POST("api/v1/scratchCard/list")
    Call<BTC_ScratchCardResponse> scratchCardList();

    @POST("api/v1/contests/contestsParticipateUpdate")
    Call<BTC_ContestParticipateResponse> contestsParticipateUpdate(@Body BTC_ParticipateContest participateContest);

    @POST("api/v1/user/updateUserPoint")
    Call<BTC_ApiResponse> updateUserPoint(@Body BTC_UpdatePoints updatePoints);

    @POST("api/v1/user/minerHistorylist")
    Call<BTC_MinerHistoryResponse> minerHistorylist();

    @POST("api/v1/user/referralUserList")
    Call<BTC_ReferralResponse> referralUserList();

    @POST("api/v1/user/activeUserMiner")
    Call<BTC_ActiveMinersListResponse> activeUserMiner();

    @POST("api/v1/user/getUserDetails")
    Call<BTC_ApiResponse> getUserDetails();

    @FormUrlEncoded
    @POST("api/v1/user/selectContestsWinner")
    Call<BTC_ApiResponse> selectContestsWinner(@Field("vUserId") String userId,
                                               @Field("vContestsId") String vContestsId);

    @FormUrlEncoded
    @POST("api/v1/user/changePassword")
    Call<BTC_ApiResponse> changePassword(@Field("vEmail") String vEmail,
                                         @Field("vPassword") String vPassword);

    @FormUrlEncoded
    @POST("api/v1/user/upgradeUserPlan")
    Call<BTC_ApiResponse> upgradeUserPlan(@Field("vPlanId") String planId);

    @FormUrlEncoded
    @POST("api/v1/user/deleteUserProfile")
    Call<BTC_ApiResponse> deleteUserProfile(@Field("vUserId") String vUserId);

}
