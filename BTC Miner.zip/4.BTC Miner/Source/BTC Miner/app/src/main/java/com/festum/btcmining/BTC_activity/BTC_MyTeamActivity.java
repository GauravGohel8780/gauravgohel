package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.BTC_adapter.BTC_TeamMembersAdapter;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_AllUsersResponse;
import com.festum.btcmining.BTC_api.model.BTC_Referral;
import com.festum.btcmining.BTC_api.model.BTC_ReferralResponse;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.R;
import com.festum.btcmining.databinding.ActivityMyTeamBinding;
import com.festum.btcmining.BTC_utils.BTC_AuthorizationInterceptor;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.util.ArrayList;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_MyTeamActivity extends AdsBaseActivity {

    ActivityMyTeamBinding binding;
    ArrayList<BTC_Referral> referralArrayList = new ArrayList<>();
    BTC_TeamMembersAdapter teamMembersAdapter;
    SharedPreferences sharedpreferences;
    String userToken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityMyTeamBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.tvTotalMembers.setText("Total Team Members : " + referralArrayList.size());


        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");

        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();

        logging.setLevel(HttpLoggingInterceptor.Level.BODY);

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        httpClient.addInterceptor(logging);
        httpClient.addInterceptor(new BTC_AuthorizationInterceptor(userToken));

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder().baseUrl(BTC_Constants.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(client).build();

        BTC_ApiService apiService = retrofit.create(BTC_ApiService.class);

        binding.rvTeamMembers.setLayoutManager(new LinearLayoutManager(this));


        Call<BTC_ReferralResponse> call = apiService.referralUserList();
        Call<BTC_AllUsersResponse> apiResponseCall = apiService.activeMinersList();


        apiResponseCall.enqueue(new Callback<BTC_AllUsersResponse>() {
            @Override
            public void onResponse(@NonNull Call<BTC_AllUsersResponse> call, @NonNull Response<BTC_AllUsersResponse> response) {

                if (response.isSuccessful()) {
                    BTC_AllUsersResponse allUsersResponse = response.body();

                    binding.tvTotalMembers.setText("Total Team Members : " + allUsersResponse.getiCount());
                }
            }

            @Override
            public void onFailure(@NonNull Call<BTC_AllUsersResponse> call, @NonNull Throwable t) {

            }
        });
        call.enqueue(new Callback<BTC_ReferralResponse>() {
            @Override
            public void onResponse(@NonNull Call<BTC_ReferralResponse> call, @NonNull Response<BTC_ReferralResponse> response) {

                if (response.isSuccessful()) {
                    binding.progressBar.setVisibility(View.GONE);

                    BTC_ReferralResponse apiResponse = response.body();

                    if (apiResponse != null) {
                        referralArrayList = apiResponse.getData();

                        if (referralArrayList.isEmpty()) {
                            binding.rvTeamMembers.setVisibility(View.GONE);
                            binding.progressBar.setVisibility(View.GONE);
                            binding.tvNoReferrals.setVisibility(View.VISIBLE);
                        } else {
                            Log.d("--referralDataArrayList", "onResponse: " + new Gson().toJson(referralArrayList));

                            binding.tvTotalMembers.setText("Total Team Members : " + apiResponse.getiCount());
                            teamMembersAdapter = new BTC_TeamMembersAdapter(referralArrayList);
                            binding.rvTeamMembers.setAdapter(teamMembersAdapter);

                            if (referralArrayList.size() == 0) {
                                binding.tvCurrentMiner.setText("Current Miners: 00");
                            } else {
                                binding.tvCurrentMiner.setText("Current Miners: " + referralArrayList.size());
                            }
                        }

                        Log.w("--apiResponse--", "referralDataArrayList Response -----" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));

                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<BTC_ReferralResponse> call, @NonNull Throwable t) {

            }
        });

        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_MyTeamActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}