package com.festum.btcmining.BTC_adapter;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.festum.btcmining.R;
import com.festum.btcmining.BTC_activity.BTC_PlanPaymentDetailActivity;
import com.festum.btcmining.BTC_api.model.BTC_PlansModel;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import java.util.ArrayList;

public class BTC_UpgradePlanAdapter extends RecyclerView.Adapter<BTC_UpgradePlanAdapter.ViewHolder> {

    Context context;
    ArrayList<BTC_PlansModel> plansModelArrayList;

    public BTC_UpgradePlanAdapter(Context context, ArrayList<BTC_PlansModel> plansModelArrayList) {
        this.context = context;
        this.plansModelArrayList = plansModelArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.upgradeplans_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BTC_PlansModel plansModel = plansModelArrayList.get(position);


        if (position % 2 == 0) {
            holder.llBG.setBackgroundResource(R.drawable.img_card_bg_1);
        } else {
            holder.llBG.setBackgroundResource(R.drawable.img_card_bg_2);
        }

        holder.tv_plan_name.setText(String.valueOf(plansModel.getvPlanName()));
        holder.tv_plan_price.setText(String.valueOf(plansModel.getdPrice()));
        holder.tv_plan_speed.setText(String.valueOf(plansModel.getdSpeed()));
        holder.tv_plan_availability.setText(String.valueOf(plansModel.isAvailability()));
        holder.tv_total_withdrawal.setText(String.valueOf(plansModel.getiWithdrawal()));
        holder.tv_plan_validity.setText(String.valueOf(plansModel.getiValidity()));



        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance((Activity) context).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(context, BTC_PlanPaymentDetailActivity.class);
                        intent.putExtra(BTC_Constants.PLAN_ID, plansModel.get_id());

                        context.startActivity(intent);
                    }
                }, MAIN_CLICK);

            }
        });
    }

    @Override
    public int getItemCount() {
        return plansModelArrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv_plan_name;
        TextView tv_plan_price;
        TextView tv_plan_speed;
        TextView tv_plan_availability;
        TextView tv_total_withdrawal;
        TextView tv_plan_validity;
        LinearLayout llBG;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tv_plan_name = itemView.findViewById(R.id.tv_plan_name);
            tv_plan_price = itemView.findViewById(R.id.tv_plan_price);
            tv_plan_speed = itemView.findViewById(R.id.tv_plan_speed);
            tv_plan_availability = itemView.findViewById(R.id.tv_plan_availability);
            tv_total_withdrawal = itemView.findViewById(R.id.tv_total_withdrawal);
            tv_plan_validity = itemView.findViewById(R.id.tv_plan_validity);
            llBG = itemView.findViewById(R.id.llBG);
        }
    }
}
