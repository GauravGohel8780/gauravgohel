package com.festum.btcmining.BTC_api.model;

public class BTC_WinnersData {

    public String vUserName;
    public int dUserPoint;
    public long dtWinnerDate;

    public String getvUserName() {
        return vUserName;
    }

    public void setvUserName(String vUserName) {
        this.vUserName = vUserName;
    }

    public int getdUserPoint() {
        return dUserPoint;
    }

    public void setdUserPoint(int dUserPoint) {
        this.dUserPoint = dUserPoint;
    }

    public long getDtWinnerDate() {
        return dtWinnerDate;
    }

    public void setDtWinnerDate(long dtWinnerDate) {
        this.dtWinnerDate = dtWinnerDate;
    }
}
