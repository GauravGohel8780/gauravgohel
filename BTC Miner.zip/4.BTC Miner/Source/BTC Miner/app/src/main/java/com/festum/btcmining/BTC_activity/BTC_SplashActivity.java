package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.utils.MyApplication.sharedPreferencesHelper;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;

import com.festum.btcmining.Ads_Common.UnderMaintenanceActivity;
import com.festum.btcmining.BuildConfig;
import com.festum.btcmining.Commen;
import com.festum.btcmining.SharedPrefs;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ApiResponse;
import com.festum.btcmining.BTC_api.model.BTC_UserData;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.databinding.ActivitySplashBinding;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.activity.AppSettingActivity;
import com.iten.tenoku.databinding.DialogAppUpdateBinding;
import com.iten.tenoku.databinding.DialogInternetBinding;
import com.iten.tenoku.listeners.AppSettingListeners;
import com.iten.tenoku.networking.AdsResponse;
import com.iten.tenoku.utils.AdConstant;
import com.iten.tenoku.utils.AdUtils;
import com.iten.tenoku.utils.LogUtils;
import com.iten.tenoku.utils.MyApplication;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.single.PermissionListener;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_SplashActivity extends AppSettingActivity {

    ActivitySplashBinding binding;
    SharedPreferences sharedpreferences;
    String pref_email;
    String pref_pass;
    String userToken;
    Activity activity;
    private String countryName;
    int LAUNCH_INTERNET_ACTIVITY = 1;
    String currentDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Commen.SetSystemFullScreen(this);
        binding = ActivitySplashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        activity = BTC_SplashActivity.this;

        RotateAnimation rotate = new RotateAnimation(0, 50000, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        rotate.setDuration(500000);
        rotate.setInterpolator(new LinearInterpolator());
        binding.ivCoin.startAnimation(rotate);

        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);

        pref_email = sharedpreferences.getString(BTC_Constants.EMAIL_KEY, null);
        pref_pass = sharedpreferences.getString(BTC_Constants.PASSWORD_KEY, null);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");
        countryName = sharedpreferences.getString(BTC_Constants.COUNTRY_NAME, "");

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/YYYY");
        currentDate = simpleDateFormat.format(Calendar.getInstance().getTime());

        setAdRequestStatus();
        checkNotificationPermission();

    }

    private void checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (ActivityCompat.checkSelfPermission(activity, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                intAction();
            } else {
                checkNotificationPermissionAbove33();
            }
        } else {
            intAction();
        }
    }

    public void checkNotificationPermissionAbove33() {
        Dexter.withContext(this).withPermission(Manifest.permission.POST_NOTIFICATIONS).withListener(new PermissionListener() {
            @Override
            public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                LogUtils.logV("TAG", "MyPermission onPermissionGranted");
                intAction();
            }

            @Override
            public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
                intAction();
            }

            @Override
            public void onPermissionRationaleShouldBeShown(com.karumi.dexter.listener.PermissionRequest permissionRequest, PermissionToken permissionToken) {
                permissionToken.continuePermissionRequest();
            }

        }).onSameThread().check();
    }

    private void intAction() {
        checkConnection();
    }

    private void checkConnection() {
        if (AdUtils.isNetworkAvailable(activity)) {
            loadSetting();
        } else {
            ShowNetworkDialog();
        }
    }


    private void ShowNetworkDialog() {
        Dialog dialog = new Dialog(activity);
        DialogInternetBinding dialogInternetBinding = DialogInternetBinding.inflate(getLayoutInflater());
        dialog.setContentView(dialogInternetBinding.getRoot());
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().getAttributes().gravity = Gravity.CENTER;
        dialog.setCancelable(false);
        dialogInternetBinding.buttonRetry.setOnClickListener(v -> {
            dialog.dismiss();
            if (AdUtils.isNetworkAvailable(activity)) {
                loadSetting();
            } else {
                Intent i = new Intent(Settings.ACTION_SETTINGS);
                startActivityForResult(i, LAUNCH_INTERNET_ACTIVITY);
            }
        });
        dialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == LAUNCH_INTERNET_ACTIVITY) {
            checkConnection();
        }
    }

    private void loadSetting() {
        AppSettings(activity, BuildConfig.VERSION_CODE, BuildConfig.APPLICATION_ID, new AppSettingListeners() {
            @Override
            public void onResponseSuccess() {
                LogUtils.logE("TAG", "onResponseSuccess: ");
                if (sharedPreferencesHelper.getAppOpenAd()) {
                    new Handler().postDelayed(() -> {
                        LogUtils.logD("TAG", "AppOpenManager PassActivity after 5 sec: ");
                        openWelcome();
                    }, 4000);

                } else {
                    new Handler().postDelayed(() -> {
                        GoToMainScreen();
                    }, 3000);
                }
            }

            @Override
            public void onUnderMaintenance() {
                com.iten.tenoku.utils.MyApplication.appOpenManager.ShowOpenAd(true, adShow -> {
                    startActivity(new Intent(activity, UnderMaintenanceActivity.class));
                    finish();
                });
            }

            @Override
            public void onResponseFail() {
                LogUtils.logE("TAG", "onResponseFail  ===> ");
                if (!sharedPreferencesHelper.sharedPreferences.getAll().isEmpty()) {
                    try {
                        AdsResponse appSettings = new Gson().fromJson(sharedPreferencesHelper.getResponse(), AdsResponse.class);
                        if (appSettings.getIsStatus()) {

                            Log.e("TAG", "onResponseFail: " + appSettings.getIsStatus());
                            CheckBooleanValue(appSettings);
                            CheckStringValue(appSettings);
                            CheckIntegerValue(appSettings);
                            SetAdColors(appSettings);
                            SetRecyclerViewAd(sharedPreferencesHelper.getGridViewPerItemAdTwo(), sharedPreferencesHelper.getGridViewPerItemAdThree(), sharedPreferencesHelper.getListViewAd());
                            SetAdData(appSettings);
                            SetHideFeature(appSettings);
                            SetUserData(appSettings);
                            FacebookAd(appSettings);
                            preLoadAd();
                            HandelData(sharedPreferencesHelper.getUnderMaintenance());
                        }
                    } catch (Exception e) {
                    }
                    openWelcome();
                } else {
                    recreate();
                }
            }

            @Override
            public void onAppUpdate(String url) {
                LogUtils.logE("TAG", "onAppUpdate: ");
                AppDialogShow(url, 0);
            }

            @Override
            public void onAppRedirect(String url) {
                LogUtils.logE("TAG", "onAppRedirect: ");
                AppDialogShow(url, 1);
            }

            @Override
            public void onStatusChange() {
                LogUtils.logE("TAG", "onStatusChange: ");

            }
        });

    }

    public final void openWelcome() {
        com.iten.tenoku.utils.MyApplication.appOpenManager.ShowOpenAd(true, adShow -> {
            GoToMainScreen();
        });

    }

    public void GoToMainScreen() {
        if (pref_email != null && pref_pass != null) {
            transferToHomeScreen();
        } else {
            if (!SharedPrefs.getIntroScreenActivity(BTC_SplashActivity.this)) {
                startActivity(new Intent(BTC_SplashActivity.this, BTC_IntroScreenActivity.class));
            } else {
                startActivity(new Intent(BTC_SplashActivity.this, BTC_MainActivity.class));
            }

        }
    }

    private void AppDialogShow(String url, int i) {
        Dialog dialog = new Dialog(activity);
        DialogAppUpdateBinding dialogAppUpdateBinding = DialogAppUpdateBinding.inflate(getLayoutInflater());
        dialog.setContentView(dialogAppUpdateBinding.getRoot());
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().getAttributes().gravity = Gravity.CENTER;
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        if (i == 0) {
            dialogAppUpdateBinding.buttonRetry.setText(com.iten.tenoku.R.string.update_title);
            dialogAppUpdateBinding.txtTitle.setText(com.iten.tenoku.R.string.update_sub_title);
            dialogAppUpdateBinding.txtDecription.setText("");
            dialogAppUpdateBinding.txtDecription.setVisibility(View.GONE);
        } else if (i == 1) {
            dialogAppUpdateBinding.buttonRetry.setText(com.iten.tenoku.R.string.install_title);
            dialogAppUpdateBinding.txtTitle.setText(com.iten.tenoku.R.string.install_sub_title);
            dialogAppUpdateBinding.txtDecription.setVisibility(View.VISIBLE);
            dialogAppUpdateBinding.txtDecription.setText(com.iten.tenoku.R.string.install_descrption);
        } else {
            dialog.dismiss();
        }
        dialogAppUpdateBinding.buttonRetry.setOnClickListener(v -> {
            dialog.dismiss();
            try {
                Uri marketUri = Uri.parse(url);
                Intent marketIntent = new Intent(Intent.ACTION_VIEW, marketUri);
                startActivity(marketIntent);
            } catch (ActivityNotFoundException ignored) {
            }
        });
        dialog.show();
    }


    private void transferToHomeScreen() {
        if (userToken != null) {
            if (pref_email != null && pref_pass != null) {

                OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

                httpClient.addInterceptor(new Interceptor() {
                    @NotNull
                    @Override
                    public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                        Request original = chain.request();
                        Request.Builder requestBuilder = original.newBuilder().header("Authorization", "Bearer " + userToken).method(original.method(), original.body());

                        Request request = requestBuilder.build();

                        Log.d("--apiResponse--", "URL: " + request.url());
                        Log.d("--apiResponse--", "Headers: " + request.headers());
                        Log.d("--apiResponse--", "Body: " + request.body());

                        return chain.proceed(request);
                    }
                });

                OkHttpClient client = httpClient.build();

                Retrofit loginRetrofit = new Retrofit.Builder().baseUrl(BTC_Constants.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(client).build();

                BTC_ApiService loginService = loginRetrofit.create(BTC_ApiService.class);


                Call<BTC_ApiResponse> loginCall = loginService.getUserDetails();

                loginCall.enqueue(new Callback<BTC_ApiResponse>() {
                    @Override
                    public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {

                        if (response.isSuccessful()) {

                            BTC_ApiResponse apiResponse = response.body();


                            if (apiResponse != null) {
                                BTC_UserData userData = apiResponse.getData();

                                Log.w("--user_details--", "onResponse: " + new GsonBuilder().setPrettyPrinting().create().toJson(userData));

                                countryName = apiResponse.getData().getvCountry();

                                SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.putString(BTC_Constants.FIRST_NAME, userData.getvFirstName());
                                editor.putString(BTC_Constants.LAST_NAME, userData.getvLastName());
                                editor.putString(BTC_Constants.COUNTRY_NAME, apiResponse.getData().getvCountry());
                                editor.apply();


                                if (userData.getvFirstName() != null && userData.getvLastName() != null) {
                                    if (SharedPrefs.getFirstTimeStartScreen(BTC_SplashActivity.this)) {
                                        Intent intent = new Intent(BTC_SplashActivity.this, BTC_HomeActivity.class);
                                        startActivity(intent);
                                    } else {
                                        SharedPrefs.setFirstTimeStartScreen(BTC_SplashActivity.this, true);
                                        Intent intent = new Intent(BTC_SplashActivity.this, BTC_StartActivity.class);
                                        startActivity(intent);
                                    }
                                } else {
                                    Intent i = new Intent(BTC_SplashActivity.this, BTC_UserDetailActivity.class);
                                    startActivity(i);
                                }
                            }
                        } else {
                            try {
                                Log.w("--user_details--", "onResponse: " + new GsonBuilder().setPrettyPrinting().create().toJson(response.errorBody().string()));
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }

                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {
                        Log.w("--user_details--", "onResponse: error" + (t.getMessage()));

                    }
                });
            }

        } else {

            Intent intent = new Intent(BTC_SplashActivity.this, BTC_MainActivity.class);
            startActivity(intent);
        }
    }

    private void setAdRequestStatus() {
        if (!MyApplication.sharedPreferencesHelper.getUserSavedDate().equals(currentDate)) {
//            Log.e(TAG, "Saved Date--------------->" + MyApplication.sharedPreferencesHelper.getUserSavedDate());
//            Log.e(TAG, "Current Date--------------->" + currentDate);
//            Log.e(TAG, "Total Failed Count: ------->" + MyApplication.sharedPreferencesHelper.getTotalFailedCount());
            MyApplication.sharedPreferencesHelper.setTotalFailedCount(AdConstant.ResetTotalCount);
            MyApplication.sharedPreferencesHelper.setAdmobFailedCount(AdConstant.ResetTotalCount);
            MyApplication.sharedPreferencesHelper.setFbFailedCount(AdConstant.ResetTotalCount);
            MyApplication.sharedPreferencesHelper.setUserSavedDate(currentDate);
            sharedPreferencesHelper.setRequestDataSend(false);
        }
    }
}