package com.festum.btcmining.BTC_adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.model.BTC_UserByRegionData;

import java.util.ArrayList;
import java.util.Collections;

public class BTC_UserByRegionAdapter extends RecyclerView.Adapter<BTC_UserByRegionAdapter.ViewHolder> {

    ArrayList<BTC_UserByRegionData> leaderboardList;

    public BTC_UserByRegionAdapter(ArrayList<BTC_UserByRegionData> leaderboardList) {
        this.leaderboardList = leaderboardList;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.userbyregion_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BTC_UserByRegionData leaderboardModel = leaderboardList.get(position);

        String country = leaderboardModel.getvCountry();

        if (country != null) {
            holder.tv_country_name.setText(country);
        }

        holder.tv_position.setText(String.valueOf(position + 1));
        holder.tv_winning_score.setText(String.valueOf(leaderboardModel.getdPoint()));
    }

    @Override
    public int getItemCount() {
        return leaderboardList.size();
    }

    public static String hideCharacters(String inputString) {
        if (inputString.length() >= 2) {
            int asteriskCount = Math.min(6, inputString.length() - 2);
            String hiddenPart = String.join("", Collections.nCopies(asteriskCount, "*"));
            return inputString.substring(0, 2) + hiddenPart;
        } else {
            return inputString;
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv_position;
        TextView tv_country_name;
        TextView tv_winning_score;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tv_position = itemView.findViewById(R.id.tv_position);
            tv_country_name = itemView.findViewById(R.id.tv_player_name);
            tv_winning_score = itemView.findViewById(R.id.tv_winning_score);
        }


    }

}
