package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.R;
import com.festum.btcmining.databinding.ActivityLeaderboardBinding;
import com.festum.btcmining.BTC_fragment.BTC_GlobalRankingFragment;
import com.festum.btcmining.BTC_fragment.BTC_UserByRegionFragment;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class BTC_LeaderboardActivity extends AdsBaseActivity {

    ActivityLeaderboardBinding binding;
    Activity activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityLeaderboardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        activity = this;


        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_LeaderboardActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(BTC_LeaderboardActivity.this, BTC_HomeActivity.class);
                        startActivity(intent);
                    }
                }, BACK_CLICK);
            }
        });


        binding.cvGlobalRanking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_LeaderboardActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        binding.cvGlobalRanking.setCardBackgroundColor(ContextCompat.getColor(BTC_LeaderboardActivity.this, R.color.orange));
                        binding.cvUserbyRegion.setCardBackgroundColor(ContextCompat.getColor(BTC_LeaderboardActivity.this, R.color.tranperent));

                        if (!activity.isFinishing()) {
                            getSupportFragmentManager().beginTransaction()
                                    .replace(R.id.fragment_container, new BTC_GlobalRankingFragment())
                                    .addToBackStack(null)
                                    .commit();
                        }
                    }
                }, MAIN_CLICK);
            }
        });
        binding.cvGlobalRanking.performClick();


        binding.cvUserbyRegion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_LeaderboardActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        if (!activity.isFinishing()) {
                            binding.cvGlobalRanking.setCardBackgroundColor(ContextCompat.getColor(BTC_LeaderboardActivity.this, R.color.tranperent));
                            binding.cvUserbyRegion.setCardBackgroundColor(ContextCompat.getColor(BTC_LeaderboardActivity.this, R.color.orange));

                            getSupportFragmentManager().beginTransaction()
                                    .replace(R.id.fragment_container, new BTC_UserByRegionFragment())
                                    .addToBackStack(null)
                                    .commit();
                        }
                    }
                }, MAIN_CLICK);
            }
        });

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                getInstance(BTC_LeaderboardActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(BTC_LeaderboardActivity.this, BTC_HomeActivity.class);
                        startActivity(intent);
                    }
                }, BACK_CLICK);
            }
        };
        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}