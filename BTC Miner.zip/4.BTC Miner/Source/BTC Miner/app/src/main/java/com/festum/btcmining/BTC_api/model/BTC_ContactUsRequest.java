package com.festum.btcmining.BTC_api.model;

public class BTC_ContactUsRequest {

    public String vName;
    public String vEmail;
    public String vSubject;
    public String vMessage;

    public BTC_ContactUsRequest(String vName, String vEmail, String vSubject, String vMessage) {
        this.vName = vName;
        this.vEmail = vEmail;
        this.vSubject = vSubject;
        this.vMessage = vMessage;
    }

    public String getvName() {
        return vName;
    }

    public void setvName(String vName) {
        this.vName = vName;
    }

    public String getvEmail() {
        return vEmail;
    }

    public void setvEmail(String vEmail) {
        this.vEmail = vEmail;
    }

    public String getvSubject() {
        return vSubject;
    }

    public void setvSubject(String vSubject) {
        this.vSubject = vSubject;
    }

    public String getvMessage() {
        return vMessage;
    }

    public void setvMessage(String vMessage) {
        this.vMessage = vMessage;
    }
}
