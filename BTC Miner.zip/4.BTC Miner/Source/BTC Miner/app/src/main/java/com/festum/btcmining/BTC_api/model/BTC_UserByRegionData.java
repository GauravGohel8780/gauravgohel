package com.festum.btcmining.BTC_api.model;

public class BTC_UserByRegionData {

    public String _id;
    public String vCountry;
    public int dPoint;
    public boolean isDeleted;

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getvCountry() {
        return vCountry;
    }

    public void setvCountry(String vCountry) {
        this.vCountry = vCountry;
    }

    public int getdPoint() {
        return dPoint;
    }

    public void setdPoint(int dPoint) {
        this.dPoint = dPoint;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }
}
