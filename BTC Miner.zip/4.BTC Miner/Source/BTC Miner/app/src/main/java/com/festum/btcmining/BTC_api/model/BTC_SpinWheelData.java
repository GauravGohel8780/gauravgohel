package com.festum.btcmining.BTC_api.model;

import java.util.ArrayList;

public class BTC_SpinWheelData {

    public String _id;
    public ArrayList<Integer> arrSpinWheelPoint;
    public int iTotalOneDaySpin;
    public boolean isTodaySpinComplete;
    public boolean isDeleted;
    public String vSpinWheelType;
    public Object dtCreatedAt;

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public ArrayList<Integer> getArrSpinWheelPoint() {
        return arrSpinWheelPoint;
    }

    public void setArrSpinWheelPoint(ArrayList<Integer> arrSpinWheelPoint) {
        this.arrSpinWheelPoint = arrSpinWheelPoint;
    }

    public int getiTotalOneDaySpin() {
        return iTotalOneDaySpin;
    }

    public void setiTotalOneDaySpin(int iTotalOneDaySpin) {
        this.iTotalOneDaySpin = iTotalOneDaySpin;
    }

    public boolean isTodaySpinComplete() {
        return isTodaySpinComplete;
    }

    public void setTodaySpinComplete(boolean todaySpinComplete) {
        isTodaySpinComplete = todaySpinComplete;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public String getvSpinWheelType() {
        return vSpinWheelType;
    }

    public void setvSpinWheelType(String vSpinWheelType) {
        this.vSpinWheelType = vSpinWheelType;
    }

    public Object getDtCreatedAt() {
        return dtCreatedAt;
    }

    public void setDtCreatedAt(Object dtCreatedAt) {
        this.dtCreatedAt = dtCreatedAt;
    }
}
