package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.R;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.databinding.ActivityReferFriendBinding;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class BTC_ReferFriendActivity extends AdsBaseActivity {

    ActivityReferFriendBinding binding;
    SharedPreferences sharedpreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityReferFriendBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
        String referral_code = sharedpreferences.getString(BTC_Constants.REFERRAL_CODE, "");

        Log.d("--apiResponse--", "onCreate: referral_code " + referral_code);

        binding.tvReferralCode.setText(referral_code);

        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_ReferFriendActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

        binding.ivCopy.setOnClickListener(v -> {
            getInstance(BTC_ReferFriendActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("label", binding.tvReferralCode.getText().toString());
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(BTC_ReferFriendActivity.this, "Copy Referral Code", Toast.LENGTH_SHORT).show();
                }
            }, MAIN_CLICK);
        });


        binding.cvShareCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Intent.ACTION_SEND);
                myIntent.setType("text/plain");
                String sub = "Enter your Referral code to friend's profile";
                String body = getString(R.string.referral_share_desc) + "\n\n" + "Referral code: " + referral_code;
                myIntent.putExtra(Intent.EXTRA_SUBJECT, sub);
                myIntent.putExtra(Intent.EXTRA_TEXT, sub + "\n\n" + body);
                startActivity(Intent.createChooser(myIntent, "Share Using"));
            }
        });
    }
    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}
