package com.festum.btcmining.BTC_api.model;

import java.util.ArrayList;

public class BTC_ContestResponse {

    int iStatusCode;
    boolean isStatus;
    int iCount;
    ArrayList<BTC_ContestsData> data;
    String vMessage;

    public int getiStatusCode() {
        return iStatusCode;
    }

    public void setiStatusCode(int iStatusCode) {
        this.iStatusCode = iStatusCode;
    }

    public boolean isStatus() {
        return isStatus;
    }

    public void setStatus(boolean status) {
        isStatus = status;
    }

    public int getiCount() {
        return iCount;
    }

    public void setiCount(int iCount) {
        this.iCount = iCount;
    }

    public ArrayList<BTC_ContestsData> getData() {
        return data;
    }

    public void setData(ArrayList<BTC_ContestsData> data) {
        this.data = data;
    }

    public String getvMessage() {
        return vMessage;
    }

    public void setvMessage(String vMessage) {
        this.vMessage = vMessage;
    }
}
