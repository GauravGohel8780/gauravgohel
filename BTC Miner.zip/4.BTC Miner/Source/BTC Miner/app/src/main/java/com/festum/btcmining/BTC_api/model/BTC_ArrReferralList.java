package com.festum.btcmining.BTC_api.model;

public class BTC_ArrReferralList {

    public String _id;
    public String vFirstName;
    public String vLastName;
    public String vEmail;
    public Object dtCreatedAt;

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getvFirstName() {
        return vFirstName;
    }

    public void setvFirstName(String vFirstName) {
        this.vFirstName = vFirstName;
    }

    public String getvLastName() {
        return vLastName;
    }

    public void setvLastName(String vLastName) {
        this.vLastName = vLastName;
    }

    public String getvEmail() {
        return vEmail;
    }

    public void setvEmail(String vEmail) {
        this.vEmail = vEmail;
    }

    public Object getDtCreatedAt() {
        return dtCreatedAt;
    }

    public void setDtCreatedAt(Object dtCreatedAt) {
        this.dtCreatedAt = dtCreatedAt;
    }
}
