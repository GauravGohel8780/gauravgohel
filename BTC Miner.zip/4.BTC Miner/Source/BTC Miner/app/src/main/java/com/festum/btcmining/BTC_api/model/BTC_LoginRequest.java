package com.festum.btcmining.BTC_api.model;


public class BTC_LoginRequest {

    String vEmail;
    String vPassword;

    public BTC_LoginRequest(String vEmail, String vPassword, String vReferralCode) {
        this.vEmail = vEmail;
        this.vPassword = vPassword;
    }

    public BTC_LoginRequest(String vEmail, String vPassword) {
        this.vEmail = vEmail;
        this.vPassword = vPassword;
    }

    public BTC_LoginRequest() {
    }

    public String getvEmail() {
        return vEmail;
    }

    public void setvEmail(String vEmail) {
        this.vEmail = vEmail;
    }

    public String getvPassword() {
        return vPassword;
    }

    public void setvPassword(String vPassword) {
        this.vPassword = vPassword;
    }
}

