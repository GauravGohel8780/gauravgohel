package com.festum.btcmining.BTC_adapter;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.model.BTC_UserData;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

public class BTC_YourWinAdapter extends RecyclerView.Adapter<BTC_YourWinAdapter.ViewHolder> {

    public BTC_YourWinAdapter(ArrayList<BTC_UserData> winnersModelArrayList, String activity) {
        this.winnersModelArrayList = winnersModelArrayList;
        this.activity = activity;
    }

    ArrayList<BTC_UserData> winnersModelArrayList;
    String activity;
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.winnershistory_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BTC_UserData winnersModel = winnersModelArrayList.get(position);

        holder.tv_winner_name.setText(winnersModel.getvFirstName() + " " + winnersModel.getvLastName());
        holder.tv_winner_date.setText(formatDate(winnersModel.getDtCreatedAt()));
        holder.tv_winner_point.setText(winnersModel.getdPoint());
    }

    @Override
    public int getItemCount() {
        return winnersModelArrayList.size();
    }

    private String formatDate(long milliseconds) /* This is your topStory.getTime()*1000 */ {
        DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy' 'HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliseconds);
        TimeZone tz = TimeZone.getDefault();
        sdf.setTimeZone(tz);
        return sdf.format(calendar.getTime());
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView tv_winner_name;
        TextView tv_winner_date;
        TextView tv_winner_point;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tv_winner_name = itemView.findViewById(R.id.tv_winner_name);
            tv_winner_date = itemView.findViewById(R.id.tv_winner_date);
            tv_winner_point = itemView.findViewById(R.id.tv_winner_point);
        }
    }
}

