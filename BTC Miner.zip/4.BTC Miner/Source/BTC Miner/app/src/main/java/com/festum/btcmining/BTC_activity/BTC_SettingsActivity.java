package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Toast;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ApiResponse;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.databinding.ActivitySettingsBinding;
import com.google.android.material.card.MaterialCardView;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.Objects;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_SettingsActivity extends AdsBaseActivity {

    ActivitySettingsBinding binding;
    SharedPreferences sharedpreferences;
    String userToken;
    String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivitySettingsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");
        userId = sharedpreferences.getString(BTC_Constants.USER_ID, "");

        Log.d("--deleteProfile--", "onCreate: userId " + userId);

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @NotNull
            @Override
            public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                Request original = chain.request();
                Request.Builder requestBuilder = original.newBuilder()
                        .header("Authorization", "Bearer " + userToken)
                        .method(original.method(), original.body());

                Request request = requestBuilder.build();

                Log.d("--apiResponse--", "URL: " + request.url());
                Log.d("--apiResponse--", "Headers: " + request.headers());
                Log.d("--apiResponse--", "Body: " + request.body());

                return chain.proceed(request);
            }
        });

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BTC_Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        BTC_ApiService apiService = retrofit.create(BTC_ApiService.class);


        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_SettingsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

        binding.cvDeleteYourProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Call<BTC_ApiResponse> call = apiService.deleteUserProfile(userId);

                Dialog dialog = new Dialog(BTC_SettingsActivity.this, R.style.customDialog);
                dialog.setContentView(R.layout.dialog_delete_profile);
                dialog.setCancelable(false);

                Objects.requireNonNull(dialog.getWindow()).setGravity(Gravity.CENTER);
                dialog.getWindow().setLayout(-1, -2);

                Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(ContextCompat.getDrawable(BTC_SettingsActivity.this, android.R.color.transparent));

                dialog.show();


                CardView cvConfirm = dialog.findViewById(R.id.cvConfirm);
                MaterialCardView mcvCancel = dialog.findViewById(R.id.mcvCancel);

                cvConfirm.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        call.enqueue(new Callback<BTC_ApiResponse>() {
                            @Override
                            public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                                if (response.isSuccessful()) {
                                    BTC_ApiResponse apiResponse = response.body();

                                    if (apiResponse != null) {
                                        Log.d("--deleteProfile--", "onResponse: deleteProfile  ----" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));

                                        SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
                                        SharedPreferences.Editor editor = sharedPreferences.edit();
                                        editor.clear();
                                        editor.apply();

                                        dialog.dismiss();

                                        Intent intent = new Intent(BTC_SettingsActivity.this, BTC_MainActivity.class);
                                        startActivity(intent);
                                    }
                                } else {
                                    try {

                                        dialog.dismiss();
                                        Toast.makeText(BTC_SettingsActivity.this, "Issue while deleting this profile. Please try again after some time.", Toast.LENGTH_SHORT).show();

                                        Log.d("--deleteProfile--", "Error: deleteProfile  ----" + response.errorBody().string());
                                    } catch (IOException e) {
                                        throw new RuntimeException(e);
                                    }

                                }
                            }

                            @Override
                            public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {

                            }
                        });

                    }
                });

                mcvCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
            }
        });

        binding.cvYourMiningHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_SettingsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(BTC_SettingsActivity.this, BTC_MinerHistoryActivity.class);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);

            }
        });

        binding.cvContactUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_SettingsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(BTC_SettingsActivity.this, BTC_ContactUsActivity.class);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });

        binding.cvHowOurAppWorks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_SettingsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(BTC_SettingsActivity.this, BTC_HowAppWorksActivity.class);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}