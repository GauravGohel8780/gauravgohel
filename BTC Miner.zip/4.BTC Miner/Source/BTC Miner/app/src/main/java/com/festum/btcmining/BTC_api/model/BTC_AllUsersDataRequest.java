package com.festum.btcmining.BTC_api.model;

public class BTC_AllUsersDataRequest {

    String _id;
    public int dPoint;
    public String vFirstName;
    String vCountry;

    public String getvCountry() {
        return vCountry;
    }

    public void setvCountry(String vCountry) {
        this.vCountry = vCountry;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public int getdPoint() {
        return dPoint;
    }

    public void setdPoint(int dPoint) {
        this.dPoint = dPoint;
    }

    public String getvFirstName() {
        return vFirstName;
    }

    public void setvFirstName(String vFirstName) {
        this.vFirstName = vFirstName;
    }

}
