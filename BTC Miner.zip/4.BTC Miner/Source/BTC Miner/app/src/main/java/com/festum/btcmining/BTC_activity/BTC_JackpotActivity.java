package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ApiResponse;
import com.festum.btcmining.BTC_api.model.BTC_ScratchCardData;
import com.festum.btcmining.BTC_api.model.BTC_ScratchCardResponse;
import com.festum.btcmining.BTC_api.model.BTC_UpdatePoints;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.databinding.ActivityJackpotBinding;
import com.festum.btcmining.BTC_preference.BTC_TimerPreference;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_JackpotActivity extends AdsBaseActivity {

    ActivityJackpotBinding binding;
    ProgressBar progressBar;
    Handler handler = new Handler();
    boolean isGenerating = false;
    int availableJackpots;
    int jackpotPoints;
    SharedPreferences sharedpreferences;
    String userToken;
    BTC_ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityJackpotBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        progressBar = findViewById(R.id.progressBar);


        progressBar.setVisibility(View.GONE);


        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");
        availableJackpots = sharedpreferences.getInt(BTC_Constants.AVAILABLE_JACKPOTS, availableJackpots);

        binding.tvAvailablejackpot.setText("Your Today Jackpot Count Left = " + availableJackpots);

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @NotNull
            @Override
            public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                Request original = chain.request();
                Request.Builder requestBuilder = original.newBuilder()
                        .header("Authorization", "Bearer " + userToken)
                        .method(original.method(), original.body());

                Request request = requestBuilder.build();

                Log.d("--apiResponse--", "URL: " + request.url());
                Log.d("--apiResponse--", "Headers: " + request.headers());
                Log.d("--apiResponse--", "Body: " + request.body());

                return chain.proceed(request);
            }
        });

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BTC_Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        apiService = retrofit.create(BTC_ApiService.class);


        Call<BTC_ScratchCardResponse> call = apiService.scratchCardList();

        call.enqueue(new Callback<BTC_ScratchCardResponse>() {
            @Override
            public void onResponse(@NonNull Call<BTC_ScratchCardResponse> call, @NonNull Response<BTC_ScratchCardResponse> response) {
                if (response.isSuccessful()) {
                    BTC_ScratchCardResponse apiResponse = response.body();

                    SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();

                    if (BTC_TimerPreference.isJackpotDayPassed(BTC_JackpotActivity.this)) {
                        if (apiResponse != null) {
                            ArrayList<BTC_ScratchCardData> scratchCardData = apiResponse.getData();

                            BTC_ScratchCardData cardData = scratchCardData.get(0);

                            Log.w("--apiResponse--", "Jackpot resposne-------> " + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));

                            availableJackpots = cardData.getiTotalOneDayScratch();

                            editor.putInt(BTC_Constants.AVAILABLE_JACKPOTS, availableJackpots);
                            editor.apply();

                            Log.d("--isDayPassed--", "onResponse: " + BTC_TimerPreference.isJackpotDayPassed(BTC_JackpotActivity.this) + "-------> total cards--" + availableJackpots);

                            binding.tvAvailablejackpot.setText("Your Today Jackpot Count Left = " + availableJackpots);


                            binding.tvPress.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    getInstance(BTC_JackpotActivity.this).ShowAd(new HandleClick() {
                                        @Override
                                        public void Show(boolean adShow) {
                                            availableJackpots--;

                                            startGeneratingNumbers();

                                            SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
                                            SharedPreferences.Editor editor = sharedPreferences.edit();
                                            editor.putInt(BTC_Constants.AVAILABLE_JACKPOTS, availableJackpots);
                                            editor.apply();

                                            binding.tvAvailablejackpot.setText("Your Today Jackpot Count Left = " + availableJackpots);

                                        }
                                    }, MAIN_CLICK);
                                }
                            });
                        }
                        BTC_TimerPreference.updateJackpotLastCallTime(BTC_JackpotActivity.this);
                    } else {

                        Log.d("--isDayPassed--", "isDayPassed: jackpotPoints else " + BTC_TimerPreference.isJackpotDayPassed(BTC_JackpotActivity.this) + "-------> total cards--" + availableJackpots);
                        Log.d("--isDayPassed--", "isDayPassed: jackpotPoints else " + BTC_TimerPreference.isJackpotDayPassed(BTC_JackpotActivity.this) + "-------> Points--" + jackpotPoints);

                        availableJackpots = sharedpreferences.getInt(BTC_Constants.AVAILABLE_JACKPOTS, availableJackpots);

                        binding.tvAvailablejackpot.setText("Your Today Jackpot Count Left = " + availableJackpots);

                        binding.tvPress.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (availableJackpots >= 1) {
                                    getInstance(BTC_JackpotActivity.this).ShowAd(new HandleClick() {
                                        @Override
                                        public void Show(boolean adShow) {
                                            startGeneratingNumbers();

                                            availableJackpots--;

                                            SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
                                            SharedPreferences.Editor editor = sharedPreferences.edit();
                                            editor.putInt(BTC_Constants.AVAILABLE_JACKPOTS, availableJackpots);
                                            editor.apply();

                                            binding.tvAvailablejackpot.setText("Your Today Jackpot Count Left = " + availableJackpots);
                                        }
                                    }, MAIN_CLICK);

                                } else {
                                    Toast.makeText(BTC_JackpotActivity.this, "Insufficient jackpot left", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                } else {
                    try {
                        Log.w("--apiResponse--", "ScratchCard data-------> " + new GsonBuilder().setPrettyPrinting().create().toJson(response.errorBody().string()));

                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }

            }

            @Override
            public void onFailure(@NonNull Call<BTC_ScratchCardResponse> call, @NonNull Throwable t) {

            }
        });


        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_JackpotActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });


        binding.tvPress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_JackpotActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        progressBar.setVisibility(View.GONE);
                        startGeneratingNumbers();
                        availableJackpots--;
                    }
                }, MAIN_CLICK);

            }
        });
    }


    private void startGeneratingNumbers() {
        if (!isGenerating) {
            isGenerating = true;
            progressBar.setVisibility(View.GONE);

            generateRandomNumber();


            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    stopGeneratingNumbers();
                }
            }, 5000);
        }
    }

    private void stopGeneratingNumbers() {
        progressBar.setVisibility(View.GONE);
        handler.removeCallbacksAndMessages(null);
        finalizeLotteryNumbers();
    }

    private void generateRandomNumber() {
        Random random = new Random();
        int randomNumber = random.nextInt(5) + 1;
        int randomNumber1 = random.nextInt(5) + 1;
        int randomNumber2 = random.nextInt(5) + 1;


        binding.tvJackpotNo1.setText(String.valueOf(randomNumber));
        binding.tvJackpotNo2.setText(String.valueOf(randomNumber1));
        binding.tvJackpotNo3.setText(String.valueOf(randomNumber2));


        if (progressBar.getProgress() >= progressBar.getMax()) {
            finalizeLotteryNumbers();
        } else {

            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    generateRandomNumber();
                }
            }, 100);

            progressBar.setProgress(progressBar.getProgress() + 1);
        }
    }

    private void finalizeLotteryNumbers() {

        Random random = new Random();
        int number1 = random.nextInt(10) + 1;
        int number2 = random.nextInt(10) + 1;
        int number3 = random.nextInt(10) + 1;

        binding.tvAvailablejackpot.setText("Your Today Jackpot Count Left = " + availableJackpots);

        Dialog dialog = new Dialog(BTC_JackpotActivity.this, R.style.customDialog);

        dialog.setContentView(R.layout.dialog_quiz_result);
        dialog.setCancelable(false);

        dialog.getWindow().setLayout(-1, -2);

        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(ContextCompat.getDrawable(BTC_JackpotActivity.this, android.R.color.transparent));
        dialog.getWindow().setGravity(Gravity.CENTER);

        dialog.show();

        TextView tvDitail = dialog.findViewById(R.id.tvDitail);

        jackpotPoints = (number1) + (number2) + (number3);

        SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.apply();
        tvDitail.setText(jackpotPoints + " Points");
        TextView tvBtnText = dialog.findViewById(R.id.tvBtnText);
        tvBtnText.setText("Collect");

        ImageView iv = dialog.findViewById(R.id.ivQuiz);
        iv.setImageDrawable(getDrawable(R.drawable.img_dialog_spinwin_bg));

        dialog.findViewById(R.id.cvButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BTC_UpdatePoints updatePoints = new BTC_UpdatePoints("Jackpot winning", jackpotPoints, true);

                Call<BTC_ApiResponse> callPoints = apiService.updateUserPoint(updatePoints);

                callPoints.enqueue(new Callback<BTC_ApiResponse>() {
                    @Override
                    public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                        BTC_ApiResponse apiResponse = response.body();

                        Log.d("--apiResponse--", "onResponse: jackpot points------> " + apiResponse);
                        dialog.dismiss();

                        Intent intent = new Intent(BTC_JackpotActivity.this, BTC_HomeActivity.class);
                        startActivity(intent);
                    }

                    @Override
                    public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {

                    }
                });


            }
        });


        String num1 = String.format("%d", number1);
        String num2 = String.format("%d", number2);
        String num3 = String.format("%d", number3);

        binding.tvJackpotNo1.setText(num1);
        binding.tvJackpotNo2.setText(num2);
        binding.tvJackpotNo3.setText(num3);

        progressBar.setProgress(0);
        progressBar.setVisibility(View.GONE);
        isGenerating = false;


        binding.tvJackpotNo1.setTextColor(ContextCompat.getColor(this, R.color.red));
        binding.tvJackpotNo2.setTextColor(ContextCompat.getColor(this, R.color.red));
        binding.tvJackpotNo3.setTextColor(ContextCompat.getColor(this, R.color.red));

    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}