package com.festum.btcmining.BTC_api.model;

public class BTC_UpdatePoints {

    public String vTransectionName;
    public int iTotalPoint;
    public boolean isIncrease;

    public BTC_UpdatePoints(String vTransectionName, int iTotalPoint, boolean isIncrease) {
        this.vTransectionName = vTransectionName;
        this.iTotalPoint = iTotalPoint;
        this.isIncrease = isIncrease;
    }

    public String getvTransectionName() {
        return vTransectionName;
    }

    public void setvTransectionName(String vTransectionName) {
        this.vTransectionName = vTransectionName;
    }

    public int getiTotalPoint() {
        return iTotalPoint;
    }

    public void setiTotalPoint(int iTotalPoint) {
        this.iTotalPoint = iTotalPoint;
    }

    public boolean isIncrease() {
        return isIncrease;
    }

    public void setIncrease(boolean increase) {
        isIncrease = increase;
    }
}
