package com.festum.btcmining.BTC_api.model;

public class BTC_MinerDataList {

    public String _id;
    public boolean isIncrease;
    public boolean isDeleted;
    public String vTransectionName;
    public int dTransectionAmount;
    public long dtCreatedAt;

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public boolean isIncrease() {
        return isIncrease;
    }

    public void setIncrease(boolean increase) {
        isIncrease = increase;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public String getvTransectionName() {
        return vTransectionName;
    }

    public void setvTransectionName(String vTransectionName) {
        this.vTransectionName = vTransectionName;
    }

    public int getdTransectionAmount() {
        return dTransectionAmount;
    }

    public void setdTransectionAmount(int dTransectionAmount) {
        this.dTransectionAmount = dTransectionAmount;
    }

    public long getDtCreatedAt() {
        return dtCreatedAt;
    }

    public void setDtCreatedAt(long dtCreatedAt) {
        this.dtCreatedAt = dtCreatedAt;
    }
}
