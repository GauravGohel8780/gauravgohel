package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ApiResponse;
import com.festum.btcmining.BTC_api.model.BTC_QuestionAnsModel;
import com.festum.btcmining.BTC_api.model.BTC_QuestionAnsResponse;
import com.festum.btcmining.BTC_api.model.BTC_UpdatePoints;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.databinding.ActivityQuizBinding;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_QuizActivity extends AdsBaseActivity {
    ActivityQuizBinding binding;
    ArrayList<TextView> optionTextViews;
    SharedPreferences sharedpreferences;
    String userToken;
    private int currentQuestion = 0;
    int correctAnswers = 0;
    BTC_ApiService apiService;
    ArrayList<BTC_QuestionAnsModel> questions = new ArrayList<>();
    Map<Integer, String> selectedAnswersMap = new HashMap<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityQuizBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        optionTextViews = new ArrayList<>();
        optionTextViews.add(findViewById(R.id.tv_option_1));
        optionTextViews.add(findViewById(R.id.tv_option_2));
        optionTextViews.add(findViewById(R.id.tv_option_3));

        binding.tvPrevious.setVisibility(View.GONE);


        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");


        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @NotNull
            @Override
            public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                Request original = chain.request();
                Request.Builder requestBuilder = original.newBuilder().header("Authorization", "Bearer " + userToken).method(original.method(), original.body());

                Request request = requestBuilder.build();

                Log.d("--apiResponse--", "URL: " + request.url());
                Log.d("--apiResponse--", "Headers: " + request.headers());
                Log.d("--apiResponse--", "Body: " + request.body());

                return chain.proceed(request);
            }
        });

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder().baseUrl(BTC_Constants.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(client).build();

        apiService = retrofit.create(BTC_ApiService.class);


        Call<BTC_QuestionAnsResponse> call = apiService.questionsList();

        call.enqueue(new Callback<BTC_QuestionAnsResponse>() {
            @Override
            public void onResponse(@NonNull Call<BTC_QuestionAnsResponse> call, @NonNull Response<BTC_QuestionAnsResponse> response) {
                BTC_QuestionAnsResponse apiResponse = response.body();

                if (apiResponse != null) {
                    if (apiResponse.getData() != null && !apiResponse.getData().isEmpty()) {
                        questions = apiResponse.getData();

                        showQuestion(0);
                    } else {
                        Log.e("--apiResponse--", "Question data is empty");
                    }
                } else {
                    Log.e("--apiResponse--", "API response is null");
                }

                Log.w("--apiResponse--", "QuestionAnsModel" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));
            }

            @Override
            public void onFailure(@NonNull Call<BTC_QuestionAnsResponse> call, @NonNull Throwable t) {

            }
        });


        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_QuizActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });


        binding.tvNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_QuizActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        onNextButtonClick(v);
                    }
                }, MAIN_CLICK);
            }
        });

        binding.tvPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_QuizActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        onPreviousButtonClick(v);
                    }
                }, MAIN_CLICK);
            }
        });

    }


    private void showQuestion(int questionIndex) {
        BTC_QuestionAnsModel currentQuestionObject = questions.get(questionIndex);
        binding.tvQuestion.setText(currentQuestionObject.getvQuestionTitle());

        int qpostion = questionIndex + 1;

        binding.tvTitleName.setText("Questions : " + qpostion + "/" + questions.size());

        if (questionIndex == 0) {
            binding.tvPrevious.setVisibility(View.GONE);
        } else {
            binding.tvPrevious.setVisibility(View.VISIBLE);
        }


        List<String> options = currentQuestionObject.getArrOptions();

        for (int i = 0; i < options.size() && i < optionTextViews.size(); i++) {
            optionTextViews.get(i).setText(options.get(i));
            optionTextViews.get(i).setBackground(ContextCompat.getDrawable(this, R.drawable.bg_edittext));
            optionTextViews.get(i).setTextColor(ContextCompat.getColor(this, R.color.white));
        }

        String userAnswer = getUserAnswer(questionIndex);
        if (userAnswer != null) {
            for (TextView optionTextView : optionTextViews) {
                if (optionTextView.getText().toString().equals(userAnswer)) {
                    optionTextView.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_orange_border));
                    optionTextView.setTextColor(ContextCompat.getColor(this, R.color.orange));

                }
            }
        }

        for (int i = 0; i < optionTextViews.size(); i++) {
            optionTextViews.get(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onOptionSelected((TextView) v);
                }
            });
        }

        if (questionIndex == questions.size() - 1) {
            binding.tvNext.setText("Submit Quiz");
        } else {
            binding.tvNext.setText("Next");
        }
    }

    public void onOptionSelected(TextView selectedOption) {

        String selectedAnswer = selectedOption.getText().toString();
        BTC_QuestionAnsModel currentQuestionObject = questions.get(currentQuestion);

        if (!currentQuestionObject.isAnswered()) {
            currentQuestionObject.setAnswered(true);

            for (TextView optionTextView : optionTextViews) {
                optionTextView.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_edittext));
                optionTextView.setTextColor(ContextCompat.getColor(this, R.color.white));
            }

            if (selectedAnswer.equals(currentQuestionObject.getCorrectAnswer())) {
                correctAnswers++;
            }

            selectedOption.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_orange_border));
            selectedOption.setTextColor(ContextCompat.getColor(this, R.color.orange));

            selectedAnswersMap.put(currentQuestion, selectedAnswer);
        }
    }

    public void onPreviousButtonClick(View view) {
        if (currentQuestion > 0) {
            currentQuestion--;
            showQuestion(currentQuestion);
        }
    }

    private boolean isAnyOptionSelected() {
        BTC_QuestionAnsModel currentQuestionObject = questions.get(currentQuestion);
        return currentQuestionObject.isAnswered();
    }

    public void onNextButtonClick(View view) {
        if (!isAnyOptionSelected()) {
            Toast.makeText(this, "Please select an option", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!isQuizAllowed()) {
            Toast.makeText(this, "You can only take the quiz once a day", Toast.LENGTH_SHORT).show();
            return;
        }

        currentQuestion++;

        if (currentQuestion < questions.size()) {
            showQuestion(currentQuestion);
        } else {
            saveSubmissionTime();
            showResultDialog();
        }
    }

    private int calculateUserScore() {
        int score = 0;
        for (int i = 0; i < questions.size(); i++) {
            if (questions.get(i).isAnswered()) {
                String userAnswer = getUserAnswer(i);
                String correctAnswer = questions.get(i).getvAnswer();
                if (userAnswer != null && userAnswer.equals(correctAnswer)) {
                    score++;
                }
            }
        }
        return score;
    }

    private void saveSubmissionTime() {
        SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putLong(BTC_Constants.QUIZ_LAST_SUBMISSION_TIME, System.currentTimeMillis());
        editor.apply();
    }

    private boolean isQuizAllowed() {
        SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        long lastSubmissionTime = sharedPreferences.getLong(BTC_Constants.QUIZ_LAST_SUBMISSION_TIME, 0);
        long currentTime = System.currentTimeMillis();

        return currentTime - lastSubmissionTime >= 24 * 60 * 60 * 1000;
    }


    private void showResultDialog() {

        Dialog resultDialog = new Dialog(this);
        resultDialog.setContentView(R.layout.dialog_quiz_result);

        resultDialog.getWindow().setLayout(-1, -2);

        Objects.requireNonNull(resultDialog.getWindow()).setBackgroundDrawable(ContextCompat.getDrawable(BTC_QuizActivity.this, android.R.color.transparent));

        ImageView ivQuiz = resultDialog.findViewById(R.id.ivQuiz);
        TextView tvDitail = resultDialog.findViewById(R.id.tvDitail);
        CardView cvButton = resultDialog.findViewById(R.id.cvButton);
        TextView tvBtnText = resultDialog.findViewById(R.id.tvBtnText);


        String resultMessage;
        int userScore = calculateUserScore();
        int totalScore = questions.size();

        if (userScore == totalScore) {

            resultMessage = "You Win 40 Points";
            tvBtnText.setText("Collect");
            ivQuiz.setImageResource(R.drawable.img_dialog_win_bg);

            BTC_UpdatePoints updatePoints = new BTC_UpdatePoints("Quiz Winning Points ", 40, true);
            Call<BTC_ApiResponse> call = apiService.updateUserPoint(updatePoints);

            cvButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    call.enqueue(new Callback<BTC_ApiResponse>() {
                        @Override
                        public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {

                            if (response.isSuccessful()) {
                                BTC_ApiResponse apiResponse = response.body();

                                Intent intent = new Intent(BTC_QuizActivity.this, BTC_ExtraEarningActivity.class);
                                startActivity(intent);
                                finish();
                                Log.w("--apiResponse--", "onResponse: quiz updatePoints " + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));

                                resultDialog.dismiss();
                            }
                        }

                        @Override
                        public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {

                        }
                    });
                }
            });

        } else {

            resultMessage = "Better Luck Next Time!";
            tvBtnText.setText("Return");
            ivQuiz.setImageResource(R.drawable.img_dialog_lost_bg);

            cvButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    resultDialog.setCancelable(false);
                    resultDialog.dismiss();
                    getOnBackPressedDispatcher().onBackPressed();
                }
            });
        }


        tvDitail.setText(resultMessage);


        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultDialog.dismiss();
                getOnBackPressedDispatcher().onBackPressed();
            }
        });

        resultDialog.show();
    }

    private String getUserAnswer(int questionIndex) {
        return selectedAnswersMap.get(questionIndex);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}