package com.festum.btcmining.BTC_adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.model.BTC_MinerDataList;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

public class BTC_MinerHistoryAdapter extends RecyclerView.Adapter<BTC_MinerHistoryAdapter.ViewHolder> {
    ArrayList<BTC_MinerDataList> winnersModelArrayList;

    public BTC_MinerHistoryAdapter(ArrayList<BTC_MinerDataList> winnersModelArrayList) {
        this.winnersModelArrayList = winnersModelArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.minerhistory_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BTC_MinerDataList winnersModel = winnersModelArrayList.get(position);

        holder.tv_transaction_name.setText(winnersModel.getvTransectionName());
        holder.tv_transaction_date.setText(formatDate(winnersModel.getDtCreatedAt()));

        if (winnersModel.isIncrease()) {
            holder.tv_transaction_amount.setText("+" + winnersModel.getdTransectionAmount());
        } else {
            holder.tv_transaction_amount.setText("-" + winnersModel.getdTransectionAmount());
        }
    }

    @Override
    public int getItemCount() {
        return winnersModelArrayList.size();
    }


    private String formatDate(long milliseconds) /* This is your topStory.getTime()*1000 */ {
        DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy' 'HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliseconds);
        TimeZone tz = TimeZone.getDefault();
        sdf.setTimeZone(tz);
        return sdf.format(calendar.getTime());
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv_transaction_name;
        TextView tv_transaction_date;
        TextView tv_transaction_amount;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tv_transaction_name = itemView.findViewById(R.id.tv_winner_name);
            tv_transaction_date = itemView.findViewById(R.id.tv_winner_date);
            tv_transaction_amount = itemView.findViewById(R.id.tv_point_history);
        }
    }
}
