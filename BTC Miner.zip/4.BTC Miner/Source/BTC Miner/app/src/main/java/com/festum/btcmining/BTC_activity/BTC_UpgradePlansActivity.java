package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.BTC_adapter.BTC_UpgradePlanAdapter;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_PlanApiResponse;
import com.festum.btcmining.BTC_api.model.BTC_PlansModel;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.R;
import com.festum.btcmining.databinding.ActivityUpgradePlansBinding;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_UpgradePlansActivity extends AdsBaseActivity {


    ArrayList<BTC_PlansModel> plansModelArrayList = new ArrayList<>();
    ActivityUpgradePlansBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityUpgradePlansBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BTC_Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        BTC_ApiService apiService = retrofit.create(BTC_ApiService.class);


        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_UpgradePlansActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });


        Call<BTC_PlanApiResponse> call = apiService.planList();

        call.enqueue(new Callback<BTC_PlanApiResponse>() {
            @Override
            public void onResponse(@NonNull Call<BTC_PlanApiResponse> call, @NonNull Response<BTC_PlanApiResponse> response) {

                if (response.isSuccessful()) {
                    BTC_PlanApiResponse apiResponse = response.body();

                    binding.clProgressBar.setVisibility(View.GONE);

                    if (apiResponse != null) {
                        ArrayList<BTC_PlansModel> dataList = apiResponse.getData();

                        plansModelArrayList.addAll(dataList);

                        binding.rvPlansList.setLayoutManager(new LinearLayoutManager(BTC_UpgradePlansActivity.this));
                        BTC_UpgradePlanAdapter adapter = new BTC_UpgradePlanAdapter(BTC_UpgradePlansActivity.this, plansModelArrayList);
                        binding.rvPlansList.setAdapter(adapter);

                        Log.w("--apiResponse--", "UpgradePlans" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));
                    } else {
                        Log.e("--apiResponse--", "Error: Response body is null");
                    }
                } else {
                    try {
                        Log.e("--apiResponse--", "Error: user detail " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<BTC_PlanApiResponse> call, @NonNull Throwable t) {

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}