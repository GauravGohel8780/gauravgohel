package com.festum.btcmining.BTC_api.model;

public class BTC_ContactUsResponse {

    public int iStatusCode;
    public boolean isStatus;
    public BTC_ContactUsRequest data;
    public String vMessage;

    public int getiStatusCode() {
        return iStatusCode;
    }

    public void setiStatusCode(int iStatusCode) {
        this.iStatusCode = iStatusCode;
    }

    public boolean isStatus() {
        return isStatus;
    }

    public void setStatus(boolean status) {
        isStatus = status;
    }

    public BTC_ContactUsRequest getData() {
        return data;
    }

    public void setData(BTC_ContactUsRequest data) {
        this.data = data;
    }

    public String getvMessage() {
        return vMessage;
    }

    public void setvMessage(String vMessage) {
        this.vMessage = vMessage;
    }
}
