package com.festum.btcmining.BTC_api.model;

public class BTC_ScratchCardData {
    public String _id;
    public int iTotalOneDayScratch;
    public int iScratchCardPoint;
    public boolean isTodayScratchComplete;
    public boolean isDeleted;
    public String vScratchCardType;
    public long dtCreatedAt;

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public int getiTotalOneDayScratch() {
        return iTotalOneDayScratch;
    }

    public void setiTotalOneDayScratch(int iTotalOneDayScratch) {
        this.iTotalOneDayScratch = iTotalOneDayScratch;
    }

    public int getiScratchCardPoint() {
        return iScratchCardPoint;
    }

    public void setiScratchCardPoint(int iScratchCardPoint) {
        this.iScratchCardPoint = iScratchCardPoint;
    }

    public boolean isTodayScratchComplete() {
        return isTodayScratchComplete;
    }

    public void setTodayScratchComplete(boolean todayScratchComplete) {
        isTodayScratchComplete = todayScratchComplete;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public String getvScratchCardType() {
        return vScratchCardType;
    }

    public void setvScratchCardType(String vScratchCardType) {
        this.vScratchCardType = vScratchCardType;
    }

    public long getDtCreatedAt() {
        return dtCreatedAt;
    }

    public void setDtCreatedAt(long dtCreatedAt) {
        this.dtCreatedAt = dtCreatedAt;
    }
}
