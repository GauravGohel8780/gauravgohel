package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ApiResponse;
import com.festum.btcmining.BTC_api.model.BTC_ContestParticipateResponse;
import com.festum.btcmining.BTC_api.model.BTC_ContestResponse;
import com.festum.btcmining.BTC_api.model.BTC_ContestsData;
import com.festum.btcmining.BTC_api.model.BTC_ParticipateContest;
import com.festum.btcmining.BTC_api.model.BTC_UpdatePoints;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.databinding.ActivityOpenedContestBinding;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Objects;
import java.util.TimeZone;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_OpenedContestActivity extends AdsBaseActivity {

    ActivityOpenedContestBinding binding;
    int total_ticket;
    int ticketPrice = 0;
    int totalAmount = 0;
    int points;
    SharedPreferences sharedpreferences;
    String userToken;
    String contestId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityOpenedContestBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        contestId = getIntent().getStringExtra(BTC_Constants.CONTEST_ID);


        binding.tvPurchaseTickets.setText("0");

        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");
        points = sharedpreferences.getInt(BTC_Constants.TOTAL_POINTS, 0);


        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @NotNull
            @Override
            public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                Request original = chain.request();
                Request.Builder requestBuilder = original.newBuilder()
                        .header("Authorization", "Bearer " + userToken)
                        .method(original.method(), original.body());

                Request request = requestBuilder.build();

                Log.d("--apiResponse--", "URL: " + request.url());
                Log.d("--apiResponse--", "Headers: " + request.headers());
                Log.d("--apiResponse--", "Bobtc mindy: " + request.body());

                return chain.proceed(request);
            }
        });

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BTC_Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        BTC_ApiService apiService = retrofit.create(BTC_ApiService.class);


        binding.tvTickets.setText(String.valueOf(ticketPrice));
        binding.tvTotalCurrency.setText(String.valueOf(total_ticket + " points"));

        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_OpenedContestActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });


        Call<BTC_ContestResponse> call = apiService.getContestsDetails(contestId);

        call.enqueue(new Callback<BTC_ContestResponse>() {
            @Override
            public void onResponse(@NonNull Call<BTC_ContestResponse> call, @NonNull Response<BTC_ContestResponse> response) {

                if (response.isSuccessful()) {
                    BTC_ContestResponse apiResponse = response.body();

                    if (apiResponse != null) {
                        ArrayList<BTC_ContestsData> dataList = apiResponse.getData();

                        for (int i = 0; i < dataList.size(); i++) {

                            int timeStamp = dataList.get(i).getDtExpiryDate();

                            total_ticket = dataList.get(i).getdContestTicket();

                            binding.tvContestName.setText(dataList.get(i).getvContestName());
                            binding.tvLeftTime.setText(formatDate(timeStamp));
                            binding.tvTotalJoins.setText(dataList.get(i).getiTotalUser() + " Joins");
                            binding.tvTickets.setText(String.valueOf(total_ticket));
                            binding.tvTimeType.setText(dataList.get(i).getvContestType());
                            binding.tvContestPoint.setText(String.valueOf(dataList.get(i).getdContestPoint()));
                        }
                        Log.w("--apiResponse--", "OpenContest " + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));
                    }
                }

            }

            @Override
            public void onFailure(@NonNull Call<BTC_ContestResponse> call, @NonNull Throwable t) {

            }
        });

        Log.d("--points--", "onClick: cvadd " + ticketPrice);

        binding.ivAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ticketPrice++;

                Log.d("--points--", "onClick: cvadd " + ticketPrice);
                totalAmount = totalAmount + total_ticket;

                binding.tvPurchaseTickets.setText("" + ticketPrice);
                binding.tvTotalCurrency.setText(totalAmount + " points");

                Log.d("--points--", "onClick: cvadd " + ticketPrice);
            }
        });

        binding.ivSubtract.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ticketPrice >= 1 && total_ticket >= 1) {
                    ticketPrice--;
                    totalAmount = totalAmount - total_ticket;

                    Log.d("--points--", "onClick: cvsubtract " + ticketPrice);

                    binding.tvPurchaseTickets.setText("" + ticketPrice);
                    binding.tvTotalCurrency.setText(totalAmount + " points");


                } else {
                    Toast.makeText(BTC_OpenedContestActivity.this, "Already you have 0 points", Toast.LENGTH_SHORT).show();
                }
            }
        });

        binding.cvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("--points--", "onClick: cvadd " + ticketPrice);
                if (points >= totalAmount) {
                    if (total_ticket >= 1 && ticketPrice >= 1) {

                        Log.d("--points--", "onClick: cvadd " + ticketPrice);

                        Log.d("--tickets--", "onClick: tickets " + ticketPrice);
                        Log.d("--tickets--", "onClick: amount " + totalAmount);

                        BTC_ParticipateContest participateContest = new BTC_ParticipateContest(contestId, ticketPrice, totalAmount);

                        Call<BTC_ContestParticipateResponse> call = apiService.contestsParticipateUpdate(participateContest);

                        call.enqueue(new Callback<BTC_ContestParticipateResponse>() {
                            @Override
                            public void onResponse(@NonNull Call<BTC_ContestParticipateResponse> call, @NonNull Response<BTC_ContestParticipateResponse> response) {

                                BTC_ContestParticipateResponse apiResponse = response.body();

                                if (response.isSuccessful()) {
                                    Log.w("--apiResponse--", "onResponse: ContestParticipateResponse----------> " + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));


                                    if (apiResponse != null) {

                                        Dialog dialog = new Dialog(BTC_OpenedContestActivity.this);
                                        dialog.setContentView(R.layout.dialog_register_successful);
                                        dialog.setCancelable(false);
                                        dialog.show();

                                        dialog.getWindow().setLayout(-1, -2);

                                        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(ContextCompat.getDrawable(BTC_OpenedContestActivity.this, android.R.color.transparent));


                                        ImageView ivCancel = dialog.findViewById(R.id.ivCancel);
                                        CardView cvOk = dialog.findViewById(R.id.cvOk);
                                        ivCancel.setVisibility(View.GONE);

                                        TextView tv_description = dialog.findViewById(R.id.email_description);
                                        tv_description.setText(totalAmount + " Points has been debited");

                                        cvOk.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                getInstance(BTC_OpenedContestActivity.this).ShowAd(new HandleClick() {
                                                    @Override
                                                    public void Show(boolean adShow) {


                                                        BTC_UpdatePoints updatePoints = new BTC_UpdatePoints("Participated Contest", totalAmount, false);

                                                        Call<BTC_ApiResponse> callPoints = apiService.updateUserPoint(updatePoints);

                                                        callPoints.enqueue(new Callback<BTC_ApiResponse>() {
                                                            @Override
                                                            public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                                                                BTC_ApiResponse apiResponse = response.body();

                                                                if (response.isSuccessful()) {
                                                                    Log.w("--updatePoints--", "onResponse: update Points----------> " + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));
                                                                    dialog.dismiss();

                                                                    Intent intent = new Intent(BTC_OpenedContestActivity.this, BTC_HomeActivity.class);
                                                                    startActivity(intent);

                                                                } else {
                                                                    try {
                                                                        Log.e("--updatePoints--", "Error: update Points " + response.errorBody().string());
                                                                    } catch (IOException e) {
                                                                        throw new RuntimeException(e);
                                                                    }
                                                                }
                                                            }

                                                            @Override
                                                            public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {

                                                            }
                                                        });

                                                        dialog.dismiss();

                                                        Intent intent = new Intent(BTC_OpenedContestActivity.this, BTC_HomeActivity.class);
                                                        startActivity(intent);
                                                    }
                                                }, MAIN_CLICK);
                                            }
                                        });

                                    }

                                }
                            }

                            @Override
                            public void onFailure(@NonNull Call<BTC_ContestParticipateResponse> call, @NonNull Throwable t) {

                            }
                        });

                    }
                } else {
                    Toast.makeText(BTC_OpenedContestActivity.this, "not success", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private String formatDate(long milliseconds) {
        DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy' 'HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliseconds);
        TimeZone tz = TimeZone.getDefault();
        sdf.setTimeZone(tz);
        return sdf.format(calendar.getTime());
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}