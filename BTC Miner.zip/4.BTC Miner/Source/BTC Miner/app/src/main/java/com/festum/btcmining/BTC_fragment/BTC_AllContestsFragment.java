package com.festum.btcmining.BTC_fragment;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.festum.btcmining.BTC_activity.BTC_ContestActivity;
import com.festum.btcmining.R;
import com.festum.btcmining.BTC_activity.BTC_OpenedContestActivity;
import com.festum.btcmining.BTC_adapter.BTC_ContestsAdapter;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ContestResponse;
import com.festum.btcmining.BTC_api.model.BTC_ContestsData;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_AllContestsFragment extends Fragment {

    RecyclerView rv_contest_list;
    ArrayList<BTC_ContestsData> contestsModelArrayList = new ArrayList<>();
    SharedPreferences sharedpreferences;
    String userToken;
    ProgressBar progressBar;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_all_contests, container, false);

        progressBar = view.findViewById(R.id.progress_bar);
        rv_contest_list = view.findViewById(R.id.rv_contest_list);


        sharedpreferences = getActivity().getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @NotNull
            @Override
            public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                Request original = chain.request();
                Request.Builder requestBuilder = original.newBuilder()
                        .header("Authorization", "Bearer " + userToken)
                        .method(original.method(), original.body());

                Request request = requestBuilder.build();

                Log.d("--apiResponse--", "URL: " + request.url());
                Log.d("--apiResponse--", "Headers: " + request.headers());
                Log.d("--apiResponse--", "Body: " + request.body());

                return chain.proceed(request);
            }
        });

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BTC_Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        BTC_ApiService apiService = retrofit.create(BTC_ApiService.class);

        Call<BTC_ContestResponse> call = apiService.contestList();

        call.enqueue(new Callback<BTC_ContestResponse>() {
            @Override
            public void onResponse(@NonNull Call<BTC_ContestResponse> call, @NonNull Response<BTC_ContestResponse> response) {
                if (response.isSuccessful()) {
                    progressBar.setVisibility(View.GONE);

                    BTC_ContestResponse apiResponse = response.body();

                    if (apiResponse != null) {
                        ArrayList<BTC_ContestsData> dataList = apiResponse.getData();

                        contestsModelArrayList.addAll(dataList);

                        rv_contest_list.setLayoutManager(new LinearLayoutManager(getContext()));
                        BTC_ContestsAdapter adapter = new BTC_ContestsAdapter(contestsModelArrayList, new BTC_ContestsAdapter.OnItemClickListener() {
                            @Override
                            public void onClick(int position) {
                                getInstance(getActivity()).ShowAd(new HandleClick() {
                                    @Override
                                    public void Show(boolean adShow) {
                                        Intent intent = new Intent(getContext(), BTC_OpenedContestActivity.class);
                                        intent.putExtra(BTC_Constants.CONTEST_ID, dataList.get(position).get_id());
                                        startActivity(intent);
                                    }
                                }, MAIN_CLICK);
                            }
                        });

                        rv_contest_list.setAdapter(adapter);

                        Log.w("--apiResponse--", "ContestResponse" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<BTC_ContestResponse> call, @NonNull Throwable t) {

            }
        });

        return view;
    }
}