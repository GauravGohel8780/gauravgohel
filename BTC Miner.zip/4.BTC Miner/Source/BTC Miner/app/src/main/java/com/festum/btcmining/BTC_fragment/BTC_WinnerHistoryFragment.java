package com.festum.btcmining.BTC_fragment;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.festum.btcmining.R;
import com.festum.btcmining.BTC_adapter.BTC_WinnersAdapter;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_WinnersData;
import com.festum.btcmining.BTC_api.model.BTC_WinnersHistoryResponse;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.databinding.FragmentWinnerHistoryBinding;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_WinnerHistoryFragment extends Fragment {

    FragmentWinnerHistoryBinding binding;
    BTC_WinnersAdapter winnersAdapter;
    SharedPreferences sharedpreferences;
    String userToken;

    BTC_ApiService apiService;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentWinnerHistoryBinding.inflate(getLayoutInflater());


        sharedpreferences = getActivity().getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");


        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @NotNull
            @Override
            public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                Request original = chain.request();
                Request.Builder requestBuilder = original.newBuilder().header("Authorization", "Bearer " + userToken).method(original.method(), original.body());

                Request request = requestBuilder.build();

                Log.d("--apiResponse--", "URL: " + request.url());
                Log.d("--apiResponse--", "Headers: " + request.headers());
                Log.d("--apiResponse--", "Body: " + request.body());

                return chain.proceed(request);
            }
        });

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder().baseUrl(BTC_Constants.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(client).build();

        apiService = retrofit.create(BTC_ApiService.class);

        binding.progressBar.setVisibility(View.VISIBLE);


        binding.rlDaily.setOnClickListener(v -> {
            getInstance(getActivity()).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    updateViews(View.VISIBLE, View.GONE, View.GONE, View.GONE, R.color.orange, R.color.white, R.color.white, R.color.white);
                    binding.progressBar.setVisibility(View.VISIBLE);
                    binding.tvNoReferrals.setVisibility(View.GONE);

                    Call<BTC_WinnersHistoryResponse> call = apiService.winnerHistory("daily");

                    call.enqueue(new Callback<BTC_WinnersHistoryResponse>() {
                        @Override
                        public void onResponse(@NonNull Call<BTC_WinnersHistoryResponse> call, @NonNull Response<BTC_WinnersHistoryResponse> response) {
                            if (response.isSuccessful()) {
                                binding.rvWinnersList.setVisibility(View.VISIBLE);
                                binding.tvNoReferrals.setVisibility(View.GONE);
                                binding.progressBar.setVisibility(View.GONE);

                                BTC_WinnersHistoryResponse apiResponse = response.body();

                                if (apiResponse != null) {
                                    ArrayList<BTC_WinnersData> winnersDataList = apiResponse.getData();

                                    if (!winnersDataList.isEmpty()) {
                                        binding.rvWinnersList.setLayoutManager(new LinearLayoutManager(getContext()));
                                        winnersAdapter = new BTC_WinnersAdapter(winnersDataList, "WinnersHistoryActivity");
                                        binding.rvWinnersList.setAdapter(winnersAdapter);

                                        Log.w("--apiResponse--", "Active miners" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));
                                    } else {
                                        binding.rvWinnersList.setVisibility(View.GONE);
                                        binding.tvNoReferrals.setVisibility(View.VISIBLE);
                                    }
                                } else {
                                    Log.e("--apiResponse--", "Error: Response body is null");
                                }
                            } else {
                                try {
                                    Log.e("--apiResponse--", "Error: user detail " + response.errorBody().string());
                                } catch (IOException e) {
                                    throw new RuntimeException(e);
                                }
                            }
                        }

                        @Override
                        public void onFailure(@NonNull Call<BTC_WinnersHistoryResponse> call, @NonNull Throwable t) {
                            Log.e("--apiResponse--", "Error: WinnersHistoryResponse " + t.getMessage());

                        }
                    });
                }
            }, MAIN_CLICK);
        });
        binding.rlDaily.performClick();

        binding.rlWeekly.setOnClickListener(v -> {
            getInstance(getActivity()).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    updateViews(View.GONE, View.VISIBLE, View.GONE, View.GONE, R.color.white, R.color.orange, R.color.white, R.color.white);

                    binding.progressBar.setVisibility(View.VISIBLE);
                    binding.tvNoReferrals.setVisibility(View.GONE);
                    binding.rvWinnersList.setVisibility(View.GONE);

                    Call<BTC_WinnersHistoryResponse> call = apiService.winnerHistory("weekly");

                    call.enqueue(new Callback<BTC_WinnersHistoryResponse>() {
                        @Override
                        public void onResponse(@NonNull Call<BTC_WinnersHistoryResponse> call, @NonNull Response<BTC_WinnersHistoryResponse> response) {
                            if (response.isSuccessful()) {
                                binding.rvWinnersList.setVisibility(View.VISIBLE);
                                binding.tvNoReferrals.setVisibility(View.GONE);
                                binding.progressBar.setVisibility(View.GONE);

                                BTC_WinnersHistoryResponse apiResponse = response.body();

                                if (apiResponse != null) {
                                    ArrayList<BTC_WinnersData> winnersDataList = apiResponse.getData();

                                    if (!winnersDataList.isEmpty()) {
                                        binding.rvWinnersList.setLayoutManager(new LinearLayoutManager(getContext()));
                                        winnersAdapter = new BTC_WinnersAdapter(winnersDataList, "WinnersHistoryActivity");
                                        binding.rvWinnersList.setAdapter(winnersAdapter);

                                        Log.w("--apiResponse--", "Winners history" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));
                                    } else {
                                        binding.rvWinnersList.setVisibility(View.GONE);
                                        binding.tvNoReferrals.setVisibility(View.VISIBLE);
                                    }
                                } else {
                                    Log.e("--apiResponse--", "Error: Response body is null");

                                    binding.progressBar.setVisibility(View.GONE);
                                    binding.rvWinnersList.setVisibility(View.GONE);
                                    binding.tvNoReferrals.setVisibility(View.VISIBLE);
                                }
                            } else {
                                try {
                                    binding.progressBar.setVisibility(View.GONE);
                                    binding.rvWinnersList.setVisibility(View.GONE);
                                    binding.tvNoReferrals.setVisibility(View.VISIBLE);

                                    Log.e("--apiResponse--", "Error: winners " + response.errorBody().string());
                                } catch (IOException e) {
                                    throw new RuntimeException(e);
                                }
                            }
                        }

                        @Override
                        public void onFailure(@NonNull Call<BTC_WinnersHistoryResponse> call, @NonNull Throwable t) {
                            Log.e("--apiResponse--", "Error: WinnersHistoryResponse " + t.getMessage());

                        }
                    });
                }
            }, MAIN_CLICK);
        });

        binding.rlFortnight.setOnClickListener(v -> {
            getInstance(getActivity()).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    updateViews(View.GONE, View.GONE, View.VISIBLE, View.GONE, R.color.white, R.color.white, R.color.orange, R.color.white);

                    binding.progressBar.setVisibility(View.VISIBLE);
                    binding.tvNoReferrals.setVisibility(View.GONE);
                    binding.rvWinnersList.setVisibility(View.GONE);

                    Call<BTC_WinnersHistoryResponse> call = apiService.winnerHistory("fortnight");

                    call.enqueue(new Callback<BTC_WinnersHistoryResponse>() {
                        @Override
                        public void onResponse(@NonNull Call<BTC_WinnersHistoryResponse> call, @NonNull Response<BTC_WinnersHistoryResponse> response) {
                            if (response.isSuccessful()) {
                                binding.rvWinnersList.setVisibility(View.VISIBLE);
                                binding.tvNoReferrals.setVisibility(View.GONE);
                                binding.progressBar.setVisibility(View.GONE);

                                BTC_WinnersHistoryResponse apiResponse = response.body();

                                if (apiResponse != null) {
                                    ArrayList<BTC_WinnersData> winnersDataList = apiResponse.getData();

                                    if (!winnersDataList.isEmpty()) {
                                        binding.rvWinnersList.setLayoutManager(new LinearLayoutManager(getContext()));
                                        winnersAdapter = new BTC_WinnersAdapter(winnersDataList, "WinnersHistoryActivity");
                                        binding.rvWinnersList.setAdapter(winnersAdapter);

                                        Log.w("--apiResponse--", "Winners history" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));
                                    } else {
                                        binding.rvWinnersList.setVisibility(View.GONE);
                                        binding.tvNoReferrals.setVisibility(View.VISIBLE);
                                    }
                                } else {
                                    Log.e("--apiResponse--", "Error: Response body is null");

                                    binding.progressBar.setVisibility(View.GONE);
                                    binding.rvWinnersList.setVisibility(View.GONE);
                                    binding.tvNoReferrals.setVisibility(View.VISIBLE);
                                }
                            } else {
                                try {
                                    binding.progressBar.setVisibility(View.GONE);
                                    binding.rvWinnersList.setVisibility(View.GONE);
                                    binding.tvNoReferrals.setVisibility(View.VISIBLE);

                                    Log.e("--apiResponse--", "Error: winners " + response.errorBody().string());
                                } catch (IOException e) {
                                    throw new RuntimeException(e);
                                }
                            }
                        }

                        @Override
                        public void onFailure(@NonNull Call<BTC_WinnersHistoryResponse> call, @NonNull Throwable t) {
                            Log.e("--apiResponse--", "Error: WinnersHistoryResponse " + t.getMessage());

                        }
                    });
                }
            }, MAIN_CLICK);

        });

        binding.rlMonthly.setOnClickListener(v -> {
            getInstance(getActivity()).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    updateViews(View.GONE, View.GONE, View.GONE, View.VISIBLE, R.color.white, R.color.white, R.color.white, R.color.orange);
                    binding.progressBar.setVisibility(View.VISIBLE);
                    binding.tvNoReferrals.setVisibility(View.GONE);
                    binding.rvWinnersList.setVisibility(View.GONE);

                    Call<BTC_WinnersHistoryResponse> call = apiService.winnerHistory("monthly");

                    call.enqueue(new Callback<BTC_WinnersHistoryResponse>() {
                        @Override
                        public void onResponse(@NonNull Call<BTC_WinnersHistoryResponse> call, @NonNull Response<BTC_WinnersHistoryResponse> response) {
                            if (response.isSuccessful()) {
                                binding.rvWinnersList.setVisibility(View.VISIBLE);
                                binding.tvNoReferrals.setVisibility(View.GONE);
                                binding.progressBar.setVisibility(View.GONE);

                                BTC_WinnersHistoryResponse apiResponse = response.body();

                                if (apiResponse != null) {
                                    ArrayList<BTC_WinnersData> winnersDataList = apiResponse.getData();

                                    if (!winnersDataList.isEmpty()) {
                                        binding.rvWinnersList.setLayoutManager(new LinearLayoutManager(getContext()));
                                        winnersAdapter = new BTC_WinnersAdapter(winnersDataList, "WinnersHistoryActivity");
                                        binding.rvWinnersList.setAdapter(winnersAdapter);

                                        Log.w("--apiResponse--", "Winners history" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));
                                    } else {
                                        binding.rvWinnersList.setVisibility(View.GONE);
                                        binding.tvNoReferrals.setVisibility(View.VISIBLE);
                                    }
                                } else {
                                    Log.e("--apiResponse--", "Error: Response body is null");

                                    binding.progressBar.setVisibility(View.GONE);
                                    binding.rvWinnersList.setVisibility(View.GONE);
                                    binding.tvNoReferrals.setVisibility(View.VISIBLE);
                                }
                            } else {
                                try {
                                    binding.progressBar.setVisibility(View.GONE);
                                    binding.rvWinnersList.setVisibility(View.GONE);
                                    binding.tvNoReferrals.setVisibility(View.VISIBLE);

                                    Log.e("--apiResponse--", "Error: winners " + response.errorBody().string());
                                } catch (IOException e) {
                                    throw new RuntimeException(e);
                                }
                            }
                        }

                        @Override
                        public void onFailure(@NonNull Call<BTC_WinnersHistoryResponse> call, @NonNull Throwable t) {
                            Log.e("--apiResponse--", "Error: WinnersHistoryResponse " + t.getMessage());

                        }
                    });
                }
            }, MAIN_CLICK);

        });

        return binding.getRoot();
    }


    private void updateViews(int dailyVisibility, int weeklyVisibility, int fortnightVisibility, int monthlyVisibility, int dailyTextColor, int weeklyTextColor, int fortnightTextColor, int monthlyTextColor) {
        binding.vDaily.setVisibility(dailyVisibility);
        binding.vWeekly.setVisibility(weeklyVisibility);
        binding.vFortnight.setVisibility(fortnightVisibility);
        binding.vMonthly.setVisibility(monthlyVisibility);

        binding.tvDaily.setTextColor(getActivity().getColor(dailyTextColor));
        binding.tvWeekly.setTextColor(getActivity().getColor(weeklyTextColor));
        binding.tvFortnight.setTextColor(getActivity().getColor(fortnightTextColor));
        binding.tvMonthly.setTextColor(getActivity().getColor(monthlyTextColor));
    }
}