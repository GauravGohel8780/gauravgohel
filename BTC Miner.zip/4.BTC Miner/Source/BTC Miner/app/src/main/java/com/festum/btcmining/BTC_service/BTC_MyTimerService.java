package com.festum.btcmining.BTC_service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;


import com.festum.btcmining.BTC_activity.BTC_HomeActivity;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ApiResponse;
import com.festum.btcmining.BTC_api.model.BTC_UpdatePoints;
import com.festum.btcmining.BTC_constants.BTC_Constants;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_MyTimerService extends Service {

    private static final String TAG = "CountdownService";
    private Handler handler;
    private Runnable runnable;
    private long countdownMillis;
    String userToken;

    // Intent action for updating UI
    public static final String COUNTDOWN_UPDATE_ACTION = "countdown_update_action";
    BTC_ApiService apiService;

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler();

        SharedPreferences sharedPreferences = BTC_MyTimerService.this.getApplicationContext().getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
        userToken = sharedPreferences.getString(BTC_Constants.USER_TOKEN, "");

        Log.d("--service--", "onCreate: " + userToken);

        startCountdown();


        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @NotNull
            @Override
            public okhttp3.Response intercept(@NotNull Chain chain) throws IOException {
                Request original = chain.request();
                Request.Builder requestBuilder = original.newBuilder()
                        .header("Authorization", "Bearer " + userToken)
                        .method(original.method(), original.body());

                Request request = requestBuilder.build();

                Log.d("--apiResponse--", "URL: " + request.url());
                Log.d("--apiResponse--", "Headers: " + request.headers());
                Log.d("--apiResponse--", "Body: " + request.body());

                return chain.proceed(request);
            }
        });

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BTC_Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        apiService = retrofit.create(BTC_ApiService.class);

    }


    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

            startForeground(1, createNotification());

        return START_STICKY;
    }

    private Notification createNotification() {
        // Create an intent to open the main activity when the notification is clicked
        Intent mainActivityIntent = new Intent(this, BTC_HomeActivity.class);
        mainActivityIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP); // Use existing instance if available
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, mainActivityIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("channelId", "Channel Name", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }


        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "channelId")
                .setContentTitle("Your Timer is Running")
                .setContentText("Remaining time: " + countdownMillis)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true); // Dismiss the notification when clicked

        return builder.build();
    }


    private void startCountdown() {
        runnable = new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "Timer tick");

                // Update UI with remaining time
                updateUI();

                // Perform your countdown logic here
                countdownMillis -= 1000;

                // Schedule the next execution after 1 second
                handler.postDelayed(this, 1000);

                // Stop the service if the countdown is completed
                if (countdownMillis <= 0) {


                    BTC_UpdatePoints updatePoints = new BTC_UpdatePoints("Day Mining Points", 200, true);

                    Call<BTC_ApiResponse> callPoints = apiService.updateUserPoint(updatePoints);

                    callPoints.enqueue(new Callback<BTC_ApiResponse>() {
                        @Override
                        public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                            BTC_ApiResponse apiResponse = response.body();

                            Log.d("--apiResponse--", "onResponse: jackpot points------> " + apiResponse);

                            Toast.makeText(BTC_MyTimerService.this, "Pints has been credited to your account", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(BTC_MyTimerService.this, BTC_HomeActivity.class);
                            startActivity(intent);
                        }

                        @Override
                        public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {

                        }
                    });

                    stopSelf();
                }
            }
        };

        // Set the initial countdown time to 24 hours
        countdownMillis = 24 * 60 * 60 * 1000;

        // Start the initial countdown
        handler.post(runnable);
    }

    private void updateUI() {
        // Broadcast the remaining time to the UI
        Intent intent = new Intent(COUNTDOWN_UPDATE_ACTION);
        intent.putExtra("remainingTimeMillis", countdownMillis);
        sendBroadcast(intent);
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
//        clearSharedPreferences();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(runnable);
        stopForeground(true);
//        clearSharedPreferences();
    }


    private void clearSharedPreferences() {
        SharedPreferences preferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.apply();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

