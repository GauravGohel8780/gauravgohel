package com.festum.btcmining.BTC_api.model;

public class BTC_ContestParticipateResponse {

    public int iStatusCode;
    public boolean isStatus;
    public BTC_ParticipateData data;
    public String vMessage;

    public int getiStatusCode() {
        return iStatusCode;
    }

    public void setiStatusCode(int iStatusCode) {
        this.iStatusCode = iStatusCode;
    }

    public boolean isStatus() {
        return isStatus;
    }

    public void setStatus(boolean status) {
        isStatus = status;
    }

    public BTC_ParticipateData getData() {
        return data;
    }

    public void setData(BTC_ParticipateData data) {
        this.data = data;
    }

    public String getvMessage() {
        return vMessage;
    }

    public void setvMessage(String vMessage) {
        this.vMessage = vMessage;
    }
}
