package com.festum.btcmining.BTC_api.model;

import java.util.ArrayList;

public class BTC_QuestionAnsModel {
    public String _id;
    public ArrayList<String> arrOptions;
    public boolean isDeleted;
    public String vQuestionTitle;
    public String vAnswer;
    public Object dtCreatedAt;
    public boolean isAnswered;
    public String correctAnswer;

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public ArrayList<String> getArrOptions() {
        return arrOptions;
    }

    public void setArrOptions(ArrayList<String> arrOptions) {
        this.arrOptions = arrOptions;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public String getvQuestionTitle() {
        return vQuestionTitle;
    }

    public void setvQuestionTitle(String vQuestionTitle) {
        this.vQuestionTitle = vQuestionTitle;
    }

    public String getvAnswer() {
        return vAnswer;
    }

    public void setvAnswer(String vAnswer) {
        this.vAnswer = vAnswer;
    }

    public Object getDtCreatedAt() {
        return dtCreatedAt;
    }

    public void setDtCreatedAt(Object dtCreatedAt) {
        this.dtCreatedAt = dtCreatedAt;
    }

    public boolean isAnswered() {
        return isAnswered;
    }

    public void setAnswered(boolean answered) {
        isAnswered = answered;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public void setCorrectAnswer(String correctAnswer) {
        this.correctAnswer = correctAnswer;
    }
}
