package com.festum.btcmining.BTC_api.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class BTC_ReferralResponse {

    public int iStatusCode;
    public boolean isStatus;
    int iCount;
    @SerializedName("data")
    public ArrayList<BTC_Referral> data;
    public String vMessage;

    public int getiStatusCode() {
        return iStatusCode;
    }

    public void setiStatusCode(int iStatusCode) {
        this.iStatusCode = iStatusCode;
    }

    public int getiCount() {
        return iCount;
    }

    public void setiCount(int iCount) {
        this.iCount = iCount;
    }

    public boolean isStatus() {
        return isStatus;
    }

    public void setStatus(boolean status) {
        isStatus = status;
    }

    public ArrayList<BTC_Referral> getData() {
        return data;
    }

    public void setData(ArrayList<BTC_Referral> data) {
        this.data = data;
    }

    public String getvMessage() {
        return vMessage;
    }

    public void setvMessage(String vMessage) {
        this.vMessage = vMessage;
    }
}
