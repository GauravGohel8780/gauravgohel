package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.Commen;
import com.festum.btcmining.R;
import com.festum.btcmining.databinding.ActivityExitBinding;
import com.iten.tenoku.utils.AdUtils;

public class BTC_ExitActivity extends AdsBaseActivity {

    ActivityExitBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Commen.SetSystemFullScreen(this);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        binding = ActivityExitBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.ll.setVisibility(View.GONE);
        binding.tvExit.setVisibility(View.VISIBLE);

        binding.tvExit.setOnClickListener(v -> {
            binding.imgExit.setImageDrawable(getDrawable(R.drawable.ic_exit));
            binding.tvExitTitle.setText("Exit ");
            binding.tvExitDetail.setText("Are you Sure\n" + "You want to exit from app?");
            binding.ll.setVisibility(View.VISIBLE);
            binding.tvExit.setVisibility(View.GONE);
        });

        binding.tvYes.setOnClickListener(v -> {
            finishAffinity();
        });
        binding.tvNo.setOnClickListener(v -> {
            getOnBackPressedDispatcher().onBackPressed();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}