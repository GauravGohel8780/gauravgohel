package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.util.Patterns;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ApiResponse;
import com.festum.btcmining.BTC_api.model.BTC_UserDetail;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.databinding.ActivityYourProfileBinding;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_YourProfileActivity extends AdsBaseActivity {
    ActivityYourProfileBinding binding;
    SharedPreferences sharedpreferences;
    String userToken;
    String firstName;
    String lastName;
    String gender;
    String countryName;
    String email;
    boolean isPasswordVisible = false;
    boolean isConfirmPasswordVisible = false;
    BTC_ApiService apiService;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityYourProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.llEditChangePassword.setVisibility(View.GONE);
        binding.llEditProfileDetail.setVisibility(View.VISIBLE);

        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");

        firstName = sharedpreferences.getString(BTC_Constants.FIRST_NAME, "");
        lastName = sharedpreferences.getString(BTC_Constants.LAST_NAME, "");
        gender = sharedpreferences.getString(BTC_Constants.GENDER, "");
        countryName = sharedpreferences.getString(BTC_Constants.COUNTRY_NAME, "");
        email = sharedpreferences.getString(BTC_Constants.EMAIL_KEY, "");

        countryName = sharedpreferences.getString(BTC_Constants.COUNTRY_NAME, "");


        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @NotNull
            @Override
            public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                Request original = chain.request();
                Request.Builder requestBuilder = original.newBuilder()
                        .header("Authorization", "Bearer " + userToken)
                        .method(original.method(), original.body());

                Request request = requestBuilder.build();

                Log.d("--apiResponse--", "URL: " + request.url());
                Log.d("--apiResponse--", "Headers: " + request.headers());
                Log.d("--apiResponse--", "Body: " + request.body());

                return chain.proceed(request);
            }
        });

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BTC_Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        apiService = retrofit.create(BTC_ApiService.class);


        binding.etFirstName.setText(firstName);
        binding.etLastName.setText(lastName);
        binding.etEmail.setText(email);


        if (gender.equals("Male")) {
            binding.radioMale.setChecked(true);
        } else {
            binding.radioFemale.setChecked(true);
        }


        String[] countryArray = BTC_Constants.country;

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.simple_spinner_item, countryArray);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        binding.spinner.setAdapter(adapter);

        if (countryName != null) {
            int positionToSet = getPositionByText(adapter, countryName);

            if (positionToSet != -1) {
                binding.spinner.setSelection(positionToSet);

                SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(BTC_Constants.COUNTRY_NAME, countryName);
                editor.apply();
            }
        }

        Call<BTC_ApiResponse> call = apiService.getUserDetails();

        call.enqueue(new Callback<BTC_ApiResponse>() {
            @Override
            public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {

                if (response.isSuccessful()) {
                    BTC_ApiResponse apiResponse = response.body();

                    Log.w("--getUserDetail--", "onResponse: profile act......" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));

                    binding.clProgressBar.setVisibility(View.GONE);

                    if (apiResponse != null) {
                        binding.etFirstName.setText(apiResponse.getData().getvFirstName());
                        binding.etLastName.setText(apiResponse.getData().getvLastName());
                        binding.etEmail.setText(apiResponse.getData().getvEmail());

                        if (apiResponse.getData() != null && apiResponse.getData().getvGender() != null) {
                            String gender = apiResponse.getData().getvGender();

                            if (apiResponse.getData() != null) {
                                if ("Male".equalsIgnoreCase(gender)) {
                                    binding.radioMale.setChecked(true);
                                } else if ("Female".equalsIgnoreCase(gender)) {
                                    binding.radioFemale.setChecked(true);
                                }
                            }
                        } else {
                            Toast.makeText(BTC_YourProfileActivity.this, "profile is null", Toast.LENGTH_SHORT).show();
                        }


                        int positionToSet = getPositionByText(adapter, apiResponse.getData().getvCountry());

                        if (positionToSet != -1) {
                            binding.spinner.setSelection(positionToSet);
                        }
                    }
                } else {
                    try {
                        Log.w("--getUserDetail--", "Error: profile act......" + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }

                }
            }

            @Override
            public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {
                Log.w("--getUserDetail--", "onFailure: profile act......" + t.getMessage());

            }
        });

        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_YourProfileActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });


        binding.cvChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_YourProfileActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        binding.llEditProfileDetail.setVisibility(View.GONE);
                        binding.llEditChangePassword.setVisibility(View.VISIBLE);
                        binding.cvChangePassword.setVisibility(View.GONE);
                        binding.cvCancel.setVisibility(View.VISIBLE);
                    }
                }, MAIN_CLICK);
            }
        });


        binding.cvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_YourProfileActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        binding.llEditChangePassword.setVisibility(View.GONE);
                        binding.llEditProfileDetail.setVisibility(View.VISIBLE);
                        binding.cvChangePassword.setVisibility(View.VISIBLE);
                        binding.cvCancel.setVisibility(View.GONE);
                    }
                }, MAIN_CLICK);
            }
        });

        binding.icPasswordVisibility.setImageDrawable(getDrawable(R.drawable.ic_unselect_eye));
        binding.etPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
        binding.icConfirmPasswordVisibility.setImageDrawable(getDrawable(R.drawable.ic_unselect_eye));
        binding.etConfirmPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());

        binding.icPasswordVisibility.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isPasswordVisible = !isPasswordVisible;
                if (isPasswordVisible) {
                    binding.etPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    binding.icPasswordVisibility.setImageDrawable(getDrawable(R.drawable.ic_select_eye));
                } else {
                    binding.icPasswordVisibility.setImageDrawable(getDrawable(R.drawable.ic_unselect_eye));
                    binding.etPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
                binding.etPassword.setSelection(Objects.requireNonNull(binding.etPassword.getText()).length());
            }
        });


        binding.icConfirmPasswordVisibility.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                isConfirmPasswordVisible = !isConfirmPasswordVisible;

                if (isConfirmPasswordVisible) {
                    binding.etConfirmPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    binding.icConfirmPasswordVisibility.setImageDrawable(getDrawable(R.drawable.ic_select_eye));
                } else {
                    binding.icConfirmPasswordVisibility.setImageDrawable(getDrawable(R.drawable.ic_unselect_eye));
                    binding.etConfirmPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }

                binding.etConfirmPassword.setSelection(Objects.requireNonNull(binding.etConfirmPassword.getText()).length());
            }
        });


        binding.cvUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String firstName = Objects.requireNonNull(binding.etFirstName.getText()).toString();
                String lastName = Objects.requireNonNull(binding.etLastName.getText()).toString();
                String email = Objects.requireNonNull(binding.etEmail.getText()).toString();

                String newPassword = Objects.requireNonNull(binding.etPassword.getText()).toString();
                String confirmPassword = Objects.requireNonNull(binding.etConfirmPassword.getText()).toString();


                if (binding.llEditProfileDetail.getVisibility() == View.VISIBLE) {
                    if (TextUtils.isEmpty(firstName)) {
                        Toast.makeText(BTC_YourProfileActivity.this, "Please enter your first name.", Toast.LENGTH_SHORT).show();
                    } else if (TextUtils.isEmpty(lastName)) {
                        Toast.makeText(BTC_YourProfileActivity.this, "Please enter your last name.", Toast.LENGTH_SHORT).show();
                    } else if (!isValidEmail(email)) {
                        Toast.makeText(BTC_YourProfileActivity.this, "Please enter your valid email.", Toast.LENGTH_SHORT).show();
                    } else {
                        binding.clProgressBar.setVisibility(View.VISIBLE);


                        binding.llEditChangePassword.setVisibility(View.GONE);
                        binding.llEditProfileDetail.setVisibility(View.VISIBLE);

                        String selectedCountry = binding.spinner.getSelectedItem().toString();

                        Log.d("--passChange--", "onClick: ll_edit_profile_detail countryName " + selectedCountry);


                        int selected = binding.radioSexGroup.getCheckedRadioButtonId();

                        RadioButton radio = findViewById(selected);

                        String gender = radio.getText().toString();

                        BTC_UserDetail userDetail = new BTC_UserDetail(firstName, lastName, selectedCountry, gender, email);

                        Call<BTC_ApiResponse> call = apiService.updateUserDetail(userDetail);

                        call.enqueue(new Callback<BTC_ApiResponse>() {
                            @Override
                            public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                                BTC_ApiResponse apiResponse = response.body();

                                if (response.isSuccessful()) {
                                    Log.w("--apiResponse--", "user_data ----> profile update" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));


                                    Dialog dialog = new Dialog(BTC_YourProfileActivity.this, R.style.customDialog);

                                    dialog.setContentView(R.layout.dialog_register_successful);
                                    dialog.setCancelable(false);

                                    Objects.requireNonNull(dialog.getWindow()).setGravity(Gravity.CENTER);

                                    dialog.getWindow().setLayout(-1, -2);

                                    Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(ContextCompat.getDrawable(BTC_YourProfileActivity.this, android.R.color.transparent));

                                    ImageView ivCancel = dialog.findViewById(R.id.ivCancel);
                                    CardView cvOk = dialog.findViewById(R.id.cvOk);
                                    TextView email_description = dialog.findViewById(R.id.email_description);

                                    email_description.setText("Profile updated successfully.");

                                    dialog.show();

                                    ivCancel.setVisibility(View.GONE);


                                    cvOk.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            getInstance(BTC_YourProfileActivity.this).ShowAd(new HandleClick() {
                                                @Override
                                                public void Show(boolean adShow) {
                                                    dialog.dismiss();
                                                    Intent intent = new Intent(BTC_YourProfileActivity.this, BTC_HomeActivity.class);
                                                    startActivity(intent);
                                                }
                                            }, MAIN_CLICK);
                                        }
                                    });
                                    SharedPreferences.Editor editor = sharedpreferences.edit();
                                    Gson gson = new Gson();
                                    String json = gson.toJson(apiResponse);

                                    editor.putString(BTC_Constants.COUNTRY_NAME, selectedCountry);
                                    editor.putString(BTC_Constants.API_RESPONSE, json);

                                    editor.apply();

                                    binding.clProgressBar.setVisibility(View.GONE);
                                } else {
                                    try {
                                        binding.clProgressBar.setVisibility(View.GONE);
                                        Log.e("--apiResponse--", "Error: user detail " + response.errorBody().string());
                                    } catch (IOException e) {
                                        throw new RuntimeException(e);
                                    }
                                }
                            }

                            @Override
                            public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {
                                Log.e("--apiResponse--", "Error: user detail onFailure " + new Gson().toJson(t.getMessage()));
                            }
                        });
                    }
                } else if (binding.llEditChangePassword.getVisibility() == View.VISIBLE) {
                    if (!isStrongPassword(newPassword)) {
                        Toast.makeText(BTC_YourProfileActivity.this, getString(R.string.password_validation_error), Toast.LENGTH_SHORT).show();
                    } else if (!confirmPassword.equals(newPassword)) {
                        Toast.makeText(BTC_YourProfileActivity.this, "Please confirm your password.", Toast.LENGTH_SHORT).show();
                    } else {
                        binding.clProgressBar.setVisibility(View.VISIBLE);

                        int selected = binding.radioSexGroup.getCheckedRadioButtonId();

                        RadioButton radio = findViewById(selected);

                        String gender = radio.getText().toString();

                        String selectedCountry = binding.spinner.getSelectedItem().toString();

                        Log.d("--passChange--", "onClick: firstName " + firstName);
                        Log.d("--passChange--", "onClick: lastName " + lastName);
                        Log.d("--passChange--", "onClick: countryName " + selectedCountry);
                        Log.d("--passChange--", "onClick: email " + email);
                        Log.d("--passChange--", "onClick: newPassword " + newPassword);

                        BTC_UserDetail userDetail = new BTC_UserDetail(firstName.trim(), lastName.trim(), selectedCountry, gender.trim(), email.trim(), newPassword);

                        Call<BTC_ApiResponse> call = apiService.updateUserDetail(userDetail);

                        call.enqueue(new Callback<BTC_ApiResponse>() {
                            @Override
                            public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                                BTC_ApiResponse apiResponse = response.body();
                                if (response.isSuccessful()) {

                                    Dialog dialog = new Dialog(BTC_YourProfileActivity.this, R.style.customDialog);

                                    dialog.setContentView(R.layout.dialog_register_successful);
                                    dialog.setCancelable(false);

                                    Objects.requireNonNull(dialog.getWindow()).setGravity(Gravity.CENTER);

                                    dialog.getWindow().setLayout(-1, -2);

                                    Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(ContextCompat.getDrawable(BTC_YourProfileActivity.this, android.R.color.transparent));

                                    ImageView ivCancel = dialog.findViewById(R.id.ivCancel);
                                    CardView cvOk = dialog.findViewById(R.id.cvOk);
                                    TextView email_description = dialog.findViewById(R.id.email_description);

                                    email_description.setText("Password change successfully.");

                                    dialog.show();

                                    ivCancel.setVisibility(View.GONE);


                                    cvOk.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            getInstance(BTC_YourProfileActivity.this).ShowAd(new HandleClick() {
                                                @Override
                                                public void Show(boolean adShow) {
                                                    dialog.dismiss();
                                                    binding.clProgressBar.setVisibility(View.GONE);

                                                    Intent intent = new Intent(BTC_YourProfileActivity.this, BTC_MainActivity.class);
                                                    SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
                                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                                    editor.clear();
                                                    editor.apply();

                                                    startActivity(intent);

                                                    Log.w("--passChange--", "user_data ----> after start password successful" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));
                                                }
                                            }, MAIN_CLICK);
                                        }
                                    });

                                } else {
                                    try {
                                        binding.clProgressBar.setVisibility(View.GONE);

                                        Log.e("--passChange--", "Error: user password else " + response.errorBody().string());
                                    } catch (IOException e) {
                                        throw new RuntimeException(e);
                                    }
                                }
                            }

                            @Override
                            public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {
                                Log.e("--apiResponse--", "Error: user detail onFailure " + new Gson().toJson(t.getMessage()));
                            }
                        });
                    }
                }
            }
        });
    }

    private int getPositionByText(ArrayAdapter<String> adapter, String text) {
        for (int i = 0; i < adapter.getCount(); i++) {
            if (text.equals(adapter.getItem(i))) {
                return i;
            }
        }
        return -1;
    }

    private boolean isValidEmail(CharSequence target) {
        return Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

    private boolean isStrongPassword(String password) {
        String regex = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}