package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.BTC_adapter.BTC_MinerHistoryAdapter;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_MinerDataList;
import com.festum.btcmining.BTC_api.model.BTC_MinerHistoryResponse;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.R;
import com.festum.btcmining.databinding.ActivityMinerHistoryBinding;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_MinerHistoryActivity extends AdsBaseActivity {
    ActivityMinerHistoryBinding binding;
    BTC_MinerHistoryAdapter minerHistoryAdapter;
    ArrayList<BTC_MinerDataList> dataArrayList = new ArrayList<>();
    SharedPreferences sharedpreferences;
    String userToken;
    int totalPoints;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityMinerHistoryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.ivBack.setOnClickListener(v -> {
            getInstance(this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);
        });

        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");
        totalPoints = sharedpreferences.getInt(BTC_Constants.TOTAL_POINTS, 0);

        binding.tvTotalPoints.setText(String.valueOf(totalPoints));


        binding.clProgressBar.setVisibility(View.VISIBLE);

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @NotNull
            @Override
            public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                Request original = chain.request();
                Request.Builder requestBuilder = original.newBuilder()
                        .header("Authorization", "Bearer " + userToken)
                        .method(original.method(), original.body());

                Request request = requestBuilder.build();

                Log.d("--apiResponse--", "URL: " + request.url());
                Log.d("--apiResponse--", "Headers: " + request.headers());
                Log.d("--apiResponse--", "Body: " + request.body());

                return chain.proceed(request);
            }
        });

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BTC_Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        BTC_ApiService apiService = retrofit.create(BTC_ApiService.class);

        Call<BTC_MinerHistoryResponse> call = apiService.minerHistorylist();

        call.enqueue(new Callback<BTC_MinerHistoryResponse>() {
            @Override
            public void onResponse(@NonNull Call<BTC_MinerHistoryResponse> call, @NonNull Response<BTC_MinerHistoryResponse> response) {
                binding.clProgressBar.setVisibility(View.GONE); // Move this line outside of the if-else block
                binding.tvNoReferrals.setVisibility(View.VISIBLE);

                if (response.isSuccessful()) {
                    BTC_MinerHistoryResponse apiResponse = response.body();

                    if (apiResponse != null) {
                        dataArrayList = apiResponse.getData().getDataList();

                        if (dataArrayList.isEmpty()) {
                            binding.rvMinerHistory.setVisibility(View.GONE);
                            binding.tvNoReferrals.setVisibility(View.VISIBLE);
                        } else {
                            binding.rvMinerHistory.setLayoutManager(new LinearLayoutManager(BTC_MinerHistoryActivity.this));
                            minerHistoryAdapter = new BTC_MinerHistoryAdapter(dataArrayList);
                            binding.rvMinerHistory.setAdapter(minerHistoryAdapter);

                            binding.rvMinerHistory.setVisibility(View.VISIBLE);
                            binding.tvNoReferrals.setVisibility(View.GONE);
                        }

                        Log.w("--apiResponse--", "miners point" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));
                    } else {

                        try {
                            binding.rvMinerHistory.setVisibility(View.GONE);
                            binding.tvNoReferrals.setVisibility(View.VISIBLE);
                            binding.clProgressBar.setVisibility(View.GONE); //
                            response.errorBody().string();
                            Log.w("--apiResponse--", "Error: else miners point" + new GsonBuilder().setPrettyPrinting().create().toJson(response.errorBody().string()));
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<BTC_MinerHistoryResponse> call, @NonNull Throwable t) {
                binding.clProgressBar.setVisibility(View.GONE);
                binding.rvMinerHistory.setVisibility(View.GONE);
                binding.tvNoReferrals.setVisibility(View.VISIBLE);

                Log.w("--apiResponse--", "Active miners" + t.getMessage());
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);

    }
}