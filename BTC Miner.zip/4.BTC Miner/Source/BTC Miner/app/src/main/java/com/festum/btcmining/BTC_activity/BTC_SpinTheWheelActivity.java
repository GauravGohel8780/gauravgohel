package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.R;
import com.festum.btcmining.databinding.ActivitySpinTheWheelBinding;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

public class BTC_SpinTheWheelActivity extends AdsBaseActivity {

    ActivitySpinTheWheelBinding binding;
    SharedPreferences sharedpreferences;
    int totalPoints;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivitySpinTheWheelBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        totalPoints = sharedpreferences.getInt(BTC_Constants.TOTAL_POINTS, 0);


        binding.tvTotalPoints.setText(String.valueOf(totalPoints));

        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_SpinTheWheelActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });


        binding.ivSilverSpin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_SpinTheWheelActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(BTC_SpinTheWheelActivity.this, BTC_OpenWheelSpinActivity.class);
                        intent.putExtra("spin_type", "silver");
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });

        binding.ivPlatinumSpin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 getInstance(BTC_SpinTheWheelActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(BTC_SpinTheWheelActivity.this, BTC_OpenWheelSpinActivity.class);
                        intent.putExtra("spin_type", "platinum");
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });

        binding.ivGoldSpin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 getInstance(BTC_SpinTheWheelActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(BTC_SpinTheWheelActivity.this, BTC_OpenWheelSpinActivity.class);
                        intent.putExtra("spin_type", "gold");
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}