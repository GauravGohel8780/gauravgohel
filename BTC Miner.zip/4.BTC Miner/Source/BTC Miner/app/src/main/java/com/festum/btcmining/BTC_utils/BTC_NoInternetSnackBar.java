package com.festum.btcmining.BTC_utils;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class BTC_NoInternetSnackBar {

//    public static boolean isNetworkAvailable(Context context) {
//        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
//        if (connectivityManager != null) {
//            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
//            return activeNetworkInfo != null && activeNetworkInfo.isConnected();
//        }
//        return false;
//    }
//
//    public static void showNoInternetSnackbar(View view) {
//        Snackbar snackbar = Snackbar.make(view, "No internet connection", Snackbar.LENGTH_INDEFINITE);
//        snackbar.show();
//    }
//
//    public static void showInternetRestoredSnackbar(View view) {
//        Snackbar snackbar = Snackbar.make(view, "OK! Your connection has been restored", Snackbar.LENGTH_INDEFINITE);
//
//        snackbar.setAction("Close", new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                snackbar.dismiss();
//            }
//        });
//
//        snackbar.show();
//    }

    public static AlertDialog noInternetDialog;
    public static AlertDialog connectionRestoredDialog;

    public static void handleConnectivityChange(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();

        if (isConnected) {
            dismissNoInternetDialog();
            showConnectionRestoredDialog(context);
        } else {
            showNoInternetDialog(context);
        }
    }

    public static void showNoInternetDialog(Context context) {
        if (noInternetDialog == null || !noInternetDialog.isShowing()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("No Internet Connection");
            builder.setMessage("Please check your internet connection and try again.");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            builder.setCancelable(false); // Optional: Make the dialog non-cancelable
            noInternetDialog = builder.create();
            noInternetDialog.show();
        }
    }

    public static void showConnectionRestoredDialog(Context context) {
        if (connectionRestoredDialog == null || !connectionRestoredDialog.isShowing()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("Connection Restored");
            builder.setMessage("Internet connection has been restored.");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            builder.setCancelable(false); // Optional: Make the dialog non-cancelable
            connectionRestoredDialog = builder.create();
            connectionRestoredDialog.show();
        }
    }

    public static void dismissNoInternetDialog() {
        if (noInternetDialog != null && noInternetDialog.isShowing()) {
            noInternetDialog.dismiss();
        }
    }
}
