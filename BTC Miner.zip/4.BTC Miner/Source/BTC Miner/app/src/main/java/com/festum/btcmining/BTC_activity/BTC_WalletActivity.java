package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.R;
import com.festum.btcmining.databinding.ActivityWalletBinding;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import java.util.Objects;

public class BTC_WalletActivity extends AdsBaseActivity {

    ActivityWalletBinding binding;
    SharedPreferences sharedpreferences;
    int totalPoints;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityWalletBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        totalPoints = sharedpreferences.getInt(BTC_Constants.TOTAL_POINTS, 0);

        binding.tvTotalPoints.setText(String.valueOf(totalPoints));


        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_WalletActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

        binding.cvWithdrawalStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String walletAddress = Objects.requireNonNull(binding.etWalletAddress.getText()).toString().trim();
                String amount = Objects.requireNonNull(binding.etWithdrawalAmount.getText()).toString();

                if (TextUtils.isEmpty(walletAddress)) {
                    Toast.makeText(BTC_WalletActivity.this, "Please enter bitcoin wallet address", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(amount)) {
                    Toast.makeText(BTC_WalletActivity.this, "Please enter withdrawal bitcoin amount", Toast.LENGTH_SHORT).show();
                } else {
                    getInstance(BTC_WalletActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            getOnBackPressedDispatcher().onBackPressed();
                        }
                    }, MAIN_CLICK);
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}