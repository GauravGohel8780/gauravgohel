package com.festum.btcmining.BTC_activity;

import static com.festum.btcmining.BTC_utils.BTC_NoInternetSnackBar.dismissNoInternetDialog;
import static com.festum.btcmining.BTC_utils.BTC_NoInternetSnackBar.showNoInternetDialog;
import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ActiveMinersListResponse;
import com.festum.btcmining.BTC_api.model.BTC_AllUsersResponse;
import com.festum.btcmining.BTC_api.model.BTC_ApiResponse;
import com.festum.btcmining.BTC_api.model.BTC_PlanDetailResponse;
import com.festum.btcmining.BTC_api.model.BTC_UserData;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.databinding.ActivityHomeBinding;
import com.festum.btcmining.BTC_receiver.BTC_CountdownReceiver;
import com.festum.btcmining.BTC_service.BTC_MyTimerService;
import com.festum.btcmining.BTC_utils.BTC_NoInternetSnackBar;
import com.festum.btcmining.BTC_utils.BTC_ServiceUtils;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_HomeActivity extends AdsBaseActivity {
    BTC_ApiResponse apiResponseGlobal;
    BTC_UserData userData;
    SharedPreferences.Editor editor;
    SharedPreferences sharedpreferences;
    String userToken;
    String code;
    String firstName;
    String lastName;
    String gender;
    String countryName;
    String email;
    String userId;
    int totalPoints;
    Call<BTC_ApiResponse> call;
    BTC_CountdownReceiver countdownReceiver;
    boolean isServiceRunning;
    public boolean isInternetConnected;
    Activity activity;
    ActivityHomeBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(this.getResources().getColor(R.color.colormian));
        }


        activity = BTC_HomeActivity.this;

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @NotNull
            @Override
            public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                Request original = chain.request();
                Request.Builder requestBuilder = original.newBuilder().header("Authorization", "Bearer " + userToken).method(original.method(), original.body());

                Request request = requestBuilder.build();

                Log.d("--apiResponse--", "URL: " + request.url());
                Log.d("--apiResponse--", "Headers: " + request.headers());
                Log.d("--apiResponse--", "Body: " + request.body());

                return chain.proceed(request);
            }
        });

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder().baseUrl(BTC_Constants.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(client).build();

        BTC_ApiService apiService = retrofit.create(BTC_ApiService.class);


        isServiceRunning = BTC_ServiceUtils.isMyServiceRunning(this, BTC_MyTimerService.class);

        Log.d("--service_stat--", "onCreate: isServiceRunning " + isServiceRunning);


        if (isServiceRunning) {
            Log.d("--service_stat--", "onDestroy: true ");
            binding.llMineTiming.setVisibility(View.VISIBLE);
            binding.tvStartMining.setVisibility(View.GONE);

            binding.tvStartMining.setText("Mining running");

            Intent serviceIntent = new Intent(BTC_HomeActivity.this, BTC_MyTimerService.class);
            ContextCompat.startForegroundService(BTC_HomeActivity.this, serviceIntent);
            countdownReceiver = new BTC_CountdownReceiver(binding.tvHour, binding.tvMinute, binding.tvSecond, binding.llMineTiming, binding.tvStartMining);
            IntentFilter filter = new IntentFilter(BTC_MyTimerService.COUNTDOWN_UPDATE_ACTION);
            registerReceiver(countdownReceiver, filter);
        } else {
            binding.llMineTiming.setVisibility(View.GONE);
            binding.tvStartMining.setVisibility(View.VISIBLE);
            Log.d("--service_stat--", "onDestroy: false ");
            binding.tvStartMining.setText("Start Mining");
            clearSharedPreferences();

        }

        userToken = getIntent().getStringExtra(BTC_Constants.USER_TOKEN);

        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");
        firstName = sharedpreferences.getString(BTC_Constants.FIRST_NAME, "");
        lastName = sharedpreferences.getString(BTC_Constants.LAST_NAME, "");
        userId = sharedpreferences.getString(BTC_Constants.USER_ID, "");

        Log.d("--token--", "onCreate: home acti: " + userToken);

        binding.llMineTiming.setVisibility(View.GONE);
        binding.tvStartMining.setVisibility(View.VISIBLE);

        Gson gson = new Gson();
        String json = sharedpreferences.getString(BTC_Constants.API_RESPONSE, "");
        apiResponseGlobal = gson.fromJson(json, BTC_ApiResponse.class);

        if (!TextUtils.isEmpty(json)) {
            apiResponseGlobal = gson.fromJson(json, BTC_ApiResponse.class);

            if (apiResponseGlobal != null) {
                userData = apiResponseGlobal.getData();

                if (userData != null) {
                    Log.d("--apiResponse--", "onCreate: ");

                    code = userData.getvReferralCode();
                    firstName = userData.getvFirstName();
                    lastName = userData.getvLastName();
                    gender = userData.getvGender();
                    countryName = userData.getvCountry();
                    email = userData.getvEmail();
                    totalPoints = userData.getdPoint();

                    editor.putString(BTC_Constants.REFERRAL_CODE, code);

                    editor.putString(BTC_Constants.FIRST_NAME, firstName);
                    editor.putString(BTC_Constants.LAST_NAME, lastName);
                    editor.putString(BTC_Constants.GENDER, gender);
                    editor.putString(BTC_Constants.COUNTRY_NAME, countryName);
                    editor.putString(BTC_Constants.EMAIL_KEY, email);
                    editor.putInt(BTC_Constants.TOTAL_POINTS, totalPoints);
                    editor.apply();

                    Log.d("--apiResponse--", "onCreate: user data code " + code);

                    binding.tvTotalPoints.setText(String.valueOf(totalPoints));

                }
            }
        }


        call = apiService.getUserDetails();

        call.enqueue(new Callback<BTC_ApiResponse>() {
            @Override
            public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {

                BTC_ApiResponse apiResponse = response.body();

                if (response.isSuccessful()) {
                    Log.w("--apiResponse--", "Home -activity ------userdata >  " + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));

                    int points = apiResponse.getData().getdPoint();
                    String planId = apiResponse.getData().getvPlanId();
                    binding.tvTotalPoints.setText(String.valueOf(points));
                    firstName = apiResponse.getData().getvFirstName();
                    lastName = apiResponse.getData().getvLastName();
                    countryName = apiResponse.getData().getvCountry();
                    userId = apiResponse.getData().get_id();

                    binding.tvUserName.setText("Hello " + firstName);
                    binding.tvProfilname.setText(firstName);

                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putInt(BTC_Constants.TOTAL_POINTS, apiResponse.getData().getdPoint());
                    editor.putString(BTC_Constants.COUNTRY_NAME, countryName);
                    editor.putString(BTC_Constants.FIRST_NAME, firstName);
                    editor.putString(BTC_Constants.LAST_NAME, lastName);
                    editor.putString(BTC_Constants.USER_ID, userId);
                    editor.putString(BTC_Constants.REFERRAL_CODE, apiResponse.getData().getvReferralCode());

                    editor.apply();

                    Log.d("--HomeActivity--", "onResponse: countryName " + countryName);

                    Call<BTC_PlanDetailResponse> planDetailResponseCall = apiService.getPlanDetails(planId);

                    planDetailResponseCall.enqueue(new Callback<BTC_PlanDetailResponse>() {
                        @Override
                        public void onResponse(@NonNull Call<BTC_PlanDetailResponse> call, @NonNull Response<BTC_PlanDetailResponse> response) {

                            if (response.isSuccessful()) {
                                BTC_PlanDetailResponse apiResponse = response.body();

                                if (apiResponse != null) {
                                    Log.w("--apiResponse--", "PlanDetailResponse" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));

                                    binding.tvPlanName.setText(apiResponse.getData().getvPlanName());

                                }

                            } else {
                                try {
                                    Log.e("--apiResponse--", "Error: PlanDetailResponse " + response.errorBody().string());
                                } catch (IOException e) {
                                    throw new RuntimeException(e);
                                }
                            }
                        }

                        @Override
                        public void onFailure(@NonNull Call<BTC_PlanDetailResponse> call, @NonNull Throwable t) {
                        }
                    });


                } else {
                    try {
                        Log.e("--apiResponse--", "Error: Home -activity ------userdata " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {

            }
        });


        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, binding.dlDrawerLayout, R.string.navigation_drawer_open, R.string.navigation_drawer_close);


        binding.ivDrawerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.dlDrawerLayout.openDrawer(GravityCompat.START);
            }
        });

        binding.dlDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        binding.llSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(BTC_HomeActivity.this, BTC_SettingsActivity.class);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });

        binding.rlDashboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        binding.dlDrawerLayout.close();
                    }
                }, MAIN_CLICK);
            }
        });

        binding.cvStartMining.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.dlDrawerLayout.close();
                binding.llMineTiming.setVisibility(View.VISIBLE);
                binding.tvStartMining.setVisibility(View.GONE);

                if (ContextCompat.checkSelfPermission(BTC_HomeActivity.this, android.Manifest.permission.FOREGROUND_SERVICE) != PackageManager.PERMISSION_GRANTED) {

                    ActivityCompat.requestPermissions(BTC_HomeActivity.this, new String[]{Manifest.permission.FOREGROUND_SERVICE}, BTC_Constants.REQUEST_FOREGROUND_PERMISSION);
                } else {

                    if (isServiceRunning) {
                        binding.llMineTiming.setVisibility(View.VISIBLE);
                        binding.tvStartMining.setVisibility(View.GONE);
                        binding.tvStartMining.setText("Mining running");

                        Call<BTC_ActiveMinersListResponse> apiResponseCall = apiService.activeUserMiner();
                        apiResponseCall.enqueue(new Callback<BTC_ActiveMinersListResponse>() {
                            @Override
                            public void onResponse(@NonNull Call<BTC_ActiveMinersListResponse> call, @NonNull Response<BTC_ActiveMinersListResponse> response) {
                                if (response.isSuccessful()) {
                                    BTC_ActiveMinersListResponse apiResponse = response.body();

                                    Log.w("--apiResponse--", "CurrentMiners Service Response -----" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));


                                } else {
                                    try {
                                        response.errorBody().string();
                                        Log.w("--apiResponse--", "response.errorBody() activeMinersListData Response -----" + new GsonBuilder().setPrettyPrinting().create().toJson(response.errorBody().string()));

                                    } catch (IOException e) {
                                        throw new RuntimeException(e);
                                    }
                                }
                            }

                            @Override
                            public void onFailure(@NonNull Call<BTC_ActiveMinersListResponse> call, @NonNull Throwable t) {
                                Log.w("--apiResponse--", "response.errorBody() activeMinersListData onFailure -----" + t.getMessage());

                            }
                        });

                        Toast.makeText(BTC_HomeActivity.this, "Mining running.", Toast.LENGTH_SHORT).show();

                        Intent serviceIntent = new Intent(BTC_HomeActivity.this, BTC_MyTimerService.class);
                        ContextCompat.startForegroundService(BTC_HomeActivity.this, serviceIntent);
//                        saveVisibilityState(true);


                        countdownReceiver = new BTC_CountdownReceiver(binding.tvHour, binding.tvMinute, binding.tvSecond, binding.llMineTiming, binding.tvStartMining);
                        IntentFilter filter = new IntentFilter(BTC_MyTimerService.COUNTDOWN_UPDATE_ACTION);
                        registerReceiver(countdownReceiver, filter);

                    } else {

                        Intent serviceIntent = new Intent(BTC_HomeActivity.this, BTC_MyTimerService.class);
                        ContextCompat.startForegroundService(BTC_HomeActivity.this, serviceIntent);
//                        saveVisibilityState(true);

                        countdownReceiver = new BTC_CountdownReceiver(binding.tvHour, binding.tvMinute, binding.tvSecond, binding.llMineTiming, binding.tvStartMining);
                        IntentFilter filter = new IntentFilter(BTC_MyTimerService.COUNTDOWN_UPDATE_ACTION);
                        registerReceiver(countdownReceiver, filter);
                    }
                }

            }
        });

        binding.llUpgradeSpeed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        binding.dlDrawerLayout.close();
                        Intent intent = new Intent(BTC_HomeActivity.this, BTC_UpgradePlansActivity.class);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });


        binding.llLeaderboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        binding.dlDrawerLayout.close();
                        Intent intent = new Intent(BTC_HomeActivity.this, BTC_LeaderboardActivity.class);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });

        binding.LLWallet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        binding.dlDrawerLayout.close();
                        Intent intent = new Intent(BTC_HomeActivity.this, BTC_WalletActivity.class);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });

        binding.llMyTeam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        binding.dlDrawerLayout.close();
                        Intent intent = new Intent(BTC_HomeActivity.this, BTC_MyTeamActivity.class);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });


        binding.llReferFriend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        binding.dlDrawerLayout.close();
                        Intent intent = new Intent(BTC_HomeActivity.this, BTC_ReferFriendActivity.class);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });

        binding.llYourProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.dlDrawerLayout.close();
                getInstance(BTC_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(BTC_HomeActivity.this, BTC_YourProfileActivity.class);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });

        binding.llExtraEarning.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        binding.dlDrawerLayout.close();
                        Intent intent = new Intent(BTC_HomeActivity.this, BTC_ExtraEarningActivity.class);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });

        binding.ivContest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        binding.dlDrawerLayout.close();
                        Intent intent = new Intent(BTC_HomeActivity.this, BTC_ContestActivity.class);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });

        binding.cvUpgradePlan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        binding.dlDrawerLayout.close();
                        Intent intent = new Intent(BTC_HomeActivity.this, BTC_UpgradePlansActivity.class);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });


        Call<BTC_AllUsersResponse> call = apiService.activeMinersList();

        call.enqueue(new Callback<BTC_AllUsersResponse>() {
            @Override
            public void onResponse(@NonNull Call<BTC_AllUsersResponse> call, @NonNull Response<BTC_AllUsersResponse> response) {

                if (response.isSuccessful()) {
                    BTC_AllUsersResponse allUsersResponse = response.body();

                    binding.tvActiveMiners.setText("" + allUsersResponse.getiCount());
                }
            }

            @Override
            public void onFailure(@NonNull Call<BTC_AllUsersResponse> call, @NonNull Throwable t) {

            }
        });


        binding.llActiveMiner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        binding.dlDrawerLayout.close();
                        Intent intent = new Intent(BTC_HomeActivity.this, BTC_ActivemMinersActivity.class);
                        startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });

        binding.llLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        binding.dlDrawerLayout.close();

                        editor.clear();
                        editor.apply();

                        Intent intent = new Intent(BTC_HomeActivity.this, BTC_MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }, MAIN_CLICK);
            }
        });


        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                getInstance(BTC_HomeActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(BTC_HomeActivity.this, BTC_ExitActivity.class);
                        startActivity(intent);
                    }
                }, BACK_CLICK);
            }
        };

        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    private void clearSharedPreferences() {
        SharedPreferences preferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.apply();
    }


    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
        if (isServiceRunning) {
            Log.d("--service_stat--", "onDestroy: true ");
        } else {
            Log.d("--service_stat--", "onDestroy: false ");

            clearSharedPreferences();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (isServiceRunning) {
            Log.d("--service_stat--", "onDestroy: true ");
        } else {
            Log.d("--service_stat--", "onDestroy: false ");

            clearSharedPreferences();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == BTC_Constants.REQUEST_FOREGROUND_PERMISSION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(this, "permission granted", Toast.LENGTH_SHORT).show();
        }

        finish();
    }


}