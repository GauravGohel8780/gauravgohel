package com.festum.btcmining.BTC_api.model;

public class BTC_PlansModel {

    public String _id;
    public boolean isPopular;
    public boolean isPurchase;
    public boolean isAvailability;
    public boolean isDeleted;
    public String vPlanName;
    public int dPrice;
    public int dSpeed;
    public int iWithdrawal;
    public int iValidity;
    public Object dtCreatedAt;

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public boolean isPopular() {
        return isPopular;
    }

    public void setPopular(boolean popular) {
        isPopular = popular;
    }

    public boolean isPurchase() {
        return isPurchase;
    }

    public void setPurchase(boolean purchase) {
        isPurchase = purchase;
    }

    public boolean isAvailability() {
        return isAvailability;
    }

    public void setAvailability(boolean availability) {
        isAvailability = availability;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public String getvPlanName() {
        return vPlanName;
    }

    public void setvPlanName(String vPlanName) {
        this.vPlanName = vPlanName;
    }

    public int getdPrice() {
        return dPrice;
    }

    public void setdPrice(int dPrice) {
        this.dPrice = dPrice;
    }

    public int getdSpeed() {
        return dSpeed;
    }

    public void setdSpeed(int dSpeed) {
        this.dSpeed = dSpeed;
    }

    public int getiWithdrawal() {
        return iWithdrawal;
    }

    public void setiWithdrawal(int iWithdrawal) {
        this.iWithdrawal = iWithdrawal;
    }

    public int getiValidity() {
        return iValidity;
    }

    public void setiValidity(int iValidity) {
        this.iValidity = iValidity;
    }

    public Object getDtCreatedAt() {
        return dtCreatedAt;
    }

    public void setDtCreatedAt(Object dtCreatedAt) {
        this.dtCreatedAt = dtCreatedAt;
    }
}
