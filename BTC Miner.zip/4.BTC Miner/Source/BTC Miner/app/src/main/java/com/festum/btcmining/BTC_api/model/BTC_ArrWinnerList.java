package com.festum.btcmining.BTC_api.model;

public class BTC_ArrWinnerList {

    public int dTotalPoint;
    public String _id;
    public String vUserId;
    public String vWinnerName;
    public Object dtCreatedAt;

    public int getdTotalPoint() {
        return dTotalPoint;
    }

    public void setdTotalPoint(int dTotalPoint) {
        this.dTotalPoint = dTotalPoint;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getvUserId() {
        return vUserId;
    }

    public void setvUserId(String vUserId) {
        this.vUserId = vUserId;
    }

    public String getvWinnerName() {
        return vWinnerName;
    }

    public void setvWinnerName(String vWinnerName) {
        this.vWinnerName = vWinnerName;
    }

    public Object getDtCreatedAt() {
        return dtCreatedAt;
    }

    public void setDtCreatedAt(Object dtCreatedAt) {
        this.dtCreatedAt = dtCreatedAt;
    }
}
