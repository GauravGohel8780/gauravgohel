package com.festum.btcmining.BTC_api.model;

public class BTC_ParticipateContest {

    public String vContestsId;
    public int iTotalTicket;
    public int iTotalAmount;

    public BTC_ParticipateContest(String vContestsId, int iTotalTicket, int iTotalAmount) {
        this.vContestsId = vContestsId;
        this.iTotalTicket = iTotalTicket;
        this.iTotalAmount = iTotalAmount;
    }

    public String getvContestsId() {
        return vContestsId;
    }

    public void setvContestsId(String vContestsId) {
        this.vContestsId = vContestsId;
    }

    public int getiTotalTicket() {
        return iTotalTicket;
    }

    public void setiTotalTicket(int iTotalTicket) {
        this.iTotalTicket = iTotalTicket;
    }

    public int getiTotalAmount() {
        return iTotalAmount;
    }

    public void setiTotalAmount(int iTotalAmount) {
        this.iTotalAmount = iTotalAmount;
    }
}
