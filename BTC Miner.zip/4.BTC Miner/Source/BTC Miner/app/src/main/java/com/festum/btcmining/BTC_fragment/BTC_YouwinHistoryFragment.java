package com.festum.btcmining.BTC_fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.festum.btcmining.BTC_adapter.BTC_YourWinAdapter;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ApiResponse;
import com.festum.btcmining.BTC_api.model.BTC_UserData;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.databinding.FragmentYouwinHistoryBinding;
import com.google.gson.GsonBuilder;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_YouwinHistoryFragment extends Fragment {
    SharedPreferences sharedpreferences;
    String userToken;
    String userId;
    FragmentYouwinHistoryBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentYouwinHistoryBinding.inflate(getLayoutInflater());

        sharedpreferences = getActivity().getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");
        userId = sharedpreferences.getString(BTC_Constants.USER_ID, "");

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @NotNull
            @Override
            public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                Request original = chain.request();
                Request.Builder requestBuilder = original.newBuilder()
                        .header("Authorization", "Bearer " + userToken)
                        .method(original.method(), original.body());

                Request request = requestBuilder.build();

                Log.d("--apiResponse--", "URL: " + request.url());
                Log.d("--apiResponse--", "Headers: " + request.headers());
                Log.d("--apiResponse--", "Body: " + request.body());

                return chain.proceed(request);
            }
        });

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BTC_Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        BTC_ApiService apiService = retrofit.create(BTC_ApiService.class);

        Call<BTC_ApiResponse> call = apiService.selectContestsWinner(userId, "6561925ffd863b17b45c5c22");

        binding.progressBar.setVisibility(View.VISIBLE);

        call.enqueue(new Callback<BTC_ApiResponse>() {
            @Override
            public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                if (response.isSuccessful()) {

                    BTC_ApiResponse apiResponse = response.body();

                    if (apiResponse != null) {

                        binding.rvYourWin.setVisibility(View.VISIBLE);
                        binding.progressBar.setVisibility(View.GONE);
                        binding.tvNoReferrals.setVisibility(View.GONE);

                        BTC_UserData winnersDataList = apiResponse.getData();
                        ArrayList<BTC_UserData> winnerList = new ArrayList<>();
                        winnerList.add(winnersDataList);

                        BTC_YourWinAdapter adapter = new BTC_YourWinAdapter(winnerList, "");
                        binding.rvYourWin.setLayoutManager(new LinearLayoutManager(getContext()));
                        binding.rvYourWin.setAdapter(adapter);


                        Log.w("--apiResponse--", "You won " + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));
                    }
                } else {
                    try {
                        binding.rvYourWin.setVisibility(View.GONE);
                        binding.progressBar.setVisibility(View.GONE);
                        binding.tvNoReferrals.setVisibility(View.VISIBLE);

                        Log.e("--apiResponse--", "Error: You won " + response.errorBody().string());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {
                Log.e("--apiResponse--", "Error: ApiResponse " + t.getMessage());

            }
        });

        return binding.getRoot();
    }
}