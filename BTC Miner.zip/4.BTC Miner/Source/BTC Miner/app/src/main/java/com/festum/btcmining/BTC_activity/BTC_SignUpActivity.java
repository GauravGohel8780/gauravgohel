package com.festum.btcmining.BTC_activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.LinkMovementMethod;
import android.text.method.PasswordTransformationMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.util.Patterns;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ApiResponse;
import com.festum.btcmining.BTC_api.model.BTC_RegisterRequest;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.databinding.ActivitySignUpBinding;

import java.io.IOException;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_SignUpActivity extends AdsBaseActivity {

    ActivitySignUpBinding binding;
    boolean isPasswordVisible = false;
    boolean isConfirmPasswordVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySignUpBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        String fullText = getResources().getString(R.string.accept_terms_of_use_amp_privacy_policy);
        SpannableString spannableString = new SpannableString(fullText);

        ClickableSpan clickSpan1 = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                Toast.makeText(BTC_SignUpActivity.this, "Terms of Use", Toast.LENGTH_SHORT).show();
            }
        };

        ClickableSpan clickSpan2 = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                Toast.makeText(BTC_SignUpActivity.this, "Privacy Policy", Toast.LENGTH_SHORT).show();
            }
        };

        int clickableTextColor1 = getResources().getColor(R.color.orange);
        int clickableTextColor2 = getResources().getColor(R.color.orange);

        spannableString.setSpan(clickSpan1, 7, 19, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableString.setSpan(new ForegroundColorSpan(clickableTextColor1),
                7, 19, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        spannableString.setSpan(clickSpan2, 21, 36, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableString.setSpan(new ForegroundColorSpan(clickableTextColor2),
                21, 36, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        binding.tvPrivacyPolicy.setMovementMethod(LinkMovementMethod.getInstance());
        binding.tvPrivacyPolicy.setText(spannableString);


        String fullText1 = getResources().getString(R.string.already_have_an_account_log_in);
        String signUpText = "Log in!";

        SpannableString login = new SpannableString(fullText1);

        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                startActivity(new Intent(BTC_SignUpActivity.this, BTC_LoginActivity.class));
            }

            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                super.updateDrawState(ds);
                ds.setUnderlineText(false);
                ds.setColor(getResources().getColor(R.color.orange));
                ds.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

            }
        };

        int startIndex = fullText1.indexOf(signUpText);
        int endIndex = startIndex + signUpText.length();
        login.setSpan(clickableSpan, startIndex, endIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        binding.tvLogIn.setText(login);
        binding.tvLogIn.setMovementMethod(LinkMovementMethod.getInstance());


        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BTC_Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();




        BTC_ApiService apiService = retrofit.create(BTC_ApiService.class);


        binding.icPasswordVisibility.setImageDrawable(getDrawable(R.drawable.ic_unselect_eye));
        binding.etPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
        binding.icConfirmPasswordVisibility.setImageDrawable(getDrawable(R.drawable.ic_unselect_eye));
        binding.etConfirmPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());

        binding.icPasswordVisibility.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isPasswordVisible = !isPasswordVisible;
                if (isPasswordVisible) {
                    binding.etPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    binding.icPasswordVisibility.setImageDrawable(getDrawable(R.drawable.ic_select_eye));
                } else {
                    binding.icPasswordVisibility.setImageDrawable(getDrawable(R.drawable.ic_unselect_eye));
                    binding.etPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
                binding.etPassword.setSelection(Objects.requireNonNull(binding.etPassword.getText()).length());
            }
        });


        binding.icConfirmPasswordVisibility.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                isConfirmPasswordVisible = !isConfirmPasswordVisible;

                if (isConfirmPasswordVisible) {
                    binding.etConfirmPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    binding.icConfirmPasswordVisibility.setImageDrawable(getDrawable(R.drawable.ic_select_eye));
                } else {
                    binding.icConfirmPasswordVisibility.setImageDrawable(getDrawable(R.drawable.ic_unselect_eye));
                    binding.etConfirmPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }

                binding.etConfirmPassword.setSelection(Objects.requireNonNull(binding.etConfirmPassword.getText()).length());
            }
        });


        binding.tvSingUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = Objects.requireNonNull(binding.etEmail.getText()).toString().trim();
                String referralCode = Objects.requireNonNull(binding.etReferralCode.getText()).toString().trim();
                String password = Objects.requireNonNull(binding.etPassword.getText()).toString();
                String confirmPassword = Objects.requireNonNull(binding.etConfirmPassword.getText()).toString();

                if (!isValidEmail(email)) {
                    Toast.makeText(BTC_SignUpActivity.this, getString(R.string.invalid_email_address), Toast.LENGTH_SHORT).show();
                } else if (!isStrongPassword(password)) {
                    Toast.makeText(BTC_SignUpActivity.this, R.string.password_validation_error, Toast.LENGTH_SHORT).show();
                } else if (!confirmPassword.equals(password)) {
                    Toast.makeText(BTC_SignUpActivity.this, "Password doesn't match, please check it.", Toast.LENGTH_SHORT).show();
                } else if (!binding.cbPolicy.isChecked()) {
                    Toast.makeText(BTC_SignUpActivity.this, "Please agree our Policy & Terms", Toast.LENGTH_SHORT).show();
                } else {

                    binding.clProgressBar.setVisibility(View.VISIBLE);

                    BTC_RegisterRequest request = new BTC_RegisterRequest();
                    request.setvEmail(email);
                    request.setvReferralCode(referralCode);
                    request.setvPassword(password);

                    Call<BTC_ApiResponse> call = apiService.registerUser(request);
                    call.enqueue(new Callback<BTC_ApiResponse>() {
                        @Override
                        public void onResponse(Call<BTC_ApiResponse> call, Response<BTC_ApiResponse> response) {
                            if (response.isSuccessful()) {


                                binding.clProgressBar.setVisibility(View.GONE);

                                BTC_ApiResponse apiResponse = response.body();
                                Log.d("--apiResponse--", "onResponse: code " + apiResponse.getiStatusCode());
                                Log.d("--apiResponse--", "onResponse: data " + apiResponse.getData());

                                if (apiResponse.getiStatusCode() == BTC_Constants.SUCCESS_CODE) {
                                    Dialog dialog = new Dialog(BTC_SignUpActivity.this, R.style.customDialog);

                                    dialog.setContentView(R.layout.dialog_register_successful);
                                    dialog.setCancelable(false);

                                    Objects.requireNonNull(dialog.getWindow()).setGravity(Gravity.CENTER);
                                    dialog.getWindow().setLayout(-1, -2);

                                    Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(ContextCompat.getDrawable(BTC_SignUpActivity.this, android.R.color.transparent));

                                    ImageView ivCancel = dialog.findViewById(R.id.ivCancel);
                                    CardView cvOk = dialog.findViewById(R.id.cvOk);

                                    dialog.show();

                                    ivCancel.setVisibility(View.GONE);


                                    cvOk.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            dialog.dismiss();

                                            Intent intent = new Intent(BTC_SignUpActivity.this, BTC_LoginActivity.class);
                                            startActivity(intent);
                                        }
                                    });
                                } else if (apiResponse.getiStatusCode() == BTC_Constants.ERROR_CODE) {
                                    binding.clProgressBar.setVisibility(View.GONE);
                                    Toast.makeText(BTC_SignUpActivity.this, "This email is registered with us.", Toast.LENGTH_SHORT).show();
                                }


                            } else {
                                binding.clProgressBar.setVisibility(View.GONE);
                                try {
                                    binding.clProgressBar.setVisibility(View.GONE);
                                    assert response.errorBody() != null;
                                    String errorBody = response.errorBody().string();
                                    Log.e("--ErrorResponse--", "onResponse: " + errorBody);

                                    Toast.makeText(BTC_SignUpActivity.this, "Email is already registered with us", Toast.LENGTH_SHORT).show();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        }

                        @Override
                        public void onFailure(Call<BTC_ApiResponse> call, Throwable t) {
                            binding.clProgressBar.setVisibility(View.GONE);
                            Toast.makeText(BTC_SignUpActivity.this, "Failed to register. Check your internet connection.", Toast.LENGTH_SHORT).show();
                            Log.e("--onFailure--", "onFailure: " + t.getMessage());
                        }
                    });

                }
            }
        });

    }


    private boolean isValidEmail(CharSequence target) {
        return Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

    private boolean isStrongPassword(String password) {
        String regex = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }
}