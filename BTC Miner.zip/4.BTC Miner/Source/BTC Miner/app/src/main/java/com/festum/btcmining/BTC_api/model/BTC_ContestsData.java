package com.festum.btcmining.BTC_api.model;

public class BTC_ContestsData {

    public String _id;
    public int iTotalUser;
    public boolean isDeleted;
    public String vContestName;
    public String vContestType;
    public int dContestTicket;
    public int dContestPoint;
    public int dtExpiryDate;
    public long dtCreatedAt;


    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public int getiTotalUser() {
        return iTotalUser;
    }

    public void setiTotalUser(int iTotalUser) {
        this.iTotalUser = iTotalUser;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public String getvContestName() {
        return vContestName;
    }

    public void setvContestName(String vContestName) {
        this.vContestName = vContestName;
    }

    public String getvContestType() {
        return vContestType;
    }

    public void setvContestType(String vContestType) {
        this.vContestType = vContestType;
    }

    public int getdContestTicket() {
        return dContestTicket;
    }

    public void setdContestTicket(int dContestTicket) {
        this.dContestTicket = dContestTicket;
    }

    public int getdContestPoint() {
        return dContestPoint;
    }

    public void setdContestPoint(int dContestPoint) {
        this.dContestPoint = dContestPoint;
    }

    public int getDtExpiryDate() {
        return dtExpiryDate;
    }

    public void setDtExpiryDate(int dtExpiryDate) {
        this.dtExpiryDate = dtExpiryDate;
    }

    public long getDtCreatedAt() {
        return dtCreatedAt;
    }

    public void setDtCreatedAt(long dtCreatedAt) {
        this.dtCreatedAt = dtCreatedAt;
    }
}
