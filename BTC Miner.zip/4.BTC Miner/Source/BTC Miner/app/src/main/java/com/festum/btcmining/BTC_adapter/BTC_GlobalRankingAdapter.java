package com.festum.btcmining.BTC_adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.model.BTC_AllUsersDataRequest;

import java.util.ArrayList;
import java.util.Collections;

public class BTC_GlobalRankingAdapter extends RecyclerView.Adapter<BTC_GlobalRankingAdapter.ViewHolder> {

    ArrayList<BTC_AllUsersDataRequest> leaderboardList;
    String fragment;

    public BTC_GlobalRankingAdapter(ArrayList<BTC_AllUsersDataRequest> leaderboardList, String fragment) {
        this.leaderboardList = leaderboardList;
        this.fragment = fragment;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.globalranking_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BTC_AllUsersDataRequest leaderboardModel = leaderboardList.get(position);

        String originalString = leaderboardModel.getvFirstName();

        if (originalString != null) {
            String hiddenResult = hideCharacters(originalString);

            holder.tv_player_name.setText(hiddenResult);
        }

        String stringDouble= Double.toString(leaderboardModel.getdPoint());

        holder.tv_position.setText(String.valueOf(position + 1));
        holder.tv_winning_score.setText(stringDouble);
    }

    @Override
    public int getItemCount() {
        return leaderboardList.size();
    }

    public static String hideCharacters(String inputString) {
        if (inputString.length() >= 2) {
            int asteriskCount = Math.min(6, inputString.length() - 2);
            String hiddenPart = String.join("", Collections.nCopies(asteriskCount, "*"));
            return inputString.substring(0, 2) + hiddenPart;
        } else {
            return inputString;
        }
    }
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv_position;
        TextView tv_player_name;
        TextView tv_winning_score;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tv_position = itemView.findViewById(R.id.tv_position);
            tv_player_name = itemView.findViewById(R.id.tv_player_name);
            tv_winning_score = itemView.findViewById(R.id.tv_winning_score);
        }


    }
}
