package com.festum.btcmining.BTC_api.model;

public class BTC_RegisterRequest {

    String vEmail;
    String vPassword;
    String vReferralCode;

    public BTC_RegisterRequest(String vEmail, String vPassword, String vReferralCode) {
        this.vEmail = vEmail;
        this.vPassword = vPassword;
        this.vReferralCode = vReferralCode;
    }

    public BTC_RegisterRequest(String vEmail, String vPassword) {
        this.vEmail = vEmail;
        this.vPassword = vPassword;
    }

    public BTC_RegisterRequest() {
    }

    public String getvEmail() {
        return vEmail;
    }

    public void setvEmail(String vEmail) {
        this.vEmail = vEmail;
    }

    public String getvPassword() {
        return vPassword;
    }

    public void setvPassword(String vPassword) {
        this.vPassword = vPassword;
    }

    public String getvReferralCode() {
        return vReferralCode;
    }

    public void setvReferralCode(String vReferralCode) {
        this.vReferralCode = vReferralCode;
    }
}
