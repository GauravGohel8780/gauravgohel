package com.festum.btcmining.BTC_adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.model.BTC_TransactionData;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

public class BTC_TransactionHistoryAdapter extends RecyclerView.Adapter<BTC_TransactionHistoryAdapter.ViewHolder> {

    ArrayList<BTC_TransactionData> participateContestList;

    public BTC_TransactionHistoryAdapter(ArrayList<BTC_TransactionData> participateContestList) {
        this.participateContestList = participateContestList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.winnershistory_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BTC_TransactionData transactionData = participateContestList.get(position);

        long timeStamp = transactionData.getDtCreatedAt();

        holder.tv_tickets.setText("Tickets: " + transactionData.getiTotalTicket());
        holder.tv_history_date.setText(formatDate(timeStamp));
        holder.tv_total_amount.setText(String.valueOf(transactionData.getiTotalAmount()));

    }

    @Override
    public int getItemCount() {
        return participateContestList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView tv_tickets;
        TextView tv_history_date;
        TextView tv_total_amount;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tv_tickets = itemView.findViewById(R.id.tv_winner_name);
            tv_history_date = itemView.findViewById(R.id.tv_winner_date);
            tv_total_amount = itemView.findViewById(R.id.tv_winner_point);
        }
    }

    private String formatDate(long milliseconds)  {
        DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy' 'HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliseconds);
        TimeZone tz = TimeZone.getDefault();
        sdf.setTimeZone(tz);
        return sdf.format(calendar.getTime());
    }

}
