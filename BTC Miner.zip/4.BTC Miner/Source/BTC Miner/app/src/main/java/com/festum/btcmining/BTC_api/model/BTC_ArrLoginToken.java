package com.festum.btcmining.BTC_api.model;

public class BTC_ArrLoginToken {
    public String _id;
    public String vToken;

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getvToken() {
        return vToken;
    }

    public void setvToken(String vToken) {
        this.vToken = vToken;
    }
}
