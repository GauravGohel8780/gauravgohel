package com.festum.btcmining.BTC_api.model;

import java.util.ArrayList;

public class BTC_UserData {

    public boolean isNewUser;
    public boolean isDeleted;
    public boolean isMailVerified;
    public boolean isActive;
    public String _id;
    public String vEmail;
    public String userToken;
    public String vPassword;
    public String vReferralCode;
    public int dPoint;
    public long iMailVerifiedToken;
    public long dtCreatedAt;
    public ArrayList<Object> arrReferralList;
    public ArrayList<BTC_ArrLoginToken> arrLoginToken;
    public int __v;
    public long dtUpdatedAt;
    public boolean isUpdated;
    public String vCountry;
    public String vFirstName;
    public String vGender;
    public String vLastName;
    public String vPlanId;

    public BTC_UserData() {
    }


    public boolean isNewUser() {
        return isNewUser;
    }

    public void setNewUser(boolean newUser) {
        isNewUser = newUser;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public boolean isMailVerified() {
        return isMailVerified;
    }

    public void setMailVerified(boolean mailVerified) {
        isMailVerified = mailVerified;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getvEmail() {
        return vEmail;
    }

    public void setvEmail(String vEmail) {
        this.vEmail = vEmail;
    }

    public String getvPassword() {
        return vPassword;
    }

    public void setvPassword(String vPassword) {
        this.vPassword = vPassword;
    }

    public String getvReferralCode() {
        return vReferralCode;
    }

    public void setvReferralCode(String vReferralCode) {
        this.vReferralCode = vReferralCode;
    }

    public int getdPoint() {
        return dPoint;
    }

    public void setdPoint(int dPoint) {
        this.dPoint = dPoint;
    }

    public long getiMailVerifiedToken() {
        return iMailVerifiedToken;
    }

    public void setiMailVerifiedToken(long iMailVerifiedToken) {
        this.iMailVerifiedToken = iMailVerifiedToken;
    }

    public long getDtCreatedAt() {
        return dtCreatedAt;
    }

    public void setDtCreatedAt(long dtCreatedAt) {
        this.dtCreatedAt = dtCreatedAt;
    }

    public ArrayList<Object> getArrReferralList() {
        return arrReferralList;
    }

    public void setArrReferralList(ArrayList<Object> arrReferralList) {
        this.arrReferralList = arrReferralList;
    }

    public ArrayList<BTC_ArrLoginToken> getArrLoginToken() {
        return arrLoginToken;
    }

    public void setArrLoginToken(ArrayList<BTC_ArrLoginToken> arrLoginToken) {
        this.arrLoginToken = arrLoginToken;
    }

    public int get__v() {
        return __v;
    }

    public void set__v(int __v) {
        this.__v = __v;
    }

    public long getDtUpdatedAt() {
        return dtUpdatedAt;
    }

    public void setDtUpdatedAt(long dtUpdatedAt) {
        this.dtUpdatedAt = dtUpdatedAt;
    }

    public boolean isUpdated() {
        return isUpdated;
    }

    public void setUpdated(boolean updated) {
        isUpdated = updated;
    }

    public String getvCountry() {
        return vCountry;
    }

    public void setvCountry(String vCountry) {
        this.vCountry = vCountry;
    }

    public String getvFirstName() {
        return vFirstName;
    }

    public void setvFirstName(String vFirstName) {
        this.vFirstName = vFirstName;
    }

    public String getvGender() {
        return vGender;
    }

    public void setvGender(String vGender) {
        this.vGender = vGender;
    }

    public String getvLastName() {
        return vLastName;
    }

    public void setvLastName(String vLastName) {
        this.vLastName = vLastName;
    }

    public String getvPlanId() {
        return vPlanId;
    }

    public void setvPlanId(String vPlanId) {
        this.vPlanId = vPlanId;
    }

    public String getUserToken() {
        return userToken;
    }

    public void setUserToken(String userToken) {
        this.userToken = userToken;
    }
}
