package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Toast;

import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ApiResponse;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.databinding.ActivityChangePasswordBinding;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_ChangePasswordActivity extends AdsBaseActivity {

    ActivityChangePasswordBinding binding;
    boolean isPasswordVisible = false;
    boolean isConfirmPasswordVisible = false;

    String userToken;
    SharedPreferences sharedpreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityChangePasswordBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");

        String intentEmail = getIntent().getStringExtra("email");

        Toast.makeText(this, ""+intentEmail, Toast.LENGTH_SHORT).show();
        binding.etEmail.setText(intentEmail);

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @NotNull
            @Override
            public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                Request original = chain.request();
                Request.Builder requestBuilder = original.newBuilder().header("Authorization", "Bearer " + userToken).method(original.method(), original.body());

                Request request = requestBuilder.build();

                Log.d("--apiResponse--", "URL: " + request.url());
                Log.d("--apiResponse--", "Headers: " + request.headers());
                Log.d("--apiResponse--", "Body: " + request.body());

                return chain.proceed(request);
            }
        });

        OkHttpClient client = httpClient.build();

        Retrofit loginRetrofit = new Retrofit.Builder().baseUrl(BTC_Constants.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(client).build();

        BTC_ApiService loginService = loginRetrofit.create(BTC_ApiService.class);


        binding.tvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = Objects.requireNonNull(binding.etEmail.getText()).toString().trim();
                String password = Objects.requireNonNull(binding.etPassword.getText()).toString();
                String ConfirmPassword = Objects.requireNonNull(binding.etConfirmPassword.getText()).toString();

                if (email.isEmpty()) {
                    Toast.makeText(BTC_ChangePasswordActivity.this, "Please Enter your email address", Toast.LENGTH_SHORT).show();
                } else if (password.isEmpty()) {
                    Toast.makeText(BTC_ChangePasswordActivity.this, "Please Enter your Password", Toast.LENGTH_SHORT).show();
                } else if (ConfirmPassword.isEmpty()) {
                    Toast.makeText(BTC_ChangePasswordActivity.this, "Please Enter your ConfirmPassword", Toast.LENGTH_SHORT).show();
                } else if (!isValidEmail(email)) {
                    Toast.makeText(BTC_ChangePasswordActivity.this, getString(R.string.invalid_email_address), Toast.LENGTH_SHORT).show();
                } else if (!isStrongPassword(password)) {
                    Toast.makeText(BTC_ChangePasswordActivity.this, R.string.password_validation_error, Toast.LENGTH_SHORT).show();
                } else if (!isStrongPassword(ConfirmPassword)) {
                    Toast.makeText(BTC_ChangePasswordActivity.this, R.string.password_validation_error, Toast.LENGTH_SHORT).show();
                } else if (!password.equals(ConfirmPassword)) {
                    Toast.makeText(BTC_ChangePasswordActivity.this, "Password and ConfirmPassword are not Match", Toast.LENGTH_SHORT).show();
                } else {
                    binding.clProgressBar.setVisibility(View.VISIBLE);

                    Call<BTC_ApiResponse> call = loginService.changePassword(email, password);

                    call.enqueue(new Callback<BTC_ApiResponse>() {
                        @Override
                        public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {

                            binding.clProgressBar.setVisibility(View.VISIBLE);

                            if (response.isSuccessful()) {
                                binding.clProgressBar.setVisibility(View.GONE);

                                BTC_ApiResponse apiResponse = response.body();

                                if (apiResponse != null) {
                                    Log.w("--passResponse--", "onResponse: " + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));
                                    getInstance(BTC_ChangePasswordActivity.this).ShowAd(new HandleClick() {
                                        @Override
                                        public void Show(boolean adShow) {
                                            Intent intent = new Intent(BTC_ChangePasswordActivity.this, BTC_LoginActivity.class);
                                            startActivity(intent);
                                            finish();
                                        }
                                    }, MAIN_CLICK);

                                    Toast.makeText(BTC_ChangePasswordActivity.this, "Now, Login with your email and changed password.", Toast.LENGTH_LONG).show();
                                }
                            } else {
                                try {

                                    assert response.errorBody() != null;
                                    Log.e("--passResponse--", "error response: " + new GsonBuilder().setPrettyPrinting().create().toJson(response.errorBody().string()));

                                    Toast.makeText(BTC_ChangePasswordActivity.this, "Your forgot password mail not verified yet! Please verify.", Toast.LENGTH_SHORT).show();


                                } catch (IOException e) {
                                    throw new RuntimeException(e);
                                }
                            }
                        }

                        @Override
                        public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {

                        }
                    });
                }
            }
        });

        binding.icPasswordVisibility.setImageDrawable(

                getDrawable(R.drawable.ic_unselect_eye));
        binding.etPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
        binding.icConfirmPasswordVisibility.setImageDrawable(

                getDrawable(R.drawable.ic_unselect_eye));
        binding.etConfirmPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());

        binding.icPasswordVisibility.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isPasswordVisible = !isPasswordVisible;
                if (isPasswordVisible) {
                    binding.etPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    binding.icPasswordVisibility.setImageDrawable(getDrawable(R.drawable.ic_select_eye));
                } else {
                    binding.icPasswordVisibility.setImageDrawable(getDrawable(R.drawable.ic_unselect_eye));
                    binding.etPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
                binding.etPassword.setSelection(Objects.requireNonNull(binding.etPassword.getText()).length());
            }
        });


        binding.icConfirmPasswordVisibility.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                isConfirmPasswordVisible = !isConfirmPasswordVisible;

                if (isConfirmPasswordVisible) {
                    binding.etConfirmPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    binding.icConfirmPasswordVisibility.setImageDrawable(getDrawable(R.drawable.ic_select_eye));
                } else {
                    binding.icConfirmPasswordVisibility.setImageDrawable(getDrawable(R.drawable.ic_unselect_eye));
                    binding.etConfirmPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }

                binding.etConfirmPassword.setSelection(Objects.requireNonNull(binding.etConfirmPassword.getText()).length());
            }
        });

    }

    private boolean isValidEmail(CharSequence target) {
        return Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

    private boolean isStrongPassword(String password) {
        String regex = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}