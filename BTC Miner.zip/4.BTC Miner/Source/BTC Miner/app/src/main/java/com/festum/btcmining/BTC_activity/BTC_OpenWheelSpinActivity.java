package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.adefruandta.spinningwheel.SpinningWheelView;
import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ApiResponse;
import com.festum.btcmining.BTC_api.model.BTC_SpinWheelData;
import com.festum.btcmining.BTC_api.model.BTC_SpinWheelResponse;
import com.festum.btcmining.BTC_api.model.BTC_UpdatePoints;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.databinding.ActivityOpenWheelSpinBinding;
import com.festum.btcmining.BTC_preference.BTC_TimerPreference;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_OpenWheelSpinActivity extends AdsBaseActivity {

    ActivityOpenWheelSpinBinding binding;
    String spin_type;
    ArrayList<Integer> pointsList = new ArrayList<>();
    int availableSpins;
    int updatePoint;
    boolean isSpinning = false;
    SharedPreferences sharedpreferences;
    String userToken;

    ArrayList<BTC_SpinWheelData> dataArrayList = new ArrayList<>();
    BTC_UpdatePoints updatePoints;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityOpenWheelSpinBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        spin_type = getIntent().getStringExtra("spin_type");

        binding.ivBack.setOnClickListener(v -> {
            getInstance(BTC_OpenWheelSpinActivity.this).ShowAd(new HandleClick() {
                @Override
                public void Show(boolean adShow) {
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }, BACK_CLICK);

        });


        binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + availableSpins);

        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");

        if (spin_type.equals("silver")) {

            availableSpins = sharedpreferences.getInt(BTC_Constants.AVAILABLE_SILVER_SPINS, availableSpins);

            String json = sharedpreferences.getString(BTC_Constants.SILVER_SPIN_POINT_LIST, "");

            Gson gson = new Gson();
            Type type = new TypeToken<List<Integer>>() {
            }.getType();
            pointsList = gson.fromJson(json, type);

        } else if (spin_type.equals("platinum")) {

            availableSpins = sharedpreferences.getInt(BTC_Constants.AVAILABLE_PLATINUM_SPINS, availableSpins);

            String json = sharedpreferences.getString(BTC_Constants.PLATINUM_SPIN_POINT_LIST, "");

            Gson gson = new Gson();
            Type type = new TypeToken<List<Integer>>() {
            }.getType();
            pointsList = gson.fromJson(json, type);

        } else {
            availableSpins = sharedpreferences.getInt(BTC_Constants.AVAILABLE_GOLDEN_SPINS, availableSpins);

            String json = sharedpreferences.getString(BTC_Constants.GOLDEN_SPIN_POINT_LIST, "");

            Gson gson = new Gson();
            Type type = new TypeToken<List<Integer>>() {
            }.getType();
            pointsList = gson.fromJson(json, type);
        }

        binding.wheel.setItems(pointsList);

        binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + availableSpins);

        Log.d("--token--", "onCreate: spin wheel " + userToken);

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @NotNull
            @Override
            public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                Request original = chain.request();
                Request.Builder requestBuilder = original.newBuilder()
                        .header("Authorization", "Bearer " + userToken)
                        .method(original.method(), original.body());

                Request request = requestBuilder.build();

                Log.d("--apiResponse--", "URL: " + request.url());
                Log.d("--apiResponse--", "Headers: " + request.headers());
                Log.d("--apiResponse--", "Body: " + request.body());

                return chain.proceed(request);
            }
        });

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BTC_Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        BTC_ApiService apiService = retrofit.create(BTC_ApiService.class);

        Call<BTC_SpinWheelResponse> call = apiService.spinTheWheelList();

        call.enqueue(new Callback<BTC_SpinWheelResponse>() {
            @Override
            public void onResponse(@NonNull Call<BTC_SpinWheelResponse> call, @NonNull Response<BTC_SpinWheelResponse> response) {
                BTC_SpinWheelResponse apiResponse = response.body();

//                Dialog dialog = new Dialog(OpenWheelSpinActivity.this, R.style.customDialog);
//
//                dialog.setContentView(R.layout.dialog_quiz_result);
//
//
//                TextView tvBtnText = dialog.findViewById(R.id.tvBtnText);
//
//                tvBtnText.setText("Collect");

                SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                if (apiResponse != null) {
                    ArrayList<BTC_SpinWheelData> spinWheelDataArrayList = apiResponse.getData();
                    dataArrayList.addAll(spinWheelDataArrayList);

                    if (spin_type != null) {

                        if (spin_type.equals("silver")) {

                            binding.tvTitleName.setText("Silver Spin Wheel");

                            if (BTC_TimerPreference.isSilverDayPassed(BTC_OpenWheelSpinActivity.this)) {
                                Log.d("--isDayPassed--", "onResponse: silver isDayPassed() " + BTC_TimerPreference.isSilverDayPassed(BTC_OpenWheelSpinActivity.this));
                                Log.d("--spin_type--", "onResponse: ");

                                BTC_SpinWheelData spinWheelData = dataArrayList.get(2);
                                pointsList = spinWheelData.getArrSpinWheelPoint();

                                availableSpins = spinWheelData.getiTotalOneDaySpin();

                                Gson gson = new Gson();
                                String json = gson.toJson(pointsList);

                                editor.putString(BTC_Constants.SILVER_SPIN_POINT_LIST, json);
                                editor.putInt(BTC_Constants.AVAILABLE_SILVER_SPINS, availableSpins);
                                editor.apply();

                                binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + availableSpins);


                                Log.w("--apiResponse--", "SpinWheelData" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));


                                ArrayList<String> result = new ArrayList<>();
                                for (Integer i : pointsList) {
                                    result.add(i.toString());
                                    binding.wheel.setItems(result);

                                }

                                binding.wheel.setOnRotationListener(new SpinningWheelView.OnRotationListener<String>() {

                                    @Override
                                    public void onRotation() {
                                        Log.d("XXXX", "On Rotation");
                                        binding.tvSpinNow.setVisibility(View.GONE);
                                    }

                                    @Override
                                    public void onStopRotation(String item) {
                                        Toast.makeText(BTC_OpenWheelSpinActivity.this, "You've got " + item + " Points", Toast.LENGTH_LONG).show();

                                        availableSpins = sharedpreferences.getInt(BTC_Constants.AVAILABLE_SILVER_SPINS, availableSpins);
                                        binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + availableSpins);

                                        updatePoint = Integer.parseInt(item);

                                        if (updatePoint == 0) {
                                            winCoinsDialog(updatePoint);
                                        } else {

                                            updatePoints = new BTC_UpdatePoints("Silver spin the wheel points", updatePoint, true);

                                            Call<BTC_ApiResponse> call = apiService.updateUserPoint(updatePoints);

                                            call.enqueue(new Callback<BTC_ApiResponse>() {
                                                @Override
                                                public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                                                    BTC_ApiResponse apiResponse = response.body();

                                                    Log.d("--apiResponse--", "onResponse: " + apiResponse);
                                                    winCoinsDialog(updatePoint);
                                                }

                                                @Override
                                                public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {

                                                }
                                            });
                                        }

                                    }
                                });

                                BTC_TimerPreference.updateSilverLastCallTime(BTC_OpenWheelSpinActivity.this);
                            } else {

                                Log.d("--isDayPassed--", "isDayPassed: silver else " + BTC_TimerPreference.isSilverDayPassed(BTC_OpenWheelSpinActivity.this) + "-------> total cards--" + availableSpins);
                                Log.d("--isDayPassed--", "isDayPassed: silver else " + BTC_TimerPreference.isSilverDayPassed(BTC_OpenWheelSpinActivity.this) + "-------> Points--" + updatePoint);

                                binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + availableSpins);

                                ArrayList<String> result = new ArrayList<>();

                                for (Integer i : pointsList) {
                                    result.add(i.toString());
                                    binding.wheel.setItems(result);

                                }

                                binding.wheel.setOnRotationListener(new SpinningWheelView.OnRotationListener<String>() {

                                    @Override
                                    public void onRotation() {
                                        Log.d("XXXX", "On Rotation");
                                        binding.tvSpinNow.setVisibility(View.GONE);
                                    }

                                    @Override
                                    public void onStopRotation(String item) {
                                        Toast.makeText(BTC_OpenWheelSpinActivity.this, "You've got " + item + " Points", Toast.LENGTH_SHORT).show();

                                        availableSpins = sharedpreferences.getInt(BTC_Constants.AVAILABLE_SILVER_SPINS, availableSpins);
                                        binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + availableSpins);

                                        updatePoint = Integer.parseInt(item);

                                        editor.putInt(BTC_Constants.AVAILABLE_SILVER_SPINS, availableSpins);
                                        editor.apply();

                                        if (updatePoint == 0) {
                                            winCoinsDialog(updatePoint);
                                        } else {

                                            BTC_UpdatePoints updatePoints = new BTC_UpdatePoints("Silver spin the wheel points", updatePoint, true);

                                            Call<BTC_ApiResponse> call = apiService.updateUserPoint(updatePoints);

                                            call.enqueue(new Callback<BTC_ApiResponse>() {
                                                @Override
                                                public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                                                    BTC_ApiResponse apiResponse = response.body();

                                                    Log.d("--apiResponse--", "onResponse: " + apiResponse);
                                                    winCoinsDialog(updatePoint);
                                                }

                                                @Override
                                                public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {

                                                }
                                            });
                                        }


                                    }
                                });
                            }
                        } else if (spin_type.equals("platinum")) {

                            binding.tvTitleName.setText("Platinum Spin Wheel");

                            if (BTC_TimerPreference.isPlatinumDayPassed(BTC_OpenWheelSpinActivity.this)) {
                                Log.d("--isDayPassed--", "onResponse: platinum isDayPassed() " + BTC_TimerPreference.isPlatinumDayPassed(BTC_OpenWheelSpinActivity.this));
                                Log.d("--spin_type--", "onResponse: ");

                                BTC_SpinWheelData spinWheelData = dataArrayList.get(1);
                                pointsList = spinWheelData.getArrSpinWheelPoint();

                                availableSpins = spinWheelData.getiTotalOneDaySpin();

                                Gson gson = new Gson();
                                String json = gson.toJson(pointsList);

                                editor.putString(BTC_Constants.PLATINUM_SPIN_POINT_LIST, json);
                                editor.putInt(BTC_Constants.AVAILABLE_PLATINUM_SPINS, availableSpins);
                                editor.apply();

                                binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + availableSpins);


                                Log.w("--apiResponse--", "SpinWheelData" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));


                                ArrayList<String> result = new ArrayList<>();
                                for (Integer i : pointsList) {
                                    result.add(i.toString());
                                    binding.wheel.setItems(result);

                                }

                                binding.wheel.setOnRotationListener(new SpinningWheelView.OnRotationListener<String>() {

                                    @Override
                                    public void onRotation() {
                                        Log.d("XXXX", "On Rotation");
                                        binding.tvSpinNow.setVisibility(View.GONE);
                                    }

                                    @Override
                                    public void onStopRotation(String item) {
                                        Toast.makeText(BTC_OpenWheelSpinActivity.this, "You've got " + item + " Points", Toast.LENGTH_SHORT).show();


                                        binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + availableSpins);

                                        updatePoint = Integer.parseInt(item);

                                        if (updatePoint == 0) {
                                            Toast.makeText(BTC_OpenWheelSpinActivity.this, "You've got " + item + " Points", Toast.LENGTH_SHORT).show();
                                            getOnBackPressedDispatcher().onBackPressed();
                                        } else {

                                            updatePoints = new BTC_UpdatePoints("Platinum spin the wheel points", updatePoint, true);

                                            Call<BTC_ApiResponse> call = apiService.updateUserPoint(updatePoints);

                                            call.enqueue(new Callback<BTC_ApiResponse>() {
                                                @Override
                                                public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                                                    BTC_ApiResponse apiResponse = response.body();

                                                    Log.d("--apiResponse--", "onResponse: " + apiResponse);
                                                    winCoinsDialog(updatePoint);
                                                }

                                                @Override
                                                public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {

                                                }
                                            });
                                        }

                                    }
                                });

                                BTC_TimerPreference.updatePlatinumLastCallTime(BTC_OpenWheelSpinActivity.this);
                            } else {

                                Log.d("--isDayPassed--", "isDayPassed: platinum else " + BTC_TimerPreference.isPlatinumDayPassed(BTC_OpenWheelSpinActivity.this) + "-------> total cards--" + availableSpins);
                                Log.d("--isDayPassed--", "isDayPassed: platinum else " + BTC_TimerPreference.isPlatinumDayPassed(BTC_OpenWheelSpinActivity.this) + "-------> Points--" + updatePoint);

                                binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + availableSpins);

                                ArrayList<String> result = new ArrayList<>();

                                for (Integer i : pointsList) {
                                    result.add(i.toString());
                                    binding.wheel.setItems(result);

                                }

                                binding.wheel.setOnRotationListener(new SpinningWheelView.OnRotationListener<String>() {

                                    @Override
                                    public void onRotation() {
                                        Log.d("XXXX", "On Rotation");
                                        binding.tvSpinNow.setVisibility(View.GONE);
                                    }

                                    @Override
                                    public void onStopRotation(String item) {
                                        Toast.makeText(BTC_OpenWheelSpinActivity.this, "You've got " + item + " Points", Toast.LENGTH_SHORT).show();
                                        binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + availableSpins);

                                        updatePoint = Integer.parseInt(item);

                                        editor.putInt(BTC_Constants.AVAILABLE_PLATINUM_SPINS, availableSpins);
                                        editor.apply();

                                        if (updatePoint == 0) {
                                            winCoinsDialog(updatePoint);
                                        } else {

                                            BTC_UpdatePoints updatePoints = new BTC_UpdatePoints("Platinum spin the wheel points", updatePoint, true);

                                            Call<BTC_ApiResponse> call = apiService.updateUserPoint(updatePoints);

                                            call.enqueue(new Callback<BTC_ApiResponse>() {
                                                @Override
                                                public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                                                    BTC_ApiResponse apiResponse = response.body();

                                                    Log.d("--apiResponse--", "onResponse: " + apiResponse);
                                                    winCoinsDialog(updatePoint);
                                                }

                                                @Override
                                                public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {

                                                }
                                            });
                                        }

                                    }
                                });
                            }

                        } else {
                            binding.tvTitleName.setText("Golden Spin Wheel");

                            if (BTC_TimerPreference.isGoldenDayPassed(BTC_OpenWheelSpinActivity.this)) {
                                Log.d("--isDayPassed--", "onResponse: golden isDayPassed() " + BTC_TimerPreference.isGoldenDayPassed(BTC_OpenWheelSpinActivity.this));
                                Log.d("--spin_type--", "onResponse: ");

                                BTC_SpinWheelData spinWheelData = dataArrayList.get(0);
                                pointsList = spinWheelData.getArrSpinWheelPoint();

                                availableSpins = spinWheelData.getiTotalOneDaySpin();

                                Gson gson = new Gson();
                                String json = gson.toJson(pointsList);

                                editor.putString(BTC_Constants.GOLDEN_SPIN_POINT_LIST, json);
                                editor.putInt(BTC_Constants.AVAILABLE_GOLDEN_SPINS, availableSpins);
                                editor.apply();

                                binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + availableSpins);


                                Log.w("--apiResponse--", "SpinWheelData" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));


                                ArrayList<String> result = new ArrayList<>();
                                for (Integer i : pointsList) {
                                    result.add(i.toString());
                                    binding.wheel.setItems(result);

                                }

                                binding.wheel.setOnRotationListener(new SpinningWheelView.OnRotationListener<String>() {

                                    @Override
                                    public void onRotation() {
                                        Log.d("XXXX", "On Rotation");
                                        binding.tvSpinNow.setVisibility(View.GONE);
                                    }

                                    @Override
                                    public void onStopRotation(String item) {
                                        Toast.makeText(BTC_OpenWheelSpinActivity.this, "You've got " + item + " Points", Toast.LENGTH_SHORT).show();

                                        availableSpins = sharedpreferences.getInt(BTC_Constants.AVAILABLE_GOLDEN_SPINS, availableSpins);
                                        binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + availableSpins);

                                        updatePoint = Integer.parseInt(item);

                                        if (updatePoint == 0) {
                                            winCoinsDialog(updatePoint);

                                        } else {
                                            updatePoints = new BTC_UpdatePoints("Golden spin the wheel points", updatePoint, true);


                                            Call<BTC_ApiResponse> call = apiService.updateUserPoint(updatePoints);

                                            call.enqueue(new Callback<BTC_ApiResponse>() {
                                                @Override
                                                public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                                                    BTC_ApiResponse apiResponse = response.body();

                                                    Log.d("--apiResponse--", "onResponse: " + apiResponse);
                                                    winCoinsDialog(updatePoint);
                                                }

                                                @Override
                                                public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {

                                                }
                                            });

                                        }
                                    }
                                });

                                BTC_TimerPreference.updateGoldenLastCallTime(BTC_OpenWheelSpinActivity.this);
                            } else {

                                Log.d("--isDayPassed--", "isDayPassed: golden else " + BTC_TimerPreference.isGoldenDayPassed(BTC_OpenWheelSpinActivity.this) + "-------> total cards--" + availableSpins);
                                Log.d("--isDayPassed--", "isDayPassed: golden else " + BTC_TimerPreference.isGoldenDayPassed(BTC_OpenWheelSpinActivity.this) + "-------> Points--" + updatePoint);

                                binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + availableSpins);

                                ArrayList<String> result = new ArrayList<>();

                                for (Integer i : pointsList) {
                                    result.add(i.toString());
                                    binding.wheel.setItems(result);

                                }

                                binding.wheel.setOnRotationListener(new SpinningWheelView.OnRotationListener<String>() {

                                    @Override
                                    public void onRotation() {
                                        Log.d("XXXX", "On Rotation");
                                        binding.tvSpinNow.setVisibility(View.GONE);
                                    }

                                    @Override
                                    public void onStopRotation(String item) {
                                        Toast.makeText(BTC_OpenWheelSpinActivity.this, "You've got " + item + " Points", Toast.LENGTH_SHORT).show();

                                        binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + availableSpins);

                                        updatePoint = Integer.parseInt(item);

                                        editor.putInt(BTC_Constants.AVAILABLE_GOLDEN_SPINS, availableSpins);
                                        editor.apply();

                                        if (updatePoint == 0) {
                                            winCoinsDialog(updatePoint);
                                        } else {

                                            BTC_UpdatePoints updatePoints = new BTC_UpdatePoints("Golden spin the wheel points", updatePoint, true);

                                            Call<BTC_ApiResponse> call = apiService.updateUserPoint(updatePoints);

                                            call.enqueue(new Callback<BTC_ApiResponse>() {
                                                @Override
                                                public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                                                    BTC_ApiResponse apiResponse = response.body();

                                                    Log.d("--apiResponse--", "onResponse: " + apiResponse);

                                                    winCoinsDialog(updatePoint);

                                                }

                                                @Override
                                                public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {

                                                }
                                            });
                                        }

                                    }
                                });
                            }
                        }
                    }

                    binding.wheel.setEnabled(false);

                    binding.tvSpinNow.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (spin_type.equals("silver")) {
                                if (availableSpins >= 1) {
                                    if (!isSpinning) {

                                        Random random = new Random();
                                        int randomSeconds = random.nextInt(5000) + 1000;
                                        binding.wheel.rotate(50, randomSeconds, 50);

                                        availableSpins--;

                                        SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
                                        SharedPreferences.Editor editor = sharedPreferences.edit();
                                        editor.putInt(BTC_Constants.AVAILABLE_SILVER_SPINS, availableSpins);
                                        editor.apply();

                                        binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + availableSpins);

                                        isSpinning = true;
                                    }
                                } else {
                                    Toast.makeText(BTC_OpenWheelSpinActivity.this, "Insufficient points to spin", Toast.LENGTH_SHORT).show();
                                }
                            } else if (spin_type.equals("platinum")) {
                                if (availableSpins >= 1) {
                                    if (!isSpinning) {

                                        Random random = new Random();
                                        int randomSeconds = random.nextInt(5000) + 1000;
                                        binding.wheel.rotate(50, randomSeconds, 50);

                                        availableSpins--;

                                        SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
                                        SharedPreferences.Editor editor = sharedPreferences.edit();
                                        editor.putInt(BTC_Constants.AVAILABLE_PLATINUM_SPINS, availableSpins);
                                        editor.apply();

                                        binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + availableSpins);

                                        isSpinning = true;
                                    }
                                } else {
                                    Toast.makeText(BTC_OpenWheelSpinActivity.this, "Insufficient points to spin", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                if (availableSpins >= 1) {
                                    if (!isSpinning) {

                                        Random random = new Random();
                                        int randomSeconds = random.nextInt(5000) + 1000;
                                        binding.wheel.rotate(50, randomSeconds, 50);

                                        availableSpins--;

                                        SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
                                        SharedPreferences.Editor editor = sharedPreferences.edit();
                                        editor.putInt(BTC_Constants.AVAILABLE_GOLDEN_SPINS, availableSpins);
                                        editor.apply();

                                        binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + availableSpins);

                                        isSpinning = true;
                                    }
                                } else {
                                    Toast.makeText(BTC_OpenWheelSpinActivity.this, "Insufficient points to spin", Toast.LENGTH_SHORT).show();
                                }
                            }

                        }
                    });
                }
                Log.w("--apiResponse--", "SpinWheelData" + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));

            }

            @Override
            public void onFailure(@NonNull Call<BTC_SpinWheelResponse> call, @NonNull Throwable t) {

            }
        });
        Log.d("--spinList--", "spinList" + new Gson().toJson(dataArrayList));


        binding.tvTitleName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getOnBackPressedDispatcher().onBackPressed();
            }
        });
    }

    private void winCoinsDialog(int Satoshi) {
        Dialog dialog = new Dialog(BTC_OpenWheelSpinActivity.this);
        dialog.setContentView(R.layout.dialog_register_successful);
        dialog.setCancelable(false);
        dialog.show();

        dialog.getWindow().setLayout(-1, -2);

        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(ContextCompat.getDrawable(BTC_OpenWheelSpinActivity.this, android.R.color.transparent));


        ImageView ivCancel = dialog.findViewById(R.id.ivCancel);
        ImageView iv = dialog.findViewById(R.id.iv);
        CardView cvOk = dialog.findViewById(R.id.cvOk);
        TextView tv_description = dialog.findViewById(R.id.email_description);

        iv.setImageDrawable(getDrawable(R.drawable.img_dialog_spinwin_bg));

        if (updatePoint == 0) {
            tv_description.setText("Sorry! Better luck next time.");
        } else {
            tv_description.setText(Satoshi + " Satoshi");
        }
        ivCancel.setVisibility(View.GONE);

        cvOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_OpenWheelSpinActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        if (updatePoint == 0) {
                            getOnBackPressedDispatcher().onBackPressed();
                        } else {
                            dialog.dismiss();
                            Intent intent = new Intent(BTC_OpenWheelSpinActivity.this, BTC_HomeActivity.class);
                            startActivity(intent);
                        }
                    }
                }, MAIN_CLICK);

            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}