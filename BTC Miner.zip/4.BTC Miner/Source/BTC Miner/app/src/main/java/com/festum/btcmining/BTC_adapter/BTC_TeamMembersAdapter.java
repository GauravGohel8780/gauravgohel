package com.festum.btcmining.BTC_adapter;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.model.BTC_Referral;

import java.util.ArrayList;

public class BTC_TeamMembersAdapter extends RecyclerView.Adapter<BTC_TeamMembersAdapter.ViewHolder> {

    ArrayList<BTC_Referral> teamMemberModelArrayList;

    public BTC_TeamMembersAdapter(ArrayList<BTC_Referral> teamMemberModelArrayList) {
        this.teamMemberModelArrayList = teamMemberModelArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.team_members_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BTC_Referral referral = teamMemberModelArrayList.get(position);

        Log.d("--refferals--", "onBindViewHolder: size------" + teamMemberModelArrayList.size());

        holder.tv_member_name.setText(referral.getvEmail());
    }

    @Override
    public int getItemCount() {
        return teamMemberModelArrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView tv_member_name;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tv_member_name = itemView.findViewById(R.id.tv_member_name);
        }
    }
}
