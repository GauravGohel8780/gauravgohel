package com.festum.btcmining.BTC_api.model;

import java.util.ArrayList;

public class BTC_ParticipateData {

    public int iTotalUser;
    public boolean isDeleted;
    public String _id;
    public String vContestName;
    public String vContestType;
    public int dContestTicket;
    public int dContestPoint;
    public int dtExpiryDate;
    public long dtCreatedAt;
    public ArrayList<BTC_ArrParticipateList> arrParticipateList;
    public int __v;
    public long dtUpdatedAt;
    public boolean isUpdated;
    public ArrayList<BTC_ArrWinnerList> arrWinnerList;

    public int getiTotalUser() {
        return iTotalUser;
    }

    public void setiTotalUser(int iTotalUser) {
        this.iTotalUser = iTotalUser;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getvContestName() {
        return vContestName;
    }

    public void setvContestName(String vContestName) {
        this.vContestName = vContestName;
    }

    public String getvContestType() {
        return vContestType;
    }

    public void setvContestType(String vContestType) {
        this.vContestType = vContestType;
    }

    public int getdContestTicket() {
        return dContestTicket;
    }

    public void setdContestTicket(int dContestTicket) {
        this.dContestTicket = dContestTicket;
    }

    public int getdContestPoint() {
        return dContestPoint;
    }

    public void setdContestPoint(int dContestPoint) {
        this.dContestPoint = dContestPoint;
    }

    public int getDtExpiryDate() {
        return dtExpiryDate;
    }

    public void setDtExpiryDate(int dtExpiryDate) {
        this.dtExpiryDate = dtExpiryDate;
    }

    public long getDtCreatedAt() {
        return dtCreatedAt;
    }

    public void setDtCreatedAt(long dtCreatedAt) {
        this.dtCreatedAt = dtCreatedAt;
    }

    public ArrayList<BTC_ArrParticipateList> getArrParticipateList() {
        return arrParticipateList;
    }

    public void setArrParticipateList(ArrayList<BTC_ArrParticipateList> arrParticipateList) {
        this.arrParticipateList = arrParticipateList;
    }

    public int get__v() {
        return __v;
    }

    public void set__v(int __v) {
        this.__v = __v;
    }

    public long getDtUpdatedAt() {
        return dtUpdatedAt;
    }

    public void setDtUpdatedAt(long dtUpdatedAt) {
        this.dtUpdatedAt = dtUpdatedAt;
    }

    public boolean isUpdated() {
        return isUpdated;
    }

    public void setUpdated(boolean updated) {
        isUpdated = updated;
    }

    public ArrayList<BTC_ArrWinnerList> getArrWinnerList() {
        return arrWinnerList;
    }

    public void setArrWinnerList(ArrayList<BTC_ArrWinnerList> arrWinnerList) {
        this.arrWinnerList = arrWinnerList;
    }
}
