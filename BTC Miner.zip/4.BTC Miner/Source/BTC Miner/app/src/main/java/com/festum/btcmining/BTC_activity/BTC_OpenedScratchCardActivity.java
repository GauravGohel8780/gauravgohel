package com.festum.btcmining.BTC_activity;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.anupkumarpanwar.scratchview.ScratchView;
import com.festum.btcmining.Ads_Common.AdsBaseActivity;
import com.festum.btcmining.R;
import com.festum.btcmining.BTC_api.BTC_ApiService;
import com.festum.btcmining.BTC_api.model.BTC_ApiResponse;
import com.festum.btcmining.BTC_api.model.BTC_ScratchCardData;
import com.festum.btcmining.BTC_api.model.BTC_ScratchCardResponse;
import com.festum.btcmining.BTC_api.model.BTC_UpdatePoints;
import com.festum.btcmining.BTC_constants.BTC_Constants;
import com.festum.btcmining.databinding.ActivityOpenedScratchCardBinding;
import com.festum.btcmining.BTC_preference.BTC_TimerPreference;
import com.google.gson.GsonBuilder;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BTC_OpenedScratchCardActivity extends AdsBaseActivity {

    ActivityOpenedScratchCardBinding binding;

    String scratch_type;
    int totalCards;
    int scratchedPoints;
    SharedPreferences sharedpreferences;
    String userToken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        binding = ActivityOpenedScratchCardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ScratchView scratchView = findViewById(R.id.scratch_view);

        scratch_type = getIntent().getStringExtra("scratch_type");

        binding.tvGotPoints.setVisibility(View.VISIBLE);

        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(BTC_OpenedScratchCardActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });


        binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + totalCards);

        sharedpreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, Context.MODE_PRIVATE);
        userToken = sharedpreferences.getString(BTC_Constants.USER_TOKEN, "");
        scratchedPoints = sharedpreferences.getInt(BTC_Constants.GET_SCRATCH_POINTS, 0);

        totalCards = sharedpreferences.getInt(BTC_Constants.AVAILABLE_CARDS, 5);

        binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + totalCards);

        Log.d("--isDayPassed--", "onCreate: total cards" + totalCards);

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @NotNull
            @Override
            public okhttp3.Response intercept(@NotNull Interceptor.Chain chain) throws IOException {
                Request original = chain.request();
                Request.Builder requestBuilder = original.newBuilder()
                        .header("Authorization", "Bearer " + userToken)
                        .method(original.method(), original.body());

                Request request = requestBuilder.build();

                Log.d("--apiResponse--", "URL: " + request.url());
                Log.d("--apiResponse--", "Headers: " + request.headers());
                Log.d("--apiResponse--", "Body: " + request.body());

                return chain.proceed(request);
            }
        });

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BTC_Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        BTC_ApiService apiService = retrofit.create(BTC_ApiService.class);

        Call<BTC_ScratchCardResponse> call = apiService.scratchCardList();

        if (scratch_type != null) {

            if (scratch_type.equals("silver")) {

                call.enqueue(new Callback<BTC_ScratchCardResponse>() {
                    @Override
                    public void onResponse(@NonNull Call<BTC_ScratchCardResponse> call, @NonNull Response<BTC_ScratchCardResponse> response) {
                        BTC_ScratchCardResponse apiResponse = response.body();

                        if (response.isSuccessful()) {
                            ArrayList<BTC_ScratchCardData> scratchCardData = apiResponse.getData();
                            BTC_ScratchCardData cardData1 = scratchCardData.get(0);
                            binding.tvGotPoints.setText(cardData1.iScratchCardPoint + "Points");
                            Log.d("--isDayPassed--", "onResponse: " + BTC_TimerPreference.isScratchDayPassed(BTC_OpenedScratchCardActivity.this));


                            Dialog dialog = new Dialog(BTC_OpenedScratchCardActivity.this, R.style.customDialog);

                            dialog.setContentView(R.layout.dialog_quiz_result);

                            dialog.getWindow().setLayout(-1, -2);

                            Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(ContextCompat.getDrawable(BTC_OpenedScratchCardActivity.this, android.R.color.transparent));


                            ImageView ivQuiz = dialog.findViewById(R.id.ivQuiz);
                            TextView tvDitail = dialog.findViewById(R.id.tvDitail);
                            TextView tvBtnText = dialog.findViewById(R.id.tvBtnText);

                            ivQuiz.setImageDrawable(getDrawable(R.drawable.img_dialog_spinwin_bg));
                            tvBtnText.setText("Collect");

                            dialog.setCancelable(false);

                            if (BTC_TimerPreference.isScratchDayPassed(BTC_OpenedScratchCardActivity.this)) {
                                if (apiResponse != null) {


                                    SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
                                    SharedPreferences.Editor editor = sharedPreferences.edit();


                                    if (scratch_type.equals("silver")) {
                                        Log.d("--spin_type--", "onResponse: ");

                                        BTC_ScratchCardData cardData = scratchCardData.get(0);

                                        Log.w("--apiResponse--", "ScratchCard data-------> " + new GsonBuilder().setPrettyPrinting().create().toJson(apiResponse));

                                        totalCards = cardData.getiTotalOneDayScratch();
                                        editor.putInt(BTC_Constants.AVAILABLE_CARDS, totalCards);
                                        editor.putInt(BTC_Constants.GET_SCRATCH_POINTS, cardData.getiScratchCardPoint());
                                        editor.apply();

                                        Log.d("--isDayPassed--", "onResponse: " + BTC_TimerPreference.isScratchDayPassed(BTC_OpenedScratchCardActivity.this) + "-------> total cards--" + totalCards);

                                        binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + totalCards);

                                        binding.tvGotPoints.setText(cardData.iScratchCardPoint + "Points");
                                        scratchView.setVisibility(View.VISIBLE);

                                        scratchView.setRevealListener(new ScratchView
                                                .IRevealListener() {
                                            @Override
                                            public void onRevealed(ScratchView scratchView) {
                                                Toast.makeText(BTC_OpenedScratchCardActivity.this,
                                                        "Revealed!", Toast.LENGTH_SHORT).show();


                                                totalCards--;

                                                SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
                                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                                editor.putInt(BTC_Constants.AVAILABLE_CARDS, totalCards);
                                                editor.apply();

                                                binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + totalCards);

                                                tvDitail.setText("You've got " + scratchCardData.get(0).getiScratchCardPoint());
                                                dialog.show();

                                                dialog.findViewById(R.id.cvButton).setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View v) {


                                                        BTC_UpdatePoints updatePoints = new BTC_UpdatePoints("Silver Scratch the card points", cardData.getiScratchCardPoint(), true);

                                                        Call<BTC_ApiResponse> callPoints = apiService.updateUserPoint(updatePoints);

                                                        callPoints.enqueue(new Callback<BTC_ApiResponse>() {
                                                            @Override
                                                            public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                                                                BTC_ApiResponse apiResponse = response.body();

                                                                Log.d("--apiResponse--", "onResponse: " + apiResponse);
                                                                dialog.dismiss();

                                                                getInstance(BTC_OpenedScratchCardActivity.this).ShowAd(new HandleClick() {
                                                                    @Override
                                                                    public void Show(boolean adShow) {
                                                                        Intent intent = new Intent(BTC_OpenedScratchCardActivity.this, BTC_HomeActivity.class);
                                                                        startActivity(intent);
                                                                    }
                                                                }, MAIN_CLICK);
                                                            }

                                                            @Override
                                                            public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {

                                                            }
                                                        });

                                                    }
                                                });

                                            }

                                            @Override
                                            public void onRevealPercentChangedListener
                                                    (ScratchView scratchView, float percent) {
                                                Log.d("Revealed", String.valueOf(percent));

                                            }
                                        });


                                    }
                                }
                                BTC_TimerPreference.updateScratchLastCallTime(BTC_OpenedScratchCardActivity.this);
                            } else {
                                Log.d("--isDayPassed--", "isDayPassed: else " + BTC_TimerPreference.isScratchDayPassed(BTC_OpenedScratchCardActivity.this) + "-------> total cards--" + totalCards);
                                Log.d("--isDayPassed--", "isDayPassed: else " + BTC_TimerPreference.isScratchDayPassed(BTC_OpenedScratchCardActivity.this) + "-------> Points--" + scratchedPoints);

                                if (totalCards >= 1) {
                                    scratchView.setVisibility(View.VISIBLE);
                                    scratchView.setRevealListener(new ScratchView.IRevealListener() {
                                        @Override
                                        public void onRevealed(ScratchView scratchView) {

                                            totalCards--;

                                            SharedPreferences sharedPreferences = getSharedPreferences(BTC_Constants.SHARED_PREFS, MODE_PRIVATE);
                                            SharedPreferences.Editor editor = sharedPreferences.edit();
                                            editor.putInt(BTC_Constants.AVAILABLE_CARDS, totalCards);
                                            editor.apply();

                                            binding.tvAvailableSpins.setText("Your Today Spin Wheel Count Left = " + totalCards);
                                            tvDitail.setText("You've got " + scratchedPoints + " Points");
                                            binding.tvGotPoints.setText(scratchedPoints + "Points");

                                            dialog.show();

                                            dialog.findViewById(R.id.cvButton).setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View v) {
                                                    BTC_UpdatePoints updatePoints = new BTC_UpdatePoints("Silver Scratch the card points", scratchedPoints, true);

                                                    Call<BTC_ApiResponse> callPoints = apiService.updateUserPoint(updatePoints);

                                                    callPoints.enqueue(new Callback<BTC_ApiResponse>() {
                                                        @Override
                                                        public void onResponse(@NonNull Call<BTC_ApiResponse> call, @NonNull Response<BTC_ApiResponse> response) {
                                                            BTC_ApiResponse apiResponse = response.body();

                                                            Log.d("--apiResponse--", "onResponse: " + apiResponse);
                                                            dialog.dismiss();

                                                            getInstance(BTC_OpenedScratchCardActivity.this).ShowAd(new HandleClick() {
                                                                @Override
                                                                public void Show(boolean adShow) {
                                                                    Intent intent = new Intent(BTC_OpenedScratchCardActivity.this, BTC_HomeActivity.class);
                                                                    startActivity(intent);
                                                                }
                                                            }, MAIN_CLICK);
                                                        }

                                                        @Override
                                                        public void onFailure(@NonNull Call<BTC_ApiResponse> call, @NonNull Throwable t) {

                                                        }
                                                    });
                                                }
                                            });

                                        }

                                        @Override
                                        public void onRevealPercentChangedListener(ScratchView scratchView, float percent) {

                                        }
                                    });
                                } else {

                                    binding.tvGotPoints.setText("Insufficient scrach cards.");

                                    scratchView.setVisibility(View.GONE);

                                }
                            }
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<BTC_ScratchCardResponse> call, @NonNull Throwable t) {

                    }
                });
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}