package com.festum.btcmining.BTC_api.model;

public class BTC_UserDetail {
    String vFirstName;
    String vLastName;
    String vCountry;
    String vGender;
    String vEmail;
    String vPassword;

    public BTC_UserDetail() {
    }

    public BTC_UserDetail(String vFirstName, String vLastName, String vCountry, String vGender) {
        this.vFirstName = vFirstName;
        this.vLastName = vLastName;
        this.vGender = vGender;
        this.vCountry = vCountry;
    }


    public BTC_UserDetail(String vFirstName, String vLastName, String vCountry, String vGender, String vEmail) {
        this.vFirstName = vFirstName;
        this.vLastName = vLastName;
        this.vCountry = vCountry;
        this.vGender = vGender;
        this.vEmail = vEmail;
    }

    public BTC_UserDetail(String vFirstName, String vLastName, String vCountry, String vGender, String email, String password) {
        this.vFirstName = vFirstName;
        this.vLastName = vLastName;
        this.vCountry = vCountry;
        this.vGender = vGender;
        this.vEmail = email;
        this.vPassword = password;
    }

    public String getvFirstName() {
        return vFirstName;
    }

    public void setvFirstName(String vFirstName) {
        this.vFirstName = vFirstName;
    }

    public String getvLastName() {
        return vLastName;
    }

    public void setvLastName(String vLastName) {
        this.vLastName = vLastName;
    }

    public String getvGender() {
        return vGender;
    }

    public void setvGender(String vGender) {
        this.vGender = vGender;
    }

    public String getvCountry() {
        return vCountry;
    }

    public void setvCountry(String vCountry) {
        this.vCountry = vCountry;
    }

    public String getPassword() {
        return vPassword;
    }

    public String getEmail() {
        return vEmail;
    }

    public void setEmail(String email) {
        this.vEmail = email;
    }

    public void setPassword(String password) {
        this.vPassword = password;
    }
}
