package com.festum.btcmining.BTC_api.model;

import java.util.ArrayList;

public class BTC_WinnersHistoryResponse {

    public int iStatusCode;
    public boolean isStatus;
    public int iCount;
    public ArrayList<BTC_WinnersData> data;
    public String vMessage;

    public int getiStatusCode() {
        return iStatusCode;
    }

    public void setiStatusCode(int iStatusCode) {
        this.iStatusCode = iStatusCode;
    }

    public boolean isStatus() {
        return isStatus;
    }

    public void setStatus(boolean status) {
        isStatus = status;
    }

    public int getiCount() {
        return iCount;
    }

    public void setiCount(int iCount) {
        this.iCount = iCount;
    }

    public ArrayList<BTC_WinnersData> getData() {
        return data;
    }

    public void setData(ArrayList<BTC_WinnersData> data) {
        this.data = data;
    }

    public String getvMessage() {
        return vMessage;
    }

    public void setvMessage(String vMessage) {
        this.vMessage = vMessage;
    }
}
