package com.videoplayer.galley.allgame.VideoDownloader.Facebook;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Random;

/* loaded from: classes4.dex */
public class DownloadLinkHandeler {
    Context context;
    Functions functions;
    String tag = "downloader_";
    String deUrl = "";
    Handler handler = new Handler(Looper.getMainLooper());
    Random random = new Random();

    public DownloadLinkHandeler(Context context) {
        this.context = context;
        this.functions = new Functions(context);
    }

    public void generateLinks(final String url) {
        new Thread(new Runnable() { // from class: com.lunarday.fbstorydownloader.networklogics.DownloadLinkHandeler.1
            @Override // java.lang.Runnable
            public void run() {
                try {
                    DownloadLinkHandeler.this.g(url);
                } catch (JSONException e2) {
                    DownloadLinkHandeler.this.handler.post(new Runnable() { // from class: com.lunarday.fbstorydownloader.networklogics.DownloadLinkHandeler.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            Toast.makeText(DownloadLinkHandeler.this.context, "Something went wrong", 0).show();
                        }
                    });
                    e2.printStackTrace();
                }
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void g(String url) throws JSONException {
        JSONObject jSONObject = new JSONObject();
        String sourceCodeWeb = this.functions.getSourceCodeWeb(url.replace("https://m.", "https://www.").replace("https://mbasic.", "https://www."));
        JSONObject jSONObject2 = new JSONObject();
        int i = 0;
        try {
            int indexOf = sourceCodeWeb.indexOf("playable_url\"") + 15;
            int indexOf2 = sourceCodeWeb.indexOf("\"", indexOf);
            Log.i(this.tag, sourceCodeWeb);
            String replaceAll = sourceCodeWeb.substring(indexOf, indexOf2).replaceAll("\\\\/", "/").replaceAll("\\\\u0025", "%");
            Log.i("sd_link", sourceCodeWeb.substring(indexOf, indexOf + 500));
            if (isValidLink(replaceAll)) {
                String fileSize = getFileSize(replaceAll);
                jSONObject2.put("link", replaceAll);
                jSONObject2.put("size", fileSize);
                i = 1;
            }
        } catch (Exception e2) {
            e2.printStackTrace();
            jSONObject2 = new JSONObject();
        }
        jSONObject.put("sd", jSONObject2);
        JSONObject jSONObject3 = new JSONObject();
        try {
            int indexOf3 = sourceCodeWeb.indexOf("playable_url_quality_hd\":\"") + 26;
            String replaceAll2 = sourceCodeWeb.substring(indexOf3, sourceCodeWeb.indexOf("\"", indexOf3)).replaceAll("\\\\/", "/").replaceAll("\\\\u0025", "%");
            Log.i("hd_link", replaceAll2);
            if (isValidLink(replaceAll2)) {
                jSONObject3.put("link", replaceAll2);
                jSONObject3.put("size", getFileSize(replaceAll2));
                i++;
            }
        } catch (Exception unused) {
            jSONObject3 = new JSONObject();
        }
        jSONObject.put("hd", jSONObject3);
        if (i == 0) {
            if (!new Pref(this.context).isFbLoogedin()) {
                Log.i("tag__", "you have to login");
                EventBus.getDefault().post("private post");
                return;
            }
            this.handler.post(new Runnable() { // from class: com.lunarday.fbstorydownloader.networklogics.DownloadLinkHandeler.2
                @Override // java.lang.Runnable
                public void run() {
                    Toast.makeText(DownloadLinkHandeler.this.context, "Link broken", 0).show();
                    ((Activity) DownloadLinkHandeler.this.context).finish();
                }
            });
            return;
        }
        EventBus.getDefault().post(jSONObject);
    }

    String getFileSize(String url) {
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(url).openConnection();
            httpURLConnection.connect();
            return this.functions.humanReadableByteCountBin(httpURLConnection.getContentLength());
        } catch (IOException e2) {
            e2.printStackTrace();
            return "Unknown";
        }
    }

    boolean isValidLink(String link) {
        return link.contains("https") && !link.contains(" ");
    }
}
