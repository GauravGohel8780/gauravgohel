package com.videoplayer.galley.allgame.AdsDemo;

import android.app.Application;

import com.onesignal.OneSignal;

public class MyApplication extends Application {

    public static AppOpenManager appOpenManager;

    private static final String ONESIGNAL_APP_ID = "25602761-f2f2-4804-982b-4d19388b2214";

    public void onCreate() {
        super.onCreate();

        if (SharedPrefs.getAdsShow(this).equals("yes")) {
            appOpenManager = new AppOpenManager(this, this);
        }

        OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);
        OneSignal.initWithContext(this);
        OneSignal.setAppId(ONESIGNAL_APP_ID);
        OneSignal.promptForPushNotifications();
    }
}
