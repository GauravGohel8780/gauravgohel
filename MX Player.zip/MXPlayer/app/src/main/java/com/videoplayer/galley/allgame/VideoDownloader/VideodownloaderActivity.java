package com.videoplayer.galley.allgame.VideoDownloader;




import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.LinearLayout;


import com.videoplayer.galley.allgame.AdsDemo.Intertials;
import com.videoplayer.galley.allgame.AdsDemo.Native;
import com.videoplayer.galley.allgame.R;
import com.videoplayer.galley.allgame.VideoDownloader.Facebook.FasebookActivity;
import com.videoplayer.galley.allgame.VideoDownloader.Instagram.InstagramActivity;
import com.videoplayer.galley.allgame.VideoDownloader.twitter.TwitterActivity;
import com.videoplayer.galley.allgame.VideoDownloader.whatsapp.WhatsappActivity;

public class VideodownloaderActivity extends AppCompatActivity {

    LinearLayout cardwapp, cardtwitter, instagramicon, facebookcard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videodownloader);
        new Native().shownativeads(this, findViewById(R.id.native_container));
        cardwapp = findViewById(R.id.cardwapp);
        cardtwitter = findViewById(R.id.cardtwitter);
        instagramicon = findViewById(R.id.instagramicon);
        facebookcard = findViewById(R.id.facebookcard);

        cardwapp.setOnClickListener(view -> {
            new Intertials().ShowIntertistialAds(this, new Intertials.OnIntertistialAdsListner() {
                public void onAdsDismissed() {
                    startActivity(new Intent(VideodownloaderActivity.this, WhatsappActivity.class));
                }
            });
        });
        cardtwitter.setOnClickListener(view -> {
            new Intertials().ShowIntertistialAds(this, new Intertials.OnIntertistialAdsListner() {
                public void onAdsDismissed() {
                    startActivity(new Intent(VideodownloaderActivity.this, TwitterActivity.class));
                }
            });
        });
        instagramicon.setOnClickListener(view -> {
            new Intertials().ShowIntertistialAds(this, new Intertials.OnIntertistialAdsListner() {
                public void onAdsDismissed() {
                    startActivity(new Intent(VideodownloaderActivity.this, InstagramActivity.class));
                }
            });
        });
        facebookcard.setOnClickListener(view -> {
            new Intertials().ShowIntertistialAds(this, new Intertials.OnIntertistialAdsListner() {
                public void onAdsDismissed() {
                    startActivity(new Intent(VideodownloaderActivity.this, FasebookActivity.class));
                }
            });
        });
    }
}