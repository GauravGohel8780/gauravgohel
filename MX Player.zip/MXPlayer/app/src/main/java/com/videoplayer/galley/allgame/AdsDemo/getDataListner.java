package com.videoplayer.galley.allgame.AdsDemo;

public interface getDataListner {
    void onSuccess();

}
