package com.videoplayer.galley.allgame.Language;


import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.videoplayer.galley.allgame.AdsDemo.Banner;
import com.videoplayer.galley.allgame.AdsDemo.SharedPrefs;
import com.videoplayer.galley.allgame.R;

import java.util.ArrayList;
import java.util.Arrays;

public class LanguageActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList<Model> courseName;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);
        new Banner().showbannerads(this, findViewById(R.id.banner_container));

        courseName = new ArrayList<>();

        courseName.add(new Model("English", "A"));
        courseName.add(new Model("বাংলা", "ক"));
        courseName.add(new Model("Gujrati", "એ"));
        courseName.add(new Model("हिंदी", "ए"));
        courseName.add(new Model("Indonesia", "I"));
        courseName.add(new Model("Española", "E"));
        courseName.add(new Model("ไทย", "ไ"));
        courseName.add(new Model("français", "f"));
        courseName.add(new Model("Portuguese", "P"));
        courseName.add(new Model("русский", "р"));
        courseName.add(new Model("Malayu", "M"));
        courseName.add(new Model("Română", "R"));
        courseName.add(new Model("italiano", "i"));
        courseName.add(new Model("中国", "中"));
        courseName.add(new Model("Filipino", "F"));
        courseName.add(new Model("Deutsche", "D"));
        courseName.add(new Model("Afrikaans", "A"));
        courseName.add(new Model("日本語", "日"));
        courseName.add(new Model("मराठी", "म"));
        courseName.add(new Model("Kiswahili", "K"));
        courseName.add(new Model("IsiZulu", "I"));
        courseName.add(new Model("עברית", "ת"));
        courseName.add(new Model("한국어", "한"));
        courseName.add(new Model("čeština", "č"));
        courseName.add(new Model("Polskie", "P"));
        courseName.add(new Model("Ελληνικά", "Ε"));
        courseName.add(new Model("Magyar", "M"));
        courseName.add(new Model("Nederlands", "N"));
        courseName.add(new Model("Türkçe", "T"));
        courseName.add(new Model("українська", "у"));
        courseName.add(new Model("svenska", "s"));
        courseName.add(new Model("Tiếng Việt", "T"));

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(linearLayoutManager);
        Adapter adapter = new Adapter(this, courseName);
        recyclerView.setAdapter(adapter);
    }
}