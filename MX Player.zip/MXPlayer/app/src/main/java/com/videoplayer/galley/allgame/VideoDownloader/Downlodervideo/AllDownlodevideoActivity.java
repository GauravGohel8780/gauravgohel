package com.videoplayer.galley.allgame.VideoDownloader.Downlodervideo;




import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.ViewGroup;

import com.google.android.material.tabs.TabLayout;

import com.videoplayer.galley.allgame.AdsDemo.Banner;
import com.videoplayer.galley.allgame.R;
import com.videoplayer.galley.allgame.VideoDownloader.Instagram.InsFrag;
import com.videoplayer.galley.allgame.VideoDownloader.twitter.TWFrag;

public class AllDownlodevideoActivity extends AppCompatActivity {

    private ViewPagerAdapter viewPagerAdapter;
    private ViewPager viewPager;
    private TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_downlodevideo);
        new Banner().showbannerads(this, findViewById(R.id.banner_container));
        viewPager = findViewById(R.id.viewpager);

        // setting up the adapter
        viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());

        // add the fragments
        viewPagerAdapter.add(new InsFrag(), "Instagram");
        viewPagerAdapter.add(new TWFrag(), "Twitter");

        // Set the adapter
        viewPager.setAdapter(viewPagerAdapter);

        // The Page (fragment) titles will be displayed in the
        // tabLayout hence we need to  set the page viewer
        // we use the setupWithViewPager().
        tabLayout = findViewById(R.id.tab_layout);
        tabLayout.setupWithViewPager(viewPager);
    }
}