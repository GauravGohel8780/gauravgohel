package com.videoplayer.galley.allgame;




import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;


import com.videoplayer.galley.allgame.AdsDemo.First_User_EnterDiloge;
import com.videoplayer.galley.allgame.AdsDemo.Intertials;
import com.videoplayer.galley.allgame.AdsDemo.Native;
import com.videoplayer.galley.allgame.AdsDemo.RateUsDialog;

public class PhotoGalleryActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_RUNNER = 123;
    LinearLayout startbtn;

    Dialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_gallery);

        new First_User_EnterDiloge(this).FirstTimeDilog();

        if (Build.VERSION.SDK_INT >= 33) {
            if (!(ActivityCompat.checkSelfPermission(PhotoGalleryActivity.this, "android.permission.READ_MEDIA_VIDEO") == 0 && ActivityCompat.checkSelfPermission(PhotoGalleryActivity.this, "android.permission.READ_MEDIA_IMAGES") == 0 || ActivityCompat.checkSelfPermission(PhotoGalleryActivity.this, "android.permission.READ_MEDIA_AUDIO") == 0) && !(ActivityCompat.checkSelfPermission(PhotoGalleryActivity.this, "android.permission.READ_EXTERNAL_STORAGE") == 0)) {
                ActivityCompat.requestPermissions(PhotoGalleryActivity.this, new String[]{"android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_AUDIO"},
                        REQUEST_CODE_RUNNER);
            }
        } else {
            if (ContextCompat.checkSelfPermission(PhotoGalleryActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(PhotoGalleryActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        REQUEST_CODE_RUNNER);
            }
        }

        startbtn = findViewById(R.id.startbtn);

        startbtn.setOnClickListener(view -> {

            new Intertials().ShowIntertistialAds(this, new Intertials.OnIntertistialAdsListner() {
                public void onAdsDismissed() {
                    startActivity(new Intent(PhotoGalleryActivity.this, VideoPlayerActivity.class));
                }
            });
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_RUNNER) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                permissiondialog();
            }
        }
    }

    private void permissiondialog() {
        dialog = new Dialog(this);
        dialog.setContentView(R.layout.dillog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setCancelable(false);
        Window window = dialog.getWindow();
        WindowManager.LayoutParams attributes = window.getAttributes();
        attributes.gravity = Gravity.CENTER;
        window.setAttributes(attributes);
        dialog.show();

        Button btnp = dialog.findViewById(R.id.btntry);
        btnp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });
    }

    private boolean checkWriteExternalPermission() {
        String permission = Manifest.permission.WRITE_EXTERNAL_STORAGE;
        int res = checkCallingOrSelfPermission(permission);
        return (res == PackageManager.PERMISSION_GRANTED);
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkWriteExternalPermission();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        new RateUsDialog(this).ShowRateUsDialog();
    }
}