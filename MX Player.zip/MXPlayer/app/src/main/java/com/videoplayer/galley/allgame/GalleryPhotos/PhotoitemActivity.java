package com.videoplayer.galley.allgame.GalleryPhotos;





import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.videoplayer.galley.allgame.AdsDemo.Banner;
import com.videoplayer.galley.allgame.AdsDemo.Intertials;
import com.videoplayer.galley.allgame.R;

import java.util.ArrayList;

public class PhotoitemActivity extends AppCompatActivity implements galleryitemClickListener {

    RecyclerView recyclerView;
    ArrayList<PhotoItemModel> model = new ArrayList<>();
    String foldePath;
    TextView foldername;

    PhotoItemAdapter adapter;
    int po;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photoitem);
        new Banner().showbannerads(this, findViewById(R.id.banner_container));
        foldername = findViewById(R.id.foldername);
        foldername.setText(getIntent().getStringExtra("foldername"));

        foldePath = getIntent().getStringExtra("folderPath");

        recyclerView = findViewById(R.id.rvphotoitem);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 3));

    }


    public ArrayList<PhotoItemModel> getAllImagesByFolder(String path) {
        ArrayList<PhotoItemModel> images = new ArrayList<>();
        Uri allVideosuri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Images.ImageColumns.DATA,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.SIZE};
        Cursor cursor = PhotoitemActivity.this.getContentResolver().query(allVideosuri, projection, MediaStore.Images.Media.DATA + " like ? ", new String[]{"%" + path + "%"}, null);
        try {
            cursor.moveToFirst();
            do {
                PhotoItemModel pic = new PhotoItemModel();

                pic.setPicturName(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)));

                pic.setPicturePath(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)));

                pic.setPictureSize(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)));

                images.add(pic);
            } while (cursor.moveToNext());
            cursor.close();
            ArrayList<PhotoItemModel> reSelection = new ArrayList<>();
            for (int i = images.size() - 1; i > -1; i--) {
                reSelection.add(images.get(i));
            }
            images = reSelection;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return images;
    }

    @Override
    public void onPicClicked(PhotoItemAdapter.PicHolder holder, int position, ArrayList<PhotoItemModel> pics) {
        new Intertials().ShowIntertistialAds(this, new Intertials.OnIntertistialAdsListner() {
            public void onAdsDismissed() {
                po = holder.getAdapterPosition();
                Intent intent = new Intent(PhotoitemActivity.this, PhotoviewPagerActivity.class);
                Bundle args = new Bundle();
                args.putParcelableArrayList("arrayP", model);
                intent.putExtra("po", String.valueOf(po));
                intent.putExtras(args);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onPicClicked(String pictureFolderPath, String folderName) {

    }

    public void back(View view) {
        onBackPressed();
    }

    @Override
    protected void onResume() {
        model = getAllImagesByFolder(foldePath);
        adapter = new PhotoItemAdapter(model, PhotoitemActivity.this, PhotoitemActivity.this);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        super.onResume();
    }
}