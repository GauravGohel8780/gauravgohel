package com.videoplayer.galley.allgame;


import android.content.Intent;
import android.os.Bundle;
import android.service.notification.StatusBarNotification;
import android.view.accessibility.AccessibilityEvent;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;

import com.videoplayer.galley.allgame.AdsDemo.Intertials;
import com.videoplayer.galley.allgame.AdsDemo.Native;
import com.videoplayer.galley.allgame.GalleryPhotos.PhotosActivity;
import com.videoplayer.galley.allgame.Language.AppCompat;
import com.videoplayer.galley.allgame.Language.LanguageActivity;
import com.videoplayer.galley.allgame.PlayGame.GamesActivity;
import com.videoplayer.galley.allgame.VideoDownloader.VideodownloaderActivity;
import com.videoplayer.galley.allgame.VideoPlayer.VideoPlayerActivity;


public class MainActivity extends AppCompat {

    CardView galleryphoto, playgame, videoplayer, videodownloader;
    ImageView languageimg;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        new Native().shownativeads(this, findViewById(R.id.native_container));

        galleryphoto = findViewById(R.id.galleryphoto);
        playgame = findViewById(R.id.playgame);
        videoplayer = findViewById(R.id.videoplayer);
        videodownloader = findViewById(R.id.videodownloader);
        languageimg = findViewById(R.id.languageimg);

        galleryphoto.setOnClickListener(view -> {
            new Intertials().ShowIntertistialAds(this, new Intertials.OnIntertistialAdsListner() {
                public void onAdsDismissed() {
                    startActivity(new Intent(MainActivity.this, PhotosActivity.class));
                }
            });
        });
        playgame.setOnClickListener(view -> {
            new Intertials().ShowIntertistialAds(this, new Intertials.OnIntertistialAdsListner() {
                public void onAdsDismissed() {
                    startActivity(new Intent(MainActivity.this, GamesActivity.class));
                }
            });
        });
        videoplayer.setOnClickListener(view -> {
            new Intertials().ShowIntertistialAds(this, new Intertials.OnIntertistialAdsListner() {
                public void onAdsDismissed() {
                    startActivity(new Intent(MainActivity.this, VideoPlayerActivity.class));
                }
            });
        });
        videodownloader.setOnClickListener(view -> {
            new Intertials().ShowIntertistialAds(this, new Intertials.OnIntertistialAdsListner() {
                public void onAdsDismissed() {
                    startActivity(new Intent(MainActivity.this, VideodownloaderActivity.class));
                }
            });
        });
        languageimg.setOnClickListener(view -> {
            new Intertials().ShowIntertistialAds(this, new Intertials.OnIntertistialAdsListner() {
                public void onAdsDismissed() {
                    startActivity(new Intent(MainActivity.this, LanguageActivity.class));
                }
            });
        });
    }



    @Override
    public void onBackPressed() {
            super.onBackPressed();

    }
}