package com.videoplayer.galley.allgame.PlayGame;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class ChildModelClass implements Parcelable {

    String image;
    String url;
    String appname;


    public ChildModelClass(String image, String url, String appname) {
        this.image = image;
        this.url = url;
        this.appname = appname;
    }

    protected ChildModelClass(Parcel in) {
        image = in.readString();
        url = in.readString();
        appname = in.readString();
    }

    public static final Creator<ChildModelClass> CREATOR = new Creator<ChildModelClass>() {
        @Override
        public ChildModelClass createFromParcel(Parcel in) {
            return new ChildModelClass(in);
        }

        @Override
        public ChildModelClass[] newArray(int size) {
            return new ChildModelClass[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(image);
        parcel.writeString(url);
        parcel.writeString(appname);
    }
}
