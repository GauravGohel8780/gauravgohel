package com.videoplayer.galley.allgame.AdsDemo;

import android.app.Activity;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdListener;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.facebook.ads.AudienceNetworkAds;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.videoplayer.galley.allgame.R;

public class Banner {

    public static Dialog dialog;
    public static String bannerid;
    public static String fbbannerid;
    public static BroadcastReceiver broadcastReceiver;

    public void showbannerads(final Activity activity, final ViewGroup viewGroup) {

        if (SharedPrefs.getInternetDilog(activity).equals("yes")){
            broadcastReceiver = new NetworkChangeListener();
            activity.registerReceiver(broadcastReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        }
        if (SharedPrefs.getAdsShow(activity).equals("yes")){
            dialog = new Dialog(activity);
            View view = LayoutInflater.from(activity).inflate(R.layout.ads_loading, null);
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.setContentView(view);
            dialog.setCancelable(false);
            Window window = dialog.getWindow();
            window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);


            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!dialog.isShowing()) {
                        dialog.show();
                    }
                }
            }, 100);

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    dialog.dismiss();
                }
            }, 5000);

            if (SharedPrefs.getbanneriduse(activity) == 0) {
                SharedPrefs.setbanneriduse(activity, 1);
                bannerid = SharedPrefs.getapp_bannerid(activity);
            } else if (SharedPrefs.getbanneriduse(activity) == 1) {
                SharedPrefs.setbanneriduse(activity, 0);
                bannerid = SharedPrefs.getapp_bannerid1(activity);
            }
            fbbannerid = SharedPrefs.getapp_fbbannerid(activity);

            if (SharedPrefs.getbannerSpecific(activity) == 0) {
                bannerads(activity, viewGroup);
            } else if (SharedPrefs.getbannerSpecific(activity) == 1) {
                admobbannerads(activity, viewGroup);
            } else if (SharedPrefs.getbannerSpecific(activity) == 2) {
                fbbanner(activity, viewGroup);
            }
        }
    }


    public void bannerads(final Activity activity, final ViewGroup viewGroup) {

        if (SharedPrefs.getbanneradsequence(activity) == 0) {
            final com.google.android.gms.ads.AdView adView = new com.google.android.gms.ads.AdView(activity);
            adView.setAdSize(com.google.android.gms.ads.AdSize.BANNER);
            adView.setAdUnitId(bannerid);
            adView.loadAd(new AdRequest.Builder().build());

            adView.setAdListener(new com.google.android.gms.ads.AdListener() {
                @Override
                public void onAdLoaded() {
                    super.onAdLoaded();
                    viewGroup.removeAllViews();
                    viewGroup.addView(adView);
                    dialog.dismiss();
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    super.onAdFailedToLoad(loadAdError);
                    fbbanner(activity, viewGroup);
                }
            });
        } else if (SharedPrefs.getbanneradsequence(activity) == 1) {
            AudienceNetworkAds.initialize(activity);
            AdListener adListener = new AdListener() {
                @Override
                public void onError(Ad ad, AdError adError) {
                    admobbannerads(activity, viewGroup);
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    dialog.dismiss();
                }

                @Override
                public void onAdClicked(Ad ad) {
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                }
            };
            AdView adView = new AdView(activity, fbbannerid, AdSize.BANNER_HEIGHT_50);
            viewGroup.addView(adView);
            adView.loadAd(adView.buildLoadAdConfig().withAdListener(adListener).build());
        }
    }


    public void admobbannerads(final Activity activity, final ViewGroup viewGroup) {
        final com.google.android.gms.ads.AdView adView = new com.google.android.gms.ads.AdView(activity);
        adView.setAdSize(com.google.android.gms.ads.AdSize.BANNER);
        adView.setAdUnitId(bannerid);
        adView.loadAd(new AdRequest.Builder().build());

        adView.setAdListener(new com.google.android.gms.ads.AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                viewGroup.removeAllViews();
                viewGroup.addView(adView);
                dialog.dismiss();
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                dialog.dismiss();
            }
        });
    }

    public void fbbanner(Activity activity, ViewGroup viewGroup) {
        AudienceNetworkAds.initialize(activity);
        AdListener adListener = new AdListener() {
            @Override
            public void onError(Ad ad, AdError adError) {
                dialog.dismiss();
            }

            @Override
            public void onAdLoaded(Ad ad) {
                dialog.dismiss();
            }

            @Override
            public void onAdClicked(Ad ad) {
            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        };
        AdView adView = new AdView(activity, fbbannerid, AdSize.BANNER_HEIGHT_50);
        viewGroup.addView(adView);
        adView.loadAd(adView.buildLoadAdConfig().withAdListener(adListener).build());
    }
}
