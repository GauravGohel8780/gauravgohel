package com.videoplayer.galley.allgame.AdsDemo;

import android.app.Activity;
import android.app.Dialog;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.videoplayer.galley.allgame.R;

public class Intertials {

    public static com.google.android.gms.ads.interstitial.InterstitialAd ADMOBInterstitialAd;
    public static InterstitialAd FBinterstitialAd;
    public static Dialog dialog;
    public static String intertialseid;
    public static String fbintertialseid;


    public void ShowIntertistialAds(Activity activity, OnIntertistialAdsListner onAdsListner) {
//        if (SharedPrefs.getAdsShow(activity).equals("yes")) {
//            if (!SharedPrefs.gettimer(activity)) {
//                IntertistialAds(activity, onAdsListner);
//                new CountDownTimer(SharedPrefs.getapp_intertialseclick(activity), 1000) {
//                    public void onTick(long millisUntilFinished) {
//                        SharedPrefs.settimer(activity, true);
//                    }
//                    public void onFinish() {
//                        SharedPrefs.settimer(activity, false);
//                    }
//                }.start();
//            } else {
//                onAdsListner.onAdsDismissed();
//            }
//        } else {
//            onAdsListner.onAdsDismissed();
//        }

        if (SharedPrefs.getAdsShow(activity).equals("yes")) {
            int intertialseclick = SharedPrefs.getapp_intertialseclick(activity);
            SharedPrefs.setinterclickcount(activity, SharedPrefs.getinterclickcount(activity) + 1);
            if (intertialseclick == SharedPrefs.getinterclickcount(activity)) {
                SharedPrefs.setinterclickcount(activity, 0);
                IntertistialAds(activity, onAdsListner);
            } else {
                onAdsListner.onAdsDismissed();
            }
        }else {
            onAdsListner.onAdsDismissed();
        }
    }


    public void IntertistialAds(final Activity activity, OnIntertistialAdsListner onAdsListner) {

        if (SharedPrefs.getinteriduse(activity) == 0) {
            SharedPrefs.setinteriduse(activity, 1);
            intertialseid = SharedPrefs.getapp_intertialseid(activity);
        } else if (SharedPrefs.getinteriduse(activity) == 1) {
            SharedPrefs.setinteriduse(activity, 0);
            intertialseid = SharedPrefs.getapp_intertialseid1(activity);
        }

        fbintertialseid = SharedPrefs.getapp_fbintertialseid(activity);

        dialog = new Dialog(activity);
        View view = LayoutInflater.from(activity).inflate(R.layout.ads_loading, null);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog.setContentView(view);
        dialog.setCancelable(false);
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!dialog.isShowing()) {
                    dialog.show();
                }
            }
        }, 300);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                dialog.dismiss();
            }
        }, 5000);

        if (SharedPrefs.getintertistialSpecific(activity) == 0) {
            if (SharedPrefs.getintertistialadsequence(activity) == 0) {
                ADMOBInterstitialAd = null;

                com.google.android.gms.ads.interstitial.InterstitialAd.load(activity, intertialseid, new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull com.google.android.gms.ads.interstitial.InterstitialAd interstitialAd) {
                        dialog.dismiss();

                        ADMOBInterstitialAd = interstitialAd;
                        ADMOBInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override
                            public void onAdFailedToShowFullScreenContent(@NonNull com.google.android.gms.ads.AdError adError) {
                                super.onAdFailedToShowFullScreenContent(adError);
                                dialog.dismiss();
                            }

                            @Override
                            public void onAdShowedFullScreenContent() {
                                super.onAdShowedFullScreenContent();
                                dialog.dismiss();
                            }

                            @Override
                            public void onAdDismissedFullScreenContent() {
                                super.onAdDismissedFullScreenContent();
                                dialog.dismiss();
                                onAdsListner.onAdsDismissed();

                            }

                            @Override
                            public void onAdImpression() {
                                super.onAdImpression();
                                dialog.dismiss();
                            }
                        });
                        dialog.dismiss();
                        ADMOBInterstitialAd.show(activity);

                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        FBIntertistialAds(activity, onAdsListner);
                    }
                });
            } else if (SharedPrefs.getintertistialadsequence(activity) == 1) {
                FBinterstitialAd = new InterstitialAd(activity, fbintertialseid);
                InterstitialAdListener interstitialAdListener = new InterstitialAdListener() {
                    @Override
                    public void onInterstitialDisplayed(Ad ad) {
                        dialog.dismiss();

                    }

                    @Override
                    public void onInterstitialDismissed(Ad ad) {
                        dialog.dismiss();
                        onAdsListner.onAdsDismissed();
                    }

                    @Override
                    public void onError(Ad ad, AdError adError) {
                        admobIntertistialAds(activity, onAdsListner);
                    }

                    @Override
                    public void onAdLoaded(Ad ad) {
                        dialog.dismiss();
                        FBinterstitialAd.show();
                    }

                    @Override
                    public void onAdClicked(Ad ad) {
                    }

                    @Override
                    public void onLoggingImpression(Ad ad) {
                    }
                };

                FBinterstitialAd.loadAd(FBinterstitialAd.buildLoadAdConfig().withAdListener(interstitialAdListener).build());

            }
        } else if (SharedPrefs.getintertistialSpecific(activity) == 1) {
            admobIntertistialAds(activity, onAdsListner);
        } else if (SharedPrefs.getintertistialSpecific(activity) == 2) {
            FBIntertistialAds(activity, onAdsListner);
        }
    }

    public static void admobIntertistialAds(final Activity activity, OnIntertistialAdsListner onAdsListner) {

        ADMOBInterstitialAd = null;

        com.google.android.gms.ads.interstitial.InterstitialAd.load(activity, intertialseid, new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull com.google.android.gms.ads.interstitial.InterstitialAd interstitialAd) {
                dialog.dismiss();

                ADMOBInterstitialAd = interstitialAd;
                ADMOBInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdFailedToShowFullScreenContent(@NonNull com.google.android.gms.ads.AdError adError) {
                        super.onAdFailedToShowFullScreenContent(adError);
                        dialog.dismiss();
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        super.onAdShowedFullScreenContent();
                        dialog.dismiss();
                    }

                    @Override
                    public void onAdDismissedFullScreenContent() {
                        super.onAdDismissedFullScreenContent();
                        dialog.dismiss();
                        onAdsListner.onAdsDismissed();

                    }

                    @Override
                    public void onAdImpression() {
                        super.onAdImpression();
                        dialog.dismiss();
                    }
                });
                dialog.dismiss();
                ADMOBInterstitialAd.show(activity);

            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                dialog.dismiss();
                onAdsListner.onAdsDismissed();
            }
        });

    }


    public void FBIntertistialAds(Activity activity, OnIntertistialAdsListner onAdsListner) {
        FBinterstitialAd = new InterstitialAd(activity, fbintertialseid);
        InterstitialAdListener interstitialAdListener = new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
                dialog.dismiss();

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                dialog.dismiss();
                onAdsListner.onAdsDismissed();
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                dialog.dismiss();
                onAdsListner.onAdsDismissed();
            }

            @Override
            public void onAdLoaded(Ad ad) {
                dialog.dismiss();
                FBinterstitialAd.show();
            }

            @Override
            public void onAdClicked(Ad ad) {
            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        };

        FBinterstitialAd.loadAd(FBinterstitialAd.buildLoadAdConfig().withAdListener(interstitialAdListener).build());
    }

    public interface OnIntertistialAdsListner {
        void onAdsDismissed();
    }
}
