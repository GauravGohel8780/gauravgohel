package com.videoplayer.galley.allgame.Language;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.videoplayer.galley.allgame.AdsDemo.Intertials;
import com.videoplayer.galley.allgame.FirstActivity;
import com.videoplayer.galley.allgame.MainActivity;
import com.videoplayer.galley.allgame.PhotoGalleryActivity;
import com.videoplayer.galley.allgame.R;
import com.videoplayer.galley.allgame.VideoPlayer.SharedPrefs;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
    ArrayList<Model> courseName;
    Activity context;
    private int checkedPosition = 0;


    // Constructor for initialization
    public Adapter(Activity context, ArrayList<Model> courseName) {
        this.context = context;
        this.courseName = courseName;
    }

    public void SetPositon(ArrayList<Model> courseName) {
        this.courseName = new ArrayList<>();
        this.courseName = courseName;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflating the Layout(Instantiates list_item.xml
        // layout file into View object)
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);

        // Passing view to ViewHolder
        Adapter.ViewHolder viewHolder = new Adapter.ViewHolder(view);
        return viewHolder;
    }

    // Binding data to the into specified position
    @Override
    public void onBindViewHolder(@NonNull Adapter.ViewHolder holder, int position) {
        if (SharedPrefs.getchackpsition(context) == 0) {
            if (checkedPosition == position) {
                holder.chackitemposition.setVisibility(View.VISIBLE);
            } else {
                holder.chackitemposition.setVisibility(View.GONE);
            }
        } else {
            if (position == SharedPrefs.getchackpsition(context)) {
                holder.chackitemposition.setVisibility(View.VISIBLE);
            } else {
                holder.chackitemposition.setVisibility(View.GONE);
            }
        }


        holder.text.setText(courseName.get(position).getLaguage());
        holder.oneword.setText(courseName.get(position).getOneword());

        LanguageManager lang = new LanguageManager(context);

        holder.itemView.setOnClickListener(view -> {
            new Intertials().ShowIntertistialAds(context, new Intertials.OnIntertistialAdsListner() {
                public void onAdsDismissed() {
                    if (position == 0) {
                        lang.updateResoutce("en");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 1) {
                        lang.updateResoutce("bn");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 2) {
                        lang.updateResoutce("gu");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 3) {
                        lang.updateResoutce("hi");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 4) {
                        lang.updateResoutce("in");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 5) {
                        lang.updateResoutce("es");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 6) {
                        lang.updateResoutce("th");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 7) {
                        lang.updateResoutce("fr");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 8) {
                        lang.updateResoutce("pt");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 9) {
                        lang.updateResoutce("ru");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 10) {
                        lang.updateResoutce("ms");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 11) {
                        lang.updateResoutce("ro");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 12) {
                        lang.updateResoutce("it");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 13) {
                        lang.updateResoutce("zh");
                        SharedPrefs.setchackpsition(context, position);
                    }  else if (position == 14) {
                        lang.updateResoutce("fil");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 15) {
                        lang.updateResoutce("de");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 16) {
                        lang.updateResoutce("af");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 17) {
                        lang.updateResoutce("ja");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 18) {
                        lang.updateResoutce("mr");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 19) {
                        lang.updateResoutce("sw");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 20) {
                        lang.updateResoutce("zu");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 21) {
                        lang.updateResoutce("iw");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 22) {
                        lang.updateResoutce("ko");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 23) {
                        lang.updateResoutce("cs");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 24) {
                        lang.updateResoutce("pl");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 25) {
                        lang.updateResoutce("el");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 26) {
                        lang.updateResoutce("hu");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 27) {
                        lang.updateResoutce("nl");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 28) {
                        lang.updateResoutce("tr");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 29) {
                        lang.updateResoutce("uk");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 30) {
                        lang.updateResoutce("sv");
                        SharedPrefs.setchackpsition(context, position);
                    } else if (position == 31) {
                        lang.updateResoutce("vi");
                        SharedPrefs.setchackpsition(context, position);
                    }

                    if (SharedPrefs.getmainchack(context)) {
                        context.startActivity(new Intent(context, FirstActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                        SharedPrefs.setchackpsition(context, position);
                    } else {
                        if (com.videoplayer.galley.allgame.AdsDemo.SharedPrefs.getchackReferrer(context).equals("no")) {
                            if (com.videoplayer.galley.allgame.AdsDemo.SharedPrefs.getChackUserinet(context).equals("gclid")) {
                                context.startActivity(new Intent(context, PhotoGalleryActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                            } else if (com.videoplayer.galley.allgame.AdsDemo.SharedPrefs.getChackUserinet(context).equals("utm_source")) {
                                context.startActivity(new Intent(context, FirstActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                            }
                        } else if (com.videoplayer.galley.allgame.AdsDemo.SharedPrefs.getchackReferrer(context).equals("yes")) {
                            context.startActivity(new Intent(context, FirstActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                        } else if (com.videoplayer.galley.allgame.AdsDemo.SharedPrefs.getchackReferrer(context).equals("other")) {
                            context.startActivity(new Intent(context, PhotoGalleryActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                        }
                    }


                    holder.chackitemposition.setVisibility(View.VISIBLE);
                    if (checkedPosition != position) {
                        notifyItemChanged(checkedPosition);
                        checkedPosition = position;
                    }

                }
            });
        });
    }

    @Override
    public int getItemCount() {
        return courseName.size();
    }

    // Initializing the Views
    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView text, oneword;
        RelativeLayout chackitemposition;

        public ViewHolder(View view) {
            super(view);
            text = (TextView) view.findViewById(R.id.languegetext);
            oneword = (TextView) view.findViewById(R.id.oneword);
            chackitemposition = (RelativeLayout) view.findViewById(R.id.chackitemposition);
        }
    }
}