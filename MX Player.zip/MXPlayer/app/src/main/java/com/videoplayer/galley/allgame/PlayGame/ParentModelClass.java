package com.videoplayer.galley.allgame.PlayGame;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.util.ArrayList;

public class ParentModelClass implements Parcelable {

    String title;
    ArrayList<ChildModelClass> childModelClassList;

    public ParentModelClass(String title, ArrayList<ChildModelClass> childModelClassList) {
        this.title = title;
        this.childModelClassList = childModelClassList;
    }


    protected ParentModelClass(Parcel in) {
        title = in.readString();
    }

    public static final Creator<ParentModelClass> CREATOR = new Creator<ParentModelClass>() {
        @Override
        public ParentModelClass createFromParcel(Parcel in) {
            return new ParentModelClass(in);
        }

        @Override
        public ParentModelClass[] newArray(int size) {
            return new ParentModelClass[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(title);
    }
}
