package com.videoplayer.galley.allgame.VideoDownloader.Facebook;




import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.content.ContextCompat;

import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.videoplayer.galley.allgame.AdsDemo.Intertials;
import com.videoplayer.galley.allgame.AdsDemo.Native;
import com.videoplayer.galley.allgame.R;

import io.reactivex.internal.functions.Functions;

public class FasebookActivity extends AppCompatActivity {

    TextView button, paste;
    EditText editText;
    AppCompatButton btnOpenInstagram;
    private ClipboardManager clipBoard;
    ImageView downloaded;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fasebook);
        new Native().shownativeads(this, findViewById(R.id.native_container));
        button = findViewById(R.id.button);
        paste = findViewById(R.id.paste);
        btnOpenInstagram = findViewById(R.id.btnOpenInstagram);
        editText = findViewById(R.id.editText);
        downloaded = findViewById(R.id.downloaded);

        downloaded.setOnClickListener(view -> {
            new Intertials().ShowIntertistialAds(this, new Intertials.OnIntertistialAdsListner() {
                public void onAdsDismissed() {
                    startActivity(new Intent(FasebookActivity.this, DownloadedViewActivity.class));
                }
            });
        });
        btnOpenInstagram.setOnClickListener(view -> {
            launchInstagram();
        });

        paste.setOnClickListener(view -> {
            clipBoard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            try {
                CharSequence textToPaste = clipBoard.getPrimaryClip().getItemAt(0).getText();
                editText.setText(textToPaste);
            } catch (Exception e) {
                return;
            }
        });

        this.button.setOnClickListener(new View.OnClickListener() { // from class: com.lunarday.fbstorydownloader.fragment.FacebookDownload.2
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (internetIsConnected()) {
                    String obj = editText.getText().toString();
                    if (obj.equals("")) {
                        Toast.makeText(FasebookActivity.this, "Paste a post url to download the post", Toast.LENGTH_SHORT).show();
                        return;
                    } else if (!obj.contains("https")) {
                        Toast.makeText(FasebookActivity.this, "Not a valid link", Toast.LENGTH_SHORT).show();
                        return;
                    } else if (!obj.contains("m.facebook") && !obj.contains("www.facebook") && !obj.contains("mbasic.facebook") && !obj.contains("fb.watch")) {
                        Toast.makeText(FasebookActivity.this, "Paste a facebook link", Toast.LENGTH_SHORT).show();
                        return;
                    } else {
                        Intent intent3 = new Intent(FasebookActivity.this, DeepLinks.class);
                        intent3.putExtra("url", obj);
                        startActivity(intent3);
//                        Toast.makeText(FasebookActivity.this, "------started-------", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    public boolean internetIsConnected() {
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (connectivityManager.getNetworkInfo(0).getState() != NetworkInfo.State.CONNECTED) {
                if (connectivityManager.getNetworkInfo(1).getState() != NetworkInfo.State.CONNECTED) {
                    return false;
                }
            }
        } catch (Exception unused) {
        }
        return true;
    }


    public void launchInstagram() {
        String instagramApp = "com.facebook.katana";
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage(instagramApp);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), R.string.instagram_not_found, Toast.LENGTH_SHORT).show();
        }
    }
}