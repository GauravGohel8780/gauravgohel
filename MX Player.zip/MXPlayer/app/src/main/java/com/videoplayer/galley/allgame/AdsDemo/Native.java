package com.videoplayer.galley.allgame.AdsDemo;

import android.app.Activity;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdListener;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.videoplayer.galley.allgame.R;

public class Native {


    public static Dialog dialog;
    String nativeid;
    String fbnativeid;
    public static BroadcastReceiver broadcastReceiver;

    public void shownativeads(final Activity activity, final ViewGroup viewGroup) {

        if (SharedPrefs.getInternetDilog(activity).equals("yes")) {
            broadcastReceiver = new NetworkChangeListener();
            activity.registerReceiver(broadcastReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        }

        if (SharedPrefs.getAdsShow(activity).equals("yes")) {

            dialog = new Dialog(activity);
            View view = LayoutInflater.from(activity).inflate(R.layout.ads_loading, null);
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.setContentView(view);
            dialog.setCancelable(false);
            Window window = dialog.getWindow();
            window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!dialog.isShowing()) {
                        dialog.show();
                    }
                }
            }, 100);

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (dialog.isShowing()) {
                        dialog.dismiss();
                    }
                }
            }, 5000);


            if (SharedPrefs.getnativeiduse(activity) == 0) {
                SharedPrefs.setnativeiduse(activity, 1);
                nativeid = SharedPrefs.getapp_nativeid(activity);
            } else if (SharedPrefs.getnativeiduse(activity) == 1) {
                SharedPrefs.setnativeiduse(activity, 0);
                nativeid = SharedPrefs.getapp_nativeid1(activity);
            }
            fbnativeid = SharedPrefs.getapp_fbnativeid(activity);

            if (SharedPrefs.getnativeSpecific(activity) == 0) {
                nativeads(activity, viewGroup);
            } else if (SharedPrefs.getnativeSpecific(activity) == 1) {
                admobnativeads(activity, viewGroup);
            } else if (SharedPrefs.getnativeSpecific(activity) == 2) {
                fbshownative(activity, viewGroup);
            }
        }
    }

    public void nativeads(final Activity activity, final ViewGroup viewGroup) {
        if (SharedPrefs.getnativeadsequence(activity) == 0) {
            AdLoader.Builder builder = new AdLoader.Builder(activity, nativeid);
            builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {
                @Override
                public void onNativeAdLoaded(@NonNull com.google.android.gms.ads.nativead.NativeAd nativeAd) {
                    new InflatAds(activity).inflat_admobnative(nativeAd, viewGroup);
                    dialog.dismiss();


                }
            });
            AdLoader adLoader = builder.withAdListener(new AdListener() {
                @Override
                public void onAdFailedToLoad(LoadAdError loadAdError) {
                    fbshownative(activity, viewGroup);
                }
            }).build();
            adLoader.loadAd(new AdRequest.Builder().build());
        } else if (SharedPrefs.getnativeadsequence(activity) == 1) {
            NativeAd nativeAd = new NativeAd(activity, fbnativeid);

            NativeAdListener nativeAdListener = new NativeAdListener() {
                @Override
                public void onMediaDownloaded(Ad ad) {

                }

                @Override
                public void onError(Ad ad, AdError adError) {
                    admobnativeads(activity, viewGroup);
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    if (nativeAd == null || nativeAd != ad) {
                        return;
                    }
                    new InflatAds(activity).inflat_facebooknative(nativeAd, viewGroup);
                    dialog.dismiss();
                }

                @Override
                public void onAdClicked(Ad ad) {
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                }
            };
            nativeAd.loadAd(nativeAd.buildLoadAdConfig().withAdListener(nativeAdListener).build());
        }
    }

    public void admobnativeads(final Activity activity, final ViewGroup viewGroup) {
        AdLoader.Builder builder = new AdLoader.Builder(activity, nativeid);
        builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {
            @Override
            public void onNativeAdLoaded(@NonNull com.google.android.gms.ads.nativead.NativeAd nativeAd) {
                new InflatAds(activity).inflat_admobnative(nativeAd, viewGroup);
                dialog.dismiss();
            }
        });
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
                dialog.dismiss();
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void fbshownative(Activity activity, ViewGroup viewGroup) {
        NativeAd nativeAd = new NativeAd(activity, fbnativeid);

        NativeAdListener nativeAdListener = new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {
                dialog.dismiss();
            }

            @Override
            public void onAdLoaded(Ad ad) {
                if (nativeAd == null || nativeAd != ad) {
                    return;
                }
                new InflatAds(activity).inflat_facebooknative(nativeAd, viewGroup);
                dialog.dismiss();
            }

            @Override
            public void onAdClicked(Ad ad) {
            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        };
        nativeAd.loadAd(nativeAd.buildLoadAdConfig().withAdListener(nativeAdListener).build());
    }
}
