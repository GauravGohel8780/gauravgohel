package com.videoplayer.galley.allgame.AdsDemo;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefs {
    private static SharedPreferences mPreferences;
    public static final String itemposition  = "itemposition";
    public static final String enteritem  = "enteritem";

    public static final String AdsShow = "AdsShow";
    public static final String app_openId = "app_openId";
    public static final String app_bannerid = "app_bannerid";
    public static final String app_bannerid1 = "app_bannerid1";
    public static final String app_fbbannerid = "app_fbbannerid";
    public static final String app_intertialseid = "app_intertialseid";
    public static final String app_intertialseid1 = "app_intertialseid1";
    public static final String app_fbintertialseid = "app_fbintertialseid";
    public static final String app_nativeid = "app_nativeid";
    public static final String app_nativeid1 = "app_nativeid1";
    public static final String app_fbnativeid = "app_fbnativeid";
    public static final String app_intertialseclick = "app_intertialseclick";
    public static final String interclickcount = "interclickcount";
    public static final String banneriduse = "banneriduse";
    public static final String nativeiduse = "nativeiduse";
    public static final String interiduse = "interiduse";
    public static final String First_chike = "First_chike";
    public static final String InternetDilog = "InternetDilog";
    public static final String FirstenterDilog = "FirstenterDilog";
    public static final String FistTimeUserimg = "FistTimeUserimg";
    public static final String FistTimeUserurl = "FistTimeUserurl";
    public static final String ChackUserinet = "ChackUserinet";
    public static final String chackENterOneUserinet = "chackENterOneUserinet";
    public static final String chackReferrer = "chackReferrer";
    public static final String bannerSpecific = "bannerSpecific";
    public static final String nativeSpecific = "nativeSpecific";
    public static final String intertistialSpecific = "intertistialSpecific";
    public static final String banneradsequence = "banneradsequence";
    public static final String nativeadsequence = "nativeadsequence";
    public static final String intertistialadsequence = "intertistialadsequence";
    public static final String appopentype = "appopentype";
    public static final String splashintet = "splashintet";
    public static final String timer = "timer";
    private static SharedPreferences getInstance(Context context) {
        if (mPreferences == null) {
            mPreferences = context.getApplicationContext().getSharedPreferences("stat_data", 0);
        }
        return mPreferences;
    }


    public static void setAdsShow(Context context, String b) {
        getInstance(context).edit().putString(AdsShow, b).apply();
    }

    public static String getAdsShow(Context context) {
        return getInstance(context).getString(AdsShow, "");
    }
    public static void setapp_openId(Context context, String b) {
        getInstance(context).edit().putString(app_openId, b).apply();
    }

    public static String getapp_openId(Context context) {
        return getInstance(context).getString(app_openId, "");
    }

    public static void setapp_bannerid(Context context, String b) {
        getInstance(context).edit().putString(app_bannerid, b).apply();
    }

    public static String getapp_bannerid(Context context) {
        return getInstance(context).getString(app_bannerid, "");
    }

    public static void setapp_bannerid1(Context context, String b) {
        getInstance(context).edit().putString(app_bannerid1, b).apply();
    }

    public static String getapp_bannerid1(Context context) {
        return getInstance(context).getString(app_bannerid1, "");
    }

    public static void setapp_fbbannerid(Context context, String b) {
        getInstance(context).edit().putString(app_fbbannerid, b).apply();
    }

    public static String getapp_fbbannerid(Context context) {
        return getInstance(context).getString(app_fbbannerid, "");
    }

    public static void setapp_intertialseid(Context context, String b) {
        getInstance(context).edit().putString(app_intertialseid, b).apply();
    }

    public static String getapp_intertialseid(Context context) {
        return getInstance(context).getString(app_intertialseid, "");
    }

    public static void setapp_intertialseid1(Context context, String b) {
        getInstance(context).edit().putString(app_intertialseid1, b).apply();
    }

    public static String getapp_intertialseid1(Context context) {
        return getInstance(context).getString(app_intertialseid1, "");
    }

    public static void setapp_fbintertialseid(Context context, String b) {
        getInstance(context).edit().putString(app_fbintertialseid, b).apply();
    }

    public static String getapp_fbintertialseid(Context context) {
        return getInstance(context).getString(app_fbintertialseid, "");
    }

    public static void setapp_nativeid(Context context, String b) {
        getInstance(context).edit().putString(app_nativeid, b).apply();
    }

    public static String getapp_nativeid(Context context) {
        return getInstance(context).getString(app_nativeid, "");
    }

    public static void setapp_nativeid1(Context context, String b) {
        getInstance(context).edit().putString(app_nativeid1, b).apply();
    }

    public static String getapp_nativeid1(Context context) {
        return getInstance(context).getString(app_nativeid1, "");
    }

    public static void setapp_fbnativeid(Context context, String b) {
        getInstance(context).edit().putString(app_fbnativeid, b).apply();
    }

    public static String getapp_fbnativeid(Context context) {
        return getInstance(context).getString(app_fbnativeid, "");
    }

    public static void setapp_intertialseclick(Context context, int b) {
        getInstance(context).edit().putInt(app_intertialseclick, b).apply();
    }

    public static int getapp_intertialseclick(Context context) {
        return getInstance(context).getInt(app_intertialseclick, 0);
    }


    public static void setinterclickcount(Context context, int b) {
        getInstance(context).edit().putInt(interclickcount, b).apply();
    }

    public static int getinterclickcount(Context context) {
        return getInstance(context).getInt(interclickcount, 0);
    }


    public static void setbanneriduse(Context context, int b) {
        getInstance(context).edit().putInt(banneriduse, b).apply();
    }

    public static int getbanneriduse(Context context) {
        return getInstance(context).getInt(banneriduse, 0);
    }

    public static void setnativeiduse(Context context, int b) {
        getInstance(context).edit().putInt(nativeiduse, b).apply();
    }

    public static int getnativeiduse(Context context) {
        return getInstance(context).getInt(nativeiduse, 0);
    }

    public static void setinteriduse(Context context, int b) {
        getInstance(context).edit().putInt(interiduse, b).apply();
    }

    public static int getinteriduse(Context context) {
        return getInstance(context).getInt(interiduse, 0);
    }

    public static void setInternetDilog(Context context, String b) {
        getInstance(context).edit().putString(InternetDilog, b).apply();
    }

    public static String getInternetDilog(Context context) {
        return getInstance(context).getString(InternetDilog, "");
    }

    public static void setFirstenterDilog(Context context, int b) {
        getInstance(context).edit().putInt(FirstenterDilog, b).apply();
    }

    public static int getFirstenterDilog(Context context) {
        return getInstance(context).getInt(FirstenterDilog, 0);
    }

    public static String getFistTimeUserimg(Context context) {
        return getInstance(context).getString(FistTimeUserimg, "");
    }

    public static void setFistTimeUserimg(Context context, String b) {
        getInstance(context).edit().putString(FistTimeUserimg, b).apply();
    }

    public static String getFistTimeUserurl(Context context) {
        return getInstance(context).getString(FistTimeUserurl, "");
    }

    public static void setFistTimeUserurl(Context context, String b) {
        getInstance(context).edit().putString(FistTimeUserurl, b).apply();
    }

    public static String getChackUserinet(Context context) {
        return getInstance(context).getString(ChackUserinet, "");
    }

    public static void setChackUserinet(Context context, String b) {
        getInstance(context).edit().putString(ChackUserinet, b).apply();
    }

    public static String getchackReferrer(Context context) {
        return getInstance(context).getString(chackReferrer, "");
    }

    public static void setchackReferrer(Context context, String b) {
        getInstance(context).edit().putString(chackReferrer, b).apply();
    }

    public static void setFirst_chike(Context context, boolean value) {
        getInstance(context).edit().putBoolean(First_chike, value).apply();
    }

    public static boolean getFirst_chike(Context context) {
        return getInstance(context).getBoolean(First_chike, false);
    }

    public static void settimer(Context context, boolean value) {
        getInstance(context).edit().putBoolean(timer, value).apply();
    }

    public static boolean gettimer(Context context) {
        return getInstance(context).getBoolean(timer, false);
    }

    public static void setbannerSpecific(Context context, int b) {
        getInstance(context).edit().putInt(bannerSpecific, b).apply();
    }

    public static int getbannerSpecific(Context context) {
        return getInstance(context).getInt(bannerSpecific, 0);
    }

    public static void setnativeSpecific(Context context, int b) {
        getInstance(context).edit().putInt(nativeSpecific, b).apply();
    }

    public static int getnativeSpecific(Context context) {
        return getInstance(context).getInt(nativeSpecific, 0);
    }

    public static void setintertistialSpecific(Context context, int b) {
        getInstance(context).edit().putInt(intertistialSpecific, b).apply();
    }

    public static int getintertistialSpecific(Context context) {
        return getInstance(context).getInt(intertistialSpecific, 0);
    }

    public static void setbanneradsequence(Context context, int b) {
        getInstance(context).edit().putInt(banneradsequence, b).apply();
    }

    public static int getbanneradsequence(Context context) {
        return getInstance(context).getInt(banneradsequence, 0);
    }

    public static void setnativeadsequence(Context context, int b) {
        getInstance(context).edit().putInt(nativeadsequence, b).apply();
    }

    public static int getnativeadsequence(Context context) {
        return getInstance(context).getInt(nativeadsequence, 0);
    }

    public static void setintertistialadsequence(Context context, int b) {
        getInstance(context).edit().putInt(intertistialadsequence, b).apply();
    }

    public static int getintertistialadsequence(Context context) {
        return getInstance(context).getInt(intertistialadsequence, 0);
    }

    public static void setappopentype(Context context, int b) {
        getInstance(context).edit().putInt(appopentype, b).apply();
    }

    public static int getappopentype(Context context) {
        return getInstance(context).getInt(appopentype, 0);
    }

    public static String getsplashintet(Context context) {
        return getInstance(context).getString(splashintet, "");
    }

    public static void setsplashintet(Context context, String b) {
        getInstance(context).edit().putString(splashintet, b).apply();
    }
}
