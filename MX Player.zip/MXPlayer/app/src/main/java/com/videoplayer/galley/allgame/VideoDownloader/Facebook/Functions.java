package com.videoplayer.galley.allgame.VideoDownloader.Facebook;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.widget.Toast;

import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.common.net.HttpHeaders;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.File;
import java.text.SimpleDateFormat;
import java.text.StringCharacterIterator;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* loaded from: classes4.dex */
public class Functions {
    public static String adUrl = "";
    public static Uri pickerUri;
    Context context;
    int cookieAccessCount = 0;
    Handler handler;
    String ua;

    public static String generateUserAgent() {
        String format = String.format("%s Android (%s/%s; %s; %s; %s; %s; %s; %s; %s_%s ;%s)", "Instagram 107.0.0.27.121", Build.VERSION.RELEASE, Build.VERSION.SDK, "320dpi", "720x1280", Build.MODEL, Build.MANUFACTURER, Build.BRAND, Build.DEVICE, Locale.getDefault().getLanguage(), Locale.getDefault().getCountry(), 113);
        Log.i("useragent", format);
        return format;
    }

    public Functions(Context context) {
        this.context = context;
        this.ua = new WebView(context).getSettings().getUserAgentString();
    }

    public String getUserAgent() {
        return this.ua;
    }

    public String getco() {
        try {
            return CookieManager.getInstance().getCookie("https://m.facebook.com");
        } catch (NullPointerException | StringIndexOutOfBoundsException unused) {
            return "null";
        }
    }


    /* loaded from: classes4.dex */
    public class GetSourceCode implements Callable<Document> {
        String url;

        public GetSourceCode(String url) {
            this.url = url;
        }

        @Override // java.util.concurrent.Callable
        public Document call() throws Exception {
            HashMap hashMap = new HashMap();
            hashMap.put("accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
            hashMap.put("accept-language", "en-IN,en-US;q=0.9,en;q=0.8");
            hashMap.put("cache-control", "max-age=0");
            hashMap.put("content-type", "application/x-www-form-urlencoded");
            hashMap.put("origin", "https://mbasic.facebook.com");
            hashMap.put("sec-fetch-dest", "document");
            hashMap.put("sec-fetch-mode", "navigate");
            hashMap.put("sec-fetch-site", HttpHeaders.ReferrerPolicyValues.SAME_ORIGIN);
            hashMap.put("sec-fetch-user", "?1");
            hashMap.put("upgrade-insecure-requests", IcyHeaders.REQUEST_HEADER_ENABLE_METADATA_VALUE);
            hashMap.put("user-agent", Functions.this.ua);
            hashMap.put("cookie", Functions.this.getco());
            try {
                return Jsoup.connect(this.url).ignoreContentType(true).headers(hashMap).userAgent(Functions.this.ua).get();
            } catch (Exception e2) {
                System.out.println(e2);
                return null;
            }
        }
    }

    public String getSourceCode(String url) {
        try {
            return ((Document) Executors.newSingleThreadExecutor().submit(new GetSourceCode(url)).get()).toString();
        } catch (Exception e2) {
            e2.printStackTrace();
            return null;
        }
    }

    public Document page(String url) {
        try {
            return (Document) Executors.newSingleThreadExecutor().submit(new GetSourceCode(url)).get();
        } catch (Exception e2) {
            e2.printStackTrace();
            return null;
        }
    }

    public String getFbDtsg() {
        ExecutorService newSingleThreadExecutor = Executors.newSingleThreadExecutor();
        try {
            String document = ((Document) newSingleThreadExecutor.submit(new GetSourceCode("https://mbasic.facebook.com")).get()).toString();
            int indexOf = document.indexOf("fb_dtsg") + 16;
            int indexOf2 = document.indexOf("\"", indexOf + 5);
            newSingleThreadExecutor.shutdown();
            return document.substring(indexOf, indexOf2);
        } catch (Exception e2) {
            e2.printStackTrace();
            newSingleThreadExecutor.shutdown();
            return "error";
        }
    }


    /* loaded from: classes4.dex */
    public class GetSourceCodeWeb implements Callable<Document> {
        String url;

        public GetSourceCodeWeb(String url) {
            this.url = url;
        }

        @Override // java.util.concurrent.Callable
        public Document call() throws Exception {
            HashMap hashMap = new HashMap();
            hashMap.put("accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
            hashMap.put("accept-language", "en-IN,en-US;q=0.9,en;q=0.8");
            hashMap.put("cache-control", "max-age=0");
            hashMap.put("origin", "https://www.facebook.com");
            hashMap.put("referer", "https://www.facebook.com");
            hashMap.put("sec-fetch-dest", "document");
            hashMap.put("sec-ch-ua", " Not A;Brand\";v=\"99\", \"Chromium\";v=\"100\", \"Google Chrome\";v=\"100");
            hashMap.put("sec-fetch-mode", "navigate");
            hashMap.put("sec-ch-ua-mobile", "?0");
            hashMap.put("sec-ch-ua-platform", "macOS");
            hashMap.put("sec-fetch-site", HttpHeaders.ReferrerPolicyValues.SAME_ORIGIN);
            hashMap.put("sec-fetch-user", "?1");
            hashMap.put("upgrade-insecure-requests", IcyHeaders.REQUEST_HEADER_ENABLE_METADATA_VALUE);
            hashMap.put("user-agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36");
            hashMap.put("cookie", Functions.this.getco());
            Document document = null;
            try {
                document = Jsoup.connect(this.url).ignoreContentType(true).headers(hashMap).maxBodySize(52428800).userAgent("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36").get();
                Log.i("aa__", document.title());
                return document;
            } catch (Exception unused) {
                return document;
            }
        }
    }

    public String getSourceCodeWeb(String url) {
        try {
            return ((Document) Executors.newSingleThreadExecutor().submit(new GetSourceCodeWeb(url)).get()).toString();
        } catch (Exception e2) {
            e2.printStackTrace();
            return null;
        }
    }

    public String getLanGfId() {
        ExecutorService newSingleThreadExecutor = Executors.newSingleThreadExecutor();
        try {
            String document = ((Document) newSingleThreadExecutor.submit(new GetSourceCode("https://mbasic.facebook.com/language.php")).get()).toString();
            int indexOf = document.indexOf("gfid", document.indexOf("/a/language.php?l=en_US")) + 5;
            int indexOf2 = document.indexOf("\"", indexOf);
            newSingleThreadExecutor.shutdown();
            return document.substring(indexOf, indexOf2);
        } catch (Exception e2) {
            e2.printStackTrace();
            newSingleThreadExecutor.shutdown();
            return "error";
        }
    }

    public void write(String key, String data) {
        Context context = this.context;
        SharedPreferences.Editor edit = context.getSharedPreferences(context.getPackageName(), 0).edit();
        edit.putString(key, data);
        edit.commit();
    }

    public String read(String key) {
        Context context = this.context;
        return context.getSharedPreferences(context.getPackageName(), 0).getString(key, "null");
    }

    public boolean isInternetOn() {
        ConnectivityManager connectivityManager = (ConnectivityManager) this.context.getSystemService(Context.CONNECTIVITY_SERVICE);
        return connectivityManager.getNetworkInfo(0).getState() == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(1).getState() == NetworkInfo.State.CONNECTED;
    }

    public String getDecodedName(String message) {
        try {
            Matcher matcher = Pattern.compile("\\\\u([0-9a-f]{4})").matcher(message);
            StringBuffer stringBuffer = new StringBuffer();
            while (matcher.find()) {
                matcher.appendReplacement(stringBuffer, String.valueOf((char) Integer.parseInt(matcher.group(1), 16)));
            }
            matcher.appendTail(stringBuffer);
            return stringBuffer.toString();
        } catch (Exception e2) {
            e2.printStackTrace();
            return message;
        }
    }

    public void printBigData(String tag, String data) {
        int length = data.length();
        while (length > 0) {
            if (length > 100) {
                Log.i(tag, data.substring(0, 100));
                data = data.substring(100);
                length = data.length();
            } else {
                Log.i(tag, data);
                return;
            }
        }
    }

    public String withSuffix(long count) {
        if (count < 1000) {
            return "" + count;
        }
        double d2 = count;
        int log = (int) (Math.log(d2) / Math.log(1000.0d));
        return String.format("%.1f %c", Double.valueOf(d2 / Math.pow(1000.0d, log)), Character.valueOf("kMBTPE".charAt(log - 1)));
    }

    public String humanReadableByteCountBin(long bytes) {
        long abs = bytes == Long.MIN_VALUE ? Long.MAX_VALUE : Math.abs(bytes);
        if (abs < PlaybackStateCompat.ACTION_PLAY_FROM_MEDIA_ID) {
            return bytes + " B";
        }
        StringCharacterIterator stringCharacterIterator = new StringCharacterIterator("KMGTPE");
        long j = abs;
        for (int i = 40; i >= 0 && abs > (0 >> i); i -= 10) {
            j >>= 10;
            stringCharacterIterator.next();
        }
        return String.format("%.1f %ciB", Double.valueOf((j * Long.signum(bytes)) / 1024.0d), Character.valueOf(stringCharacterIterator.current()));
    }

    public String getFormatedTime(int duration) {
        return (duration / 60) + " min " + (duration % 60) + " s";
    }

    public String getStringForNumber(int j) {
        String str = "";
        while (j > 0) {
            int i = j % 10;
            j /= 10;
            str = ((i < 0 || i >= 27) ? null : String.valueOf((char) (i + 65))) + str;
        }
        return str.toLowerCase();
    }

    public void copy(String s) {
        ((ClipboardManager) this.context.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("label", s));
        Toast.makeText(this.context, "Copied", Toast.LENGTH_SHORT).show();
    }

    public int getColor(int index) {
        return Color.parseColor(new String[]{"#fadbd8", "#f4ecf7", "#fdedec", "#f9ebea", "#d2b4de", "#d6eaf8", "#d1f2eb", "#fadbd8", "#f4ecf7", "#fdedec", "#f9ebea", "#fdebd0", "#f9e79f", "#fcf3cf", "#d5f5e3", "#abebc6", "#d6eaf8", "#d5f5e3", "#fdebd0", "#fcf3cf", "#f5eef8", "#d5f5e3", "#fdebd0", "#fcf3cf", "#f9e79f", "#fdf2e9", "#fcf3cf", "#ebf5fb", "#fdedec", "#f9ebea", "#fadbd8", "#f4ecf7", "#fdedec", "#f9ebea", "#d2b4de", "#d6eaf8", "#d1f2eb", "#fadbd8", "#f4ecf7", "#fdedec", "#fadbd8", "#f4ecf7", "#fdedec", "#f9ebea", "#fdebd0", "#f9e79f", "#fcf3cf", "#fdedec", "#f9ebea", "#d2b4de", "#d6eaf8", "#d1f2eb", "#fadbd8", "#f4ecf7", "#fdedec", "#f9ebea", "#fdebd0", "#f9e79", "#fcf3cf", "#d5f5e3", "#abebc6", "#d6eaf8", "#d5f5e3", "#fdebd0", "#fcf3cf", "#f9e79f", "#aeb6bf", "#d6dbdf"}[index % 68]);
    }

    public String getParentDir() {
        return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + "/Story Downloader" + File.separator;
    }

    public String getDateTime() {
        Date time = Calendar.getInstance().getTime();
        System.out.println("Current time => " + time);
        return new SimpleDateFormat("dd-MMM-yyyy_HH-mm-ss", Locale.getDefault()).format(time);
    }

    public String toTimeAgo(long time) {
        long currentTimeMillis = System.currentTimeMillis() - time;
        List asList = Arrays.asList("year", "month", "day", "hour", "minute", "second");
        int i = 0;
        List asList2 = Arrays.asList(Long.valueOf(TimeUnit.DAYS.toMillis(365L)), Long.valueOf(TimeUnit.DAYS.toMillis(30L)), Long.valueOf(TimeUnit.DAYS.toMillis(1L)), Long.valueOf(TimeUnit.HOURS.toMillis(1L)), Long.valueOf(TimeUnit.MINUTES.toMillis(1L)), Long.valueOf(TimeUnit.SECONDS.toMillis(1L)));
        StringBuffer stringBuffer = new StringBuffer();
        while (true) {
            if (i >= asList2.size()) {
                break;
            }
            long longValue = currentTimeMillis / ((Long) asList2.get(i)).longValue();
            if (longValue > 0) {
                stringBuffer.append(longValue).append(" ").append((String) asList.get(i)).append(longValue != 1 ? "s" : "").append(" ago");
            } else {
                i++;
            }
        }
        return "".equals(stringBuffer.toString()) ? "0 seconds ago" : stringBuffer.toString();
    }

    public boolean internetIsConnected() {
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) this.context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (connectivityManager.getNetworkInfo(0).getState() != NetworkInfo.State.CONNECTED) {
                if (connectivityManager.getNetworkInfo(1).getState() != NetworkInfo.State.CONNECTED) {
                    return false;
                }
            }
        } catch (Exception unused) {
        }
        return true;
    }

    public static boolean is29orAbove() {
        Log.i("tag__", "version" + Build.VERSION.SDK_INT);
        return Build.VERSION.SDK_INT >= 33;
    }
}
