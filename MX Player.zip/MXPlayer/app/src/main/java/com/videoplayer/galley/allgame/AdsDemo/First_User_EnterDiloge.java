package com.videoplayer.galley.allgame.AdsDemo;


import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.videoplayer.galley.allgame.R;

public class First_User_EnterDiloge {

    Activity activity;
    Boolean firsttime = false;

    public First_User_EnterDiloge(Activity activity) {
        this.activity = activity;
    }

    public void FirstTimeDilog() {
        if (SharedPrefs.getFirstenterDilog(activity) == 1) {
            if (!firsttime) {
                FirstTimeUser();
                firsttime = true;
            }
        }
    }

    private void FirstTimeUser() {
        Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setContentView(R.layout.first_time_user_dilog);
        dialog.setCancelable(false);
        Window window = dialog.getWindow();

        WindowManager.LayoutParams attributes = window.getAttributes();
        attributes.gravity = Gravity.CENTER;
        attributes.width = WindowManager.LayoutParams.MATCH_PARENT;
        attributes.height = WindowManager.LayoutParams.MATCH_PARENT;
        window.setAttributes(attributes);


        ImageView videoimage = dialog.findViewById(R.id.videoimage);
        ImageView btncancel = dialog.findViewById(R.id.btncancel);
        TextView btncancel1 = dialog.findViewById(R.id.btncancel1);
        TextView btnwatchvideo = dialog.findViewById(R.id.btnwatchvideo);

        String FistTimeUserimg = SharedPrefs.getFistTimeUserimg(activity);
        String FistTimeUserurl = SharedPrefs.getFistTimeUserurl(activity);
        Glide.with(activity).load(FistTimeUserimg).into(videoimage);
        btncancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        btncancel1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        btnwatchvideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(FistTimeUserurl));
                activity.startActivity(intent);
            }
        });
        dialog.show();
    }
}
