package com.videoplayer.galley.allgame.VideoPlayer;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import com.videoplayer.galley.allgame.AdsDemo.Intertials;
import com.videoplayer.galley.allgame.R;

import java.util.ArrayList;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.ViewHolder> {

    private ArrayList<VideoModel> arrayList;
    private Context context;

    public VideoAdapter(ArrayList<VideoModel> arrayList, Context context) {
        this.arrayList = arrayList;
        this.context = context;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.videolayout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        VideoModel model = arrayList.get(position);

//        Glide.with(context).load(model.getFirstPic()).apply(new RequestOptions().centerCrop()).into(holder.folderPic);

        String text = model.getFolderName();
        holder.folderName.setText(text);
        holder.foldercoutn.setText("(" + model.getNumberOfPics() + ") ");

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Intertials().ShowIntertistialAds((Activity) context, new Intertials.OnIntertistialAdsListner() {
                    public void onAdsDismissed() {
                        Intent intent = new Intent(context, VideoitemActivity.class);
                        intent.putExtra("folderPath", model.getPath());
                        intent.putExtra("foldername", model.getFolderName());
                        context.startActivity(intent);
                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView folderPic;
        private TextView folderName, foldercoutn;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            folderPic = (ImageView) itemView.findViewById(R.id.folderphoto);
            folderName = (TextView) itemView.findViewById(R.id.tvname);
            foldercoutn = (TextView) itemView.findViewById(R.id.tvcoutn);
        }
    }
}