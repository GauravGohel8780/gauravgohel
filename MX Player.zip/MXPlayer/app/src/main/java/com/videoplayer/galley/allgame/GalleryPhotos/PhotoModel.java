package com.videoplayer.galley.allgame.GalleryPhotos;

import java.util.Comparator;

public class PhotoModel {


    private  String path;
    private  String FolderName;
    private int numberOfPics = 0;
    private String firstPic;

    public PhotoModel(){

    }

    public PhotoModel(String path, String folderName) {
        this.path = path;
        FolderName = folderName;
    }

    public static Comparator<PhotoModel> comparatorAZsize = new Comparator<PhotoModel>() {
        @Override
        public int compare(PhotoModel photoModel, PhotoModel t1) {
            return photoModel.getFolderName().compareTo(t1.getFolderName());
        }
    };
    public static Comparator<PhotoModel> comparatorZAsize = new Comparator<PhotoModel>() {
        @Override
        public int compare(PhotoModel photoModel, PhotoModel t1) {
            return t1.getFolderName().compareTo(photoModel.getFolderName());
        }
    };

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getFolderName() {
        return FolderName;
    }

    public void setFolderName(String folderName) {
        FolderName = folderName;
    }

    public int getNumberOfPics() {
        return numberOfPics;
    }

    public void setNumberOfPics(int numberOfPics) {
        this.numberOfPics = numberOfPics;
    }

    public void addpics(){
        this.numberOfPics++;
    }

    public String getFirstPic() {
        return firstPic;
    }

    public void setFirstPic(String firstPic) {
        this.firstPic = firstPic;
    }
}