package com.videoplayer.galley.allgame.AdsDemo;


import android.app.Activity;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdListener;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.nativead.NativeAd;
import com.videoplayer.galley.allgame.R;

public class NativeBanner extends AppCompatActivity {
    public static Dialog dialog;
    String nativeid;

    String fbnativeid;
    public static BroadcastReceiver broadcastReceiver;

    public void shownativebannerads(final Activity activity, final ViewGroup viewGroup) {

        if (SharedPrefs.getInternetDilog(activity).equals("yes")){
            broadcastReceiver = new NetworkChangeListener();
            activity.registerReceiver(broadcastReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        }

        if (SharedPrefs.getAdsShow(activity).equals("yes")) {

            dialog = new Dialog(activity);
            View view = LayoutInflater.from(activity).inflate(R.layout.ads_loading, null);
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.setContentView(view);
            dialog.setCancelable(false);
            Window window = dialog.getWindow();
            window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!dialog.isShowing()) {
                        dialog.show();
                    }
                }
            }, 100);

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (dialog.isShowing()) {
                        dialog.dismiss();
                    }
                }
            }, 5000);


            if (SharedPrefs.getnativeiduse(activity) == 0) {
                SharedPrefs.setnativeiduse(activity, 1);
                nativeid = SharedPrefs.getapp_nativeid(activity);
            } else if (SharedPrefs.getnativeiduse(activity) == 1) {
                SharedPrefs.setnativeiduse(activity, 0);
                nativeid = SharedPrefs.getapp_nativeid1(activity);
            }
            fbnativeid = SharedPrefs.getapp_fbnativeid(activity);

            if (SharedPrefs.getnativeSpecific(activity) == 0) {
                nativebannerads(activity, viewGroup);
            } else if (SharedPrefs.getnativeSpecific(activity) == 1) {
                admobnativebannerads(activity, viewGroup);
            } else if (SharedPrefs.getnativeSpecific(activity) == 2) {
                fbshownativebanner(activity, viewGroup);
            }
        }
    }

    public void nativebannerads(final Activity activity, final ViewGroup viewGroup) {
        if (SharedPrefs.getnativeadsequence(activity) == 0) {
            AdLoader.Builder builder = new AdLoader.Builder(activity, nativeid);
            builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                @Override
                public void onNativeAdLoaded(@NonNull NativeAd nativeAd) {
                    new InflatAds(activity).inflat_admobnativebanner(nativeAd, viewGroup);
                    dialog.dismiss();


                }
            });
            AdLoader adLoader = builder.withAdListener(new AdListener() {
                @Override
                public void onAdFailedToLoad(LoadAdError loadAdError) {
                    fbshownativebanner(activity, viewGroup);
                }
            }).build();
            adLoader.loadAd(new AdRequest.Builder().build());
        } else if (SharedPrefs.getnativeadsequence(activity) == 1) {
            final com.facebook.ads.NativeAd nativeAd = new com.facebook.ads.NativeAd(activity, fbnativeid);
            nativeAd.loadAd(nativeAd.buildLoadAdConfig().withAdListener(new NativeAdListener() {
                public void onAdClicked(Ad ad) {
                }

                public void onLoggingImpression(Ad ad) {
                }

                public void onMediaDownloaded(Ad ad) {
                }

                public void onError(Ad ad, AdError adError) {
                    admobnativebannerads(activity, viewGroup);
                }

                public void onAdLoaded(Ad ad) {
                    new InflatAds(activity).inflate_fbnativebanner(nativeAd, viewGroup);
                    dialog.dismiss();
                }
            }).build());
        }
    }

    public void admobnativebannerads(final Activity activity, final ViewGroup viewGroup) {
        AdLoader.Builder builder = new AdLoader.Builder(activity, nativeid);
        builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
            @Override
            public void onNativeAdLoaded(@NonNull NativeAd nativeAd) {
                new InflatAds(activity).inflat_admobnativebanner(nativeAd, viewGroup);
                dialog.dismiss();
            }
        });
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
                dialog.dismiss();
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void fbshownativebanner(final Activity activity, final ViewGroup viewGroup) {
        final com.facebook.ads.NativeAd nativeAd = new com.facebook.ads.NativeAd(activity, fbnativeid);
        nativeAd.loadAd(nativeAd.buildLoadAdConfig().withAdListener(new NativeAdListener() {
            public void onAdClicked(Ad ad) {
            }

            public void onLoggingImpression(Ad ad) {
            }

            public void onMediaDownloaded(Ad ad) {
            }

            public void onError(Ad ad, AdError adError) {
                dialog.dismiss();
            }

            public void onAdLoaded(Ad ad) {
                new InflatAds(activity).inflate_fbnativebanner(nativeAd, viewGroup);
                dialog.dismiss();
            }
        }).build());
    }
}
