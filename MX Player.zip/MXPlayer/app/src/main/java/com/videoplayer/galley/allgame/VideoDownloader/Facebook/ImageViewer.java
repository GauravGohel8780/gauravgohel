package com.videoplayer.galley.allgame.VideoDownloader.Facebook;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import com.bumptech.glide.Glide;
import com.videoplayer.galley.allgame.R;

import java.io.File;
import java.net.URLConnection;

/* loaded from: classes4.dex */
public class ImageViewer extends AppCompatActivity {
    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_viewer);
        final String stringExtra = getIntent().getStringExtra("path");
        Glide.with((FragmentActivity) this).load(stringExtra).into((ImageView) findViewById(R.id.image));
        ((ImageButton) findViewById(R.id.share)).setOnClickListener(new View.OnClickListener() { // from class: com.lunarday.fbstorydownloader.activities.ImageViewer.1
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                ImageViewer.this.shareFile(new File(stringExtra));
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void shareFile(File file) {
        String substring = file.getAbsolutePath().substring(file.getAbsolutePath().lastIndexOf("."));
        try {
            StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType(URLConnection.guessContentTypeFromName("aaa" + substring));
            intent.putExtra("android.intent.extra.STREAM", Uri.parse("file://"+ file.getAbsolutePath()));
            startActivity(Intent.createChooser(intent, "Share File"));
        } catch (Exception unused) {
            Toast.makeText(this, "You don't have any app to open this file.", Toast.LENGTH_SHORT).show();
        }
    }
}
