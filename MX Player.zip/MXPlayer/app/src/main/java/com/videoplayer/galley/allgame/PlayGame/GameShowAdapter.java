package com.videoplayer.galley.allgame.PlayGame;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import com.videoplayer.galley.allgame.AdsDemo.Intertials;
import com.videoplayer.galley.allgame.R;

import java.util.List;

public class GameShowAdapter extends RecyclerView.Adapter<GameShowAdapter.ViewHolder> {

    List<ChildModelClass> gameshowList;
    Activity context;

    public GameShowAdapter(List<ChildModelClass> gameshowList, Activity context) {
        this.gameshowList = gameshowList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.game_show_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Glide.with(context).load(gameshowList.get(position).image).into(holder.iv_chile_image);
        holder.txt_child.setText(gameshowList.get(position).appname);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Intertials().ShowIntertistialAds(context, new Intertials.OnIntertistialAdsListner() {
                    public void onAdsDismissed() {
                        Uri uri = Uri.parse(gameshowList.get(position).url); // missing 'http://' will cause crashed
                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                        context.startActivity(intent);

                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return gameshowList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView iv_chile_image;
        TextView txt_child;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            iv_chile_image = itemView.findViewById(R.id.iv_child_item);
            txt_child = itemView.findViewById(R.id.txt_child);
        }
    }
}
