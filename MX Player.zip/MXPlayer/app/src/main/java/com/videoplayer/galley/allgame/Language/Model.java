package com.videoplayer.galley.allgame.Language;

import java.io.Serializable;

public class Model implements Serializable {

    private boolean isChecked = false;

    private String Laguage,oneword;

    public boolean isChecked() {
        return isChecked;
    }

    public void setChecked(boolean checked) {
        isChecked = checked;
    }

    public Model(String laguage, String oneword) {
        Laguage = laguage;
        this.oneword = oneword;
    }

    public String getLaguage() {
        return Laguage;
    }

    public void setLaguage(String laguage) {
        Laguage = laguage;
    }

    public String getOneword() {
        return oneword;
    }

    public void setOneword(String oneword) {
        this.oneword = oneword;
    }
}
