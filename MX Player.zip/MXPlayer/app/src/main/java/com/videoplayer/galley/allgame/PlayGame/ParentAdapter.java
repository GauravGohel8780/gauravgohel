package com.videoplayer.galley.allgame.PlayGame;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.videoplayer.galley.allgame.AdsDemo.Intertials;
import com.videoplayer.galley.allgame.R;

import java.util.ArrayList;

public class ParentAdapter extends RecyclerView.Adapter<ParentAdapter.ViewHolder> {

    ArrayList<ParentModelClass> parentModelClassList;
    Activity context;
    private final itemClickListener picListerner;

    public ParentAdapter(ArrayList<ParentModelClass> parentModelClassList, Activity context, itemClickListener picListerner) {
        this.parentModelClassList = parentModelClassList;
        this.context = context;
        this.picListerner = picListerner;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.parent_rv_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.tv_parent_title.setText(parentModelClassList.get(position).title);

        ChildAdapter childAdapter;
        childAdapter = new ChildAdapter(parentModelClassList.get(position).childModelClassList, context);
        holder.rv_child.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));
        holder.rv_child.setAdapter(childAdapter);
        childAdapter.notifyDataSetChanged();


        holder.tv_parent_title_more.setOnClickListener(view -> {
            new Intertials().ShowIntertistialAds(context, new Intertials.OnIntertistialAdsListner() {
                public void onAdsDismissed() {
                    picListerner.onPicClicked(holder, position, parentModelClassList.get(position).childModelClassList);
                }
            });
        });
    }

    @Override
    public int getItemCount() {
        return parentModelClassList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        RecyclerView rv_child;
        public TextView tv_parent_title, tv_parent_title_more;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            rv_child = itemView.findViewById(R.id.rv_child);
            tv_parent_title = itemView.findViewById(R.id.tv_parent_title);
            tv_parent_title_more = itemView.findViewById(R.id.tv_parent_title_more);
        }
    }
}
