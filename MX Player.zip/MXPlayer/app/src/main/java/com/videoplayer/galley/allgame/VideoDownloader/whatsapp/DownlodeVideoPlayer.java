package com.videoplayer.galley.allgame.VideoDownloader.whatsapp;


import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Point;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.PlaybackParams;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.GestureDetectorCompat;


import com.videoplayer.galley.allgame.R;


public class DownlodeVideoPlayer extends AppCompatActivity implements View.OnTouchListener, ScaleGestureDetector.OnScaleGestureListener, View.OnClickListener {

    RelativeLayout zoomLayout;
    boolean isOpen = true;
    ScaleGestureDetector scaleDetector;
    GestureDetectorCompat gestureDetector;
    private static final float MIN_ZOOM = 1.0f;
    private static final float MAX_ZOOM = 5.0f;
    boolean intLeft, intRight;
    private Display display;
    private Point size;
    private Mode mode = Mode.NONE;


    private enum Mode {
        NONE, DRAG, ZOOM;
    }

    int device_width;
    private int sWidth;
    private boolean isEnable = true;
    private float scale = 1.0f;
    private float lastScaleFactor = 0f;

    private float startX = 0f;
    private float startY = 0f;

    private float dx = 0f;
    private float dy = 0f;
    private float prevDx = 0f;
    private float prevDy = 0f;

    int position = -1;
    private VideoView videoView;
    RelativeLayout three;
    LinearLayout one, two, four, five, lockControls, unlockControls, rotate, audioTrack;
    ImageButton goBack, rewind, forward, playPause;
    TextView title, endTime, videoView_Speed;
    SeekBar videoSeekBar;
    ImageView soundimg;
    private static int aux = 0;

    PopupWindow mypopupWindow;
    PlaybackParams myPlayBackParams = null;

    @Override
    public boolean onTouch(View view, MotionEvent event) {
        switch (event.getAction() & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN:
                hideDefaultControls();
                if (scale > MIN_ZOOM) {
                    mode = Mode.DRAG;
                    startX = event.getX() - prevDx;
                    startY = event.getY() - prevDy;
                }
                break;
            case MotionEvent.ACTION_MOVE:
                hideDefaultControls();
                isEnable = false;
                if (mode == Mode.DRAG) {
                    dx = event.getX() - startX;
                    dy = event.getY() - startY;
                }
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                mode = Mode.ZOOM;
                break;
            case MotionEvent.ACTION_POINTER_UP:
                mode = Mode.DRAG;
                break;
            case MotionEvent.ACTION_UP:
                mode = Mode.NONE;
                prevDx = dx;
                prevDy = dy;
                break;
        }
        scaleDetector.onTouchEvent(event);
        gestureDetector.onTouchEvent(event);
        if ((mode == Mode.DRAG && scale >= MIN_ZOOM) || mode == Mode.ZOOM) {
            zoomLayout.requestDisallowInterceptTouchEvent(true);
            float maxDx = (child().getWidth() - (child().getWidth() / scale)) / 2 * scale;
            float maxDy = (child().getHeight() - (child().getHeight() / scale)) / 2 * scale;
            dx = Math.min(Math.max(dx, -maxDx), maxDx);
            dy = Math.min(Math.max(dy, -maxDy), maxDy);
            applyScaleAndTranslation();
        }
        return true;
    }

    private void applyScaleAndTranslation() {
        child().setScaleX(scale);
        child().setScaleY(scale);
        child().setTranslationX(dx);
        child().setTranslationY(dy);
    }

    private View child() {
        return zoomLayout(0);
    }

    private View zoomLayout(int i) {
        return videoView;
    }

    @Override
    public boolean onScale(ScaleGestureDetector scaleGestureDetector) {
        float scaleFactor = scaleDetector.getScaleFactor();
        if (lastScaleFactor == 0 || (Math.signum(scaleFactor) == Math.signum(lastScaleFactor))) {
            scale *= scaleFactor;
            scale = Math.max(MIN_ZOOM, Math.min(scale, MAX_ZOOM));
            lastScaleFactor = scaleFactor;
        } else {
            lastScaleFactor = 0;
        }
        return true;
    }

    @Override
    public boolean onScaleBegin(ScaleGestureDetector scaleGestureDetector) {
        return true;
    }

    @Override
    public void onScaleEnd(ScaleGestureDetector scaleGestureDetector) {

    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_downlode_video_player);

        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.black));


        videoView = findViewById(R.id.video_view);
        zoomLayout = findViewById(R.id.zoom_layout);
        one = findViewById(R.id.videoView_one_layout);
        two = findViewById(R.id.videoView_four_two_child_layout);
        three = findViewById(R.id.videoView_three_layout);
        four = findViewById(R.id.videoView_four_layout);
        five = findViewById(R.id.video_five_layout);
        lockControls = findViewById(R.id.videoView_lock_screen);
        unlockControls = findViewById(R.id.video_five_child_layout);
        videoView_Speed = findViewById(R.id.videoView_Speed);


        rotate = findViewById(R.id.videoView_rotation);
        audioTrack = findViewById(R.id.videoView_track);

        goBack = findViewById(R.id.videoView_go_back);
        title = findViewById(R.id.videoView_title);
        rewind = findViewById(R.id.videoView_rewind);
        playPause = findViewById(R.id.videoView_play_pause_btn);
        forward = findViewById(R.id.videoView_forward);
        endTime = findViewById(R.id.videoView_endtime);
        videoSeekBar = findViewById(R.id.videoView_seekbar);
        soundimg = findViewById(R.id.soundimg);


        goBack.setOnClickListener(this);
        rewind.setOnClickListener(this);
        playPause.setOnClickListener(this);
        forward.setOnClickListener(this);
        lockControls.setOnClickListener(this);
        five.setOnClickListener(this);
        unlockControls.setOnClickListener(this);
        rotate.setOnClickListener(this);

        videoView_Speed.setOnClickListener(view -> {
            mypopupWindow.showAsDropDown(view, -40, -620);
        });
        videoView_Speed.setText("1.0x");


        position = getIntent().getIntExtra("videoPath", -1);
        title.setText(FullscreenImageAdapter.imageList.get(position).getFileName());
        String path = FullscreenImageAdapter.imageList.get(position).getFilePath();
        if (path != null) {
            videoView.setVideoPath(path);
            videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mediaPlayer) {

                    LayoutInflater inflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    View view = inflater.inflate(R.layout.password_type_dialog, null);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        myPlayBackParams = new PlaybackParams();
                        mediaPlayer.setPlaybackParams(myPlayBackParams.setSpeed(SharedPrefs.getVideo_speed(DownlodeVideoPlayer.this)));
                    }

                    TextView tv05x = view.findViewById(R.id.tv05x);
                    TextView tv10x = view.findViewById(R.id.tv10x);
                    TextView tv15x = view.findViewById(R.id.tv15x);
                    TextView tv20x = view.findViewById(R.id.tv20x);
                    TextView tv30x = view.findViewById(R.id.tv30x);

                    tv05x.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            SharedPrefs.setVideo_speed(DownlodeVideoPlayer.this, 0.5f);
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                myPlayBackParams = new PlaybackParams();
                                mediaPlayer.setPlaybackParams(myPlayBackParams.setSpeed(SharedPrefs.getVideo_speed(DownlodeVideoPlayer.this)));
                            }
                            videoView_Speed.setText("0.5x");
                            mypopupWindow.dismiss();

                        }
                    });

                    tv10x.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            SharedPrefs.setVideo_speed(DownlodeVideoPlayer.this, 1.0f);
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                myPlayBackParams = new PlaybackParams();
                                mediaPlayer.setPlaybackParams(myPlayBackParams.setSpeed(SharedPrefs.getVideo_speed(DownlodeVideoPlayer.this)));
                            }
                            videoView_Speed.setText("1.0x");
                            mypopupWindow.dismiss();

                        }
                    });

                    tv15x.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            SharedPrefs.setVideo_speed(DownlodeVideoPlayer.this, 1.5f);
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                myPlayBackParams = new PlaybackParams();
                                mediaPlayer.setPlaybackParams(myPlayBackParams.setSpeed(SharedPrefs.getVideo_speed(DownlodeVideoPlayer.this)));
                            }
                            videoView_Speed.setText("1.5x");
                            mypopupWindow.dismiss();
                        }
                    });

                    tv20x.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            SharedPrefs.setVideo_speed(DownlodeVideoPlayer.this, 2.0f);
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                myPlayBackParams = new PlaybackParams();
                                mediaPlayer.setPlaybackParams(myPlayBackParams.setSpeed(SharedPrefs.getVideo_speed(DownlodeVideoPlayer.this)));
                            }
                            videoView_Speed.setText("2.0x");
                            mypopupWindow.dismiss();

                        }
                    });

                    tv30x.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            SharedPrefs.setVideo_speed(DownlodeVideoPlayer.this, 3.0f);
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                myPlayBackParams = new PlaybackParams();
                                mediaPlayer.setPlaybackParams(myPlayBackParams.setSpeed(SharedPrefs.getVideo_speed(DownlodeVideoPlayer.this)));
                            }
                            videoView_Speed.setText("3.0x");
                            mypopupWindow.dismiss();
                        }
                    });


                    mypopupWindow = new PopupWindow(view, RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT, true);


                    videoSeekBar.setMax(videoView.getDuration());
                    videoView.start();
                    audioTrack.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            voicemute();


                        }
                    });
                }
            });
        } else {
            Toast.makeText(this, "Path didn't exists", Toast.LENGTH_SHORT).show();
        }

        zoomLayout = findViewById(R.id.zoom_layout);
        display = getWindowManager().getDefaultDisplay();
        size = new Point();
        display.getSize(size);
        sWidth = size.x;
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        device_width = displayMetrics.widthPixels;
        zoomLayout.setOnTouchListener(this);
        scaleDetector = new ScaleGestureDetector(getApplicationContext(), this);
        gestureDetector = new GestureDetectorCompat(getApplicationContext(), new GestureDetector());


        initalizeSeekBars();
        setHandler();


    }

    private void voicemute() {
        AudioManager mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        if (aux % 2 == 0) {
            mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0);
            aux++;
            soundimg.setImageDrawable(getResources().getDrawable(R.drawable.unmute));
        } else {
            mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 7, 0);
            aux++;
            soundimg.setImageDrawable(getResources().getDrawable(R.drawable.mute));
        }
    }


    private void initalizeSeekBars() {
        videoSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if (videoSeekBar.getId() == R.id.videoView_seekbar) {
                    if (b) {
                        videoView.seekTo(i);
                        videoView.start();
                        int currentPosition = videoView.getCurrentPosition();
                        endTime.setText("" + convertIntoTime(videoView.getDuration() - currentPosition));
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    public static String convertIntoTime(int ms) {
        String time;
        int x, seconds, minutes, hours;
        x = ms / 1000;
        seconds = x % 60;
        x /= 60;
        minutes = x % 60;
        x /= 60;
        hours = x % 24;
        if (hours != 0)
            time = String.format("%02d", hours) + ":" + String.format("%02d", minutes) + ":" + String.format("%02d", seconds);
        else time = String.format("%02d", minutes) + ":" + String.format("%02d", seconds);
        return time;
    }

    private void setHandler() {
        Handler handler = new Handler();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                if (videoView.getDuration() > 0) {
                    int currentPosition = videoView.getCurrentPosition();
                    videoSeekBar.setProgress(currentPosition);
                    endTime.setText("" + convertIntoTime(videoView.getDuration() - currentPosition));
                }
                handler.postDelayed(this, 0);
            }
        };
        handler.postDelayed(runnable, 500);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.videoView_rotation:
                int orientation = getResources().getConfiguration().orientation;
                if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                } else if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                }
                break;

            case R.id.videoView_lock_screen:
                hideDefaultControls();
                five.setVisibility(View.VISIBLE);
                break;

            case R.id.video_five_layout:
                if (isOpen) {
                    unlockControls.setVisibility(View.INVISIBLE);
                    isOpen = false;
                } else {
                    unlockControls.setVisibility(View.VISIBLE);
                    isOpen = true;
                }
                break;

            case R.id.video_five_child_layout:
                five.setVisibility(View.GONE);
                showDefaultControls();
                break;

            case R.id.videoView_go_back:
                onBackPressed();
                aux = 0;
                break;

            case R.id.videoView_rewind:
                videoView.seekTo(videoView.getCurrentPosition() - 10000);
                break;

            case R.id.videoView_forward:
                videoView.seekTo(videoView.getCurrentPosition() + 10000);
                break;

            case R.id.videoView_play_pause_btn:
                if (videoView.isPlaying()) {
                    videoView.pause();
                    playPause.setImageDrawable(getResources().getDrawable(R.drawable.ic_play));
                } else {
                    videoView.start();
                    playPause.setImageDrawable(getResources().getDrawable(R.drawable.netflix_pause_button));
                }
                break;
        }
    }

    private class GestureDetector extends android.view.GestureDetector.SimpleOnGestureListener {

        @Override
        public boolean onSingleTapConfirmed(MotionEvent e) {
            if (isEnable) {
                hideDefaultControls();
                isEnable = false;
            } else {
                showDefaultControls();
                isEnable = true;
            }
            return super.onSingleTapConfirmed(e);
        }

        @Override
        public boolean onDoubleTap(MotionEvent event) {
            if (event.getX() < (sWidth / 2)) {
                intLeft = true;
                intRight = false;
                videoView.seekTo(videoView.getCurrentPosition() - 20000);
//                Toast.makeText(DownlodeVideoPlayer.this, "-20sec", Toast.LENGTH_SHORT).show();
            } else if (event.getX() > (sWidth / 2)) {
                intLeft = false;
                intRight = true;
                videoView.seekTo(videoView.getCurrentPosition() + 20000);
//                Toast.makeText(DownlodeVideoPlayer.this, "+20sec", Toast.LENGTH_SHORT).show();
            }
            return super.onDoubleTap(event);
        }
    }

    private void hideDefaultControls() {
        one.setVisibility(View.GONE);
        two.setVisibility(View.GONE);
        three.setVisibility(View.GONE);
        four.setVisibility(View.GONE);

        final Window window = this.getWindow();
        if (window == null) {
            return;
        }
        window.clearFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        final View decorview = window.getDecorView();
        if (decorview != null) {
            int uiOption = decorview.getSystemUiVisibility();
            if (Build.VERSION.SDK_INT >= 14) {
                uiOption |= View.SYSTEM_UI_FLAG_LOW_PROFILE;
            }

            if (Build.VERSION.SDK_INT >= 16) {
                uiOption |= View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
            }

            if (Build.VERSION.SDK_INT >= 19) {
                uiOption |= View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            }
            decorview.setSystemUiVisibility(uiOption);
        }
    }

    private void showDefaultControls() {
        one.setVisibility(View.VISIBLE);
        two.setVisibility(View.VISIBLE);
        three.setVisibility(View.VISIBLE);
        four.setVisibility(View.VISIBLE);

        final Window window = this.getWindow();
        if (window == null) {
            return;
        }
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        window.addFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
        final View decorview = window.getDecorView();
        if (decorview != null) {
            int uiOption = decorview.getSystemUiVisibility();
            if (Build.VERSION.SDK_INT >= 14) {
                uiOption &= ~View.SYSTEM_UI_FLAG_LOW_PROFILE;
            }

            if (Build.VERSION.SDK_INT >= 16) {
                uiOption &= ~View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
            }

            if (Build.VERSION.SDK_INT >= 19) {
                uiOption &= ~View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            }
            decorview.setSystemUiVisibility(uiOption);
        }
    }
}