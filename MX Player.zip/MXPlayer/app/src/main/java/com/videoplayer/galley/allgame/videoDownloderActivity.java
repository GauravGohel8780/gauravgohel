package com.videoplayer.galley.allgame;




import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.LinearLayout;


import com.videoplayer.galley.allgame.AdsDemo.Intertials;
import com.videoplayer.galley.allgame.AdsDemo.Native;

public class videoDownloderActivity extends AppCompatActivity {

    LinearLayout startbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_downloder);

        new Native().shownativeads(this, findViewById(R.id.native_container));

        startbtn = findViewById(R.id.startbtn);

        startbtn.setOnClickListener(view -> {
            new Intertials().ShowIntertistialAds(this, new Intertials.OnIntertistialAdsListner() {
                public void onAdsDismissed() {
                    startActivity(new Intent(videoDownloderActivity.this, FirstActivity.class));
                }
            });
        });
    }
}