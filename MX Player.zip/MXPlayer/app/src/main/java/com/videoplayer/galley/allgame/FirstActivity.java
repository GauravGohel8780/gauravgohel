package com.videoplayer.galley.allgame;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import com.videoplayer.galley.allgame.AdsDemo.First_User_EnterDiloge;
import com.videoplayer.galley.allgame.AdsDemo.Intertials;
import com.videoplayer.galley.allgame.AdsDemo.Native;
import com.videoplayer.galley.allgame.AdsDemo.RateUsDialog;
import com.videoplayer.galley.allgame.AdsDemo.SharedPrefs;
import com.videoplayer.galley.allgame.Language.LanguageActivity;
import com.videoplayer.galley.allgame.R;

public class FirstActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_RUNNER = 123;
    boolean firstdilog = true;
    Dialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);


        if (Build.VERSION.SDK_INT >= 33) {
            if (!(ActivityCompat.checkSelfPermission(FirstActivity.this, "android.permission.READ_MEDIA_VIDEO") == 0 && ActivityCompat.checkSelfPermission(FirstActivity.this, "android.permission.READ_MEDIA_IMAGES") == 0 || ActivityCompat.checkSelfPermission(FirstActivity.this, "android.permission.READ_MEDIA_AUDIO") == 0) && !(ActivityCompat.checkSelfPermission(FirstActivity.this, "android.permission.READ_EXTERNAL_STORAGE") == 0)) {
                ActivityCompat.requestPermissions(FirstActivity.this, new String[]{"android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_AUDIO"},
                        REQUEST_CODE_RUNNER);
            }
        } else {
            if (ContextCompat.checkSelfPermission(FirstActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(FirstActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        REQUEST_CODE_RUNNER);
            }
        }

        if (SharedPrefs.getchackReferrer(FirstActivity.this).equals("no")) {
            if (SharedPrefs.getChackUserinet(FirstActivity.this).equals("utm_source")) {
                new First_User_EnterDiloge(this).FirstTimeDilog();
            }
        } else if (SharedPrefs.getchackReferrer(FirstActivity.this).equals("yes")) {
            new First_User_EnterDiloge(this).FirstTimeDilog();
        }


        new Native().shownativeads(this, findViewById(R.id.native_container));
        SharedPrefs.setFirst_chike(FirstActivity.this, true);
        com.videoplayer.galley.allgame.VideoPlayer.SharedPrefs.setmainchack(this, true);

        findViewById(R.id.start).setOnClickListener(view -> {
            new Intertials().ShowIntertistialAds(this, new Intertials.OnIntertistialAdsListner() {
                public void onAdsDismissed() {
                    startActivity(new Intent(FirstActivity.this, SecondActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                }
            });
        });

        findViewById(R.id.share).setOnClickListener(view -> {
            try {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_SUBJECT, "My application name");
                String shareMessage = "\nLet me recommend you this application\n\n";
                shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "\n\n";
                shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                startActivity(Intent.createChooser(shareIntent, "choose one"));
            } catch (Exception e) {
                //e.toString();
            }
        });
        findViewById(R.id.rate).setOnClickListener(view -> {
            Uri uri = Uri.parse("market://details?id=" + getPackageName());
            Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
            try {
                startActivity(myAppLinkToMarket);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this, " unable to find market app", Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_RUNNER) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                permissiondialog();
            }
        }
    }

    private void permissiondialog() {
        dialog = new Dialog(this);
        dialog.setContentView(R.layout.dillog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setCancelable(false);
        Window window = dialog.getWindow();
        WindowManager.LayoutParams attributes = window.getAttributes();
        attributes.gravity = Gravity.CENTER;
        window.setAttributes(attributes);
        dialog.show();

        Button btnp = dialog.findViewById(R.id.btntry);
        btnp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });
    }

    private boolean checkWriteExternalPermission() {
        int res;
        if (Build.VERSION.SDK_INT >= 33) {
            String permission = Manifest.permission.READ_MEDIA_AUDIO;
            res = checkCallingOrSelfPermission(permission);
        } else {
            String permission = Manifest.permission.WRITE_EXTERNAL_STORAGE;
            res = checkCallingOrSelfPermission(permission);
        }
        return (res == PackageManager.PERMISSION_GRANTED);
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkWriteExternalPermission();
    }


    @Override
    public void onBackPressed() {
        if (SharedPrefs.getchackReferrer(FirstActivity.this).equals("no")) {
            if (SharedPrefs.getChackUserinet(FirstActivity.this).equals("utm_source")) {
                new RateUsDialog(this).ShowRateUsDialog();
            } else {
                super.onBackPressed();
            }
        } else if (SharedPrefs.getchackReferrer(FirstActivity.this).equals("yes")) {
            new RateUsDialog(this).ShowRateUsDialog();
        } else if (SharedPrefs.getchackReferrer(FirstActivity.this).equals("other")) {
            super.onBackPressed();
        }
    }
}