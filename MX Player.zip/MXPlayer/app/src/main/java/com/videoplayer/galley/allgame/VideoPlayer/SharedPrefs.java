package com.videoplayer.galley.allgame.VideoPlayer;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatDelegate;

public class SharedPrefs {

    public static final String PREF_NIGHT_MODE = "night_mode";
    private static SharedPreferences mPreferences;
    public static final String Video_speed = "Video_speed";

    public static final String First_download = "First_download";
    public static final String First_dialog = "First_dialog";
    public static final String chackpsition = "chackpsition";
    public static final String chackgetornot = "chackgetornot";
    public static final String mainchack = "mainchack";

    private static SharedPreferences getInstance(Context context) {
        if (mPreferences == null) {
            mPreferences = context.getApplicationContext()
                    .getSharedPreferences("all_saver_data", Context.MODE_PRIVATE);
        }
        return mPreferences;
    }

    public static int getInt(Context context, String key, int defaultValue) {
        return getInstance(context).getInt(key, defaultValue);
    }

    public static void setInt(Context context, String key, int value) {
        getInstance(context).edit().putInt(key, value).apply();
    }

    public static void clearPrefs(Context context) {
        getInstance(context).edit().clear().apply();
    }

    public static int getAppNightDayMode(Context context) {
        return getInt(context, PREF_NIGHT_MODE, AppCompatDelegate.MODE_NIGHT_NO);
    }

    public static void setFirst_dialog(Context context, String value) {
        getInstance(context).edit().putString(First_dialog, value).apply();
    }

    public static String getFirst_dialog(Context context) {
        return getInstance(context).getString(First_dialog, "");
    }

    public static void setchackpsition(Context context, int value) {
        getInstance(context).edit().putInt(chackpsition, value).apply();
    }

    public static int getchackpsition(Context context) {
        return getInstance(context).getInt(chackpsition, 0);
    }

    public static void setFirst_download(Context context, boolean b) {
        getInstance(context).edit().putBoolean(First_download, b).apply();
    }

    public static boolean getFirst_download(Context context) {
        return getInstance(context).getBoolean(First_download, false);
    }

    public static void setmainchack(Context context, boolean b) {
        getInstance(context).edit().putBoolean(mainchack, b).apply();
    }

    public static boolean getmainchack(Context context) {
        return getInstance(context).getBoolean(mainchack, false);
    }

    public static void setchackgetornot(Context context, boolean b) {
        getInstance(context).edit().putBoolean(chackgetornot, b).apply();
    }

    public static boolean getchackgetornot(Context context) {
        return getInstance(context).getBoolean(chackgetornot, false);
    }


    public static void setVideo_speed(Context context, float value) {
        getInstance(context).edit().putFloat(Video_speed, value).apply();
    }

    public static float getVideo_speed(Context context) {
        return getInstance(context).getFloat(Video_speed, 1.0f);
    }
}
