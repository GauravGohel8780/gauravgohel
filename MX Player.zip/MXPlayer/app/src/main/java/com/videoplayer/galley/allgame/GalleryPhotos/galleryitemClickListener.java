package com.videoplayer.galley.allgame.GalleryPhotos;


import java.util.ArrayList;


public interface galleryitemClickListener {

    void onPicClicked(PhotoItemAdapter.PicHolder holder, int position, ArrayList<PhotoItemModel> pics);
    void onPicClicked(String pictureFolderPath,String folderName);
}
