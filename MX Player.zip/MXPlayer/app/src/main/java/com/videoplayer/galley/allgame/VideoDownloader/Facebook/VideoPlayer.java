package com.videoplayer.galley.allgame.VideoDownloader.Facebook;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.ui.PlayerView;
import com.videoplayer.galley.allgame.R;

import java.io.File;
import java.net.URLConnection;

/* loaded from: classes4.dex */
public class VideoPlayer extends AppCompatActivity {
    ExoPlayer player;
    PlayerView videoView;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player_db);
        final String stringExtra = getIntent().getStringExtra("path");
        this.videoView = (PlayerView) findViewById(R.id.video_view);
        ExoPlayer build = new ExoPlayer.Builder(this).build();
        this.player = build;
        this.videoView.setPlayer(build);
        try {
            this.player.setMediaItem(MediaItem.fromUri(stringExtra));
            this.player.prepare();
            this.player.play();
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        ((ImageButton) findViewById(R.id.share)).setOnClickListener(new View.OnClickListener() { // from class: com.lunarday.fbstorydownloader.activities.VideoPlayer.1
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                VideoPlayer.this.shareFile(new File(stringExtra));
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void shareFile(File file) {
        String substring = file.getAbsolutePath().substring(file.getAbsolutePath().lastIndexOf("."));
        try {
            StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType(URLConnection.guessContentTypeFromName("aaa" + substring));
            intent.putExtra("android.intent.extra.STREAM", Uri.parse("file://"+ file.getAbsolutePath()));
            startActivity(Intent.createChooser(intent, "Share File"));
        } catch (Exception unused) {
            Toast.makeText(this, "You don't have any app to open this file.", Toast.LENGTH_SHORT).show();
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onPause() {
        super.onPause();
        this.player.pause();
    }
}
