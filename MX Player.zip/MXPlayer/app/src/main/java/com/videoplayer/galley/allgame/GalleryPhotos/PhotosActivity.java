package com.videoplayer.galley.allgame.GalleryPhotos;




import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.ViewGroup;


import com.videoplayer.galley.allgame.AdsDemo.Banner;
import com.videoplayer.galley.allgame.R;

import java.util.ArrayList;

public class PhotosActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<PhotoModel> arrayList = new ArrayList<>();
    PhotoAdapter adapter;
    GridLayoutManager gridLayoutManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photos);

        new Banner().showbannerads(this, findViewById(R.id.banner_container));

        recyclerView = findViewById(R.id.recyclerfolder);
        recyclerView.setHasFixedSize(true);
        gridLayoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(gridLayoutManager);
        arrayList = getPicturePaths();

        adapter = new PhotoAdapter(arrayList, this);
        recyclerView.setAdapter(adapter);

    }

    private ArrayList<PhotoModel> getPicturePaths() {

        ArrayList<String> picPaths = new ArrayList<>();
        Uri allImagesuri = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Images.ImageColumns.DATA,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
                MediaStore.Images.Media.BUCKET_ID};

        Cursor cursor = getContentResolver().query(allImagesuri, projection, null, null, null);

        try {
            if (cursor != null) {
                cursor.moveToFirst();
            }
            do {
                PhotoModel model = new PhotoModel();
                String name = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME));
                String folder = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME));
                String datapath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA));


                String folderpaths = datapath.substring(0, datapath.lastIndexOf(folder + "/"));
                folderpaths = folderpaths + folder + "/";
                if (!picPaths.contains(folderpaths)) {
                    picPaths.add(folderpaths);

                    model.setPath(folderpaths);
                    model.setFolderName(folder);
                    model.setFirstPic(datapath);
                    model.addpics();
                    arrayList.add(model);
                } else {
                    for (int i = 0; i < arrayList.size(); i++) {

                        model = (PhotoModel) arrayList.get(i);
                        if (model.getPath().equals(folderpaths)) {
                            model.setFirstPic(datapath);
                            model.addpics();
                        }
                    }
                }
            } while (cursor.moveToNext());
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return arrayList;
    }

}