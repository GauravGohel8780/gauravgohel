package com.videoplayer.galley.allgame;

import android.content.Intent;
import android.os.Bundle;

import com.videoplayer.galley.allgame.AdsDemo.Native;
import com.videoplayer.galley.allgame.Language.AppCompat;

public class SecondActivity extends AppCompat {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_second);

        new Native().shownativeads(this, findViewById(R.id.native_container));


        findViewById(R.id.startbtn).setOnClickListener(view -> {
            startActivity(new Intent(SecondActivity.this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}