package com.videoplayer.galley.allgame.VideoPlayer;


import java.util.ArrayList;


public interface galleryVideoitemClickListener {

    void onPicClicked(VideoItemAdapter.PicHolder holder, int position, ArrayList<VideoItemModel> pics);
    void onPicClicked(String pictureFolderPath,String folderName);
}
