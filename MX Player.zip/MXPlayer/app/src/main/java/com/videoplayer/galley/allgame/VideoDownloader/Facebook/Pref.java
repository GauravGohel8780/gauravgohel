package com.videoplayer.galley.allgame.VideoDownloader.Facebook;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

/* loaded from: classes4.dex */
public class Pref {
    Context context;
    String fc;
    Gson gson = new Gson();

    public Pref(Context context) {
        this.context = context;
    }

    public void write(String key, String data) {
        Context context = this.context;
        SharedPreferences.Editor edit = context.getSharedPreferences(context.getPackageName(), 0).edit();
        edit.putString(key, data);
        edit.commit();
    }

    public String read(String key) {
        Context context = this.context;
        return context.getSharedPreferences(context.getPackageName(), 0).getString(key, "null");
    }

    public void saveDownloadId(int id) {
        JSONArray jSONArray;
        try {
            jSONArray = new JSONArray(read("downloads"));
        } catch (JSONException e2) {
            e2.printStackTrace();
            jSONArray = new JSONArray();
        }
        jSONArray.put(id);
        write("downloads", jSONArray.toString());
    }

    public List<Integer> getDownloadIds() {
        JSONArray jSONArray;
        ArrayList arrayList = new ArrayList();
        try {
            jSONArray = new JSONArray(read("downloads"));
        } catch (JSONException e2) {
            e2.printStackTrace();
            jSONArray = new JSONArray();
        }
        for (int length = jSONArray.length() - 1; length >= 0; length--) {
            try {
                arrayList.add(Integer.valueOf(jSONArray.getInt(length)));
            } catch (JSONException e3) {
                e3.printStackTrace();
            }
        }
        return arrayList;
    }

    public void saveStories(List<StoryModel> list) {
        String json = this.gson.toJson(list, new TypeToken<List<StoryModel>>() { // from class: com.lunarday.fbstorydownloader.Pref.1
        }.getType());
        Log.i("savedStories", json + "aa");
        write("stories" + read("c_user"), json);
    }

    public List<StoryModel> getSavedStories() {
        try {
            List<StoryModel> list = (List) this.gson.fromJson(read("stories" + read("c_user")), new TypeToken<List<StoryModel>>() { // from class: com.lunarday.fbstorydownloader.Pref.2
            }.getType());
            Log.i("savedStories_size", list.size() + "aa");
            return list;
        } catch (Exception e2) {
            e2.printStackTrace();
            return new ArrayList();
        }
    }

    public int getDownloadCount() {
        try {
            return Integer.parseInt(read("DownloadCount"));
        } catch (Exception unused) {
            return 0;
        }
    }

    public void increaseDownlodCount() {
        write("DownloadCount", (getDownloadCount() + 1) + "");
    }

    public boolean isRated() {
        try {
            return Boolean.parseBoolean(read("isRated"));
        } catch (Exception unused) {
            return false;
        }
    }

    public void setRatedSucessFully() {
        write("isRated", "true");
    }

    public int getPermissionState(String type) {
        try {
            String read = read("request"+ type);
            Log.i("requst_code", "request"+ read);
            return Integer.parseInt(read);
        } catch (Exception e2) {
            e2.printStackTrace();
            return 1;
        }
    }

    public void setPermissionState(String type, int code) {
        write("request"+ type, code + "");
    }

    public void setFbLogin(boolean value) {
        write("login", value + "");
    }

    public void fbLogout() {
        write("login", "false");
        CookieManager cookieManager = CookieManager.getInstance();
        this.fc = cookieManager.getCookie("https://www.instagram.com");
        cookieManager.removeAllCookies(new ValueCallback<Boolean>() { // from class: com.lunarday.fbstorydownloader.Pref.3
            @Override // android.webkit.ValueCallback
            public void onReceiveValue(Boolean value) {
            }
        });
        String str = this.fc;
        if (str == null) {
            return;
        }
        for (String str2 : str.split(";")) {
            cookieManager.setCookie("https://www.instagram.com", str2);
        }
        Log.i("cookie__", this.fc);
        cookieManager.flush();
    }

    public boolean isFbLoogedin() {
        try {
            boolean parseBoolean = Boolean.parseBoolean(read("login"));
            Log.i("MainActivity__", parseBoolean + " login status");
            return parseBoolean;
        } catch (Exception unused) {
            return false;
        }
    }

    public void setInstaLogin(boolean value) {
        write("login_insta", value + "");
    }

    public void instaLogout() {
        write("login_insta", "true");
        CookieManager cookieManager = CookieManager.getInstance();
        this.fc = cookieManager.getCookie("https://www.facebook.com");
        cookieManager.removeAllCookies(new ValueCallback<Boolean>() { // from class: com.lunarday.fbstorydownloader.Pref.4
            @Override // android.webkit.ValueCallback
            public void onReceiveValue(Boolean value) {
            }
        });
        for (String str : this.fc.split(";")) {
            cookieManager.setCookie("https://www.facebook.com", str);
        }
        Log.i("cookie__", this.fc);
        cookieManager.flush();
    }

    public boolean isInstaLoogedin() {
        try {
            return Boolean.parseBoolean(read("login_insta"));
        } catch (Exception unused) {
            return false;
        }
    }

    public void setPremium(boolean value) {
        write("isPremium", value + "");
    }

    public boolean isPremium() {
        try {
            return Boolean.parseBoolean(read("isPremium"));
        } catch (Exception unused) {
            return true;
        }
    }

    public String getPrice() {
        return read("price").equals("null") ? "$6" : read("price");
    }

    public void setPrice(String price) {
        write("price", price);
    }

    public void setNoSeen(boolean v) {
        write("noseen", v + "");
    }

    public boolean isNoSeen() {
        try {
            return Boolean.parseBoolean(read("noseen"));
        } catch (Exception unused) {
            return false;
        }
    }
}
