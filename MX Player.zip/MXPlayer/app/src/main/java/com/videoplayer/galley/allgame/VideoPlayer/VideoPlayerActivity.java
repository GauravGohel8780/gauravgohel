package com.videoplayer.galley.allgame.VideoPlayer;




import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.ViewGroup;


import com.videoplayer.galley.allgame.AdsDemo.Banner;
import com.videoplayer.galley.allgame.R;

import java.util.ArrayList;

public class VideoPlayerActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<VideoModel> arrayList = new ArrayList<>();
    VideoAdapter adapter;
    LinearLayoutManager gridLayoutManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player);

        new Banner().showbannerads(this, findViewById(R.id.banner_container));

        recyclerView = findViewById(R.id.recyclervideo);
        recyclerView.setHasFixedSize(true);

        gridLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(gridLayoutManager);
        arrayList = getPicturePaths();

        adapter = new VideoAdapter(arrayList, this);
        recyclerView.setAdapter(adapter);
    }

    private ArrayList<VideoModel> getPicturePaths() {

        ArrayList<String> picPaths = new ArrayList<>();
        Uri allImagesuri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Video.VideoColumns.DATA,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
                MediaStore.Video.Media.BUCKET_ID};

        Cursor cursor = getContentResolver().query(allImagesuri, projection, null, null, null);

        try {
            if (cursor != null) {
                cursor.moveToFirst();
            }
            do {
                VideoModel model = new VideoModel();
                String name = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME));
                String folder = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME));
                String datapath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA));


                String folderpaths = datapath.substring(0, datapath.lastIndexOf(folder + "/"));
                folderpaths = folderpaths + folder + "/";
                if (!picPaths.contains(folderpaths)) {
                    picPaths.add(folderpaths);

                    model.setPath(folderpaths);
                    model.setFolderName(folder);
                    model.setFirstPic(datapath);
                    model.addpics();
                    arrayList.add(model);
                } else {
                    for (int i = 0; i < arrayList.size(); i++) {
                        model = (VideoModel) arrayList.get(i);
                        if (model.getPath().equals(folderpaths)) {
                            model.setFirstPic(datapath);
                            model.addpics();
                        }
                    }
                }
            } while (cursor.moveToNext());
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return arrayList;
    }
}