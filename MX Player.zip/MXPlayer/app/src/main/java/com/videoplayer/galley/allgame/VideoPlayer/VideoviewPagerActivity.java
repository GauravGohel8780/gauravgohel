package com.videoplayer.galley.allgame.VideoPlayer;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;



import com.videoplayer.galley.allgame.R;

import java.io.File;
import java.util.ArrayList;

public class VideoviewPagerActivity extends AppCompatActivity {

    ArrayList<VideoItemModel> allImages = new ArrayList<>();

    ViewPager mViewPager;
    VideoViewPagerAdapter mVideoViewPagerAdapter;
    LinearLayout share, delete, details;

    VideoItemModel model;
    String imageUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videoview_pager);

        getWindow().setStatusBarColor(this.getResources().getColor(R.color.black));

        share = findViewById(R.id.share);
        delete = findViewById(R.id.delete);
        details = findViewById(R.id.details);

        Bundle bundle = getIntent().getExtras();

        String position = bundle.getString("po");

        allImages = getIntent().getExtras().getParcelableArrayList("arrayP");


        mViewPager = findViewById(R.id.viewPagerMain);

        mVideoViewPagerAdapter = new VideoViewPagerAdapter(this, allImages);
        mViewPager.setAdapter(mVideoViewPagerAdapter);

        mViewPager.setCurrentItem(Integer.parseInt(position));
        model = allImages.get(Integer.parseInt(position));
        imageUrl = model.getPicturePath();

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri imageUri = Uri.parse(model.getPicturePath());
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("image/*");

                intent.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(intent, "Share"));

            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                AlertDialog.Builder builder = new AlertDialog.Builder(VideoviewPagerActivity.this);
                builder.setTitle("Confirm Delete....");
                builder.setMessage("Are you sure, You Want To Delete This Status?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                        deleteAlbumFile(VideoviewPagerActivity.this, model.getPicturePath());
                        VideoviewPagerActivity.super.onBackPressed();
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                builder.show();
            }
        });

        details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showProperties(Integer.parseInt(String.valueOf(position)));
            }
        });

        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                model = allImages.get(position);
                imageUrl = model.getPicturePath();

                details.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        showProperties(Integer.parseInt(String.valueOf(position)));
                    }
                });
            }


            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });


    }

    public static String fileReadableSize(long size) {
        String s = "";
        long kilobyte = 1024;
        long megabyte = kilobyte * kilobyte;
        long gigabyte = megabyte * kilobyte;
        long terabyte = gigabyte * kilobyte;

        double kb = (double) size / kilobyte;
        double mb = kb / kilobyte;
        double gb = mb / kilobyte;
        double tb = gb / kilobyte;

        if (size < kilobyte) {
            s = size + "bytes";
        } else if (size >= kilobyte && size < megabyte) {
            s = String.format("%.2f", kb) + "KB";
        } else if (size >= megabyte && size < gigabyte) {
            s = String.format("%.2f", mb) + "MB";
        } else if (size >= gigabyte && size < terabyte) {
            s = String.format("%.2f", gb) + "GB";
        } else if (size >= terabyte) {
            s = String.format("%.2f", tb) + "tB";
        }

        return s;
    }

    private void showProperties(int position) {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.image_details);

        String name = allImages.get(position).getPicturName();
        String path = allImages.get(position).getPicturePath();
        String size = allImages.get(position).getPictureSize();

        TextView tit = dialog.findViewById(R.id.pro_title);
        TextView st = dialog.findViewById(R.id.pro_storage);
        TextView siz = dialog.findViewById(R.id.pro_size);

        tit.setText(name);
        st.setText(path);
        siz.setText(fileReadableSize(Long.parseLong(size)));

        dialog.show();

    }


    public static void deleteAlbumFile(Context context, String filePath) {
        File photo = new File(filePath);
        if (!photo.exists()) {
            return;
        }
        photo.delete();
        context.getContentResolver().delete(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                MediaStore.Images.Media.DATA + "=?",
                new String[]{
                        photo.getAbsolutePath()
                });
        context.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.parse("file://" + photo)));
    }
}