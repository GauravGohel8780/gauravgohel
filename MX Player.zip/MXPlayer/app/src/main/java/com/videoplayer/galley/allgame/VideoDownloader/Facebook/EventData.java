package com.videoplayer.galley.allgame.VideoDownloader.Facebook;

/* loaded from: classes4.dex */
public class EventData {
    public int code;
    public String data;

    public EventData(String data, int code) {
        this.data = data;
        this.code = code;
    }
}
