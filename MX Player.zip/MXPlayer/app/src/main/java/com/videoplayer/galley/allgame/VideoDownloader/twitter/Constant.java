package com.videoplayer.galley.allgame.VideoDownloader.twitter;

/**
 * Created by Shid on 21/12/2018.
 */

public class Constant {
    //Create an developper account on twitter and get your api key
    public static final String TWITTER_KEY = "wHa3s8vF5cmke6HEaiCiq9aa9";
    public static final String TWITTER_SECRET = "ZdU9kcF6XjUudLQ8qoW8XzxwMx5HPscrI6gUIrrmu5fnfkyBv1";

    //Permissions
    public static final int REQUEST_EXTERNAL_STORAGE = 1;
    public static final String[] PERMISSION_STRORAGE = {
            android.Manifest.permission.READ_EXTERNAL_STORAGE,
            android.Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    public static final int REQUEST_CODE = 20;
    public static final int NOTI_IDENTIFIER = 3100;
    public static final int AUTO_REQUEST_CODE = 30;


}
