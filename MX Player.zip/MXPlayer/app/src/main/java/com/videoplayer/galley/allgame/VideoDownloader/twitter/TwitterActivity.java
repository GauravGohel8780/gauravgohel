package com.videoplayer.galley.allgame.VideoDownloader.twitter;



import static com.videoplayer.galley.allgame.VideoDownloader.whatsapp.Utils1.RootDirectoryTwitter;
import static com.videoplayer.galley.allgame.VideoDownloader.whatsapp.Utils1.createTWFolder;
import static com.videoplayer.galley.allgame.VideoDownloader.whatsapp.Utils1.startDownload;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.twitter.sdk.android.core.Callback;
import com.twitter.sdk.android.core.DefaultLogger;
import com.twitter.sdk.android.core.Result;
import com.twitter.sdk.android.core.Twitter;
import com.twitter.sdk.android.core.TwitterApiClient;
import com.twitter.sdk.android.core.TwitterAuthConfig;
import com.twitter.sdk.android.core.TwitterConfig;
import com.twitter.sdk.android.core.TwitterCore;
import com.twitter.sdk.android.core.TwitterException;
import com.twitter.sdk.android.core.models.Tweet;
import com.twitter.sdk.android.core.services.StatusesService;
import com.videoplayer.galley.allgame.AdsDemo.Intertials;
import com.videoplayer.galley.allgame.AdsDemo.Native;
import com.videoplayer.galley.allgame.R;
import com.videoplayer.galley.allgame.VideoDownloader.Downlodervideo.AllDownlodevideoActivity;
import com.videoplayer.galley.allgame.VideoDownloader.Instagram.InstagramActivity;
import com.videoplayer.galley.allgame.VideoPlayer.SharedPrefs;

import retrofit2.Call;

public class TwitterActivity extends AppCompatActivity {

    private AppCompatButton btndownload, btnpaste, btnOpenTwitter;
    private ProgressDialog progressDialog;
    private TextView txt_url;
    ImageView downlodede;
    private RelativeLayout linearLayout;
    private ClipboardManager clipboardManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_twitter);

        new Native().shownativeads(this, findViewById(R.id.native_container));

        setUI();
        btnClick();
        setTwitterConfig();
        detectIntent();


        createTWFolder();

    }



    @SuppressLint("ClickableViewAccessibility")
    public void setUI() {
        btndownload = findViewById(R.id.btndownload);
        txt_url = findViewById(R.id.txt_tweet_url);
        linearLayout = findViewById(R.id.main_layout);
        btnpaste = findViewById(R.id.btnpaste);
        downlodede = findViewById(R.id.downlodede);
        btnOpenTwitter = findViewById(R.id.btnOpenTwitter);

//        progressDialog = new ProgressDialog(this);
//        progressDialog.setMessage("Fetching video....");
//        progressDialog.setCancelable(false);
//        progressDialog.setIndeterminate(true);

//        txt_url.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View v, MotionEvent event) {
//                final int DRAWABLE_LEFT = 0;
//                final int DRAWABLE_TOP = 1;
//                final int DRAWABLE_RIGHT = 2;
//                final int DRAWABLE_BOTTOM = 3;
//
//                if (event.getAction() == MotionEvent.ACTION_UP) {
//                    if (event.getRawX() >= (txt_url.getRight() - txt_url.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
//                        // your action here
//                        txt_url.setText("");
//
//                        return true;
//                    }
//                }
//                return false;
//            }
//        });

    }

    public void btnClick() {

        btnpaste.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                try {
                    CharSequence textToPaste = clipboardManager.getPrimaryClip().getItemAt(0).getText();
                    txt_url.setText(textToPaste);
                } catch (Exception e) {
                    return;
                }
            }
        });
        downlodede.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Intertials().ShowIntertistialAds(TwitterActivity.this, new Intertials.OnIntertistialAdsListner() {
                    public void onAdsDismissed() {
                        Intent intent = new Intent(TwitterActivity.this, AllDownlodevideoActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    }
                });
            }
        });

        btndownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fname;

                //Check if the tweet url field has text containing twitter.com/...
                if (txt_url.getText().length() > 0 && txt_url.getText().toString().contains("twitter.com/")) {

                    Long id = getTweetId(txt_url.getText().toString());
                    fname = String.valueOf(id);

                    //Call method to get tweet
                    if (id != null) {
                        getTweet(id, fname);
                        if (!SharedPrefs.getFirst_download(TwitterActivity.this)) {
                            SharedPrefs.setFirst_download(TwitterActivity.this, true);
                            SharedPrefs.setFirst_dialog(TwitterActivity.this, "activity");
                        }
                    } else {
                        alertNoUrl();
                    }
                } else {
                    alertNoUrl();
                }
            }
        });

        btnOpenTwitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openTwitter();
            }
        });
    }

    private void openTwitter() {
        try {
            Intent i = this.getPackageManager().getLaunchIntentForPackage("com.twitter.android");
            this.startActivity(i);
        } catch (Exception var4) {
            this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + "com.twitter.android")));
        }

    }

    private Long getTweetId(String s) {
        Log.d("TAG", "link is :" + s);

        try {
            String[] split = s.split("\\/");
            String id = split[5].split("\\?")[0];
            return Long.parseLong(id);
        } catch (Exception e) {
            Log.d("TAG", "getTweetId: " + e.getLocalizedMessage());
            alertNoUrl();
            return null;
        }
    }

    private void alertNoUrl() {

        Toast.makeText(this, "Enter Correct URL", Toast.LENGTH_SHORT).show();
    }

    public void detectIntent() {
        // Get intent, action and MIME type
        //Return the intent that started this activity, that is the case when we are sharing a tweet
        //from twitter
        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();

        if (Intent.ACTION_SEND.equals(action) && type != null) {

            if ("text/plain".equals(type)) {
                handleSharedText(intent);
            }
        }
    }

    private void handleSharedText(Intent intent) {
        String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
        Log.d("TAG", "shared text is :" + sharedText);
        if (sharedText != null) {
            try {
                // splits a String into an array of substrings given a specific delimiter.
                if (sharedText.split("\\ ").length > 1) {
                    //sharedText is splitted into four elements into an array and returns
                    //the fourth elements of the array
                    txt_url.setText(sharedText.split("\\ ")[4]);

                } else {
                    txt_url.setText(sharedText.split("\\ ")[0]);
                }

            } catch (Exception e) {
                Log.d("TAG", "handleSharedText: " + e);
            }
        }

    }

    public void setTwitterConfig() {

        TwitterConfig config = new TwitterConfig.Builder(this)
                .logger(new DefaultLogger(Log.DEBUG))
                .twitterAuthConfig(new TwitterAuthConfig(Constant.TWITTER_KEY, Constant.TWITTER_SECRET))
                .debug(true)
                .build();
        Twitter.initialize(config);
    }

    private void getTweet(Long id, String fname) {
//        progressDialog.show();
        createTWFolder();
        try {
            TwitterApiClient twitterApiClient = TwitterCore.getInstance().getApiClient();
            StatusesService statusesService = twitterApiClient.getStatusesService();
            Call<Tweet> tweetCall = statusesService.show(id, null, null, null);
            tweetCall.enqueue(new Callback<Tweet>() {
                @Override
                public void success(Result<Tweet> result) {
                    //Check if media is present
                    if (result.data.extendedEntities == null && result.data.entities.media == null) {
                        alertNoMedia();
                    } else if (result.data.extendedEntities != null) {
                        if ((result.data.extendedEntities.media.isEmpty())) {
                            alertNoVideo();
                        } else {
                            String filename = "twitter_" + fname;
                            String url;

                            //Set filename to gif or mp4
                            if ((result.data.extendedEntities.media.get(0).type).equals("video") ||
                                    (result.data.extendedEntities.media.get(0).type).equals("animated_gif")) {
                                filename = filename + ".mp4";
                                Log.d("TAG", "filenme for video is " + filename);

                            }

                            int i = 0;
                            url = result.data.extendedEntities.media.get(0).videoInfo.variants.get(i).url;

                            Log.d("TAG", "url is " + url);

                            while (!url.contains(".mp4")) {
                                try {
                                    if (result.data.extendedEntities.media.get(0).videoInfo.variants.get(i) != null) {
                                        url = result.data.extendedEntities.media.get(0).videoInfo.variants.get(i).url;
                                        Log.d("TAG", "url2 is " + url);
                                        i += 1;
                                    }
                                } catch (IndexOutOfBoundsException e) {
                                    startDownload(url, RootDirectoryTwitter, TwitterActivity.this, filename);
                                }
                            }

                            startDownload(url, RootDirectoryTwitter, TwitterActivity.this, filename);
                        }
                    }

                }


                @Override
                public void failure(TwitterException exception) {
                    Toast.makeText(TwitterActivity.this, "Request failed, check your Internet connection", Toast.LENGTH_SHORT).show();
                }
            });
        } catch (IndexOutOfBoundsException e) {
            e.printStackTrace();
        }

    }

    private void alertNoVideo() {
//        progressDialog.hide();
        Toast.makeText(this, "URL entered do not contain any video or gif", Toast.LENGTH_SHORT).show();
    }

    private void alertNoMedia() {
//        progressDialog.hide();
        Toast.makeText(this, "The link entered do not contain any media", Toast.LENGTH_SHORT).show();
    }
}