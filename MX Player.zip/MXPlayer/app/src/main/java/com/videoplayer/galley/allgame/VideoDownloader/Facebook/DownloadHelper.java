package com.videoplayer.galley.allgame.VideoDownloader.Facebook;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;


import org.greenrobot.eventbus.EventBus;

/* loaded from: classes4.dex */
public class DownloadHelper {
    static boolean isServiceConnected = false;
    Context context;
    public DownloaderService downloaderService;
    String tag = "DownloadHandeler";
    private ServiceConnection serviceConnection = new ServiceConnection() { // from class: com.lunarday.fbstorydownloader.helper.DownloadHelper.3
        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.i(DownloadHelper.this.tag, "on onServiceConnected entered");
            DownloadHelper.this.downloaderService = ((DownloaderService.MyLocalinder) service).getService();
            DownloadHelper.isServiceConnected = true;
            Log.i(DownloadHelper.this.tag, "on onServiceConnected finished");
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName name) {
            Log.i(DownloadHelper.this.tag, "on onServiceDisconnected finished");
            DownloadHelper.isServiceConnected = false;
        }
    };
    Handler handler = new Handler(Looper.getMainLooper());

    public DownloadHelper(Context context) {
        this.context = context;
        startServiceAndBind();
    }

    public void startDownload(final String url, final String filename) {
        startServiceAndBind();
        new Thread(new Runnable() { // from class: com.lunarday.fbstorydownloader.helper.DownloadHelper.1
            @Override // java.lang.Runnable
            public void run() {
                while (!DownloadHelper.isServiceConnected) {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e2) {
                        e2.printStackTrace();
                    }
                }
                DownloadHelper.this.handler.post(new Runnable() { // from class: com.lunarday.fbstorydownloader.helper.DownloadHelper.1.1
                    @Override // java.lang.Runnable
                    public void run() {
                        Log.i(DownloadHelper.this.tag, "downloaderService download called");
                        DownloadHelper.this.downloaderService.download(url, filename);
                    }
                });
            }
        }).start();
    }

    public void getFetch() {
        startServiceAndBind();
        new Thread(new Runnable() { // from class: com.lunarday.fbstorydownloader.helper.DownloadHelper.2
            @Override // java.lang.Runnable
            public void run() {
                while (DownloadHelper.this.downloaderService == null) {
                    try {
                        Thread.sleep(50L);
                    } catch (InterruptedException e2) {
                        e2.printStackTrace();
                    }
                }
                DownloadHelper.this.handler.post(new Runnable() { // from class: com.lunarday.fbstorydownloader.helper.DownloadHelper.2.1
                    @Override // java.lang.Runnable
                    public void run() {
                        Log.i(DownloadHelper.this.tag, "downloaderService download called");
                        EventBus.getDefault().post(DownloadHelper.this.downloaderService.getFetch());
                    }
                });
            }
        }).start();
    }

    private void startServiceAndBind() {
        Intent intent = new Intent(this.context, DownloaderService.class);
        this.context.bindService(intent, this.serviceConnection, Context.BIND_AUTO_CREATE);
        this.context.startService(intent);
        Log.i("data__",  "start");
    }
}
