package com.videoplayer.galley.allgame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;


import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdSettings;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;

public class FBtestActivity extends AppCompatActivity {

    private InterstitialAd interstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fbtest);
//        AdSettings.addTestDevice("2cb3ef85-ef77-45a2-b18e-11af45bc4763");

        AudienceNetworkAds.initialize(this);
        findViewById(R.id.showInterBtn).setOnClickListener(view -> {
            start();
        });
    }
//609404390770541_621974402846873
//IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID
    private void start(){
        interstitialAd = new InterstitialAd(this, "609404390770541_621974402846873");
        // Create listeners for the Interstitial Ad
        InterstitialAdListener interstitialAdListener = new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
                Toast.makeText(FBtestActivity.this, "Interstitial ad displayed.", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                Toast.makeText(FBtestActivity.this, "Interstitial ad dismissed.", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Toast.makeText(FBtestActivity.this, "Interstitial ad failed to load:"+adError, Toast.LENGTH_SHORT).show();
                Log.d("gggggggg", "onError: "+adError);
            }

            @Override
            public void onAdLoaded(Ad ad) {
                interstitialAd.show();
                Toast.makeText(FBtestActivity.this, "Interstitial ad is loaded and ready to be displayed!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAdClicked(Ad ad) {
                Toast.makeText(FBtestActivity.this, "Interstitial ad clicked!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onLoggingImpression(Ad ad) {
                // Ad impression logged callback
                Toast.makeText(FBtestActivity.this, "Interstitial ad impression logged!", Toast.LENGTH_SHORT).show();
            }
        };

        // For auto play video ads, it's recommended to load the ad
        // at least 30 seconds before it is shown
        interstitialAd.loadAd(
                interstitialAd.buildLoadAdConfig()
                        .withAdListener(interstitialAdListener)
                        .build());
    }
}
