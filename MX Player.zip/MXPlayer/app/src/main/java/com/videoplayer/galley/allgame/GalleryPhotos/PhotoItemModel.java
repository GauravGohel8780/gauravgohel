package com.videoplayer.galley.allgame.GalleryPhotos;

import android.os.Parcel;
import android.os.Parcelable;

public class PhotoItemModel implements Parcelable {

    /*normal Model*/
    private String picturName;
    private String picturePath;
    private String pictureSize;

    public PhotoItemModel() {
    }

    public PhotoItemModel(String picturName, String picturePath, String pictureSize) {
        this.picturName = picturName;
        this.picturePath = picturePath;
        this.pictureSize = pictureSize;
    }

    protected PhotoItemModel(Parcel in) {
        picturName = in.readString();
        picturePath = in.readString();
        pictureSize = in.readString();
    }

    public static final Creator<PhotoItemModel> CREATOR = new Creator<PhotoItemModel>() {
        @Override
        public PhotoItemModel createFromParcel(Parcel in) {
            return new PhotoItemModel(in);
        }

        @Override
        public PhotoItemModel[] newArray(int size) {
            return new PhotoItemModel[size];
        }
    };

    public String getPicturName() {
        return picturName;
    }

    public void setPicturName(String picturName) {
        this.picturName = picturName;
    }

    public String getPicturePath() {
        return picturePath;
    }

    public void setPicturePath(String picturePath) {
        this.picturePath = picturePath;
    }

    public String getPictureSize() {
        return pictureSize;
    }

    public void setPictureSize(String pictureSize) {
        this.pictureSize = pictureSize;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(picturName);
        parcel.writeString(picturePath);
        parcel.writeString(pictureSize);
    }
}

/*viewpeger model*/

//    private String picturName;
//    private String picturePath;
//    private  String pictureSize;
//
//
//
//
//    private  String imageUri;
//    private Boolean selected = false;
//
//    private String key_id;
//    private int item_image;
//    private String favStatus;
//
//
//    public PhotoItemModel(){
//
//    }
//
//    public PhotoItemModel(String picturName, String picturePath, String pictureSize, String imageUri, String key_id, int item_image) {
//        this.picturName = picturName;
//        this.picturePath = picturePath;
//        this.pictureSize = pictureSize;
//
//        this.imageUri = imageUri;
//
//        this.key_id = key_id;
//        this.item_image = item_image;
//    }
//
//
//    protected PhotoItemModel(Parcel in) {
//        picturName = in.readString();
//        picturePath = in.readString();
//        pictureSize = in.readString();
//        imageUri = in.readString();
//        byte tmpSelected = in.readByte();
//        selected = tmpSelected == 0 ? null : tmpSelected == 1;
//    }
//
//    public static final Creator<PhotoItemModel> CREATOR = new Creator<PhotoItemModel>() {
//        @Override
//        public PhotoItemModel createFromParcel(Parcel in) {
//            return new PhotoItemModel(in);
//        }
//
//        @Override
//        public PhotoItemModel[] newArray(int size) {
//            return new PhotoItemModel[size];
//        }
//    };
//
//    public String getPicturName() {
//        return picturName;
//    }
//
//    public void setPicturName(String picturName) {
//        this.picturName = picturName;
//    }
//
//    public String getPicturePath() {
//        return picturePath;
//    }
//
//    public void setPicturePath(String picturePath) {
//        this.picturePath = picturePath;
//    }
//
//    public String getPictureSize() {
//        return pictureSize;
//    }
//
//    public void setPictureSize(String pictureSize) {
//        this.pictureSize = pictureSize;
//    }
//
//    public String getImageUri() {
//        return imageUri;
//    }
//
//    public void setImageUri(String imageUri) {
//        this.imageUri = imageUri;
//    }
//
//    public Boolean getSelected() {
//        return selected;
//    }
//
//    public void setSelected(Boolean selected) {
//        this.selected = selected;
//    }
//
//    public String getPath() {
//        return picturePath;
//    }
//
//    @Override
//    public int describeContents() {
//        return 0;
//    }
//
//    @Override
//    public void writeToParcel(Parcel parcel, int i) {
//        parcel.writeString(picturName);
//        parcel.writeString(picturePath);
//        parcel.writeString(pictureSize);
//        parcel.writeString(imageUri);
//        parcel.writeByte((byte) (selected == null ? 0 : selected ? 1 : 2));
//    }
//
//    public String getKey_id() {
//        return key_id;
//    }
//
//    public void setKey_id(String key_id) {
//        this.key_id = key_id;
//    }
//
//    public int getItem_image() {
//        return item_image;
//    }
//
//    public void setItem_image(int item_image) {
//        this.item_image = item_image;
//    }
//
//    public PhotoItemModel(String favStatus) {
//        this.favStatus = favStatus;
//    }
//
//    public String getFavStatus() {
//        return favStatus;
//    }
//
//    public void setFavStatus(String favStatus) {
//        this.favStatus = favStatus;
//    }
//
//
//}
