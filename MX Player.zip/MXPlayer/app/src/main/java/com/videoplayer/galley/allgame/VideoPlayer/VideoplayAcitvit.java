package com.videoplayer.galley.allgame.VideoPlayer;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import com.videoplayer.galley.allgame.R;


public class VideoplayAcitvit extends AppCompatActivity {

    VideoView videoshow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videoplay_acitvit);

        videoshow = findViewById(R.id.videoshow);

        Intent i = getIntent();
        Uri uri = Uri.parse(i.getExtras().get("Videoshow").toString());
        videoshow.setVideoURI(uri);

        MediaController mediaController = new MediaController(this);

        mediaController.setAnchorView(videoshow);

        mediaController.setMediaPlayer(videoshow);

        videoshow.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                finish();
            }
        });

        videoshow.setMediaController(mediaController);

        videoshow.start();

    }
}