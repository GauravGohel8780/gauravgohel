package com.videoplayer.galley.allgame.PlayGame;

import java.util.ArrayList;

public interface itemClickListener {

    void onPicClicked(ParentAdapter.ViewHolder holder, int position, ArrayList<ChildModelClass> arrayList);

}