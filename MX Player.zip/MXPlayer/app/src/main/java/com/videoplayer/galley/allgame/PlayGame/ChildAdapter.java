package com.videoplayer.galley.allgame.PlayGame;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.videoplayer.galley.allgame.R;

import java.util.ArrayList;

public class ChildAdapter extends RecyclerView.Adapter<ChildAdapter.ViewHolder> {

    ArrayList<ChildModelClass> childModelClassList;
    Activity context;

    public ChildAdapter(ArrayList<ChildModelClass> childModelClassList, Activity context) {
        this.childModelClassList = childModelClassList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;

        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.child_rv_layout, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {


        Glide.with(context).load(childModelClassList.get(position).image).into(holder.iv_chile_image);
        holder.txt_main.setText(childModelClassList.get(position).appname);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse(childModelClassList.get(position).url);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                context.startActivity(intent);
            }
        });
    }


    @Override
    public int getItemCount() {
        return 24;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView iv_chile_image;
        TextView txt_main;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            iv_chile_image = itemView.findViewById(R.id.iv_child_item);
            txt_main = itemView.findViewById(R.id.txt_main);
        }
    }


}

