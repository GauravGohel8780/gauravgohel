package com.videoplayer.galley.allgame.AdsDemo;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.ads.AdOptionsView;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdLayout;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.videoplayer.galley.allgame.R;

import java.util.ArrayList;
import java.util.List;

public class InflatAds {
    Activity activity;

    public InflatAds(Activity activity) {
        this.activity = activity;
    }


    public void inflat_admobnative(com.google.android.gms.ads.nativead.NativeAd unifiedNativeAd, ViewGroup viewGroup) {

        NativeAdView adView = (NativeAdView) (activity).getLayoutInflater().inflate(R.layout.ads_native_admob, null);

        com.google.android.gms.ads.nativead.MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        TextView button = adView.findViewById(R.id.ad_call_to_action);

        adView.setCallToActionView(button);
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        ((TextView) adView.getHeadlineView()).setText(unifiedNativeAd.getHeadline());
        if (unifiedNativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(unifiedNativeAd.getBody());
        }

        if (unifiedNativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((TextView) adView.getCallToActionView()).setText(unifiedNativeAd.getCallToAction());
        }

        if (unifiedNativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    unifiedNativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        adView.setNativeAd(unifiedNativeAd);

        viewGroup.removeAllViews();
        viewGroup.addView(adView);
    }

    public void inflat_admobnativebanner(com.google.android.gms.ads.nativead.NativeAd unifiedNativeAd, ViewGroup viewGroup) {

        NativeAdView adView = (NativeAdView) (activity).getLayoutInflater().inflate(R.layout.ads_nativebanner_admob, null);

        com.google.android.gms.ads.nativead.MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        TextView button = adView.findViewById(R.id.ad_call_to_action);

        adView.setCallToActionView(button);
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        ((TextView) adView.getHeadlineView()).setText(unifiedNativeAd.getHeadline());
        if (unifiedNativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(unifiedNativeAd.getBody());
        }

        if (unifiedNativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((TextView) adView.getCallToActionView()).setText(unifiedNativeAd.getCallToAction());
        }

        if (unifiedNativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    unifiedNativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        adView.setNativeAd(unifiedNativeAd);


        viewGroup.removeAllViews();
        viewGroup.addView(adView);
    }

    public void inflate_fbnativebanner(NativeAd nativeBannerAd, ViewGroup viewGroup) {
        nativeBannerAd.unregisterView();
        View inflate = LayoutInflater.from(activity).inflate(R.layout.ads_nativebanner_fb, (ViewGroup) null);
        viewGroup.removeAllViews();
        viewGroup.addView(inflate);
        LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.ad_choices_container);
        AdOptionsView adOptionsView = new AdOptionsView(activity, nativeBannerAd, (NativeAdLayout) inflate.findViewById(R.id.nativview));
        linearLayout.removeAllViews();
        int i = 0;
        linearLayout.addView(adOptionsView, 0);
        TextView textView = (TextView) inflate.findViewById(R.id.native_ad_title);
        TextView textView2 = (TextView) inflate.findViewById(R.id.native_ad_social_context);
        MediaView mediaView = (MediaView) inflate.findViewById(R.id.native_icon_view);
        TextView textView3 = (TextView) inflate.findViewById(R.id.native_ad_call_to_action);
        textView3.setText(nativeBannerAd.getAdCallToAction());
        if (!nativeBannerAd.hasCallToAction()) {
            i = 4;
        }
        textView3.setVisibility(i);
        textView.setText(nativeBannerAd.getAdvertiserName());
        textView2.setText(nativeBannerAd.getAdBodyText());
        ArrayList arrayList = new ArrayList();
        arrayList.add(textView);
        arrayList.add(textView3);
        arrayList.add(mediaView);
        arrayList.add(textView2);
        nativeBannerAd.registerViewForInteraction(inflate, mediaView, (List<View>) arrayList);
    }

    public void inflat_facebooknative(NativeAd nativeAd, ViewGroup viewGroup) {

        nativeAd.unregisterView();
        View inflate = LayoutInflater.from(activity).inflate(R.layout.ads_nativ_fb, (ViewGroup) null);
        viewGroup.removeAllViews();
        viewGroup.addView(inflate);
        LinearLayout adChoicesContainer = inflate.findViewById(R.id.ad_choices_container);
        AdOptionsView adOptionsView = new AdOptionsView(activity, nativeAd, inflate.findViewById(R.id.nativview));
        adChoicesContainer.removeAllViews();
        adChoicesContainer.addView(adOptionsView, 0);
        MediaView nativeAdIcon = inflate.findViewById(R.id.native_ad_icon);
        TextView nativeAdTitle = inflate.findViewById(R.id.native_ad_title);
        MediaView nativeAdMedia = inflate.findViewById(R.id.native_ad_media);
        TextView nativeAdSocialContext = inflate.findViewById(R.id.native_ad_social_context);
        TextView nativeAdBody = inflate.findViewById(R.id.native_ad_body);
        TextView sponsoredLabel = inflate.findViewById(R.id.native_ad_sponsored_label);
        TextView nativeAdCallToAction = inflate.findViewById(R.id.native_ad_call_to_action);

        nativeAdTitle.setText(nativeAd.getAdvertiserName());
        nativeAdBody.setText(nativeAd.getAdBodyText());
        nativeAdSocialContext.setText(nativeAd.getAdSocialContext());
        nativeAdCallToAction.setVisibility(nativeAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
        nativeAdCallToAction.setText(nativeAd.getAdCallToAction());
        sponsoredLabel.setText(nativeAd.getSponsoredTranslation());

        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(nativeAdTitle);
        clickableViews.add(nativeAdCallToAction);

        nativeAd.registerViewForInteraction(inflate, nativeAdMedia, nativeAdIcon, clickableViews);
    }
}
