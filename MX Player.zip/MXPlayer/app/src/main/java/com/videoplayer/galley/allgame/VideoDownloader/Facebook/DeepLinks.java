package com.videoplayer.galley.allgame.VideoDownloader.Facebook;

import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.videoplayer.galley.allgame.R;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/* loaded from: classes4.dex */
public class DeepLinks extends AppCompatActivity {
    String action;
    TextView detailsTv;
    TextView detailsTv2;
    BottomSheetDialog dialog;
    DownloadHelper downloadHelper;
    NestedScrollView downloadLayout;
    DownloadLinkHandeler downloadLinkHandeler;
    LinearLayout hdLayout;
    Intent intent;
    Button login;
    LottieAnimationView lottieAnimationView;
    LinearLayout notLoggedin;
    Pref pref;
    Random random;
    LinearLayout sdLayout;
    LinearLayout singleItemLayout;
    TextView textView;
    ImageView thum;
    TextView titleTv;
    TextView titleTv2;
    String tag = "deeplinks";
    long tpp = 259200000;
    AlertDialog alertDialog = null;
    String price = "";
    String[] permissions = {"android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"};

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        this.intent = intent;
        this.action = intent.getAction();
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        this.dialog = bottomSheetDialog;
        bottomSheetDialog.setContentView(R.layout.link_gen);
        this.detailsTv = (TextView) this.dialog.findViewById(R.id.details);
        this.titleTv = (TextView) this.dialog.findViewById(R.id.title);
        this.detailsTv2 = (TextView) this.dialog.findViewById(R.id.details2);
        this.titleTv2 = (TextView) this.dialog.findViewById(R.id.title2);
        this.lottieAnimationView = (LottieAnimationView) this.dialog.findViewById(R.id.lottie_layer);
        this.downloadLayout = (NestedScrollView) this.dialog.findViewById(R.id.download_view);
        this.singleItemLayout = (LinearLayout) this.dialog.findViewById(R.id.single_layout);
        this.login = (Button) this.dialog.findViewById(R.id.login);
        this.notLoggedin = (LinearLayout) this.dialog.findViewById(R.id.login_requred);
        this.hdLayout = (LinearLayout) this.dialog.findViewById(R.id.hd_layout);
        this.sdLayout = (LinearLayout) this.dialog.findViewById(R.id.sd_layout);
        this.random = new Random();
        this.downloadLinkHandeler = new DownloadLinkHandeler(this);
        this.downloadHelper = new DownloadHelper(this);
        this.pref = new Pref(this);

        startDownloadProcess();
        this.dialog.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.lunarday.fbstorydownloader.activities.DeepLinks.2
            @Override // android.content.DialogInterface.OnDismissListener
            public void onDismiss(DialogInterface dialog) {
                DeepLinks.this.finish();
            }
        });

    }

    void startDownloadProcess() {
        if (new Pref(this).isRated() || new Pref(this).getDownloadCount() <= 2) {
            new Functions(this);
            if (Functions.is29orAbove() || this.pref.getPermissionState("android.permission.WRITE_EXTERNAL_STORAGE") == 0 || ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
                if (this.intent.getStringExtra("url") != null) {
                    this.downloadLinkHandeler.generateLinks(this.intent.getStringExtra("url"));
                    try {
                        this.dialog.show();
                        return;
                    } catch (Exception unused) {
                        return;
                    }
                }
                String type = this.intent.getType();
                if ("android.intent.action.SEND".equals(this.action) && type != null && "text/plain".equals(type)) {
                    if (!this.pref.isPremium()) {
                        return;
                    }
                    this.downloadLinkHandeler.generateLinks(this.intent.getStringExtra("android.intent.extra.TEXT"));
                    this.dialog.show();
                    return;
                }
                return;
            } else if (this.pref.getPermissionState("android.permission.WRITE_EXTERNAL_STORAGE") == 2) {
                deniedPermanently();
                return;
            } else {
                checkPermissions();
                return;
            }
        }
        AlertDialog create = new AlertDialog.Builder(this).setTitle("Rate us").setMessage("To download more posts please rate us 5 star positively.").setPositiveButton("Rate 5 star", new DialogInterface.OnClickListener() { // from class: com.lunarday.fbstorydownloader.activities.DeepLinks.5
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                DeepLinks.this.openAppRating();
            }
        }).setNegativeButton("Not now", new DialogInterface.OnClickListener() { // from class: com.lunarday.fbstorydownloader.activities.DeepLinks.4
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                DeepLinks.this.alertDialog.dismiss();
            }
        }).setCancelable(false).create();
        this.alertDialog = create;
        create.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.lunarday.fbstorydownloader.activities.DeepLinks.6
            @Override // android.content.DialogInterface.OnDismissListener
            public void onDismiss(DialogInterface dialogInterface) {
                DeepLinks.this.finish();
            }
        });
        this.alertDialog.show();
    }

    void deniedPermanently() {
        new AlertDialog.Builder(this).setTitle("Permissions Required").setMessage("You have forcefully denied some of the required permissions for this action. Please open settings, go to permissions and allow them.").setPositiveButton("Settings", new DialogInterface.OnClickListener() { // from class: com.lunarday.fbstorydownloader.activities.DeepLinks.8
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", Uri.fromParts("package", DeepLinks.this.getPackageName(), null));
                intent.addFlags(268435456);
                DeepLinks.this.startActivity(intent);
            }
        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() { // from class: com.lunarday.fbstorydownloader.activities.DeepLinks.7
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
            }
        }).setCancelable(false).create().show();
    }

    private boolean checkPermissions() {
        String[] strArr;
        new Functions(this);
        if (Functions.is29orAbove()) {
            return true;
        }
        ArrayList arrayList = new ArrayList();
        for (String str : this.permissions) {
            if (ContextCompat.checkSelfPermission(this, str) != 0) {
                arrayList.add(str);
            }
        }
        if (arrayList.isEmpty()) {
            return true;
        }
        ActivityCompat.requestPermissions(this, (String[]) arrayList.toArray(new String[arrayList.size()]), 100);
        return false;
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onCompleteListGeneration(JSONObject jsonObject) {
        this.pref.increaseDownlodCount();
        this.lottieAnimationView.setVisibility(View.GONE);
        this.singleItemLayout.setVisibility(View.VISIBLE);
        Log.i("tag__", jsonObject.toString());
        try {
            final JSONObject jSONObject = jsonObject.getJSONObject("sd");
            final String str = "video" + this.random.nextInt() + "_sd.mp4";
            this.titleTv.setText(str);
            this.detailsTv.setText("Quality : Medium\nSize : " + jSONObject.getString("size"));
            this.sdLayout.setOnClickListener(new View.OnClickListener() { // from class: com.lunarday.fbstorydownloader.activities.DeepLinks.9
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    try {
                        DeepLinks.this.downloadHelper.startDownload(jSONObject.getString("link"), str);
                        DeepLinks.this.dialog.dismiss();
                    } catch (JSONException e2) {
                        e2.printStackTrace();
                    }
                }
            });
        } catch (Exception unused) {
            this.sdLayout.setVisibility(View.GONE);
        }
        try {
            final JSONObject jSONObject2 = jsonObject.getJSONObject("hd");
            Log.i("tag__", jSONObject2.toString());
            final String str2 = "video" + this.random.nextInt() + "_hd.mp4";
            this.hdLayout.setOnClickListener(new View.OnClickListener() { // from class: com.lunarday.fbstorydownloader.activities.DeepLinks.10
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    try {
                        DeepLinks.this.downloadHelper.startDownload(jSONObject2.getString("link"), str2);
                        DeepLinks.this.dialog.dismiss();
                    } catch (JSONException e2) {
                        e2.printStackTrace();
                    }
                }
            });
            this.titleTv2.setText(str2);
            this.detailsTv2.setText("Quality : High\nSize : " + jSONObject2.getString("size"));
        } catch (Exception e2) {
            e2.printStackTrace();
            this.hdLayout.setVisibility(View.GONE);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onCompleteListGeneration(String message) {
        Log.i("Tag__", message);
        if (message.equals("private post")) {
            this.lottieAnimationView.setVisibility(View.GONE);
            this.downloadLayout.setVisibility(View.GONE);
            this.notLoggedin.setVisibility(View.VISIBLE);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    void openAppRating() {
        String packageName = getPackageName();
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + packageName));
        boolean z = false;
        Iterator<ResolveInfo> it = getPackageManager().queryIntentActivities(intent, 0).iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            ResolveInfo next = it.next();
            if (next.activityInfo.applicationInfo.packageName.equals("com.android.vending")) {
                ActivityInfo activityInfo = next.activityInfo;
                ComponentName componentName = new ComponentName(activityInfo.applicationInfo.packageName, activityInfo.name);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.setComponent(componentName);
                startActivity(intent);
                z = true;
                break;
            }
        }
        if (!z) {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + packageName)));
        }
        this.pref.setRatedSucessFully();
    }
}
