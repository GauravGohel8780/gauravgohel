package com.videoplayer.galley.allgame.AdsDemo;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.RemoteException;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.installreferrer.api.InstallReferrerClient;
import com.android.installreferrer.api.InstallReferrerStateListener;
import com.android.installreferrer.api.ReferrerDetails;
import com.facebook.ads.AudienceNetworkAds;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;
import com.videoplayer.galley.allgame.R;

import org.json.JSONException;
import org.json.JSONObject;


public class AppOpenEntilation extends AppCompatActivity {

    AppOpenAd.AppOpenAdLoadCallback loadCallback;

    FirebaseRemoteConfig mFirebaseRemoteConfig;
    Context activity;
    String referrerUrl,json_test;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);


    }

    public void ADSinit(final Activity activity, final getDataListner myCallback1) {

        InstallReferrerClient referrerClient;
        referrerClient = InstallReferrerClient.newBuilder(this).build();
        referrerClient.startConnection(new InstallReferrerStateListener() {
            @Override
            public void onInstallReferrerSetupFinished(int responseCode) {

                switch (responseCode) {
                    case com.android.installreferrer.api.InstallReferrerClient.InstallReferrerResponse.OK:
                        ReferrerDetails response = null;

                        try {
                            response = referrerClient.getInstallReferrer();
                        } catch (RemoteException e) {
                            throw new RuntimeException(e);
                        }

                        referrerUrl = response.getInstallReferrer();
                        long referrerClickTime = response.getReferrerClickTimestampSeconds();
                        long appInstallTime = response.getInstallBeginTimestampSeconds();
                        boolean instantExperienceLaunched = response.getGooglePlayInstantParam();

                        SharedPrefs.setChackUserinet(activity, printSubsInDelimiters1(referrerUrl));

                        break;
                    case com.android.installreferrer.api.InstallReferrerClient.InstallReferrerResponse.FEATURE_NOT_SUPPORTED:

                        break;
                    case com.android.installreferrer.api.InstallReferrerClient.InstallReferrerResponse.SERVICE_UNAVAILABLE:

                        break;
                }
            }

            @Override
            public void onInstallReferrerServiceDisconnected() {

            }
        });


        mFirebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
        FirebaseRemoteConfigSettings configSettings = new FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(0)
                .build();
        mFirebaseRemoteConfig.setConfigSettingsAsync(configSettings);

        mFirebaseRemoteConfig.fetchAndActivate().addOnCompleteListener(new OnCompleteListener<Boolean>() {
            @Override
            public void onComplete(@NonNull Task<Boolean> task) {


                if (SharedPrefs.getChackUserinet(activity).equals("gclid")) {
                    json_test = mFirebaseRemoteConfig.getString("Data");
                } else if (SharedPrefs.getChackUserinet(activity).equals("utm_source")) {
                    json_test = mFirebaseRemoteConfig.getString("Data1");
                }


                try {
                    JSONObject response = new JSONObject(json_test);
                    JSONObject extradataJsonObject = response.getJSONObject("APP_SETTINGS");

                    SharedPrefs.setAdsShow(activity, extradataJsonObject.getString("AdsShow"));
                    SharedPrefs.setapp_openId(activity, extradataJsonObject.getString("openId"));
                    SharedPrefs.setapp_bannerid(activity, extradataJsonObject.getString("bannerid"));
                    SharedPrefs.setapp_bannerid1(activity, extradataJsonObject.getString("bannerid1"));
                    SharedPrefs.setapp_fbbannerid(activity, extradataJsonObject.getString("fbbannerid"));
                    SharedPrefs.setapp_nativeid(activity, extradataJsonObject.getString("nativeid"));
                    SharedPrefs.setapp_nativeid1(activity, extradataJsonObject.getString("nativeid1"));
                    SharedPrefs.setapp_fbnativeid(activity, extradataJsonObject.getString("fbnativeid"));
                    SharedPrefs.setapp_intertialseid(activity, extradataJsonObject.getString("intertialseid"));
                    SharedPrefs.setapp_intertialseid1(activity, extradataJsonObject.getString("intertialseid1"));
                    SharedPrefs.setapp_fbintertialseid(activity, extradataJsonObject.getString("fbintertialseid"));
                    SharedPrefs.setchackReferrer(activity, extradataJsonObject.getString("chackReferrer"));
                    SharedPrefs.setapp_intertialseclick(activity, extradataJsonObject.getInt("intertialseclick"));
                    SharedPrefs.setInternetDilog(activity, extradataJsonObject.getString("InternetDilog"));
                    SharedPrefs.setFirstenterDilog(activity, extradataJsonObject.getInt("FirstenterDilog"));
                    SharedPrefs.setFistTimeUserimg(activity, extradataJsonObject.getString("FistTimeUserimg"));
                    SharedPrefs.setFistTimeUserurl(activity, extradataJsonObject.getString("FistTimeUserurl"));
                    SharedPrefs.setbannerSpecific(activity, extradataJsonObject.getInt("bannerSpecific"));
                    SharedPrefs.setnativeSpecific(activity, extradataJsonObject.getInt("nativeSpecific"));
                    SharedPrefs.setintertistialSpecific(activity, extradataJsonObject.getInt("intertistialSpecific"));
                    SharedPrefs.setbanneradsequence(activity, extradataJsonObject.getInt("banneradsequence"));
                    SharedPrefs.setnativeadsequence(activity, extradataJsonObject.getInt("nativeadsequence"));
                    SharedPrefs.setintertistialadsequence(activity, extradataJsonObject.getInt("intertistialadsequence"));
                    SharedPrefs.setappopentype(activity, extradataJsonObject.getInt("appopentype"));
                    SharedPrefs.setsplashintet(activity, extradataJsonObject.getString("splashintet"));
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        MobileAds.initialize(activity);
        AudienceNetworkAds.initialize(activity);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (SharedPrefs.getAdsShow(activity).equals("yes")){
                    if (SharedPrefs.getsplashintet(activity).equals("yes")) {
                        SharedPrefs.setinterclickcount(activity,0);
//                        SharedPrefs.settimer(activity, false);
                        getAppSDK(activity, myCallback1);
                    }
                }else {
                    myCallback1.onSuccess();
                }
            }
        }, 5000);
    }

    private void getAppSDK(final Activity activity, final getDataListner myCallback1) {
        if (SharedPrefs.getappopentype(activity) == 0) {
            try {

                loadCallback = new AppOpenAd.AppOpenAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull AppOpenAd appOpenAd) {
                        super.onAdLoaded(appOpenAd);

                        FullScreenContentCallback r2 = new FullScreenContentCallback() {
                            public void onAdDismissedFullScreenContent() {
                                myCallback1.onSuccess();
                            }

                            public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                                myCallback1.onSuccess();
                            }

                            public void onAdShowedFullScreenContent() {

                            }
                        };

                        appOpenAd.show(activity);
                        appOpenAd.setFullScreenContentCallback(r2);

                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        super.onAdFailedToLoad(loadAdError);
                        myCallback1.onSuccess();
                    }
                };
                String appopenids = SharedPrefs.getapp_openId(activity);
                AppOpenAd.load(activity, appopenids, new AdRequest.Builder().build(), AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback);

            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (SharedPrefs.getappopentype(activity) == 1) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {

                    new Intertials().IntertistialAds(activity, new Intertials.OnIntertistialAdsListner() {
                        @Override
                        public void onAdsDismissed() {
                            myCallback1.onSuccess();
                        }
                    });

                }
            }, 1000);
        }
    }

    public String printSubsInDelimiters1(String str) {
        String ans = "";
        String[] arr = str.split("=", 2);
        ans = arr[0];
        return ans;
    }
}