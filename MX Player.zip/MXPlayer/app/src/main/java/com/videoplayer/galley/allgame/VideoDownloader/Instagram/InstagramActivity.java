package com.videoplayer.galley.allgame.VideoDownloader.Instagram;




import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;


import com.videoplayer.galley.allgame.AdsDemo.Intertials;
import com.videoplayer.galley.allgame.AdsDemo.Native;
import com.videoplayer.galley.allgame.R;
import com.videoplayer.galley.allgame.VideoDownloader.Downlodervideo.AllDownlodevideoActivity;
import com.videoplayer.galley.allgame.VideoDownloader.twitter.TwitterActivity;
import com.videoplayer.galley.allgame.VideoDownloader.whatsapp.Utils;


public class InstagramActivity extends AppCompatActivity {

    EditText linkEdt;
    ImageView downlodede;
    Button downloadBtn, btnpaste, btnOpenInstagram;
    private ClipboardManager clipBoard;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instagram);

        new Native().shownativeads(this, findViewById(R.id.native_container));

        linkEdt = findViewById(R.id.linkEdt);
        downloadBtn = findViewById(R.id.downloadBtn);
        btnpaste = findViewById(R.id.btnpaste);
        downlodede = findViewById(R.id.downlodede);
        btnOpenInstagram = findViewById(R.id.btnOpenInstagram);

        downlodede.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Intertials().ShowIntertistialAds(InstagramActivity.this, new Intertials.OnIntertistialAdsListner() {
                    public void onAdsDismissed() {
                        Intent intent = new Intent(InstagramActivity.this, AllDownlodevideoActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    }
                });
            }
        });



        downloadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Utils.isNetworkAvailable(InstagramActivity.this)) {

                    if (linkEdt.getText().toString().trim().length() == 0) {
                        Toast.makeText(InstagramActivity.this, "Please paste url and download!!!!", Toast.LENGTH_SHORT).show();
                    } else {
                        final String url = linkEdt.getText().toString();

                        if (!Patterns.WEB_URL.matcher(url).matches() && !url.contains("instagram")) {
                            Toast.makeText(InstagramActivity.this, "Invalid Url...!", Toast.LENGTH_SHORT).show();
                        } else {
//                            InstaDownload.INSTANCE.startInstaDownload(url,InstagramActivity.this);
                            InstaDownload.INSTANCE.startInstaDownload(url,InstagramActivity.this);
                            linkEdt.getText().clear();
                        }
                    }
                } else {
                    Toast.makeText(InstagramActivity.this, "Internet Connection not available!!!!", Toast.LENGTH_SHORT).show();
                }
            }


        });

        btnpaste.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clipBoard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                try {
                    CharSequence textToPaste = clipBoard.getPrimaryClip().getItemAt(0).getText();
                    linkEdt.setText(textToPaste);
                } catch (Exception e) {
                    return;
                }
            }
        });

        btnOpenInstagram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                launchInstagram();
            }
        });


    }

    public void launchInstagram() {
        String instagramApp = "com.instagram.android";
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage(instagramApp);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), R.string.instagram_not_found, Toast.LENGTH_SHORT).show();
        }
    }
}