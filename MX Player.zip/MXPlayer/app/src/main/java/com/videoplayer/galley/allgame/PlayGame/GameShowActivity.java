package com.videoplayer.galley.allgame.PlayGame;




import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.videoplayer.galley.allgame.AdsDemo.Banner;
import com.videoplayer.galley.allgame.R;

import java.util.ArrayList;

public class GameShowActivity extends AppCompatActivity {
    ArrayList<ChildModelClass> arrayList = new ArrayList<>();
    GameShowAdapter childAdapter;
    RecyclerView recyclerView;
    TextView foldername1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_show);


        new Banner().showbannerads(this, findViewById(R.id.banner_container));

        foldername1 = findViewById(R.id.foldername);

        Bundle bundle = getIntent().getExtras();
        String position = bundle.getString("po");
        String foldername = bundle.getString("Foldername");
        arrayList = getIntent().getExtras().getParcelableArrayList("arrayP");

        foldername1.setText(foldername);
        recyclerView = findViewById(R.id.rvgame);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 3));
        childAdapter = new GameShowAdapter(arrayList, this);
        recyclerView.setAdapter(childAdapter);


    }
}