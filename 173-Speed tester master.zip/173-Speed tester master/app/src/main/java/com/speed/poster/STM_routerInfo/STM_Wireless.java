package com.speed.poster.STM_routerInfo;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.text.format.Formatter;

import java.math.BigInteger;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.ByteOrder;
import java.util.Enumeration;


public class STM_Wireless {
    private final Context context;

    public STM_Wireless(Context context) {
        this.context = context;
    }

    public String getMacAddress() {
        String macAddress = getWifiInfo().getMacAddress();
        if ("02:00:00:00:00:00".equals(macAddress)) {
            try {
                byte[] hardwareAddress = NetworkInterface.getByInetAddress(getWifiInetAddress()).getHardwareAddress();
                StringBuilder sb = new StringBuilder();
                int length = hardwareAddress.length;
                for (int i = 0; i < length; i++) {
                    sb.append(String.format("%02x:", Byte.valueOf(hardwareAddress[i])));
                }
                if (sb.length() > 0) {
                    sb.deleteCharAt(sb.length() - 1);
                }
                return sb.toString();
            } catch (SocketException e) {
                throw new RuntimeException(e);
            }
        }
        return macAddress;
    }

    private InetAddress getWifiInetAddress() {
        try {
            return InetAddress.getByName((String) getInternalWifiIpAddress(String.class));
        } catch (UnknownHostException e) {
            throw new RuntimeException(e);
        }
    }

    public String getBSSID() {
        return getWifiInfo().getBSSID();
    }

    public String getGetWay() {
        return String.valueOf(Formatter.formatIpAddress(getWifiManager().getDhcpInfo().gateway));
    }


    public <T> T getInternalWifiIpAddress(Class<T> cls) {
        int ipAddress = getWifiInfo().getIpAddress();
        if (ByteOrder.nativeOrder().equals(ByteOrder.LITTLE_ENDIAN)) {
            ipAddress = Integer.reverseBytes(ipAddress);
        }
        byte[] byteArray = BigInteger.valueOf(ipAddress).toByteArray();
        if (cls.isInstance("")) {
            try {
                return cls.cast(InetAddress.getByAddress(byteArray).getHostAddress());
            } catch (UnknownHostException e) {
                throw new RuntimeException(e);
            }
        }
        try {
            return cls.cast(Integer.valueOf(new BigInteger(InetAddress.getByAddress(byteArray).getAddress()).intValue()));
        } catch (UnknownHostException e2) {
            throw new RuntimeException(e2);
        }
    }

    public String getInternalMobileIpAddress() {
        try {
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            if (networkInterfaces == null || !networkInterfaces.hasMoreElements()) {
                return "Unknown";
            }
            Enumeration<InetAddress> inetAddresses = networkInterfaces.nextElement().getInetAddresses();
            while (true) {
                if (inetAddresses.hasMoreElements()) {
                    InetAddress nextElement = inetAddresses.nextElement();
                    if (!nextElement.isLoopbackAddress() && (nextElement instanceof Inet4Address)) {
                        return nextElement.getHostAddress();
                    }
                }
            }
        } catch (SocketException unused) {
            return "Unknown";
        }
    }

    public boolean isConnectedWifi() {
        NetworkInfo networkInfo = getNetworkInfo(1);
        return networkInfo != null && networkInfo.isConnectedOrConnecting();
    }

    public boolean isEnabled() {
        return getWifiManager().isWifiEnabled();
    }

    public WifiManager getWifiManager() {
        return (WifiManager) this.context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
    }

    public WifiInfo getWifiInfo() {
        return getWifiManager().getConnectionInfo();
    }

    private ConnectivityManager getConnectivityManager() {
        return (ConnectivityManager) this.context.getSystemService(Context.CONNECTIVITY_SERVICE);
    }

    private NetworkInfo getNetworkInfo(int i) {
        ConnectivityManager connectivityManager = getConnectivityManager();
        if (connectivityManager != null) {
            return connectivityManager.getNetworkInfo(i);
        }
        return null;
    }
}
