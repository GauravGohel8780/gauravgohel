package com.speed.poster.STM_wifiIpcalculator;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;


import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.speed.poster.Ads_Common.AdsBaseActivity;
import com.speed.poster.R;
import com.speed.poster.STM_speedtest.STM_spped_MainActivity;
import com.speed.poster.STM_wifiInfo.STM_WiFiInfoMainActivity;

@SuppressWarnings("all")
public class STM_Ipv4calculator_Activity extends AdsBaseActivity {
    private int CurrentBits;
    private String CurrentIP;
    Spinner spinner;
    Button calculate;
    EditText ipaddress;
    TextView address_range;
    TextView ip_binary_host;
    TextView ip_binary_netmask;
    TextView ip_binary_network;
    TextView maximum_addresses;
    TextView wildcard;
    Button reset;
    Spinner subnetmask;

    @Override 
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.stm_activity_ip_v4);
        Toolbar toolbar = findViewById(R.id.tbToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_toolbar_back_black_dark);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(STM_Ipv4calculator_Activity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

        this.ipaddress = (EditText) findViewById(R.id.etIPaddress);
        this.calculate = (Button) findViewById(R.id.btnCalculate);
        this.reset = (Button) findViewById(R.id.btnReset);
        this.address_range = (TextView) findViewById(R.id.tvAddressRange);
        this.maximum_addresses = (TextView) findViewById(R.id.tvMaximumAddresses);
        this.wildcard = (TextView) findViewById(R.id.tvWildcard);
        this.ip_binary_network = (TextView) findViewById(R.id.tvIpBinaryNetwork);
        this.ip_binary_host = (TextView) findViewById(R.id.tvIpBinaryHost);
        this.ip_binary_netmask = (TextView) findViewById(R.id.tvIpBinaryNetmask);
        this.spinner = (Spinner) findViewById(R.id.snrBitlength);
        this.subnetmask = (Spinner) findViewById(R.id.sprSubnetmask);
        ArrayAdapter<CharSequence> createFromResource = ArrayAdapter.createFromResource(this, R.array.arrays_bitlengths, R.layout.stm_spinner_item);
        createFromResource.setDropDownViewResource(17367049);
        this.spinner.setAdapter((SpinnerAdapter) createFromResource);
        ArrayAdapter<CharSequence> createFromResource2 = ArrayAdapter.createFromResource(this, R.array.subnets, R.layout.stm_spinner_item);
        createFromResource2.setDropDownViewResource(17367049);
        this.subnetmask.setAdapter((SpinnerAdapter) createFromResource2);
        this.calculate.setOnClickListener(new View.OnClickListener() {
            @Override 
            public void onClick(View view) {
                ((InputMethodManager) STM_Ipv4calculator_Activity.this.getSystemService(Context.INPUT_METHOD_SERVICE)).toggleSoftInput(1, 0);
                STM_Ipv4calculator_Activity.this.doCalculate();
            }
        });
        this.reset.setOnClickListener(new View.OnClickListener() {
            @Override 
            public void onClick(View view) {
                STM_Ipv4calculator_Activity.this.CurrentIP = "";
                STM_Ipv4calculator_Activity.this.CurrentBits = 24;
                STM_Ipv4calculator_Activity.this.updateFields();
                STM_Ipv4calculator_Activity.this.ClearResults();
            }
        });
        this.spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override 
            public void onNothingSelected(AdapterView<?> adapterView) {
            }

            @Override 
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                STM_Ipv4calculator_Activity.this.UpdateSubnetmaskFromBitlength();
                STM_Ipv4calculator_Activity.this.updateResults(true);
            }
        });
        this.subnetmask.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override 
            public void onNothingSelected(AdapterView<?> adapterView) {
            }

            @Override 
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                STM_Ipv4calculator_Activity.this.UpdateBitlengthFromSubnetmask();
                STM_Ipv4calculator_Activity.this.updateResults(true);
            }
        });
        this.spinner.setSelection(this.CurrentBits - 1);
        this.subnetmask.setSelection(this.CurrentBits - 1);
    }

    public void updateFields() {
        this.ipaddress.setText(this.CurrentIP);
        this.spinner.setSelection(this.CurrentBits - 1);
    }

    public void UpdateSubnetmaskFromBitlength() {
        this.subnetmask.setSelection(this.spinner.getSelectedItemPosition());
    }

    public void UpdateBitlengthFromSubnetmask() {
        this.spinner.setSelection(this.subnetmask.getSelectedItemPosition());
    }

    public void doCalculate() {
        if (updateResults(true)) {
            return;
        }
        this.address_range.setText("Bad IP format");
    }

    public static String convertIPIntDec2StringBinary(int i) {
        String binaryString = Integer.toBinaryString(i);
        int length = binaryString.length();
        if (length < 32) {
            for (int i2 = 0; i2 < 32 - length; i2++) {
                binaryString = "0" + binaryString;
            }
        }
        return binaryString.substring(0, 8) + "." + binaryString.substring(8, 16) + "." + binaryString.substring(16, 24) + "." + binaryString.substring(24, 32);
    }

    public boolean updateResults(boolean z) {
        Editable text = this.ipaddress.getText();
        if (text == null) {
            return false;
        }
        String obj = text.toString();
        try {
            int stringIPtoInt = stringIPtoInt(obj);
            String str = (String) this.spinner.getSelectedItem();
            if (str == null) {
                return false;
            }
            int parseInt = Integer.parseInt(str.substring(1));
            int i = (1 << (32 - parseInt)) - 1;
            int i2 = ~i;
            int i3 = stringIPtoInt & i2;
            String IntIPToString = IntIPToString(i3);
            String IntIPToString2 = IntIPToString(i3 | i);
            int i4 = i > 0 ? i - 1 : 0;
            String IntIPToString3 = IntIPToString(i);
            String convertIPIntDec2StringBinary = convertIPIntDec2StringBinary(stringIPtoInt);
            String convertIPIntDec2StringBinary2 = convertIPIntDec2StringBinary(i2);
            this.CurrentIP = obj;
            this.CurrentBits = parseInt;
            if (z) {
                this.address_range.setText(IntIPToString + " - " + IntIPToString2);
                try {
                    this.maximum_addresses.setText(String.format("%02d", Integer.valueOf(i4)));
                    this.wildcard.setText(IntIPToString3);
                    if (parseInt >= 24) {
                        parseInt += 3;
                    } else if (parseInt >= 16) {
                        parseInt += 2;
                    } else if (parseInt >= 8) {
                        parseInt++;
                    }
                    String substring = convertIPIntDec2StringBinary.substring(0, parseInt);
                    String substring2 = convertIPIntDec2StringBinary.substring(parseInt);
                    this.ip_binary_network.setText(substring);
                    this.ip_binary_host.setText(substring2);
                    this.ip_binary_netmask.setText(convertIPIntDec2StringBinary2);
                    PreferenceManager.getDefaultSharedPreferences(this).getBoolean("notification", false);
                    return true;
                } catch (Exception unused) {
                    ClearResults();
                    return false;
                }
            }
            return true;
        } catch (Exception unused2) {
            ClearResults();
            return false;
        }
    }

    public static int stringIPtoInt(String str) throws Exception {
        String[] split = str.split("\\.", 4);
        if (split.length == 4) {
            int i = 0;
            for (String str2 : split) {
                if (str2.length() >= 1) {
                    try {
                        int parseInt = Integer.parseInt(str2);
                        if (parseInt > 255) {
                            try {
                                try {
                                    throw new Exception();
                                } catch (Exception e) {
                                    throw new RuntimeException(e);
                                }
                            } catch (Exception e2) {
                                throw new RuntimeException(e2);
                            }
                        }
                        i = (i << 8) | parseInt;
                    } catch (NumberFormatException unused) {
                        throw new Exception();
                    }
                } else {
                    try {
                        throw new Exception();
                    } catch (Exception e3) {
                        throw new RuntimeException(e3);
                    }
                }
            }
            return i;
        }
        try {
            throw new Exception();
        } catch (Exception e4) {
            throw new RuntimeException(e4);
        }
    }

    private String IntIPToString(int i) {
        return String.format("%d.%d.%d.%d", Integer.valueOf((((-16777216) & i) >> 24) & 255), Integer.valueOf((16711680 & i) >> 16), Integer.valueOf((65280 & i) >> 8), Integer.valueOf(i & 255));
    }

    public void ClearResults() {
        this.address_range.setText("");
        this.maximum_addresses.setText("");
        this.wildcard.setText("");
        this.ip_binary_network.setText("");
        this.ip_binary_host.setText("");
        this.ip_binary_netmask.setText("");
    }

    @Override 
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    @Override 
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            return true;
        } else if (itemId == R.id.rate) {
            if (isOnline()) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } else {
                Toast makeText = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText.setGravity(17, 0, 0);
                makeText.show();
            }
            return true;
        } else if (itemId == R.id.share) {
            if (isOnline()) {
                Intent intent2 = new Intent("android.intent.action.SEND");
                intent2.setType("text/plain");
                intent2.putExtra("android.intent.extra.TEXT", "Hi! I'm using a Who Use My Wi-Fi application. Check it out:http://play.google.com/store/apps/details?id=" + getPackageName());
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(Intent.createChooser(intent2, "Share with Friends"));
            } else {
                Toast makeText2 = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText2.setGravity(17, 0, 0);
                makeText2.show();
            }
            return true;
        } else {
            return super.onOptionsItemSelected(menuItem);
        }
    }

    public boolean isOnline() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }
    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
