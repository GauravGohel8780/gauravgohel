package com.speed.poster.STM_speedtest.STM_spped_spped_test;


import java.io.BufferedReader;
import java.io.InputStream;
import java.io.StringReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;


public class STM_spped_DevilDownloadTest extends Thread {
    public String fileURL;
    long startTime = 0;
    long endTime = 0;
    double downloadElapsedTime = 0.0d;
    int downloadedByte = 0;
    double finalDownloadRate = 0.0d;
    boolean finished = false;
    double instantDownloadRate = 0.0d;
    int timeout = 8;
    HttpsURLConnection httpsConn = null;

    public STM_spped_DevilDownloadTest(String str) {
        this.fileURL = str;
    }

    private double round(double d, int i) {
        if (i < 0) {
            throw new IllegalArgumentException();
        }
        try {
            return new BigDecimal(d).setScale(i, RoundingMode.HALF_UP).doubleValue();
        } catch (Exception unused) {
            return 0.0d;
        }
    }

    public double getInstantDownloadRate() {
        return this.instantDownloadRate;
    }

    public void setInstantDownloadRate(int i, double d) {
        if (i >= 0) {
            this.instantDownloadRate = round(Double.valueOf(((i * 8) / 1000000) / d).doubleValue(), 2);
        } else {
            this.instantDownloadRate = 0.0d;
        }
    }

    public double getFinalDownloadRate() {
        return round(this.finalDownloadRate, 2);
    }

    public boolean isFinished() {
        return this.finished;
    }

    @Override
    public void run() {
        startTime = System.currentTimeMillis();
        downloadedByte = 0;

        ArrayList<String> urls = new ArrayList<>();
        urls.add(fileURL + "random4000x4000.jpg");
        urls.add(fileURL + "random3000x3000.jpg");

        for (String urlStr : urls) {
            try {
                URL url = new URL(urlStr);
                HttpsURLConnection httpsConn = (HttpsURLConnection) url.openConnection();
                httpsConn.setSSLSocketFactory((SSLSocketFactory) SSLSocketFactory.getDefault());

                String host = new BufferedReader(new StringReader(urlStr)).readLine().split("://")[1].split(":")[0];
                httpsConn.setHostnameVerifier(new HostnameVerifier() {
                    @Override
                    public boolean verify(String hostname, SSLSession session) {
                        return hostname.equals(host);
                    }
                });

                httpsConn.connect();

                if (httpsConn.getResponseCode() == 200) {
                    try (InputStream inputStream = httpsConn.getInputStream()) {
                        byte[] buffer = new byte[1024];
                        int bytesRead;

                        while ((bytesRead = inputStream.read(buffer)) != -1) {
                            downloadedByte += bytesRead;
                            endTime = System.currentTimeMillis();
                            downloadElapsedTime = (endTime - startTime) / 1000.0;
                            setInstantDownloadRate(this.downloadedByte, downloadElapsedTime);
                            if (downloadElapsedTime >= timeout) {
                                break;
                            }
                        }
                    }
                } else {
                    System.out.println("Link not found...");
                }

                httpsConn.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        endTime = System.currentTimeMillis();
        downloadElapsedTime = (endTime - startTime) / 1000.0;
        finalDownloadRate = ((downloadedByte * 8) / 1000000.0) / downloadElapsedTime;
        finished = true;
    }
}
