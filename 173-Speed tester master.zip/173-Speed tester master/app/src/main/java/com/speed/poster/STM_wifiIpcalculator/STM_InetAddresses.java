package com.speed.poster.STM_wifiIpcalculator;

import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.util.Arrays;


public class STM_InetAddresses {
    public static int fromBytes(byte b, byte b2, byte b3, byte b4) {
        return (b << 24) | ((b2 & (-1)) << 16) | ((b3 & (-1)) << 8) | (b4 & (-1));
    }

    public static boolean isMappedIPv4Address(String str) {
        byte[] ipStringToBytes = ipStringToBytes(str);
        if (ipStringToBytes == null || ipStringToBytes.length != 16) {
            return false;
        }
        int i = 0;
        while (true) {
            if (i >= 10) {
                for (int i2 = 10; i2 < 12; i2++) {
                    if (ipStringToBytes[i2] != -1) {
                        return false;
                    }
                }
                return true;
            } else if (ipStringToBytes[i] != 0) {
                return false;
            } else {
                i++;
            }
        }
    }

    public static byte[] ipStringToBytes(String str) {
        boolean z = false;
        boolean z2 = false;
        for (int i = 0; i < str.length(); i++) {
            char charAt = str.charAt(i);
            if (charAt == '.') {
                z2 = true;
            } else if (charAt == ':') {
                if (z2) {
                    return null;
                }
                z = true;
            } else if (Character.digit(charAt, 16) == -1) {
                return null;
            }
        }
        if (!z) {
            if (z2) {
                return textToNumericFormatV4(str);
            }
            return null;
        } else if (z2 && (str = convertDottedQuadToHex(str)) == null) {
            return null;
        } else {
            return textToNumericFormatV6(str);
        }
    }

    private static byte[] textToNumericFormatV4(String str) {
        String[] split = str.split("\\.", 5);
        if (split.length != 4) {
            return null;
        }
        byte[] bArr = new byte[4];
        for (int i = 0; i < 4; i++) {
            try {
                bArr[i] = parseOctet(split[i]);
            } catch (NumberFormatException unused) {
                return null;
            }
        }
        return bArr;
    }

    private static byte[] textToNumericFormatV6(String str) {
        int length;
        int i;
        String[] split = str.split(":", 10);
        if (split.length < 3 || split.length > 9) {
            return null;
        }
        int i2 = -1;
        for (int i3 = 1; i3 < split.length - 1; i3++) {
            if (split[i3].length() == 0) {
                if (i2 >= 0) {
                    return null;
                }
                i2 = i3;
            }
        }
        if (i2 >= 0) {
            int length2 = (split.length - i2) - 1;
            if (split[0].length() == 0 && i2 - 1 != 0) {
                return null;
            }
            if (split[split.length - 1].length() == 0 && length2 - 1 != 0) {
                return null;
            }
            i = length2;
            length = i2;
        } else {
            length = split.length;
            i = 0;
        }
        int i4 = 8 - (length + i);
        if (i2 >= 0) {
            if (i4 < 1) {
                return null;
            }
        } else if (i4 != 0) {
            return null;
        }
        ByteBuffer allocate = ByteBuffer.allocate(16);
        for (int i5 = 0; i5 < length; i5++) {
            try {
                allocate.putShort(parseHextet(split[i5]));
            } catch (NumberFormatException unused) {
                return null;
            }
        }
        for (int i6 = 0; i6 < i4; i6++) {
            allocate.putShort((short) 0);
        }
        while (i > 0) {
            allocate.putShort(parseHextet(split[split.length - i]));
            i--;
        }
        return allocate.array();
    }

    private static String convertDottedQuadToHex(String str) {
        int lastIndexOf = str.lastIndexOf(58) + 1;
        String substring = str.substring(0, lastIndexOf);
        byte[] textToNumericFormatV4 = textToNumericFormatV4(str.substring(lastIndexOf));
        if (textToNumericFormatV4 == null) {
            return null;
        }
        return substring + Integer.toHexString((textToNumericFormatV4[1] & (-1)) | ((textToNumericFormatV4[0] & (-1)) << 8)) + ":" + Integer.toHexString(((textToNumericFormatV4[2] & (-1)) << 8) | (textToNumericFormatV4[3] & (-1)));
    }

    private static byte parseOctet(String str) {
        int parseInt = Integer.parseInt(str);
        if (parseInt > 255 || (str.startsWith("0") && str.length() > 1)) {
            throw new NumberFormatException();
        }
        return (byte) parseInt;
    }

    private static short parseHextet(String str) {
        int parseInt = Integer.parseInt(str, 16);
        if (parseInt <= 65535) {
            return (short) parseInt;
        }
        throw new NumberFormatException();
    }

    public static String toAddrString(InetAddress inetAddress) {
        if (inetAddress == null) {
            return null;
        }
        if (inetAddress instanceof Inet4Address) {
            return inetAddress.getHostAddress();
        }
        if (inetAddress instanceof Inet6Address) {
            byte[] address = inetAddress.getAddress();
            int[] iArr = new int[8];
            for (int i = 0; i < 8; i++) {
                int i2 = i * 2;
                iArr[i] = fromBytes((byte) 0, (byte) 0, address[i2], address[i2 + 1]);
            }
            compressLongestRunOfZeroes(iArr);
            return hextetsToIPv6String(iArr);
        }
        return null;
    }

    private static void compressLongestRunOfZeroes(int[] iArr) {
        int i = -1;
        int i2 = -1;
        int i3 = -1;
        for (int i4 = 0; i4 < iArr.length + 1; i4++) {
            if (i4 >= iArr.length || iArr[i4] != 0) {
                if (i3 >= 0) {
                    int i5 = i4 - i3;
                    if (i5 > i) {
                        i2 = i3;
                        i = i5;
                    }
                    i3 = -1;
                }
            } else if (i3 < 0) {
                i3 = i4;
            }
        }
        if (i >= 2) {
            Arrays.fill(iArr, i2, i + i2, -1);
        }
    }

    private static String hextetsToIPv6String(int[] iArr) {
        StringBuilder sb = new StringBuilder(39);
        int i = 0;
        boolean z = false;
        while (i < iArr.length) {
            boolean z2 = iArr[i] >= 0;
            if (z2) {
                if (z) {
                    sb.append(':');
                }
                sb.append(Integer.toHexString(iArr[i]));
            } else if (i == 0 || z) {
                sb.append("::");
            }
            i++;
            z = z2;
        }
        return sb.toString();
    }
}
