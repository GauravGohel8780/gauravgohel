package com.speed.poster.STM_speedtest;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.speed.poster.Ads_Common.AdsBaseActivity;
import com.speed.poster.Ads_Common.ExitActivity;
import com.speed.poster.R;
import com.speed.poster.STM_speedtest.STM_spped_CustomAdapter.STM_spped_CustomAdapter;
import com.speed.poster.STM_speedtest.STM_spped_CustomAdapter.STM_spped_MyDatabaseHelper;

import java.util.ArrayList;
import java.util.Objects;

public class STM_spped_History extends AdsBaseActivity {
    private STM_spped_CustomAdapter customAdapter;
    ArrayList<String> download;
    STM_spped_MyDatabaseHelper myDB;
    ArrayList<String> ping;
    RecyclerView rvRecyclerView;
    ArrayList<String> time;
    ArrayList<String> type;
    ArrayList<String> upload;

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.stm_activity_history);
        this.rvRecyclerView = (RecyclerView) findViewById(R.id.rvRecyclerView);
        this.myDB = new STM_spped_MyDatabaseHelper(this);
        this.time = new ArrayList<>();
        this.type = new ArrayList<>();
        this.ping = new ArrayList<>();
        this.download = new ArrayList<>();
        this.upload = new ArrayList<>();
        storeDataInArrays();
        STM_spped_CustomAdapter spped_customadapter = new STM_spped_CustomAdapter(this, this, this.time, this.type, this.ping, this.download, this.upload);
        this.customAdapter = spped_customadapter;
        this.rvRecyclerView.setAdapter(spped_customadapter);
        this.rvRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    @Override
    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 1) {
            recreate();
        }
    }

    void storeDataInArrays() {
        Cursor readAllData = this.myDB.readAllData();
        if (readAllData.getCount() == 0) {
            return;
        }
        while (readAllData.moveToNext()) {
            this.time.add(readAllData.getString(1));
            this.ping.add(readAllData.getString(2));
            this.download.add(readAllData.getString(3));
            this.upload.add(readAllData.getString(4));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.setting) {
            Dialog dialog = new Dialog(STM_spped_History.this);
            dialog.setContentView(R.layout.stm_dialog_delete_history);
            dialog.setCancelable(false);
            dialog.show();

            dialog.getWindow().setLayout(-1, -2);

            Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(ContextCompat.getDrawable(STM_spped_History.this, android.R.color.transparent));


            CardView mcvNo = dialog.findViewById(R.id.mcvNo);
            CardView mcvYes = dialog.findViewById(R.id.mcvYes);


            mcvNo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
            mcvYes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    getInstance(STM_spped_History.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            Intent intent;
                            try {
                                STM_spped_History.this.myDB.deleteAllData();
                                intent = new Intent(STM_spped_History.this, STM_spped_MainActivity.class);
                            } catch (Exception unused) {
                                intent = new Intent(STM_spped_History.this, STM_spped_MainActivity.class);
                            } catch (Throwable th) {
                                STM_spped_History.this.startActivity(new Intent(STM_spped_History.this, STM_spped_MainActivity.class));
                                STM_spped_History.this.finish();
                                throw th;
                            }
                            STM_spped_History.this.startActivity(intent);
                            STM_spped_History.this.finish();
                            dialog.dismiss();
                        }
                    }, BACK_CLICK);
                }
            });
        }
        return super.onOptionsItemSelected(menuItem);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
