package com.speed.poster.STM_Tools_Ping;

import android.content.Context;
import android.text.InputFilter;
import android.text.Spanned;


public class STM_InputFilterMinMax implements InputFilter {
    private final int max;
    private final int min;

    private boolean isInRange(int i, int i2, int i3) {
        return i2 > i ? i3 >= i && i3 <= i2 : i3 >= i2 && i3 <= i;
    }

    public STM_InputFilterMinMax(int i, int i2) {
        this.min = i;
        this.max = i2;
    }

    public STM_InputFilterMinMax(String str, String str2, Context context, String str3) {
        this.min = Integer.parseInt(str);
        this.max = Integer.parseInt(str2);
    }

    @Override
    public CharSequence filter(CharSequence charSequence, int i, int i2, Spanned spanned, int i3, int i4) {
        try {
            if (isInRange(this.min, this.max, Integer.parseInt(charSequence.toString()))) {
                return null;
            }
            return "";
        } catch (NumberFormatException unused) {
            return charSequence;
        }
    }
}
