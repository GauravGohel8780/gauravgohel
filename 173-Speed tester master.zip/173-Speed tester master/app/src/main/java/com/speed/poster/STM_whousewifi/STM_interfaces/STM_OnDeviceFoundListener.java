package com.speed.poster.STM_whousewifi.STM_interfaces;

import com.speed.poster.STM_whousewifi.STM_DeviceFinder;
import com.speed.poster.STM_whousewifi.STM_models.STM_DeviceItem;

import java.util.List;


public interface STM_OnDeviceFoundListener {
    void onFailed(STM_DeviceFinder deviceFinder, int i);

    void onFinished(STM_DeviceFinder deviceFinder, List<STM_DeviceItem> list);

    void onStart(STM_DeviceFinder deviceFinder);
}
