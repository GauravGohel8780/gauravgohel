package com.speed.poster.STM_speedtest;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.Location;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.jtv7.rippleswitchlib.RippleSwitch;
import com.speed.poster.Ads_Common.AdsBaseActivity;
import com.speed.poster.Ads_Common.ExitActivity;
import com.speed.poster.R;
import com.speed.poster.STM_speedtest.STM_spped_CustomAdapter.STM_spped_MyDatabaseHelper;
import com.speed.poster.STM_speedtest.STM_spped_htmldialog.STM_spped_HtmlDialogListener;
import com.speed.poster.STM_speedtest.STM_spped_spped_test.STM_spped_DevilDownloadTest;
import com.speed.poster.STM_speedtest.STM_spped_spped_test.STM_spped_HttpUploadTest;
import com.speed.poster.STM_speedtest.STM_spped_spped_test.STM_spped_PingTest;
import com.speed.poster.STM_wifiInfo.STM_WifiInformationMainActivity;

import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

public class STM_spped_MainActivity extends AdsBaseActivity implements RippleSwitch.OnCheckedChangeListener {
    static int lastPosition;
    static int position;
    private Bitmap bitmap;
    private DecimalFormat dec;
    private DecimalFormat decmbs;
    private TextView downloadTextView;
    private TextView fdownload;
    private TextView fhost;
    private TextView flocation;
    private TextView fping;
    private TextView fupload;
    private TextView hostname;
    private TextView locationname;
    private TextView mdatametartype;
    private TextView mhead;
    private TextView pingTextView;
    private RippleSwitch rs;
    private ImageView speedface;
    private Button startButton;
    HashSet<String> tempBlackList;
    private Typeface type;
    private TextView uploadTextView;
    STM_spped_GetSpeedTestHostsHandler getSpeedTestHostsHandler = null;
    boolean doubleBackToExitPressedOnce = false;
    int timer = 0;
    private STM_spped_HtmlDialogListener listener = new STM_spped_HtmlDialogListener() {
        @Override
        public void onNegativeButtonPressed() {
        }

        @Override
        public void onPositiveButtonPressed() {
            SharedPreferences.Editor edit = STM_spped_MainActivity.this.getSharedPreferences("MyPrefsFile", 0).edit();
            edit.putString("Policy", "2nd");
            edit.apply();
        }
    };

    public int getPositionByRate(double d) {
        if (d <= 1.0d) {
            return (int) (d * 30.0d);
        }
        if (d <= 10.0d) {
            return ((int) (d * 6.0d)) + 30;
        }
        if (d <= 30.0d) {
            return ((int) ((d - 10.0d) * 3.0d)) + 90;
        }
        if (d <= 50.0d) {
            return ((int) ((d - 30.0d) * 1.5d)) + 150;
        }
        if (d <= 100.0d) {
            return ((int) ((d - 50.0d) * 1.2d)) + 180;
        }
        return 0;
    }

    @Override
    public void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
        STM_spped_GetSpeedTestHostsHandler spped_getspeedtesthostshandler = new STM_spped_GetSpeedTestHostsHandler();
        this.getSpeedTestHostsHandler = spped_getspeedtesthostshandler;
        spped_getspeedtesthostshandler.start();
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.stm_main_speed_layout);
        getSharedPreferences("MyPrefsFile", 0);
        this.startButton = (Button) findViewById(R.id.startButton);
        this.speedface = (ImageView) findViewById(R.id.ivSpeedoMiter);
        this.dec = new DecimalFormat("#.##");
        this.decmbs = new DecimalFormat("#.###");
        this.tempBlackList = new HashSet<>();
        STM_spped_GetSpeedTestHostsHandler spped_getspeedtesthostshandler = new STM_spped_GetSpeedTestHostsHandler();
        this.getSpeedTestHostsHandler = spped_getspeedtesthostshandler;
        spped_getspeedtesthostshandler.start();
        this.hostname = (TextView) findViewById(R.id.tvHosttxt);
        this.locationname = (TextView) findViewById(R.id.tvFocation);
        this.pingTextView = (TextView) findViewById(R.id.tvPingText);
        this.mhead = (TextView) findViewById(R.id.tvHeder);
        this.mdatametartype = (TextView) findViewById(R.id.tvDataMetarType);
        this.downloadTextView = (TextView) findViewById(R.id.tvDownloadText);
        this.uploadTextView = (TextView) findViewById(R.id.tvUploadText);
        this.fhost = (TextView) findViewById(R.id.tvFhost);
        this.fping = (TextView) findViewById(R.id.tvFping);
        this.flocation = (TextView) findViewById(R.id.tvFlocation);
        this.fdownload = (TextView) findViewById(R.id.textView2);
        this.fupload = (TextView) findViewById(R.id.textView3);
        this.fhost.setTypeface(this.type);
        this.fping.setTypeface(this.type);
        this.flocation.setTypeface(this.type);
        this.fdownload.setTypeface(this.type);
        this.fupload.setTypeface(this.type);
        this.mhead.setTypeface(this.type);
        this.mdatametartype.setTypeface(this.type);
        this.downloadTextView.setTypeface(this.type);
        this.uploadTextView.setTypeface(this.type);
        this.hostname.setTypeface(this.type);
        this.locationname.setTypeface(this.type);
        this.pingTextView.setTypeface(this.type);
        this.startButton.setTypeface(this.type);
        RippleSwitch rippleSwitch = (RippleSwitch) findViewById(R.id.rsRippleSwitch);
        this.rs = rippleSwitch;
        rippleSwitch.setOnCheckedChangeListener(this);
        ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        this.startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(STM_spped_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        STM_spped_MainActivity.this.mainrun();
                        STM_spped_MainActivity.this.startButton.setText("Running");
                    }
                }, MAIN_CLICK);
            }
        });

        findViewById(R.id.btnHistory).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(STM_spped_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        startActivity(new Intent(STM_spped_MainActivity.this, STM_spped_History.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    }
                }, MAIN_CLICK);
            }
        });


    }

    public void mainrun() {
        this.startButton.setEnabled(false);
        if (this.getSpeedTestHostsHandler == null) {
            STM_spped_GetSpeedTestHostsHandler spped_getspeedtesthostshandler = new STM_spped_GetSpeedTestHostsHandler();
            this.getSpeedTestHostsHandler = spped_getspeedtesthostshandler;
            spped_getspeedtesthostshandler.start();
        }
        new Thread(new AnonymousClass2()).start();
    }

    class AnonymousClass2 implements Runnable {
        ImageView barImageView;
        RotateAnimation rotate;

        AnonymousClass2() {
            this.barImageView = (ImageView) STM_spped_MainActivity.this.findViewById(R.id.barImageView);
        }

        @Override
        public void run() {
            boolean z;
            STM_spped_MainActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    STM_spped_MainActivity.this.mhead.setText("Selecting best server");
                }
            });
            int i = 600;
            while (!STM_spped_MainActivity.this.getSpeedTestHostsHandler.isFinished()) {
                i--;
                try {
                    Thread.sleep(100L);
                    continue;
                } catch (InterruptedException unused) {

                }
                if (i <= 0) {
                    STM_spped_MainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(STM_spped_MainActivity.this.getApplicationContext(), "No Connection...", Toast.LENGTH_LONG).show();
                            STM_spped_MainActivity.this.startButton.setEnabled(true);
                            STM_spped_MainActivity.this.startButton.setText("Restart Test");
                            try {
                                STM_spped_MainActivity.this.mhead.setText(R.string.app_name);
                            } catch (Exception unused2) {
                            }
                        }
                    });
                    STM_spped_MainActivity.this.getSpeedTestHostsHandler = null;
                    return;
                }
            }
            HashMap<Integer, String> mapKey = STM_spped_MainActivity.this.getSpeedTestHostsHandler.getMapKey();
            HashMap<Integer, List<String>> mapValue = STM_spped_MainActivity.this.getSpeedTestHostsHandler.getMapValue();
            double selfLat = STM_spped_MainActivity.this.getSpeedTestHostsHandler.getSelfLat();
            double selfLon = STM_spped_MainActivity.this.getSpeedTestHostsHandler.getSelfLon();
            double d = 1.9349458E7d;
            int i2 = 0;
            for (Integer num : mapKey.keySet()) {
                int intValue = num.intValue();
                if (!STM_spped_MainActivity.this.tempBlackList.contains(mapValue.get(Integer.valueOf(intValue)).get(5))) {
                    Location location = new Location("Source");
                    location.setLatitude(selfLat);
                    location.setLongitude(selfLon);
                    List<String> list = mapValue.get(Integer.valueOf(intValue));
                    double d2 = selfLat;
                    Location location2 = new Location("Dest");
                    location2.setLatitude(Double.parseDouble(list.get(0)));
                    location2.setLongitude(Double.parseDouble(list.get(1)));
                    double distanceTo = location.distanceTo(location2);
                    if (d > distanceTo) {
                        d = distanceTo;
                        i2 = intValue;
                    }
                    selfLat = d2;
                }
            }
            String replace = mapKey.get(Integer.valueOf(i2)).replace("http://", "https://");
            final List<String> list2 = mapValue.get(Integer.valueOf(i2));
            if (list2 == null) {
                STM_spped_MainActivity.this.runOnUiThread(new Runnable() {
                    @Override 
                    public void run() {
                        STM_spped_MainActivity.this.mhead.setText("There was a problem");
                    }
                });
                return;
            }
            STM_spped_MainActivity.this.runOnUiThread(new Runnable() {
                @Override 
                public void run() {
                    STM_spped_MainActivity.this.hostname.setText((CharSequence) list2.get(5));
                    STM_spped_MainActivity.this.locationname.setText((CharSequence) list2.get(3));
                }
            });
            STM_spped_MainActivity.this.runOnUiThread(new Runnable() {
                @Override 
                public void run() {
                    STM_spped_MainActivity.this.pingTextView.setText("0 ms");
                    if (STM_spped_MainActivity.this.rs.isChecked()) {
                        STM_spped_MainActivity.this.downloadTextView.setText("0 MB/s");
                        STM_spped_MainActivity.this.uploadTextView.setText("0 MB/s");
                        return;
                    }
                    STM_spped_MainActivity.this.downloadTextView.setText("0 Mbps");
                    STM_spped_MainActivity.this.uploadTextView.setText("0 Mbps");
                }
            });
            final ArrayList arrayList = new ArrayList();
            final ArrayList arrayList2 = new ArrayList();
            final ArrayList arrayList3 = new ArrayList();
            Boolean bool = false;
            Boolean bool2 = false;
            Boolean bool3 = false;
            Boolean bool4 = false;
            Boolean bool5 = false;
            Boolean bool6 = false;
            final STM_spped_PingTest spped_pingtest = new STM_spped_PingTest(list2.get(6).replace(":8080", ""), 3);
            boolean z2 = true;
            final STM_spped_DevilDownloadTest spped_devildownloadtest = new STM_spped_DevilDownloadTest(replace.replace(replace.split("/")[replace.split("/").length - 1], ""));
            final STM_spped_HttpUploadTest spped_httpuploadtest = new STM_spped_HttpUploadTest(replace);
            while (true) {
                if (!bool.booleanValue()) {
                    spped_pingtest.start();
                    bool = Boolean.valueOf(z2);
                }
                if (bool2.booleanValue() && !bool3.booleanValue()) {
                    spped_devildownloadtest.start();
                    bool3 = Boolean.valueOf(z2);
                }
                if (bool4.booleanValue() && !bool5.booleanValue()) {
                    spped_httpuploadtest.start();
                    bool5 = Boolean.valueOf(z2);
                }
                if (bool2.booleanValue()) {
                    if (spped_pingtest.getAvgRtt() == 0.0d) {
                        System.out.println("Ping error...");
                    } else {
                        STM_spped_MainActivity.this.runOnUiThread(new Runnable() {
                            @Override 
                            public void run() {
                                STM_spped_MainActivity.this.pingTextView.setText(STM_spped_MainActivity.this.dec.format(spped_pingtest.getAvgRtt()) + " ms");
                                try {
                                    STM_spped_MainActivity.this.mhead.setText("PING");
                                } catch (Exception unused2) {
                                }
                            }
                        });
                    }
                } else {
                    arrayList.add(Double.valueOf(spped_pingtest.getInstantRtt()));
                    STM_spped_MainActivity.this.runOnUiThread(new Runnable() {
                        @Override 
                        public void run() {
                            STM_spped_MainActivity.this.pingTextView.setText(STM_spped_MainActivity.this.dec.format(spped_pingtest.getInstantRtt()) + " ms");
                            try {
                                STM_spped_MainActivity.this.mhead.setText("PING");
                            } catch (Exception unused2) {
                            }
                        }
                    });
                    STM_spped_MainActivity.this.runOnUiThread(new Runnable() {
                        @Override 
                        public void run() {
                            XYSeries xYSeries = new XYSeries("");
                            xYSeries.setTitle("");
                            int i3 = 0;
                            for (Object d3 : new ArrayList(arrayList)) {
                                xYSeries.add(i3, (Double) d3);
                                i3++;
                            }
                            new XYMultipleSeriesDataset().addSeries(xYSeries);
                        }
                    });
                }
                if (bool2.booleanValue()) {
                    if (bool4.booleanValue()) {
                        if (spped_devildownloadtest.getFinalDownloadRate() == 0.0d) {
                            System.out.println("Download error...");
                        } else {
                            STM_spped_MainActivity.this.runOnUiThread(new Runnable() {
                                @Override 
                                public void run() {
                                    if (STM_spped_MainActivity.this.rs.isChecked()) {
                                        STM_spped_MainActivity.this.downloadTextView.setText(STM_spped_MainActivity.this.decmbs.format(spped_devildownloadtest.getFinalDownloadRate() / 8.0d) + " MB/s");
                                    } else {
                                        STM_spped_MainActivity.this.downloadTextView.setText(STM_spped_MainActivity.this.dec.format(spped_devildownloadtest.getFinalDownloadRate()) + " Mbps");
                                    }
                                    try {
                                        STM_spped_MainActivity.this.mhead.setText("DOWNLOAD");
                                    } catch (Exception unused2) {
                                    }
                                }
                            });
                        }
                    } else {
                        double instantDownloadRate = spped_devildownloadtest.getInstantDownloadRate();
                        arrayList2.add(Double.valueOf(instantDownloadRate));
                        if (STM_spped_MainActivity.this.rs.isChecked()) {
                            STM_spped_MainActivity.position = STM_spped_MainActivity.this.getPositionByRate(instantDownloadRate / 8.0d);
                        } else {
                            STM_spped_MainActivity.position = STM_spped_MainActivity.this.getPositionByRate(instantDownloadRate);
                        }
                        STM_spped_MainActivity.this.runOnUiThread(new Runnable() {
                            @Override 
                            public void run() {
                                AnonymousClass2.this.rotate = new RotateAnimation(STM_spped_MainActivity.lastPosition, STM_spped_MainActivity.position, 1, 0.5f, 1, 0.5f);
                                AnonymousClass2.this.rotate.setInterpolator(new LinearInterpolator());
                                AnonymousClass2.this.rotate.setDuration(100L);
                                AnonymousClass2.this.barImageView.startAnimation(AnonymousClass2.this.rotate);
                                if (STM_spped_MainActivity.this.rs.isChecked()) {
                                    STM_spped_MainActivity.this.downloadTextView.setText(STM_spped_MainActivity.this.decmbs.format(spped_devildownloadtest.getInstantDownloadRate() / 8.0d) + " MB/s");
                                } else {
                                    STM_spped_MainActivity.this.downloadTextView.setText(STM_spped_MainActivity.this.dec.format(spped_devildownloadtest.getInstantDownloadRate()) + " Mbps");
                                }
                                try {
                                    STM_spped_MainActivity.this.mhead.setText("DOWNLOAD");
                                } catch (Exception unused2) {
                                }
                            }
                        });
                        STM_spped_MainActivity.lastPosition = STM_spped_MainActivity.position;
                        STM_spped_MainActivity.this.runOnUiThread(new Runnable() {
                            @Override 
                            public void run() {
                                XYSeries xYSeries = new XYSeries("");
                                xYSeries.setTitle("");
                                int i3 = 0;
                                for (Object d3 : new ArrayList(arrayList2)) {
                                    xYSeries.add(i3, (Double) d3);
                                    i3++;
                                }
                                new XYMultipleSeriesDataset().addSeries(xYSeries);
                            }
                        });
                    }
                }
                if (bool4.booleanValue()) {
                    if (bool6.booleanValue()) {
                        if (spped_httpuploadtest.getFinalUploadRate() == 0.0d) {
                            System.out.println("Upload error...");
                        } else {
                            STM_spped_MainActivity.this.runOnUiThread(new Runnable() {
                                @Override 
                                public void run() {
                                    if (STM_spped_MainActivity.this.rs.isChecked()) {
                                        STM_spped_MainActivity.this.uploadTextView.setText(STM_spped_MainActivity.this.decmbs.format(spped_httpuploadtest.getFinalUploadRate() / 8.0d) + " MM/s");
                                    } else {
                                        STM_spped_MainActivity.this.uploadTextView.setText(STM_spped_MainActivity.this.dec.format(spped_httpuploadtest.getFinalUploadRate()) + " Mbps");
                                    }
                                    try {
                                        STM_spped_MainActivity.this.mhead.setText("UPLOAD");
                                    } catch (Exception unused2) {
                                    }
                                }
                            });
                        }
                    } else {
                        double instantUploadRate = spped_httpuploadtest.getInstantUploadRate();
                        arrayList3.add(Double.valueOf(instantUploadRate));
                        if (STM_spped_MainActivity.this.rs.isChecked()) {
                            STM_spped_MainActivity.position = STM_spped_MainActivity.this.getPositionByRate(instantUploadRate / 8.0d);
                        } else {
                            STM_spped_MainActivity.position = STM_spped_MainActivity.this.getPositionByRate(instantUploadRate);
                        }
                        STM_spped_MainActivity.this.runOnUiThread(new Runnable() {
                            @Override 
                            public void run() {
                                AnonymousClass2.this.rotate = new RotateAnimation(STM_spped_MainActivity.lastPosition, STM_spped_MainActivity.position, 1, 0.5f, 1, 0.5f);
                                AnonymousClass2.this.rotate.setInterpolator(new LinearInterpolator());
                                AnonymousClass2.this.rotate.setDuration(100L);
                                AnonymousClass2.this.barImageView.startAnimation(AnonymousClass2.this.rotate);
                                if (STM_spped_MainActivity.this.rs.isChecked()) {
                                    STM_spped_MainActivity.this.uploadTextView.setText(STM_spped_MainActivity.this.decmbs.format(spped_httpuploadtest.getInstantUploadRate() / 8.0d) + " MB/s");
                                } else {
                                    STM_spped_MainActivity.this.uploadTextView.setText(STM_spped_MainActivity.this.dec.format(spped_httpuploadtest.getInstantUploadRate()) + " Mbps");
                                }
                                try {
                                    STM_spped_MainActivity.this.mhead.setText("UPLOAD");
                                } catch (Exception unused2) {
                                }
                            }
                        });
                        STM_spped_MainActivity.lastPosition = STM_spped_MainActivity.position;
                        STM_spped_MainActivity.this.runOnUiThread(new Runnable() {
                            @Override 
                            public void run() {
                                XYSeries xYSeries = new XYSeries("");
                                xYSeries.setTitle("");
                                int i3 = 0;
                                for (Object d3 : new ArrayList(arrayList3)) {
                                    if (i3 == 0) {
                                        d3 = Double.valueOf(0.0d);
                                    }
                                    xYSeries.add(i3, (double) d3);
                                    i3++;
                                }
                                new XYMultipleSeriesDataset().addSeries(xYSeries);
                            }
                        });
                    }
                }
                if (!bool2.booleanValue() || !bool4.booleanValue() || !spped_httpuploadtest.isFinished()) {
                    if (spped_pingtest.isFinished()) {
                        z = true;
                        bool2 = true;
                    } else {
                        z = true;
                    }
                    if (spped_devildownloadtest.isFinished()) {
                        bool4 = Boolean.valueOf(z);
                    }
                    if (spped_httpuploadtest.isFinished()) {
                        bool6 = Boolean.valueOf(z);
                    }
                    if (bool.booleanValue() && !bool2.booleanValue()) {
                        try {
                            Thread.sleep(300L);
                        } catch (InterruptedException unused2) {
                        }
                    } else {
                        try {
                            Thread.sleep(100L);
                        } catch (InterruptedException unused3) {
                        }
                    }
                    z2 = z;
                } else {
                    STM_spped_MainActivity.this.runOnUiThread(new Runnable() {
                        @Override 
                        public void run() {
                            STM_spped_MainActivity.this.startButton.setEnabled(true);
                            STM_spped_MainActivity.this.startButton.setText("Restart Test");
                            try {
                                STM_spped_MainActivity.this.mhead.setText(R.string.app_name);
                            } catch (Exception unused4) {
                            }
                            STM_spped_MainActivity.this.sharing();
                            Toast.makeText(STM_spped_MainActivity.this, "" + STM_spped_MainActivity.this.pingTextView.getText().toString().trim(), Toast.LENGTH_SHORT).show();
                            String time = new SimpleDateFormat("HH:mm a", Locale.getDefault()).format(new Date()).trim();
                            new STM_spped_MyDatabaseHelper(STM_spped_MainActivity.this).addBook(time, STM_spped_MainActivity.this.pingTextView.getText().toString().trim(), STM_spped_MainActivity.this.downloadTextView.getText().toString().trim(), STM_spped_MainActivity.this.uploadTextView.getText().toString().trim());
                        }
                    });
                    return;
                }
            }
        }
    }

    @Override
    public void onCheckChanged(boolean z) {
        if (this.rs.isChecked()) {
            this.mdatametartype.setText("MEGABYTE PER SECOND");
            this.downloadTextView.setText("0 MB/s");
            this.uploadTextView.setText("0 MB/s");
            this.speedface.setImageResource(R.drawable.ic_megabyteps);
            return;
        }
        this.mdatametartype.setText("MEGABIT PER SECOND");
        this.downloadTextView.setText("0 Mbps");
        this.uploadTextView.setText("0 Mbps");
        this.speedface.setImageResource(R.drawable.ic_megabitps);
    }

    public void sharing() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.CustomDialog);
        View inflate = getLayoutInflater().inflate(R.layout.stm_share_activity, (ViewGroup) null);
        TextView textView = (TextView) inflate.findViewById(R.id.tvRping);
        TextView textView2 = (TextView) inflate.findViewById(R.id.tvRdownload);
        TextView textView3 = (TextView) inflate.findViewById(R.id.tvRupload);
        ((TextView) inflate.findViewById(R.id.tvTimeview)).setText(new SimpleDateFormat("HH:mm:ss a", Locale.getDefault()).format(new Date()));
        ((TextView) inflate.findViewById(R.id.tvDateview)).setText(new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date()));
        TextView textView4 = (TextView) inflate.findViewById(R.id.tvThostingname);
        TextView textView5 = (TextView) inflate.findViewById(R.id.tvTestTlocationname);
        textView.setTypeface(this.type);
        textView2.setTypeface(this.type);
        textView3.setTypeface(this.type);
        ((TextView) inflate.findViewById(R.id.tvTping)).setTypeface(this.type);
        ((TextView) inflate.findViewById(R.id.tdownload)).setTypeface(this.type);
        ((TextView) inflate.findViewById(R.id.tupload)).setTypeface(this.type);
        ((TextView) inflate.findViewById(R.id.tvSharehead)).setTypeface(this.type);
        ((TextView) inflate.findViewById(R.id.tvSubhead)).setTypeface(this.type);
        textView4.setTypeface(this.type);
        textView5.setTypeface(this.type);
        textView.setText(this.pingTextView.getText().toString());
        textView2.setText(this.downloadTextView.getText().toString());
        textView3.setText(this.uploadTextView.getText().toString());


        SpannableString spannableString = new SpannableString("SERVER : " + this.hostname.getText().toString());
        spannableString.setSpan(new ForegroundColorSpan(Color.BLACK), 0, "SERVER : ".length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableString.setSpan(new StyleSpan(Typeface.BOLD), 0, "SERVER : ".length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableString.setSpan(new ForegroundColorSpan(Color.parseColor("#242424")), "SERVER : ".length(), spannableString.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView4.setText(spannableString);


        SpannableString spannableString1 = new SpannableString("LOCATION : " + this.locationname.getText().toString());
        spannableString1.setSpan(new ForegroundColorSpan(Color.BLACK), 0, "LOCATION : ".length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableString1.setSpan(new StyleSpan(Typeface.BOLD), 0, "LOCATION : ".length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView5.setText(spannableString1);
        builder.setView(inflate);
        final AlertDialog create = builder.create();
        create.setCanceledOnTouchOutside(true);
        create.show();

    }

    @Override
    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 102 && i2 == -1) {
            Toast.makeText(this, "Draw over other app permission enable.", Toast.LENGTH_SHORT).show();
        }
    }
}
