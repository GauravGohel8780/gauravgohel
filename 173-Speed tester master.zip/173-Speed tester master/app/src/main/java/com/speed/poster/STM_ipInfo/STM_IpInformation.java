package com.speed.poster.STM_ipInfo;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.DhcpInfo;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.format.Formatter;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;


import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.speed.poster.Ads_Common.AdsBaseActivity;
import com.speed.poster.STM_AppUtils;
import com.speed.poster.R;
import com.speed.poster.STM_wifiInfo.STM_WiFiInfoMainActivity;
import com.speed.poster.STM_wifiInfo.STM_WifiInformationMainActivity;

import org.jsoup.Jsoup;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class STM_IpInformation extends AdsBaseActivity {
    public String broadcastadd;
    public String bssid;
    public boolean checkFirstTime = true;
    public String city;
    public String connectiontype;
    public String country;
    public String externalip;
    TextView txtnid;
    TextView txtOrg;
    TextView txtRegion;
    TextView txtSSID;
    TextView txtServerAd;
    TextView txtSignal;
    TextView txtSpeed;
    TextView txtTimeZone;
    TextView txttype;
    TextView ip;
    WifiManager wifiManager;
    Context context;
    DhcpInfo dhcpInfo;
    ProgressBar progressbbar;
    TextView txtBroadcast;
    TextView txtBssid;
    TextView txtCity;
    TextView txtConnectionType;
    TextView txtCoordinates;
    TextView txtCountry;
    TextView txtDnso;
    TextView txtDnst;
    TextView txtFrequency;
    TextView txtGateway;
    TextView txtHost;
    TextView txtInternalIp;
    TextView txtLeasae;
    TextView txtLocalhost;
    TextView txtMacAd;
    TextView txtMask;
    public String frequency;
    public String gateway;
    public String host;
    public String internalip;
    public String lat;
    public String lng;
    public String localhost;
    public String macad;
    public String maskm;
    public String networkid;
    public String organization;
    public String region;
    public String s_dns1;
    public String s_dns2;
    public String s_gateway;
    public String s_ipAddress;
    public String s_leaseDuration;
    public String s_netmask;
    public String s_serverAddress;
    public String server;
    public String signal;
    public String speed;
    public String ssid;
    public String timezone;
    public String type;

    @Override
    public void onPointerCaptureChanged(boolean z) {

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            return true;
        } else if (itemId == R.id.rate) {
            if (isOnline()) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } else {
                Toast makeText = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText.setGravity(17, 0, 0);
                makeText.show();
            }
            return true;
        } else if (itemId == R.id.share) {
            if (isOnline()) {
                Intent intent2 = new Intent("android.intent.action.SEND");
                intent2.setType("text/plain");
                intent2.putExtra("android.intent.extra.TEXT", "Hi! I'm using a Who Use My Wi-Fi application. Check it out:http://play.google.com/store/apps/details?id=" + getPackageName());
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(Intent.createChooser(intent2, "Share with Friends"));
            } else {
                Toast makeText2 = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText2.setGravity(17, 0, 0);
                makeText2.show();
            }
            return true;
        } else {
            return super.onOptionsItemSelected(menuItem);
        }
    }

    public boolean isOnline() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    @Override 
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.stm_ip_information_activity);
        this.context = this;
        Toolbar toolbar = findViewById(R.id.tbToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_toolbar_back_black_dark);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(STM_IpInformation.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

        this.progressbbar = (ProgressBar) findViewById(R.id.progressbbar);
        this.ip = (TextView) findViewById(R.id.tvIp);
        this.txtOrg = (TextView) findViewById(R.id.tvOrg);
        this.txtSignal = (TextView) findViewById(R.id.tvSignal);
        this.txtSpeed = (TextView) findViewById(R.id.tvSpeed);
        this.txtCity = (TextView) findViewById(R.id.tvCity);
        this.txtRegion = (TextView) findViewById(R.id.tvRegion);
        this.txtCountry = (TextView) findViewById(R.id.tvCountry);
        this.txtTimeZone = (TextView) findViewById(R.id.tvTimeZone);
        this.txtCoordinates = (TextView) findViewById(R.id.tvCoordinates);
        this.txtSSID = (TextView) findViewById(R.id.tvSSID);
        this.txtHost = (TextView) findViewById(R.id.tvHost);
        this.txtInternalIp = (TextView) findViewById(R.id.tvInternalIp);
        this.txtMacAd = (TextView) findViewById(R.id.tvMacAd);
        this.txtBroadcast = (TextView) findViewById(R.id.tvBroadcast);
        this.txtMask = (TextView) findViewById(R.id.tvMask);
        this.txtGateway = (TextView) findViewById(R.id.tvGateway);
        this.txtDnso = (TextView) findViewById(R.id.tvDnso);
        this.txtDnst = (TextView) findViewById(R.id.tvDnst);
        this.txtLocalhost = (TextView) findViewById(R.id.tvLocalhost);
        this.txtFrequency = (TextView) findViewById(R.id.txtFrequency);
        this.txtBssid = (TextView) findViewById(R.id.tvBssid);
        this.txtLeasae = (TextView) findViewById(R.id.tvLeasae);
        this.txtServerAd = (TextView) findViewById(R.id.tvServerAd);
        this.txtConnectionType = (TextView) findViewById(R.id.tvConnectionType);
        this.txttype = (TextView) findViewById(R.id.tvtype);
        this.txtnid = (TextView) findViewById(R.id.tvnid);
        this.wifiManager = (WifiManager) this.context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        checkConnection();
        new JsoupAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
    }

    
    public class JsoupAsyncTask extends AsyncTask<Void, Void, Boolean> {
        String jsonstirng
                ;

        private JsoupAsyncTask() {
            this.jsonstirng = "";
        }

        @Override 
        public void onPreExecute() {
            try {
                super.onPreExecute();
            } catch (Exception e) {
                e.printStackTrace();
            }
            STM_IpInformation.this.progressbbar.setVisibility(View.VISIBLE);
        }

        @Override 
        public Boolean doInBackground(Void... voidArr) {
            try {
                this.jsonstirng = new OkHttpClient().newCall(new Request.Builder().url("https://api.ipify.org/").build()).execute().body().string().trim();
                return null;
            } catch (IOException e) {
                this.jsonstirng = "";
                e.printStackTrace();
                return null;
            } catch (Throwable th) {
                try {
                    try {
                        th.printStackTrace();
                        return false;
                    } catch (Exception unused) {
                        this.jsonstirng = Jsoup.connect("http://checkip.amazonaws.com/").ignoreContentType(true).get().select("body").text().trim();
                        return null;
                    }
                } catch (IOException e2) {
                    e2.printStackTrace();
                    return null;
                }
            }
        }

        @Override 
        public void onPostExecute(Boolean bool) {
            try {
                STM_IpInformation ipInformation = STM_IpInformation.this;
                ipInformation.checkFirstTime = false;
                ipInformation.getHeroes(this.jsonstirng);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override 
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        try {
            super.onRequestPermissionsResult(i, strArr, iArr);
            if (i == 112) {
                int length = strArr.length;
                boolean z = false;
                for (int i2 = 0; i2 < length; i2++) {
                    String str = strArr[i2];
                    if (iArr[i2] == -1) {
                        if (!shouldShowRequestPermissionRationale(str)) {
                            break;
                        }
                        z = true;
                    }
                }
                if (z) {
                    ActivityCompat.requestPermissions(this, strArr, 112);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadData() {
        try {
            WifiInfo connectionInfo = this.wifiManager.getConnectionInfo();
            Log.i("spped", "loadData: " + connectionInfo.getLinkSpeed() + "mbps");
            this.txtSpeed.setText(connectionInfo.getLinkSpeed() + "mbps");
            this.internalip = Formatter.formatIpAddress(connectionInfo.getIpAddress());
            try {
                ConnectivityManager connectivityManager = (ConnectivityManager) this.context.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
                int i = 0;
                boolean isConnectedOrConnecting = connectivityManager.getNetworkInfo(0).isConnectedOrConnecting();
                boolean isConnectedOrConnecting2 = connectivityManager.getNetworkInfo(1).isConnectedOrConnecting();
                System.out.println(isConnectedOrConnecting + " net " + isConnectedOrConnecting2);
                if (isConnectedOrConnecting) {
                    int rssi = ((WifiManager) this.context.getApplicationContext().getSystemService(Context.WIFI_SERVICE)).getConnectionInfo().getRssi();
                    this.internalip = getIpAddress();
                    this.signal = "0 %" + rssi + "dBm";
                    this.connectiontype = "MOBILE";
                    this.txtSignal.setText("MOBILE");
                    this.localhost = "127.0.0.1";
                    STM_AppUtils.isConnected(this.context.getApplicationContext());
                    String str = STM_AppUtils.mobileNetwork;
                    this.type = str;
                    this.txttype.setText(str);
                    this.macad = mac();
                    this.speed = "0 Mbps";
                    this.bssid = "No Available";
                    this.broadcastadd = "No Available";
                    this.maskm = "0.0.0.0";
                    this.networkid = "No Available";
                } else if (isConnectedOrConnecting2) {
                    this.signal = ((WifiManager) this.context.getApplicationContext().getSystemService(Context.WIFI_SERVICE)).getConnectionInfo().getRssi() + "dBm";
                    this.connectiontype = "WIFI";
                    this.localhost = "127.0.0.1";
                    try {
                        i = connectionInfo.getLinkSpeed();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    this.speed = i + " Mbps";
                    this.macad = mac();
                    getBroadcast(InetAddress.getByName(this.internalip));
                    this.maskm = msk();
                    this.bssid = String.valueOf(this.wifiManager.getConnectionInfo().getBSSID());
                    STM_AppUtils.isConnected(this.context.getApplicationContext());
                    this.type = STM_AppUtils.mobileNetwork;
                    this.networkid = String.valueOf(this.wifiManager.getConnectionInfo().getNetworkId());
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
            DhcpInfo dhcpInfo = this.wifiManager.getDhcpInfo();
            this.dhcpInfo = dhcpInfo;
            this.s_dns1 = String.valueOf(Formatter.formatIpAddress(dhcpInfo.dns1));
            this.s_dns2 = String.valueOf(this.dhcpInfo.dns2);
            this.s_gateway = String.valueOf(Formatter.formatIpAddress(this.dhcpInfo.gateway));
            this.s_ipAddress = String.valueOf(this.dhcpInfo.ipAddress);
            this.s_leaseDuration = String.valueOf(this.dhcpInfo.leaseDuration);
            this.s_netmask = String.valueOf(this.dhcpInfo.netmask);
            this.s_serverAddress = String.valueOf(Formatter.formatIpAddress(this.dhcpInfo.serverAddress));
            this.ssid = this.wifiManager.getConnectionInfo().getSSID();
            this.frequency = this.wifiManager.getConnectionInfo().getFrequency() + " MHz";
            this.ip.setText(this.externalip);
            this.txtSignal.setText(this.signal);
            this.txtSpeed.setText(this.speed);
            String str2 = this.ssid;
            if (str2 != null && !str2.isEmpty() && !this.ssid.equals("null")) {
                this.ssid = this.ssid.replace("\"", "");
            }
            this.txtSSID.setText(this.ssid);
            this.txtHost.setText(this.externalip);
            this.txtInternalIp.setText(this.internalip);
            this.txtMacAd.setText(this.macad);
            this.txtBroadcast.setText(this.broadcastadd);
            this.txtMask.setText(this.maskm);
            this.txtGateway.setText(this.s_gateway);
            this.txtDnso.setText(this.s_dns1);
            this.txtDnst.setText(this.s_dns2);
            this.txtLocalhost.setText(this.localhost);
            this.txtFrequency.setText(this.frequency);
            this.txtBssid.setText(this.bssid);
            this.txtLeasae.setText(this.s_leaseDuration);
            this.txtServerAd.setText(this.s_serverAddress);
            this.txttype.setText(this.type);
            this.txtConnectionType.setText(this.connectiontype);
            this.txtnid.setText(this.networkid);
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    private void checkConnection() {
        boolean isConnected = STM_ConnectivityReceiver.isConnected();
        if (isConnected) {
            showSnack(isConnected);
            return;
        }
        Toast makeText = Toast.makeText(getApplicationContext(), "No Internet Connection", Toast.LENGTH_SHORT);
        makeText.setGravity(17, 0, 0);
        makeText.show();
    }

    private void showSnack(boolean z) {
        if (z) {
            new JsoupAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
            return;
        }
        Toast makeText = Toast.makeText(getApplicationContext(), "No Internet Connection", Toast.LENGTH_SHORT);
        makeText.setGravity(17, 0, 0);
        makeText.show();
        try {
            this.txtOrg.setText("No Available");
            this.ip.setText("No Available");
            this.txtCity.setText("No Available");
            this.txtRegion.setText("No Available");
            this.txtCountry.setText("No Available");
            this.txtTimeZone.setText("No Available");
            this.txtHost.setText("No Available");
            this.ip.setText("No Available");
            this.txtSignal.setText("No Available");
            this.txtSpeed.setText("No Available");
            this.txtSSID.setText("No Available");
            this.txtHost.setText("No Available");
            this.txtInternalIp.setText("No Available");
            this.txtMacAd.setText("No Available");
            this.txtBroadcast.setText("No Available");
            this.txtMask.setText("No Available");
            this.txtGateway.setText("No Available");
            this.txtDnso.setText("No Available");
            this.txtDnst.setText("No Available");
            this.txtLeasae.setText("No Available");
            this.txtBssid.setText("No Available");
            this.txtServerAd.setText("No Available");
            this.txttype.setText("No Available");
            this.txtLocalhost.setText("No Available");
            this.txtFrequency.setText("No Available");
            this.txtnid.setText("No Available");
            this.txtCoordinates.setText("Latitude: 0.0\nLongitude: 0.0");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void getHeroes(final String str) {
        STM_Api api = (STM_Api) new Retrofit.Builder().baseUrl(STM_Api.BASE_URL).addConverterFactory(GsonConverterFactory.create()).build().create(STM_Api.class);
        Log.e("Public IP", str);
        try {
            api.getIPINFO("json/").enqueue(new Callback<STM_IPinfo>() {
                @Override 
                public void onResponse(Call<STM_IPinfo> call, Response<STM_IPinfo> response) {
                    try {
                        STM_IpInformation.this.externalip = str;
                        if (!response.body().getStatus().equalsIgnoreCase("success")) {
                            STM_IpInformation.this.progressbbar.setVisibility(View.GONE);
                            return;
                        }
                        Log.e("Public IP", str);
                        STM_IpInformation.this.country = response.body().getCountry();
                        STM_IpInformation.this.timezone = response.body().getTimezone();
                        STM_IpInformation.this.city = response.body().getCity();
                        STM_IpInformation.this.region = response.body().getRegionName();
                        STM_IpInformation.this.lat = response.body().getLat();
                        STM_IpInformation.this.lng = response.body().getLon();
                        STM_IpInformation.this.progressbbar.setVisibility(View.GONE);
                        STM_IpInformation ipInformation = STM_IpInformation.this;
                        ipInformation.txtOrg.setText(ipInformation.organization);
                        STM_IpInformation.this.ip.setText(" " + STM_IpInformation.this.externalip);
                        STM_IpInformation ipInformation2 = STM_IpInformation.this;
                        ipInformation2.txtCity.setText(ipInformation2.city);
                        STM_IpInformation ipInformation3 = STM_IpInformation.this;
                        ipInformation3.txtRegion.setText(ipInformation3.region);
                        STM_IpInformation ipInformation4 = STM_IpInformation.this;
                        ipInformation4.txtCountry.setText(ipInformation4.country);
                        STM_IpInformation ipInformation5 = STM_IpInformation.this;
                        ipInformation5.txtTimeZone.setText(ipInformation5.timezone);
                        STM_IpInformation ipInformation6 = STM_IpInformation.this;
                        ipInformation6.txtHost.setText(ipInformation6.externalip);
                        STM_IpInformation.this.txtCoordinates.setText("Latitude: " + STM_IpInformation.this.lat + "\nLongitude: " + STM_IpInformation.this.lng);
                        STM_IpInformation.this.loadData();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(Call<STM_IPinfo> call, Throwable th) {
                    STM_IpInformation.this.progressbbar.setVisibility(View.GONE);
                    th.printStackTrace();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String getIpAddress() {
        try {
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            if (!networkInterfaces.hasMoreElements()) {
                return null;
            }
            Enumeration<InetAddress> inetAddresses = networkInterfaces.nextElement().getInetAddresses();
            while (true) {
                if (inetAddresses.hasMoreElements()) {
                    InetAddress nextElement = inetAddresses.nextElement();
                    if (!nextElement.isLoopbackAddress() && (nextElement instanceof Inet4Address)) {
                        return nextElement.getHostAddress();
                    }
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String mac() {
        try {
            Iterator it = Collections.list(NetworkInterface.getNetworkInterfaces()).iterator();
            while (it.hasNext()) {
                NetworkInterface networkInterface = (NetworkInterface) it.next();
                if (networkInterface.getName().equalsIgnoreCase("wlan0")) {
                    byte[] hardwareAddress = networkInterface.getHardwareAddress();
                    if (hardwareAddress == null) {
                        return "";
                    }
                    StringBuilder sb = new StringBuilder();
                    int length = hardwareAddress.length;
                    for (int i = 0; i < length; i++) {
                        sb.append(Integer.toHexString(hardwareAddress[i] & (-1)) + ":");
                    }
                    if (sb.length() > 0) {
                        sb.deleteCharAt(sb.length() - 1);
                    }
                    return sb.toString();
                }
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public InetAddress getBroadcast(InetAddress inetAddress) {
        try {
            InetAddress inetAddress2 = null;
            for (InterfaceAddress interfaceAddress : NetworkInterface.getByInetAddress(inetAddress).getInterfaceAddresses()) {
                inetAddress2 = interfaceAddress.getBroadcast();
                if (inetAddress2 != null) {
                    this.broadcastadd = inetAddress2.toString().replace("/", "");
                }
            }
            return inetAddress2;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public String msk() {
        String str;
        try {
            str = this.internalip;
        } catch (Exception e) {
            try {
                e.printStackTrace();
                str = null;
            } catch (Exception e2) {
                e2.printStackTrace();
                return null;
            }
        }
        int parseInt = Integer.parseInt(str.split("\\.")[0]);
        return parseInt <= 127 ? "255.0.0.0" : parseInt <= 191 ? "255.255.0.0" : parseInt <= 223 ? "255.255.255.0" : (parseInt <= 239 || parseInt <= 254) ? "255.0.0.0" : "";
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall1).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall2).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall3).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}
