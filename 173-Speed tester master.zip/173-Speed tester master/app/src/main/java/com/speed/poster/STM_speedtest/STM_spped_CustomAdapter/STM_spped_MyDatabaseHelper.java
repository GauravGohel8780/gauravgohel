package com.speed.poster.STM_speedtest.STM_spped_CustomAdapter;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;


public class STM_spped_MyDatabaseHelper extends SQLiteOpenHelper {
    private static final String COLUMN_DOWNLOAD = "hs_download";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_PING = "hs_ping";
    private static final String COLUMN_TIME = "hs_time";
    private static final String COLUMN_TYPE = "hs_type";
    private static final String COLUMN_UPLOAD = "hs_upload";
    private static final String DATABASE_NAME = "HSLibrary.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "my_HS";
    private Context context;

    public STM_spped_MyDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 1);
        this.context = context;
    }

    @Override 
    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL("CREATE TABLE my_HS (_id INTEGER PRIMARY KEY AUTOINCREMENT, hs_time TEXT, hs_ping TEXT, hs_download TEXT, hs_upload TEXT);");
    }

    @Override 
    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS my_HS");
        onCreate(sQLiteDatabase);
    }

    public void addBook(String str, String str2, String str3, String str4) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_TIME, str);
        contentValues.put(COLUMN_PING, str2);
        contentValues.put(COLUMN_DOWNLOAD, str3);
        contentValues.put(COLUMN_UPLOAD, str4);
        if (writableDatabase.insert(TABLE_NAME, null, contentValues) == -1) {
            Toast.makeText(this.context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this.context, "Added History!", Toast.LENGTH_SHORT).show();
        }
    }

    public Cursor readAllData() {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        if (readableDatabase != null) {
            return readableDatabase.rawQuery("SELECT * FROM my_HS", null);
        }
        return null;
    }

    void updateData(String str, String str2, String str3, String str4, String str5, String str6) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_TIME, str2);
        contentValues.put(COLUMN_PING, str4);
        contentValues.put(COLUMN_DOWNLOAD, str5);
        contentValues.put(COLUMN_UPLOAD, str6);
        if (writableDatabase.update(TABLE_NAME, contentValues, "_id=?", new String[]{str}) == -1) {
            Toast.makeText(this.context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this.context, "Updated Successfully!", Toast.LENGTH_SHORT).show();
        }
    }

    void deleteOneRow(String str) {
        if (getWritableDatabase().delete(TABLE_NAME, "_id=?", new String[]{str}) == -1) {
            Toast.makeText(this.context, "Failed to Delete.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this.context, "Successfully Deleted.", Toast.LENGTH_SHORT).show();
        }
    }

    public void deleteAllData() {
        getWritableDatabase().execSQL("DELETE FROM my_HS");
    }
}
