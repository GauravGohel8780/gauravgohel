package com.speed.poster.STM_wifiRouterPassword;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.speed.poster.R;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;

public class STM_RouterPasswordAdapter extends RecyclerView.Adapter<STM_RouterPasswordAdapter.ViewHolder> implements Filterable {
    private final ArrayList<STM_DataModel> arraylist;
    private final ArrayList<STM_DataModel> dataSet;

    @Override
    public Filter getFilter() {
        return null;
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        public View layout;
        public TextView txtBrand;
        public TextView txtPassword;
        public TextView txtType;
        public TextView txtUsername;
        public ViewHolder(STM_RouterPasswordAdapter routerPasswordAdapter, View view) {
            super(view);
            this.layout = view;
            this.txtBrand = (TextView) view.findViewById(R.id.tvBrand);
            this.txtType = (TextView) view.findViewById(R.id.tvType);
            this.txtUsername = (TextView) view.findViewById(R.id.tvUsername);
            this.txtPassword = (TextView) view.findViewById(R.id.tvPassword);
        }
    }

    public STM_RouterPasswordAdapter(Context context, ArrayList<STM_DataModel> arrayList) {
        ArrayList<STM_DataModel> arrayList2 = new ArrayList<>();
        this.arraylist = arrayList2;
        this.dataSet = arrayList;
        arrayList2.addAll(arrayList);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(this, LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.stm_router_password_item, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        viewHolder.txtBrand.setText(this.dataSet.get(i).getBrand());
        viewHolder.txtPassword.setText(this.dataSet.get(i).getPassword());
        viewHolder.txtType.setText(this.dataSet.get(i).getType());
        viewHolder.txtUsername.setText(this.dataSet.get(i).getUsername());
    }

    public void filter(String str, String str2) {
        try {
            this.dataSet.clear();
            if (!str.isEmpty() && !str2.isEmpty()) {
                Iterator<STM_DataModel> it = this.arraylist.iterator();
                while (it.hasNext()) {
                    STM_DataModel next = it.next();
                    if (next.getType() != null) {
                        Log.i("ContentValues", "filter BOTH: CALLED");
                        if (next.getType().toLowerCase(Locale.getDefault()).contains(str2.toLowerCase()) && next.getBrand().toLowerCase(Locale.getDefault()).contains(str.toLowerCase())) {
                            this.dataSet.add(next);
                        }
                    }
                }
            } else if (!str2.isEmpty()) {
                Log.i("ContentValues", "filter: 11111");
                Iterator<STM_DataModel> it2 = this.arraylist.iterator();
                while (it2.hasNext()) {
                    STM_DataModel next2 = it2.next();
                    if (next2.getType() != null && next2.getType().toLowerCase(Locale.getDefault()).contains(str2.toLowerCase())) {
                        this.dataSet.add(next2);
                    }
                }
            } else if (!str.isEmpty()) {
                Log.i("ContentValues", "filter: 222222");
                Iterator<STM_DataModel> it3 = this.arraylist.iterator();
                while (it3.hasNext()) {
                    STM_DataModel next3 = it3.next();
                    if (next3.getBrand().toLowerCase(Locale.getDefault()).contains(str.toLowerCase())) {
                        this.dataSet.add(next3);
                    }
                }
            } else if (str.isEmpty()) {
                Iterator<STM_DataModel> it4 = this.arraylist.iterator();
                while (it4.hasNext()) {
                    this.dataSet.add(it4.next());
                }
            }
            notifyDataSetChanged();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return this.dataSet.size();
    }
}



