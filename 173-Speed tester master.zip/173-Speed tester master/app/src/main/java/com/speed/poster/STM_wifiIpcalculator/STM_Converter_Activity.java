package com.speed.poster.STM_wifiIpcalculator;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.speed.poster.Ads_Common.AdsBaseActivity;
import com.speed.poster.R;
import com.speed.poster.STM_wifiInfo.STM_WiFiInfoMainActivity;


public class STM_Converter_Activity extends AdsBaseActivity {
    private String currentIP;
    Button btnConvertbin;
    Button btnConvertdec;
    Button btnConverthex;
    EditText etIpbinary;
    EditText etIphex;
    EditText etConverterIpaddress;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.stm_activity_converter);
        Toolbar toolbar = findViewById(R.id.tbToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_toolbar_back_black_dark);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(STM_Converter_Activity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

        this.etConverterIpaddress = (EditText) findViewById(R.id.etConverterIpaddress);
        this.etIpbinary = (EditText) findViewById(R.id.etIpbinary);
        this.etIphex = (EditText) findViewById(R.id.etIphex);
        this.btnConvertdec = (Button) findViewById(R.id.btnConvertdec);
        this.btnConvertbin = (Button) findViewById(R.id.btnConvertbin);
        this.btnConverthex = (Button) findViewById(R.id.btnConverthex);
        this.btnConvertdec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((InputMethodManager) STM_Converter_Activity.this.getSystemService(Context.INPUT_METHOD_SERVICE)).toggleSoftInput(1, 0);
                if (STM_Converter_Activity.this.etConverterIpaddress.getText().toString().trim().length() == 0) {
                    Toast.makeText(STM_Converter_Activity.this.getApplicationContext(), (int) R.string.stm_err_bad_ip, Toast.LENGTH_SHORT).show();
                } else {
                    STM_Converter_Activity.this.convertDecimal();
                }
            }
        });
        this.btnConvertbin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((InputMethodManager) STM_Converter_Activity.this.getSystemService(Context.INPUT_METHOD_SERVICE)).toggleSoftInput(1, 0);
                if (STM_Converter_Activity.this.etIpbinary.getText().toString().trim().length() == 0) {
                    Toast.makeText(STM_Converter_Activity.this.getApplicationContext(), (int) R.string.stm_err_bad_ip, Toast.LENGTH_SHORT).show();
                } else {
                    STM_Converter_Activity.this.convertBinary();
                }
            }
        });
        this.btnConverthex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((InputMethodManager) STM_Converter_Activity.this.getSystemService(Context.INPUT_METHOD_SERVICE)).toggleSoftInput(1, 0);
                if (STM_Converter_Activity.this.etIphex.getText().toString().trim().length() == 0) {
                    Toast.makeText(STM_Converter_Activity.this.getApplicationContext(), (int) R.string.stm_err_bad_ip, Toast.LENGTH_SHORT).show();
                } else {
                    STM_Converter_Activity.this.convertHex();
                }
            }
        });
    }

    public static int stringIPtoInt(String str) throws Exception {
        String[] split = str.split("\\.", 4);
        if (split.length == 4) {
            int i = 0;
            for (String str2 : split) {
                if (str2.length() >= 1) {
                    try {
                        int parseInt = Integer.parseInt(str2);
                        if (parseInt > 255) {
                            try {
                                try {
                                    throw new Exception();
                                } catch (Exception e) {
                                    throw new RuntimeException(e);
                                }
                            } catch (Exception e2) {
                                throw new RuntimeException(e2);
                            }
                        }
                        i = (i << 8) | parseInt;
                    } catch (NumberFormatException unused) {
                        throw new Exception();
                    }
                } else {
                    try {
                        throw new Exception();
                    } catch (Exception e3) {
                        throw new RuntimeException(e3);
                    }
                }
            }
            return i;
        }
        try {
            throw new Exception();
        } catch (Exception e4) {
            throw new RuntimeException(e4);
        }
    }

    public void convertDecimal() {
        String trim = this.etConverterIpaddress.getText().toString().trim();
        try {
            int stringIPtoInt = stringIPtoInt(trim);
            this.currentIP = trim;
            this.etIpbinary.setText(convertIPIntDec2StringBinary(stringIPtoInt));
            this.etIphex.setText(convertIPIntDec2StringHex(stringIPtoInt));
        } catch (Exception unused) {
        }
    }

    String trim;

    public void convertBinary() {

        if (this.etIpbinary.getText().toString().trim().length() >= 32) {
            try {
                String str = Integer.parseInt(trim.substring(0, 8), 2) + "." + Integer.parseInt(trim.substring(9, 17), 2) + "." + Integer.parseInt(trim.substring(18, 26), 2) + "." + Integer.parseInt(trim.substring(27, 35), 2);
                this.currentIP = str;
                this.etConverterIpaddress.setText(str);
                this.etIphex.setText(convertIPIntDec2StringHex(stringIPtoInt(this.currentIP)));
            } catch (Exception unused) {
            }
        }
    }

    public void convertHex() {
        if (this.etIphex.getText().toString().trim().length() >= 11) {
            try {
                String str = Integer.parseInt(trim.substring(0, 2), 16) + "." + Integer.parseInt(trim.substring(3, 5), 16) + "." + Integer.parseInt(trim.substring(6, 8), 16) + "." + Integer.parseInt(trim.substring(9, 11), 16);
                this.currentIP = str;
                this.etConverterIpaddress.setText(str);
                this.etIpbinary.setText(convertIPIntDec2StringBinary(stringIPtoInt(this.currentIP)));
            } catch (Exception unused) {
            }
        }
    }

    public static String convertIPIntDec2StringBinary(int i) {
        String binaryString = Integer.toBinaryString(i);
        int length = binaryString.length();
        if (length < 32) {
            for (int i2 = 0; i2 < 32 - length; i2++) {
                binaryString = "0" + binaryString;
            }
        }
        return binaryString.substring(0, 8) + "." + binaryString.substring(8, 16) + "." + binaryString.substring(16, 24) + "." + binaryString.substring(24, 32);
    }

    public static String convertIPIntDec2StringHex(int i) {
        String hexString = Integer.toHexString(i);
        int length = hexString.length();
        if (length < 8) {
            for (int i2 = 0; i2 < 8 - length; i2++) {
                hexString = "0" + hexString;
            }
        }
        return hexString.substring(0, 2) + "." + hexString.substring(2, 4) + "." + hexString.substring(4, 6) + "." + hexString.substring(6, 8);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            return true;
        } else if (itemId == R.id.rate) {
            if (isOnline()) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } else {
                Toast makeText = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText.setGravity(17, 0, 0);
                makeText.show();
            }
            return true;
        } else if (itemId == R.id.share) {
            if (isOnline()) {
                Intent intent2 = new Intent("android.intent.action.SEND");
                intent2.setType("text/plain");
                intent2.putExtra("android.intent.extra.TEXT", "Hi! I'm using a Who Use My Wi-Fi application. Check it out:http://play.google.com/store/apps/details?id=" + getPackageName());
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(Intent.createChooser(intent2, "Share with Friends"));
            } else {
                Toast makeText2 = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText2.setGravity(17, 0, 0);
                makeText2.show();
            }
            return true;
        } else {
            return super.onOptionsItemSelected(menuItem);
        }
    }

    public boolean isOnline() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
