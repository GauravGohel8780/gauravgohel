package com.speed.poster;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.speed.poster.Ads_Common.AdsBaseActivity;
import com.speed.poster.Ads_Common.ExitActivity;
import com.speed.poster.STM_Tools_Ping.STM_PingToolsActivity;

import com.speed.poster.STM_Wifi_common.STM_Intro_Activity;
import com.speed.poster.STM_routerInfo.STM_RouterInfoMainActivity;
import com.speed.poster.STM_whousewifi.STM_WhoUseWiFiMainActivity;
import com.speed.poster.STM_wifiInfo.STM_WiFiInfoMainActivity;
import com.speed.poster.STM_wifiIpcalculator.STM_Ipcalculator_Activity;
import com.speed.poster.STM_speedtest.STM_spped_MainActivity;

import java.util.Objects;


public class STM_MainActivity extends AdsBaseActivity {
    public static final String ACTION_CLOSE = "ACTION_CLOSE";
    private static final int PERMISSION_REQUEST_CODE = 1;
    Activity activity;
    Context context;
    ImageView imgWiFiOnOff;
    LinearLayout linPingTools;
    LinearLayout linRouterInfo;
    LinearLayout linWhoUseWiFi;
    LinearLayout linWiFiOnOff;
    LinearLayout linWiFiOnOffView;
    LinearLayout linWifiInfo;
    LinearLayout lin_calculator;
    AppCompatTextView txtHomeTitle;
    private FirstReceiver firstReceiver;
    LinearLayout sppedtets;

    private boolean checkPermission() {
        return ContextCompat.checkSelfPermission(this.context, "android.permission.ACCESS_FINE_LOCATION") == 0 || ContextCompat.checkSelfPermission(this.context, "android.permission.ACCESS_COARSE_LOCATION") == 0;
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this.activity, new String[]{"android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"}, 1);
    }


    class FirstReceiver extends BroadcastReceiver {
        FirstReceiver() {
        }

        @Override 
        public void onReceive(Context context, Intent intent) {
            Log.e("FirstReceiver", "FirstReceiver");
            if (intent.getAction().equals(STM_MainActivity.ACTION_CLOSE)) {
                STM_MainActivity.this.finish();
            }
        }
    }

    @Override
    
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.stm_activity_main_home);
        IntentFilter intentFilter = new IntentFilter(ACTION_CLOSE);
        FirstReceiver firstReceiver = new FirstReceiver();
        this.firstReceiver = firstReceiver;

        this.context = this;
        this.activity = this;
        setSupportActionBar((Toolbar) findViewById(R.id.tbToolbar));
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        this.linWiFiOnOffView = (LinearLayout) findViewById(R.id.llWiFiOnOffView);
        this.linWiFiOnOff = (LinearLayout) findViewById(R.id.llWiFiOnOff);
        this.linPingTools = (LinearLayout) findViewById(R.id.llPingTools);
        this.linWifiInfo = (LinearLayout) findViewById(R.id.llWifiInfo);
        this.linRouterInfo = (LinearLayout) findViewById(R.id.llRouterInfo);
        this.linWhoUseWiFi = (LinearLayout) findViewById(R.id.llWhoUseWiFi);
        this.lin_calculator = (LinearLayout) findViewById(R.id.llCalculator);
        this.sppedtets = (LinearLayout) findViewById(R.id.llsppedtets);
        this.txtHomeTitle = (AppCompatTextView) findViewById(R.id.tvHomeTitle);
        this.imgWiFiOnOff = (ImageView) findViewById(R.id.imgWiFiOnOff);
        this.linWiFiOnOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= 29) {
                    Intent intent = new Intent("android.settings.WIFI_SETTINGS");
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    STM_MainActivity.this.startActivity(intent);
                } else if (STM_MainActivity.this.isWifiEnabled()) {
                    ((WifiManager) STM_MainActivity.this.getApplicationContext().getSystemService(Context.WIFI_SERVICE)).setWifiEnabled(false);
                    STM_MainActivity.this.imgWiFiOnOff.setImageResource(R.drawable.ic_wifi_off_home_page);
                    STM_MainActivity.this.txtHomeTitle.setText("Tap to Enable Wi-Fi");
                } else {
                    ((WifiManager) STM_MainActivity.this.getApplicationContext().getSystemService(Context.WIFI_SERVICE)).setWifiEnabled(true);
                    STM_MainActivity.this.imgWiFiOnOff.setImageResource(R.drawable.ic_wifi_on_home_page);
                    STM_MainActivity.this.txtHomeTitle.setText("Tap to Disable Wi-Fi");
                }
            }
        });
        this.linPingTools.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(STM_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(STM_MainActivity.this, STM_PingToolsActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        STM_MainActivity.this.startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });
        this.linWifiInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(STM_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(STM_MainActivity.this, STM_WiFiInfoMainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        STM_MainActivity.this.startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });
        this.linRouterInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(STM_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(STM_MainActivity.this, STM_RouterInfoMainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        STM_MainActivity.this.startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });
        this.linWhoUseWiFi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(STM_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(STM_MainActivity.this, STM_WhoUseWiFiMainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        STM_MainActivity.this.startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });
        this.lin_calculator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(STM_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(STM_MainActivity.this, STM_Ipcalculator_Activity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        STM_MainActivity.this.startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });
        this.sppedtets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(STM_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        STM_MainActivity.this.startActivity(new Intent(STM_MainActivity.this, STM_spped_MainActivity.class));
                    }
                }, MAIN_CLICK);
            }
        });

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                getInstance(STM_MainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        startActivity(new Intent(STM_MainActivity.this, ExitActivity.class));
                    }
                }, BACK_CLICK);
            }
        };

        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            return true;
        } else if (itemId == R.id.rate) {
            if (isOnline()) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } else {
                Toast makeText = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText.setGravity(17, 0, 0);
                makeText.show();
            }
            return true;
        } else if (itemId == R.id.share) {
            if (isOnline()) {
                Intent intent2 = new Intent("android.intent.action.SEND");
                intent2.setType("text/plain");
                intent2.putExtra("android.intent.extra.TEXT", "Hi! I'm using a Who Use My Wi-Fi application. Check it out:http://play.google.com/store/apps/details?id=" + getPackageName());
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(Intent.createChooser(intent2, "Share with Friends"));
            } else {
                Toast makeText2 = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText2.setGravity(17, 0, 0);
                makeText2.show();
            }
            return true;
        } else {
            return super.onOptionsItemSelected(menuItem);
        }
    }

    public boolean isOnline() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    @Override
    public void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
        if (checkPermission()) {
            Log.e("pn", "");
        } else {
            Log.e("npg", "");
            requestPermission();
        }
        if (isWifiEnabled()) {
            this.imgWiFiOnOff.setImageResource(R.drawable.ic_wifi_on_home_page);
            this.txtHomeTitle.setText("Tap to Disable Wi-Fi");
            return;
        }
        this.imgWiFiOnOff.setImageResource(R.drawable.ic_wifi_off_home_page);
        this.txtHomeTitle.setText("Tap to Enable Wi-Fi");
    }

    public boolean isWifiEnabled() {
        return ((WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE)).isWifiEnabled();
    }


}
