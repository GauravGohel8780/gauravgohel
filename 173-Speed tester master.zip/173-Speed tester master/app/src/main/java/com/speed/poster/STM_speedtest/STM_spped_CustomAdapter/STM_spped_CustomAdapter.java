package com.speed.poster.STM_speedtest.STM_spped_CustomAdapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.speed.poster.R;

import java.util.ArrayList;


public class STM_spped_CustomAdapter extends RecyclerView.Adapter<STM_spped_CustomAdapter.MyViewHolder> {
    private Activity activity;
    private Context context;
    private ArrayList download;
    private ArrayList ping;
    private ArrayList time;
    private ArrayList type;
    private ArrayList upload;

    public STM_spped_CustomAdapter(Activity activity, Context context, ArrayList arrayList, ArrayList arrayList2, ArrayList arrayList3, ArrayList arrayList4, ArrayList arrayList5) {
        this.activity = activity;
        this.context = context;
        this.time = arrayList;
        this.type = arrayList2;
        this.ping = arrayList3;
        this.download = arrayList4;
        this.upload = arrayList5;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(this.context).inflate(R.layout.stm_history_row_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {
        myViewHolder.time_txt.setText(String.valueOf(this.time.get(i)));
        myViewHolder.ping_txt.setText(String.valueOf(this.ping.get(i)));
        myViewHolder.download_txt.setText(String.valueOf(this.download.get(i)));
        myViewHolder.upload_txt.setText(String.valueOf(this.upload.get(i)));
    }

    @Override
    public int getItemCount() {
        return this.time.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView download_txt;
        LinearLayout mainLayout;
        TextView ping_txt;
        TextView time_txt;
        TextView upload_txt;

        MyViewHolder(View view) {
            super(view);
            this.time_txt = (TextView) view.findViewById(R.id.tvMTime);
            this.ping_txt = (TextView) view.findViewById(R.id.tvMPing);
            this.download_txt = (TextView) view.findViewById(R.id.tvMDownload);
            this.upload_txt = (TextView) view.findViewById(R.id.tvMUpload);
            this.mainLayout = (LinearLayout) view.findViewById(R.id.mainLayout);
        }
    }
}
