package com.speed.poster.STM_Tools_Ping;

import android.app.Activity;
import android.content.SharedPreferences;
import android.util.Log;


public abstract class STM_MyUtility {
    public static boolean addping(Activity activity, String str) {
        String stringFromPreferences = getStringFromPreferences(activity, null, "ping");
        if (stringFromPreferences == null || stringFromPreferences.isEmpty() || !stringFromPreferences.contains(str)) {
            if (stringFromPreferences != null) {
                str = stringFromPreferences + "," + str;
            }
            return putStringInPreferences(activity, str, "ping");
        }
        return false;
    }

    public static String[] getping(Activity activity) {
        try {
            String stringFromPreferences = getStringFromPreferences(activity, null, "ping");
            if (stringFromPreferences != null && !stringFromPreferences.isEmpty()) {
                return convertStringToArray(stringFromPreferences);
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static boolean putStringInPreferences(Activity activity, String str, String str2) {
        SharedPreferences.Editor edit = activity.getPreferences(0).edit();
        edit.putString(str2, str);
        edit.commit();
        return true;
    }

    private static String getStringFromPreferences(Activity activity, String str, String str2) {
        String string = activity.getPreferences(0).getString(str2, str);
        Log.i("TAG", "getStringFromPreferences: " + string);
        return string;
    }

    private static String[] convertStringToArray(String str) {
        try {
            return str.split(",");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
