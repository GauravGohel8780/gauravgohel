package com.speed.poster.STM_wifiInfo;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.format.Formatter;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;


import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.speed.poster.Ads_Common.AdsBaseActivity;
import com.speed.poster.Ads_Common.ExitActivity;
import com.speed.poster.STM_AppUtils;
import com.speed.poster.R;

import com.speed.poster.STM_MainActivity;
import com.speed.poster.STM_ipInfo.STM_ConnectivityReceiver;
import com.speed.poster.STM_ipInfo.STM_IpInformation;
import com.speed.poster.STM_wifiList.STM_WifiListActivity;
import com.speed.poster.STM_wifiStrenghth.STM_WifiStrengthMainActivity;

import org.jsoup.Jsoup;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.Objects;

import okhttp3.OkHttpClient;
import okhttp3.Request;


public class STM_WiFiInfoMainActivity extends AdsBaseActivity {
    Activity activity;
    Context context;
    STM_ConnectivityReceiver connectivityReceiver;
    String stringK;
    String stringL;
    LinearLayout linIPInfo;
    LinearLayout linWiFiInfo;
    LinearLayout linWiFiStrength;
    LinearLayout linWifiList;
    String stringQ;
    AppCompatTextView txtExternalIP;
    AppCompatTextView txtGateway;
    AppCompatTextView txtLocalIp;
    WifiManager wifiManager;

    private boolean checkPermission() {
        return ContextCompat.checkSelfPermission(this.context, "android.permission.ACCESS_FINE_LOCATION") == 0 || ContextCompat.checkSelfPermission(this.context, "android.permission.ACCESS_COARSE_LOCATION") == 0;
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this.activity, new String[]{"android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"}, 1);
    }

    @Override 
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 1) {
            if (iArr.length <= 0 || iArr[0] != 0) {
                int i2 = iArr[1];
            }
        }
    }

    @Override 
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    @Override 
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            return true;
        } else if (itemId == R.id.rate) {
            if (isOnline()) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } else {
                Toast makeText = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText.setGravity(17, 0, 0);
                makeText.show();
            }
            return true;
        } else if (itemId == R.id.share) {
            if (isOnline()) {
                Intent intent2 = new Intent("android.intent.action.SEND");
                intent2.setType("text/plain");
                intent2.putExtra("android.intent.extra.TEXT", "Hi! I'm using a Who Use My Wi-Fi application. Check it out:http://play.google.com/store/apps/details?id=" + getPackageName());
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(Intent.createChooser(intent2, "Share with Friends"));
            } else {
                Toast makeText2 = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText2.setGravity(17, 0, 0);
                makeText2.show();
            }
            return true;
        } else {
            return super.onOptionsItemSelected(menuItem);
        }
    }

    public boolean isOnline() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    @Override 
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.stm_activity_wifi_info_main);
        this.context = this;
        this.activity = this;

        Toolbar toolbar = findViewById(R.id.tbToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_toolbar_back_black_dark);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(STM_WiFiInfoMainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });
        
        this.txtLocalIp = (AppCompatTextView) findViewById(R.id.tvLocalIp);
        this.txtGateway = (AppCompatTextView) findViewById(R.id.tvGateway);
        this.txtExternalIP = (AppCompatTextView) findViewById(R.id.tvExternalIP);
        this.linWiFiStrength = (LinearLayout) findViewById(R.id.llWiFiStrength);
        this.linWiFiInfo = (LinearLayout) findViewById(R.id.llWiFiInfo);
        this.linWifiList = (LinearLayout) findViewById(R.id.llWifiList);
        this.linIPInfo = (LinearLayout) findViewById(R.id.llIPInfo);
        registerReceiver(this.connectivityReceiver, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
        this.wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        try {
            StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().permitAll().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.linWiFiStrength.setOnClickListener(new View.OnClickListener() {
            @Override 
            public void onClick(View view) {
                getInstance(STM_WiFiInfoMainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(STM_WiFiInfoMainActivity.this, STM_WifiStrengthMainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        STM_WiFiInfoMainActivity.this.startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });
        this.linWiFiInfo.setOnClickListener(new View.OnClickListener() {
            @Override 
            public void onClick(View view) {
                getInstance(STM_WiFiInfoMainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(STM_WiFiInfoMainActivity.this, STM_WifiInformationMainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        STM_WiFiInfoMainActivity.this.startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });
        this.linWifiList.setOnClickListener(new View.OnClickListener() {
            @Override 
            public void onClick(View view) {
                getInstance(STM_WiFiInfoMainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(STM_WiFiInfoMainActivity.this, STM_WifiListActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        STM_WiFiInfoMainActivity.this.startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });
        this.linIPInfo.setOnClickListener(new View.OnClickListener() {
            @Override 
            public void onClick(View view) {
                getInstance(STM_WiFiInfoMainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(STM_WiFiInfoMainActivity.this, STM_IpInformation.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        STM_WiFiInfoMainActivity.this.startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });
    }

    @Override 
    public void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
        if (checkPermission()) {
            new getWifiDetailsTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
            checkConnection();
            return;
        }
        requestPermission();
    }

    
    public class getWifiDetailsTask extends AsyncTask<Void, Void, Void> {
        private getWifiDetailsTask() {
        }

        @Override 
        public void onPreExecute() {
            super.onPreExecute();
        }

        @Override 
        public Void doInBackground(Void... voidArr) {
            Elements elements;
            try {
                STM_WiFiInfoMainActivity.this.stringK = new OkHttpClient().newCall(new Request.Builder().url("https://api.ipify.org/").build()).execute().body().string().trim();
            } catch (Exception e) {
                STM_WiFiInfoMainActivity.this.stringK = "";
                e.printStackTrace();
            } catch (Throwable th) {
                try {
                    try {
                        th.printStackTrace();
                        return null;
                    } catch (Exception unused) {
                        elements = Jsoup.connect("http://checkip.amazonaws.com/").ignoreContentType(true).get().select("body");
                        STM_WiFiInfoMainActivity.this.stringK = elements.text().trim();
                        return null;
                    }
                } catch (IOException e2) {
                    e2.printStackTrace();
                    elements = null;
                    STM_WiFiInfoMainActivity.this.stringK = elements.text().trim();
                    return null;
                }
            }
            return null;
        }

        @Override 
        public void onPostExecute(Void r1) {
            try {
                STM_WiFiInfoMainActivity.this.loadWifiInfoData();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void checkConnection() {
        showSnack(STM_ConnectivityReceiver.isConnected());
    }

    private void showSnack(boolean z) {
        if (z) {
            new getWifiDetailsTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
            return;
        }
        Toast makeText = Toast.makeText(getApplicationContext(), "No Internet Connection", Toast.LENGTH_SHORT);
        makeText.setGravity(17, 0, 0);
        makeText.show();
    }

    public void loadWifiInfoData() {
        boolean z;
        try {
            this.stringL = Formatter.formatIpAddress(this.wifiManager.getConnectionInfo().getIpAddress());
            try {
                ConnectivityManager connectivityManager = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
                boolean z2 = false;
                if (connectivityManager != null) {
                    NetworkInfo networkInfo = connectivityManager.getNetworkInfo(0);
                    Objects.requireNonNull(networkInfo);
                    z = networkInfo.isConnectedOrConnecting();
                } else {
                    z = false;
                }
                if (connectivityManager != null) {
                    NetworkInfo networkInfo2 = connectivityManager.getNetworkInfo(1);
                    Objects.requireNonNull(networkInfo2);
                    z2 = networkInfo2.isConnectedOrConnecting();
                }
                System.out.println(z + " net " + z2);
                if (z) {
                    Object systemService = getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    Objects.requireNonNull(systemService);
                    ((WifiManager) systemService).getConnectionInfo().getRssi();
                    this.stringL = getIpAddress();
                    STM_AppUtils.isConnected(getApplicationContext());
                } else if (z2) {
                    this.stringQ = String.valueOf(Formatter.formatIpAddress(this.wifiManager.getDhcpInfo().gateway));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            this.txtLocalIp.setText("Local ip : " + this.stringL);
            this.txtExternalIP.setText("" + this.stringK);
            this.txtGateway.setText("" + this.stringQ);
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    public static String getIpAddress() {
        try {
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            if (!networkInterfaces.hasMoreElements()) {
                return null;
            }
            Enumeration<InetAddress> inetAddresses = networkInterfaces.nextElement().getInetAddresses();
            while (true) {
                if (inetAddresses.hasMoreElements()) {
                    InetAddress nextElement = inetAddresses.nextElement();
                    if (!nextElement.isLoopbackAddress() && (nextElement instanceof Inet4Address)) {
                        String hostAddress = nextElement.getHostAddress();
                        Log.e("IP address", "" + hostAddress);
                        Log.i("TAG", "getIpAddress: " + hostAddress);
                        return hostAddress;
                    }
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override 
    public void onDestroy() {
        super.onDestroy();
        try {
            if (this.connectivityReceiver != null) {
                LocalBroadcastManager.getInstance(this).unregisterReceiver(this.connectivityReceiver);
                this.connectivityReceiver = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
