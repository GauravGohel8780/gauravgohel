package com.speed.poster.STM_wifiRouterPassword;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.speed.poster.Ads_Common.AdsBaseActivity;
import com.speed.poster.Ads_Common.ExitActivity;
import com.speed.poster.R;
import com.speed.poster.STM_wifiInfo.STM_WiFiInfoMainActivity;

import java.util.ArrayList;


public class STM_Router_password extends AdsBaseActivity {
    private static ArrayList<STM_DataModel> data;
    STM_RouterPasswordAdapter routerPasswordAdapter;
    ArrayList<STM_DataModel> arrayList;
    EditText brandSearch;
    Context context;
    RecyclerView recyclerView;
    String str1 = "";
    String str2 = "";
    EditText typeSearch;
    private RecyclerView.LayoutManager layoutManager;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            return true;
        } else if (itemId == R.id.rate) {
            if (isOnline()) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } else {
                Toast makeText = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText.setGravity(17, 0, 0);
                makeText.show();
            }
            return true;
        } else if (itemId == R.id.share) {
            if (isOnline()) {
                Intent intent2 = new Intent("android.intent.action.SEND");
                intent2.setType("text/plain");
                intent2.putExtra("android.intent.extra.TEXT", "Hi! I'm using a Who Use My Wi-Fi application. Check it out:http://play.google.com/store/apps/details?id=" + getPackageName());
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(Intent.createChooser(intent2, "Share with Friends"));
            } else {
                Toast makeText2 = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText2.setGravity(17, 0, 0);
                makeText2.show();
            }
            return true;
        } else {
            return super.onOptionsItemSelected(menuItem);
        }
    }

    public boolean isOnline() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.stm_activity_router_password);
        Toolbar toolbar = findViewById(R.id.tbToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_toolbar_back_black_dark);
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.rvPassword);
        this.recyclerView = recyclerView;
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.context);
        this.layoutManager = linearLayoutManager;
        this.recyclerView.setLayoutManager(linearLayoutManager);
        this.recyclerView.setItemAnimator(new DefaultItemAnimator());
        data = new ArrayList<>();
        this.arrayList = new ArrayList<>();
        TypedArray obtainTypedArray = getResources().obtainTypedArray(R.array.routersData);
        int length = obtainTypedArray.length();
        String[][] strArr = new String[length][];

        for (int i = 0; i < length; i++) {
            int resourceId = obtainTypedArray.getResourceId(i, 0);
            if (resourceId > 0) {
                String[] stringArray = getResources().getStringArray(resourceId);
                strArr[i] = stringArray;
                String param3 = (!TextUtils.isEmpty(stringArray[2])) ? strArr[i][2].trim() : "";
                String param4 = (TextUtils.isEmpty(strArr[i][3])) ? "" : strArr[i][3].trim();
                STM_DataModel dataModel = new STM_DataModel(stringArray[0], stringArray[1], param3, param4);
                this.arrayList.add(dataModel);
            }
        }
        obtainTypedArray.recycle();
        STM_RouterPasswordAdapter routerPasswordAdapter = new STM_RouterPasswordAdapter(this.context, this.arrayList);
        this.routerPasswordAdapter = routerPasswordAdapter;
        this.recyclerView.setAdapter(routerPasswordAdapter);
        this.brandSearch = (EditText) findViewById(R.id.etBrandSearch);
        this.typeSearch = (EditText) findViewById(R.id.etTypeSearch);
        this.brandSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {
            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
                STM_Router_password.this.str1 = charSequence.toString().trim();
                STM_Router_password router_password = STM_Router_password.this;
                router_password.routerPasswordAdapter.filter(router_password.str1, router_password.str2);
            }
        });
        this.typeSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {
            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
                STM_Router_password.this.str2 = charSequence.toString().trim();
                STM_Router_password router_password = STM_Router_password.this;
                router_password.routerPasswordAdapter.filter(router_password.str1, router_password.str2);
            }
        });

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(STM_Router_password.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

    }


    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
