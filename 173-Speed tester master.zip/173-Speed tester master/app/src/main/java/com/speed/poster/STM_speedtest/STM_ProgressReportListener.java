package com.speed.poster.STM_speedtest;


public interface STM_ProgressReportListener {
    void reportCurrentDownloadProgress(long j);

    void reportCurrentDownloadSpeed(long j);

    void reportCurrentUploadPercentage(long j);

    void reportCurrentUploadSpeed(long j);
}
