package com.speed.poster.STM_speedtest.STM_spped_htmldialog;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.ProgressBar;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.speed.poster.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

@SuppressWarnings("all")
public class STM_spped_HtmlDialogFragment extends DialogFragment {
    private static final String KEY_CANCELABLE = "keyCancelable";
    private static final String KEY_HTML_RES_ID = "keyHtmlResId";
    private static final String KEY_NEGATIVE_BUTTON_TEXT = "keyNegativeButtonText";
    private static final String KEY_POSITIVE_BUTTON_TEXT = "keyPositiveButtonText";
    private static final String KEY_SHOW_NEGATIVE_BUTTON = "keyShowNegativeButton";
    private static final String KEY_SHOW_POSITIVE_BUTTON = "keyShowPositiveButton";
    private static final String KEY_TITLE = "keyTitle";
    private static final String TAG = "HtmlDialogFragment";
    public static final String TAG_HTML_DIALOG_FRAGMENT = "tagHtmlDialogFragment";
    private static STM_spped_HtmlDialogListener mListener;
    private boolean mCancelable;
    private AsyncTask<Void, Void, String> mHtmlLoader;
    private int mHtmlResId;
    private String mNegativeButtonText;
    private String mPositiveButtonText;
    private ProgressBar mProgressBar;
    private boolean mShowNegativeButton;
    private boolean mShowPositiveButton;
    private String mTitle;
    private WebView mWebView;

    public static STM_spped_HtmlDialogFragment newInstance(STM_spped_HtmlDialogListener spped_htmldialoglistener, int i, String str, boolean z, String str2, boolean z2, String str3, boolean z3) {
        mListener = spped_htmldialoglistener;
        STM_spped_HtmlDialogFragment spped_htmldialogfragment = new STM_spped_HtmlDialogFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(KEY_HTML_RES_ID, i);
        bundle.putString(KEY_TITLE, str);
        bundle.putBoolean(KEY_SHOW_NEGATIVE_BUTTON, z);
        bundle.putString(KEY_NEGATIVE_BUTTON_TEXT, str2);
        bundle.putBoolean(KEY_SHOW_POSITIVE_BUTTON, z2);
        bundle.putString(KEY_POSITIVE_BUTTON_TEXT, str3);
        bundle.putBoolean(KEY_CANCELABLE, z3);
        spped_htmldialogfragment.setArguments(bundle);
        return spped_htmldialogfragment;
    }

    @Override 
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        unpackBundle();
    }

    private void unpackBundle() {
        Bundle arguments = getArguments();
        this.mHtmlResId = arguments.getInt(KEY_HTML_RES_ID);
        this.mTitle = arguments.getString(KEY_TITLE);
        this.mShowNegativeButton = arguments.getBoolean(KEY_SHOW_NEGATIVE_BUTTON);
        this.mNegativeButtonText = arguments.getString(KEY_NEGATIVE_BUTTON_TEXT);
        this.mShowPositiveButton = arguments.getBoolean(KEY_SHOW_POSITIVE_BUTTON);
        this.mPositiveButtonText = arguments.getString(KEY_POSITIVE_BUTTON_TEXT);
        this.mCancelable = arguments.getBoolean(KEY_CANCELABLE);
    }

    @Override 
    public void onDestroy() {
        super.onDestroy();
        AsyncTask<Void, Void, String> asyncTask = this.mHtmlLoader;
        if (asyncTask != null) {
            asyncTask.cancel(true);
        }
    }

    @Override 
    public Dialog onCreateDialog(Bundle bundle) {
        String str;
        String str2;
        setCancelable(this.mCancelable);
        View inflate = LayoutInflater.from(getActivity()).inflate(R.layout.stm_html_fragment, (ViewGroup) null);
        this.mWebView = (WebView) inflate.findViewById(R.id.webView);
        this.mProgressBar = (ProgressBar) inflate.findViewById(R.id.progressBar);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        String str3 = this.mTitle;
        if (str3 != null) {
            builder.setTitle(str3);
        }
        builder.setView(inflate);
        if (this.mShowNegativeButton && (str2 = this.mNegativeButtonText) != null) {
            builder.setNegativeButton(str2, new DialogInterface.OnClickListener() { 
                @Override 
                public void onClick(DialogInterface dialogInterface, int i) {
                    if (STM_spped_HtmlDialogFragment.mListener != null) {
                        STM_spped_HtmlDialogFragment.mListener.onNegativeButtonPressed();
                    }
                    dialogInterface.dismiss();
                }
            });
        }
        if (this.mShowPositiveButton && (str = this.mPositiveButtonText) != null) {
            builder.setPositiveButton(str, new DialogInterface.OnClickListener() { 
                @Override 
                public void onClick(DialogInterface dialogInterface, int i) {
                    if (STM_spped_HtmlDialogFragment.mListener != null) {
                        STM_spped_HtmlDialogFragment.mListener.onPositiveButtonPressed();
                    }
                    dialogInterface.dismiss();
                }
            });
        }
        return builder.create();
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        loadHtml();
    }

    private void loadHtml() {
        this.mHtmlLoader = new AsyncTask<Void, Void, String>() {
            @Override
            public String doInBackground(Void... voidArr) {
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(STM_spped_HtmlDialogFragment.this.getActivity().getResources().openRawResource(STM_spped_HtmlDialogFragment.this.mHtmlResId)));
                StringBuilder sb = new StringBuilder();
                while (true) {
                    try {
                        String readLine = bufferedReader.readLine();
                        if (readLine == null) {
                            break;
                        }
                        sb.append(readLine).append("\n");
                    } catch (IOException unused) {
                        Log.d(STM_spped_HtmlDialogFragment.TAG, "IOException caught in loadHtml()");
                    }
                }
                try {
                    bufferedReader.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                return sb.toString();
            }


            @Override
            public void onPostExecute(String str) {
                if (STM_spped_HtmlDialogFragment.this.getActivity() == null || isCancelled()) {
                    return;
                }
                STM_spped_HtmlDialogFragment.this.mProgressBar.setVisibility(View.INVISIBLE);
                STM_spped_HtmlDialogFragment.this.mWebView.setVisibility(View.VISIBLE);
                STM_spped_HtmlDialogFragment.this.mWebView.loadDataWithBaseURL(null, str, "text/html", "utf-8", null);
                STM_spped_HtmlDialogFragment.this.mHtmlLoader = null;
            }
        }.execute(new Void[0]);
    }

    @Override
    public void onCancel(DialogInterface dialogInterface) {
        super.onCancel(dialogInterface);
        STM_spped_HtmlDialogListener spped_htmldialoglistener = mListener;
        if (spped_htmldialoglistener != null) {
            spped_htmldialoglistener.onDialogCancel();
        }
    }
}
