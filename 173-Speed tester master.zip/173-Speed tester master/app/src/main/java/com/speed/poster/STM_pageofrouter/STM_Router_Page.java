package com.speed.poster.STM_pageofrouter;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.text.format.Formatter;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.HttpAuthHandler;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;


import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.speed.poster.Ads_Common.AdsBaseActivity;
import com.speed.poster.Ads_Common.ExitActivity;
import com.speed.poster.STM_AppUtils;
import com.speed.poster.R;
import com.speed.poster.STM_wifiInfo.STM_WiFiInfoMainActivity;

import java.util.Objects;


public class STM_Router_Page extends AdsBaseActivity {
    String str1;
    WebView webView;
    private STM_AppUtils wifi;

    public class MyCustomizedWebClient extends WebViewClient {
        @Override
        public void onReceivedHttpAuthRequest(WebView webView, HttpAuthHandler httpAuthHandler, String str, String str2) {
        }

        private MyCustomizedWebClient(STM_Router_Page router_Page) {
        }

        @Override
        public void onPageFinished(WebView webView, String str) {
            super.onPageFinished(webView, str);
        }
    }


    public class backInWB implements View.OnKeyListener {
        backInWB(STM_Router_Page router_Page) {
        }

        @Override
        public boolean onKey(View view, int i, KeyEvent keyEvent) {
            if (keyEvent.getAction() != 0) {
                return false;
            }
            WebView webView = (WebView) view;
            if (i == 4 && webView.canGoBack()) {
                webView.goBack();
                return true;
            }
            return false;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            return true;
        } else if (itemId == R.id.rate) {
            if (isOnline()) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } else {
                Toast makeText = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText.setGravity(17, 0, 0);
                makeText.show();
            }
            return true;
        } else if (itemId == R.id.share) {
            if (isOnline()) {
                Intent intent2 = new Intent("android.intent.action.SEND");
                intent2.setType("text/plain");
                intent2.putExtra("android.intent.extra.TEXT", "Hi! I'm using a Who Use My Wi-Fi application. Check it out:http://play.google.com/store/apps/details?id=" + getPackageName());
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(Intent.createChooser(intent2, "Share with Friends"));
            } else {
                Toast makeText2 = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText2.setGravity(17, 0, 0);
                makeText2.show();
            }
            return true;
        } else {
            return super.onOptionsItemSelected(menuItem);
        }
    }

    public boolean isOnline() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    @Override
    public void onCreate(Bundle bundle) {
        try {
            super.onCreate(bundle);
            setContentView(R.layout.stm_activity_router_page_new);
            Toolbar toolbar = findViewById(R.id.tbToolbar);
            setSupportActionBar(toolbar);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_toolbar_back_black_dark);
            this.wifi = new STM_AppUtils(getApplicationContext());
            this.webView = (WebView) findViewById(R.id.webview);
            loadUrl();

            toolbar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    getInstance(STM_Router_Page.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            getOnBackPressedDispatcher().onBackPressed();
                        }
                    }, BACK_CLICK);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadUrl() {
        try {
            if (!this.wifi.isConnectedWifi()) {
                Toast makeText = Toast.makeText(getApplicationContext(), getResources().getString(R.string.stm_notConnectedWifi), Toast.LENGTH_SHORT);
                makeText.setGravity(17, 0, 0);
                makeText.show();
            } else if (this.wifi.isEnabled()) {
                try {
                    Object systemService = getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    Objects.requireNonNull(systemService);
                    this.str1 = String.valueOf(Formatter.formatIpAddress(((WifiManager) systemService).getDhcpInfo().gateway));
                    WebSettings settings = this.webView.getSettings();
                    settings.setJavaScriptEnabled(true);
                    settings.setLoadWithOverviewMode(true);
                    settings.setUseWideViewPort(true);
                    settings.setBuiltInZoomControls(true);
                    settings.setDisplayZoomControls(false);
                    settings.setJavaScriptCanOpenWindowsAutomatically(true);
                    this.webView.setOnKeyListener(new backInWB(this));
                    this.webView.setWebViewClient(new MyCustomizedWebClient(this));
                    this.webView.loadUrl("http://" + this.str1);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                Toast makeText2 = Toast.makeText(getApplicationContext(), getResources().getString(R.string.stm_wifiDisabled), Toast.LENGTH_SHORT);
                makeText2.setGravity(17, 0, 0);
                makeText2.show();
            }
        } catch (Resources.NotFoundException e2) {
            e2.printStackTrace();
        }
    }


    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
