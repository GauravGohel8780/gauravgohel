package com.speed.poster.STM_whousewifi;

import java.math.BigInteger;
import java.net.InetAddress;
import java.net.UnknownHostException;


public class STM_Utils {
    public static String parseIpAddress(long j) {
        try {
            byte[] byteArray = BigInteger.valueOf(j).toByteArray();
            reverse(byteArray);
            return InetAddress.getByAddress(byteArray).getHostAddress();
        } catch (UnknownHostException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void reverse(byte[] bArr) {
        if (bArr != null) {
            reverse(bArr, 0, bArr.length);
        }
    }

    public static void reverse(byte[] bArr, int i, int i2) {
        if (bArr != null) {
            int min = Math.min(bArr.length, i2) - 1;
            for (int max = Math.max(i, 0); min > max; max++) {
                byte b = bArr[min];
                bArr[min] = bArr[max];
                bArr[max] = b;
                min--;
            }
        }
    }
}
