package com.speed.poster.Ads_Common;

import static com.iten.tenoku.ad.AdShow.getInstance;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.iten.tenoku.utils.AdUtils;
import com.speed.poster.R;
import com.speed.poster.databinding.StmLayoutExitBinding;

public class ExitActivity extends AdsBaseActivity {

    StmLayoutExitBinding binding;
    Activity activity;
    Boolean aBoolean;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = StmLayoutExitBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        activity = this;
        todo();
    }


    private void todo() {
        aBoolean = getIntent().getBooleanExtra("Under", false);
        binding.cvNo.setOnClickListener(view -> {
            if (Boolean.TRUE.equals(aBoolean)) {
                startActivity(new Intent(activity, UnderMaintenanceActivity.class));
            } else {
                super.onBackPressed();
            }
        });

        binding.cvYes.setOnClickListener(view -> {
            finishAffinity();
            System.exit(0);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}