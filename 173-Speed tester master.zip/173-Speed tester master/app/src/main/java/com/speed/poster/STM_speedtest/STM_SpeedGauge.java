package com.speed.poster.STM_speedtest;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

import androidx.recyclerview.widget.ItemTouchHelper;

import com.speed.poster.R;

public class STM_SpeedGauge extends View {
    private static final float RADSxTICK = 0.06283186f;
    double a;
    double b;
    private Paint indicatorpaint;
    private Paint tickspaint;

    public float carib(double d) {
        float f;
        float f2;
        if (d <= 5.0d) {
            f = (float) d;
            f2 = 5.0f;
        } else if (d <= 10.0d) {
            f = (float) d;
            f2 = 3.0f;
        } else if (d <= 12.0d) {
            f = (float) d;
            f2 = 2.5833333f;
        } else if (d < 14.0d) {
            f = (float) d;
            f2 = 2.2857144f;
        } else if (d < 16.0d) {
            f = (float) d;
            f2 = 2.0625f;
        } else if (d < 18.0d) {
            f = (float) d;
            f2 = 1.8888888f;
        } else if (d < 20.0d) {
            f = (float) d;
            f2 = 1.75f;
        } else if (d <= 22.0d) {
            f = (float) d;
            f2 = 1.6363636f;
        } else if (d < 24.0d) {
            f = (float) d;
            f2 = 1.5416666f;
        } else if (d < 26.0d) {
            f = (float) d;
            f2 = 1.4615384f;
        } else if (d < 28.0d) {
            f = (float) d;
            f2 = 1.3928572f;
        } else if (d < 30.0d) {
            f = (float) d;
            f2 = 1.3333334f;
        } else if (d <= 32.0d) {
            f = (float) d;
            f2 = 1.28125f;
        } else if (d < 34.0d) {
            f = (float) d;
            f2 = 1.2352941f;
        } else if (d < 36.0d) {
            f = (float) d;
            f2 = 1.1944444f;
        } else if (d < 38.0d) {
            f = (float) d;
            f2 = 1.1578947f;
        } else if (d < 40.0d) {
            f = (float) d;
            f2 = 1.125f;
        } else if (d <= 42.0d) {
            f = (float) d;
            f2 = 1.0952381f;
        } else if (d < 44.0d) {
            f = (float) d;
            f2 = 1.0681819f;
        } else if (d < 46.0d) {
            f = (float) d;
            f2 = 1.0434783f;
        } else if (d < 48.0d) {
            f = (float) d;
            f2 = 1.0208334f;
        } else if (d >= 50.0d) {
            return 0.0f;
        } else {
            f = (float) d;
            f2 = 1.0f;
        }
        return f * f2;
    }

    public void setEndValue(double d) {
        this.b = d;
        invalidate();
    }

    public void setValue(double d) {
        this.a = d;
        invalidate();
    }

    private void init() {
        Paint paint = new Paint(1);
        this.tickspaint = paint;
        paint.setColor(getResources().getColor(R.color.stm_color_lighblack));
        this.tickspaint.setStrokeWidth(10.0f);
        this.tickspaint.setTextSize(getResources().getDimensionPixelSize(R.dimen.textsize));
        Paint paint2 = new Paint(1);
        this.indicatorpaint = paint2;
        paint2.setColor(getResources().getColor(R.color.stm_color_TickColor));
        this.indicatorpaint.setStrokeWidth(8.0f);
        this.indicatorpaint.setStyle(Paint.Style.FILL);
    }

    public STM_SpeedGauge(Context context) {
        super(context);
        this.a = 0.0d;
        this.b = 50.0d;
        init();
    }

    public STM_SpeedGauge(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a = 0.0d;
        this.b = 50.0d;
        init();
    }

    public STM_SpeedGauge(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.a = 0.0d;
        this.b = 50.0d;
        init();
    }

    @Override 
    public void onMeasure(int i, int i2) {
        int i3;
        int mode = MeasureSpec.getMode(i);
        int size = MeasureSpec.getSize(i);
        MeasureSpec.getMode(i2);
        MeasureSpec.getSize(i2);
        if (mode == 1073741824) {
            i3 = size / 2;
        } else if (mode == Integer.MIN_VALUE) {
            i3 = size / 2;
        } else {
            setMeasuredDimension(500, ItemTouchHelper.Callback.DEFAULT_SWIPE_ANIMATION_DURATION);
            i3 = 0;
            size = 500;
        }
        setMeasuredDimension(size, i3 + 50);
    }

    @Override 
    public void draw(Canvas canvas) {
        int i;
        int i2;
        int i3;
        char c;
        int i4;
        char c2;
        super.draw(canvas);
        float width = getWidth() / 2;
        float f = width - 10.0f;
        float f2 = width - 20.0f;
        float f3 = width - 50.0f;
        float width2 = getWidth() / 2;
        float height = getHeight() - 20.0f;
        char c3 = 5;
        int i5 = 50;
        char c4 = 0;
        int i6 = 0;
        int i7 = 50;
        int i8 = 5;
        while (i6 <= i5) {
            float f4 = f2;
            double d = i6 * RADSxTICK;
            float f5 = f;
            float cos = (float) Math.cos(d);
            float sin = (float) Math.sin(d);
            if (c4 == c3 || c4 == 0) {
                i = i8;
                i2 = i7;
                i3 = i6;
                c = c3;
                i4 = 50;
            } else {
                i = i8;
                i2 = i7;
                i4 = 50;
                c = c3;
                canvas.drawLine((cos * f5) + width2, height - (sin * f5), (cos * width) + width2, height - (sin * width), this.tickspaint);
                i3 = i6 + 1;
            }
            canvas.drawLine((cos * f4) + width2, height - (sin * f4), (cos * width) + width2, height - (sin * width), this.tickspaint);
            if (i2 >= 10) {
                canvas.drawText("" + i2, ((cos * f3) + width2) - ((50 - i3) * 0.4f), (height - (sin * f3)) + 10.0f, this.tickspaint);
                i2 -= 10;
                i8 = i;
                c2 = 0;
            } else {
                int i9 = i;
                c2 = 0;
                canvas.drawText("" + i9, ((cos * f3) + width2) - ((50 - i3) * 0.4f), (height - (sin * f3)) + 10.0f, this.tickspaint);
                i8 = i9 - 1;
            }
            i6 = i3 + 1;
            c4 = 1;
            i7 = i2;
            i5 = i4;
            f2 = f4;
            f = f5;
            c3 = c;
        }
        float f6 = f2;
        double carib = 3.141592653589793d - (((float) (carib(this.a) / this.b)) * 3.141592653589793d);
        float cos2 = (float) Math.cos(carib);
        float sin2 = (float) Math.sin(carib);
        canvas.drawLine(width2 - 20.0f, height, width2 + (cos2 * f3), height - (sin2 * f3), this.indicatorpaint);
        double d2 = carib + 0.05235987755982988d;
        double d3 = carib - 0.05235987755982988d;
        Path path = new Path();
        path.reset();
        float cos3 = (((float) Math.cos(d2)) * f3) + width2;
        float sin3 = height - (((float) Math.sin(d2)) * f3);
        path.moveTo(cos3, sin3);
        path.lineTo((((float) Math.cos(d3)) * f3) + width2, height - (((float) Math.sin(d3)) * f3));
        path.lineTo((cos2 * f6) + width2, height - (sin2 * f6));
        path.lineTo(cos3, sin3);
        canvas.drawPath(path, this.indicatorpaint);
    }
}
