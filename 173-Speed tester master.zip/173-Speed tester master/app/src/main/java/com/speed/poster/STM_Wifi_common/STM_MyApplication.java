package com.speed.poster.STM_Wifi_common;


public class STM_MyApplication extends com.iten.tenoku.utils.MyApplication {
    private static STM_MyApplication mInstance;

    public static synchronized STM_MyApplication getInstance() {
        STM_MyApplication myApplication;
        synchronized (STM_MyApplication.class) {
            myApplication = mInstance;
        }
        return myApplication;
    }

    @Override 
    public void onCreate() {
        super.onCreate();
        mInstance = this;
    }
}
