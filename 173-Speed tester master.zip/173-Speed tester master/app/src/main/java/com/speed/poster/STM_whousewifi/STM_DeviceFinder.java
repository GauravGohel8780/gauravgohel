package com.speed.poster.STM_whousewifi;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import com.speed.poster.STM_whousewifi.STM_interfaces.STM_OnDeviceFoundListener;
import com.speed.poster.STM_whousewifi.STM_macinfo.STM_MacAddressInfo;
import com.speed.poster.STM_whousewifi.STM_models.STM_DeviceItem;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;


public class STM_DeviceFinder {
    private final Context context;
    private ExecutorService executorService;
    private final STM_OnDeviceFoundListener onDeviceFoundListener;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean isRunning = false;
    private final List<STM_DeviceItem> reachableDevices = new ArrayList();
    private boolean stopRequested = false;
    private int timeout = 1500;

    public STM_DeviceFinder(Context context, STM_OnDeviceFoundListener onDeviceFoundListener) {
        this.context = context;
        this.onDeviceFoundListener = onDeviceFoundListener;
    }

    public STM_DeviceFinder setTimeout(int i) {
        this.timeout = i;
        return this;
    }

    public void start() {
        this.isRunning = true;
        this.stopRequested = false;
        this.reachableDevices.clear();
        new Thread(new Runnable() { 
            @Override 
            public void run() {
                STM_DeviceFinder.this.startPing();
            }
        }).start();
    }

    private void sendStartEvent() {
        this.handler.post(new Runnable() { 
            @Override 
            public void run() {
                onDeviceFoundListener.onStart(STM_DeviceFinder.this);
            }
        });
    }

    private void sendFailedEvent(final int i) {
        this.handler.post(new Runnable() { 
            @Override 
            public void run() {
                onDeviceFoundListener.onFailed(STM_DeviceFinder.this, i);
            }
        });
    }

    private void sendFinishedEvent(final List<STM_DeviceItem> list) {
        this.handler.post(new Runnable() { 
            @Override 
            public void run() {
                onDeviceFoundListener.onFinished(STM_DeviceFinder.this, list);
            }
        });
    }


    private static boolean isBelowAndroidR() {
        return Build.VERSION.SDK_INT < 30;
    }

    public void startPing() {
        if (!STM_NetworkInfo.isWifiConnected(this.context)) {
            this.isRunning = false;
            sendFailedEvent(2);
            return;
        }
        this.executorService = Executors.newFixedThreadPool(255);
        sendStartEvent();
        String gatewayAddress = STM_NetworkInfo.getGatewayAddress(this.context);
        String substring = gatewayAddress.substring(0, gatewayAddress.lastIndexOf(".") + 1);
        int i = 0;
        while (i < 255) {
            try {
                StringBuilder sb = new StringBuilder();
                sb.append(substring);
                i++;
                sb.append(i);
                this.executorService.execute(new Ping(sb.toString()));
            } catch (Exception e) {
                e.printStackTrace();
                if (this.stopRequested) {
                    sendFailedEvent(0);
                    return;
                } else {
                    sendFailedEvent(3);
                    return;
                }
            }
        }
        this.executorService.shutdown();
        try {
            if (this.executorService.awaitTermination(10L, TimeUnit.MINUTES)) {
                if (isBelowAndroidR()) {
                    STM_MacAddressInfo.setMacAddress(this.context, this.reachableDevices);
                }
                sendFinishedEvent(this.reachableDevices);
            } else {
                sendFailedEvent(3);
            }
        } catch (InterruptedException e2) {
            if (this.stopRequested) {
                sendFailedEvent(0);
            } else {
                sendFailedEvent(3);
            }
            e2.printStackTrace();
        }
        this.isRunning = false;
    }

    
    public class Ping implements Runnable {
        private final String ipAddress;

        public Ping(String str) {
            this.ipAddress = str;
        }

        @Override 
        public void run() {
            try {
                InetAddress byName = InetAddress.getByName(this.ipAddress);
                if (Thread.currentThread().isInterrupted() || !byName.isReachable(STM_DeviceFinder.this.timeout)) {
                    return;
                }
                STM_DeviceItem deviceItem = new STM_DeviceItem();
                deviceItem.setIpAddress(this.ipAddress);
                deviceItem.setDeviceName(byName.getHostName());
                STM_DeviceFinder.this.reachableDevices.add(deviceItem);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
