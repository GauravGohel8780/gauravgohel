package com.speed.poster.STM_whousewifi.STM_vendor;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class STM_VendorInfo {
    public static final String UNKNOWN = "UnKnown";
    private static String json = "[]";
    private static JSONArray jsonArray;

    private static void readVendorFile(Context context) {
        if (jsonArray != null) {
            return;
        }
        try {
            InputStream open = context.getAssets().open("vendors.json");
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(open));
            StringBuilder sb = new StringBuilder();
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine != null) {
                    sb.append(readLine);
                } else {
                    json = sb.toString();
                    bufferedReader.close();
                    open.close();
                    return;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static JSONArray getJsonArray(Context context) {
        if (jsonArray == null) {
            readVendorFile(context);
            try {
                jsonArray = new JSONArray(json);
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }
        return jsonArray;
    }

    public static String getVendorName(Context context, String str) {
        try {
            JSONArray jsonArray2 = getJsonArray(context);
            for (int i = 0; i < jsonArray2.length(); i++) {
                JSONObject jSONObject = jsonArray2.getJSONObject(i);
                String string = jSONObject.getString("m");
                String string2 = jSONObject.getString("n");
                if (str.toLowerCase().startsWith(string.toLowerCase())) {
                    return string2;
                }
            }
            return "UnKnown";
        } catch (JSONException e) {
            e.printStackTrace();
            return "UnKnown";
        }
    }
}
