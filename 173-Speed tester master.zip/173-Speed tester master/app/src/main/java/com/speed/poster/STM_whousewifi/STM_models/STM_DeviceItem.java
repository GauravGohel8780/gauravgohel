package com.speed.poster.STM_whousewifi.STM_models;


public class STM_DeviceItem {
    private String deviceName = "UnKnown";
    private String ipAddress = "UnKnown";
    private String macAddress = "UnKnown";
    private String vendorName = "UnKnown";

    public String getIpAddress() {
        return this.ipAddress;
    }

    public void setIpAddress(String str) {
        this.ipAddress = str;
    }

    public String getMacAddress() {
        return this.macAddress;
    }

    public void setMacAddress(String str) {
        this.macAddress = str;
    }

    public String getDeviceName() {
        return this.deviceName;
    }

    public void setDeviceName(String str) {
        this.deviceName = str;
    }

    public String getVendorName() {
        return this.vendorName;
    }

    public void setVendorName(String str) {
        this.vendorName = str;
    }

    public boolean isIpAddressAndDeviceNameSame() {
        return this.ipAddress.equals(this.deviceName);
    }
}
