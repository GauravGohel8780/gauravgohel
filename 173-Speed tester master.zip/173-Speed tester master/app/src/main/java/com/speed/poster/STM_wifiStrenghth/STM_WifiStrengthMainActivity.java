package com.speed.poster.STM_wifiStrenghth;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.speed.poster.Ads_Common.AdsBaseActivity;
import com.speed.poster.Ads_Common.ExitActivity;
import com.speed.poster.R;
import com.speed.poster.STM_MainActivity;
import com.speed.poster.STM_wifiInfo.STM_WiFiInfoMainActivity;

import java.util.Objects;

import at.grabner.circleprogress.CircleProgressView;


public class STM_WifiStrengthMainActivity extends AdsBaseActivity {
    public CountDownTimer countDownTimer;
    public CountDownTimer countDownTimerUbicacion;
    boolean aBoolean;
    Context context;
    CircleProgressView circleProgressView;
    TextView textView;
    public int tiempoMilisegundos = 1000;
    private WifiInfo wifiInfo;
    private WifiManager wifiManager;

    public int calculateSignalLevel(int i, int i2) {
        if (i <= -100) {
            return 0;
        }
        return i >= -50 ? i2 - 1 : (int) (((i + 100) * (i2 - 1)) / 50.0f);
    }

    @Override 
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override 
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            return true;
        } else if (itemId == R.id.rate) {
            if (isOnline()) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } else {
                Toast makeText = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText.setGravity(17, 0, 0);
                makeText.show();
            }
            return true;
        } else if (itemId == R.id.share) {
            if (isOnline()) {
                Intent intent2 = new Intent("android.intent.action.SEND");
                intent2.setType("text/plain");
                intent2.putExtra("android.intent.extra.TEXT", "Hi! I'm using a Who Use My Wi-Fi application. Check it out:http://play.google.com/store/apps/details?id=" + getPackageName());
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(Intent.createChooser(intent2, "Share with Friends"));
            } else {
                Toast makeText2 = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText2.setGravity(17, 0, 0);
                makeText2.show();
            }
            return true;
        } else {
            return super.onOptionsItemSelected(menuItem);
        }
    }

    public boolean isOnline() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    @Override 
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.stm_wifi_strenght_activity);
        this.context = this;
        Toolbar toolbar = findViewById(R.id.tbToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_toolbar_back_black_dark);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(STM_WifiStrengthMainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

        this.circleProgressView = (CircleProgressView) findViewById(R.id.pbWiFiStrength);
        this.textView = (TextView) findViewById(R.id.tvPercent);
        CheckGpsStatus();
        if (this.aBoolean) {
            actualizarIntensidadWifi(this.tiempoMilisegundos);
        } else {
            new AlertDialog.Builder(this).setMessage("This Permission Is Require To Get Network Name status & Some Other Info.").setPositiveButton("OK", new DialogInterface.OnClickListener() { 
                @Override 
                public void onClick(DialogInterface dialogInterface, int i) {
                    STM_WifiStrengthMainActivity.this.solicitarPermisos();
                    STM_WifiStrengthMainActivity.this.enableGPS();
                }
            }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() { 
                @Override 
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.cancel();
                }
            }).show();
        }
        this.wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
    }


    public void actualizarIntensidadWifi(int i) {
        this.countDownTimer = new CountDownTimer(60000L, i) { 
            @Override 
            public void onTick(long j) {
                STM_WifiStrengthMainActivity.this.procesoActualizarIntensidadWifi();
            }

            @Override 
            public void onFinish() {
                STM_WifiStrengthMainActivity.this.procesoActualizarIntensidadWifi();
                STM_WifiStrengthMainActivity.this.countDownTimer.start();
            }
        }.start();
    }

    public void CheckGpsStatus() {
        LocationManager locationManager = (LocationManager) this.context.getSystemService(Context.LOCATION_SERVICE);
        if (locationManager != null) {
            this.aBoolean = locationManager.isProviderEnabled("gps");
        }
    }

    public void procesoActualizarIntensidadWifi() {
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        this.wifiManager = wifiManager;
        if (wifiManager != null) {
            this.wifiInfo = wifiManager.getConnectionInfo();
        }
        int calculateSignalLevel = calculateSignalLevel(this.wifiInfo.getRssi(), 101);
        this.circleProgressView.setValue(calculateSignalLevel);
        this.textView.setText("" + calculateSignalLevel + " %");
    }

    @Override 
    public void onDestroy() {
        super.onDestroy();
        CountDownTimer countDownTimer = this.countDownTimer;
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        CountDownTimer countDownTimer2 = this.countDownTimerUbicacion;
        if (countDownTimer2 != null) {
            countDownTimer2.cancel();
        }
    }

    public void solicitarPermisos() {
        ActivityCompat.requestPermissions(this, new String[]{"android.permission.ACCESS_COARSE_LOCATION"}, 1);
        ActivityCompat.requestPermissions(this, new String[]{"android.permission.ACCESS_FINE_LOCATION"}, 1);
    }

    @Override 
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i != 1) {
            return;
        }
        if (iArr.length <= 0 || iArr[0] != 0) {
            actualizarIntensidadWifi(this.tiempoMilisegundos);
        } else if (!wifiActivado()) {
            enableGPS();
        } else if (!conectadoWifi()) {
            Toast makeText = Toast.makeText(getApplicationContext(), "You are not connected WiFi network", Toast.LENGTH_SHORT);
            makeText.setGravity(17, 0, 0);
            makeText.show();
        } else if (GPSActivado()) {
            actualizarIntensidadWifi(this.tiempoMilisegundos);
        } else {
            enableGPS();
            actualizarIntensidadWifi(this.tiempoMilisegundos);
        }
    }

    private boolean wifiActivado() {
        Object systemService = getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        Objects.requireNonNull(systemService);
        return ((WifiManager) systemService).isWifiEnabled();
    }

    public boolean GPSActivado() {
        Object systemService = getSystemService(Context.LOCATION_SERVICE);
        Objects.requireNonNull(systemService);
        return ((LocationManager) systemService).isProviderEnabled("gps");
    }

    public boolean conectadoWifi() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (Build.VERSION.SDK_INT >= 29) {
            NetworkCapabilities networkCapabilities = connectivityManager != null ? connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork()) : null;
            return networkCapabilities != null && networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
        } else if (connectivityManager == null) {
            return false;
        } else {
            NetworkInfo networkInfo = connectivityManager.getNetworkInfo(1);
            Objects.requireNonNull(networkInfo);
            return networkInfo.isConnected();
        }
    }

    public void enableGPS() {
        try {
            startActivity(new Intent("android.settings.LOCATION_SOURCE_SETTINGS"));
        } catch (ActivityNotFoundException unused) {
            Toast makeText = Toast.makeText(getApplicationContext(), "Unable to open GPS configuration", Toast.LENGTH_SHORT);
            makeText.setGravity(17, 0, 0);
            makeText.show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
