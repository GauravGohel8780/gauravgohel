package com.speed.poster.STM_speedtest;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;


public class STM_SpeedTestMini {
    private final String host;
    private final int port;
    private STM_ProgressReportListener report = null;
    Socket socket;

    
    static class C05601 implements STM_ProgressReportListener {
        @Override 
        public void reportCurrentDownloadProgress(long j) {
        }

        @Override 
        public void reportCurrentDownloadSpeed(long j) {
        }

        @Override 
        public void reportCurrentUploadPercentage(long j) {
        }

        @Override 
        public void reportCurrentUploadSpeed(long j) {
        }

        C05601() {
        }
    }

    public static void main(String[] strArr) {
        STM_SpeedTestMini speedTestMini = new STM_SpeedTestMini("192.168.3.125", 80);
        speedTestMini.setProgressReportListener(new C05601());
        System.out.println(speedTestMini.doDownloadtest());
    }

    public STM_SpeedTestMini(String str, int i) {
        this.host = str;
        this.port = i;
    }

    public void setProgressReportListener(STM_ProgressReportListener progressReportListener) {
        this.report = progressReportListener;
    }


    public long doDownloadtest() {
        try {
            this.socket = new Socket(this.host, this.port);
            try {
                PrintWriter printWriter = new PrintWriter(this.socket.getOutputStream());
                printWriter.println("GET /speedtest/random2000x2000.jpg HTTP/1.1");
                printWriter.println("Host: " + this.host);
                printWriter.println("Cache-Control: max-age=0");
                printWriter.println("Connection: close");
                printWriter.println("");
                printWriter.flush();
                try {
                    this.socket.getInputStream().read();
                    long currentTimeMillis = System.currentTimeMillis();
                    byte[] bArr = new byte[1048576];
                    long j = 1;
                    while (true) {
                        long j2 = 0;
                        do {
                            try {
                                long read = this.socket.getInputStream().read(bArr);
                                if (read == -1) {
                                    long currentTimeMillis2 = (long) ((j * 8) / ((System.currentTimeMillis() - currentTimeMillis) / 1000.0d));
                                    try {
                                        this.socket.close();
                                        return currentTimeMillis2;
                                    } catch (IOException e) {
                                        throw new RuntimeException(e);
                                    }
                                }
                                j2 += read;
                                j += read;
                            } catch (IOException e2) {
                                throw new RuntimeException(e2);
                            }
                        } while (j2 < 32768);
                        this.report.reportCurrentDownloadProgress((100 * j) / 7907740);
                        System.currentTimeMillis();
                    }
                } catch (IOException e3) {
                    throw new RuntimeException(e3);
                }
            } catch (IOException e4) {
                throw new RuntimeException(e4);
            }
        } catch (IOException e5) {
            throw new RuntimeException(e5);
        }
    }
}
