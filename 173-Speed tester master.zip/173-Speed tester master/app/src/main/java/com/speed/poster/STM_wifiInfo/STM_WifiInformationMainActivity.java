package com.speed.poster.STM_wifiInfo;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.DhcpInfo;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;


import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.speed.poster.Ads_Common.AdsBaseActivity;
import com.speed.poster.R;
import com.speed.poster.STM_wifiStrenghth.STM_WifiStrengthMainActivity;

import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Objects;


public class STM_WifiInformationMainActivity extends AdsBaseActivity {
    public CountDownTimer countDownTimer;
    public CountDownTimer countDownTimerUbicacion;
    private DhcpInfo dhcpInfo;
    boolean aBoolean;
    Context context;
    TextView txtNetworkBSSID;
    TextView txtNetworkChannel;
    TextView txtNetworkDNS;
    TextView txtNetworkFrequency;
    TextView txtNetworkGateway;
    TextView txtNetworkIPAddress;
    TextView txtNetworkMacAddress;
    TextView txtNetworkName;
    TextView txtNetworkRSSI;
    TextView txtNetworkSignalStrength;
    TextView txtNetworkSpeed;
    TextView txtNetworkSubnetMask;
    private int intensidadSignal;
    private int nivelRssi;
    public int tiempoMilisegundos = 1000;
    private WifiInfo wifiInfo;
    private WifiManager wifiManager;

    public int calculateSignalLevel(int i, int i2) {
        if (i <= -100) {
            return 0;
        }
        return i >= -50 ? i2 - 1 : (int) (((i + 100) * (i2 - 1)) / 50.0f);
    }

    public String obtenerIntensidadSignal(int i) {
        return i == 0 ? "Without signal" : i == 1 ? "Low coverage" : i == 2 ? "Good" : i == 3 ? "Very good" : i != 4 ? "Unknown" : "Excellent";
    }

    @Override 
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }



    @Override 
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            return true;
        } else if (itemId == R.id.rate) {
            if (isOnline()) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } else {
                Toast makeText = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText.setGravity(17, 0, 0);
                makeText.show();
            }
            return true;
        } else if (itemId == R.id.share) {
            if (isOnline()) {
                Intent intent2 = new Intent("android.intent.action.SEND");
                intent2.setType("text/plain");
                intent2.putExtra("android.intent.extra.TEXT", "Hi! I'm using a Who Use My Wi-Fi application. Check it out:http://play.google.com/store/apps/details?id=" + getPackageName());
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(Intent.createChooser(intent2, "Share with Friends"));
            } else {
                Toast makeText2 = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText2.setGravity(17, 0, 0);
                makeText2.show();
            }
            return true;
        } else {
            return super.onOptionsItemSelected(menuItem);
        }
    }

    public boolean isOnline() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    @Override 
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.stm_wifi_info_activity_main);
        this.context = this;
        Toolbar toolbar = findViewById(R.id.tbToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_toolbar_back_black_dark);
        CheckGpsStatus();

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(STM_WifiInformationMainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

        if (this.aBoolean) {
            actualizarIntensidadWifi(this.tiempoMilisegundos);
        } else {
            new AlertDialog.Builder(this).setMessage("This permission is require to get name of network & (ssid) bssid and network status visibility.").setPositiveButton("OK", new DialogInterface.OnClickListener() { 
                @Override 
                public void onClick(DialogInterface dialogInterface, int i) {
                    STM_WifiInformationMainActivity.this.solicitarPermisos();
                    STM_WifiInformationMainActivity.this.enableGPS();
                }
            }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() { 
                @Override 
                public void onClick(DialogInterface dialogInterface, int i) {
                    Log.d("Dialog, clicked", "Cancel");
                    dialogInterface.cancel();
                }
            }).show();
        }
        this.txtNetworkName = (TextView) findViewById(R.id.tvNetworkName);
        this.txtNetworkRSSI = (TextView) findViewById(R.id.tvNetworkRSSI);
        this.txtNetworkSignalStrength = (TextView) findViewById(R.id.tvNetworkSignalStrength);
        this.txtNetworkSpeed = (TextView) findViewById(R.id.tvNetworkSpeed);
        this.txtNetworkIPAddress = (TextView) findViewById(R.id.tvNetworkIPAddress);
        this.txtNetworkMacAddress = (TextView) findViewById(R.id.tvNetworkMacAddress);
        this.txtNetworkGateway = (TextView) findViewById(R.id.tvNetworkGateway);
        this.txtNetworkSubnetMask = (TextView) findViewById(R.id.tvNetworkSubnetMask);
        this.txtNetworkBSSID = (TextView) findViewById(R.id.tvNetworkBSSID);
        this.txtNetworkFrequency = (TextView) findViewById(R.id.tvNetworkFrequency);
        this.txtNetworkChannel = (TextView) findViewById(R.id.tvNetworkChannel);
        this.txtNetworkDNS = (TextView) findViewById(R.id.tvNetworkDNS);
        this.wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
    }


    public void actualizarIntensidadWifi(int i) {
        this.countDownTimer = new CountDownTimer(60000L, i) { 
            @Override 
            public void onTick(long j) {
                STM_WifiInformationMainActivity.this.procesoActualizarIntensidadWifi();
            }

            @Override 
            public void onFinish() {
                STM_WifiInformationMainActivity.this.procesoActualizarIntensidadWifi();
                STM_WifiInformationMainActivity.this.countDownTimer.start();
            }
        }.start();
    }

    public void CheckGpsStatus() {
        LocationManager locationManager = (LocationManager) this.context.getSystemService(Context.LOCATION_SERVICE);
        if (locationManager != null) {
            this.aBoolean = locationManager.isProviderEnabled("gps");
        }
    }

    public void procesoActualizarIntensidadWifi() {
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        this.wifiManager = wifiManager;
        if (wifiManager != null) {
            this.wifiInfo = wifiManager.getConnectionInfo();
        }
        this.nivelRssi = calculateSignalLevel(this.wifiInfo.getRssi(), 101);
        this.intensidadSignal = calculateSignalLevel(this.wifiInfo.getRssi(), 5);
        this.dhcpInfo = this.wifiManager.getDhcpInfo();
        String formatearIp = formatearIp(this.wifiInfo.getIpAddress());
        String formatearIp2 = formatearIp(this.dhcpInfo.gateway);
        String formatearIp3 = formatearIp(this.dhcpInfo.dns1);
        String formatearIp4 = formatearIp(this.dhcpInfo.dns2);
        try {
            this.txtNetworkName.setText(this.wifiInfo.getSSID().replace("\"", ""));
            this.txtNetworkRSSI.setText(this.wifiInfo.getRssi() + " dBm");
            this.txtNetworkSignalStrength.setText(obtenerIntensidadSignal(this.intensidadSignal));
            this.txtNetworkSpeed.setText(this.wifiInfo.getLinkSpeed() + " Mbps");
            this.txtNetworkIPAddress.setText(formatearIp);
            this.txtNetworkMacAddress.setText(obtenerDireccionMAC());
            this.txtNetworkGateway.setText(formatearIp2);
            this.txtNetworkSubnetMask.setText(getMascaraSubred());
            this.txtNetworkBSSID.setText(this.wifiInfo.getBSSID().toUpperCase());
            this.txtNetworkFrequency.setText(this.wifiInfo.getFrequency() + " MHz");
            this.txtNetworkChannel.setText(String.valueOf(getCanal(this.wifiInfo.getFrequency())));
            this.txtNetworkDNS.setText(formatearIp3 + "\n" + formatearIp4);
        } catch (NullPointerException unused) {
            limpiarCampos();
        }
    }

    @Override 
    public void onDestroy() {
        super.onDestroy();
        CountDownTimer countDownTimer = this.countDownTimer;
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        CountDownTimer countDownTimer2 = this.countDownTimerUbicacion;
        if (countDownTimer2 != null) {
            countDownTimer2.cancel();
        }
    }

    public void limpiarCampos() {
        this.txtNetworkName.setText("");
        this.txtNetworkRSSI.setText("");
        this.txtNetworkSignalStrength.setText("");
        this.txtNetworkSpeed.setText("");
        this.txtNetworkIPAddress.setText("");
        this.txtNetworkMacAddress.setText("");
        this.txtNetworkGateway.setText("");
        this.txtNetworkSubnetMask.setText("");
        this.txtNetworkBSSID.setText("");
        this.txtNetworkFrequency.setText("");
        this.txtNetworkChannel.setText("");
        this.txtNetworkDNS.setText("");
    }

    public void solicitarPermisos() {
        ActivityCompat.requestPermissions(this, new String[]{"android.permission.ACCESS_COARSE_LOCATION"}, 1);
    }

    @Override 
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i != 1) {
            return;
        }
        if (iArr.length <= 0 || iArr[0] != 0) {
            actualizarIntensidadWifi(this.tiempoMilisegundos);
        } else if (!wifiActivado()) {
            enableGPS();
        } else if (!conectadoWifi()) {
            Toast makeText = Toast.makeText(getApplicationContext(), "You are not connected WiFi network", Toast.LENGTH_SHORT);
            makeText.setGravity(17, 0, 0);
            makeText.show();
        } else if (GPSActivado()) {
            actualizarIntensidadWifi(this.tiempoMilisegundos);
        } else {
            enableGPS();
            actualizarIntensidadWifi(this.tiempoMilisegundos);
        }
    }

    public String obtenerDireccionMAC() {
        NetworkInterface networkInterface;
        try {
            Iterator it = Collections.list(NetworkInterface.getNetworkInterfaces()).iterator();
            do {
                if (!it.hasNext()) {
                    return "";
                }
                networkInterface = (NetworkInterface) it.next();
            } while (!networkInterface.getName().equalsIgnoreCase("wlan0"));
            byte[] hardwareAddress = networkInterface.getHardwareAddress();
            if (hardwareAddress == null) {
                return "";
            }
            StringBuilder sb = new StringBuilder();
            int length = hardwareAddress.length;
            for (int i = 0; i < length; i++) {
                sb.append(String.format("%02X:", Byte.valueOf(hardwareAddress[i])));
            }
            if (sb.length() > 0) {
                sb.deleteCharAt(sb.length() - 1);
            }
            return sb.toString();
        } catch (Exception unused) {
            return "Unknown";
        }
    }

    private boolean wifiActivado() {
        Object systemService = getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        Objects.requireNonNull(systemService);
        return ((WifiManager) systemService).isWifiEnabled();
    }

    public boolean GPSActivado() {
        Object systemService = getSystemService(Context.LOCATION_SERVICE);
        Objects.requireNonNull(systemService);
        return ((LocationManager) systemService).isProviderEnabled("gps");
    }

    public boolean conectadoWifi() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (Build.VERSION.SDK_INT >= 29) {
            NetworkCapabilities networkCapabilities = connectivityManager != null ? connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork()) : null;
            return networkCapabilities != null && networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
        } else if (connectivityManager == null) {
            return false;
        } else {
            NetworkInfo networkInfo = connectivityManager.getNetworkInfo(1);
            Objects.requireNonNull(networkInfo);
            return networkInfo.isConnected();
        }
    }

    public void enableGPS() {
        try {
            startActivity(new Intent("android.settings.LOCATION_SOURCE_SETTINGS"));
        } catch (ActivityNotFoundException unused) {
            Toast makeText = Toast.makeText(getApplicationContext(), "Unable to open GPS configuration", Toast.LENGTH_SHORT);
            makeText.setGravity(17, 0, 0);
            makeText.show();
        }
    }

    public void abrirConfiguracionWifi() {
        startActivity(new Intent("android.settings.WIFI_SETTINGS"));
        try {
            Intent intent = new Intent();
            intent.setComponent(new ComponentName("com.android.settings", "com.android.settings.wifi.WifiSettings"));
            startActivity(intent);
        } catch (ActivityNotFoundException | SecurityException unused) {
            Toast makeText = Toast.makeText(getApplicationContext(), "Unable to open WiFi configuration", Toast.LENGTH_SHORT);
            makeText.setGravity(17, 0, 0);
            makeText.show();
        }
    }

    public int getCanal(int i) {
        if (i == 2484) {
            return 14;
        }
        if (i < 2484) {
            return (i - 2407) / 5;
        }
        return (i / 5) + NotificationManagerCompat.IMPORTANCE_UNSPECIFIED;
    }

    public String formatearIp(int i) {
        return String.format("%d.%d.%d.%d", Integer.valueOf(i & 255), Integer.valueOf((i >> 8) & 255), Integer.valueOf((i >> 16) & 255), Integer.valueOf((i >> 24) & 255));
    }

    public String getMascaraSubred() {
        String str = "Unknown";
        try {
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            while (networkInterfaces.hasMoreElements()) {
                NetworkInterface nextElement = networkInterfaces.nextElement();
                if (nextElement.isUp()) {
                    for (InterfaceAddress interfaceAddress : nextElement.getInterfaceAddresses()) {
                        InetAddress address = interfaceAddress.getAddress();
                        if (!address.isLoopbackAddress() && address.getHostAddress().indexOf(":") <= 0) {
                            str = calcularMaskByPrefixLength(interfaceAddress.getNetworkPrefixLength());
                        }
                    }
                }
            }
        } catch (Exception unused) {
        }
        return str;
    }

    public static String calcularMaskByPrefixLength(int i) {
        int i2 = (-1) << (32 - i);
        int[] iArr = new int[4];
        for (int i3 = 0; i3 < 4; i3++) {
            iArr[3 - i3] = (i2 >> (i3 * 8)) & 255;
        }
        String str = "" + iArr[0];
        for (int i4 = 1; i4 < 4; i4++) {
            str = str + "." + iArr[i4];
        }
        return str;
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall1).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}
