package com.speed.poster.STM_wifiIpcalculator;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;


import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.speed.poster.Ads_Common.AdsBaseActivity;
import com.speed.poster.R;
import com.speed.poster.STM_wifiInfo.STM_WiFiInfoMainActivity;


import java.math.BigInteger;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.UnknownHostException;

@SuppressWarnings("all")
public class STM_Ipv6calculator_Activity extends AdsBaseActivity {
    private int CurrentBitsIPv6;
    private String CurrentIPv6;
    Button ipv6calculate;
    EditText ipv6address;
    Spinner ipv6subnetmasks;
    TextView v6address_range;
    TextView v6info;
    TextView v6maximum_addresses;
    MulticastAddress[] multicastAddresses = {new MulticastAddress(this, "ff02::1", R.string.stm_allnodes), new MulticastAddress(this, "ff02::2", R.string.stm_allrouters), new MulticastAddress(this, "ff02::9", R.string.stm_allriprouters), new MulticastAddress(this, "ff05::101", R.string.stm_allntpservers), new MulticastAddress(this, "ff05::1:3", R.string.stm_alldhcpservers)};
    Button ipv6reset;

    
    public class MulticastAddress {
        String string;
        int anInt;

        public MulticastAddress(STM_Ipv6calculator_Activity ipv6calculator_Activity, String str, int i) {
            this.string = str;
            this.anInt = i;
        }
    }

    @Override 
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.stm_activity_ip_v6);
        Toolbar toolbar = findViewById(R.id.tbToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_toolbar_back_black_dark);


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(STM_Ipv6calculator_Activity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

        this.ipv6address = (EditText) findViewById(R.id.etIpv6address);
        this.ipv6calculate = (Button) findViewById(R.id.btnIpv6calculate);
        this.ipv6reset = (Button) findViewById(R.id.btnIpv6reset);
        this.ipv6subnetmasks = (Spinner) findViewById(R.id.sprIpv6subnetmasks);
        this.v6address_range = (TextView) findViewById(R.id.tvV6addressRange);
        this.v6maximum_addresses = (TextView) findViewById(R.id.tvV6maximumAddresses);
        this.v6info = (TextView) findViewById(R.id.tvV6info);
        ArrayAdapter<CharSequence> createFromResource = ArrayAdapter.createFromResource(this, R.array.arrays_ipv6subnetmasks, R.layout.stm_spinner_item);
        createFromResource.setDropDownViewResource(17367049);
        this.ipv6subnetmasks.setAdapter((SpinnerAdapter) createFromResource);
        this.ipv6calculate.setOnClickListener(new View.OnClickListener() {
            @Override 
            public void onClick(View view) {
                ((InputMethodManager) STM_Ipv6calculator_Activity.this.getSystemService(Context.INPUT_METHOD_SERVICE)).toggleSoftInput(1, 0);
                STM_Ipv6calculator_Activity.this.doCalculate();
            }
        });
        this.ipv6reset.setOnClickListener(new View.OnClickListener() {
            @Override 
            public void onClick(View view) {
                STM_Ipv6calculator_Activity.this.CurrentIPv6 = "";
                STM_Ipv6calculator_Activity.this.CurrentBitsIPv6 = 24;
                STM_Ipv6calculator_Activity.this.updateFields();
                STM_Ipv6calculator_Activity.this.ClearResults();
            }
        });
        this.ipv6subnetmasks.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override 
            public void onNothingSelected(AdapterView<?> adapterView) {
            }

            @Override 
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                STM_Ipv6calculator_Activity.this.updateResults(true);
            }
        });
        this.ipv6subnetmasks.setSelection(this.CurrentBitsIPv6 - 1);
    }

    public void doCalculate() {
        if (updateResults(true)) {
            return;
        }
        this.v6address_range.setText("Bad IP format");
    }

    public void ClearResults() {
        this.v6address_range.setText("");
        this.v6maximum_addresses.setText("");
        this.v6info.setText("");
    }

    public void updateFields() {
        this.ipv6address.setText(this.CurrentIPv6);
        this.ipv6subnetmasks.setSelection(this.CurrentBitsIPv6 - 1);
    }

    private static InetAddress bigIntToIPv6Address(BigInteger bigInteger) {
        byte[] bArr = new byte[16];
        byte[] byteArray = bigInteger.toByteArray();
        if (byteArray.length > 16 && (byteArray.length != 17 || byteArray[0] != 0)) {
            try {
                throw new UnknownHostException("invalid IPv6 address (too big)");
            } catch (UnknownHostException e) {
                throw new RuntimeException(e);
            }
        } else if (byteArray.length == 16) {
            try {
                return InetAddress.getByAddress(byteArray);
            } catch (UnknownHostException e2) {
                throw new RuntimeException(e2);
            }
        } else {
            if (byteArray.length == 17) {
                System.arraycopy(byteArray, 1, bArr, 0, 16);
            } else {
                System.arraycopy(byteArray, 0, bArr, 16 - byteArray.length, byteArray.length);
            }
            try {
                return InetAddress.getByAddress(bArr);
            } catch (UnknownHostException e3) {
                throw new RuntimeException(e3);
            }
        }
    }

    private String addStringWithSpace(String str, String str2) {
        if (str.length() != 0) {
            str = str + ", ";
        }
        return str + str2;
    }



    public boolean updateResults(boolean z) {
        Editable text = this.ipv6address.getText();
        if (text == null) {
            return false;
        }
        String obj = text.toString();
        try {
            try {
                byte[] ipStringToBytes = STM_InetAddresses.ipStringToBytes(obj);
                if (ipStringToBytes == null) {
                    return false;
                }
                InetAddress byAddress = InetAddress.getByAddress(ipStringToBytes);
                boolean z2 = byAddress instanceof Inet6Address;
                BigInteger bigInteger = new BigInteger(byAddress.getAddress());
                int selectedItemPosition = this.ipv6subnetmasks.getSelectedItemPosition() + 1;
                BigInteger bigInteger2 = BigInteger.ONE;
                BigInteger subtract = bigInteger2.shiftLeft(128 - selectedItemPosition).subtract(bigInteger2);
                BigInteger and = subtract.xor(new BigInteger("ffffffffffffffffffffffffffffffff", 16)).and(bigInteger);
                and.toByteArray();
                InetAddress bigIntToIPv6Address = bigIntToIPv6Address(and);
                InetAddress bigIntToIPv6Address2 = bigIntToIPv6Address(and.or(subtract));
                BigInteger bigInteger3 = BigInteger.ZERO;
                if (!subtract.equals(bigInteger3)) {
                    bigInteger3 = subtract.subtract(bigInteger2);
                }
                String str = "";
                if (byAddress.isAnyLocalAddress()) {
                    try {
                        str = addStringWithSpace("", getString(R.string.stm_any_local));
                    } catch (NumberFormatException unused) {
                    }
                }
                if (byAddress.isLinkLocalAddress()) {
                    str = addStringWithSpace(str, getString(R.string.stm_link_local));
                }
                if (byAddress.isLoopbackAddress()) {
                    str = addStringWithSpace(str, getString(R.string.stm_loopback));
                }
                if (byAddress.isMCGlobal()) {
                    str = addStringWithSpace(str, getString(R.string.stm_mcglobal));
                }
                if (byAddress.isMCLinkLocal()) {
                    str = addStringWithSpace(str, getString(R.string.stm_mclink_local));
                }
                if (byAddress.isMCNodeLocal()) {
                    str = addStringWithSpace(str, getString(R.string.stm_mcnode_local));
                }
                if (byAddress.isMCOrgLocal()) {
                    str = addStringWithSpace(str, getString(R.string.stm_mcorg_local));
                }
                if (byAddress.isMCSiteLocal()) {
                    str = addStringWithSpace(str, getString(R.string.stm_mcsite_local));
                }
                if (byAddress.isMulticastAddress()) {
                    str = addStringWithSpace(str, getString(R.string.stm_multicast));
                    MulticastAddress[] multicastAddressArr = this.multicastAddresses;
                    int length = multicastAddressArr.length;
                    int i = 0;
                    while (true) {
                        if (i >= length) {
                            break;
                        }
                        MulticastAddress multicastAddress = multicastAddressArr[i];
                        try {
                            if (byAddress.getHostAddress().equals(InetAddress.getByAddress(STM_InetAddresses.ipStringToBytes(multicastAddress.string)).getHostAddress())) {
                                break;
                            }
                            i++;
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                            ClearResults();
                            return false;
                        } catch (UnknownHostException e2) {
                            e2.printStackTrace();
                            ClearResults();
                            return false;
                        }
                    }
                }
                if (STM_InetAddresses.isMappedIPv4Address(obj)) {
                    str = addStringWithSpace(str, getString(R.string.stm_mappedipv4));
                }
                this.v6address_range.setText(bigIntToIPv6Address.getHostAddress() + " - " + bigIntToIPv6Address2.getHostAddress());
                this.v6maximum_addresses.setText(bigInteger3.toString());
                this.v6info.setText(str);
                this.CurrentIPv6 = obj;
                this.CurrentBitsIPv6 = selectedItemPosition;
                return true;
            } catch (UnknownHostException e3) {
                e3.printStackTrace();
                ClearResults();
                return false;
            }
        } catch (NumberFormatException e4) {
            e4.printStackTrace();
            ClearResults();
            return false;
        }
    }

    @Override 
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override 
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override 
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            return true;
        } else if (itemId == R.id.rate) {
            if (isOnline()) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } else {
                Toast makeText = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText.setGravity(17, 0, 0);
                makeText.show();
            }
            return true;
        } else if (itemId == R.id.share) {
            if (isOnline()) {
                Intent intent2 = new Intent("android.intent.action.SEND");
                intent2.setType("text/plain");
                intent2.putExtra("android.intent.extra.TEXT", "Hi! I'm using a Who Use My Wi-Fi application. Check it out:http://play.google.com/store/apps/details?id=" + getPackageName());
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(Intent.createChooser(intent2, "Share with Friends"));
            } else {
                Toast makeText2 = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText2.setGravity(17, 0, 0);
                makeText2.show();
            }
            return true;
        } else {
            return super.onOptionsItemSelected(menuItem);
        }
    }

    public boolean isOnline() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}
