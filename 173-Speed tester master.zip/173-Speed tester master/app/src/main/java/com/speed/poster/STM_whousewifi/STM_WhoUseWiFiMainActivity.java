package com.speed.poster.STM_whousewifi;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.net.wifi.SupplicantState;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.speed.poster.Ads_Common.AdsBaseActivity;
import com.speed.poster.R;

import com.speed.poster.STM_Wifi_common.STM_Intro_Activity;
import com.speed.poster.STM_whousewifi.STM_interfaces.STM_OnDeviceFoundListener;
import com.speed.poster.STM_whousewifi.STM_models.STM_DeviceItem;
import com.speed.poster.STM_whousewifi.STM_models.STM_DeviceModal;


import java.util.ArrayList;
import java.util.List;
public class STM_WhoUseWiFiMainActivity extends AdsBaseActivity {
    private final ArrayList<STM_DeviceModal> devices = new ArrayList<>();
    private long end;
    STM_DeviceAdapter deviceAdapter;
    AppCompatTextView getway_name;
    RecyclerView rv_device_list;
    Button scanhost;
    private long start;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        try {
            setContentView(R.layout.stm_activity_who_use_wifi_users);
            setSupportActionBar((Toolbar) findViewById(R.id.tbToolbar));
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_toolbar_back_black_dark);
            
            this.getway_name = (AppCompatTextView) findViewById(R.id.tvGetwayName);
            WifiInfo connectionInfo = ((WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE)).getConnectionInfo();
            if (connectionInfo.getSupplicantState() == SupplicantState.COMPLETED) {
                this.getway_name.setText(connectionInfo.getSSID());
            }
            RecyclerView recyclerView = (RecyclerView) findViewById(R.id.rvDeviceList);
            this.rv_device_list = recyclerView;
            recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), RecyclerView.VERTICAL, false));
            this.scanhost = (Button) findViewById(R.id.scanhost);
            deviceAdapter = new STM_DeviceAdapter(this, this.devices);
            rv_device_list.setAdapter(deviceAdapter);
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("Scanning, please wait.");
            final STM_DeviceFinder deviceFinder = new STM_DeviceFinder(this, new STM_OnDeviceFoundListener() {
                @Override 
                public void onFailed(STM_DeviceFinder deviceFinder2, int i) {
                }

                @Override 
                public void onStart(STM_DeviceFinder deviceFinder2) {
                    STM_WhoUseWiFiMainActivity.this.devices.clear();
                    progressDialog.show();
                    STM_WhoUseWiFiMainActivity.this.start = System.currentTimeMillis();
                }

                @Override 
                public void onFinished(STM_DeviceFinder deviceFinder2, List<STM_DeviceItem> list) {
                    STM_WhoUseWiFiMainActivity.this.end = System.currentTimeMillis();
                    long unused = STM_WhoUseWiFiMainActivity.this.end;
                    long unused2 = STM_WhoUseWiFiMainActivity.this.start;
                    try {
                        if (list.size() > 0) {
                            for (STM_DeviceItem deviceItem : list) {
                                if (deviceItem != null) {
                                    STM_DeviceModal deviceModal = new STM_DeviceModal();
                                    if (deviceItem.getDeviceName() != null) {
                                        deviceModal.setDeviceName(deviceItem.getDeviceName());
                                    }
                                    if (deviceItem.getIpAddress() != null) {
                                        deviceModal.setIpAddress(deviceItem.getIpAddress());
                                    }
                                    if (deviceItem.getVendorName() != null) {
                                        deviceModal.setVendorName(deviceItem.getVendorName());
                                    }
                                    if (deviceItem.getMacAddress() != null) {
                                        deviceModal.setMacAddress(deviceItem.getMacAddress());
                                    }
                                    STM_WhoUseWiFiMainActivity.this.devices.add(deviceModal);
                                }
                            }
                        }
                        STM_WhoUseWiFiMainActivity.this.deviceAdapter.notifyDataSetChanged();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    progressDialog.dismiss();
                }
            });
            deviceFinder.setTimeout(1500).start();
            this.scanhost.setOnClickListener(new View.OnClickListener() {
                @Override 
                public void onClick(View view) {
                    getInstance(STM_WhoUseWiFiMainActivity.this).ShowAd(new HandleClick() {
                        @Override
                        public void Show(boolean adShow) {
                            STM_WhoUseWiFiMainActivity.this.devices.clear();
                            STM_WhoUseWiFiMainActivity.this.deviceAdapter.notifyDataSetChanged();
                            deviceFinder.setTimeout(1500).start();
                        }
                    }, MAIN_CLICK);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override 
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override 
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override 
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            return true;
        } else if (itemId == R.id.rate) {
            if (isOnline()) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } else {
                Toast makeText = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText.setGravity(17, 0, 0);
                makeText.show();
            }
            return true;
        } else if (itemId == R.id.share) {
            if (isOnline()) {
                Intent intent2 = new Intent("android.intent.action.SEND");
                intent2.setType("text/plain");
                intent2.putExtra("android.intent.extra.TEXT", "Hi! I'm using a Who Use My Wi-Fi application. Check it out:http://play.google.com/store/apps/details?id=" + getPackageName());
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(Intent.createChooser(intent2, "Share with Friends"));
            } else {
                Toast makeText2 = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText2.setGravity(17, 0, 0);
                makeText2.show();
            }
            return true;
        } else {
            return super.onOptionsItemSelected(menuItem);
        }
    }

    public boolean isOnline() {
        android.net.NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }
    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
