package com.speed.poster.STM_whousewifi;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;

import com.speed.poster.R;
import com.speed.poster.STM_whousewifi.STM_models.STM_DeviceModal;

import java.util.ArrayList;

public class STM_DeviceAdapter extends RecyclerView.Adapter<STM_DeviceAdapter.Holder> {
    Context context;
    ArrayList<STM_DeviceModal> arrayList;
    
    public class Holder extends RecyclerView.ViewHolder {
        AppCompatTextView hostIp;
        AppCompatTextView hostMac;
        AppCompatTextView hostMacVendor;
        LinearLayout linBorderView;

        public Holder(STM_DeviceAdapter deviceAdapter, View view) {
            super(view);
            this.linBorderView = (LinearLayout) view.findViewById(R.id.llBorderView);
            this.hostMacVendor = (AppCompatTextView) view.findViewById(R.id.tvHostMacVendor);
            this.hostMac = (AppCompatTextView) view.findViewById(R.id.tvHostMac);
            this.hostIp = (AppCompatTextView) view.findViewById(R.id.tvHostIp);
        }
    }

    public STM_DeviceAdapter(Context context, ArrayList<STM_DeviceModal> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
        Log.i("ContentValues", "CustomPingAdapter: " + arrayList.size());
        LayoutInflater.from(context);
    }

    @Override 
    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(this, LayoutInflater.from(this.context).inflate(R.layout.stm_row_host_item_other_devices, viewGroup, false));
    }



    @Override 
    public void onBindViewHolder(Holder holder, int i) {
        STM_DeviceModal deviceModal = this.arrayList.get(i);
        holder.hostMacVendor.setText(deviceModal.getDeviceName());
        holder.hostMac.setText(deviceModal.getMacAddress());
        holder.hostIp.setText(deviceModal.getIpAddress());
    }

    @Override 
    public long getItemId(int i) {
        return this.arrayList.size();
    }

    @Override 
    public int getItemCount() {
        ArrayList<STM_DeviceModal> arrayList = this.arrayList;
        if (arrayList == null) {
            return 0;
        }
        return arrayList.size();
    }
}
