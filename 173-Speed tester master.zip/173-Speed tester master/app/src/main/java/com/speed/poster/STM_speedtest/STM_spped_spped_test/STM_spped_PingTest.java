package com.speed.poster.STM_speedtest.STM_spped_spped_test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class STM_spped_PingTest extends Thread {
    int count;
    String server;
    double instantRtt = 0.0d;
    double avgRtt = 0.0d;
    boolean finished = false;
    public STM_spped_PingTest(String str, int i) {
        this.server = str;
        this.count = i;
    }

    public double getAvgRtt() {
        return this.avgRtt;
    }

    public double getInstantRtt() {
        return this.instantRtt;
    }

    public boolean isFinished() {
        return this.finished;
    }

    @Override
    public void run() {
        Process pingProcess;
        try {
            ProcessBuilder processBuilder = new ProcessBuilder("ping", "-c", String.valueOf(count), server);
            processBuilder.redirectErrorStream(true);
            pingProcess = processBuilder.start();
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(pingProcess.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains("icmp_seq")) {
                    instantRtt = Double.parseDouble(line.split(" ")[line.split(" ").length - 2].replace("time=", ""));
                }
                if (line.startsWith("rtt ")) {
                    avgRtt = Double.parseDouble(line.split("/")[4]);
                } else if (line.contains("Unreachable") || line.contains("Unknown")) {
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            pingProcess.waitFor();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        finished = true;
    }
}
