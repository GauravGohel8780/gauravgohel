package com.speed.poster.STM_wifiIpcalculator;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;


import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.speed.poster.Ads_Common.AdsBaseActivity;
import com.speed.poster.R;
import com.speed.poster.STM_MainActivity;
import com.speed.poster.STM_speedtest.STM_spped_MainActivity;
import com.speed.poster.STM_whousewifi.STM_WhoUseWiFiMainActivity;
import com.speed.poster.STM_wifiInfo.STM_WiFiInfoMainActivity;


public class STM_Ipcalculator_Activity extends AdsBaseActivity {
    LinearLayout lin_converter;
    LinearLayout lin_ipv4;
    LinearLayout lin_ipv6;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.stm_ipcalculator_main_activity);
        Toolbar toolbar = findViewById(R.id.tbToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_toolbar_back_black_dark);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(STM_Ipcalculator_Activity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

        this.lin_ipv4 = (LinearLayout) findViewById(R.id.llIpv4);
        this.lin_ipv6 = (LinearLayout) findViewById(R.id.llIpv6);
        this.lin_converter = (LinearLayout) findViewById(R.id.llConverter);
        this.lin_ipv4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(STM_Ipcalculator_Activity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        STM_Ipcalculator_Activity.this.startActivity(new Intent(STM_Ipcalculator_Activity.this, STM_Ipv4calculator_Activity.class));
                    }
                }, MAIN_CLICK);
            }
        });
        this.lin_ipv6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(STM_Ipcalculator_Activity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        STM_Ipcalculator_Activity.this.startActivity(new Intent(STM_Ipcalculator_Activity.this, STM_Ipv6calculator_Activity.class));
                    }
                }, MAIN_CLICK);
            }
        });
        this.lin_converter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(STM_Ipcalculator_Activity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        STM_Ipcalculator_Activity.this.startActivity(new Intent(STM_Ipcalculator_Activity.this, STM_Converter_Activity.class));
                    }
                }, MAIN_CLICK);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            return true;
        } else if (itemId == R.id.rate) {
            if (isOnline()) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } else {
                Toast makeText = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText.setGravity(17, 0, 0);
                makeText.show();
            }
            return true;
        } else if (itemId == R.id.share) {
            if (isOnline()) {
                Intent intent2 = new Intent("android.intent.action.SEND");
                intent2.setType("text/plain");
                intent2.putExtra("android.intent.extra.TEXT", "Hi! I'm using a Who Use My Wi-Fi application. Check it out:http://play.google.com/store/apps/details?id=" + getPackageName());
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(Intent.createChooser(intent2, "Share with Friends"));
            } else {
                Toast makeText2 = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText2.setGravity(17, 0, 0);
                makeText2.show();
            }
            return true;
        } else {
            return super.onOptionsItemSelected(menuItem);
        }
    }

    public boolean isOnline() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_MEDIUM);
    }
}
