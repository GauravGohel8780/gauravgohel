package com.speed.poster.STM_whousewifi;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.DhcpInfo;
import android.net.wifi.WifiManager;


public class STM_NetworkInfo {
    public static boolean isWifiConnected(Context context) {
        return ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE)).getNetworkInfo(1).isConnected();
    }

    public static DhcpInfo getDhcpInfo(Context context) {
        return ((WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE)).getDhcpInfo();
    }

    public static String getGatewayAddress(Context context) {
        return STM_Utils.parseIpAddress(getDhcpInfo(context).gateway);
    }

    public static String getDeviceIpAddress(Context context) {
        return STM_Utils.parseIpAddress(getDhcpInfo(context).ipAddress);
    }
}
