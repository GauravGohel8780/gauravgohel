package com.speed.poster.STM_whousewifi.STM_macinfo;

import android.content.Context;

import com.speed.poster.STM_whousewifi.STM_NetworkInfo;
import com.speed.poster.STM_whousewifi.STM_models.STM_DeviceItem;
import com.speed.poster.STM_whousewifi.STM_vendor.STM_VendorInfo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.List;

public class STM_MacAddressInfo {
    public static void setMacAddress(Context context, List<STM_DeviceItem> list) {
        try {
            HashMap hashMap = new HashMap();
            for (STM_DeviceItem deviceItem : list) {
                hashMap.put(deviceItem.getIpAddress(), deviceItem);
            }
            String deviceIpAddress = STM_NetworkInfo.getDeviceIpAddress(context);
            STM_DeviceItem deviceItem2 = (STM_DeviceItem) hashMap.get(deviceIpAddress);
            if (deviceItem2 != null) {
                String currentDeviceMacAddress = getCurrentDeviceMacAddress(deviceIpAddress);
                deviceItem2.setMacAddress(currentDeviceMacAddress);
                deviceItem2.setVendorName(STM_VendorInfo.getVendorName(context, currentDeviceMacAddress));
            }
            try {
                Process exec = Runtime.getRuntime().exec("ip n");
                exec.waitFor();
                if (exec.exitValue() != 0) {
                    return;
                }
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(exec.getInputStream()));
                while (true) {
                    String readLine = bufferedReader.readLine();
                    if (readLine == null) {
                        return;
                    }
                    String[] split = readLine.split(" ");
                    if (split.length == 6) {
                        String str = split[0];
                        String str2 = split[4];
                        STM_DeviceItem deviceItem3 = (STM_DeviceItem) hashMap.get(str);
                        if (deviceItem3 != null) {
                            deviceItem3.setMacAddress(str2);
                            deviceItem3.setVendorName(STM_VendorInfo.getVendorName(context, deviceItem3.getMacAddress()));
                        }
                    }
                }
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    public static String getCurrentDeviceMacAddress(String str) {
        byte[] hardwareAddress;
        try {
            NetworkInterface byInetAddress = NetworkInterface.getByInetAddress(InetAddress.getByName(str));
            if (byInetAddress == null || (hardwareAddress = byInetAddress.getHardwareAddress()) == null) {
                return "UnKnown";
            }
            StringBuilder sb = new StringBuilder(18);
            for (byte b : hardwareAddress) {
                if (sb.length() > 0) {
                    sb.append(":");
                }
                sb.append(String.format("%02x", Byte.valueOf(b)));
            }
            return sb.toString();
        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
            return "UnKnown";
        }
    }
}
