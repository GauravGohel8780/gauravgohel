package com.speed.poster.STM_Tools_Ping;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.InputFilter;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.speed.poster.Ads_Common.AdsBaseActivity;
import com.speed.poster.R;
import com.speed.poster.STM_speedtest.STM_spped_MainActivity;
import com.speed.poster.STM_wifiInfo.STM_WiFiInfoMainActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Objects;
import java.util.regex.Pattern;

@SuppressWarnings("all")
public class STM_PingToolsActivity extends AdsBaseActivity {
    private static final Pattern IPV6_HEX_COMPRESSED_PATTERN = Pattern.compile("^((?:[0-9A-Fa-f]{1,4}(?::[0-9A-Fa-f]{1,4})*)?)::((?:[0-9A-Fa-f]{1,4}(?::[0-9A-Fa-f]{1,4})*)?)$");
    private static final Pattern IPV6_STD_PATTERN = Pattern.compile("^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$");
    ArrayAdapter<String> arrayAdapter;
    ArrayList<Float> arrayList;
    AsyncTask asyncTask;
    Context context;
    int intm;
    int intn;
    Boolean aBoolean = Boolean.FALSE;
    String s;
    LinearLayout linNext;
    ArrayList<String> arrayList1;
    RecyclerView recyclerViewPingList;
    EditText edtTime;
    AutoCompleteTextView txtHostUrl;
    EditText edTCount;
    @Override 
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.stm_ping_activity);
        this.context = this;
        Toolbar toolbar = findViewById(R.id.tbToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_toolbar_back_black_dark);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(STM_PingToolsActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });

        this.arrayList = new ArrayList<>();
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.rvPingList);
        this.recyclerViewPingList = recyclerView;
        recyclerView.setHasFixedSize(true);
        this.recyclerViewPingList.setNestedScrollingEnabled(true);
        this.recyclerViewPingList.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        this.linNext = (LinearLayout) findViewById(R.id.llNext);
        this.txtHostUrl = (AutoCompleteTextView) findViewById(R.id.tvHostUrl);
        String[] strArr = STM_MyUtility.getping((Activity) this.context);
        if (strArr != null) {
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this.context, 17367043, strArr);
            this.arrayAdapter = arrayAdapter;
            this.txtHostUrl.setAdapter(arrayAdapter);
        }
        this.edtTime = (EditText) findViewById(R.id.edtTime);
        edTCount = (EditText) findViewById(R.id.edTCount);
        edTCount.setFilters(new InputFilter[]{new STM_InputFilterMinMax("0", "500", this.context, "Enter Valid Range From 0 - 500")});
        this.edtTime.setFilters(new InputFilter[]{new STM_InputFilterMinMax("0", "10000", this.context, "Enter Valid Range From 0 - 1000")});
        this.txtHostUrl.getText().toString();
        this.linNext.setOnClickListener(new View.OnClickListener() {
            @Override 
            public void onClick(View view) {
                STM_PingToolsActivity pingToolsActivity;
                String str;
                try {
                    STM_PingToolsActivity.this.arrayList1 = new ArrayList<>();
                } catch (Exception e) {
                    e.printStackTrace();
                    return;
                }
                if (STM_ConnectivityReceiver.isConnected()) {
                    Object systemService = STM_PingToolsActivity.this.context.getSystemService(Context.INPUT_METHOD_SERVICE);
                    Objects.requireNonNull(systemService);
                    ((InputMethodManager) systemService).hideSoftInputFromWindow(STM_PingToolsActivity.this.txtHostUrl.getWindowToken(), 0);
                    STM_PingToolsActivity pingToolsActivity2 = STM_PingToolsActivity.this;
                    pingToolsActivity2.s = pingToolsActivity2.txtHostUrl.getText().toString().trim();
                    if (!STM_PingToolsActivity.this.s.isEmpty()) {
                        STM_PingToolsActivity.this.s.length();
                        STM_PingToolsActivity pingToolsActivity3 = STM_PingToolsActivity.this;
                        pingToolsActivity3.intm = Integer.parseInt(edTCount.getText().toString());
                        STM_PingToolsActivity pingToolsActivity4 = STM_PingToolsActivity.this;
                        Log.d("hhh", "onClick: "+ arrayList1.size());
                        pingToolsActivity4.intn = Integer.parseInt(pingToolsActivity4.edtTime.getText().toString());
                        if (STM_PingToolsActivity.this.arrayList1.size() > 1 && STM_PingToolsActivity.this.arrayList.size() > 1) {
                            STM_PingToolsActivity.this.arrayList1.clear();
                            STM_PingToolsActivity.this.arrayList.clear();
                        }
                        STM_PingToolsActivity.this.asyncTask = new initDb();
                        STM_PingToolsActivity pingToolsActivity5 = STM_PingToolsActivity.this;
                        String str2 = pingToolsActivity5.s;
                        if (str2 != null && STM_MyUtility.addping((Activity) pingToolsActivity5.context, str2) && (str = (pingToolsActivity = STM_PingToolsActivity.this).s) != null) {
                            ArrayAdapter<String> arrayAdapter2 = pingToolsActivity.arrayAdapter;
                            if (arrayAdapter2 != null) {
                                try {
                                    arrayAdapter2.add(str);
                                    STM_PingToolsActivity.this.arrayAdapter.notifyDataSetChanged();
                                    return;
                                } catch (Exception e2) {
                                    e2.printStackTrace();
                                    return;
                                }
                            }

                                String[] strArr2 = STM_MyUtility.getping((Activity) pingToolsActivity.context);
                                if (strArr2 != null) {
                                    STM_PingToolsActivity.this.arrayAdapter = new ArrayAdapter<>(STM_PingToolsActivity.this.context, 17367043, strArr2);
                                    STM_PingToolsActivity pingToolsActivity6 = STM_PingToolsActivity.this;
                                    pingToolsActivity6.txtHostUrl.setAdapter(pingToolsActivity6.arrayAdapter);
                                    return;
                                }
                                return;
                        }
                        STM_PingToolsActivity.this.asyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Object[0]);
                        return;
                    }
                    Toast makeText = Toast.makeText(STM_PingToolsActivity.this.getApplicationContext(), "Please Enter Valid Host", Toast.LENGTH_SHORT);
                    makeText.setGravity(17, 0, 0);
                    makeText.show();
                    return;
                }
                Toast makeText2 = Toast.makeText(STM_PingToolsActivity.this.getApplicationContext(), "No Internet Connection", Toast.LENGTH_SHORT);
                makeText2.setGravity(17, 0, 0);
                makeText2.show();
            }
        });
    }

    @Override 
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override 
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override 
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            return true;
        } else if (itemId == R.id.rate) {
            if (isOnline()) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } else {
                Toast makeText = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText.setGravity(17, 0, 0);
                makeText.show();
            }
            return true;
        } else if (itemId == R.id.share) {
            if (isOnline()) {
                Intent intent2 = new Intent("android.intent.action.SEND");
                intent2.setType("text/plain");
                intent2.putExtra("android.intent.extra.TEXT", "Hi! I'm using a Who Use My Wi-Fi application. Check it out:http://play.google.com/store/apps/details?id=" + getPackageName());
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(Intent.createChooser(intent2, "Share with Friends"));
            } else {
                Toast makeText2 = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText2.setGravity(17, 0, 0);
                makeText2.show();
            }
            return true;
        } else {
            return super.onOptionsItemSelected(menuItem);
        }
    }

    public boolean isOnline() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    public synchronized boolean getflag() {
        return this.aBoolean.booleanValue();
    }

    public void doPing(int i, int i2, String str) {
        for (int i3 = 0; i3 < i && !getflag(); i3++) {
            try {
                Thread.sleep(i2);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            ping(str, i2);
        }
    }

    @Override 
    public void onStop() {
        super.onStop();
        try {
            AsyncTask asyncTask = this.asyncTask;
            if (asyncTask != null && asyncTask.getStatus() == AsyncTask.Status.RUNNING) {
                this.asyncTask.cancel(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean isIPv6HexCompressedAddress(String str) {
        return str != null && IPV6_HEX_COMPRESSED_PATTERN.matcher(str).matches();
    }

    public static boolean isIPv6Address(String str) {
        return isIPv6StdAddress(str) || isIPv6HexCompressedAddress(str);
    }

    public static boolean isIPv6StdAddress(String str) {
        return str != null && IPV6_STD_PATTERN.matcher(str).matches();
    }
    String[] split;
    public int ping(String str, int i) {

        Runtime runtime = Runtime.getRuntime();
        StringBuilder sb = new StringBuilder();
        int max = Math.max(i / 1000, 1);
        int max2 = Math.max(128, 1);
        try {
            InetAddress byName = InetAddress.getByName(str);
            String hostAddress = byName.getHostAddress();
            String str2 = "ping";
            if (hostAddress == null) {
                hostAddress = byName.getHostName();
            } else if (isIPv6Address(hostAddress)) {
                str2 = "ping6";
            }
            try {
                Process exec = runtime.exec(str2 + " -c 1 -W " + max + " -t " + max2 + " " + hostAddress);
                try {
                    exec.waitFor();
                    int exitValue = exec.exitValue();
                    if (exitValue == 0) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(exec.getInputStream()));
                        while (true) {
                            try {
                                String readLine = bufferedReader.readLine();
                                if (readLine == null) {
                                    split = sb.toString().split("\\n");
                                    if (split.length > 1) {
                                        break;
                                    }
                                } else {
                                    sb.append(readLine);
                                    sb.append("\n");
                                }
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }
                        }
                        runOnUiThread(new Runnable() { 
                            @Override 
                            public void run() {
                                STM_PingToolsActivity.this.arrayList1.add(0, split[1]);
                                Log.i("ContentValues", "run: " + STM_PingToolsActivity.this.arrayList1);
                                STM_PingToolsActivity pingToolsActivity = STM_PingToolsActivity.this;
                                STM_CustomPingAdapter customPingAdapter = new STM_CustomPingAdapter(pingToolsActivity.context, pingToolsActivity.arrayList1);
                                STM_PingToolsActivity.this.recyclerViewPingList.setAdapter(customPingAdapter);
                                customPingAdapter.notifyDataSetChanged();
                            }
                        });
                    }
                    return exitValue;
                } catch (InterruptedException e2) {
                    throw new RuntimeException(e2);
                }
            } catch (IOException e3) {
                throw new RuntimeException(e3);
            }
        } catch (UnknownHostException e4) {
            throw new RuntimeException(e4);
        }
    }

    
    public class initDb extends AsyncTask<Object, Object, Void> {
        ProgressDialog f3654a;

        @Override 
        public void onPreExecute() {
        }

        initDb() {
            this.f3654a = new ProgressDialog(STM_PingToolsActivity.this.context);
        }

        @Override 
        public Void doInBackground(Object... objArr) {
            try {
                isCancelled();
                try {
                    STM_PingToolsActivity pingToolsActivity = STM_PingToolsActivity.this;
                    pingToolsActivity.doPing(pingToolsActivity.intm, pingToolsActivity.intn, pingToolsActivity.s);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            } catch (Exception e2) {
                e2.printStackTrace();
                return null;
            }
        }

        @Override 
        public void onPostExecute(Void r1) {
            try {
                this.f3654a.dismiss();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
