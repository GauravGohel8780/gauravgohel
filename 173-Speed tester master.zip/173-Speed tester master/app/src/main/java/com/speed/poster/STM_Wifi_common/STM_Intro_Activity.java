package com.speed.poster.STM_Wifi_common;


import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.speed.poster.Ads_Common.AdsBaseActivity;
import com.speed.poster.STM_MainActivity;
import com.speed.poster.R;
import com.speed.poster.databinding.StmActivityIntroBinding;

import java.util.ArrayList;

public class STM_Intro_Activity extends AdsBaseActivity {
    StmActivityIntroBinding binding;
    Animation btnAnim;
    ImageView indicator_img;
    STM_IntroViewPagerAdapter introViewPagerAdapter;
    int position = 0;
    private ViewPager screenPager;
    TabLayout tab_indicator;


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        SetSystemFullScreen(this);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        StmActivityIntroBinding inflate = StmActivityIntroBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView(inflate.getRoot());

        final ArrayList arrayList = new ArrayList();
        arrayList.add(new STM_IntroModel(getString(R.string.stm_text_title_a), getString(R.string.stm_text_intro_a), R.drawable.ic_intro_logo_1));
        arrayList.add(new STM_IntroModel(getString(R.string.stm_text_title_a), getString(R.string.stm_text_intro_b), R.drawable.ic_intro_logo_2));
        arrayList.add(new STM_IntroModel(getString(R.string.stm_text_title_a), getString(R.string.stm_text_intro_c), R.drawable.ic_intro_logo_3));
        this.screenPager = (ViewPager) findViewById(R.id.vpScreenViewpager);
        this.tab_indicator = (TabLayout) findViewById(R.id.tlTabIndicator);
        this.indicator_img = (ImageView) findViewById(R.id.ivIndicator);
        STM_IntroViewPagerAdapter introViewPagerAdapter = new STM_IntroViewPagerAdapter(this, arrayList);
        this.introViewPagerAdapter = introViewPagerAdapter;
        this.screenPager.setAdapter(introViewPagerAdapter);
        this.tab_indicator.setupWithViewPager(this.screenPager);
        findViewById(R.id.ivNext).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(STM_Intro_Activity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        STM_Intro_Activity intro_Activity = STM_Intro_Activity.this;
                        intro_Activity.position = intro_Activity.screenPager.getCurrentItem();
                        if (position < arrayList.size()) {
                            position++;
                            screenPager.setCurrentItem(position);
                        }
                        if (position == arrayList.size() - 1) {
                            loaddLastScreen();
                        }
                        if (position == arrayList.size()) {
                            startActivity(new Intent(STM_Intro_Activity.this, STM_MainActivity.class));
                            new STM_PrefManager().setFistTimeIntro(STM_Intro_Activity.this, true);
                        }

                    }
                }, MAIN_CLICK);
            }
        });
        this.tab_indicator.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    indicator_img.setImageResource(R.drawable.ic_intro_page_1);
                } else if (tab.getPosition() == 1) {
                    indicator_img.setImageResource(R.drawable.ic_intro_page_2);
                } else if (tab.getPosition() == 2) {
                    indicator_img.setImageResource(R.drawable.ic_intro_page_3);
                }
                if (tab.getPosition() == arrayList.size() - 1) {
                    loaddLastScreen();
                }
                if (tab.getPosition() == arrayList.size() - 2) {
                    tab_indicator.setVisibility(View.INVISIBLE);
                }
            }
        });
    }

    public void loaddLastScreen() {
        this.tab_indicator.setVisibility(View.INVISIBLE);
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        finishAffinity();
    }


    public static void SetSystemFullScreen(Activity activity) {
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) {
            View v = activity.getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            View decorView = activity.getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
