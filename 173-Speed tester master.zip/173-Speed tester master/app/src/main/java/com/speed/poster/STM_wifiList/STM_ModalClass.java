package com.speed.poster.STM_wifiList;


public class STM_ModalClass {
    private String canal;
    private String direccionMac;
    private String frecuencia;
    private String nombreRed;
    private String nombreRedYDireccionMac;
    private int porcentaje;
    private int rssi;
    private String seguridad;

    public STM_ModalClass(String str, String str2, String str3, String str4, String str5, String str6, int i, int i2) {
        this.nombreRed = str;
        this.direccionMac = str2;
        this.nombreRedYDireccionMac = str3;
        this.frecuencia = str4;
        this.canal = str5;
        this.seguridad = str6;
        this.rssi = i;
        this.porcentaje = i2;
    }

    public String getNombreRed() {
        return this.nombreRed;
    }

    public void setNombreRed(String str) {
        this.nombreRed = str;
    }

    public String getDireccionMac() {
        return this.direccionMac;
    }

    public void setDireccionMac(String str) {
        this.direccionMac = str;
    }

    public String getNombreRedYDireccionMac() {
        return this.nombreRedYDireccionMac;
    }

    public void setNombreRedYDireccionMac(String str) {
        this.nombreRedYDireccionMac = str;
    }

    public String getFrecuencia() {
        return this.frecuencia;
    }

    public void setFrecuencia(String str) {
        this.frecuencia = str;
    }

    public String getCanal() {
        return this.canal;
    }

    public void setCanal(String str) {
        this.canal = str;
    }

    public String getSeguridad() {
        return this.seguridad;
    }

    public void setSeguridad(String str) {
        this.seguridad = str;
    }

    public int getRssi() {
        return this.rssi;
    }

    public void setRssi(int i) {
        this.rssi = i;
    }

    public int getPorcentaje() {
        return this.porcentaje;
    }

    public void setPorcentaje(int i) {
        this.porcentaje = i;
    }
}
