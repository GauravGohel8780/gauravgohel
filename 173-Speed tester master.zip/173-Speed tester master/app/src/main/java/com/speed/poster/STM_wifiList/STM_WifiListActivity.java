package com.speed.poster.STM_wifiList;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.BACK_CLICK;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.speed.poster.Ads_Common.AdsBaseActivity;
import com.speed.poster.R;
import com.speed.poster.STM_wifiInfo.STM_WiFiInfoMainActivity;
import com.speed.poster.STM_wifiInfo.STM_WifiInformationMainActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class STM_WifiListActivity extends AdsBaseActivity {
    public CountDownTimer countDownTimerGeneral;
    private Parcelable posicionRecycler;
    public TextView txtSearchingWifi;
    private WifiListAdapter wifiListAdapter;
    public RecyclerView wifiListRecyclerView;
    public ArrayList<STM_ModalClass> wifiLists;
    private WifiManager wifiManager;

    public int calculateSignalLevel(int i, int i2) {
        if (i <= -100) {
            return 0;
        }
        return i >= -50 ? i2 - 1 : (int) (((i + 100) * (i2 - 1)) / 50.0f);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            return true;
        } else if (itemId == R.id.rate) {
            if (isOnline()) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } else {
                Toast makeText = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText.setGravity(17, 0, 0);
                makeText.show();
            }
            return true;
        } else if (itemId == R.id.share) {
            if (isOnline()) {
                Intent intent2 = new Intent("android.intent.action.SEND");
                intent2.setType("text/plain");
                intent2.putExtra("android.intent.extra.TEXT", "Hi! I'm using a Who Use My Wi-Fi application. Check it out:http://play.google.com/store/apps/details?id=" + getPackageName());
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(Intent.createChooser(intent2, "Share with Friends"));
            } else {
                Toast makeText2 = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText2.setGravity(17, 0, 0);
                makeText2.show();
            }
            return true;
        } else {
            return super.onOptionsItemSelected(menuItem);
        }
    }

    public boolean isOnline() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.stm_wifi_list_activity);
        Toolbar toolbar = findViewById(R.id.tbToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_toolbar_back_black_dark);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getInstance(STM_WifiListActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }, BACK_CLICK);
            }
        });


        solicitarPermisos();
        this.wifiListRecyclerView = (RecyclerView) findViewById(R.id.rvWifiList);
        this.txtSearchingWifi = (TextView) findViewById(R.id.tvSearchingWifi);
        this.wifiListRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        this.wifiLists = new ArrayList<>();
        procesoActualizacionRedes();
    }

    public class WifiListAdapter extends RecyclerView.Adapter<WifiListAdapter.ViewHolder> implements View.OnClickListener {
        int linBorderView = 1;
        public ArrayList<STM_ModalClass> listaRedes;
        private View.OnClickListener listener;

        public class ViewHolder extends RecyclerView.ViewHolder {
            ProgressBar barraPorcentaje;
            TextView txtCanal;
            TextView txtFrecuencia;
            LinearLayout linBorderView;
            TextView txtNombreRedYDireccionMac;
            TextView txtPorcentaje;
            TextView txtRssi;
            TextView txtSeguridad;

            public ViewHolder(WifiListAdapter wifiListAdapter, View view) {
                super(view);
                this.txtNombreRedYDireccionMac = (TextView) view.findViewById(R.id.tvNombreRedYDireccionMac);
                this.txtFrecuencia = (TextView) view.findViewById(R.id.tvFrecuencia);
                this.txtCanal = (TextView) view.findViewById(R.id.tvCanal);
                this.txtSeguridad = (TextView) view.findViewById(R.id.tvSeguridad);
                this.txtPorcentaje = (TextView) view.findViewById(R.id.txtPorcentaje);
                this.txtRssi = (TextView) view.findViewById(R.id.tvRssi);
                this.barraPorcentaje = (ProgressBar) view.findViewById(R.id.pbBarraPorcentaje);
                this.linBorderView = (LinearLayout) view.findViewById(R.id.llBorderView);
            }
        }

        public WifiListAdapter(STM_WifiListActivity wifiListActivity, ArrayList<STM_ModalClass> arrayList) {
            this.listaRedes = arrayList;
        }

        @Override 
        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View inflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.stm_wifi_list_layout, viewGroup, false);
            ViewHolder viewHolder = new ViewHolder(this, inflate);
            inflate.setOnClickListener(this);
            return viewHolder;
        }

        @Override 
        public void onBindViewHolder(ViewHolder viewHolder, int i) {
            viewHolder.txtNombreRedYDireccionMac.setText(this.listaRedes.get(i).getNombreRedYDireccionMac());
            viewHolder.txtFrecuencia.setText("Frequency:  " + this.listaRedes.get(i).getFrecuencia() + " MHz");
            viewHolder.txtCanal.setText("Channel:  " + this.listaRedes.get(i).getCanal());
            viewHolder.txtSeguridad.setText("Security:  " + this.listaRedes.get(i).getSeguridad());
            viewHolder.txtPorcentaje.setText(this.listaRedes.get(i).getPorcentaje() + "%");
            viewHolder.txtRssi.setText(this.listaRedes.get(i).getRssi() + " dBm");
            viewHolder.barraPorcentaje.setProgress(this.listaRedes.get(i).getPorcentaje());
        }

        @Override 
        public int getItemCount() {
            return this.listaRedes.size();
        }

        @Override 
        public void onClick(View view) {
            View.OnClickListener onClickListener = this.listener;
            if (onClickListener != null) {
                onClickListener.onClick(view);
            }
        }

        public void setOnClickListener(View.OnClickListener onClickListener) {
            this.listener = onClickListener;
        }
    }

    private void solicitarPermisos() {
        ActivityCompat.requestPermissions(this, new String[]{"android.permission.ACCESS_COARSE_LOCATION"}, 1);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        CountDownTimer countDownTimer = this.countDownTimerGeneral;
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
    }

    public void actualizarRedes(int i) {
        this.countDownTimerGeneral = new CountDownTimer(60000L, i) { 
            @Override 
            public void onTick(long j) {
                try {
                    STM_WifiListActivity.this.procesoActualizacionRedes();
                } catch (SecurityException unused) {

                }
            }

            @Override
            public void onFinish() {
                STM_WifiListActivity.this.procesoActualizacionRedes();
                STM_WifiListActivity.this.countDownTimerGeneral.start();
            }
        }.start();
    }

    public void procesoActualizacionRedes() {
        this.wifiLists.clear();
        try {
            this.posicionRecycler = this.wifiListRecyclerView.getLayoutManager().onSaveInstanceState();
        } catch (Exception unused) {
        }
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        this.wifiManager = wifiManager;
        try {
            wifiManager.startScan();
        } catch (Exception unused2) {
        }
        try {
            if (ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0) {
                String str = "";
                String str2 = str;
                for (ScanResult scanResult : this.wifiManager.getScanResults()) {
                    String replace = scanResult.SSID.replace("\"", "");
                    String upperCase = scanResult.BSSID.toUpperCase();
                    String obtenerSeguridadRed = obtenerSeguridadRed(scanResult.capabilities);
                    int i = scanResult.level;
                    int calculateSignalLevel = calculateSignalLevel(i, 101);
                    try {
                        str = String.valueOf(scanResult.frequency);
                        str2 = String.valueOf(getCanal(scanResult.frequency));
                    } catch (NullPointerException unused3) {
                    }
                    try {
                        this.wifiLists.add(new STM_ModalClass(replace, upperCase, replace + " [" + upperCase + "]", str, str2, obtenerSeguridadRed, i, calculateSignalLevel));
                    } catch (NullPointerException unused4) {
                    }
                }
                if (!this.wifiLists.isEmpty()) {
                    this.txtSearchingWifi.setVisibility(View.GONE);
                    iniciarAdaptador();
                    this.wifiListRecyclerView.getLayoutManager().onRestoreInstanceState(this.posicionRecycler);
                    return;
                }
                this.txtSearchingWifi.setVisibility(View.VISIBLE);
                iniciarAdaptador();
            }
        } catch (Exception unused5) {
        }
    }

    public String obtenerSeguridadRed(String str) {
        CharSequence[] charSequenceArr = {"WEP", "WPA", "WPA2", "WPA-EAP", "IEEE8021X"};
        for (int i = 4; i >= 0; i--) {
            if (str.contains(charSequenceArr[i])) {
                return (String) charSequenceArr[i];
            }
        }
        return "Open";
    }

    public int getCanal(int i) {
        if (i == 2484) {
            return 14;
        }
        if (i < 2484) {
            return (i - 2407) / 5;
        }
        return (i / 5) + NotificationManagerCompat.IMPORTANCE_UNSPECIFIED;
    }

    public void iniciarAdaptador() {
        Collections.sort(this.wifiLists, new Comparator<STM_ModalClass>() {
            @Override
            public int compare(STM_ModalClass modalClass, STM_ModalClass modalClass2) {
                if (modalClass.getRssi() < modalClass2.getRssi()) {
                    return 1;
                }
                return modalClass.getRssi() > modalClass2.getRssi() ? -1 : 0;
            }
        });
        WifiListAdapter wifiListAdapter = new WifiListAdapter(this, this.wifiLists);
        this.wifiListAdapter = wifiListAdapter;
        this.wifiListRecyclerView.setAdapter(wifiListAdapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BANNER);
    }
}
