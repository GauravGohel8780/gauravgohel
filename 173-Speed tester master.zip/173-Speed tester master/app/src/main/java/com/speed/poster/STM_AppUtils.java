package com.speed.poster;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;

public class STM_AppUtils {
    public static int TYPE_MOBILE = 2;
    public static int TYPE_NOT_CONNECTED = 0;
    public static int TYPE_WIFI = 1;
    private static boolean connectionEstablished = false;
    public static String mobileNetwork;
    private final Context context;

    public STM_AppUtils(Context context) {
        this.context = context;
    }

    public static int getConnectivityStatus(Context context) {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        if (activeNetworkInfo != null) {
            if (activeNetworkInfo.getType() == 1) {
                return TYPE_WIFI;
            }
            if (activeNetworkInfo.getType() == 0) {
                return TYPE_MOBILE;
            }
        }
        return TYPE_NOT_CONNECTED;
    }

    public static String getConnectivityStatusString(Context context) {
        int connectivityStatus = getConnectivityStatus(context);
        try {
            if (connectivityStatus == TYPE_WIFI) {
                return "Wifi enabled";
            }
            if (connectivityStatus == TYPE_MOBILE) {
                return "Mobile data enabled";
            }
            if (connectivityStatus != TYPE_NOT_CONNECTED) {
                return null;
            }
            return "Not connected to Internet";
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static String getNetwork(Context context) {
        try {
            NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
            if (activeNetworkInfo == null || !activeNetworkInfo.isConnected()) {
                mobileNetwork = "No Connection";
            }
            if (activeNetworkInfo.getType() == 1) {
                mobileNetwork = "WIFI";
                return "WIFI";
            } else if (activeNetworkInfo.getType() == 0) {
                switch (activeNetworkInfo.getSubtype()) {
                    case 1:
                        mobileNetwork = "2G";
                        return "2G";
                    case 2:
                        mobileNetwork = "2G";
                        return "2G";
                    case 3:
                        mobileNetwork = "3G";
                        return "3G";
                    case 4:
                        mobileNetwork = "2G";
                        return "2G";
                    case 5:
                        mobileNetwork = "3G";
                        return "3G";
                    case 6:
                        mobileNetwork = "3G";
                        return "3G";
                    case 7:
                        mobileNetwork = "2G";
                        return "2G";
                    case 8:
                        mobileNetwork = "3G";
                        return "3G";
                    case 9:
                        mobileNetwork = "3G";
                        return "3G";
                    case 10:
                        mobileNetwork = "3G";
                        return "3G";
                    case 11:
                        mobileNetwork = "2G";
                        return "2G";
                    case 12:
                        mobileNetwork = "3G";
                        return "3G";
                    case 13:
                        mobileNetwork = "LTE";
                        return "LTE";
                    case 14:
                        mobileNetwork = "3G";
                        return "3G";
                    case 15:
                        mobileNetwork = "3G";
                        return "3G";
                    case 16:
                        mobileNetwork = "3G";
                        return "3G";
                    default:
                        mobileNetwork = "UNKOWN";
                        return "UNKOWN";
                }
            } else {
                mobileNetwork = "UNKOWN";
                return "UNKOWN";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean isConnected(Context context) {
        String network = getNetwork(context);
        boolean z = network.equals("WIFI") || network.equals("MOBILE NETWORK");
        connectionEstablished = z;
        return z;
    }

    public boolean getConnectionEstablished() {
        return connectionEstablished;
    }

    public boolean isConnectedWifi() {
        NetworkInfo networkInfo = getNetworkInfo(1);
        return networkInfo != null && networkInfo.isConnectedOrConnecting();
    }

    public boolean isEnabled() {
        return getWifiManager().isWifiEnabled();
    }

    public WifiManager getWifiManager() {
        return (WifiManager) this.context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
    }

    private ConnectivityManager getConnectivityManager() {
        return (ConnectivityManager) this.context.getSystemService(Context.CONNECTIVITY_SERVICE);
    }

    private NetworkInfo getNetworkInfo(int i) {
        ConnectivityManager connectivityManager = getConnectivityManager();
        if (connectivityManager != null) {
            return connectivityManager.getNetworkInfo(i);
        }
        return null;
    }
}
