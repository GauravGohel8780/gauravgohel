package com.speed.poster.STM_routerInfo;

import static com.iten.tenoku.ad.AdShow.getInstance;
import static com.iten.tenoku.utils.AdUtils.ClickType.MAIN_CLICK;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.Toolbar;


import com.iten.tenoku.ad.HandleClick.HandleClick;
import com.iten.tenoku.utils.AdUtils;
import com.speed.poster.Ads_Common.AdsBaseActivity;
import com.speed.poster.R;

import com.speed.poster.STM_pageofrouter.STM_Router_Page;
import com.speed.poster.STM_wifiRouterPassword.STM_Router_password;


public class STM_RouterInfoMainActivity extends AdsBaseActivity {
    LinearLayout linRouterAdmin;
    LinearLayout linRouterPasswordList;
    AppCompatTextView txtGateway;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            return true;
        } else if (itemId == R.id.rate) {
            if (isOnline()) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } else {
                Toast makeText = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText.setGravity(17, 0, 0);
                makeText.show();
            }
            return true;
        } else if (itemId == R.id.share) {
            if (isOnline()) {
                Intent intent2 = new Intent("android.intent.action.SEND");
                intent2.setType("text/plain");
                intent2.putExtra("android.intent.extra.TEXT", "Hi! I'm using a Who Use My Wi-Fi application. Check it out:http://play.google.com/store/apps/details?id=" + getPackageName());
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(Intent.createChooser(intent2, "Share with Friends"));
            } else {
                Toast makeText2 = Toast.makeText(getApplicationContext(), "No Internet Connection..", Toast.LENGTH_SHORT);
                makeText2.setGravity(17, 0, 0);
                makeText2.show();
            }
            return true;
        } else {
            return super.onOptionsItemSelected(menuItem);
        }
    }

    public boolean isOnline() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.stm_activity_router_info_main);
        setSupportActionBar((Toolbar) findViewById(R.id.tbToolbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_toolbar_back_black_dark);
        
        this.txtGateway = (AppCompatTextView) findViewById(R.id.tvGateway);
        this.linRouterPasswordList = (LinearLayout) findViewById(R.id.llRouterPasswordList);
        this.linRouterAdmin = (LinearLayout) findViewById(R.id.llRouterAdmin);
        setDetails();
        this.linRouterPasswordList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(STM_RouterInfoMainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(STM_RouterInfoMainActivity.this, STM_Router_password.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        STM_RouterInfoMainActivity.this.startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });
        this.linRouterAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInstance(STM_RouterInfoMainActivity.this).ShowAd(new HandleClick() {
                    @Override
                    public void Show(boolean adShow) {
                        Intent intent = new Intent(STM_RouterInfoMainActivity.this, STM_Router_Page.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        STM_RouterInfoMainActivity.this.startActivity(intent);
                    }
                }, MAIN_CLICK);
            }
        });
    }

    private void setDetails() {
        STM_Wireless wireless = new STM_Wireless(this);
        if (wireless.isEnabled() && wireless.isConnectedWifi()) {
            try {
                String.valueOf(wireless.getWifiInfo().getFrequency());
                this.txtGateway.setText("Gateway : " + wireless.getGetWay());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getInstance(this).ShowNativeAd(findViewById(R.id.nativeSmall).findViewById(R.id.native_ad_layout), AdUtils.NativeType.NATIVE_BIG);
    }
}
