package com.speed.poster.STM_ipInfo;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Url;


public interface STM_Api {
    String BASE_URL = "http://ip-api.com/";

    @GET
    Call<STM_IPinfo> getIPINFO(@Url String str);
}
