package com.speed.poster.STM_speedtest.STM_spped_spped_test;

import android.util.Log;


import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.StringReader;
import java.net.URL;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;

class STM_spped_HandlerUpload extends Thread {
    URL url;

    public STM_spped_HandlerUpload(URL url) {
        this.url = url;
    }

    @Override
    public void run() {
        byte[] bArr = new byte[153600];
        long currentTimeMillis = System.currentTimeMillis();
        while (true) {
            try {
                final String str = new BufferedReader(new StringReader(this.url.toString())).readLine().split("://")[1].split(":")[0];
                Log.d("Uploadurl", str);
                HttpsURLConnection httpsURLConnection = (HttpsURLConnection) this.url.openConnection();
                httpsURLConnection.setDoOutput(true);
                httpsURLConnection.setRequestMethod("POST");
                httpsURLConnection.setRequestProperty("Connection", "Keep-Alive");
                httpsURLConnection.setSSLSocketFactory((SSLSocketFactory) SSLSocketFactory.getDefault());
                httpsURLConnection.setHostnameVerifier(new HostnameVerifier() {
                    @Override
                    public boolean verify(String str2, SSLSession sSLSession) {
                        return str2.equals(str);
                    }
                });
                httpsURLConnection.connect();
                DataOutputStream dataOutputStream = new DataOutputStream(httpsURLConnection.getOutputStream());
                dataOutputStream.write(bArr, 0, 153600);
                dataOutputStream.flush();
                httpsURLConnection.getResponseCode();
                STM_spped_HttpUploadTest.uploadedKByte = (int) (STM_spped_HttpUploadTest.uploadedKByte + (153600 / 1024.0d));
                if ((System.currentTimeMillis() - currentTimeMillis) / 1000.0d >= 8) {
                    return;
                }
                dataOutputStream.close();
                httpsURLConnection.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
                return;
            }
        }
    }
}
