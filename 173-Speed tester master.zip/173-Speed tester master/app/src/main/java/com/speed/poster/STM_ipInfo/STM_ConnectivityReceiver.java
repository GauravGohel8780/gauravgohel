package com.speed.poster.STM_ipInfo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

import com.speed.poster.STM_AppUtils;
import com.speed.poster.STM_Wifi_common.STM_MyApplication;

public class STM_ConnectivityReceiver extends BroadcastReceiver {
    public static ConnectivityReceiverListener connectivityReceiverListener;
    public interface ConnectivityReceiverListener {
        void onNetworkConnectionChanged(boolean z);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            Log.i("ContentValues", "onReceive: ");
            NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
            boolean z = activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
            Log.i("ContentValues", "onReceive: " + STM_AppUtils.getConnectivityStatusString(context));
            ConnectivityReceiverListener connectivityReceiverListener2 = connectivityReceiverListener;
            if (connectivityReceiverListener2 != null) {
                connectivityReceiverListener2.onNetworkConnectionChanged(z);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean isConnected() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) STM_MyApplication.getInstance().getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }
}
