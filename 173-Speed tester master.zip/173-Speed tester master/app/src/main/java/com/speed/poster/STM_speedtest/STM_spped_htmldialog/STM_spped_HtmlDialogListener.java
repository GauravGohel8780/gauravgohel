package com.speed.poster.STM_speedtest.STM_spped_htmldialog;


public abstract class STM_spped_HtmlDialogListener {
    public void onDialogCancel() {
    }

    public abstract void onNegativeButtonPressed();

    public abstract void onPositiveButtonPressed();
}
