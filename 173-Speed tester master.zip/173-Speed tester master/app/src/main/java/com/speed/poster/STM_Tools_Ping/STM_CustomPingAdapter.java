package com.speed.poster.STM_Tools_Ping;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;

import com.speed.poster.R;

import java.util.ArrayList;

public class STM_CustomPingAdapter extends RecyclerView.Adapter<STM_CustomPingAdapter.Holder> {
    Context context;
    ArrayList<String> a;
    public class Holder extends RecyclerView.ViewHolder {
        LinearLayout linBorderView;
        AppCompatTextView txtPingNumber;
        AppCompatTextView txtPingResultByte;

        public Holder(STM_CustomPingAdapter customPingAdapter, View view) {
            super(view);
            this.txtPingNumber = (AppCompatTextView) view.findViewById(R.id.tvPingNumber);
            this.txtPingResultByte = (AppCompatTextView) view.findViewById(R.id.tvPingResultByte);
            this.linBorderView = (LinearLayout) view.findViewById(R.id.llBorderView);
        }
    }

    public STM_CustomPingAdapter(Context context, ArrayList<String> arrayList) {
        this.context = context;
        this.a = arrayList;
        Log.i("ContentValues", "CustomPingAdapter: " + arrayList.size());
        LayoutInflater.from(context);
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(this, LayoutInflater.from(this.context).inflate(R.layout.stm_ping_list_layout, viewGroup, false));
    }


    @Override
    public void onBindViewHolder(Holder holder, int i) {
        holder.txtPingNumber.setText("#" + (getItemCount() - i));
        holder.txtPingResultByte.setText(this.a.get(i));
    }

    @Override
    public long getItemId(int i) {
        return this.a.size();
    }

    @Override
    public int getItemCount() {
        ArrayList<String> arrayList = this.a;
        if (arrayList == null) {
            return 0;
        }
        return arrayList.size();
    }
}
