package com.iten.tenoku.ad.HandleClick;

public interface HandleOwnInterstitialAd {
    void Show(boolean adShow);
}
