package com.iten.tenoku.listeners;

public interface ExitListeners {

    void onExitScreen();

    void onDoubleExit();

    void onBackScreen();
}
