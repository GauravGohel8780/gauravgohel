package com.statussaver.wacaption.gbversion.WAUtil.adpter;

import android.content.Context;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import com.statussaver.wacaption.gbversion.WAUtil.frgmnt.AudioFragment;
import com.statussaver.wacaption.gbversion.WAUtil.frgmnt.SendAudioFragment;

/* loaded from: classes3.dex */
public class PagerAudioAdpter extends FragmentPagerAdapter {
    Context actContext;
    String checkId;
    int totCount;

    public PagerAudioAdpter(Context context, FragmentManager fragmentManager, int i, String str) {
        super(fragmentManager, i);
        this.actContext = context;
        this.totCount = i;
        this.checkId = str;
    }

    @Override // androidx.fragment.app.FragmentPagerAdapter
    public Fragment getItem(int i) {
        if (i == 0) {
            return new AudioFragment();
        }
        if (i == 1) {
            return new SendAudioFragment();
        }
        return null;
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public int getCount() {
        return this.totCount;
    }
}
