package com.statussaver.wacaption.gbversion.StatusSaver.fragment;

import android.media.ThumbnailUtils;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.core.internal.view.SupportMenu;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.StatusSaver.adpter.Adpter_10_Video;
import com.statussaver.wacaption.gbversion.StatusSaver.model.VideosModel;
import com.statussaver.wacaption.gbversion.StatusSaver.util.ItemOffsetDecoration;
import com.statussaver.wacaption.gbversion.StatusSaver.util.SdCardHelper;
import java.io.File;
import java.util.ArrayList;

/* loaded from: classes3.dex */
public class Fragment_10_Video extends Fragment {
    ImageView mErrorView;
    RecyclerView mTVideoRvVideosList;
    SwipeRefreshLayout mTVideoSrlVideoView;
    Adpter_10_Video mVideoAdapter;
    public ArrayList<VideosModel> mVideoList;

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_10_video, viewGroup, false);
        this.mTVideoRvVideosList = (RecyclerView) inflate.findViewById(R.id.tVideo_rvVideosList);
        this.mTVideoSrlVideoView = (SwipeRefreshLayout) inflate.findViewById(R.id.tVideo_srlVideoView);
        this.mErrorView = (ImageView) inflate.findViewById(R.id.error_view);
        this.mVideoList = new ArrayList<>();
        copyAllStatusIntoFile();
        this.mVideoAdapter = new Adpter_10_Video(getActivity(), this.mVideoList);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 2);
        this.mTVideoRvVideosList.addItemDecoration(new ItemOffsetDecoration(getActivity(), R.dimen.photos_list_spacing));
        this.mTVideoRvVideosList.setLayoutManager(gridLayoutManager);
        this.mTVideoRvVideosList.setNestedScrollingEnabled(true);
        ((SimpleItemAnimator) this.mTVideoRvVideosList.getItemAnimator()).setSupportsChangeAnimations(false);
        this.mTVideoRvVideosList.setAdapter(this.mVideoAdapter);
        this.mVideoAdapter.notifyDataSetChanged();
        doStatusCheck();
        this.mTVideoSrlVideoView.setColorSchemeColors(SupportMenu.CATEGORY_MASK, -16711936, -16776961, -16711681);
        this.mTVideoSrlVideoView.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.fragment.Fragment_10_Video.1
            @Override // androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
            public void onRefresh() {
                if (Fragment_10_Video.this.mTVideoRvVideosList == null || Fragment_10_Video.this.mVideoAdapter == null) {
                    return;
                }
                Fragment_10_Video.this.mTVideoRvVideosList.getRecycledViewPool().clear();
                Fragment_10_Video.this.mVideoList.clear();
                Fragment_10_Video.this.mVideoAdapter.notifyDataSetChanged();
                Fragment_10_Video.this.copyAllStatusIntoFile();
            }
        });
        return inflate;
    }

    private void doStatusCheck() {
        if (this.mVideoList.size() == 0) {
            doCheckFile();
        } else {
            this.mErrorView.setVisibility(8);
            this.mTVideoSrlVideoView.setRefreshing(false);
        }
        Adpter_10_Video adpter_10_Video = this.mVideoAdapter;
        if (adpter_10_Video != null) {
            adpter_10_Video.notifyDataSetChanged();
        }
    }

    public void copyAllStatusIntoFile() {
        this.mTVideoSrlVideoView.setRefreshing(false);
        if (SdCardHelper.isSdCardPresent()) {
            File externalStorageDirectory = Environment.getExternalStorageDirectory();
            File file = new File(externalStorageDirectory.getAbsolutePath() + "/WhatsApp/Media/.Statuses/");
            if (file.isDirectory()) {
                File[] listFiles = file.listFiles();
                this.mErrorView.setVisibility(8);
                if (listFiles == null || listFiles.length == 0) {
                    doCheckFile();
                    return;
                }
                for (int i = 0; i < listFiles.length; i++) {
                    if (listFiles[i].getName().contains(".mp4") || listFiles[i].getName().contains(".flv") || listFiles[i].getName().contains(".mkv")) {
                        VideosModel videosModel = new VideosModel();
                        videosModel.setVideoName(listFiles[i].getName());
                        videosModel.setVideoPath(listFiles[i].getAbsolutePath());
                        videosModel.setBitmap(ThumbnailUtils.createVideoThumbnail(listFiles[i].getAbsolutePath(), 3));
                        this.mVideoList.add(videosModel);
                    }
                    if (this.mVideoList.size() == 0) {
                        doCheckFile();
                    } else {
                        this.mErrorView.setVisibility(8);
                    }
                }
                return;
            }
            doCheckFile();
        }
    }

    private void doCheckFile() {
        this.mTVideoSrlVideoView.setRefreshing(false);
        this.mErrorView.setVisibility(0);
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
    }
}
