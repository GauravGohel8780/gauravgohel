package com.statussaver.wacaption.gbversion.StatusSaver.adpter;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.StatusSaver.activity.SavedViewer;
import com.statussaver.wacaption.gbversion.StatusSaver.util.ModelStatus;
import com.statussaver.wacaption.gbversion.newwautl.Utils;
import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;

/* loaded from: classes3.dex */
public class adpter_Saved extends RecyclerView.Adapter<adpter_Saved.MyViewHolder> {
    public Activity acontext;
    public ArrayList<ModelStatus> arrayList;

    public adpter_Saved(Activity activity, ArrayList<ModelStatus> arrayList) {
        this.arrayList = arrayList;
        this.acontext = activity;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_saved_pictures_s, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {
        ModelStatus modelStatus = this.arrayList.get(i);
        Glide.with(this.acontext).load(modelStatus.getFull_path()).into(myViewHolder.imageView);
        if (Build.VERSION.SDK_INT >= 30) {
            myViewHolder.delete.setVisibility(8);
        } else {
            myViewHolder.delete.setVisibility(0);
        }
        if (modelStatus.getFull_path().endsWith(".mp4")) {
            myViewHolder.play.setVisibility(0);
        } else {
            myViewHolder.play.setVisibility(8);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.arrayList.size();
    }

    public void shareVia(String str, String str2) {
        try {
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType(str);
            Activity activity = this.acontext;
            Uri uriForFile = FileProvider.getUriForFile(activity, this.acontext.getPackageName() + ".provider", new File(str2));
            intent.addFlags(1);
            intent.putExtra("android.intent.extra.STREAM", uriForFile);
            intent.putExtra("android.intent.extra.TEXT", this.acontext.getString(R.string.share) + this.acontext.getPackageName());
            this.acontext.startActivity(Intent.createChooser(intent, "Share Your Video!"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteFile(String str, int i) {
        File file = new File(str);
        if (file.exists()) {
            if (file.delete()) {
                removeAt(i);
                Toast.makeText(this.acontext, "Delete Success", 0).show();
                PrintStream printStream = System.out;
                printStream.println("file Deleted :" + str);
                return;
            }
            Toast.makeText(this.acontext, "Delete Failed", 0).show();
            PrintStream printStream2 = System.out;
            printStream2.println("file not Deleted :" + str);
        }
    }

    public void removeAt(int i) {
        this.arrayList.remove(i);
        notifyItemRemoved(i);
        notifyItemRangeChanged(i, this.arrayList.size());
    }

    /* loaded from: classes3.dex */
    public class MyViewHolder extends RecyclerView.ViewHolder {
        public ImageView delete;
        public ImageView imageView;
        public ImageView play;
        public ImageView share;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public MyViewHolder(View view) {
            super(view);
            this.imageView = (ImageView) view.findViewById(R.id.saved_image);
            this.play = (ImageView) view.findViewById(R.id.saved_play);
            ImageView imageView = (ImageView) view.findViewById(R.id.saved_delete);
            this.delete = imageView;
            imageView.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.adpter.adpter_Saved.MyViewHolder.1
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    MyViewHolder.this.lambda$new$0$SavedAdaptor$MyViewHolder(view2);
                }
            });
            ImageView imageView2 = (ImageView) view.findViewById(R.id.saved_share);
            this.share = imageView2;
            imageView2.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.adpter.adpter_Saved.MyViewHolder.2
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    ModelStatus modelStatus = adpter_Saved.this.arrayList.get(MyViewHolder.this.getAdapterPosition());
                    if (modelStatus.getFull_path().endsWith(".jpg")) {
                        adpter_Saved.this.shareVia("image/jpg", modelStatus.getFull_path());
                    } else if (!modelStatus.getFull_path().endsWith(".mp4")) {
                    } else {
                        adpter_Saved.this.shareVia("video/mp4", modelStatus.getFull_path());
                    }
                }
            });
            this.itemView.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.adpter.adpter_Saved.MyViewHolder.3
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    MyViewHolder.this.lambda$new$2$SavedAdaptor$MyViewHolder(view2);
                }
            });
        }

        public void lambda$new$0$SavedAdaptor$MyViewHolder(View view) {
            try {
                adpter_Saved adpter_saved = adpter_Saved.this;
                adpter_saved.deleteFile(adpter_saved.arrayList.get(getAdapterPosition()).getFull_path(), getAdapterPosition());
            } catch (ArrayIndexOutOfBoundsException unused) {
            }
        }

        public void lambda$new$2$SavedAdaptor$MyViewHolder(View view) {
            final ModelStatus modelStatus = adpter_Saved.this.arrayList.get(getAdapterPosition());
            if (modelStatus.getFull_path().endsWith(".jpg")) {
//                AppManage.getInstance(adpter_Saved.this.acontext).showInterstitialAd(adpter_Saved.this.acontext, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.adpter.adpter_Saved.MyViewHolder.4
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        Intent intent = new Intent(adpter_Saved.this.acontext, SavedViewer.class);
                        intent.putExtra("path", modelStatus.getFull_path());
                        intent.putExtra("type", Utils.IMAGE);
                        intent.putExtra("pack", modelStatus.getPack());
                        adpter_Saved.this.acontext.startActivity(intent);
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            } else {
//                AppManage.getInstance(adpter_Saved.this.acontext).showInterstitialAd(adpter_Saved.this.acontext, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.adpter.adpter_Saved.MyViewHolder.5
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        Intent intent = new Intent(adpter_Saved.this.acontext, SavedViewer.class);
                        intent.putExtra("path", modelStatus.getFull_path());
                        intent.putExtra("type", Utils.VIDEO);
                        intent.putExtra("pack", modelStatus.getPack());
                        adpter_Saved.this.acontext.startActivity(intent);
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        }
    }
}
