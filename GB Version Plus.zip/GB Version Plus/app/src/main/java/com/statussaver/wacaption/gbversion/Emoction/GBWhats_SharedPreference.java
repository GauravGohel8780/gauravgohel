package com.statussaver.wacaption.gbversion.Emoction;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.Arrays;

public class GBWhats_SharedPreference {
    public static final String FAVORITES = "Product_Favorite";
    public static final String PREFS_NAME = "PRODUCT_APP";

    public ArrayList<GBWhats_CSFEmot> getFavorites(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_NAME, 0);
        if (!sharedPreferences.contains(FAVORITES)) {
            return null;
        }
        return new ArrayList<>(Arrays.asList((GBWhats_CSFEmot[]) new Gson().fromJson(sharedPreferences.getString(FAVORITES, null), GBWhats_CSFEmot[].class)));
    }
}
