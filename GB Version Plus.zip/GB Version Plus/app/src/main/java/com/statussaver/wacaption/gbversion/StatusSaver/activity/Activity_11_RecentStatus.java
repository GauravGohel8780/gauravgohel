package com.statussaver.wacaption.gbversion.StatusSaver.activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.PointerIconCompat;
import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.google.android.material.tabs.TabLayout;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.StatusSaver.fragment.Fragment_11_Image;
import com.statussaver.wacaption.gbversion.StatusSaver.fragment.Fragment_11_Video;
import com.statussaver.wacaption.gbversion.StatusSaver.model.StoryModel;
import com.statussaver.wacaption.gbversion.StatusSaver.util.Const;
import com.statussaver.wacaption.gbversion.StatusSaver.util.WhitelistCheck;
import com.statussaver.wacaption.gbversion.StatusSaver.util.iUtils;
import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.IntFunction;

/* loaded from: classes3.dex */
public class Activity_11_RecentStatus extends AppCompatActivity {
    AppCompatButton btn_grant;
    Context context;
    private File[] files;
    private ImageView iv_back;
    private String namedataprefs;
    boolean result;
    TabLayout tab_layout;
    private ViewPager viewPager;
    ArrayList<Object> filesList = new ArrayList<>();
    private int[] tabIconsselect = {R.drawable.photo_select, R.drawable.video_select};
    private int[] tabIconsunselect = {R.drawable.photo, R.drawable.video};

    @SuppressLint("WrongConstant")
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_11_recent_status);
        this.context = this;
        this.btn_grant = (AppCompatButton) findViewById(R.id.btn_grant);
        this.tab_layout = (TabLayout) findViewById(R.id.tab_layout);
        this.viewPager = (ViewPager) findViewById(R.id.viewpager);
        ImageView imageView = (ImageView) findViewById(R.id.iv_back);
        this.iv_back = imageView;
        imageView.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_11_RecentStatus.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Activity_11_RecentStatus.this.onBackPressed();
            }
        });
        this.namedataprefs = getSharedPreferences("whatsapp_pref", 0).getString("whatsapp", "");
        this.btn_grant.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_11_RecentStatus.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Activity_11_RecentStatus.this.grantAnd11permission();
            }
        });
        boolean checkPermission = checkPermission();
        this.result = checkPermission;
        if (checkPermission) {
            if (this.namedataprefs.equals("")) {
                this.btn_grant.setVisibility(0);
            } else if (getFromSdcard() != null) {
                this.viewPager.setOffscreenPageLimit(0);
                setupViewPager(this.viewPager);
                this.tab_layout.setupWithViewPager(this.viewPager);
                setupTabIcons();
                for (int i = 0; i < this.tab_layout.getTabCount(); i++) {
                    this.tab_layout.getTabAt(i).setCustomView((ImageView) LayoutInflater.from(getApplicationContext()).inflate(R.layout.custom_tab, (ViewGroup) null));
                }
                this.tab_layout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_11_RecentStatus.3
                    @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
                    public void onTabReselected(TabLayout.Tab tab) {
                    }

                    @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
                    public void onTabSelected(TabLayout.Tab tab) {
                        if (tab.getPosition() == 0) {
                            Activity_11_RecentStatus.this.tab_layout.getTabAt(0).setIcon(Activity_11_RecentStatus.this.tabIconsselect[0]);
                        }
                        if (tab.getPosition() == 1) {
                            Activity_11_RecentStatus.this.tab_layout.getTabAt(1).setIcon(Activity_11_RecentStatus.this.tabIconsselect[1]);
                        }
                    }

                    @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
                    public void onTabUnselected(TabLayout.Tab tab) {
                        Activity_11_RecentStatus.this.tab_layout.getTabAt(0).setIcon(Activity_11_RecentStatus.this.tabIconsunselect[0]);
                        Activity_11_RecentStatus.this.tab_layout.getTabAt(1).setIcon(Activity_11_RecentStatus.this.tabIconsunselect[1]);
                    }
                });
                this.btn_grant.setVisibility(8);
            } else {
                this.btn_grant.setVisibility(0);
            }
        }
    }

    private void setupTabIcons() {
        this.tab_layout.getTabAt(0).setIcon(this.tabIconsselect[0]);
        this.tab_layout.getTabAt(1).setIcon(this.tabIconsunselect[1]);
    }

    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        viewPagerAdapter.addFragment(new Fragment_11_Image(this, getData()), "Images");
        viewPagerAdapter.addFragment(new Fragment_11_Video(this, getData()), "Videos");
        viewPager.setAdapter(viewPagerAdapter);
        viewPager.setCurrentItem(0);
    }

    private ArrayList<Object> getData() {
        int i = 0;
        if (Build.VERSION.SDK_INT >= 30) {
            if (this.filesList != null) {
                this.filesList = new ArrayList<>();
            }
            try {
                DocumentFile[] fromSdcard = getFromSdcard();
                int length = fromSdcard.length;
                while (i < length) {
                    DocumentFile documentFile = fromSdcard[i];
                    Uri uri = documentFile.getUri();
                    StoryModel storyModel = new StoryModel();
                    storyModel.setName("Download");
                    storyModel.setUri(uri);
                    storyModel.setPath(documentFile.getUri().toString());
                    storyModel.setFilename(documentFile.getUri().getLastPathSegment());
                    storyModel.setPack(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    PrintStream printStream = System.out;
                    printStream.println("dhasjhdahsdhas " + documentFile.getUri().toString());
                    if (!documentFile.getUri().toString().contains(".nomedia") && !documentFile.getUri().toString().equals("")) {
                        this.filesList.add(storyModel);
                    }
                    this.btn_grant.setVisibility(8);
                    i++;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            if (this.filesList != null) {
                this.filesList = new ArrayList<>();
            }
            getSharedPreferences("whatsapp_pref", 0).getString("whatsapp", "main");
            File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + Const.FOLDER_NAME + "Media/.Statuses");
            File file2 = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + Const.FOLDER_NAME_Whatsapp_and11 + "Media/.Statuses");
            final ArrayList arrayList = new ArrayList(Arrays.asList(file.listFiles() != null ? file.listFiles() : new File[]{new File("")}));
            arrayList.addAll(Arrays.asList(file2.listFiles() != null ? file2.listFiles() : new File[]{new File("")}));
            File[] fileArr = new File[arrayList.size()];
            if (Build.VERSION.SDK_INT >= 24) {
                Arrays.setAll(fileArr, new IntFunction() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_11_RecentStatus.4
                    @Override // java.util.function.IntFunction
                    public final Object apply(int i2) {
                        return (File) arrayList.get(i2);
                    }
                });
                this.files = fileArr;
            } else {
                this.files = file.listFiles();
            }
            try {
                Arrays.sort(this.files, new Comparator() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_11_RecentStatus.5
                    @Override // java.util.Comparator
                    public int compare(Object obj, Object obj2) {
                        File file3 = (File) obj;
                        File file4 = (File) obj2;
                        if (file3.lastModified() > file4.lastModified()) {
                            return -1;
                        }
                        return file3.lastModified() < file4.lastModified() ? 1 : 0;
                    }
                });
                while (true) {
                    File[] fileArr2 = this.files;
                    if (i >= fileArr2.length) {
                        break;
                    }
                    File file3 = fileArr2[i];
                    StoryModel storyModel2 = new StoryModel();
                    storyModel2.setName("Download");
                    storyModel2.setUri(Uri.fromFile(file3));
                    storyModel2.setPath(this.files[i].getAbsolutePath());
                    storyModel2.setFilename(file3.getName());
                    storyModel2.setPack(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    if (!file3.getName().equals(".nomedia") && !file3.getPath().equals("")) {
                        this.filesList.add(storyModel2);
                    }
                    this.btn_grant.setVisibility(8);
                    i++;
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        return this.filesList;
    }

    /* loaded from: classes3.dex */
    public class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList();
        private final List<String> mFragmentTitleList = new ArrayList();

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        ViewPagerAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        @Override // androidx.fragment.app.FragmentPagerAdapter
        public Fragment getItem(int i) {
            return this.mFragmentList.get(i);
        }

        @Override // androidx.viewpager.widget.PagerAdapter
        public int getCount() {
            return this.mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String str) {
            this.mFragmentList.add(fragment);
            this.mFragmentTitleList.add(str);
        }

        @Override // androidx.viewpager.widget.PagerAdapter
        public CharSequence getPageTitle(int i) {
            return this.mFragmentTitleList.get(i);
        }
    }

    private DocumentFile[] getFromSdcard() {
        DocumentFile fromTreeUri = DocumentFile.fromTreeUri(this, Uri.parse(this.namedataprefs));
        if (fromTreeUri == null || !fromTreeUri.exists() || !fromTreeUri.isDirectory() || !fromTreeUri.canRead() || !fromTreeUri.canWrite()) {
            return null;
        }
        return fromTreeUri.listFiles();
    }

    public boolean checkPermission() {
        if (Build.VERSION.SDK_INT < 23 || ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
            return true;
        }
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.WRITE_EXTERNAL_STORAGE")) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(true);
            builder.setTitle(R.string.pernecessory);
            builder.setMessage(R.string.write_neesory);
            builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_11_RecentStatus.6
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialogInterface, int i) {
                    ActivityCompat.requestPermissions(Activity_11_RecentStatus.this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 123);
                }
            });
            builder.create().show();
            return false;
        }
        ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 123);
        return false;
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 1239) {
            this.viewPager.setOffscreenPageLimit(0);
            setupViewPager(this.viewPager);
            this.tab_layout.setupWithViewPager(this.viewPager);
        } else if (i != 1011 || i2 != -1) {
        } else {
            Uri data = intent.getData();
            try {
                if (Build.VERSION.SDK_INT >= 19) {
                    getContentResolver().takePersistableUriPermission(data, 1);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            this.namedataprefs = data.toString();
            SharedPreferences.Editor edit = getSharedPreferences("whatsapp_pref", 0).edit();
            edit.putString("whatsapp", data.toString());
            edit.apply();
            if (this.namedataprefs.equals("")) {
                this.btn_grant.setVisibility(0);
            } else if (getFromSdcard() != null) {
                this.btn_grant.setVisibility(8);
                this.viewPager.setOffscreenPageLimit(0);
                setupViewPager(this.viewPager);
                this.tab_layout.setupWithViewPager(this.viewPager);
            } else {
                this.btn_grant.setVisibility(0);
            }
        }
    }

    public void grantAnd11permission() {
        Intent intent;
        iUtils.isPackageInstalled(this, WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
        StorageManager storageManager = (StorageManager) getSystemService("storage");
        String whatsupFolder = getWhatsupFolder();
        if (Build.VERSION.SDK_INT >= 29) {
            intent = storageManager.getPrimaryStorageVolume().createOpenDocumentTreeIntent();
            String replace = intent.getParcelableExtra("android.provider.extra.INITIAL_URI").toString().replace("/root/", "/document/");
            intent.putExtra("android.provider.extra.INITIAL_URI", Uri.parse(replace + "%3A" + whatsupFolder));
        } else {
            intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
            intent.putExtra("android.provider.extra.INITIAL_URI", Uri.parse(whatsupFolder));
        }
        intent.addFlags(2);
        intent.addFlags(1);
        intent.addFlags(128);
        intent.addFlags(64);
        startActivityForResult(intent, PointerIconCompat.TYPE_COPY);
    }

    public String getWhatsupFolder() {
        StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStorageDirectory());
        sb.append(File.separator);
        sb.append("Android/media/com.whatsapp/WhatsApp");
        sb.append(File.separator);
        sb.append("Media");
        sb.append(File.separator);
        sb.append(".Statuses");
        return new File(sb.toString()).isDirectory() ? "Android%2Fmedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F.Statuses" : "WhatsApp%2FMedia%2F.Statuses";
    }

    public void checkAgain() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.WRITE_EXTERNAL_STORAGE")) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(true);
            builder.setTitle(R.string.pernecessory);
            builder.setMessage(R.string.write_neesory);
            builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_11_RecentStatus.7
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    Activity_11_RecentStatus.this.lambda$checkAgain$0$RecentStatusActivity(dialogInterface, i);
                }
            });
            builder.create().show();
            return;
        }
        ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 123);
    }

    public void lambda$checkAgain$0$RecentStatusActivity(DialogInterface dialogInterface, int i) {
        ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 123);
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 123) {
            if (iArr.length <= 0 || iArr[0] != 0) {
                checkAgain();
            } else {
                Log.e("", "");
            }
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
//        AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_11_RecentStatus.8
//            @Override // com.pesonal.adsdk.MyCallback
//            public void callbackCall() {
                Activity_11_RecentStatus.this.finish();
//            }
//        }, AppManage.app_mainClickCntSwAd);
    }
}
