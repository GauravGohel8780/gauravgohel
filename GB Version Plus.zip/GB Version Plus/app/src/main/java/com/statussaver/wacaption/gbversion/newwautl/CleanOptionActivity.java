package com.statussaver.wacaption.gbversion.newwautl;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.text.format.Formatter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.documentfile.provider.DocumentFile;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.StatusSaver.util.WhitelistCheck;
import java.io.File;

/* loaded from: classes3.dex */
public class CleanOptionActivity extends AppCompatActivity {
    private Activity activity;
    getSizeAsync async;
    RelativeLayout audioBtn;
    ImageView backIV;
    RelativeLayout docBtn;
    RelativeLayout gifBtn;
    RelativeLayout imgBtn;
    RelativeLayout stickerBtn;
    RelativeLayout videoBtn;
    RelativeLayout wallBtn;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_clean_option);
        this.activity = this;
        ((ImageView) findViewById(R.id.back)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.newwautl.CleanOptionActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                CleanOptionActivity.super.onBackPressed();
            }
        });
        ((RelativeLayout) findViewById(R.id.imgBtn)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.newwautl.CleanOptionActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                CleanOptionActivity cleanOptionActivity = CleanOptionActivity.this;
                cleanOptionActivity.onTapBtn(Utils.IMAGE, cleanOptionActivity.getWhatsupFolder("WhatsApp Images"), CleanOptionActivity.this.getWhatsupFolder("WhatsApp Images%2FSent"));
            }
        });
        ((RelativeLayout) findViewById(R.id.videoBtn)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.newwautl.CleanOptionActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                CleanOptionActivity cleanOptionActivity = CleanOptionActivity.this;
                cleanOptionActivity.onTapBtn(Utils.VIDEO, cleanOptionActivity.getWhatsupFolder("WhatsApp Video"), CleanOptionActivity.this.getWhatsupFolder("WhatsApp Video%2FSent"));
            }
        });
        ((RelativeLayout) findViewById(R.id.docBtn)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.newwautl.CleanOptionActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                CleanOptionActivity cleanOptionActivity = CleanOptionActivity.this;
                cleanOptionActivity.onTapBtn(Utils.DOCUMENT, cleanOptionActivity.getWhatsupFolder("WhatsApp Documents"), CleanOptionActivity.this.getWhatsupFolder("WhatsApp Documents%2FSent"));
            }
        });
        ((RelativeLayout) findViewById(R.id.audioBtn)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.newwautl.CleanOptionActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                CleanOptionActivity cleanOptionActivity = CleanOptionActivity.this;
                cleanOptionActivity.onTapBtn(Utils.AUDIO, cleanOptionActivity.getWhatsupFolder("WhatsApp Audio"), CleanOptionActivity.this.getWhatsupFolder("WhatsApp Audio%2FSent"));
            }
        });
        ((RelativeLayout) findViewById(R.id.stickerBtn)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.newwautl.CleanOptionActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                CleanOptionActivity cleanOptionActivity = CleanOptionActivity.this;
                cleanOptionActivity.onTapOther(Utils.STICKER, cleanOptionActivity.getWhatsupFolder("WhatsApp Stickers"));
            }
        });
        ((RelativeLayout) findViewById(R.id.wallBtn)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.newwautl.CleanOptionActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                CleanOptionActivity cleanOptionActivity = CleanOptionActivity.this;
                cleanOptionActivity.onTapOther(Utils.WALLPAPER, cleanOptionActivity.getWhatsupFolder("WallPaper"));
            }
        });
        ((RelativeLayout) findViewById(R.id.gifBtn)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.newwautl.CleanOptionActivity.8
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                CleanOptionActivity cleanOptionActivity = CleanOptionActivity.this;
                cleanOptionActivity.onTapBtn(Utils.GIF, cleanOptionActivity.getWhatsupFolder("WhatsApp Animated Gifs"), CleanOptionActivity.this.getWhatsupFolder("WhatsApp Animated Gifs%2FSent"));
            }
        });
        getSizeAsync getsizeasync = new getSizeAsync();
        this.async = getsizeasync;
        getsizeasync.execute(new Void[0]);
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
//        AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.newwautl.CleanOptionActivity.9
//            @Override // com.pesonal.adsdk.MyCallback
//            public void callbackCall() {
                CleanOptionActivity.this.finish();
//            }
//        }, AppManage.app_mainClickCntSwAd);
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onResume() {
        super.onResume();
        getSizeAsync getsizeasync = new getSizeAsync();
        this.async = getsizeasync;
        getsizeasync.execute(new Void[0]);
    }

    /* loaded from: classes3.dex */
    class getSizeAsync extends AsyncTask<Void, Void, Void> {
        String txt1 = "0B";
        String txt2 = "0B";
        String txt3 = "0B";
        String txt4 = "0B";
        String txt5 = "0B";
        String txt6 = "0B";
        String txt7 = "0B";

        getSizeAsync() {
        }

        public Void doInBackground(Void... voidArr) {
            if (Utils.iswApp) {
                if (!SharedPrefs.getWAImgTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWAImgSendTree(CleanOptionActivity.this).equals("")) {
                    CleanOptionActivity cleanOptionActivity = CleanOptionActivity.this;
                    long folderSize = CleanOptionActivity.folderSize(cleanOptionActivity.getFiles(SharedPrefs.getWAImgTree(cleanOptionActivity)));
                    CleanOptionActivity cleanOptionActivity2 = CleanOptionActivity.this;
                    this.txt1 = Formatter.formatShortFileSize(cleanOptionActivity, folderSize + CleanOptionActivity.folderSize(cleanOptionActivity2.getFiles(SharedPrefs.getWAImgSendTree(cleanOptionActivity2))));
                } else if (!SharedPrefs.getWAImgTree(CleanOptionActivity.this).equals("") && SharedPrefs.getWAImgSendTree(CleanOptionActivity.this).equals("")) {
                    CleanOptionActivity cleanOptionActivity3 = CleanOptionActivity.this;
                    this.txt1 = Formatter.formatShortFileSize(cleanOptionActivity3, CleanOptionActivity.folderSize(cleanOptionActivity3.getFiles(SharedPrefs.getWAImgTree(cleanOptionActivity3))));
                } else if (SharedPrefs.getWAImgTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWAImgSendTree(CleanOptionActivity.this).equals("")) {
                    CleanOptionActivity cleanOptionActivity4 = CleanOptionActivity.this;
                    this.txt1 = Formatter.formatShortFileSize(cleanOptionActivity4, CleanOptionActivity.folderSize(cleanOptionActivity4.getFiles(SharedPrefs.getWAImgSendTree(cleanOptionActivity4))));
                }
                if (!SharedPrefs.getWAVideoTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWAVideoSendTree(CleanOptionActivity.this).equals("")) {
                    CleanOptionActivity cleanOptionActivity5 = CleanOptionActivity.this;
                    long folderSize2 = CleanOptionActivity.folderSize(cleanOptionActivity5.getFiles(SharedPrefs.getWAVideoTree(cleanOptionActivity5)));
                    CleanOptionActivity cleanOptionActivity6 = CleanOptionActivity.this;
                    this.txt2 = Formatter.formatShortFileSize(cleanOptionActivity5, folderSize2 + CleanOptionActivity.folderSize(cleanOptionActivity6.getFiles(SharedPrefs.getWAVideoSendTree(cleanOptionActivity6))));
                } else if (!SharedPrefs.getWAVideoTree(CleanOptionActivity.this).equals("") && SharedPrefs.getWAVideoSendTree(CleanOptionActivity.this).equals("")) {
                    CleanOptionActivity cleanOptionActivity7 = CleanOptionActivity.this;
                    this.txt2 = Formatter.formatShortFileSize(cleanOptionActivity7, CleanOptionActivity.folderSize(cleanOptionActivity7.getFiles(SharedPrefs.getWAVideoTree(cleanOptionActivity7))));
                } else if (SharedPrefs.getWAVideoTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWAVideoSendTree(CleanOptionActivity.this).equals("")) {
                    CleanOptionActivity cleanOptionActivity8 = CleanOptionActivity.this;
                    this.txt2 = Formatter.formatShortFileSize(cleanOptionActivity8, CleanOptionActivity.folderSize(cleanOptionActivity8.getFiles(SharedPrefs.getWAVideoSendTree(cleanOptionActivity8))));
                }
                if (!SharedPrefs.getWADocTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWADocSendTree(CleanOptionActivity.this).equals("")) {
                    CleanOptionActivity cleanOptionActivity9 = CleanOptionActivity.this;
                    long folderSize3 = CleanOptionActivity.folderSize(cleanOptionActivity9.getFiles(SharedPrefs.getWADocTree(cleanOptionActivity9)));
                    CleanOptionActivity cleanOptionActivity10 = CleanOptionActivity.this;
                    this.txt3 = Formatter.formatShortFileSize(cleanOptionActivity9, folderSize3 + CleanOptionActivity.folderSize(cleanOptionActivity10.getFiles(SharedPrefs.getWADocSendTree(cleanOptionActivity10))));
                } else if (!SharedPrefs.getWADocTree(CleanOptionActivity.this).equals("") && SharedPrefs.getWADocSendTree(CleanOptionActivity.this).equals("")) {
                    CleanOptionActivity cleanOptionActivity11 = CleanOptionActivity.this;
                    this.txt3 = Formatter.formatShortFileSize(cleanOptionActivity11, CleanOptionActivity.folderSize(cleanOptionActivity11.getFiles(SharedPrefs.getWADocTree(cleanOptionActivity11))));
                } else if (SharedPrefs.getWADocTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWADocSendTree(CleanOptionActivity.this).equals("")) {
                    CleanOptionActivity cleanOptionActivity12 = CleanOptionActivity.this;
                    this.txt3 = Formatter.formatShortFileSize(cleanOptionActivity12, CleanOptionActivity.folderSize(cleanOptionActivity12.getFiles(SharedPrefs.getWADocSendTree(cleanOptionActivity12))));
                }
                if (!SharedPrefs.getWAAudioTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWAAudioSendTree(CleanOptionActivity.this).equals("")) {
                    CleanOptionActivity cleanOptionActivity13 = CleanOptionActivity.this;
                    long folderSize4 = CleanOptionActivity.folderSize(cleanOptionActivity13.getFiles(SharedPrefs.getWAAudioTree(cleanOptionActivity13)));
                    CleanOptionActivity cleanOptionActivity14 = CleanOptionActivity.this;
                    this.txt4 = Formatter.formatShortFileSize(cleanOptionActivity13, folderSize4 + CleanOptionActivity.folderSize(cleanOptionActivity14.getFiles(SharedPrefs.getWAAudioSendTree(cleanOptionActivity14))));
                } else if (!SharedPrefs.getWAAudioTree(CleanOptionActivity.this).equals("") && SharedPrefs.getWAAudioSendTree(CleanOptionActivity.this).equals("")) {
                    CleanOptionActivity cleanOptionActivity15 = CleanOptionActivity.this;
                    this.txt4 = Formatter.formatShortFileSize(cleanOptionActivity15, CleanOptionActivity.folderSize(cleanOptionActivity15.getFiles(SharedPrefs.getWAAudioTree(cleanOptionActivity15))));
                } else if (SharedPrefs.getWAAudioTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWAAudioSendTree(CleanOptionActivity.this).equals("")) {
                    CleanOptionActivity cleanOptionActivity16 = CleanOptionActivity.this;
                    this.txt4 = Formatter.formatShortFileSize(cleanOptionActivity16, CleanOptionActivity.folderSize(cleanOptionActivity16.getFiles(SharedPrefs.getWAAudioSendTree(cleanOptionActivity16))));
                }
                if (!SharedPrefs.getWAStickerTree(CleanOptionActivity.this).equals("")) {
                    CleanOptionActivity cleanOptionActivity17 = CleanOptionActivity.this;
                    this.txt5 = Formatter.formatShortFileSize(cleanOptionActivity17, CleanOptionActivity.folderSize(cleanOptionActivity17.getFiles(SharedPrefs.getWAStickerTree(cleanOptionActivity17))));
                }
                if (!SharedPrefs.getWAWallTree(CleanOptionActivity.this).equals("")) {
                    CleanOptionActivity cleanOptionActivity18 = CleanOptionActivity.this;
                    this.txt6 = Formatter.formatShortFileSize(cleanOptionActivity18, CleanOptionActivity.folderSize(cleanOptionActivity18.getFiles(SharedPrefs.getWAWallTree(cleanOptionActivity18))));
                }
                if (!SharedPrefs.getWAGifTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWAGifSendTree(CleanOptionActivity.this).equals("")) {
                    CleanOptionActivity cleanOptionActivity19 = CleanOptionActivity.this;
                    long folderSize5 = CleanOptionActivity.folderSize(cleanOptionActivity19.getFiles(SharedPrefs.getWAGifTree(cleanOptionActivity19)));
                    CleanOptionActivity cleanOptionActivity20 = CleanOptionActivity.this;
                    this.txt7 = Formatter.formatShortFileSize(cleanOptionActivity19, folderSize5 + CleanOptionActivity.folderSize(cleanOptionActivity20.getFiles(SharedPrefs.getWAGifSendTree(cleanOptionActivity20))));
                    return null;
                } else if (!SharedPrefs.getWAGifTree(CleanOptionActivity.this).equals("") && SharedPrefs.getWAGifSendTree(CleanOptionActivity.this).equals("")) {
                    CleanOptionActivity cleanOptionActivity21 = CleanOptionActivity.this;
                    this.txt7 = Formatter.formatShortFileSize(cleanOptionActivity21, CleanOptionActivity.folderSize(cleanOptionActivity21.getFiles(SharedPrefs.getWAGifTree(cleanOptionActivity21))));
                    return null;
                } else {
                    if (SharedPrefs.getWAGifTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWAGifSendTree(CleanOptionActivity.this).equals("")) {
                        CleanOptionActivity cleanOptionActivity22 = CleanOptionActivity.this;
                        this.txt7 = Formatter.formatShortFileSize(cleanOptionActivity22, CleanOptionActivity.folderSize(cleanOptionActivity22.getFiles(SharedPrefs.getWAGifSendTree(cleanOptionActivity22))));
                    }
                    return null;
                }
            }
            if (!SharedPrefs.getWBImgTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWBImgSendTree(CleanOptionActivity.this).equals("")) {
                CleanOptionActivity cleanOptionActivity23 = CleanOptionActivity.this;
                long folderSize6 = CleanOptionActivity.folderSize(cleanOptionActivity23.getFiles(SharedPrefs.getWBImgTree(cleanOptionActivity23)));
                CleanOptionActivity cleanOptionActivity24 = CleanOptionActivity.this;
                this.txt1 = Formatter.formatShortFileSize(cleanOptionActivity23, folderSize6 + CleanOptionActivity.folderSize(cleanOptionActivity24.getFiles(SharedPrefs.getWBImgSendTree(cleanOptionActivity24))));
            } else if (!SharedPrefs.getWBImgTree(CleanOptionActivity.this).equals("") && SharedPrefs.getWBImgSendTree(CleanOptionActivity.this).equals("")) {
                CleanOptionActivity cleanOptionActivity25 = CleanOptionActivity.this;
                this.txt1 = Formatter.formatShortFileSize(cleanOptionActivity25, CleanOptionActivity.folderSize(cleanOptionActivity25.getFiles(SharedPrefs.getWBImgTree(cleanOptionActivity25))));
            } else if (SharedPrefs.getWBImgTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWBImgSendTree(CleanOptionActivity.this).equals("")) {
                CleanOptionActivity cleanOptionActivity26 = CleanOptionActivity.this;
                this.txt1 = Formatter.formatShortFileSize(cleanOptionActivity26, CleanOptionActivity.folderSize(cleanOptionActivity26.getFiles(SharedPrefs.getWBImgSendTree(cleanOptionActivity26))));
            }
            if (!SharedPrefs.getWBVideoTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWBVideoSendTree(CleanOptionActivity.this).equals("")) {
                CleanOptionActivity cleanOptionActivity27 = CleanOptionActivity.this;
                long folderSize7 = CleanOptionActivity.folderSize(cleanOptionActivity27.getFiles(SharedPrefs.getWBVideoTree(cleanOptionActivity27)));
                CleanOptionActivity cleanOptionActivity28 = CleanOptionActivity.this;
                this.txt2 = Formatter.formatShortFileSize(cleanOptionActivity27, folderSize7 + CleanOptionActivity.folderSize(cleanOptionActivity28.getFiles(SharedPrefs.getWBVideoSendTree(cleanOptionActivity28))));
            } else if (!SharedPrefs.getWBVideoTree(CleanOptionActivity.this).equals("") && SharedPrefs.getWBVideoSendTree(CleanOptionActivity.this).equals("")) {
                CleanOptionActivity cleanOptionActivity29 = CleanOptionActivity.this;
                this.txt2 = Formatter.formatShortFileSize(cleanOptionActivity29, CleanOptionActivity.folderSize(cleanOptionActivity29.getFiles(SharedPrefs.getWBVideoTree(cleanOptionActivity29))));
            } else if (SharedPrefs.getWBVideoTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWBVideoSendTree(CleanOptionActivity.this).equals("")) {
                CleanOptionActivity cleanOptionActivity30 = CleanOptionActivity.this;
                this.txt2 = Formatter.formatShortFileSize(cleanOptionActivity30, CleanOptionActivity.folderSize(cleanOptionActivity30.getFiles(SharedPrefs.getWBVideoSendTree(cleanOptionActivity30))));
            }
            if (!SharedPrefs.getWBDocTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWBDocSendTree(CleanOptionActivity.this).equals("")) {
                CleanOptionActivity cleanOptionActivity31 = CleanOptionActivity.this;
                long folderSize8 = CleanOptionActivity.folderSize(cleanOptionActivity31.getFiles(SharedPrefs.getWBDocTree(cleanOptionActivity31)));
                CleanOptionActivity cleanOptionActivity32 = CleanOptionActivity.this;
                this.txt3 = Formatter.formatShortFileSize(cleanOptionActivity31, folderSize8 + CleanOptionActivity.folderSize(cleanOptionActivity32.getFiles(SharedPrefs.getWBDocSendTree(cleanOptionActivity32))));
            } else if (!SharedPrefs.getWBDocTree(CleanOptionActivity.this).equals("") && SharedPrefs.getWBDocSendTree(CleanOptionActivity.this).equals("")) {
                CleanOptionActivity cleanOptionActivity33 = CleanOptionActivity.this;
                this.txt3 = Formatter.formatShortFileSize(cleanOptionActivity33, CleanOptionActivity.folderSize(cleanOptionActivity33.getFiles(SharedPrefs.getWBDocTree(cleanOptionActivity33))));
            } else if (SharedPrefs.getWBDocTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWBDocSendTree(CleanOptionActivity.this).equals("")) {
                CleanOptionActivity cleanOptionActivity34 = CleanOptionActivity.this;
                this.txt3 = Formatter.formatShortFileSize(cleanOptionActivity34, CleanOptionActivity.folderSize(cleanOptionActivity34.getFiles(SharedPrefs.getWBDocSendTree(cleanOptionActivity34))));
            }
            if (!SharedPrefs.getWBAudioTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWBAudioSendTree(CleanOptionActivity.this).equals("")) {
                CleanOptionActivity cleanOptionActivity35 = CleanOptionActivity.this;
                long folderSize9 = CleanOptionActivity.folderSize(cleanOptionActivity35.getFiles(SharedPrefs.getWBAudioTree(cleanOptionActivity35)));
                CleanOptionActivity cleanOptionActivity36 = CleanOptionActivity.this;
                this.txt4 = Formatter.formatShortFileSize(cleanOptionActivity35, folderSize9 + CleanOptionActivity.folderSize(cleanOptionActivity36.getFiles(SharedPrefs.getWBAudioSendTree(cleanOptionActivity36))));
            } else if (!SharedPrefs.getWBAudioTree(CleanOptionActivity.this).equals("") && SharedPrefs.getWBAudioSendTree(CleanOptionActivity.this).equals("")) {
                CleanOptionActivity cleanOptionActivity37 = CleanOptionActivity.this;
                this.txt4 = Formatter.formatShortFileSize(cleanOptionActivity37, CleanOptionActivity.folderSize(cleanOptionActivity37.getFiles(SharedPrefs.getWBAudioTree(cleanOptionActivity37))));
            } else if (SharedPrefs.getWBAudioTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWBAudioSendTree(CleanOptionActivity.this).equals("")) {
                CleanOptionActivity cleanOptionActivity38 = CleanOptionActivity.this;
                this.txt4 = Formatter.formatShortFileSize(cleanOptionActivity38, CleanOptionActivity.folderSize(cleanOptionActivity38.getFiles(SharedPrefs.getWBAudioSendTree(cleanOptionActivity38))));
            }
            if (!SharedPrefs.getWBStickerTree(CleanOptionActivity.this).equals("")) {
                CleanOptionActivity cleanOptionActivity39 = CleanOptionActivity.this;
                this.txt5 = Formatter.formatShortFileSize(cleanOptionActivity39, CleanOptionActivity.folderSize(cleanOptionActivity39.getFiles(SharedPrefs.getWBStickerTree(cleanOptionActivity39))));
            }
            if (!SharedPrefs.getWBWallTree(CleanOptionActivity.this).equals("")) {
                CleanOptionActivity cleanOptionActivity40 = CleanOptionActivity.this;
                this.txt6 = Formatter.formatShortFileSize(cleanOptionActivity40, CleanOptionActivity.folderSize(cleanOptionActivity40.getFiles(SharedPrefs.getWBWallTree(cleanOptionActivity40))));
            }
            if (!SharedPrefs.getWBGifTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWBGifSendTree(CleanOptionActivity.this).equals("")) {
                CleanOptionActivity cleanOptionActivity41 = CleanOptionActivity.this;
                long folderSize10 = CleanOptionActivity.folderSize(cleanOptionActivity41.getFiles(SharedPrefs.getWBGifTree(cleanOptionActivity41)));
                CleanOptionActivity cleanOptionActivity42 = CleanOptionActivity.this;
                this.txt7 = Formatter.formatShortFileSize(cleanOptionActivity41, folderSize10 + CleanOptionActivity.folderSize(cleanOptionActivity42.getFiles(SharedPrefs.getWBGifSendTree(cleanOptionActivity42))));
                return null;
            } else if (!SharedPrefs.getWBGifTree(CleanOptionActivity.this).equals("") && SharedPrefs.getWBGifSendTree(CleanOptionActivity.this).equals("")) {
                CleanOptionActivity cleanOptionActivity43 = CleanOptionActivity.this;
                this.txt7 = Formatter.formatShortFileSize(cleanOptionActivity43, CleanOptionActivity.folderSize(cleanOptionActivity43.getFiles(SharedPrefs.getWBGifTree(cleanOptionActivity43))));
                return null;
            } else {
                if (SharedPrefs.getWBGifTree(CleanOptionActivity.this).equals("") && !SharedPrefs.getWBGifSendTree(CleanOptionActivity.this).equals("")) {
                    CleanOptionActivity cleanOptionActivity44 = CleanOptionActivity.this;
                    this.txt7 = Formatter.formatShortFileSize(cleanOptionActivity44, CleanOptionActivity.folderSize(cleanOptionActivity44.getFiles(SharedPrefs.getWBGifSendTree(cleanOptionActivity44))));
                }
                return null;
            }
        }

        public void onPostExecute(Void r2) {
            super.onPostExecute( r2);
            ((TextView) CleanOptionActivity.this.findViewById(R.id.txt1)).setText(this.txt1);
            ((TextView) CleanOptionActivity.this.findViewById(R.id.txt2)).setText(this.txt2);
            ((TextView) CleanOptionActivity.this.findViewById(R.id.txt3)).setText(this.txt3);
            ((TextView) CleanOptionActivity.this.findViewById(R.id.txt4)).setText(this.txt4);
            ((TextView) CleanOptionActivity.this.findViewById(R.id.txt5)).setText(this.txt5);
            ((TextView) CleanOptionActivity.this.findViewById(R.id.txt6)).setText(this.txt6);
            ((TextView) CleanOptionActivity.this.findViewById(R.id.txt7)).setText(this.txt7);
        }
    }

    public DocumentFile[] getFiles(String str) {
        DocumentFile fromTreeUri = DocumentFile.fromTreeUri(getApplicationContext(), Uri.parse(str));
        if (fromTreeUri == null || !fromTreeUri.exists() || !fromTreeUri.isDirectory() || !fromTreeUri.canRead() || !fromTreeUri.canWrite()) {
            return null;
        }
        return fromTreeUri.listFiles();
    }

    public static long folderSize(DocumentFile[] documentFileArr) {
        long j = 0;
        if (documentFileArr == null) {
            return 0L;
        }
        long j2 = 0;
        for (DocumentFile documentFile : documentFileArr) {
            if (documentFile.isFile()) {
                j2 = documentFile.length();
            }
            j += j2;
        }
        return j;
    }

    public void onTapBtn(String str, String str2, String str3) {
        if (Utils.appInstalledOrNot(this, WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME)) {
            onTTap(str, str2, str3);
        } else {
            Toast.makeText(this, "Please Install WhatsApp For Download Status!!!!!", 0).show();
        }
    }

    public void onTTap(String str, String str2, String str3) {
        final Intent intent = new Intent(this, CleanDataActivity.class);
        intent.putExtra("category", str);
        intent.putExtra("receivePath", str2);
        intent.putExtra("sentPath", str3);
//        AppManage.getInstance(this.activity).showInterstitialAd(this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.newwautl.CleanOptionActivity.10
//            @Override // com.pesonal.adsdk.MyCallback
//            public void callbackCall() {
                CleanOptionActivity.this.startActivity(intent);
//            }
//        }, AppManage.app_mainClickCntSwAd);
    }

    @SuppressLint("WrongConstant")
    public void onTapOther(String str, String str2) {
        if (Utils.iswApp) {
            if (Utils.appInstalledOrNot(this, WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME)) {
                oTOther(str, str2);
            } else {
                Toast.makeText(this, "Please Install WhatsApp For Download Status!!!!!", 0).show();
            }
        }
    }

    public void oTOther(String str, String str2) {
        final Intent intent = new Intent(this, WallCleanerActivity.class);
        intent.putExtra("category", str);
        intent.putExtra("folderPath", str2);
//        AppManage.getInstance(this.activity).showInterstitialAd(this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.newwautl.CleanOptionActivity.11
//            @Override // com.pesonal.adsdk.MyCallback
//            public void callbackCall() {
                CleanOptionActivity.this.startActivity(intent);
//            }
//        }, AppManage.app_mainClickCntSwAd);
    }

    public String getWhatsupFolder(String str) {
        if (new File(Environment.getExternalStorageDirectory() + File.separator + "Android/media/com.whatsapp/WhatsApp" + File.separator + "Media").isDirectory()) {
            return "Android%2Fmedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F" + str;
        }
        return "WhatsApp%2FMedia%2F" + str;
    }
}
