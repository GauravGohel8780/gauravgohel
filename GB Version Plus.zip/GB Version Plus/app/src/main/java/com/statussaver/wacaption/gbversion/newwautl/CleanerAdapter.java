package com.statussaver.wacaption.gbversion.newwautl;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.text.format.Formatter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.statussaver.wacaption.gbversion.R;
import java.util.List;

public class CleanerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Activity activity;
    String category;
    List<CleanerFileModel> mData;
    public OnCheckboxListener onCheckboxListener;
    int audios = 3;
    int document = 4;
    int gif = 5;
    int images = 1;
    int videos = 2;
    int voice = 6;

    public interface OnCheckboxListener {
        void onCheckboxListener(View view, List<CleanerFileModel> list);
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public CheckBox checkBox;
        public ImageView imagevi;

        public ViewHolder(View view) {
            super(view);
            ImageView imageView = (ImageView) view.findViewById(R.id.imageView);
            this.imagevi = imageView;
            imageView.setOnClickListener(this);
            this.checkBox = (CheckBox) view.findViewById(R.id.checkbox);
        }

        @Override
        public void onClick(View view) {
            Intent intent = new Intent();
            intent.setAction("android.intent.action.VIEW");
            intent.setDataAndType(Uri.parse(CleanerAdapter.this.mData.get(getAdapterPosition()).getFilePath()), "image/*");
            intent.addFlags(1);
            try {
                CleanerAdapter.this.activity.startActivity(intent);
            } catch (ActivityNotFoundException unused) {
                Toast.makeText(CleanerAdapter.this.activity, "No Apps in your device for view this type of file.", 1).show();
            }
        }
    }

    public class ViewHolderAudios extends RecyclerView.ViewHolder implements View.OnClickListener {
        public CheckBox checkBox;
        public ImageView imageView;
        public TextView name;
        public TextView size;

        public ViewHolderAudios(View view) {
            super(view);
            this.name = (TextView) view.findViewById(R.id.name);
            this.size = (TextView) view.findViewById(R.id.size);
            this.checkBox = (CheckBox) view.findViewById(R.id.checkbox);
            ImageView imageView = (ImageView) view.findViewById(R.id.imageView);
            this.imageView = imageView;
            imageView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            Intent intent = new Intent();
            intent.setAction("android.intent.action.VIEW");
            intent.setDataAndType(Uri.parse(CleanerAdapter.this.mData.get(getAdapterPosition()).getFilePath()), "audio/*");
            intent.addFlags(1);
            try {
                CleanerAdapter.this.activity.startActivity(intent);
            } catch (ActivityNotFoundException unused) {
                Toast.makeText(CleanerAdapter.this.activity, "No Apps in your device for view this type of file.", 1).show();
            }
        }
    }

    public class ViewHolderDocs extends RecyclerView.ViewHolder implements View.OnClickListener {
        public CheckBox checkBox;
        private ImageView imageView;
        public TextView name;
        public TextView size;

        public ViewHolderDocs(View view) {
            super(view);
            this.name = (TextView) view.findViewById(R.id.name);
            this.size = (TextView) view.findViewById(R.id.size);
            this.checkBox = (CheckBox) view.findViewById(R.id.checkbox);
            ImageView imageView = (ImageView) view.findViewById(R.id.imageView);
            this.imageView = imageView;
            imageView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            CleanerAdapter cleanerAdapter = CleanerAdapter.this;
            cleanerAdapter.viewIntent(cleanerAdapter.activity, CleanerAdapter.this.mData.get(getAdapterPosition()).getFilePath());
        }
    }

    public class ViewHolderVideos extends RecyclerView.ViewHolder implements View.OnClickListener {

        public CheckBox checkBox;
        public ImageView imagevi;

        public ViewHolderVideos(View view) {
            super(view);
            ImageView imageView = (ImageView) view.findViewById(R.id.imageView);
            this.imagevi = imageView;
            imageView.setOnClickListener(this);
            this.checkBox = (CheckBox) view.findViewById(R.id.checkbox);
        }

        @Override
        public void onClick(View view) {
            Intent intent = new Intent();
            intent.setAction("android.intent.action.VIEW");
            intent.setDataAndType(Uri.parse(CleanerAdapter.this.mData.get(getAdapterPosition()).getFilePath()), "video/*");
            intent.addFlags(1);
            try {
                CleanerAdapter.this.activity.startActivity(intent);
            } catch (ActivityNotFoundException unused) {
                Toast.makeText(CleanerAdapter.this.activity, "No Apps in your device for view this type of file.", 1).show();
            }
        }
    }

    public CleanerAdapter(FragmentActivity fragmentActivity, List<CleanerFileModel> list, String str, OnCheckboxListener onCheckboxListener) {
        this.mData = list;
        this.activity = fragmentActivity;
        this.category = str;
        this.onCheckboxListener = onCheckboxListener;
    }

    @Override
    public int getItemViewType(int i) {
        String str = this.category;
        int hashCode = str.hashCode();
        char c = '\uffff';
        switch (hashCode) {
            case -892481550:
                if (str.equals("status")) {
                    c = 4;
                    break;
                }
                break;
            case 102340:
                if (str.equals(Utils.GIF)) {
                    c = 5;
                    break;
                }
                break;
            case 93166550:
                if (str.equals(Utils.AUDIO)) {
                    c = 3;
                    break;
                }
                break;
            case 100313435:
                if (str.equals(Utils.IMAGE)) {
                    c = 1;
                    break;
                }
                break;
            case 112202875:
                if (str.equals(Utils.VIDEO)) {
                    c = 2;
                    break;
                }
                break;
            case 861720859:
                if (str.equals(Utils.DOCUMENT)) {
                    c = 6;
                    break;
                }
                break;
        }
        if (c == 2) {
            return this.videos;
        }
        if (c == 3) {
            return this.audios;
        }
        if (c == 4) {
            return this.voice;
        }
        if (c == 5) {
            return this.gif;
        }
        if (c != 6) {
            return this.images;
        }
        return this.document;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        if (i == 1) {
            return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cleaner_item, viewGroup, false));
        }
        if (i == 2 || i == 5) {
            return new ViewHolderVideos(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cleaner_video_item, viewGroup, false));
        }
        if (i == 4) {
            return new ViewHolderDocs(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cleaner_doc_item, viewGroup, false));
        }
        return new ViewHolderAudios(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cleaner_audio_item, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, @SuppressLint("RecyclerView") final int i) {
        CleanerFileModel cleanerFileModel = this.mData.get(i);
        if (getItemViewType(i) == 1) {
            ViewHolder viewHolder2 = (ViewHolder) viewHolder;
            Glide.with(this.activity).load(cleanerFileModel.getFilePath()).into(viewHolder2.imagevi);
            viewHolder2.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    CleanerAdapter.this.mData.get(i).setSelected(z);
                    if (CleanerAdapter.this.onCheckboxListener != null) {
                        CleanerAdapter.this.onCheckboxListener.onCheckboxListener(compoundButton, CleanerAdapter.this.mData);
                    }
                }
            });
            if (cleanerFileModel.isSelected()) {
                viewHolder2.checkBox.setChecked(true);
            } else {
                viewHolder2.checkBox.setChecked(false);
            }
        } else if (getItemViewType(i) == 2 || getItemViewType(i) == 5) {
            ViewHolderVideos viewHolderVideos = (ViewHolderVideos) viewHolder;
            Glide.with(this.activity).load(cleanerFileModel.getFilePath()).into(viewHolderVideos.imagevi);
            viewHolderVideos.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    CleanerAdapter.this.mData.get(i).setSelected(z);
                    if (CleanerAdapter.this.onCheckboxListener != null) {
                        CleanerAdapter.this.onCheckboxListener.onCheckboxListener(compoundButton, CleanerAdapter.this.mData);
                    }
                }
            });
            if (cleanerFileModel.isSelected()) {
                viewHolderVideos.checkBox.setChecked(true);
            } else {
                viewHolderVideos.checkBox.setChecked(false);
            }
        } else if (getItemViewType(i) == 4) {
            ViewHolderDocs viewHolderDocs = (ViewHolderDocs) viewHolder;
            viewHolderDocs.name.setText(cleanerFileModel.getFileName());
            viewHolderDocs.size.setText(Formatter.formatShortFileSize(this.activity, Long.parseLong(cleanerFileModel.getSize())));
            viewHolderDocs.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    CleanerAdapter.this.mData.get(i).setSelected(z);
                    if (CleanerAdapter.this.onCheckboxListener != null) {
                        CleanerAdapter.this.onCheckboxListener.onCheckboxListener(compoundButton, CleanerAdapter.this.mData);
                    }
                }
            });
            if (cleanerFileModel.isSelected()) {
                viewHolderDocs.checkBox.setChecked(true);
            } else {
                viewHolderDocs.checkBox.setChecked(false);
            }
        } else if (getItemViewType(i) != 3 && getItemViewType(i) != 6) {
        } else {
            ViewHolderAudios viewHolderAudios = (ViewHolderAudios) viewHolder;
            if (getItemViewType(i) == 3) {
                viewHolderAudios.imageView.setImageResource(R.drawable.audio);
            } else {
                viewHolderAudios.imageView.setImageResource(R.drawable.voice);
            }
            viewHolderAudios.name.setText(cleanerFileModel.getFileName());
            viewHolderAudios.size.setText(Formatter.formatShortFileSize(this.activity, Long.parseLong(cleanerFileModel.getSize())));
            viewHolderAudios.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    CleanerAdapter.this.mData.get(i).setSelected(z);
                    if (CleanerAdapter.this.onCheckboxListener != null) {
                        CleanerAdapter.this.onCheckboxListener.onCheckboxListener(compoundButton, CleanerAdapter.this.mData);
                    }
                }
            });
            if (cleanerFileModel.isSelected()) {
                viewHolderAudios.checkBox.setChecked(true);
            } else {
                viewHolderAudios.checkBox.setChecked(false);
            }
        }
    }

    @Override
    public int getItemCount() {
        return this.mData.size();
    }

    @SuppressLint("WrongConstant")
    public void viewIntent(Activity activity, String str) {
        String fileExt = fileExt(str);
        if (fileExt != null) {
            MimeTypeMap singleton = MimeTypeMap.getSingleton();
            Intent intent = new Intent("android.intent.action.VIEW");
            Uri parse = Uri.parse(str);
            Log.e("viewIntent: ", str + "======" + fileExt);
            intent.setDataAndType(parse, singleton.getMimeTypeFromExtension(fileExt.substring(1)));
            intent.addFlags(1);
            intent.setFlags(268435456);
            try {
                activity.startActivity(intent);
            } catch (ActivityNotFoundException unused) {
                Toast.makeText(activity, "No Apps in your device for view this type of file.", 1).show();
            }
        }
    }

    private String fileExt(String str) {
        if (str.indexOf("?") > -1) {
            str = str.substring(0, str.indexOf("?"));
        }
        if (str.lastIndexOf(".") == -1) {
            return null;
        }
        String substring = str.substring(str.lastIndexOf(".") + 1);
        if (substring.indexOf("%") > -1) {
            substring = substring.substring(0, substring.indexOf("%"));
        }
        if (substring.indexOf("/") > -1) {
            substring = substring.substring(0, substring.indexOf("/"));
        }
        return substring.toLowerCase();
    }
}
