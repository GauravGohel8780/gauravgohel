package com.statussaver.wacaption.gbversion.Emoction;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.statussaver.wacaption.gbversion.R;

public class GBWhats_CatEmotionActivity extends AppCompatActivity {

    public GridView f179h;
    public int[] f180i = {R.drawable.csf_love, R.drawable.csf_happy, R.drawable.csf_music, R.drawable.csf_animal, R.drawable.csf_angry, R.drawable.csf_sad, R.drawable.csf_splee, R.drawable.csf_excited, R.drawable.csf_hungry, R.drawable.csf_shy, R.drawable.csf_other, R.drawable.csf_kiss, R.drawable.csf_smile, R.drawable.csf_laugh};
    public String[] f181j = {"Love", "Happy", "Music", "Animals", "Angry", "Sad", "Sleeping", "Excited", "Hungry", "Shy", "Other", "Kiss", "Smile", "Laugh"};

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.gbwhats_activity_cat_emotion);
        getWindow().setFlags(1024, 1024);
        ((TextView) findViewById(R.id.tx_nm)).setText("Emotion");
        GridView gridView = (GridView) findViewById(R.id.csf_grid);
        this.f179h = gridView;
        gridView.setAdapter((ListAdapter) new GBWhats_TxtemotincustAdepter(this, this.f181j, this.f180i));
        ((ImageView) findViewById(R.id.back)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GBWhats_CatEmotionActivity.this.onBackPressed();
            }
        });
    }

    @Override
    public void onBackPressed() {
        GBWhats_CatEmotionActivity.this.finish();
    }
}
