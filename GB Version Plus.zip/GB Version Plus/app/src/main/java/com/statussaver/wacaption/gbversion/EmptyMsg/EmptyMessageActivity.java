package com.statussaver.wacaption.gbversion.EmptyMsg;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.statussaver.wacaption.gbversion.Emoction.GBWhats_CopyHan;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.StatusSaver.util.WhitelistCheck;

public class EmptyMessageActivity extends AppCompatActivity {
    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_empty_message);
        findViewById(R.id.send_emptymsg_btn).setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View view) {
                Intent launchIntentForPackage = EmptyMessageActivity.this.getPackageManager().getLaunchIntentForPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                int i = Build.VERSION.SDK_INT;
                if (launchIntentForPackage != null) {
                    Intent intent = new Intent("android.intent.action.SEND");
                    intent.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent.putExtra("android.intent.extra.TEXT", "\u200f\u200f");
                    intent.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    intent.putExtra("jid", "@s.whatsapp.net");
                    EmptyMessageActivity.this.startActivity(intent);
                } else if (i >= 30) {
                    Intent intent2 = new Intent("android.intent.action.SEND");
                    intent2.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent2.putExtra("android.intent.extra.TEXT", "\u200f\u200f");
                    intent2.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    intent2.putExtra("jid", "@s.whatsapp.net");
                    try {
                        EmptyMessageActivity.this.startActivity(intent2);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(EmptyMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                    }
                } else {
                    Toast.makeText(EmptyMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                }
            }
        });
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EmptyMessageActivity.super.onBackPressed();
            }
        });
    }

    @Override
    public void onBackPressed() {
        EmptyMessageActivity.this.finish();
    }
}
