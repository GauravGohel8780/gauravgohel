package com.statussaver.wacaption.gbversion.DirectMessage;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.statussaver.wacaption.gbversion.Emoction.GBWhats_CopyHan;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.StatusSaver.util.WhitelistCheck;

public class DirectMessageActivity extends AppCompatActivity {

    public ClipData myClip;

    public ClipboardManager myClipboard;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_direct_message);
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity.this.finish();
            }
        });
        findViewById(R.id.l1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", "Hi, How are you?");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.l2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", "Good Morning");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.l3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", "Good Night");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.l4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", "Whare are you?");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.l5).setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", "When will you rech?");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.l6).setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", "I have reached home.");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.l7).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", "Where are going?");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.l8).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", " have you had dinner?");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.l9).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", "how's your day?");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.l10).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", "Where will we meet?");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.c1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", "Hi, How are you?");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.c2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", "Good Morning");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.c3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", "Good Night");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.c4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", "Whare are you?");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.c5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", "When will you rech?");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.c6).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", "I have reached home.");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.c7).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", "Where are going?");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.c8).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", " have you had dinner?");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.c9).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", "how's your day?");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.c10).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity directMessageActivity = DirectMessageActivity.this;
                directMessageActivity.myClipboard = (ClipboardManager) directMessageActivity.getSystemService("clipboard");
                DirectMessageActivity.this.myClip = ClipData.newPlainText("text", "Where will we meet?");
                DirectMessageActivity.this.myClipboard.setPrimaryClip(DirectMessageActivity.this.myClip);
                Toast.makeText(DirectMessageActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        findViewById(R.id.s1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = Build.VERSION.SDK_INT;
                if (DirectMessageActivity.this.getPackageManager().getLaunchIntentForPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME) != null) {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.TEXT", "Hi, How are you?");
                    intent.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    DirectMessageActivity.this.startActivity(intent);
                } else if (i >= 30) {
                    Intent intent2 = new Intent();
                    intent2.setAction("android.intent.action.SEND");
                    intent2.putExtra("android.intent.extra.TEXT", "Hi, How are you?");
                    intent2.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent2.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    try {
                        DirectMessageActivity.this.startActivity(intent2);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                    }
                } else {
                    Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                }
            }
        });
        findViewById(R.id.s2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = Build.VERSION.SDK_INT;
                if (DirectMessageActivity.this.getPackageManager().getLaunchIntentForPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME) != null) {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.TEXT", "Good Morning");
                    intent.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    DirectMessageActivity.this.startActivity(intent);
                } else if (i >= 30) {
                    Intent intent2 = new Intent();
                    intent2.setAction("android.intent.action.SEND");
                    intent2.putExtra("android.intent.extra.TEXT", "Good Morning");
                    intent2.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent2.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    try {
                        DirectMessageActivity.this.startActivity(intent2);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                    }
                } else {
                    Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                }
            }
        });
        findViewById(R.id.s3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = Build.VERSION.SDK_INT;
                if (DirectMessageActivity.this.getPackageManager().getLaunchIntentForPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME) != null) {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.TEXT", "Good Night");
                    intent.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    DirectMessageActivity.this.startActivity(intent);
                } else if (i >= 30) {
                    Intent intent2 = new Intent();
                    intent2.setAction("android.intent.action.SEND");
                    intent2.putExtra("android.intent.extra.TEXT", "Good Night");
                    intent2.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent2.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    try {
                        DirectMessageActivity.this.startActivity(intent2);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                    }
                } else {
                    Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                }
            }
        });
        findViewById(R.id.s4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = Build.VERSION.SDK_INT;
                if (DirectMessageActivity.this.getPackageManager().getLaunchIntentForPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME) != null) {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.TEXT", "Whare are you?");
                    intent.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    DirectMessageActivity.this.startActivity(intent);
                } else if (i >= 30) {
                    Intent intent2 = new Intent();
                    intent2.setAction("android.intent.action.SEND");
                    intent2.putExtra("android.intent.extra.TEXT", "Whare are you?");
                    intent2.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent2.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    try {
                        DirectMessageActivity.this.startActivity(intent2);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                    }
                } else {
                    Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                }
            }
        });
        findViewById(R.id.s5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = Build.VERSION.SDK_INT;
                if (DirectMessageActivity.this.getPackageManager().getLaunchIntentForPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME) != null) {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.TEXT", "When will you rech?");
                    intent.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    DirectMessageActivity.this.startActivity(intent);
                } else if (i >= 30) {
                    Intent intent2 = new Intent();
                    intent2.setAction("android.intent.action.SEND");
                    intent2.putExtra("android.intent.extra.TEXT", "When will you rech?");
                    intent2.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent2.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    try {
                        DirectMessageActivity.this.startActivity(intent2);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                    }
                } else {
                    Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                }
            }
        });
        findViewById(R.id.s6).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = Build.VERSION.SDK_INT;
                if (DirectMessageActivity.this.getPackageManager().getLaunchIntentForPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME) != null) {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.TEXT", "I have reached home.");
                    intent.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    DirectMessageActivity.this.startActivity(intent);
                } else if (i >= 30) {
                    Intent intent2 = new Intent();
                    intent2.setAction("android.intent.action.SEND");
                    intent2.putExtra("android.intent.extra.TEXT", "I have reached home.");
                    intent2.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent2.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    try {
                        DirectMessageActivity.this.startActivity(intent2);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                    }
                } else {
                    Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                }
            }
        });
        findViewById(R.id.s7).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = Build.VERSION.SDK_INT;
                if (DirectMessageActivity.this.getPackageManager().getLaunchIntentForPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME) != null) {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.TEXT", "Where are going?");
                    intent.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    DirectMessageActivity.this.startActivity(intent);
                } else if (i >= 30) {
                    Intent intent2 = new Intent();
                    intent2.setAction("android.intent.action.SEND");
                    intent2.putExtra("android.intent.extra.TEXT", "Where are going?");
                    intent2.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent2.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    try {
                        DirectMessageActivity.this.startActivity(intent2);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                    }
                } else {
                    Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                }
            }
        });
        findViewById(R.id.s8).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = Build.VERSION.SDK_INT;
                if (DirectMessageActivity.this.getPackageManager().getLaunchIntentForPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME) != null) {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.TEXT", "have you had dinner?");
                    intent.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    DirectMessageActivity.this.startActivity(intent);
                } else if (i >= 30) {
                    Intent intent2 = new Intent();
                    intent2.setAction("android.intent.action.SEND");
                    intent2.putExtra("android.intent.extra.TEXT", "have you had dinner?");
                    intent2.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent2.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    try {
                        DirectMessageActivity.this.startActivity(intent2);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                    }
                } else {
                    Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                }
            }
        });
        findViewById(R.id.s9).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = Build.VERSION.SDK_INT;
                if (DirectMessageActivity.this.getPackageManager().getLaunchIntentForPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME) != null) {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.TEXT", "how's your day?");
                    intent.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    DirectMessageActivity.this.startActivity(intent);
                } else if (i >= 30) {
                    Intent intent2 = new Intent();
                    intent2.setAction("android.intent.action.SEND");
                    intent2.putExtra("android.intent.extra.TEXT", "how's your day?");
                    intent2.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent2.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    try {
                        DirectMessageActivity.this.startActivity(intent2);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                    }
                } else {
                    Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                }
            }
        });
        findViewById(R.id.s10).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = Build.VERSION.SDK_INT;
                if (DirectMessageActivity.this.getPackageManager().getLaunchIntentForPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME) != null) {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.TEXT", "Where will we meet?");
                    intent.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    DirectMessageActivity.this.startActivity(intent);
                } else if (i >= 30) {
                    Intent intent2 = new Intent();
                    intent2.setAction("android.intent.action.SEND");
                    intent2.putExtra("android.intent.extra.TEXT", "Where will we meet?");
                    intent2.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent2.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    try {
                        DirectMessageActivity.this.startActivity(intent2);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                    }
                } else {
                    Toast.makeText(DirectMessageActivity.this, "Whatsapp doesn't installed", 0).show();
                }
            }
        });
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectMessageActivity.this.onBackPressed();
            }
        });
    }

    @Override
    public void onBackPressed() {
        DirectMessageActivity.this.finish();
    }

}
