package com.statussaver.wacaption.gbversion.WAUtil;

import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.WAUtil.adpter.AudioAdpter;
import com.statussaver.wacaption.gbversion.WAUtil.adpter.GbVersonAdpter;
import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes3.dex */
public class VoiceNoteActivity extends AppCompatActivity {
    AudioAdpter audioAdps;
    File backup;
    private File file4;
    TextView filet;
    ImageView imgBack;
    File profile;
    RecyclerView recylerView;
    TextView size;
    long sizeBackup = 0;
    long sizePro = 0;
    long sizeVoice = 0;
    long sizeWall = 0;
    TextView txtTitle;
    File voice;
    File wallpaper;
    GbVersonAdpter yoWhatsAdps;

    public static String getReadableSize(long j) {
        if (j <= 0) {
            return "0";
        }
        double d = j;
        int log10 = (int) (Math.log10(d) / Math.log10(1024.0d));
        StringBuilder sb = new StringBuilder();
        DecimalFormat decimalFormat = new DecimalFormat("#,##0.#");
        double pow = Math.pow(1024.0d, log10);
        Double.isNaN(d);
        Double.isNaN(d);
        Double.isNaN(d);
        sb.append(decimalFormat.format(d / pow));
        sb.append(" ");
        sb.append(new String[]{"B", "KB", "MB", "GB", "TB"}[log10]);
        return sb.toString();
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_voice_note);
        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "/WhatsApp");
        File file2 = new File(file.getAbsolutePath(), "/Media/WhatsApp Voice Notes");
        this.voice = file2;
        file2.listFiles();
        ArrayList arrayList = new ArrayList();
        populate(this.voice.getAbsolutePath(), arrayList);
        this.recylerView = (RecyclerView) findViewById(R.id.recylerView);
        this.filet = (TextView) findViewById(R.id.file);
        this.size = (TextView) findViewById(R.id.size);
        this.txtTitle = (TextView) findViewById(R.id.txtTitle);
        this.imgBack = (ImageView) findViewById(R.id.imgBack);
        this.txtTitle.setText(getIntent().getStringExtra("active"));
        this.imgBack.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.VoiceNoteActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                VoiceNoteActivity.this.onBackPressed();
            }
        });
        File file3 = new File(file.getAbsolutePath(), "/Databases");
        this.backup = file3;
        File[] listFiles = file3.listFiles();
        ArrayList arrayList2 = new ArrayList();
        if (listFiles != null) {
            for (int i = 0; i < listFiles.length; i++) {
                if (listFiles[i].getPath().endsWith(".db.crypt12")) {
                    arrayList2.add(listFiles[i].getPath());
                    this.sizeBackup += listFiles[i].length();
                }
            }
        }
        if (Build.VERSION.SDK_INT >= 30) {
            this.file4 = new File("Android/media/com.whatsapp/WhatsApp/Media/WallPaper");
        } else {
            this.file4 = new File(file.getAbsolutePath(), "/Media/WallPaper");
        }
        File file4 = this.file4;
        this.wallpaper = file4;
        File[] listFiles2 = file4.listFiles();
        ArrayList arrayList3 = new ArrayList();
        if (listFiles2 != null) {
            for (int i2 = 0; i2 < listFiles2.length; i2++) {
                if (listFiles2[i2].getPath().endsWith(".jpg") || listFiles2[i2].getPath().endsWith(".png") || listFiles2[i2].getPath().endsWith(".jpeg")) {
                    arrayList3.add(listFiles2[i2].getPath());
                    this.sizeWall += listFiles2[i2].length();
                }
            }
        }
        File file5 = new File(file.getAbsolutePath(), "/Media/WhatsApp Profile Photos");
        this.profile = file5;
        File[] listFiles3 = file5.listFiles();
        ArrayList arrayList4 = new ArrayList();
        if (listFiles3 != null) {
            for (int i3 = 0; i3 < listFiles3.length; i3++) {
                if (listFiles3[i3].getPath().endsWith(".jpg") || listFiles3[i3].getPath().endsWith(".png") || listFiles3[i3].getPath().endsWith(".jpeg")) {
                    arrayList4.add(listFiles3[i3].getPath());
                    this.sizePro += listFiles3[i3].length();
                }
            }
        }
        if (getIntent().getStringExtra("id").equals("6")) {
            this.recylerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 1));
            AudioAdpter audioAdpter = new AudioAdpter(getApplicationContext(), arrayList, "103");
            this.audioAdps = audioAdpter;
            this.recylerView.setAdapter(audioAdpter);
            this.audioAdps.notifyDataSetChanged();
            this.filet.setText(arrayList.size() + " Files");
            this.size.setText("Size: " + getReadableSize(this.sizeVoice));
        } else if (getIntent().getStringExtra("id").equals("8")) {
            this.recylerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 1));
            AudioAdpter audioAdpter2 = new AudioAdpter(getApplicationContext(), arrayList2, "102");
            this.audioAdps = audioAdpter2;
            this.recylerView.setAdapter(audioAdpter2);
            this.audioAdps.notifyDataSetChanged();
            this.filet.setText(arrayList2.size() + " Files");
            this.size.setText("Size: " + getReadableSize(this.sizeBackup));
        } else if (getIntent().getStringExtra("id").equals("7")) {
            this.recylerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));
            this.yoWhatsAdps = new GbVersonAdpter(getApplicationContext(), arrayList3, "7", "WallPapers");
            this.recylerView.setAdapter(this.audioAdps);
            this.yoWhatsAdps.notifyDataSetChanged();
            this.filet.setText(arrayList3.size() + " Files");
            this.size.setText("Size: " + getReadableSize(this.sizeWall));
        } else if (getIntent().getStringExtra("id").equals("4")) {
            this.recylerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));
            this.yoWhatsAdps = new GbVersonAdpter(getApplicationContext(), arrayList4, "4", "Profiles");
            this.recylerView.setAdapter(this.audioAdps);
            this.yoWhatsAdps.notifyDataSetChanged();
            this.filet.setText(arrayList3.size() + " Files");
            this.size.setText("Size: " + getReadableSize(this.sizePro));
        }
    }

    public void populate(String str, List<String> list) {
        File[] listFiles;
        try {
            for (File file : new File(str).listFiles()) {
                if (file.isFile()) {
                    if (!file.getName().equalsIgnoreCase(".nomedia")) {
                        list.add(file.getPath());
                        this.sizeVoice += file.length();
                    }
                } else if (file.isDirectory()) {
                    populate(file.getAbsolutePath(), list);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
//        AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.WAUtil.VoiceNoteActivity.2
//            @Override // com.pesonal.adsdk.MyCallback
//            public void callbackCall() {
                VoiceNoteActivity.this.finish();
//            }
//        }, AppManage.app_mainClickCntSwAd);
    }
}
