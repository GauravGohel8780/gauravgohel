package com.statussaver.wacaption.gbversion.FakeStory;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.PointerIconCompat;

import com.statussaver.wacaption.gbversion.R;

import de.hdodenhof.circleimageview.CircleImageView;

import java.util.Calendar;

public class GBWhats_FakestoryActivity extends AppCompatActivity {

    public LinearLayout clean_lay;
    public TextView dpcap;
    public TextView editName;
    public TextView editTime;
    public Bitmap f11841o;
    public float f11842p = 150.0f;
    public ImageView f188dp;
    public ImageView f189h;
    public RelativeLayout fakeShow;
    public ImageView img_selectstory;
    public TextView inputName;
    public ImageView inputPic;
    public TextView inputTime;
    private TimePickerDialog mTimePicker;
    public CircleImageView setProfile;
    public TextView typecap;

    public class C1623f implements Runnable {
        public C1623f() {
        }

        @Override
        public void run() {
            GBWhats_FakestoryActivity.this.clean_lay.setVisibility(8);
            GBWhats_FakestoryActivity.this.fakeShow.setVisibility(0);
            GBWhats_FakestoryActivity.this.getWindow().setFlags(1024, 1024);
            GBWhats_FakestoryActivity.this.getWindow().setNavigationBarColor(GBWhats_FakestoryActivity.this.getResources().getColor(R.color.black));
            if (GBWhats_FakestoryActivity.this.editName.getText().toString().equals("")) {
                GBWhats_FakestoryActivity.this.inputName.setText(GBWhats_FakestoryActivity.this.getString(R.string.app_name));
            } else {
                GBWhats_FakestoryActivity gBWhats_FakestoryActivity = GBWhats_FakestoryActivity.this;
                gBWhats_FakestoryActivity.inputName.setText(gBWhats_FakestoryActivity.editName.getText().toString());
            }
            if (GBWhats_FakestoryActivity.this.editTime.getText().toString().equals("")) {
                GBWhats_FakestoryActivity.this.inputTime.setText("2 minutes ago");
            } else {
                GBWhats_FakestoryActivity gBWhats_FakestoryActivity2 = GBWhats_FakestoryActivity.this;
                gBWhats_FakestoryActivity2.inputTime.setText(gBWhats_FakestoryActivity2.editTime.getText().toString());
            }
            GBWhats_FakestoryActivity gBWhats_FakestoryActivity3 = GBWhats_FakestoryActivity.this;
            gBWhats_FakestoryActivity3.dpcap.setText(gBWhats_FakestoryActivity3.typecap.getText().toString());
        }
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        Uri data;
        super.onActivityResult(i, i2, intent);
        if (i == 1000 && i2 == -1) {
            Uri data2 = intent.getData();
            if (data2 == null) {
                return;
            }
            this.img_selectstory.setImageURI(data2);
            this.inputPic.setImageURI(data2);
        } else if (i != 1001 || i2 != -1 || (data = intent.getData()) == null) {
        } else {
            this.setProfile.setImageURI(data);
            this.f188dp.setImageURI(data);
        }
    }

    @Override
    public void onBackPressed() {
        if (this.clean_lay.getVisibility() == 0) {
            return;
        }
        if (this.fakeShow.getVisibility() == 0) {
            this.fakeShow.setVisibility(8);
            this.clean_lay.setVisibility(8);
            mo29469w();
            mo29468v();
            return;
        }
        GBWhats_FakestoryActivity.this.finish();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.gbwhats_activity_fakestory);
        getWindow().setFlags(1024, 1024);
        ((TextView) findViewById(R.id.tx_nm)).setText("Fake Story");
        this.f189h = (ImageView) findViewById(R.id.back);
        this.editName = (TextView) findViewById(R.id.editName);
        this.inputName = (TextView) findViewById(R.id.inputName);
        this.typecap = (TextView) findViewById(R.id.typecap);
        this.dpcap = (TextView) findViewById(R.id.dpcap);
        this.editTime = (TextView) findViewById(R.id.editTime);
        this.inputTime = (TextView) findViewById(R.id.inputTime);
        this.fakeShow = (RelativeLayout) findViewById(R.id.fakeShow);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.clean_lay);
        this.clean_lay = linearLayout;
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });
        this.setProfile = (CircleImageView) findViewById(R.id.setProfile);
        this.f188dp = (ImageView) findViewById(R.id.dp);
        this.img_selectstory = (ImageView) findViewById(R.id.img_selectstory);
        this.inputPic = (ImageView) findViewById(R.id.inputPic);
        Bitmap decodeResource = BitmapFactory.decodeResource(getResources(), R.drawable.select_img);
        this.f11841o = decodeResource;
        this.img_selectstory.setImageBitmap(decodeResource);
        ((ImageView) findViewById(R.id.reedit)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GBWhats_FakestoryActivity.this.fakeShow.setVisibility(8);
                GBWhats_FakestoryActivity.this.clean_lay.setVisibility(8);
                GBWhats_FakestoryActivity.this.mo29469w();
                GBWhats_FakestoryActivity.this.mo29468v();
            }
        });
        ((ImageView) findViewById(R.id.selectProfile)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GBWhats_FakestoryActivity.this.startActivityForResult(Intent.createChooser(new Intent().setAction("android.intent.action.PICK").setType("image/*"), "Selecting Image"), PointerIconCompat.TYPE_CONTEXT_MENU);
            }
        });
        this.img_selectstory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GBWhats_FakestoryActivity.this.startActivityForResult(Intent.createChooser(new Intent().setAction("android.intent.action.PICK").setType("image/*"), "Selecting Image"), 1000);
            }
        });
        this.f189h.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GBWhats_FakestoryActivity.this.onBackPressed();
            }
        });
        this.editTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                int i = calendar.get(11);
                int i2 = calendar.get(12);
                GBWhats_FakestoryActivity.this.mTimePicker = new TimePickerDialog(GBWhats_FakestoryActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int i3, int i4) {
                        TextView textView = GBWhats_FakestoryActivity.this.editTime;
                        textView.setText(i3 + ":" + i4);
                    }
                }, i, i2, true);
                GBWhats_FakestoryActivity.this.mTimePicker.setTitle("Select Time");
                GBWhats_FakestoryActivity.this.mTimePicker.show();
            }
        });
        ((ImageView) findViewById(R.id.btn_done)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (GBWhats_FakestoryActivity.this.editName.getText().toString().isEmpty()) {
                    GBWhats_FakestoryActivity.this.editName.setError("Name should not be blank");
                } else if (GBWhats_FakestoryActivity.this.editTime.getText().toString().isEmpty()) {
                    GBWhats_FakestoryActivity.this.editTime.setError("LastSeen should not be blank");
                } else if (GBWhats_FakestoryActivity.this.typecap.getText().toString().isEmpty()) {
                    GBWhats_FakestoryActivity.this.typecap.setError("Caption should not be blank");
                } else {
                    new Handler().postDelayed(new C1623f(), 500L);
                }
            }
        });
    }

    public void mo29468v() {
        getWindow().setFlags(2048, 2048);
        Bitmap decodeResource = BitmapFactory.decodeResource(getResources(), R.drawable.select_img);
        this.f11841o = decodeResource;
        this.img_selectstory.setImageBitmap(decodeResource);
        this.setProfile.setImageDrawable(getDrawable(R.drawable.ic_fakepro));
    }

    public void mo29469w() {
        getWindow().setFlags(2048, 2048);
        this.typecap.setText("");
        this.editTime.setText("");
        this.editName.setText("");
        Bitmap decodeResource = BitmapFactory.decodeResource(getResources(), R.drawable.select_img);
        this.f11841o = decodeResource;
        this.img_selectstory.setImageBitmap(decodeResource);
        this.setProfile.setImageDrawable(getDrawable(R.drawable.ic_fakepro));
    }
}
