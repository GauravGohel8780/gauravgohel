package com.statussaver.wacaption.gbversion.SplashExit.Activity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.SplashExit.Splash_Utils.Glob;

/* loaded from: classes3.dex */
public class PrivacyPolicy extends AppCompatActivity {
    private ProgressDialog progDailog;
    private WebView wvprivacy;

    @SuppressLint("WrongConstant")
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.sp_privacypolicy);
        ProgressDialog show = ProgressDialog.show(this, "Loading", "Please wait...", true);
        this.progDailog = show;
        show.setCancelable(false);
        WebView webView = (WebView) findViewById(R.id.wvPrivacyPolicy);
        this.wvprivacy = webView;
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        this.wvprivacy.setInitialScale(1);
        this.wvprivacy.getSettings().setLoadWithOverviewMode(true);
        this.wvprivacy.getSettings().setUseWideViewPort(true);
        this.wvprivacy.setScrollBarStyle(33554432);
        this.wvprivacy.setScrollbarFadingEnabled(true);
        this.wvprivacy.getSettings().setBuiltInZoomControls(true);
        this.wvprivacy.getSettings().setDisplayZoomControls(false);
        this.wvprivacy.setWebViewClient(new WebViewClient() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.PrivacyPolicy.1
            @Override // android.webkit.WebViewClient
            public void onReceivedError(WebView webView2, int i, String str, String str2) {
                Toast.makeText(PrivacyPolicy.this, str, 0).show();
            }

            @Override // android.webkit.WebViewClient
            public void onPageFinished(WebView webView2, String str) {
                super.onPageFinished(webView2, str);
                PrivacyPolicy.this.progDailog.dismiss();
            }

            @Override // android.webkit.WebViewClient
            public boolean shouldOverrideUrlLoading(WebView webView2, String str) {
                PrivacyPolicy.this.progDailog.show();
                if (str.startsWith("http:") || str.startsWith("https:")) {
                    return false;
                }
                PrivacyPolicy.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
                return true;
            }
        });
//        if (AppManage.app_privacyPolicyLink != null && !AppManage.app_privacyPolicyLink.isEmpty()) {
//            this.wvprivacy.loadUrl(AppManage.app_privacyPolicyLink);
//        } else {
            this.wvprivacy.loadUrl(Glob.privacy_link);
//        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        super.onBackPressed();
    }
}
