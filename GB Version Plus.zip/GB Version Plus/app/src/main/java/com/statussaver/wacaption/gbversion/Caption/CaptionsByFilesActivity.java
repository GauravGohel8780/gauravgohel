package com.statussaver.wacaption.gbversion.Caption;

import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.statussaver.wacaption.gbversion.Caption.adpter.CaptionsByFilesListAdapter;
import com.statussaver.wacaption.gbversion.R;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class CaptionsByFilesActivity extends AppCompatActivity {

    ArrayList<String> arraylistGoodCaptions;
    CaptionsByFilesListAdapter captionsListAdapter;
    ListView listVewCaptions;
    BufferedReader reader;
    Parcelable state;
    String title;
    TextView tv_title;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_captions_by_files);
        this.title = getIntent().getStringExtra("title");
        TextView textView = (TextView) findViewById(R.id.tv_title);
        this.tv_title = textView;
        textView.setText(this.title);
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CaptionsByFilesActivity.this.finish();
            }
        });
        this.listVewCaptions = (ListView) findViewById(R.id.listViewFacts);
        setTitle(Categories.categoriesArray[CaptionActivity.positionSelected]);
        this.arraylistGoodCaptions = new ArrayList<>();
        try {
            this.reader = new BufferedReader(new InputStreamReader(getAssets().open(CaptionActivity.fileToOpen)));
            while (true) {
                String readLine = this.reader.readLine();
                if (readLine == null) {
                    return;
                }
                if (!readLine.equals("")) {
                    this.arraylistGoodCaptions.add(readLine);
                }
            }
        } catch (Exception e) {
            Log.i("KAMLESH", "Exception : " + e.getMessage());
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        Parcelable parcelable = this.state;
        if (parcelable != null) {
            this.listVewCaptions.onRestoreInstanceState(parcelable);
            return;
        }
        CaptionsByFilesListAdapter captionsByFilesListAdapter = new CaptionsByFilesListAdapter(this, this.arraylistGoodCaptions);
        this.captionsListAdapter = captionsByFilesListAdapter;
        this.listVewCaptions.setAdapter((ListAdapter) captionsByFilesListAdapter);
    }

    @Override
    public void onPause() {
        this.state = this.listVewCaptions.onSaveInstanceState();
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        CaptionsByFilesActivity.this.finish();
    }
}
