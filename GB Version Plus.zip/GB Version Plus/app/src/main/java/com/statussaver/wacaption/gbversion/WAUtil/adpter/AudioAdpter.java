package com.statussaver.wacaption.gbversion.WAUtil.adpter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.statussaver.wacaption.gbversion.R;
import java.util.List;

/* loaded from: classes3.dex */
public class AudioAdpter extends RecyclerView.Adapter<AudioAdpter.MyView> {
    Context actContext;
    String checkId;
    List<String> imgStatusArray;

    public AudioAdpter(Context context, List<String> list, String str) {
        this.actContext = context;
        this.imgStatusArray = list;
        this.checkId = str;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public MyView onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyView(LayoutInflater.from(this.actContext).inflate(R.layout.itm_rec_audio, viewGroup, false));
    }

    public void onBindViewHolder(MyView myView, int i) {
        myView.textView.setText(this.imgStatusArray.get(i).substring(this.imgStatusArray.get(i).lastIndexOf("/") + 1));
        if (this.checkId.equals("102")) {
            Glide.with(this.actContext).load(Integer.valueOf((int) R.drawable.i5)).into(myView.imgAudio);
        } else if (this.checkId.equals("103")) {
            Glide.with(this.actContext).load(Integer.valueOf((int) R.drawable.i8)).into(myView.imgAudio);
        } else {
            Glide.with(this.actContext).load(Integer.valueOf((int) R.drawable.i7)).into(myView.imgAudio);
        }
        myView.textView.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.adpter.AudioAdpter.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
            }
        });
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.imgStatusArray.size();
    }

    /* loaded from: classes3.dex */
    public class MyView extends RecyclerView.ViewHolder {
        ImageView imgAudio;
        TextView textView;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public MyView(View view) {
            super(view);
            this.textView = (TextView) view.findViewById(R.id.nameAudio);
            this.imgAudio = (ImageView) view.findViewById(R.id.imgAudio);
        }
    }
}
