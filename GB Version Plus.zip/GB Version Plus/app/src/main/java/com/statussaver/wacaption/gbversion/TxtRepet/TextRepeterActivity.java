package com.statussaver.wacaption.gbversion.TxtRepet;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.statussaver.wacaption.gbversion.Emoction.GBWhats_CopyHan;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.StatusSaver.util.WhitelistCheck;

/* loaded from: classes3.dex */
public class TextRepeterActivity extends AppCompatActivity {
    CheckBox addMoreText;
    CheckBox addNextLine;
    CheckBox addSpace;
    ImageView btnGenerate;
    ImageView btnShare;
    boolean checkChar;
    boolean checkNextLine;
    boolean checkSpace;
    EditText editMessageCount;
    EditText editOtherText;
    EditText editRepeatMessage;
    String text = "";
    TextView txtGeneratedMessage;
    TextView txtGeneratedText;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_text_repeter);
        this.txtGeneratedText = (TextView) findViewById(R.id.txtGeneratedText);
        this.txtGeneratedMessage = (TextView) findViewById(R.id.txtGeneratedMessage);
        this.editRepeatMessage = (EditText) findViewById(R.id.editRepeatMessage);
        this.editMessageCount = (EditText) findViewById(R.id.editMessageCount);
        EditText editText = (EditText) findViewById(R.id.editOtherText);
        this.editOtherText = editText;
        editText.setEnabled(false);
        this.btnShare = (ImageView) findViewById(R.id.btnShare);
        this.addSpace = (CheckBox) findViewById(R.id.addSpace);
        this.addNextLine = (CheckBox) findViewById(R.id.addNextLine);
        this.addMoreText = (CheckBox) findViewById(R.id.addMoreText);
        this.btnGenerate = (ImageView) findViewById(R.id.btnGenerate);
        this.addMoreText.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.TxtRepet.TextRepeterActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (TextRepeterActivity.this.addMoreText.isChecked()) {
                    TextRepeterActivity.this.editOtherText.setEnabled(true);
                } else {
                    TextRepeterActivity.this.editOtherText.setEnabled(false);
                }
            }
        });
        this.btnGenerate.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.TxtRepet.TextRepeterActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                int i;
                TextRepeterActivity.this.txtGeneratedMessage.setVisibility(8);
                TextRepeterActivity.this.txtGeneratedText.setVisibility(8);
                if (TextRepeterActivity.this.editMessageCount.getText().toString().trim().length() > 0) {
                    i = Integer.parseInt(TextRepeterActivity.this.editMessageCount.getText().toString().trim());
                    if (i > 200) {
                        Toast.makeText(TextRepeterActivity.this, "please enter counter below 200...", 0).show();
                        return;
                    }
                } else {
                    i = 0;
                }
                if (TextRepeterActivity.this.editMessageCount.getText().toString().isEmpty()) {
                    Toast.makeText(TextRepeterActivity.this, "please enter count...", 0).show();
                }
                String trim = TextRepeterActivity.this.editRepeatMessage.getText().toString().trim();
                if (trim.length() > 0) {
                    TextRepeterActivity.this.txtGeneratedText.setText("");
                    TextRepeterActivity textRepeterActivity = TextRepeterActivity.this;
                    textRepeterActivity.checkChar = textRepeterActivity.addMoreText.isChecked();
                    TextRepeterActivity textRepeterActivity2 = TextRepeterActivity.this;
                    textRepeterActivity2.checkNextLine = textRepeterActivity2.addNextLine.isChecked();
                    TextRepeterActivity textRepeterActivity3 = TextRepeterActivity.this;
                    textRepeterActivity3.checkSpace = textRepeterActivity3.addSpace.isChecked();
                    TextRepeterActivity.this.text = "";
                    for (int i2 = 0; i2 < i; i2++) {
                        TextRepeterActivity textRepeterActivity4 = TextRepeterActivity.this;
                        textRepeterActivity4.text = TextRepeterActivity.this.text + trim;
                        if (TextRepeterActivity.this.checkSpace) {
                            TextRepeterActivity textRepeterActivity5 = TextRepeterActivity.this;
                            textRepeterActivity5.text = TextRepeterActivity.this.text + " ";
                        }
                        if (TextRepeterActivity.this.checkChar) {
                            TextRepeterActivity textRepeterActivity6 = TextRepeterActivity.this;
                            textRepeterActivity6.text = TextRepeterActivity.this.text + TextRepeterActivity.this.editOtherText.getText().toString().trim();
                        }
                        if (TextRepeterActivity.this.checkNextLine) {
                            TextRepeterActivity textRepeterActivity7 = TextRepeterActivity.this;
                            textRepeterActivity7.text = TextRepeterActivity.this.text + "\n";
                        }
                    }
                    TextRepeterActivity.this.btnGenerate.setClickable(true);
                    TextRepeterActivity.this.txtGeneratedMessage.setVisibility(0);
                    TextRepeterActivity.this.txtGeneratedText.setVisibility(0);
                    TextRepeterActivity.this.txtGeneratedText.setText(TextRepeterActivity.this.text);
                    return;
                }
                Toast.makeText(TextRepeterActivity.this, "please enter message...", 0).show();
            }
        });
        this.btnShare.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.TxtRepet.TextRepeterActivity.3
            @SuppressLint("WrongConstant")
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                int i = Build.VERSION.SDK_INT;
                if (TextRepeterActivity.this.text.length() <= 0) {
                    Toast.makeText(TextRepeterActivity.this, "please generate text...", 0).show();
                } else if (TextRepeterActivity.this.getPackageManager().getLaunchIntentForPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME) != null) {
                    Intent intent = new Intent("android.intent.action.SEND");
                    intent.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent.putExtra("android.intent.extra.TEXT", TextRepeterActivity.this.text);
                    intent.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    TextRepeterActivity.this.startActivity(intent);
                } else if (i >= 30) {
                    Intent intent2 = new Intent("android.intent.action.SEND");
                    intent2.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent2.putExtra("android.intent.extra.TEXT", TextRepeterActivity.this.text);
                    intent2.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    try {
                        TextRepeterActivity.this.startActivity(intent2);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(TextRepeterActivity.this, "Whatsapp doesn't installed", 0).show();
                    }
                } else {
                    Toast.makeText(TextRepeterActivity.this, "Whatsapp doesn't installed", 0).show();
                }
            }
        });
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.TxtRepet.TextRepeterActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                TextRepeterActivity.this.onBackPressed();
            }
        });
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
//        AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.TxtRepet.TextRepeterActivity.5
//            @Override // com.pesonal.adsdk.MyCallback
//            public void callbackCall() {
                TextRepeterActivity.this.finish();
//            }
//        }, AppManage.app_mainClickCntSwAd);
    }
}
