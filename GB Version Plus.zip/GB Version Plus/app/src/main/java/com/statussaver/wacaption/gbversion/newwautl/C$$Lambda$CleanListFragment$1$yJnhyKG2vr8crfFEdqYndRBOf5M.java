package com.statussaver.wacaption.gbversion.newwautl;

import android.content.DialogInterface;

public final class C$$Lambda$CleanListFragment$1$yJnhyKG2vr8crfFEdqYndRBOf5M implements DialogInterface.OnClickListener {
    public static final C$$Lambda$CleanListFragment$1$yJnhyKG2vr8crfFEdqYndRBOf5M INSTANCE = new C$$Lambda$CleanListFragment$1$yJnhyKG2vr8crfFEdqYndRBOf5M();

    private C$$Lambda$CleanListFragment$1$yJnhyKG2vr8crfFEdqYndRBOf5M() {
    }

    @Override
    public final void onClick(DialogInterface dialogInterface, int i) {
        dialogInterface.dismiss();
    }
}
