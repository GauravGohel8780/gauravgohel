package com.statussaver.wacaption.gbversion.WhatsShake;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import com.statussaver.wacaption.gbversion.R;

/* loaded from: classes3.dex */
public class GBWhats_WhatsShakeActivity extends AppCompatActivity {
    public static boolean ShakeCheck = false;
    public static int f324l;
    public ImageView f325h;
    public SwitchCompat f326i;
    public SharedPreferences f327j;
    public ImageView f328k;

    @SuppressLint("WrongConstant")
    public boolean isMyServiceRunning(Class<?> cls) {
        for (ActivityManager.RunningServiceInfo runningServiceInfo : ((ActivityManager) getSystemService("activity")).getRunningServices(Integer.MAX_VALUE)) {
            if (cls.getName().equals(runningServiceInfo.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.gbwhats_activity_whats_shake);
        ((TextView) findViewById(R.id.tx_nm)).setText("Whatsapp Shake");
        getWindow().setFlags(1024, 1024);
        this.f327j = PreferenceManager.getDefaultSharedPreferences(this);
        this.f325h = (ImageView) findViewById(R.id.btnShake);
        this.f328k = (ImageView) findViewById(R.id.back);
        SwitchCompat switchCompat = (SwitchCompat) findViewById(R.id.idSwitch);
        this.f326i = switchCompat;
        switchCompat.setChecked(this.f327j.getBoolean("checked", false));
        this.f326i.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: com.statussaver.wacaption.gbversion.WhatsShake.GBWhats_WhatsShakeActivity.1
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                Intent intent = new Intent(GBWhats_WhatsShakeActivity.this, GBWhats_ShakeService.class);
                GBWhats_WhatsShakeActivity.f324l++;
                if (z) {
                    GBWhats_WhatsShakeActivity.ShakeCheck = true;
                    GBWhats_WhatsShakeActivity.this.f327j.edit().putBoolean("checked", true).apply();
                    if (GBWhats_WhatsShakeActivity.this.isMyServiceRunning(GBWhats_ShakeService.class)) {
                        return;
                    }
                    GBWhats_WhatsShakeActivity.this.getApplicationContext().startService(intent);
                    return;
                }
                GBWhats_WhatsShakeActivity.ShakeCheck = false;
                GBWhats_WhatsShakeActivity.this.f327j.edit().putBoolean("checked", false).apply();
                if (!GBWhats_WhatsShakeActivity.this.isMyServiceRunning(GBWhats_ShakeService.class)) {
                    return;
                }
                GBWhats_WhatsShakeActivity.this.stopService(intent);
            }
        });
        this.f328k.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WhatsShake.GBWhats_WhatsShakeActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GBWhats_WhatsShakeActivity.this.onBackPressed();
            }
        });
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onPause() {
        super.onPause();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onResume() {
        super.onResume();
        if (this.f327j.getBoolean("checked", false)) {
            Intent intent = new Intent(this, GBWhats_ShakeService.class);
            ShakeCheck = true;
            this.f327j.edit().putBoolean("checked", true).apply();
            getApplicationContext().startService(intent);
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
//        AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.WhatsShake.GBWhats_WhatsShakeActivity.3
//            @Override // com.pesonal.adsdk.MyCallback
//            public void callbackCall() {
                GBWhats_WhatsShakeActivity.this.finish();
//            }
//        }, AppManage.app_mainClickCntSwAd);
    }
}
