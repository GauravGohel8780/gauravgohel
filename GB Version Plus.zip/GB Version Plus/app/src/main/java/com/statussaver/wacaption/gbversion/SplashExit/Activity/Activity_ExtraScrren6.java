package com.statussaver.wacaption.gbversion.SplashExit.Activity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.statussaver.wacaption.gbversion.Caption.CaptionActivity;
import com.statussaver.wacaption.gbversion.MainActivity;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.SplashExit.Splash_Utils.Glob;

/* loaded from: classes3.dex */
public class Activity_ExtraScrren6 extends AppCompatActivity {
    Activity_ExtraScrren6 activity;
    private ImageView caption;
    boolean doubleBackToExitPressedOnce = false;
    private ImageView img_vehicleinfo;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity__extra_scrren6);
        this.activity = this;
//        AppManage.getInstance(this).showNativeAds(this, (ViewGroup) findViewById(R.id.native_container), (ImageView) findViewById(R.id.native_space_img), 1);
        this.img_vehicleinfo = (ImageView) findViewById(R.id.gb_version);
        this.caption = (ImageView) findViewById(R.id.caption);
//        if (AppManage.playgamebutton == 1) {
//            findViewById(R.id.iv_playgame).setVisibility(0);
//            findViewById(R.id.iv_playgame).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren6.1
//                @Override // android.view.View.OnClickListener
//                public void onClick(View view) {
//                    AppManage.openChromeCustomTabUrl(Activity_ExtraScrren6.this.activity, AppManage.playgamelink);
//                }
//            });
//        } else {
//            findViewById(R.id.iv_playgame).setVisibility(8);
//        }
        this.img_vehicleinfo.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren6.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                if (Glob.checkMultiplePermissions(Activity_ExtraScrren6.this.activity)) {
//                    AppManage.getInstance(Activity_ExtraScrren6.this.activity).showInterstitialAd(Activity_ExtraScrren6.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren6.2.1
//                        @Override // com.pesonal.adsdk.MyCallback
//                        public void callbackCall() {
                            Activity_ExtraScrren6.this.startActivity(new Intent(Activity_ExtraScrren6.this, MainActivity.class));
//                        }
//                    }, AppManage.app_mainClickCntSwAd);
//                }
            }
        });
        this.caption.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren6.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                AppManage.getInstance(Activity_ExtraScrren6.this.activity).showInterstitialAd(Activity_ExtraScrren6.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren6.3.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        Activity_ExtraScrren6.this.startActivity(new Intent(Activity_ExtraScrren6.this, CaptionActivity.class));
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }


    //    @Override // androidx.activity.ComponentActivity, android.app.Activity
//    public void onBackPressed() {
//        if (AppManage.extrascreen5 == 1) {
//            AppManage.getInstance(this.activity).showInterstitialBackAd(this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren6.4
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
//                    Activity_ExtraScrren6.this.finish();
//                }
//            }, AppManage.app_mainClickCntSwAd);
//        } else if (AppManage.extrascreen4 == 1) {
//            AppManage.getInstance(this.activity).showInterstitialBackAd(this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren6.5
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
//                    Activity_ExtraScrren6.this.finish();
//                }
//            }, AppManage.app_mainClickCntSwAd);
//        } else if (AppManage.extrascreen3 == 1) {
//            AppManage.getInstance(this.activity).showInterstitialBackAd(this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren6.6
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
//                    Activity_ExtraScrren6.this.finish();
//                }
//            }, AppManage.app_mainClickCntSwAd);
//        } else if (AppManage.extrascreen2 == 1) {
//            AppManage.getInstance(this.activity).showInterstitialBackAd(this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren6.7
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
//                    Activity_ExtraScrren6.this.finish();
//                }
//            }, AppManage.app_mainClickCntSwAd);
//        } else if (AppManage.extrascreen1 == 1) {
//            AppManage.getInstance(this.activity).showInterstitialBackAd(this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren6.8
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
//                    Activity_ExtraScrren6.this.finish();
//                }
//            }, AppManage.app_mainClickCntSwAd);
//        } else if (AppManage.startScreen == 1) {
//            AppManage.getInstance(this.activity).showInterstitialBackAd(this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren6.9
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
//                    Activity_ExtraScrren6.this.finish();
//                }
//            }, AppManage.app_mainClickCntSwAd);
//        } else if (Glob.isOnline(this.activity)) {
//            if (AppManage.exitscreen == 1) {
//                startActivity(new Intent(this, BackActivity.class));
//            } else if (AppManage.exitscreendialog == 1) {
//                final Dialog dialog = new Dialog(this, R.style.MyDialog);
//                dialog.setCanceledOnTouchOutside(true);
//                dialog.setContentView(R.layout.backdlg);
//                dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
//                AppManage.show_anims_3btn(this, (RelativeLayout) dialog.findViewById(R.id.qureka), (RelativeLayout) dialog.findViewById(R.id.iv_predchamp), (RelativeLayout) dialog.findViewById(R.id.iv_mgl));
//                ((ImageView) dialog.findViewById(R.id.exit)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren6.10
//                    @Override // android.view.View.OnClickListener
//                    public void onClick(View view) {
//                        AppManage.getInstance(Activity_ExtraScrren6.this.activity).showInterstitialBackAd(Activity_ExtraScrren6.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren6.10.1
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
//                                Activity_ExtraScrren6.this.startActivity(new Intent(Activity_ExtraScrren6.this, Exit_Act.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    }
//                });
//                ((ImageView) dialog.findViewById(R.id.cancel)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren6.11
//                    @Override // android.view.View.OnClickListener
//                    public void onClick(View view) {
//                        dialog.dismiss();
//                    }
//                });
//                dialog.show();
//            } else if (this.doubleBackToExitPressedOnce) {
//                finishAffinity();
//            } else {
//                this.doubleBackToExitPressedOnce = true;
//                Toast.makeText(this, "Please click BACK again to exit", 0).show();
//                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren6.12
//                    @Override // java.lang.Runnable
//                    public void run() {
//                        Activity_ExtraScrren6.this.doubleBackToExitPressedOnce = false;
//                    }
//                }, 2000L);
//            }
//        } else if (this.doubleBackToExitPressedOnce) {
//            finishAffinity();
//        } else {
//            this.doubleBackToExitPressedOnce = true;
//            Toast.makeText(this, "Please click BACK again to exit", 0).show();
//            new Handler().postDelayed(new Runnable() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren6.13
//                @Override // java.lang.Runnable
//                public void run() {
//                    Activity_ExtraScrren6.this.doubleBackToExitPressedOnce = false;
//                }
//            }, 2000L);
//        }
//    }
}
