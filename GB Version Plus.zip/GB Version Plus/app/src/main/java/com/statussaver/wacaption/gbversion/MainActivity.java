package com.statussaver.wacaption.gbversion;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.statussaver.wacaption.gbversion.Caption.CaptionActivity;
import com.statussaver.wacaption.gbversion.DirectMessage.DirectMessageActivity;
import com.statussaver.wacaption.gbversion.Emoction.GBWhats_CatEmotionActivity;
import com.statussaver.wacaption.gbversion.Emoji.EmojiActivity;
import com.statussaver.wacaption.gbversion.EmptyMsg.EmptyMessageActivity;
import com.statussaver.wacaption.gbversion.FakeStory.GBWhats_FakestoryActivity;
import com.statussaver.wacaption.gbversion.Fakeprofile.GBWhats_FakeProfileActivity;
import com.statussaver.wacaption.gbversion.MultiMsg.MultiPleMessageActivty;
import com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_whatsappstatusButton;
import com.statussaver.wacaption.gbversion.TxtRepet.TextRepeterActivity;
import com.statussaver.wacaption.gbversion.Web.WACloneActivity;
import com.statussaver.wacaption.gbversion.WhatsShake.GBWhats_WhatsShakeActivity;
import com.statussaver.wacaption.gbversion.dirctchat.DirectChatActivity;
import com.statussaver.wacaption.gbversion.magictext.Decoration_Activity;
import com.statussaver.wacaption.gbversion.magictext.Text_activity;

/* loaded from: classes2.dex */
public class MainActivity extends AppCompatActivity {
    private Activity activity;
    boolean doubleBackToExitPressedOnce = false;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        this.activity = this;
//        AppManage.getInstance(this).showNativeAds(this, (ViewGroup) findViewById(R.id.native_container), (ImageView) findViewById(R.id.native_space_img), 2);
//        AppManage.getInstance(this).showBannerAds(this, (ViewGroup) findViewById(R.id.native_container1));
        findViewById(R.id.btn_ss).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.MainActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                AppManage.getInstance(MainActivity.this.activity).showInterstitialAd(MainActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.1.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, Activity_whatsappstatusButton.class));
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        findViewById(R.id.btn_dc).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.MainActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                AppManage.getInstance(MainActivity.this.activity).showInterstitialAd(MainActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.2.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, DirectChatActivity.class));
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        findViewById(R.id.btn_em).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.MainActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                AppManage.getInstance(MainActivity.this.activity).showInterstitialAd(MainActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.3.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, EmojiActivity.class));
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        findViewById(R.id.btn_tc).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.MainActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                AppManage.getInstance(MainActivity.this.activity).showInterstitialAd(MainActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.4.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, CaptionActivity.class));
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        findViewById(R.id.btn_dm).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.MainActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                AppManage.getInstance(MainActivity.this.activity).showInterstitialAd(MainActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.5.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, DirectMessageActivity.class));
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        findViewById(R.id.btn_tr).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.MainActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                AppManage.getInstance(MainActivity.this.activity).showInterstitialAd(MainActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.6.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, TextRepeterActivity.class));
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        findViewById(R.id.btn_mm).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.MainActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                AppManage.getInstance(MainActivity.this.activity).showInterstitialAd(MainActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.7.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, MultiPleMessageActivty.class));
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        findViewById(R.id.btn_sm).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.MainActivity.8
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                AppManage.getInstance(MainActivity.this.activity).showInterstitialAd(MainActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.8.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, EmptyMessageActivity.class));
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        findViewById(R.id.btn_wc).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.MainActivity.9
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                AppManage.getInstance(MainActivity.this.activity).showInterstitialAd(MainActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.9.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, WACloneActivity.class));
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        findViewById(R.id.wa_shake).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.MainActivity.10
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                AppManage.getInstance(MainActivity.this.activity).showInterstitialAd(MainActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.10.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, GBWhats_WhatsShakeActivity.class));
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        findViewById(R.id.fake_P).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.MainActivity.11
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                AppManage.getInstance(MainActivity.this.activity).showInterstitialAd(MainActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.11.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, GBWhats_FakeProfileActivity.class));
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        findViewById(R.id.fake_s).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.MainActivity.12
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                AppManage.getInstance(MainActivity.this.activity).showInterstitialAd(MainActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.12.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, GBWhats_FakestoryActivity.class));
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        findViewById(R.id.id_emoticon).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.MainActivity.13
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                AppManage.getInstance(MainActivity.this.activity).showInterstitialAd(MainActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.13.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, GBWhats_CatEmotionActivity.class));
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        findViewById(R.id.magic_txt).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.MainActivity.14
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                AppManage.getInstance(MainActivity.this.activity).showInterstitialAd(MainActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.14.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, Text_activity.class));
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        findViewById(R.id.decoration_txt).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.MainActivity.15
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                AppManage.getInstance(MainActivity.this.activity).showInterstitialAd(MainActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.15.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, Decoration_Activity.class));
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    //    @Override // androidx.activity.ComponentActivity, android.app.Activity
//    public void onBackPressed() {
//        if (AppManage.extrascreen6 == 1) {
//            AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.16
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
//                    MainActivity.this.finish();
//                }
//            }, AppManage.app_mainClickCntSwAd);
//        } else if (AppManage.extrascreen5 == 1) {
//            AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.17
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
//                    MainActivity.this.finish();
//                }
//            }, AppManage.app_mainClickCntSwAd);
//        } else if (AppManage.extrascreen4 == 1) {
//            AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.18
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
//                    MainActivity.this.finish();
//                }
//            }, AppManage.app_mainClickCntSwAd);
//        } else if (AppManage.extrascreen3 == 1) {
//            AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.19
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
//                    MainActivity.this.finish();
//                }
//            }, AppManage.app_mainClickCntSwAd);
//        } else if (AppManage.extrascreen2 == 1) {
//            AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.20
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
//                    MainActivity.this.finish();
//                }
//            }, AppManage.app_mainClickCntSwAd);
//        } else if (AppManage.extrascreen1 == 1) {
//            AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.21
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
//                    MainActivity.this.finish();
//                }
//            }, AppManage.app_mainClickCntSwAd);
//        } else if (AppManage.startScreen == 1) {
//            AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.22
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
//                    MainActivity.this.finish();
//                }
//            }, AppManage.app_mainClickCntSwAd);
//        } else if (Glob.isOnline(this.activity)) {
//            if (AppManage.exitscreen == 1) {
//                startActivity(new Intent(this, BackActivity.class));
//            } else if (AppManage.exitscreendialog == 1) {
//                final Dialog dialog = new Dialog(this, R.style.MyDialog);
//                dialog.setCanceledOnTouchOutside(true);
//                dialog.setContentView(R.layout.backdlg);
//                dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
//                AppManage.show_anims_3btn(this, (RelativeLayout) dialog.findViewById(R.id.qureka), (RelativeLayout) dialog.findViewById(R.id.iv_predchamp), (RelativeLayout) dialog.findViewById(R.id.iv_mgl));
//                ((ImageView) dialog.findViewById(R.id.exit)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.MainActivity.23
//                    @Override // android.view.View.OnClickListener
//                    public void onClick(View view) {
//                        AppManage.getInstance(MainActivity.this.activity).showInterstitialBackAd(MainActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.MainActivity.23.1
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
//                                MainActivity.this.startActivity(new Intent(MainActivity.this, Exit_Act.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    }
//                });
//                ((ImageView) dialog.findViewById(R.id.cancel)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.MainActivity.24
//                    @Override // android.view.View.OnClickListener
//                    public void onClick(View view) {
//                        dialog.dismiss();
//                    }
//                });
//                dialog.show();
//            } else if (this.doubleBackToExitPressedOnce) {
//                finishAffinity();
//            } else {
//                this.doubleBackToExitPressedOnce = true;
//                Toast.makeText(this, "Please click BACK again to exit", 0).show();
//                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.statussaver.wacaption.gbversion.MainActivity.25
//                    @Override // java.lang.Runnable
//                    public void run() {
//                        MainActivity.this.doubleBackToExitPressedOnce = false;
//                    }
//                }, 2000L);
//            }
//        } else if (this.doubleBackToExitPressedOnce) {
//            finishAffinity();
//        } else {
//            this.doubleBackToExitPressedOnce = true;
//            Toast.makeText(this, "Please click BACK again to exit", 0).show();
//            new Handler().postDelayed(new Runnable() { // from class: com.statussaver.wacaption.gbversion.MainActivity.26
//                @Override // java.lang.Runnable
//                public void run() {
//                    MainActivity.this.doubleBackToExitPressedOnce = false;
//                }
//            }, 2000L);
//        }
//    }
}
