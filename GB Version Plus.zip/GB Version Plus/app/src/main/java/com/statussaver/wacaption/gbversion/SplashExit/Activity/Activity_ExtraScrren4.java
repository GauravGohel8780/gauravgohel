package com.statussaver.wacaption.gbversion.SplashExit.Activity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.statussaver.wacaption.gbversion.MainActivity;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.SplashExit.Splash_Utils.Glob;
import com.statussaver.wacaption.gbversion.SplashExit.Splash_Utils.Launches;
import com.statussaver.wacaption.gbversion.magictext.Text_activity;

/* loaded from: classes3.dex */
public class Activity_ExtraScrren4 extends AppCompatActivity {
    Activity_ExtraScrren4 activity;
    ImageView backImg;
    boolean doubleBackToExitPressedOnce = false;
    private ImageView img_share;
    private ImageView magic_txt;
    private ImageView text_openapp;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity__extra_scrren4);
        this.activity = this;
//        AppManage.getInstance(this).showNativeAds(this, (ViewGroup) findViewById(R.id.native_container), (ImageView) findViewById(R.id.native_space_img), 1);
//        AppManage.show_anims_3btn(this, (RelativeLayout) findViewById(R.id.qureka), (RelativeLayout) findViewById(R.id.iv_predchamp), (RelativeLayout) findViewById(R.id.iv_mgl));
        this.magic_txt = (ImageView) findViewById(R.id.magic_txt);
        this.text_openapp = (ImageView) findViewById(R.id.text_openapp);
        this.img_share = (ImageView) findViewById(R.id.iv_share);
        this.text_openapp.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren4.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                if (Glob.checkMultiplePermissions(Activity_ExtraScrren4.this.activity)) {
//                    if (AppManage.extrascreen5 == 1) {
//                        AppManage.getInstance(Activity_ExtraScrren4.this.activity).showInterstitialAd(Activity_ExtraScrren4.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren4.1.1
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
                                Activity_ExtraScrren4.this.startActivity(new Intent(Activity_ExtraScrren4.this, Activity_ExtraScrren5.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    } else if (AppManage.extrascreen6 == 1) {
//                        AppManage.getInstance(Activity_ExtraScrren4.this.activity).showInterstitialAd(Activity_ExtraScrren4.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren4.1.2
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
//                                Activity_ExtraScrren4.this.startActivity(new Intent(Activity_ExtraScrren4.this, Activity_ExtraScrren6.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    } else {
//                        AppManage.getInstance(Activity_ExtraScrren4.this.activity).showInterstitialAd(Activity_ExtraScrren4.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren4.1.3
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
//                                Activity_ExtraScrren4.this.startActivity(new Intent(Activity_ExtraScrren4.this, MainActivity.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    }
//                }
            }
        });
        this.img_share.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren4.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Launches.shareApp(Activity_ExtraScrren4.this);
            }
        });
        this.magic_txt.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren4.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                AppManage.getInstance(Activity_ExtraScrren4.this.activity).showInterstitialAd(Activity_ExtraScrren4.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren4.3.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        Activity_ExtraScrren4.this.startActivity(new Intent(Activity_ExtraScrren4.this, Text_activity.class).putExtra("from", "from_exam"));
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    //    @Override // androidx.activity.ComponentActivity, android.app.Activity
//    public void onBackPressed() {
//        if (AppManage.extrascreen3 == 1) {
//            AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren4.4
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
//                    Activity_ExtraScrren4.this.finish();
//                }
//            }, AppManage.app_mainClickCntSwAd);
//        } else if (AppManage.extrascreen2 == 1) {
//            AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren4.5
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
//                    Activity_ExtraScrren4.this.finish();
//                }
//            }, AppManage.app_mainClickCntSwAd);
//        } else if (AppManage.extrascreen1 == 1) {
//            AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren4.6
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
//                    Activity_ExtraScrren4.this.finish();
//                }
//            }, AppManage.app_mainClickCntSwAd);
//        } else if (AppManage.startScreen == 1) {
//            AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren4.7
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
//                    Activity_ExtraScrren4.this.finish();
//                }
//            }, AppManage.app_mainClickCntSwAd);
//        } else if (Glob.isOnline(this.activity)) {
//            if (AppManage.exitscreen == 1) {
//                startActivity(new Intent(this, BackActivity.class));
//            } else if (AppManage.exitscreendialog == 1) {
//                final Dialog dialog = new Dialog(this, R.style.MyDialog);
//                dialog.setCanceledOnTouchOutside(true);
//                dialog.setContentView(R.layout.backdlg);
//                dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
//                AppManage.show_anims_3btn(this, (RelativeLayout) dialog.findViewById(R.id.qureka), (RelativeLayout) dialog.findViewById(R.id.iv_predchamp), (RelativeLayout) dialog.findViewById(R.id.iv_mgl));
//                ((ImageView) dialog.findViewById(R.id.exit)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren4.8
//                    @Override // android.view.View.OnClickListener
//                    public void onClick(View view) {
//                        AppManage.getInstance(Activity_ExtraScrren4.this.activity).showInterstitialBackAd(Activity_ExtraScrren4.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren4.8.1
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
//                                Activity_ExtraScrren4.this.startActivity(new Intent(Activity_ExtraScrren4.this, Exit_Act.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    }
//                });
//                ((ImageView) dialog.findViewById(R.id.cancel)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren4.9
//                    @Override // android.view.View.OnClickListener
//                    public void onClick(View view) {
//                        dialog.dismiss();
//                    }
//                });
//                dialog.show();
//            } else if (this.doubleBackToExitPressedOnce) {
//                finishAffinity();
//            } else {
//                this.doubleBackToExitPressedOnce = true;
//                Toast.makeText(this, "Please click BACK again to exit", 0).show();
//                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren4.10
//                    @Override // java.lang.Runnable
//                    public void run() {
//                        Activity_ExtraScrren4.this.doubleBackToExitPressedOnce = false;
//                    }
//                }, 2000L);
//            }
//        } else if (this.doubleBackToExitPressedOnce) {
//            finishAffinity();
//        } else {
//            this.doubleBackToExitPressedOnce = true;
//            Toast.makeText(this, "Please click BACK again to exit", 0).show();
//            new Handler().postDelayed(new Runnable() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren4.11
//                @Override // java.lang.Runnable
//                public void run() {
//                    Activity_ExtraScrren4.this.doubleBackToExitPressedOnce = false;
//                }
//            }, 2000L);
//        }
//    }
}
