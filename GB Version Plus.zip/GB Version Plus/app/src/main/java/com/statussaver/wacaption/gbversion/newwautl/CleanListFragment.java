package com.statussaver.wacaption.gbversion.newwautl;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.storage.StorageManager;
import android.text.format.Formatter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.view.PointerIconCompat;
import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.newwautl.CleanerAdapter;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes3.dex */
public class CleanListFragment extends Fragment implements CleanerAdapter.OnCheckboxListener {
    loadDataAsync async;
    String category;
    LinearLayout delete;
    RelativeLayout emptyLay;
    File file;
    String isSent;
    RelativeLayout loaderLay;
    CleanerAdapter mAdapter;
    RecyclerView.LayoutManager mLayoutManager;
    String path;
    RecyclerView recyclerView;
    LinearLayout sAccessBtn;
    CheckBox selectAll;
    TextView txt;
    int REQUEST_ACTION_OPEN_DOCUMENT_TREE = PointerIconCompat.TYPE_ALIAS;
    ArrayList<CleanerFileModel> filesToDelete = new ArrayList<>();
    ArrayList<CleanerFileModel> statusImageList = new ArrayList<>();

    public static CleanListFragment newInstance(String str, String str2, String str3) {
        CleanListFragment cleanListFragment = new CleanListFragment();
        Bundle bundle = new Bundle();
        bundle.putString("path", str2);
        bundle.putString("category", str);
        bundle.putString("isSent", str3);
        cleanListFragment.setArguments(bundle);
        return cleanListFragment;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_clean_list, viewGroup, false);
        if (getArguments() != null) {
            this.path = getArguments().getString("path");
            this.category = getArguments().getString("category");
            this.isSent = getArguments().getString("isSent");
        }
        this.loaderLay = (RelativeLayout) inflate.findViewById(R.id.loaderLay);
        this.emptyLay = (RelativeLayout) inflate.findViewById(R.id.emptyLay);
        RecyclerView recyclerView = (RecyclerView) inflate.findViewById(R.id.recyclerView);
        this.recyclerView = recyclerView;
        recyclerView.setHasFixedSize(true);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 3);
        this.mLayoutManager = gridLayoutManager;
        this.recyclerView.setLayoutManager(gridLayoutManager);
        this.txt = (TextView) inflate.findViewById(R.id.txt);
        LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.delete);
        this.delete = linearLayout;
        linearLayout.setOnClickListener(new AnonymousClass1());
        CheckBox checkBox = (CheckBox) inflate.findViewById(R.id.selectAll);
        this.selectAll = checkBox;
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: com.statussaver.wacaption.gbversion.newwautl.CleanListFragment.2
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (compoundButton.isPressed()) {
                    CleanListFragment.this.filesToDelete.clear();
                    int i = 0;
                    while (true) {
                        if (i >= CleanListFragment.this.statusImageList.size()) {
                            break;
                        } else if (!CleanListFragment.this.statusImageList.get(i).selected) {
                            z = true;
                            break;
                        } else {
                            i++;
                        }
                    }
                    if (z) {
                        for (int i2 = 0; i2 < CleanListFragment.this.statusImageList.size(); i2++) {
                            CleanListFragment.this.statusImageList.get(i2).selected = true;
                            CleanListFragment.this.filesToDelete.add(CleanListFragment.this.statusImageList.get(i2));
                        }
                        CleanListFragment.this.selectAll.setChecked(true);
                    } else {
                        for (int i3 = 0; i3 < CleanListFragment.this.statusImageList.size(); i3++) {
                            CleanListFragment.this.statusImageList.get(i3).selected = false;
                        }
                    }
                    CleanListFragment.this.mAdapter.notifyDataSetChanged();
                }
            }
        });
        LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.sAccessBtn);
        this.sAccessBtn = linearLayout2;
        linearLayout2.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.newwautl.CleanListFragment.3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                CleanListFragment.this.lambda$onCreateView$0$CleanListFragment(view);
            }
        });
        if (!Utils.iswApp || !this.category.equals(Utils.IMAGE)) {
            if (Utils.iswApp || !this.category.equals(Utils.IMAGE)) {
                if (!Utils.iswApp || !this.category.equals(Utils.VIDEO)) {
                    if (Utils.iswApp || !this.category.equals(Utils.VIDEO)) {
                        if (!Utils.iswApp || !this.category.equals(Utils.DOCUMENT)) {
                            if (Utils.iswApp || !this.category.equals(Utils.DOCUMENT)) {
                                if (!Utils.iswApp || !this.category.equals(Utils.AUDIO)) {
                                    if (Utils.iswApp || !this.category.equals(Utils.AUDIO)) {
                                        if (!Utils.iswApp || !this.category.equals(Utils.GIF)) {
                                            if (!Utils.iswApp && this.category.equals(Utils.GIF)) {
                                                if (this.isSent.equals("yes")) {
                                                    if (!SharedPrefs.getWBGifSendTree(getActivity()).equals("")) {
                                                        populateGrid();
                                                    }
                                                } else if (!SharedPrefs.getWBGifTree(getActivity()).equals("")) {
                                                    populateGrid();
                                                }
                                            }
                                        } else if (this.isSent.equals("yes")) {
                                            if (!SharedPrefs.getWAGifSendTree(getActivity()).equals("")) {
                                                populateGrid();
                                            }
                                        } else if (!SharedPrefs.getWAGifTree(getActivity()).equals("")) {
                                            populateGrid();
                                        }
                                    } else if (this.isSent.equals("yes")) {
                                        if (!SharedPrefs.getWBAudioSendTree(getActivity()).equals("")) {
                                            populateGrid();
                                        }
                                    } else if (!SharedPrefs.getWBAudioTree(getActivity()).equals("")) {
                                        populateGrid();
                                    }
                                } else if (this.isSent.equals("yes")) {
                                    if (!SharedPrefs.getWAAudioSendTree(getActivity()).equals("")) {
                                        populateGrid();
                                    }
                                } else if (!SharedPrefs.getWAAudioTree(getActivity()).equals("")) {
                                    populateGrid();
                                }
                            } else if (this.isSent.equals("yes")) {
                                if (!SharedPrefs.getWBDocSendTree(getActivity()).equals("")) {
                                    populateGrid();
                                }
                            } else if (!SharedPrefs.getWBDocTree(getActivity()).equals("")) {
                                populateGrid();
                            }
                        } else if (this.isSent.equals("yes")) {
                            if (!SharedPrefs.getWADocSendTree(getActivity()).equals("")) {
                                populateGrid();
                            }
                        } else if (!SharedPrefs.getWADocTree(getActivity()).equals("")) {
                            populateGrid();
                        }
                    } else if (this.isSent.equals("yes")) {
                        if (!SharedPrefs.getWBVideoSendTree(getActivity()).equals("")) {
                            populateGrid();
                        }
                    } else if (!SharedPrefs.getWBVideoTree(getActivity()).equals("")) {
                        populateGrid();
                    }
                } else if (this.isSent.equals("yes")) {
                    if (!SharedPrefs.getWAVideoSendTree(getActivity()).equals("")) {
                        populateGrid();
                    }
                } else if (!SharedPrefs.getWAVideoTree(getActivity()).equals("")) {
                    populateGrid();
                }
            } else if (this.isSent.equals("yes")) {
                if (!SharedPrefs.getWBImgSendTree(getActivity()).equals("")) {
                    populateGrid();
                }
            } else if (!SharedPrefs.getWBImgTree(getActivity()).equals("")) {
                populateGrid();
            }
        } else if (this.isSent.equals("yes")) {
            if (!SharedPrefs.getWAImgSendTree(getActivity()).equals("")) {
                populateGrid();
            }
        } else if (!SharedPrefs.getWAImgTree(getActivity()).equals("")) {
            populateGrid();
        }
        return inflate;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.statussaver.wacaption.gbversion.newwautl.CleanListFragment$1 */
    /* loaded from: classes3.dex */
    public class AnonymousClass1 implements View.OnClickListener {
        AnonymousClass1() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (!CleanListFragment.this.filesToDelete.isEmpty()) {
                new AlertDialog.Builder(CleanListFragment.this.getContext()).setMessage("Are you sure , You want to delete selected files?").setCancelable(true).setNegativeButton("Yes", new DialogInterface.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.newwautl.CleanListFragment.1.1
                    @Override // android.content.DialogInterface.OnClickListener
                    public final void onClick(DialogInterface dialogInterface, int i) {
                        AnonymousClass1.this.lambda$onClick$0$CleanListFragment$1(dialogInterface, i);
                    }
                }).setPositiveButton("No", C$$Lambda$CleanListFragment$1$yJnhyKG2vr8crfFEdqYndRBOf5M.INSTANCE).create().show();
            }
        }

        @SuppressLint("WrongConstant")
        public void lambda$onClick$0$CleanListFragment$1(DialogInterface dialogInterface, int i) {
            ArrayList arrayList = new ArrayList();
            Iterator<CleanerFileModel> it = CleanListFragment.this.filesToDelete.iterator();
            char c = '\uffff';
            while (it.hasNext()) {
                CleanerFileModel next = it.next();
                DocumentFile fromSingleUri = DocumentFile.fromSingleUri(CleanListFragment.this.getActivity(), Uri.parse(next.getFilePath()));
                if (!fromSingleUri.exists() || !fromSingleUri.delete()) {
                    c = 0;
                } else {
                    arrayList.add(next);
                    if (c == 0) {
                        return;
                    }
                    c = 1;
                }
            }
            CleanListFragment.this.filesToDelete.clear();
            Iterator it2 = arrayList.iterator();
            while (it2.hasNext()) {
                CleanListFragment.this.statusImageList.remove((CleanerFileModel) it2.next());
            }
            CleanListFragment.this.mAdapter.notifyDataSetChanged();
            if (c == 0) {
                Toast.makeText(CleanListFragment.this.getContext(), "Couldn't delete some files", 0).show();
            } else if (c == 1) {
                Toast.makeText(CleanListFragment.this.getActivity(), "Deleted successfully", 0).show();
            }
            CleanListFragment.this.txt.setText(R.string.delete_items_blank);
            CleanListFragment.this.txt.setTextColor(CleanListFragment.this.getResources().getColor(R.color.black));
            CleanListFragment.this.selectAll.setChecked(false);
        }
    }

    public void lambda$onCreateView$0$CleanListFragment(View view) {
        Intent intent;
        StorageManager storageManager = (StorageManager) getActivity().getSystemService("storage");
        String str = this.path;
        if (Build.VERSION.SDK_INT >= 29) {
            intent = storageManager.getPrimaryStorageVolume().createOpenDocumentTreeIntent();
            String replace = ((Uri) intent.getParcelableExtra("android.provider.extra.INITIAL_URI")).toString().replace("/root/", "/document/");
            intent.putExtra("android.provider.extra.INITIAL_URI", Uri.parse(replace + "%3A" + str));
        } else {
            intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
            intent.putExtra("android.provider.extra.INITIAL_URI", Uri.parse("content://com.android.externalstorage.documents/document/primary%3A" + str));
        }
        intent.addFlags(2);
        intent.addFlags(1);
        intent.addFlags(128);
        intent.addFlags(64);
        startActivityForResult(intent, this.REQUEST_ACTION_OPEN_DOCUMENT_TREE);
    }

    public void populateGrid() {
        loadDataAsync loaddataasync = new loadDataAsync();
        this.async = loaddataasync;
        loaddataasync.execute(new Void[0]);
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroy() {
        super.onDestroy();
        loadDataAsync loaddataasync = this.async;
        if (loaddataasync != null) {
            loaddataasync.cancel(true);
        }
    }

    /* loaded from: classes3.dex */
    public class loadDataAsync extends AsyncTask<Void, Void, Void> {
        DocumentFile[] allFiles;

        loadDataAsync() {
        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            super.onPreExecute();
            CleanListFragment.this.loaderLay.setVisibility(0);
            CleanListFragment.this.recyclerView.setVisibility(8);
            CleanListFragment.this.sAccessBtn.setVisibility(8);
            CleanListFragment.this.emptyLay.setVisibility(8);
        }

        public Void doInBackground(Void... voidArr) {
            this.allFiles = null;
            CleanListFragment.this.statusImageList = new ArrayList<>();
            this.allFiles = CleanListFragment.this.getFromSdcard();
            int i = 0;
            while (true) {
                DocumentFile[] documentFileArr = this.allFiles;
                if (i >= documentFileArr.length) {
                    return null;
                }
                if (!documentFileArr[i].getUri().toString().contains(".nomedia") && !this.allFiles[i].isDirectory()) {
                    CleanListFragment.this.statusImageList.add(new CleanerFileModel(this.allFiles[i].getUri().toString(), this.allFiles[i].getName(), String.valueOf(this.allFiles[i].length())));
                }
                i++;
            }
        }

        public void onPostExecute(Void r4) {
            super.onPostExecute( r4);
            new Handler().postDelayed(new Runnable() { // from class: com.statussaver.wacaption.gbversion.newwautl.CleanListFragment.loadDataAsync.1
                @Override // java.lang.Runnable
                public final void run() {
                    loadDataAsync.this.lambda$onPostExecute$0$CleanListFragment$loadDataAsync();
                }
            }, 300L);
        }

        public void lambda$onPostExecute$0$CleanListFragment$loadDataAsync() {
            if (CleanListFragment.this.getActivity() != null) {
                CleanListFragment cleanListFragment = CleanListFragment.this;
                cleanListFragment.mAdapter = new CleanerAdapter(cleanListFragment.getActivity(), CleanListFragment.this.statusImageList, CleanListFragment.this.category, CleanListFragment.this);
                CleanListFragment.this.recyclerView.setAdapter(CleanListFragment.this.mAdapter);
                CleanListFragment.this.loaderLay.setVisibility(8);
                CleanListFragment.this.recyclerView.setVisibility(0);
            }
            if (CleanListFragment.this.statusImageList == null || CleanListFragment.this.statusImageList.size() == 0) {
                CleanListFragment.this.emptyLay.setVisibility(0);
            } else {
                CleanListFragment.this.emptyLay.setVisibility(8);
            }
        }
    }

    public DocumentFile[] getFromSdcard() {
        String str;
        if (!Utils.iswApp || !this.category.equals(Utils.IMAGE)) {
            if (Utils.iswApp || !this.category.equals(Utils.IMAGE)) {
                if (!Utils.iswApp || !this.category.equals(Utils.VIDEO)) {
                    if (Utils.iswApp || !this.category.equals(Utils.VIDEO)) {
                        if (!Utils.iswApp || !this.category.equals(Utils.DOCUMENT)) {
                            if (Utils.iswApp || !this.category.equals(Utils.DOCUMENT)) {
                                if (!Utils.iswApp || !this.category.equals(Utils.AUDIO)) {
                                    if (Utils.iswApp || !this.category.equals(Utils.AUDIO)) {
                                        if (!Utils.iswApp || !this.category.equals(Utils.GIF)) {
                                            if (Utils.iswApp || !this.category.equals(Utils.GIF)) {
                                                str = "";
                                            } else {
                                                str = this.isSent.equals("yes") ? SharedPrefs.getWBGifSendTree(getActivity()) : SharedPrefs.getWBGifTree(getActivity());
                                            }
                                        } else if (this.isSent.equals("yes")) {
                                            str = SharedPrefs.getWAGifSendTree(getActivity());
                                        } else {
                                            str = SharedPrefs.getWAGifTree(getActivity());
                                        }
                                    } else if (this.isSent.equals("yes")) {
                                        str = SharedPrefs.getWBAudioSendTree(getActivity());
                                    } else {
                                        str = SharedPrefs.getWBAudioTree(getActivity());
                                    }
                                } else if (this.isSent.equals("yes")) {
                                    str = SharedPrefs.getWAAudioSendTree(getActivity());
                                } else {
                                    str = SharedPrefs.getWAAudioTree(getActivity());
                                }
                            } else if (this.isSent.equals("yes")) {
                                str = SharedPrefs.getWBDocSendTree(getActivity());
                            } else {
                                str = SharedPrefs.getWBDocTree(getActivity());
                            }
                        } else if (this.isSent.equals("yes")) {
                            str = SharedPrefs.getWADocSendTree(getActivity());
                        } else {
                            str = SharedPrefs.getWADocTree(getActivity());
                        }
                    } else if (this.isSent.equals("yes")) {
                        str = SharedPrefs.getWBVideoSendTree(getActivity());
                    } else {
                        str = SharedPrefs.getWBVideoTree(getActivity());
                    }
                } else if (this.isSent.equals("yes")) {
                    str = SharedPrefs.getWAVideoSendTree(getActivity());
                } else {
                    str = SharedPrefs.getWAVideoTree(getActivity());
                }
            } else if (this.isSent.equals("yes")) {
                str = SharedPrefs.getWBImgSendTree(getActivity());
            } else {
                str = SharedPrefs.getWBImgTree(getActivity());
            }
        } else if (this.isSent.equals("yes")) {
            str = SharedPrefs.getWAImgSendTree(getActivity());
        } else {
            str = SharedPrefs.getWAImgTree(getActivity());
        }
        DocumentFile fromTreeUri = DocumentFile.fromTreeUri(requireContext().getApplicationContext(), Uri.parse(str));
        if (fromTreeUri == null || !fromTreeUri.exists() || !fromTreeUri.isDirectory() || !fromTreeUri.canRead() || !fromTreeUri.canWrite()) {
            return null;
        }
        return fromTreeUri.listFiles();
    }

    @Override // androidx.fragment.app.Fragment
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == this.REQUEST_ACTION_OPEN_DOCUMENT_TREE && i2 == -1) {
            Uri data = intent.getData();
            try {
                if (Build.VERSION.SDK_INT >= 19) {
                    requireContext().getContentResolver().takePersistableUriPermission(data, 3);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (!Utils.iswApp || !this.category.equals(Utils.IMAGE)) {
                if (Utils.iswApp || !this.category.equals(Utils.IMAGE)) {
                    if (!Utils.iswApp || !this.category.equals(Utils.VIDEO)) {
                        if (Utils.iswApp || !this.category.equals(Utils.VIDEO)) {
                            if (!Utils.iswApp || !this.category.equals(Utils.DOCUMENT)) {
                                if (Utils.iswApp || !this.category.equals(Utils.DOCUMENT)) {
                                    if (!Utils.iswApp || !this.category.equals(Utils.AUDIO)) {
                                        if (Utils.iswApp || !this.category.equals(Utils.AUDIO)) {
                                            if (!Utils.iswApp || !this.category.equals(Utils.GIF)) {
                                                if (!Utils.iswApp && this.category.equals(Utils.GIF)) {
                                                    if (this.isSent.equals("yes")) {
                                                        SharedPrefs.setWBGifSendTree(getActivity(), data.toString());
                                                    } else {
                                                        SharedPrefs.setWBGifTree(getActivity(), data.toString());
                                                    }
                                                }
                                            } else if (this.isSent.equals("yes")) {
                                                SharedPrefs.setWAGifSendTree(getActivity(), data.toString());
                                            } else {
                                                SharedPrefs.setWAGifTree(getActivity(), data.toString());
                                            }
                                        } else if (this.isSent.equals("yes")) {
                                            SharedPrefs.setWBAudioSendTree(getActivity(), data.toString());
                                        } else {
                                            SharedPrefs.setWBAudioTree(getActivity(), data.toString());
                                        }
                                    } else if (this.isSent.equals("yes")) {
                                        SharedPrefs.setWAAudioSendTree(getActivity(), data.toString());
                                    } else {
                                        SharedPrefs.setWAAudioTree(getActivity(), data.toString());
                                    }
                                } else if (this.isSent.equals("yes")) {
                                    SharedPrefs.setWBDocSendTree(getActivity(), data.toString());
                                } else {
                                    SharedPrefs.setWBDocTree(getActivity(), data.toString());
                                }
                            } else if (this.isSent.equals("yes")) {
                                SharedPrefs.setWADocSendTree(getActivity(), data.toString());
                            } else {
                                SharedPrefs.setWADocTree(getActivity(), data.toString());
                            }
                        } else if (this.isSent.equals("yes")) {
                            SharedPrefs.setWBVideoSendTree(getActivity(), data.toString());
                        } else {
                            SharedPrefs.setWBVideoTree(getActivity(), data.toString());
                        }
                    } else if (this.isSent.equals("yes")) {
                        SharedPrefs.setWAVideoSendTree(getActivity(), data.toString());
                    } else {
                        SharedPrefs.setWAVideoTree(getActivity(), data.toString());
                    }
                } else if (this.isSent.equals("yes")) {
                    SharedPrefs.setWBImgSendTree(getActivity(), data.toString());
                } else {
                    SharedPrefs.setWBImgTree(getActivity(), data.toString());
                }
            } else if (this.isSent.equals("yes")) {
                SharedPrefs.setWAImgSendTree(getActivity(), data.toString());
            } else {
                SharedPrefs.setWAImgTree(getActivity(), data.toString());
            }
            populateGrid();
        }
    }

    @Override // com.statussaver.wacaption.gbversion.newwautl.CleanerAdapter.OnCheckboxListener
    public void onCheckboxListener(View view, List<CleanerFileModel> list) {
        this.filesToDelete.clear();
        for (CleanerFileModel cleanerFileModel : list) {
            if (cleanerFileModel.isSelected()) {
                this.filesToDelete.add(cleanerFileModel);
            }
        }
        if (this.filesToDelete.size() == this.statusImageList.size()) {
            this.selectAll.setChecked(true);
        }
        if (!this.filesToDelete.isEmpty()) {
            long j = 0;
            Iterator<CleanerFileModel> it = this.filesToDelete.iterator();
            while (it.hasNext()) {
                j += Integer.parseInt(it.next().getSize());
            }
            String formatShortFileSize = Formatter.formatShortFileSize(getActivity(), j);
            TextView textView = this.txt;
            textView.setText("Delete Selected Items (" + formatShortFileSize + ")");
            this.txt.setTextColor(Color.parseColor("#FF000000"));
            return;
        }
        this.txt.setText(R.string.delete_items_blank);
        this.txt.setTextColor(getResources().getColor(R.color.black));
        this.selectAll.setChecked(false);
    }
}
