package com.statussaver.wacaption.gbversion.SplashExit.Activity;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Locale;

/* loaded from: classes3.dex */
public class PreferenceManager {
    private static final String IS_FIRST_TIME_LAUNCH = "IsFirstTimeLaunch";
    private static final String PREF_NAME = "intro_slider-welcome";
    int PRIVATE_MODE = 0;
    Context _context;
    SharedPreferences.Editor editor;
    SharedPreferences pref;

    public PreferenceManager(Context context) {
        this._context = context;
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, 0);
        this.pref = sharedPreferences;
        this.editor = sharedPreferences.edit();
    }

    public void setFirstTimeLaunch(boolean z) {
        this.editor.putBoolean(IS_FIRST_TIME_LAUNCH, z);
        this.editor.commit();
    }

    public boolean isFirstTimeLaunch() {
        return this.pref.getBoolean(IS_FIRST_TIME_LAUNCH, true);
    }

    public void putString(String str, Locale locale) {
        this.editor.putString(str, String.valueOf(locale));
        this.editor.commit();
    }

    public String getStringpreference(String str, String str2) {
        return this.pref.getString(str, str2);
    }

    public void setStringpreference(String str, String str2) {
        this.editor.putString(str, str2).commit();
        this.editor.commit();
    }

    public Locale getString(String str) {
        return Locale.forLanguageTag(this.pref.getString(str, Locale.getDefault().getLanguage()));
    }

    public boolean isBooleenPreference(String str) {
        return this.pref.getBoolean(str, false);
    }

    public void setBooleanpreference(String str, boolean z) {
        this.editor.putBoolean(str, z).commit();
        this.editor.commit();
    }
}
