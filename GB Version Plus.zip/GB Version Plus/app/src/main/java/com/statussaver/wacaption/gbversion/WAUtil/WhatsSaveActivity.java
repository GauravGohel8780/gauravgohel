package com.statussaver.wacaption.gbversion.WAUtil;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import com.statussaver.wacaption.gbversion.R;
import java.io.File;

/* loaded from: classes3.dex */
public class WhatsSaveActivity extends AppCompatActivity {
    ImageView delete;
    ImageView imageview;
    ImageView imgShare;
    ImageView imgback;
    VideoView videoView;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_whats_save);
        this.imageview = (ImageView) findViewById(R.id.imageview);
        this.videoView = (VideoView) findViewById(R.id.videoview);
        this.delete = (ImageView) findViewById(R.id.delete);
        this.imgShare = (ImageView) findViewById(R.id.imgShare);
        this.imgback = (ImageView) findViewById(R.id.imgBack);
        final String stringExtra = getIntent().getStringExtra("status");
        Log.d("NEWvvv", getIntent().getStringExtra("checkId"));
        File file = new File(stringExtra);
        if (file.getAbsolutePath().contains(".mp4")) {
            this.videoView.setVisibility(0);
            this.imageview.setVisibility(8);
            this.videoView.setVideoPath(stringExtra);
            this.videoView.start();
            this.videoView.setMediaController(new MediaController(this));
        } else {
            this.videoView.setVisibility(8);
            this.imageview.setVisibility(0);
            ImageView imageView = this.imageview;
            imageView.setImageURI(FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", file));
        }
        this.delete.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsSaveActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                final Dialog dialog = new Dialog(WhatsSaveActivity.this);
                dialog.requestWindowFeature(1);
                dialog.setCancelable(true);
                dialog.setContentView(R.layout.delete_dialog);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                ((TextView) dialog.findViewById(R.id.txtDelTitle)).setText("Do you want to delete this Media?");
                ((ImageView) dialog.findViewById(R.id.btn_cancel)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsSaveActivity.1.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.dismiss();
                    }
                });
                ((ImageView) dialog.findViewById(R.id.btn_okay)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsSaveActivity.1.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.cancel();
                        try {
                            new File(stringExtra).delete();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        WhatsSaveActivity.this.onBackPressed();
                    }
                });
                dialog.show();
            }
        });
        this.imgShare.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsSaveActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("*/*");
                File file2 = new File(stringExtra);
                WhatsSaveActivity whatsSaveActivity = WhatsSaveActivity.this;
                intent.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(whatsSaveActivity, WhatsSaveActivity.this.getApplicationContext().getPackageName() + ".provider", file2));
                WhatsSaveActivity.this.startActivity(Intent.createChooser(intent, "Send to..."));
            }
        });
        this.imgback.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsSaveActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                WhatsSaveActivity.this.onBackPressed();
            }
        });
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onStop() {
        super.onStop();
        this.videoView.stopPlayback();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onResume() {
        super.onResume();
        this.videoView.start();
    }
}
