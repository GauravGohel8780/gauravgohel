package com.statussaver.wacaption.gbversion.newwautl;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.statussaver.wacaption.gbversion.R;

public class CleanDataActivity extends AppCompatActivity {

    ImageView backIV;
    String category;
    String receivePath;
    String sentPath;
    TabLayout tabLayout;
    ViewPager viewPager;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_clean_data);
        this.category = getIntent().getStringExtra("category");
        this.receivePath = getIntent().getStringExtra("receivePath");
        this.sentPath = getIntent().getStringExtra("sentPath");
        Log.e("category: ", this.category);
        Log.e("receivePath: ", this.receivePath);
        Log.e("sentPath: ", this.sentPath);
        ImageView imageView = (ImageView) findViewById(R.id.backIV);
        this.backIV = imageView;
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CleanDataActivity.this.onBackPressed();
            }
        });
        ViewPager viewPager = (ViewPager) findViewById(R.id.pagerdiet);
        this.viewPager = viewPager;
        viewPager.setAdapter(new CleanerPagerAdapter(getSupportFragmentManager(), this.category, this.receivePath, this.sentPath));
        TabLayout tabLayout = (TabLayout) findViewById(R.id.tab_layoutdiet);
        this.tabLayout = tabLayout;
        tabLayout.setupWithViewPager(this.viewPager);
        setupTabIcons();
        this.tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }
        });
    }

    @Override
    public void onBackPressed() {
        CleanDataActivity.this.finish();
    }

    private void setupTabIcons() {
        TextView textView = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab2, (ViewGroup) null);
        textView.setText("Received File");
        this.tabLayout.getTabAt(0).setCustomView(textView);
        TextView textView2 = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab2, (ViewGroup) null);
        textView2.setText("Sent File");
        this.tabLayout.getTabAt(1).setCustomView(textView2);
    }
}
