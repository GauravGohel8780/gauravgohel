package com.statussaver.wacaption.gbversion.Fakeprofile;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.snackbar.Snackbar;
import com.statussaver.wacaption.gbversion.R;

import de.hdodenhof.circleimageview.CircleImageView;

import java.util.Calendar;

public class GBWhats_FakeProfileActivity extends AppCompatActivity {

    public static Uri selectedImageUri;
    public ImageView back;
    public ImageView f190h;
    public EditText f191i;
    public TextView f192j;
    public EditText f193k;
    public TextView f194l;
    public EditText f195m;
    public CircleImageView f196n;
    public ImageView f197o;
    public ImageView f198p;
    public String f199q;
    public String f200r;
    public String f201s;
    public String f202t;
    public String f203u;
    private TimePickerDialog mTimePicker;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @SuppressLint("ResourceType")
    private void checkPermission() {
        if (ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") + ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.WRITE_EXTERNAL_STORAGE") || ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.READ_EXTERNAL_STORAGE")) {
                Snackbar.make(findViewById(16908290), "Please Grant Permissions to upload profile photo", -2).setAction("ENABLE", new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.Fakeprofile.GBWhats_FakeProfileActivity.1
                    @RequiresApi(api = Build.VERSION_CODES.M)
                    @Override
                    public void onClick(View view) {
                        GBWhats_FakeProfileActivity.this.requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"}, 123);
                    }
                }).show();
            } else {
                requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"}, 123);
            }
        }
    }

    private void findView() {
        this.f191i = (EditText) findViewById(R.id.et_entername);
        this.f192j = (TextView) findViewById(R.id.et_lastseen);
        this.f193k = (EditText) findViewById(R.id.et_status);
        this.f194l = (TextView) findViewById(R.id.et_statusdate);
        this.f195m = (EditText) findViewById(R.id.et_mobilenum);
        this.f196n = (CircleImageView) findViewById(R.id.profile);
        this.f197o = (ImageView) findViewById(R.id.btn_selectphoto);
        this.f198p = (ImageView) findViewById(R.id.btn_done);
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i2 == -1 && i == 2) {
            Uri data = intent.getData();
            selectedImageUri = data;
            if (data == null) {
                return;
            }
            this.f196n.setImageURI(data);
        }
    }

    @Override
    public void onBackPressed() {
        GBWhats_FakeProfileActivity.this.finish();
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.gbwhats_activity_fake_profile);
        ((TextView) findViewById(R.id.tx_nm)).setText("Fake Profile");
        this.f190h = (ImageView) findViewById(R.id.back);
        getWindow().setFlags(1024, 1024);
        if (Build.VERSION.SDK_INT >= 23) {
            checkPermission();
        }
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GBWhats_FakeProfileActivity.super.onBackPressed();
            }
        });
        findView();
        this.f192j.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                int i = calendar.get(11);
                int i2 = calendar.get(12);
                GBWhats_FakeProfileActivity.this.mTimePicker = new TimePickerDialog(GBWhats_FakeProfileActivity.this, new TimePickerDialog.OnTimeSetListener() { // from class: com.statussaver.wacaption.gbversion.Fakeprofile.GBWhats_FakeProfileActivity.4.1
                    @Override
                    public void onTimeSet(TimePicker timePicker, int i3, int i4) {
                        TextView textView = GBWhats_FakeProfileActivity.this.f192j;
                        textView.setText(i3 + ":" + i4);
                    }
                }, i, i2, true);
                GBWhats_FakeProfileActivity.this.mTimePicker.setTitle("Select Time");
                GBWhats_FakeProfileActivity.this.mTimePicker.show();
            }
        });
        this.f194l.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                new DatePickerDialog(GBWhats_FakeProfileActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i2, int i3) {
                        GBWhats_FakeProfileActivity.this.f194l.setText("-" + String.valueOf(i) + "-" + String.valueOf(i2) + "-" + String.valueOf(i3));
                    }
                }, calendar.get(1), calendar.get(2), calendar.get(5)).show();
            }
        });
        this.f197o.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GBWhats_FakeProfileActivity.this.startActivityForResult(Intent.createChooser(new Intent().setAction("android.intent.action.PICK").setType("image/*"), "Selecting Image"), 2);
            }
        });
        this.f198p.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (GBWhats_FakeProfileActivity.this.f191i.getText().toString().isEmpty()) {
                    GBWhats_FakeProfileActivity.this.f191i.setError("Name Should not be blank");
                } else if (GBWhats_FakeProfileActivity.this.f192j.getText().toString().isEmpty()) {
                    GBWhats_FakeProfileActivity.this.f192j.setError("Last seen Should not be blank");
                } else if (GBWhats_FakeProfileActivity.this.f193k.getText().toString().isEmpty()) {
                    GBWhats_FakeProfileActivity.this.f193k.setError("Status Should not be blank");
                } else if (GBWhats_FakeProfileActivity.this.f194l.getText().toString().isEmpty()) {
                    GBWhats_FakeProfileActivity.this.f194l.setError("Status date Should not be blank");
                } else if (GBWhats_FakeProfileActivity.this.f195m.getText().toString().isEmpty()) {
                    GBWhats_FakeProfileActivity.this.f195m.setError("Mobile number Should not be blank");
                } else if (GBWhats_FakeProfileActivity.this.f195m.length() < 10) {
                    GBWhats_FakeProfileActivity.this.f195m.setError("Please enter valid number");
                } else {
                    GBWhats_FakeProfileActivity gBWhats_FakeProfileActivity = GBWhats_FakeProfileActivity.this;
                    gBWhats_FakeProfileActivity.f199q = gBWhats_FakeProfileActivity.f191i.getText().toString();
                    GBWhats_FakeProfileActivity gBWhats_FakeProfileActivity2 = GBWhats_FakeProfileActivity.this;
                    gBWhats_FakeProfileActivity2.f200r = gBWhats_FakeProfileActivity2.f192j.getText().toString();
                    GBWhats_FakeProfileActivity gBWhats_FakeProfileActivity3 = GBWhats_FakeProfileActivity.this;
                    gBWhats_FakeProfileActivity3.f201s = gBWhats_FakeProfileActivity3.f193k.getText().toString();
                    GBWhats_FakeProfileActivity gBWhats_FakeProfileActivity4 = GBWhats_FakeProfileActivity.this;
                    gBWhats_FakeProfileActivity4.f202t = gBWhats_FakeProfileActivity4.f194l.getText().toString();
                    GBWhats_FakeProfileActivity gBWhats_FakeProfileActivity5 = GBWhats_FakeProfileActivity.this;
                    gBWhats_FakeProfileActivity5.f203u = gBWhats_FakeProfileActivity5.f195m.getText().toString();
                    Intent intent = new Intent(GBWhats_FakeProfileActivity.this, GBWhats_ProfileShowActivity.class);
                    intent.putExtra("lastseen", GBWhats_FakeProfileActivity.this.f200r);
                    intent.putExtra("status", GBWhats_FakeProfileActivity.this.f201s);
                    intent.putExtra("statusdate", GBWhats_FakeProfileActivity.this.f202t);
                    intent.putExtra("number", GBWhats_FakeProfileActivity.this.f203u);
                    GBWhats_FakeProfileActivity.this.startActivity(intent);
                }
            }
        });
        this.f190h.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GBWhats_FakeProfileActivity.this.onBackPressed();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i != 123 || iArr.length <= 0) {
            return;
        }
        boolean z = true;
        boolean z2 = iArr[1] == 0;
        if (iArr[0] != 0) {
            z = false;
        }
        if (z2 && z) {
            return;
        }
        Snackbar.make(findViewById(16908290), "Please Grant Permissions to upload profile photo", -2).setAction("ENABLE", new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.Fakeprofile.GBWhats_FakeProfileActivity.9
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                GBWhats_FakeProfileActivity.this.requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"}, 123);
            }
        }).show();
    }
}
