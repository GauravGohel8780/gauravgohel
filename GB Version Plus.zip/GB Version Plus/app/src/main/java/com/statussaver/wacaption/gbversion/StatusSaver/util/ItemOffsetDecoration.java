package com.statussaver.wacaption.gbversion.StatusSaver.util;

import android.content.Context;
import android.graphics.Rect;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

/* loaded from: classes3.dex */
public class ItemOffsetDecoration extends RecyclerView.ItemDecoration {
    private int mItemOffset;

    public ItemOffsetDecoration(int i) {
        this.mItemOffset = i;
    }

    public ItemOffsetDecoration(Context context, int i) {
        this(context.getResources().getDimensionPixelSize(i));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.ItemDecoration
    public void getItemOffsets(Rect rect, View view, RecyclerView recyclerView, RecyclerView.State state) {
        super.getItemOffsets(rect, view, recyclerView, state);
        int i = this.mItemOffset;
        rect.set(i, i, i, i);
    }
}
