package com.statussaver.wacaption.gbversion.WhatsShake;

import android.content.pm.PackageManager;

/* loaded from: classes3.dex */
public class GBWhats_Internetconnection {
    public static boolean isPackageInstalled(String str, PackageManager packageManager) {
        try {
            packageManager.getPackageInfo(str, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }
}
