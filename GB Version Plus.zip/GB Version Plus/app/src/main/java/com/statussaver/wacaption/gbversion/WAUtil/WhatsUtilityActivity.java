package com.statussaver.wacaption.gbversion.WAUtil;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.exifinterface.media.ExifInterface;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.StatusSaver.util.WhitelistCheck;
import com.statussaver.wacaption.gbversion.newwautl.CleanDataActivity;
import com.statussaver.wacaption.gbversion.newwautl.Utils;
import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes3.dex */
public class WhatsUtilityActivity extends AppCompatActivity {
    private Activity activity;
    File audioFile;
    File audioSendFile;
    ImageView back;
    List<String> backUpArray;
    File backUpFile;
    ImageView imgDelAll;
    ImageView imgDelAudio;
    ImageView imgDelBackUp;
    ImageView imgDelImage;
    ImageView imgDelProfile;
    ImageView imgDelStatus;
    ImageView imgDelVideo;
    ImageView imgDelVoice;
    ImageView imgDelWall;
    File imgFile;
    File imgSend;
    LinearLayout layForAudio;
    LinearLayout layForBackUp;
    LinearLayout layForImage;
    LinearLayout layForProfile;
    LinearLayout layForStatus;
    LinearLayout layForVideo;
    LinearLayout layForVoice;
    LinearLayout layForWallapaper;
    ProgressDialog mProDialog;
    List<String> proArray;
    File profileFile;
    List<String> recImgeArray;
    List<String> recVideoArray;
    List<String> sendAudioArray;
    List<String> sendImgeArray;
    List<String> sendVideoArray;
    int sizeOfAudio;
    int sizeOfImage;
    int sizeOfVideo;
    File status;
    List<String> statusArray;
    TextView txtTotAudFile;
    TextView txtTotAudSize;
    TextView txtTotBpFile;
    TextView txtTotBpSize;
    TextView txtTotImgFile;
    TextView txtTotImgSize;
    TextView txtTotProfileFile;
    TextView txtTotProfileSize;
    TextView txtTotVidFile;
    TextView txtTotVidSize;
    TextView txtTotVoicFile;
    TextView txtTotVoicSize;
    TextView txtTotWalFile;
    TextView txtTotWalSize;
    TextView txtTotalFile;
    TextView txtTotalSize;
    TextView txtTotalStatusFile;
    TextView txtTotalStatusSize;
    File videoFile;
    File videoSendFile;
    List<String> voiceArray;
    File voiceFile;
    List<String> wallapaperArray;
    File wallpaperFile;
    long sizeAudio = 0;
    long sizeBackup = 0;
    long sizeImgage = 0;
    long sizeProfile = 0;
    long sizeStatus = 0;
    long sizeVideo = 0;
    long sizeVoice = 0;
    long sizeWallapaper = 0;

    public static String getReadableSize(long j) {
        if (j <= 0) {
            return "0";
        }
        double d = j;
        int log10 = (int) (Math.log10(d) / Math.log10(1024.0d));
        StringBuilder sb = new StringBuilder();
        DecimalFormat decimalFormat = new DecimalFormat("#,##0.#");
        double pow = Math.pow(1024.0d, log10);
        Double.isNaN(d);
        Double.isNaN(d);
        Double.isNaN(d);
        sb.append(decimalFormat.format(d / pow));
        sb.append(" ");
        sb.append(new String[]{"B", "KB", "MB", "GB", "TB"}[log10]);
        return sb.toString();
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_whats_utility);
        this.activity = this;
        this.mProDialog = new ProgressDialog(this);
        this.imgDelAll = (ImageView) findViewById(R.id.imgDelAll);
        this.back = (ImageView) findViewById(R.id.back);
        this.imgDelImage = (ImageView) findViewById(R.id.imgDelImage);
        this.imgDelVideo = (ImageView) findViewById(R.id.imgDelVideo);
        this.imgDelStatus = (ImageView) findViewById(R.id.imgDelStatus);
        this.imgDelProfile = (ImageView) findViewById(R.id.imgDelProfile);
        this.imgDelAudio = (ImageView) findViewById(R.id.imgDelAudio);
        this.imgDelVoice = (ImageView) findViewById(R.id.imgDelVoice);
        this.imgDelWall = (ImageView) findViewById(R.id.imgDelWall);
        this.imgDelBackUp = (ImageView) findViewById(R.id.imgDelBackUp);
        this.txtTotalSize = (TextView) findViewById(R.id.txtTotalSize);
        this.txtTotalFile = (TextView) findViewById(R.id.txtTotalFile);
        this.txtTotImgFile = (TextView) findViewById(R.id.txtTotImgFile);
        this.txtTotImgSize = (TextView) findViewById(R.id.txtTotImgSize);
        this.txtTotVidFile = (TextView) findViewById(R.id.txtTotVidFile);
        this.txtTotVidSize = (TextView) findViewById(R.id.txtTotVidSize);
        this.txtTotalStatusSize = (TextView) findViewById(R.id.txtTotalStatusSize);
        this.txtTotalStatusFile = (TextView) findViewById(R.id.txtTotalStatusFile);
        this.txtTotProfileSize = (TextView) findViewById(R.id.txtTotProfileSize);
        this.txtTotProfileFile = (TextView) findViewById(R.id.txtTotProfileFile);
        this.txtTotAudFile = (TextView) findViewById(R.id.txtTotAudFile);
        this.txtTotAudSize = (TextView) findViewById(R.id.txtTotAudSize);
        this.txtTotVoicFile = (TextView) findViewById(R.id.txtTotVoicFile);
        this.txtTotVoicSize = (TextView) findViewById(R.id.txtTotVoicSize);
        this.txtTotWalFile = (TextView) findViewById(R.id.txtTotWalFile);
        this.txtTotWalSize = (TextView) findViewById(R.id.txtTotWalSize);
        this.txtTotBpFile = (TextView) findViewById(R.id.txtTotBpFile);
        this.txtTotBpSize = (TextView) findViewById(R.id.txtTotBpSize);
        this.layForImage = (LinearLayout) findViewById(R.id.layForImage);
        this.layForVideo = (LinearLayout) findViewById(R.id.layForVideo);
        this.layForStatus = (LinearLayout) findViewById(R.id.layForStatus);
        this.layForProfile = (LinearLayout) findViewById(R.id.layForProfile);
        this.layForAudio = (LinearLayout) findViewById(R.id.layForAudio);
        this.layForVoice = (LinearLayout) findViewById(R.id.layForVoice);
        this.layForWallapaper = (LinearLayout) findViewById(R.id.layForWallapaper);
        this.layForBackUp = (LinearLayout) findViewById(R.id.layForBackUp);
//        AppManage.show_anim_header(this, (RelativeLayout) findViewById(R.id.rl_anim_header));
        this.layForImage.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                WhatsUtilityActivity whatsUtilityActivity = WhatsUtilityActivity.this;
                whatsUtilityActivity.onTapBtn(Utils.IMAGE, whatsUtilityActivity.getWhatsupFolder("WhatsApp Images"), WhatsUtilityActivity.this.getWhatsupFolder("WhatsApp Images%2FSent"));
            }
        });
        this.layForVideo.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                final Intent intent = new Intent(WhatsUtilityActivity.this, ViewAllDataActivity.class);
                intent.putExtra("active", "Videos");
                intent.putExtra("id", ExifInterface.GPS_MEASUREMENT_2D);
//                AppManage.getInstance(WhatsUtilityActivity.this.activity).showInterstitialAd(WhatsUtilityActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.2.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        WhatsUtilityActivity.this.startActivity(intent);
                        WhatsUtilityActivity.this.finish();
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        this.layForStatus.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                final Intent intent = new Intent(WhatsUtilityActivity.this, ViewAllDataActivity.class);
                intent.putExtra("active", "Status");
                intent.putExtra("id", ExifInterface.GPS_MEASUREMENT_3D);
//                AppManage.getInstance(WhatsUtilityActivity.this.activity).showInterstitialAd(WhatsUtilityActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.3.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        WhatsUtilityActivity.this.startActivity(intent);
                        WhatsUtilityActivity.this.finish();
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        this.layForProfile.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                final Intent intent = new Intent(WhatsUtilityActivity.this, VoiceNoteActivity.class);
                intent.putExtra("active", "Profiles");
                intent.putExtra("id", "4");
//                AppManage.getInstance(WhatsUtilityActivity.this.activity).showInterstitialAd(WhatsUtilityActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.4.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        WhatsUtilityActivity.this.startActivity(intent);
                        WhatsUtilityActivity.this.finish();
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        this.layForAudio.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                final Intent intent = new Intent(WhatsUtilityActivity.this, ViewAllDataActivity.class);
                intent.putExtra("active", "Audios");
                intent.putExtra("id", "5");
//                AppManage.getInstance(WhatsUtilityActivity.this.activity).showInterstitialAd(WhatsUtilityActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.5.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        WhatsUtilityActivity.this.startActivity(intent);
                        WhatsUtilityActivity.this.finish();
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        this.layForVoice.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                final Intent intent = new Intent(WhatsUtilityActivity.this, VoiceNoteActivity.class);
                intent.putExtra("active", "Voice Notes");
                intent.putExtra("id", "6");
//                AppManage.getInstance(WhatsUtilityActivity.this.activity).showInterstitialAd(WhatsUtilityActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.6.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        WhatsUtilityActivity.this.startActivity(intent);
                        WhatsUtilityActivity.this.finish();
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        this.layForWallapaper.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                final Intent intent = new Intent(WhatsUtilityActivity.this, VoiceNoteActivity.class);
                intent.putExtra("active", "Wallpapers");
                intent.putExtra("id", "7");
//                AppManage.getInstance(WhatsUtilityActivity.this.activity).showInterstitialAd(WhatsUtilityActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.7.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        WhatsUtilityActivity.this.startActivity(intent);
                        WhatsUtilityActivity.this.finish();
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        this.layForBackUp.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.8
            public void lambda$onClick$0$SI_UtilsActivity$8(String str) {
            }

            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                final Intent intent = new Intent(WhatsUtilityActivity.this, VoiceNoteActivity.class);
                intent.putExtra("active", "Backups");
                intent.putExtra("id", "8");
//                AppManage.getInstance(WhatsUtilityActivity.this.activity).showInterstitialAd(WhatsUtilityActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.8.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        WhatsUtilityActivity.this.startActivity(intent);
                        WhatsUtilityActivity.this.finish();
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
        this.imgDelImage.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.9
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (WhatsUtilityActivity.this.txtTotImgFile.getText().toString().equals("Total Files: 0")) {
                    Toast.makeText(WhatsUtilityActivity.this, "No Media..", 0).show();
                    return;
                }
                final Dialog dialog = new Dialog(WhatsUtilityActivity.this);
                dialog.requestWindowFeature(1);
                dialog.setCancelable(true);
                dialog.setContentView(R.layout.delete_dialog);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                ((TextView) dialog.findViewById(R.id.txtDelTitle)).setText("Do you want to delete all Images?");
                ((ImageView) dialog.findViewById(R.id.btn_cancel)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.9.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.dismiss();
                    }
                });
                ((ImageView) dialog.findViewById(R.id.btn_okay)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.9.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.cancel();
                        new deleteImg().execute(new String[0]);
                    }
                });
                dialog.show();
            }
        });
        this.imgDelVideo.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.10
            @SuppressLint("WrongConstant")
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (WhatsUtilityActivity.this.txtTotVidFile.getText().toString().equals("Total Files: 0")) {
                    Toast.makeText(WhatsUtilityActivity.this, "No Media..", 0).show();
                    return;
                }
                final Dialog dialog = new Dialog(WhatsUtilityActivity.this);
                dialog.requestWindowFeature(1);
                dialog.setCancelable(true);
                dialog.setContentView(R.layout.delete_dialog);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                ((TextView) dialog.findViewById(R.id.txtDelTitle)).setText("Do you want to delete all Videos?");
                ((ImageView) dialog.findViewById(R.id.btn_cancel)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.10.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.dismiss();
                    }
                });
                ((ImageView) dialog.findViewById(R.id.btn_okay)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.10.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.cancel();
                        new deleteVideo().execute(new String[0]);
                    }
                });
                dialog.show();
            }
        });
        this.imgDelStatus.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.11
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (WhatsUtilityActivity.this.txtTotalStatusFile.getText().toString().equals("Total Files: 0")) {
                    Toast.makeText(WhatsUtilityActivity.this, "No Media..", 0).show();
                    return;
                }
                final Dialog dialog = new Dialog(WhatsUtilityActivity.this);
                dialog.requestWindowFeature(1);
                dialog.setCancelable(true);
                dialog.setContentView(R.layout.delete_dialog);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                ((TextView) dialog.findViewById(R.id.txtDelTitle)).setText("Do you want to delete all Status?");
                ((ImageView) dialog.findViewById(R.id.btn_cancel)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.11.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.dismiss();
                    }
                });
                ((ImageView) dialog.findViewById(R.id.btn_okay)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.11.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.cancel();
                        new deleteStatus().execute(new String[0]);
                    }
                });
                dialog.show();
            }
        });
        this.imgDelProfile.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.12
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (WhatsUtilityActivity.this.txtTotProfileFile.getText().toString().equals("Total Files: 0")) {
                    Toast.makeText(WhatsUtilityActivity.this, "No Media..", 0).show();
                    return;
                }
                final Dialog dialog = new Dialog(WhatsUtilityActivity.this);
                dialog.requestWindowFeature(1);
                dialog.setCancelable(true);
                dialog.setContentView(R.layout.delete_dialog);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                ((TextView) dialog.findViewById(R.id.txtDelTitle)).setText("Do you want to delete all profileFiles?");
                ((ImageView) dialog.findViewById(R.id.btn_cancel)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.12.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.dismiss();
                    }
                });
                ((ImageView) dialog.findViewById(R.id.btn_okay)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.12.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.cancel();
                        new deletePro().execute(new String[0]);
                    }
                });
                dialog.show();
            }
        });
        this.imgDelAudio.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.13
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (WhatsUtilityActivity.this.txtTotAudFile.getText().toString().equals("Total Files: 0")) {
                    Toast.makeText(WhatsUtilityActivity.this, "No Media..", 0).show();
                    return;
                }
                final Dialog dialog = new Dialog(WhatsUtilityActivity.this);
                dialog.requestWindowFeature(1);
                dialog.setCancelable(true);
                dialog.setContentView(R.layout.delete_dialog);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                ((TextView) dialog.findViewById(R.id.txtDelTitle)).setText("Do you want to delete all Audios?");
                ((ImageView) dialog.findViewById(R.id.btn_cancel)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.13.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.dismiss();
                    }
                });
                ((ImageView) dialog.findViewById(R.id.btn_okay)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.13.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.cancel();
                        new deleteAudio().execute(new String[0]);
                    }
                });
                dialog.show();
            }
        });
        this.imgDelVoice.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.14
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (WhatsUtilityActivity.this.txtTotVoicFile.getText().toString().equals("Total Files: 0")) {
                    Toast.makeText(WhatsUtilityActivity.this, "No Media..", 0).show();
                    return;
                }
                final Dialog dialog = new Dialog(WhatsUtilityActivity.this);
                dialog.requestWindowFeature(1);
                dialog.setCancelable(true);
                dialog.setContentView(R.layout.delete_dialog);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                ((TextView) dialog.findViewById(R.id.txtDelTitle)).setText("Do you want to delete all Voice Notes?");
                ((ImageView) dialog.findViewById(R.id.btn_cancel)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.14.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.dismiss();
                    }
                });
                ((ImageView) dialog.findViewById(R.id.btn_okay)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.14.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.cancel();
                        new deleteVoice().execute(new String[0]);
                    }
                });
                dialog.show();
            }
        });
        this.imgDelWall.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.15
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (WhatsUtilityActivity.this.txtTotWalFile.getText().toString().equals("Total Files: 0")) {
                    Toast.makeText(WhatsUtilityActivity.this, "No Media..", 0).show();
                    return;
                }
                final Dialog dialog = new Dialog(WhatsUtilityActivity.this);
                dialog.requestWindowFeature(1);
                dialog.setCancelable(true);
                dialog.setContentView(R.layout.delete_dialog);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                ((TextView) dialog.findViewById(R.id.txtDelTitle)).setText("Do you want to delete all Wallpapers?");
                ((ImageView) dialog.findViewById(R.id.btn_cancel)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.15.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.dismiss();
                    }
                });
                ((ImageView) dialog.findViewById(R.id.btn_okay)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.15.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.cancel();
                        new deleteWall().execute(new String[0]);
                    }
                });
                dialog.show();
            }
        });
        this.imgDelBackUp.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.16
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (WhatsUtilityActivity.this.txtTotBpFile.getText().toString().equals("Total Files: 0")) {
                    Toast.makeText(WhatsUtilityActivity.this, "No Media..", 0).show();
                    return;
                }
                final Dialog dialog = new Dialog(WhatsUtilityActivity.this);
                dialog.requestWindowFeature(1);
                dialog.setCancelable(true);
                dialog.setContentView(R.layout.delete_dialog);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                ((TextView) dialog.findViewById(R.id.txtDelTitle)).setText("Do you want to delete all Backups?");
                ((ImageView) dialog.findViewById(R.id.btn_cancel)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.16.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.dismiss();
                    }
                });
                ((ImageView) dialog.findViewById(R.id.btn_okay)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.16.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.cancel();
                        new deleteBackups().execute(new String[0]);
                    }
                });
                dialog.show();
            }
        });
        this.imgDelAll.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.17
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (WhatsUtilityActivity.this.txtTotalSize.getText().toString().equals("0")) {
                    Toast.makeText(WhatsUtilityActivity.this, "No Media..", 0).show();
                    return;
                }
                final Dialog dialog = new Dialog(WhatsUtilityActivity.this);
                dialog.requestWindowFeature(1);
                dialog.setCancelable(true);
                dialog.setContentView(R.layout.delete_dialog);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                ((TextView) dialog.findViewById(R.id.txtDelTitle)).setText("Do you want to delete all files?");
                ((ImageView) dialog.findViewById(R.id.btn_cancel)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.17.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.dismiss();
                    }
                });
                ((ImageView) dialog.findViewById(R.id.btn_okay)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.17.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.cancel();
                        new deleteAll().execute(new String[0]);
                    }
                });
                dialog.show();
            }
        });
        this.back.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.18
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                WhatsUtilityActivity.this.onBackPressed();
            }
        });
        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "/WhatsApp");
        this.imgFile = new File(file.getAbsolutePath(), "/Media/WhatsApp Images");
        File file2 = new File("/storage/emulated/0/WhatsApp/Media/WhatsApp Images/Sent");
        this.imgSend = file2;
        File[] listFiles = file2.listFiles();
        this.sendImgeArray = new ArrayList();
        if (listFiles != null) {
            for (int i = 0; i < listFiles.length; i++) {
                if (listFiles[i].getPath().endsWith(".jpg") || listFiles[i].getPath().endsWith(".png") || listFiles[i].getPath().endsWith(".jpeg")) {
                    this.sendImgeArray.add(listFiles[i].getPath());
                    this.sizeImgage += listFiles[i].length();
                }
            }
        }
        File[] listFiles2 = this.imgFile.listFiles();
        this.recImgeArray = new ArrayList();
        if (listFiles2 != null) {
            for (int i2 = 0; i2 < listFiles2.length; i2++) {
                if (listFiles2[i2].getPath().endsWith(".jpg") || listFiles2[i2].getPath().endsWith(".png") || listFiles2[i2].getPath().endsWith(".jpeg")) {
                    this.recImgeArray.add(listFiles2[i2].getPath());
                    this.sizeImgage += listFiles2[i2].length();
                }
            }
        }
        this.videoFile = new File(file.getAbsolutePath(), "/Media/WhatsApp Video");
        File file3 = new File(this.videoFile.getAbsolutePath(), "/Sent");
        this.videoSendFile = file3;
        File[] listFiles3 = file3.listFiles();
        this.sendVideoArray = new ArrayList();
        if (listFiles3 != null) {
            for (int i3 = 0; i3 < listFiles3.length; i3++) {
                if (listFiles3[i3].getPath().endsWith(".mp4")) {
                    this.sendVideoArray.add(listFiles3[i3].getPath());
                    this.sizeVideo += listFiles3[i3].length();
                }
            }
        }
        File[] listFiles4 = this.videoFile.listFiles();
        this.recVideoArray = new ArrayList();
        if (listFiles4 != null) {
            for (int i4 = 0; i4 < listFiles4.length; i4++) {
                if (listFiles4[i4].getPath().endsWith(".mp4")) {
                    this.recVideoArray.add(listFiles4[i4].getPath());
                    this.sizeVideo += listFiles4[i4].length();
                }
            }
        }
        File file4 = new File(file.getAbsolutePath(), "/Media/.Statuses");
        this.status = file4;
        File[] listFiles5 = file4.listFiles();
        this.statusArray = new ArrayList();
        if (listFiles5 != null) {
            for (int i5 = 0; i5 < listFiles5.length; i5++) {
                if (listFiles5[i5].getPath().endsWith(".mp4") || listFiles5[i5].getPath().endsWith(".jpg") || listFiles5[i5].getPath().endsWith(".png") || listFiles5[i5].getPath().endsWith(".jpeg")) {
                    this.statusArray.add(listFiles5[i5].getPath());
                    this.sizeStatus += listFiles5[i5].length();
                }
            }
        }
        File file5 = new File(file.getAbsolutePath(), "/Media/WhatsApp Profile Photos");
        this.profileFile = file5;
        File[] listFiles6 = file5.listFiles();
        this.proArray = new ArrayList();
        if (listFiles6 != null) {
            for (int i6 = 0; i6 < listFiles6.length; i6++) {
                if (listFiles6[i6].getPath().endsWith(".jpg") || listFiles6[i6].getPath().endsWith(".png") || listFiles6[i6].getPath().endsWith(".jpeg")) {
                    this.proArray.add(listFiles6[i6].getPath());
                    this.sizeProfile += listFiles6[i6].length();
                }
            }
        }
        this.audioFile = new File(file.getAbsolutePath(), "/Media/WhatsApp Audio");
        File file6 = new File(this.audioFile.getAbsolutePath(), "/Sent");
        this.audioSendFile = file6;
        file6.listFiles();
        this.sendAudioArray = new ArrayList();
        this.voiceFile = new File(file.getAbsolutePath(), "/Media/WhatsApp Voice Notes");
        this.voiceArray = new ArrayList();
        File file7 = new File(file.getAbsolutePath(), "/Media/WallPaper");
        this.wallpaperFile = file7;
        File[] listFiles7 = file7.listFiles();
        this.wallapaperArray = new ArrayList();
        if (listFiles7 != null) {
            for (int i7 = 0; i7 < listFiles7.length; i7++) {
                if (listFiles7[i7].getPath().endsWith(".jpg") || listFiles7[i7].getPath().endsWith(".png") || listFiles7[i7].getPath().endsWith(".jpeg")) {
                    this.wallapaperArray.add(listFiles7[i7].getPath());
                    this.sizeWallapaper += listFiles7[i7].length();
                }
            }
        }
        File file8 = new File(file.getAbsolutePath(), "/Databases");
        this.backUpFile = file8;
        File[] listFiles8 = file8.listFiles();
        this.backUpArray = new ArrayList();
        if (listFiles8 != null) {
            for (int i8 = 0; i8 < listFiles8.length; i8++) {
                if (listFiles8[i8].getPath().endsWith(".db.crypt12")) {
                    this.backUpArray.add(listFiles8[i8].getPath());
                    this.sizeBackup += listFiles8[i8].length();
                }
            }
        }
        this.sizeOfImage = this.sendImgeArray.size() + this.recImgeArray.size();
        this.txtTotImgFile.setText("Total Files: " + this.sizeOfImage);
        this.txtTotImgSize.setText("Total Size: " + getReadableSize(this.sizeImgage));
        this.sizeOfVideo = this.sendVideoArray.size() + this.recVideoArray.size();
        this.txtTotVidFile.setText("Total Files: " + this.sizeOfVideo);
        this.txtTotVidSize.setText("Total Size: " + getReadableSize(this.sizeVideo));
        this.txtTotalStatusFile.setText("Total Files: " + this.statusArray.size());
        this.txtTotalStatusSize.setText("Total Size: " + getReadableSize(this.sizeStatus));
        this.txtTotProfileFile.setText("Total Files: " + this.proArray.size());
        this.txtTotProfileSize.setText("Total Size: " + getReadableSize(this.sizeProfile));
        this.txtTotWalFile.setText("Total Files: " + this.wallapaperArray.size());
        this.txtTotWalSize.setText("Total Size: " + getReadableSize(this.sizeWallapaper));
        this.txtTotBpFile.setText("Total Files: " + this.backUpArray.size());
        this.txtTotBpSize.setText("Total Size: " + getReadableSize(this.sizeBackup));
        long j = this.sizeImgage + this.sizeVideo + this.sizeStatus + this.sizeProfile + this.sizeWallapaper + this.sizeBackup;
        int size = this.sizeOfImage + this.sizeOfVideo + this.statusArray.size() + this.proArray.size() + this.wallapaperArray.size() + this.backUpArray.size();
        this.txtTotalFile.setText("(" + size + " files found)");
        this.txtTotalSize.setText(getReadableSize(j));
    }

    public String getWhatsupFolder(String str) {
        if (new File(Environment.getExternalStorageDirectory() + File.separator + "Android/media/com.whatsapp/WhatsApp" + File.separator + "Media").isDirectory()) {
            return "Android%2Fmedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F" + str;
        }
        return "WhatsApp%2FMedia%2F" + str;
    }

    public void deleteAudioFile(String str) {
        File[] listFiles;
        if (str != null) {
            try {
                for (File file : new File(str).listFiles()) {
                    if (file.isFile()) {
                        if (!file.getName().equalsIgnoreCase(".nomedia")) {
                            file.delete();
                        }
                    } else if (file.isDirectory()) {
                        deleteAudioFile(file.getAbsolutePath());
                    }
                }
                return;
            } catch (Exception e) {
                e.printStackTrace();
                return;
            }
        }
        Toast.makeText(this, "No Audio Files..", 0).show();
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
//        AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.19
//            @Override // com.pesonal.adsdk.MyCallback
//            public void callbackCall() {
                WhatsUtilityActivity.this.finish();
//            }
//        }, AppManage.app_mainClickCntSwAd);
    }

    /* loaded from: classes3.dex */
    public class deleteImg extends AsyncTask<String, String, String> {
        public deleteImg() {

        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            super.onPreExecute();
            WhatsUtilityActivity.this.mProDialog.setMessage("Please Wait...!!");
            WhatsUtilityActivity.this.mProDialog.setProgressStyle(0);
            WhatsUtilityActivity.this.mProDialog.setIndeterminate(true);
            WhatsUtilityActivity.this.mProDialog.setProgress(0);
            WhatsUtilityActivity.this.mProDialog.setCancelable(false);
            WhatsUtilityActivity.this.mProDialog.show();
        }

        public String doInBackground(String... strArr) {
            if (WhatsUtilityActivity.this.imgFile.isDirectory()) {
                for (String str : WhatsUtilityActivity.this.imgFile.list()) {
                    new File(WhatsUtilityActivity.this.imgFile, str).delete();
                }
            }
            if (!WhatsUtilityActivity.this.imgSend.isDirectory()) {
                return null;
            }
            for (String str2 : WhatsUtilityActivity.this.imgSend.list()) {
                new File(WhatsUtilityActivity.this.imgSend, str2).delete();
            }
            return null;
        }

        public void onPostExecute(String str) {
            super.onPostExecute(String.valueOf(String.valueOf(str)));
            WhatsUtilityActivity.this.txtTotImgFile.setText("Total Files: 0");
            WhatsUtilityActivity.this.txtTotImgSize.setText("Total Size: 0");
            long j = ((((WhatsUtilityActivity.this.sizeVideo + WhatsUtilityActivity.this.sizeStatus) + WhatsUtilityActivity.this.sizeProfile) + WhatsUtilityActivity.this.sizeWallapaper) + WhatsUtilityActivity.this.sizeBackup) - WhatsUtilityActivity.this.sizeImgage;
            int size = ((((WhatsUtilityActivity.this.sizeOfVideo + WhatsUtilityActivity.this.statusArray.size()) + WhatsUtilityActivity.this.proArray.size()) + WhatsUtilityActivity.this.wallapaperArray.size()) + WhatsUtilityActivity.this.backUpArray.size()) - WhatsUtilityActivity.this.sizeOfImage;
            TextView textView = WhatsUtilityActivity.this.txtTotalFile;
            textView.setText("(" + size + " files found)");
            WhatsUtilityActivity.this.txtTotalSize.setText(WhatsUtilityActivity.getReadableSize(j));
            WhatsUtilityActivity.this.mProDialog.dismiss();
            Toast.makeText(WhatsUtilityActivity.this, "Deleted Succesfully", 0).show();
        }
    }

    /* loaded from: classes3.dex */
    public class deleteVideo extends AsyncTask<String, String, String> {
        public deleteVideo() {

        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            super.onPreExecute();
            WhatsUtilityActivity.this.mProDialog.setMessage("Please Wait...!!");
            WhatsUtilityActivity.this.mProDialog.setProgressStyle(0);
            WhatsUtilityActivity.this.mProDialog.setIndeterminate(true);
            WhatsUtilityActivity.this.mProDialog.setProgress(0);
            WhatsUtilityActivity.this.mProDialog.setCancelable(false);
            WhatsUtilityActivity.this.mProDialog.show();
        }

        public String doInBackground(String... strArr) {
            if (WhatsUtilityActivity.this.videoFile.isDirectory()) {
                for (String str : WhatsUtilityActivity.this.videoFile.list()) {
                    new File(WhatsUtilityActivity.this.videoFile, str).delete();
                }
            }
            if (!WhatsUtilityActivity.this.videoSendFile.isDirectory()) {
                return null;
            }
            for (String str2 : WhatsUtilityActivity.this.videoSendFile.list()) {
                new File(WhatsUtilityActivity.this.videoSendFile, str2).delete();
            }
            return null;
        }

        public void onPostExecute(String str) {
            super.onPostExecute( str);
            WhatsUtilityActivity.this.txtTotVidFile.setText("Total Files: 0");
            WhatsUtilityActivity.this.txtTotVidSize.setText("Total Size: 0");
            long j = (WhatsUtilityActivity.this.sizeImgage - WhatsUtilityActivity.this.sizeVideo) + WhatsUtilityActivity.this.sizeStatus + WhatsUtilityActivity.this.sizeProfile + WhatsUtilityActivity.this.sizeWallapaper + WhatsUtilityActivity.this.sizeBackup;
            int size = (WhatsUtilityActivity.this.sizeOfImage - WhatsUtilityActivity.this.sizeOfVideo) + WhatsUtilityActivity.this.statusArray.size() + WhatsUtilityActivity.this.proArray.size() + WhatsUtilityActivity.this.wallapaperArray.size() + WhatsUtilityActivity.this.backUpArray.size();
            TextView textView = WhatsUtilityActivity.this.txtTotalFile;
            textView.setText("(" + size + " files found)");
            WhatsUtilityActivity.this.txtTotalSize.setText(WhatsUtilityActivity.getReadableSize(j));
            WhatsUtilityActivity.this.mProDialog.dismiss();
            Toast.makeText(WhatsUtilityActivity.this, "Deleted Succesfully", 0).show();
        }
    }

    /* loaded from: classes3.dex */
    public class deleteStatus extends AsyncTask<String, String, String> {
        public deleteStatus() {

        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            super.onPreExecute();
            WhatsUtilityActivity.this.mProDialog.setMessage("Please Wait...!!");
            WhatsUtilityActivity.this.mProDialog.setProgressStyle(0);
            WhatsUtilityActivity.this.mProDialog.setIndeterminate(true);
            WhatsUtilityActivity.this.mProDialog.setProgress(0);
            WhatsUtilityActivity.this.mProDialog.setCancelable(false);
            WhatsUtilityActivity.this.mProDialog.show();
        }

        public String doInBackground(String... strArr) {
            if (!WhatsUtilityActivity.this.status.isDirectory()) {
                return null;
            }
            for (String str : WhatsUtilityActivity.this.status.list()) {
                new File(WhatsUtilityActivity.this.status, str).delete();
            }
            return null;
        }

        public void onPostExecute(String str) {
            super.onPostExecute( str);
            WhatsUtilityActivity.this.txtTotalStatusFile.setText("Total Files: 0");
            WhatsUtilityActivity.this.txtTotalStatusSize.setText("Total Size: 0");
            long j = ((WhatsUtilityActivity.this.sizeImgage + WhatsUtilityActivity.this.sizeVideo) - WhatsUtilityActivity.this.sizeStatus) + WhatsUtilityActivity.this.sizeProfile + WhatsUtilityActivity.this.sizeWallapaper + WhatsUtilityActivity.this.sizeBackup;
            int size = ((WhatsUtilityActivity.this.sizeOfImage + WhatsUtilityActivity.this.sizeOfVideo) - WhatsUtilityActivity.this.statusArray.size()) + WhatsUtilityActivity.this.proArray.size() + WhatsUtilityActivity.this.wallapaperArray.size() + WhatsUtilityActivity.this.backUpArray.size();
            TextView textView = WhatsUtilityActivity.this.txtTotalFile;
            textView.setText("(" + size + " files found)");
            WhatsUtilityActivity.this.txtTotalSize.setText(WhatsUtilityActivity.getReadableSize(j));
            WhatsUtilityActivity.this.mProDialog.dismiss();
            Toast.makeText(WhatsUtilityActivity.this, "Deleted Succesfully", 0).show();
        }
    }

    /* loaded from: classes3.dex */
    public class deletePro extends AsyncTask<String, String, String> {
        public deletePro() {

        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            super.onPreExecute();
            WhatsUtilityActivity.this.mProDialog.setMessage("Please Wait...!!");
            WhatsUtilityActivity.this.mProDialog.setProgressStyle(0);
            WhatsUtilityActivity.this.mProDialog.setIndeterminate(true);
            WhatsUtilityActivity.this.mProDialog.setProgress(0);
            WhatsUtilityActivity.this.mProDialog.setCancelable(false);
            WhatsUtilityActivity.this.mProDialog.show();
        }

        public String doInBackground(String... strArr) {
            if (!WhatsUtilityActivity.this.profileFile.isDirectory()) {
                return null;
            }
            for (String str : WhatsUtilityActivity.this.profileFile.list()) {
                new File(WhatsUtilityActivity.this.profileFile, str).delete();
            }
            return null;
        }

        public void onPostExecute(String str) {
            super.onPostExecute( str);
            WhatsUtilityActivity.this.txtTotProfileFile.setText("Total Files: 0");
            WhatsUtilityActivity.this.txtTotProfileSize.setText("Total Size: 0");
            long j = (((WhatsUtilityActivity.this.sizeImgage + WhatsUtilityActivity.this.sizeVideo) + WhatsUtilityActivity.this.sizeStatus) - WhatsUtilityActivity.this.sizeProfile) + WhatsUtilityActivity.this.sizeWallapaper + WhatsUtilityActivity.this.sizeBackup;
            int size = (((WhatsUtilityActivity.this.sizeOfImage + WhatsUtilityActivity.this.sizeOfVideo) + WhatsUtilityActivity.this.statusArray.size()) - WhatsUtilityActivity.this.proArray.size()) + WhatsUtilityActivity.this.wallapaperArray.size() + WhatsUtilityActivity.this.backUpArray.size();
            TextView textView = WhatsUtilityActivity.this.txtTotalFile;
            textView.setText("(" + size + " files found)");
            WhatsUtilityActivity.this.txtTotalSize.setText(WhatsUtilityActivity.getReadableSize(j));
            WhatsUtilityActivity.this.mProDialog.dismiss();
            Toast.makeText(WhatsUtilityActivity.this, "Deleted Succesfully", 0).show();
        }
    }

    /* loaded from: classes3.dex */
    public class deleteAudio extends AsyncTask<String, String, String> {
        public deleteAudio() {

        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            super.onPreExecute();
            WhatsUtilityActivity.this.mProDialog.setMessage("Please Wait...!!");
            WhatsUtilityActivity.this.mProDialog.setProgressStyle(0);
            WhatsUtilityActivity.this.mProDialog.setIndeterminate(true);
            WhatsUtilityActivity.this.mProDialog.setProgress(0);
            WhatsUtilityActivity.this.mProDialog.setCancelable(false);
            WhatsUtilityActivity.this.mProDialog.show();
        }

        public String doInBackground(String... strArr) {
            if (WhatsUtilityActivity.this.audioFile.isDirectory()) {
                for (String str : WhatsUtilityActivity.this.audioFile.list()) {
                    new File(WhatsUtilityActivity.this.audioFile, str).delete();
                }
            }
            if (!WhatsUtilityActivity.this.audioSendFile.isDirectory()) {
                return null;
            }
            for (String str2 : WhatsUtilityActivity.this.audioSendFile.list()) {
                new File(WhatsUtilityActivity.this.audioSendFile, str2).delete();
            }
            return null;
        }

        public void onPostExecute(String str) {
            super.onPostExecute( str);
            WhatsUtilityActivity.this.txtTotAudFile.setText("Total Files: 0");
            WhatsUtilityActivity.this.txtTotAudSize.setText("Total Size: 0");
            long j = WhatsUtilityActivity.this.sizeImgage + WhatsUtilityActivity.this.sizeVideo + WhatsUtilityActivity.this.sizeStatus + WhatsUtilityActivity.this.sizeProfile + WhatsUtilityActivity.this.sizeWallapaper + WhatsUtilityActivity.this.sizeBackup;
            int size = WhatsUtilityActivity.this.sizeOfImage + WhatsUtilityActivity.this.sizeOfVideo + WhatsUtilityActivity.this.statusArray.size() + WhatsUtilityActivity.this.proArray.size() + WhatsUtilityActivity.this.wallapaperArray.size() + WhatsUtilityActivity.this.backUpArray.size();
            TextView textView = WhatsUtilityActivity.this.txtTotalFile;
            textView.setText("(" + size + " files found)");
            WhatsUtilityActivity.this.txtTotalSize.setText(WhatsUtilityActivity.getReadableSize(j));
            WhatsUtilityActivity.this.mProDialog.dismiss();
            Toast.makeText(WhatsUtilityActivity.this, "Deleted Succesfully", 0).show();
        }
    }

    /* loaded from: classes3.dex */
    public class deleteVoice extends AsyncTask<String, String, String> {
        public deleteVoice() {

        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            super.onPreExecute();
            WhatsUtilityActivity.this.mProDialog.setMessage("Please Wait...!!");
            WhatsUtilityActivity.this.mProDialog.setProgressStyle(0);
            WhatsUtilityActivity.this.mProDialog.setIndeterminate(true);
            WhatsUtilityActivity.this.mProDialog.setProgress(0);
            WhatsUtilityActivity.this.mProDialog.setCancelable(false);
            WhatsUtilityActivity.this.mProDialog.show();
        }

        public String doInBackground(String... strArr) {
            if (WhatsUtilityActivity.this.voiceFile.isDirectory()) {
                for (String str : WhatsUtilityActivity.this.voiceFile.list()) {
                    new File(WhatsUtilityActivity.this.voiceFile, str).delete();
                }
            }
            WhatsUtilityActivity whatsUtilityActivity = WhatsUtilityActivity.this;
            whatsUtilityActivity.deleteAudioFile(whatsUtilityActivity.voiceFile.getAbsolutePath());
            return null;
        }

        public void onPostExecute(String str) {
            super.onPostExecute( str);
            WhatsUtilityActivity.this.txtTotVoicFile.setText("Total Files: 0");
            WhatsUtilityActivity.this.txtTotVoicSize.setText("Total Size: 0");
            long j = WhatsUtilityActivity.this.sizeImgage + WhatsUtilityActivity.this.sizeVideo + WhatsUtilityActivity.this.sizeStatus + WhatsUtilityActivity.this.sizeProfile + WhatsUtilityActivity.this.sizeWallapaper + WhatsUtilityActivity.this.sizeBackup;
            int size = WhatsUtilityActivity.this.sizeOfImage + WhatsUtilityActivity.this.sizeOfVideo + WhatsUtilityActivity.this.statusArray.size() + WhatsUtilityActivity.this.proArray.size() + WhatsUtilityActivity.this.wallapaperArray.size() + WhatsUtilityActivity.this.backUpArray.size();
            TextView textView = WhatsUtilityActivity.this.txtTotalFile;
            textView.setText("(" + size + " files found)");
            WhatsUtilityActivity.this.txtTotalSize.setText(WhatsUtilityActivity.getReadableSize(j));
            WhatsUtilityActivity.this.mProDialog.dismiss();
            Toast.makeText(WhatsUtilityActivity.this, "Deleted Succesfully", 0).show();
        }
    }

    /* loaded from: classes3.dex */
    public class deleteWall extends AsyncTask<String, String, String> {
        public deleteWall() {

        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            super.onPreExecute();
            WhatsUtilityActivity.this.mProDialog.setMessage("Please Wait...!!");
            WhatsUtilityActivity.this.mProDialog.setProgressStyle(0);
            WhatsUtilityActivity.this.mProDialog.setIndeterminate(true);
            WhatsUtilityActivity.this.mProDialog.setProgress(0);
            WhatsUtilityActivity.this.mProDialog.setCancelable(false);
            WhatsUtilityActivity.this.mProDialog.show();
        }

        public String doInBackground(String... strArr) {
            if (!WhatsUtilityActivity.this.wallpaperFile.isDirectory()) {
                return null;
            }
            for (String str : WhatsUtilityActivity.this.wallpaperFile.list()) {
                new File(WhatsUtilityActivity.this.wallpaperFile, str).delete();
            }
            return null;
        }

        public void onPostExecute(String str) {
            super.onPostExecute( str);
            WhatsUtilityActivity.this.txtTotWalFile.setText("Total Files: 0");
            WhatsUtilityActivity.this.txtTotWalSize.setText("Total Size: 0");
            long j = WhatsUtilityActivity.this.sizeImgage + WhatsUtilityActivity.this.sizeVideo + WhatsUtilityActivity.this.sizeStatus + WhatsUtilityActivity.this.sizeProfile + WhatsUtilityActivity.this.sizeWallapaper + WhatsUtilityActivity.this.sizeBackup;
            int size = WhatsUtilityActivity.this.sizeOfImage + WhatsUtilityActivity.this.sizeOfVideo + WhatsUtilityActivity.this.statusArray.size() + WhatsUtilityActivity.this.proArray.size() + WhatsUtilityActivity.this.wallapaperArray.size() + WhatsUtilityActivity.this.backUpArray.size();
            TextView textView = WhatsUtilityActivity.this.txtTotalFile;
            textView.setText("(" + size + " files found)");
            WhatsUtilityActivity.this.txtTotalSize.setText(WhatsUtilityActivity.getReadableSize(j));
            WhatsUtilityActivity.this.mProDialog.dismiss();
            Toast.makeText(WhatsUtilityActivity.this, "Deleted Succesfully", 0).show();
        }
    }

    /* loaded from: classes3.dex */
    public class deleteBackups extends AsyncTask<String, String, String> {
        public deleteBackups() {

        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            super.onPreExecute();
            WhatsUtilityActivity.this.mProDialog.setMessage("Please Wait...!!");
            WhatsUtilityActivity.this.mProDialog.setProgressStyle(0);
            WhatsUtilityActivity.this.mProDialog.setIndeterminate(true);
            WhatsUtilityActivity.this.mProDialog.setProgress(0);
            WhatsUtilityActivity.this.mProDialog.setCancelable(false);
            WhatsUtilityActivity.this.mProDialog.show();
        }

        public String doInBackground(String... strArr) {
            if (!WhatsUtilityActivity.this.backUpFile.isDirectory()) {
                return null;
            }
            for (String str : WhatsUtilityActivity.this.backUpFile.list()) {
                new File(WhatsUtilityActivity.this.backUpFile, str).delete();
            }
            return null;
        }

        public void onPostExecute(String str) {
            super.onPostExecute( str);
            WhatsUtilityActivity.this.txtTotBpFile.setText("Total Files: 0");
            WhatsUtilityActivity.this.txtTotBpSize.setText("Total Size: 0");
            long j = ((((WhatsUtilityActivity.this.sizeImgage + WhatsUtilityActivity.this.sizeVideo) + WhatsUtilityActivity.this.sizeStatus) + WhatsUtilityActivity.this.sizeProfile) + WhatsUtilityActivity.this.sizeWallapaper) - WhatsUtilityActivity.this.sizeBackup;
            int size = ((((WhatsUtilityActivity.this.sizeOfImage + WhatsUtilityActivity.this.sizeOfVideo) + WhatsUtilityActivity.this.statusArray.size()) + WhatsUtilityActivity.this.proArray.size()) + WhatsUtilityActivity.this.wallapaperArray.size()) - WhatsUtilityActivity.this.backUpArray.size();
            TextView textView = WhatsUtilityActivity.this.txtTotalFile;
            textView.setText("(" + size + " files found)");
            WhatsUtilityActivity.this.txtTotalSize.setText(WhatsUtilityActivity.getReadableSize(j));
            WhatsUtilityActivity.this.mProDialog.dismiss();
            Toast.makeText(WhatsUtilityActivity.this, "Deleted Succesfully", 0).show();
        }
    }

    /* loaded from: classes3.dex */
    public class deleteAll extends AsyncTask<String, String, String> {
        public deleteAll() {

        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            super.onPreExecute();
            WhatsUtilityActivity.this.mProDialog.setMessage("Please Wait...!!");
            WhatsUtilityActivity.this.mProDialog.setProgressStyle(0);
            WhatsUtilityActivity.this.mProDialog.setIndeterminate(true);
            WhatsUtilityActivity.this.mProDialog.setProgress(0);
            WhatsUtilityActivity.this.mProDialog.setCancelable(false);
            WhatsUtilityActivity.this.mProDialog.show();
        }

        public String doInBackground(String... strArr) {
            if (WhatsUtilityActivity.this.imgFile.isDirectory()) {
                for (String str : WhatsUtilityActivity.this.imgFile.list()) {
                    new File(WhatsUtilityActivity.this.imgFile, str).delete();
                }
            }
            if (WhatsUtilityActivity.this.imgSend.isDirectory()) {
                for (String str2 : WhatsUtilityActivity.this.imgSend.list()) {
                    new File(WhatsUtilityActivity.this.imgSend, str2).delete();
                }
            }
            if (WhatsUtilityActivity.this.videoFile.isDirectory()) {
                for (String str3 : WhatsUtilityActivity.this.videoFile.list()) {
                    new File(WhatsUtilityActivity.this.videoFile, str3).delete();
                }
            }
            if (WhatsUtilityActivity.this.videoSendFile.isDirectory()) {
                for (String str4 : WhatsUtilityActivity.this.videoSendFile.list()) {
                    new File(WhatsUtilityActivity.this.videoSendFile, str4).delete();
                }
            }
            if (WhatsUtilityActivity.this.status.isDirectory()) {
                for (String str5 : WhatsUtilityActivity.this.status.list()) {
                    new File(WhatsUtilityActivity.this.status, str5).delete();
                }
            }
            if (WhatsUtilityActivity.this.profileFile.isDirectory()) {
                for (String str6 : WhatsUtilityActivity.this.profileFile.list()) {
                    new File(WhatsUtilityActivity.this.profileFile, str6).delete();
                }
            }
            if (WhatsUtilityActivity.this.wallpaperFile.isDirectory()) {
                for (String str7 : WhatsUtilityActivity.this.wallpaperFile.list()) {
                    new File(WhatsUtilityActivity.this.wallpaperFile, str7).delete();
                }
            }
            if (!WhatsUtilityActivity.this.backUpFile.isDirectory()) {
                return null;
            }
            for (String str8 : WhatsUtilityActivity.this.backUpFile.list()) {
                new File(WhatsUtilityActivity.this.backUpFile, str8).delete();
            }
            return null;
        }

        public void onPostExecute(String str) {
            super.onPostExecute( str);
            WhatsUtilityActivity.this.txtTotalFile.setText("(0 files found)");
            WhatsUtilityActivity.this.txtTotalSize.setText("0.0 KB");
            WhatsUtilityActivity.this.txtTotImgFile.setText("Total Files: 0");
            WhatsUtilityActivity.this.txtTotImgSize.setText("Total Size: 0");
            WhatsUtilityActivity.this.txtTotVidFile.setText("Total Files: 0");
            WhatsUtilityActivity.this.txtTotVidSize.setText("Total Size: 0");
            WhatsUtilityActivity.this.txtTotalStatusFile.setText("Total Files: 0");
            WhatsUtilityActivity.this.txtTotalStatusSize.setText("Total Size: 0");
            WhatsUtilityActivity.this.txtTotProfileFile.setText("Total Files: 0");
            WhatsUtilityActivity.this.txtTotProfileSize.setText("Total Size: 0");
            WhatsUtilityActivity.this.txtTotAudFile.setText("Total Files: 0");
            WhatsUtilityActivity.this.txtTotAudSize.setText("Total Size: 0");
            WhatsUtilityActivity.this.txtTotVoicFile.setText("Total Files: 0");
            WhatsUtilityActivity.this.txtTotVoicSize.setText("Total Size: 0");
            WhatsUtilityActivity.this.txtTotWalFile.setText("Total Files: 0");
            WhatsUtilityActivity.this.txtTotWalSize.setText("Total Size: 0");
            WhatsUtilityActivity.this.txtTotBpFile.setText("Total Files: 0");
            WhatsUtilityActivity.this.txtTotBpSize.setText("Total Size: 0");
            WhatsUtilityActivity.this.mProDialog.dismiss();
            Toast.makeText(WhatsUtilityActivity.this, "Deleted Succesfully", 0).show();
        }
    }

    public void onTapBtn(String str, String str2, String str3) {
        if (appInstalledOrNot(this, WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME)) {
            onTTap(str, str2, str3);
        } else {
            Toast.makeText(this, "Please Install WhatsApp For Download Status!!!!!", 0).show();
        }
    }

    public void onTTap(String str, String str2, String str3) {
        final Intent intent = new Intent(this, CleanDataActivity.class);
        intent.putExtra("category", str);
        intent.putExtra("receivePath", str2);
        intent.putExtra("sentPath", str3);
//        AppManage.getInstance(this.activity).showInterstitialAd(this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.WAUtil.WhatsUtilityActivity.20
//            @Override // com.pesonal.adsdk.MyCallback
//            public void callbackCall() {
                WhatsUtilityActivity.this.startActivity(intent);
//            }
//        }, AppManage.app_mainClickCntSwAd);
    }

    public static boolean appInstalledOrNot(Context context, String str) {
        try {
            context.getPackageManager().getPackageInfo(str, 1);
            return true;
        } catch (PackageManager.NameNotFoundException unused) {
            return false;
        }
    }
}
