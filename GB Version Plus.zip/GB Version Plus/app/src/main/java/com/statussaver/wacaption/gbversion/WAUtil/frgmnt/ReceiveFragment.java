package com.statussaver.wacaption.gbversion.WAUtil.frgmnt;

import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.WAUtil.adpter.GbVersonAdpter;
import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;

/* loaded from: classes3.dex */
public class ReceiveFragment extends Fragment {
    public static final File STATUS_DIRECTORY = new File(Environment.getExternalStorageDirectory() + File.separator + "WhatsApp/Media/WhatsApp Images");
    public static final File STATUS_DIRECTORY_NEW = new File(Environment.getExternalStorageDirectory() + File.separator + "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images");
    GbVersonAdpter adapter;
    private File file1;
    TextView filet;
    File folder;
    RecyclerView recyclerView_Image;
    TextView size;
    long sizeImg = 0;

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = LayoutInflater.from(getContext()).inflate(R.layout.fragment_receive, viewGroup, false);
        this.recyclerView_Image = (RecyclerView) inflate.findViewById(R.id.recyclerView_Image);
        this.filet = (TextView) inflate.findViewById(R.id.file);
        this.size = (TextView) inflate.findViewById(R.id.size);
        this.recyclerView_Image.setLayoutManager(new GridLayoutManager(getActivity(), 2));
        return inflate;
    }

    public static String getReadableSize(long j) {
        if (j <= 0) {
            return "0";
        }
        double d = j;
        int log10 = (int) (Math.log10(d) / Math.log10(1024.0d));
        StringBuilder sb = new StringBuilder();
        DecimalFormat decimalFormat = new DecimalFormat("#,##0.#");
        double pow = Math.pow(1024.0d, log10);
        Double.isNaN(d);
        Double.isNaN(d);
        Double.isNaN(d);
        sb.append(decimalFormat.format(d / pow));
        sb.append(" ");
        sb.append(new String[]{"B", "KB", "MB", "GB", "TB"}[log10]);
        return sb.toString();
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        init();
    }

    private void init() {
        File[] listFiles;
        ArrayList arrayList = new ArrayList();
        File file = STATUS_DIRECTORY;
        if (file.exists()) {
            File[] listFiles2 = file.listFiles();
            if (listFiles2 != null) {
                for (int i = 0; i < listFiles2.length; i++) {
                    if (listFiles2[i].getPath().endsWith(".jpg") || listFiles2[i].getPath().endsWith(".png") || listFiles2[i].getPath().endsWith(".jpeg")) {
                        arrayList.add(listFiles2[i].getPath());
                    }
                }
            }
        } else {
            File file2 = STATUS_DIRECTORY_NEW;
            if (file2.exists() && (listFiles = file2.listFiles()) != null) {
                for (int i2 = 0; i2 < listFiles.length; i2++) {
                    if (listFiles[i2].getPath().endsWith(".jpg") || listFiles[i2].getPath().endsWith(".png") || listFiles[i2].getPath().endsWith(".jpeg")) {
                        arrayList.add(listFiles[i2].getPath());
                    }
                }
            }
        }
        if (arrayList.size() == 0) {
            this.recyclerView_Image.setVisibility(8);
            this.size.setVisibility(0);
            this.filet.setText("0 Files");
            return;
        }
        TextView textView = this.filet;
        textView.setText(arrayList.size() + " Files");
        TextView textView2 = this.size;
        textView2.setText("Size: " + getReadableSize(this.sizeImg));
        GbVersonAdpter gbVersonAdpter = new GbVersonAdpter(getActivity(), arrayList, "1", "Images");
        this.adapter = gbVersonAdpter;
        this.recyclerView_Image.setAdapter(gbVersonAdpter);
        this.adapter.notifyDataSetChanged();
    }
}
