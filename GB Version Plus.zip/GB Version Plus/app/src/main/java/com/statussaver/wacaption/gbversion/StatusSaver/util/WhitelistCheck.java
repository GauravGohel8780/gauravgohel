package com.statussaver.wacaption.gbversion.StatusSaver.util;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;

/* loaded from: classes3.dex */
public class WhitelistCheck {
    private static final String AUTHORITY_QUERY_PARAM = "authority";
    public static final String CONSUMER_WHATSAPP_PACKAGE_NAME = "com.whatsapp";
    private static final String CONTENT_PROVIDER = ".provider.sticker_whitelist_check";
    private static final String IDENTIFIER_QUERY_PARAM = "identifier";
    private static final String QUERY_PATH = "is_whitelisted";
    private static final String QUERY_RESULT_COLUMN_NAME = "result";
    public static final String SMB_WHATSAPP_PACKAGE_NAME = "com.whatsapp.w4b";
    private static final String STICKER_APP_AUTHORITY = "com.hdvideostatus.whatstools.stickercontentprovider";

    static boolean isWhitelisted(Context context, String str) {
        return isWhitelistedFromProvider(context, str, CONSUMER_WHATSAPP_PACKAGE_NAME) && isWhitelistedFromProvider(context, str, SMB_WHATSAPP_PACKAGE_NAME);
    }

    @SuppressLint("WrongConstant")
    private static boolean isWhitelistedFromProvider(Context context, String str, String str2) {
        Cursor query;
        boolean z = false;
        String[] strArr = new String[0];
        PackageManager packageManager = context.getPackageManager();
        if (!isPackageInstalled(str2, packageManager)) {
            return true;
        }
        String str3 = str2 + CONTENT_PROVIDER;
        if (packageManager.resolveContentProvider(str3, 128) != null && (query = context.getContentResolver().query(new Uri.Builder().scheme("content").authority(str3).appendPath(QUERY_PATH).appendQueryParameter(AUTHORITY_QUERY_PARAM, STICKER_APP_AUTHORITY).appendQueryParameter(IDENTIFIER_QUERY_PARAM, str).build(), strArr, null, null, null)) != null) {
            if (query.moveToFirst()) {
                if (query.getInt(query.getColumnIndexOrThrow("result")) == 1) {
                    z = true;
                }
                query.close();
                return z;
            }
            query.close();
        }
        return false;
    }

    public static boolean isPackageInstalled(String str, PackageManager packageManager) {
        try {
            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(str, 0);
            if (applicationInfo != null) {
                return applicationInfo.enabled;
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return false;
    }
}
