package com.statussaver.wacaption.gbversion.StatusSaver.fragment;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.StatusSaver.adpter.adpter_Saved;
import com.statussaver.wacaption.gbversion.StatusSaver.util.Const;
import com.statussaver.wacaption.gbversion.StatusSaver.util.ModelStatus;
import com.statussaver.wacaption.gbversion.StatusSaver.util.WhitelistCheck;
import java.io.File;
import java.util.ArrayList;

/* loaded from: classes3.dex */
public class fragment_SavedImages extends Fragment implements SwipeRefreshLayout.OnRefreshListener {
    public String SaveFilePath = Const.RootDirectoryWhatsappShow + "/";
    Activity activity;
    ArrayList<ModelStatus> data;
    SwipeRefreshLayout mSwipeRefreshLayout;
    RecyclerView rv;
    ImageView textView;

    public fragment_SavedImages(Activity activity) {
        this.activity = activity;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.frag_saved_images, viewGroup, false);
        this.rv = (RecyclerView) inflate.findViewById(R.id.rv_status);
        SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) inflate.findViewById(R.id.contentView);
        this.mSwipeRefreshLayout = swipeRefreshLayout;
        swipeRefreshLayout.setOnRefreshListener(this);
        this.textView = (ImageView) inflate.findViewById(R.id.textView);
        this.rv.setHasFixedSize(true);
        loadData();
        return inflate;
    }

    /* JADX WARN: Type inference failed for: r2v3, types: [com.statussaver.wacaption.gbversion.StatusSaver.fragment.fragment_SavedImages$2] */
    /* JADX WARN: Type inference failed for: r2v6, types: [com.statussaver.wacaption.gbversion.StatusSaver.fragment.fragment_SavedImages$1] */
    public void loadData() {
        this.data = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 30) {
            File file = new File(Const.savedData);
            if (file.exists()) {
                final File[] listFiles = file.listFiles();
                Log.d("Files", "Size: " + listFiles.length);
                final String[] strArr = {""};
                new AsyncTask<Void, Void, Void>() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.fragment.fragment_SavedImages.1
                    public Void doInBackground(Void... voidArr) {
                        for (int length = listFiles.length - 1; length >= 0; length--) {
                            Log.d("Files", "FileName:" + listFiles[length].getName());
                            Log.d("Files", "FileName:" + listFiles[length].getName().substring(0, listFiles[length].getName().length() + (-4)));
                            if (listFiles[length].getName().endsWith(".jpg")) {
                                strArr[0] = Const.savedData + listFiles[length].getName();
                                fragment_SavedImages.this.data.add(new ModelStatus(strArr[0], listFiles[length].getName().substring(0, listFiles[length].getName().length() + (-4)), 0, WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME));
                            }
                        }
                        return null;
                    }

                    public void onPostExecute(Void r4) {
                        super.onPostExecute( r4);
                        if (fragment_SavedImages.this.data.toArray().length <= 0) {
                            fragment_SavedImages.this.textView.setVisibility(0);
                        }
                        fragment_SavedImages.this.rv.setAdapter(new adpter_Saved(fragment_SavedImages.this.getActivity(), fragment_SavedImages.this.data));
                        fragment_SavedImages.this.rv.setLayoutManager(new GridLayoutManager(fragment_SavedImages.this.getActivity(), 2));
                    }
                }.execute(new Void[0]);
            } else {
                this.textView.setVisibility(0);
            }
        } else {
            File file2 = new File(this.SaveFilePath);
            if (file2.exists()) {
                final File[] listFiles2 = file2.listFiles();
                Log.d("Files", "Size: " + listFiles2.length);
                final String[] strArr2 = {""};
                new AsyncTask<Void, Void, Void>() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.fragment.fragment_SavedImages.2
                    public Void doInBackground(Void... voidArr) {
                        for (int length = listFiles2.length - 1; length >= 0; length--) {
                            Log.d("Files", "FileName:" + listFiles2[length].getName());
                            Log.d("Files", "FileName:" + listFiles2[length].getName().substring(0, listFiles2[length].getName().length() + (-4)));
                            if (listFiles2[length].getName().endsWith(".jpg")) {
                                strArr2[0] = fragment_SavedImages.this.SaveFilePath + "" + listFiles2[length].getName();
                                fragment_SavedImages.this.data.add(new ModelStatus(strArr2[0], listFiles2[length].getName().substring(0, listFiles2[length].getName().length() + (-4)), 0, WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME));
                            }
                        }
                        return null;
                    }

                    public void onPostExecute(Void r4) {
                        super.onPostExecute( r4);
                        if (fragment_SavedImages.this.data.toArray().length <= 0) {
                            fragment_SavedImages.this.textView.setVisibility(0);
                        }
                        fragment_SavedImages.this.rv.setAdapter(new adpter_Saved(fragment_SavedImages.this.getActivity(), fragment_SavedImages.this.data));
                        fragment_SavedImages.this.rv.setLayoutManager(new GridLayoutManager(fragment_SavedImages.this.getActivity(), 2));
                    }
                }.execute(new Void[0]);
            } else {
                this.textView.setVisibility(0);
            }
        }
        refreshItems();
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
    }

    public void refreshItems() {
        onItemsLoadComplete();
    }

    public void onItemsLoadComplete() {
        this.mSwipeRefreshLayout.setRefreshing(false);
    }

    @Override // androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
    public void onRefresh() {
        loadData();
    }
}
