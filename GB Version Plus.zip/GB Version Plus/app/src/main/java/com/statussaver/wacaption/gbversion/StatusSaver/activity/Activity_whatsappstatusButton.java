package com.statussaver.wacaption.gbversion.StatusSaver.activity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import com.statussaver.wacaption.gbversion.R;

/* loaded from: classes3.dex */
public class Activity_whatsappstatusButton extends AppCompatActivity {
    Activity_whatsappstatusButton activity;
    private ImageView btn_recentstatus;
    private ImageView btn_savedstatus;
    Intent intent;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main2);
        this.activity = this;
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_whatsappstatusButton.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Activity_whatsappstatusButton.this.onBackPressed();
            }
        });
        initview();
        click();
    }

    private void click() {
        this.btn_recentstatus.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_whatsappstatusButton.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= 30) {
//                    AppManage.getInstance(Activity_whatsappstatusButton.this.activity).showInterstitialAd(Activity_whatsappstatusButton.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_whatsappstatusButton.2.1
//                        @Override // com.pesonal.adsdk.MyCallback
//                        public void callbackCall() {
                            Activity_whatsappstatusButton.this.intent = new Intent(Activity_whatsappstatusButton.this.getApplicationContext(), Activity_11_RecentStatus.class);
                            Activity_whatsappstatusButton.this.startActivity(Activity_whatsappstatusButton.this.intent);
//                        }
//                    }, AppManage.app_mainClickCntSwAd);
                } else {
//                    AppManage.getInstance(Activity_whatsappstatusButton.this.activity).showInterstitialAd(Activity_whatsappstatusButton.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_whatsappstatusButton.2.2
//                        @Override // com.pesonal.adsdk.MyCallback
//                        public void callbackCall() {
                            Activity_whatsappstatusButton.this.intent = new Intent(Activity_whatsappstatusButton.this.getApplicationContext(), Activity_10_StorieSaver.class);
                            Activity_whatsappstatusButton.this.startActivity(Activity_whatsappstatusButton.this.intent);
//                        }
//                    }, AppManage.app_mainClickCntSwAd);
                }
            }
        });
        this.btn_savedstatus.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_whatsappstatusButton.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                AppManage.getInstance(Activity_whatsappstatusButton.this.activity).showInterstitialAd(Activity_whatsappstatusButton.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_whatsappstatusButton.3.1
//                    @Override // com.pesonal.adsdk.MyCallback
//                    public void callbackCall() {
                        Activity_whatsappstatusButton.this.intent = new Intent(Activity_whatsappstatusButton.this.getApplicationContext(), activity_SavedStatus.class);
                        Activity_whatsappstatusButton.this.startActivity(Activity_whatsappstatusButton.this.intent);
//                    }
//                }, AppManage.app_mainClickCntSwAd);
            }
        });
    }

    private void initview() {
        this.btn_recentstatus = (ImageView) findViewById(R.id.img_rectent);
        this.btn_savedstatus = (ImageView) findViewById(R.id.gallery);
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
//        AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_whatsappstatusButton.4
//            @Override // com.pesonal.adsdk.MyCallback
//            public void callbackCall() {
                Activity_whatsappstatusButton.this.finish();
//            }
//        }, AppManage.app_mainClickCntSwAd);
    }
}
