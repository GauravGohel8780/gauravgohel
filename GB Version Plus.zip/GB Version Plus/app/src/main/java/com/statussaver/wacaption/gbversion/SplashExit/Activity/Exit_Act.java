package com.statussaver.wacaption.gbversion.SplashExit.Activity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import com.statussaver.wacaption.gbversion.R;

/* loaded from: classes3.dex */
public class Exit_Act extends AppCompatActivity {
    ImageView img_ok;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.sp_activity_exit);
        ImageView imageView = (ImageView) findViewById(R.id.ok);
        this.img_ok = imageView;
        imageView.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Exit_Act.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Exit_Act.this.finishAffinity();
            }
        });
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        finishAffinity();
    }
}
