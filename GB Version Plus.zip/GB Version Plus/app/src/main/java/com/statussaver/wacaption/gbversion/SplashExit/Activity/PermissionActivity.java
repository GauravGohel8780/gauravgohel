package com.statussaver.wacaption.gbversion.SplashExit.Activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.telecom.TelecomManager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.SplashExit.Splash_Utils.Glob;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

/* loaded from: classes3.dex */
public class PermissionActivity extends AppCompatActivity {
    private static ArrayList arrayList;
    private static ArrayList arrayList2;
    public String TITLE;
    Activity activity;
    private TextView btn_txt;
    private boolean check;
    boolean doubleBackToExitPressedOnce = false;
    private SharedPreferences.Editor editor;
    private ImageView permission;
    SharedPreferences sharedPreferences;
    TelecomManager systemServicee;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_permission);
        this.activity = this;
//        AppManage.getInstance(this).showNativeAds(this, (ViewGroup) findViewById(R.id.native_container), (ImageView) findViewById(R.id.native_space_img), 2);
        getSharedPreferences("PREFERENCE", 0).edit().putBoolean("isFirstRun", false).apply();
        ImageView imageView = (ImageView) findViewById(R.id.txt_done);
        this.permission = imageView;
        imageView.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.PermissionActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (PermissionActivity.this.checkPermission()) {
                    PermissionActivity.this.Next();
                } else {
                    PermissionActivity.this.arePermissionDenied();
                }
            }
        });
    }

    public void Next() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
        String format = simpleDateFormat.format(calendar.getTime());
//        if (Glob.checkMultiplePermissions(this.activity)) {
////            if (Glob.isOnline(this.activity) && AppManage.vpnscreen == 1) {
////                Glob.checkTime(AppManage.vpnstarttime, AppManage.vpnendtime, format, this.activity);
////            } else {
//                Glob.callnext(this.activity);
////            }
//        }
        startActivity(new Intent(getApplicationContext(),StartActivity.class));
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 2 && iArr[0] == 0) {
            Next();
        }
    }

    public boolean checkPermission() {
        return ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.WRITE_EXTERNAL_STORAGE") == 0 && ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.READ_EXTERNAL_STORAGE") == 0;
    }

    public void arePermissionDenied() {
        ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"}, 200);
    }

    @SuppressLint("WrongConstant")
    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
//        if (AppManage.exitscreen == 1) {
//            startActivity(new Intent(this, BackActivity.class));
//            finish();
//        } else
            if (this.doubleBackToExitPressedOnce) {
            finishAffinity();
        } else {
            this.doubleBackToExitPressedOnce = true;
            Toast.makeText(this, "Please click BACK again to exit", 0).show();
            new Handler().postDelayed(new Runnable() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.PermissionActivity.2
                @Override // java.lang.Runnable
                public void run() {
                    PermissionActivity.this.doubleBackToExitPressedOnce = false;
                }
            }, 1000L);
        }
    }
}
