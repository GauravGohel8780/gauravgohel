package com.statussaver.wacaption.gbversion.Caption;

import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.statussaver.wacaption.gbversion.Caption.adpter.CaptionsListAdapter;
import com.statussaver.wacaption.gbversion.R;

public class CategoryCaptionsActivity extends AppCompatActivity {

    CaptionsListAdapter captionsListAdapter;
    ListView listViewFacts;
    Parcelable state;
    private TextView tx_nm;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_category_captions);
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CategoryCaptionsActivity.super.onBackPressed();
            }
        });
        this.listViewFacts = (ListView) findViewById(R.id.listViewFacts);
        TextView textView = (TextView) findViewById(R.id.tx_nm);
        this.tx_nm = textView;
        textView.setText(Categories.categoriesArray[CaptionActivity.positionSelected]);
        CaptionsListAdapter captionsListAdapter = new CaptionsListAdapter(this, CaptionActivity.selectedArray);
        this.captionsListAdapter = captionsListAdapter;
        this.listViewFacts.setAdapter((ListAdapter) captionsListAdapter);
    }

    @Override
    public void onResume() {
        super.onResume();
        Parcelable parcelable = this.state;
        if (parcelable != null) {
            this.listViewFacts.onRestoreInstanceState(parcelable);
        }
    }

    @Override
    public void onPause() {
        this.state = this.listViewFacts.onSaveInstanceState();
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        CategoryCaptionsActivity.this.finish();
    }
}
