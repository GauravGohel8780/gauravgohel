package com.statussaver.wacaption.gbversion.MultiMsg;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.statussaver.wacaption.gbversion.Emoction.GBWhats_CopyHan;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.StatusSaver.util.WhitelistCheck;

public class MultiPleMessageActivty extends AppCompatActivity {

    EditText editMessager;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_multi_ple_message);
        this.editMessager = (EditText) findViewById(R.id.editMessager);
        findViewById(R.id.send_multimsg_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = Build.VERSION.SDK_INT;
                if (MultiPleMessageActivty.this.editMessager.getText().toString().length() <= 0) {
                    Toast.makeText(MultiPleMessageActivty.this, "please enter message...", 0).show();
                } else if (MultiPleMessageActivty.this.getPackageManager().getLaunchIntentForPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME) != null) {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.TEXT", MultiPleMessageActivty.this.editMessager.getText().toString());
                    intent.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    MultiPleMessageActivty.this.startActivity(intent);
                    MultiPleMessageActivty.this.editMessager.setText("");
                } else if (i >= 30) {
                    Intent intent2 = new Intent();
                    intent2.setAction("android.intent.action.SEND");
                    intent2.putExtra("android.intent.extra.TEXT", MultiPleMessageActivty.this.editMessager.getText().toString());
                    intent2.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                    intent2.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    try {
                        MultiPleMessageActivty.this.startActivity(intent2);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(MultiPleMessageActivty.this, "Whatsapp doesn't installed", 0).show();
                    }
                    MultiPleMessageActivty.this.editMessager.setText("");
                } else {
                    Toast.makeText(MultiPleMessageActivty.this, "Whatsapp doesn't installed", 0).show();
                }
            }
        });
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MultiPleMessageActivty.this.onBackPressed();
            }
        });
    }

    @Override
    public void onBackPressed() {
        MultiPleMessageActivty.this.finish();
    }
}
