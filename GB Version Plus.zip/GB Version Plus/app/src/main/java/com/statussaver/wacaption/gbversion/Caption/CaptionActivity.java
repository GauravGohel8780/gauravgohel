package com.statussaver.wacaption.gbversion.Caption;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.StrictMode;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.statussaver.wacaption.gbversion.Caption.adpter.CategoryListAdapter;
import com.statussaver.wacaption.gbversion.R;

public class CaptionActivity extends AppCompatActivity {

    public static String[] categoriesArray = {"Girls", "Love & Emotion", "Friends", "Hillarious", "For Insta", "Motivational", "Birthday", "Cool", "Fitness", "Flirty", "Food", "Friendship", "Funny", "Inspiring", "Life", "Love", "Party", "Sarcastic", "Savage", "Selfie", "Selflove", "Smile", "Success", "Sweet", "Travel", "Happiness"};
    static String fileToOpen;
    static int positionSelected;
    static String[] selectedArray;
    private Activity activity;
    String[][] captionsAtrrays;
    CategoryListAdapter categoryListAdapter;
    ListView listViewCategory;
    SharedPreferences.Editor localEditor;
    SharedPreferences localSharedPreferences;
    Parcelable state;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_caption);
        this.activity = this;
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CaptionActivity.this.finish();
            }
        });
        String[][] strArr = {new String[]{"sckjdch", "dcdscdsd"}, getResources().getStringArray(R.array.Birthday_Captions), getResources().getStringArray(R.array.Cool_Captions), getResources().getStringArray(R.array.Fitness_Captions), getResources().getStringArray(R.array.Flirty), getResources().getStringArray(R.array.Food_Captions), getResources().getStringArray(R.array.Friendship), getResources().getStringArray(R.array.Funny_Captions), getResources().getStringArray(R.array.Inspiring_Captions), getResources().getStringArray(R.array.Life), getResources().getStringArray(R.array.Love), getResources().getStringArray(R.array.Party_Captions), getResources().getStringArray(R.array.Sarcastic_Captions), getResources().getStringArray(R.array.Savage_Captions), getResources().getStringArray(R.array.Selfie_Captions), getResources().getStringArray(R.array.Selflove_Captions), getResources().getStringArray(R.array.Smile_Captions), getResources().getStringArray(R.array.Sucess_Captions), getResources().getStringArray(R.array.Sweet_Captions), getResources().getStringArray(R.array.Travel_Captions), getResources().getStringArray(R.array.happiness)};
        this.listViewCategory = (ListView) findViewById(R.id.listViewCategories);
        CategoryListAdapter categoryListAdapter = new CategoryListAdapter(this, Categories.categoriesArray);
        this.categoryListAdapter = categoryListAdapter;
        this.listViewCategory.setAdapter((ListAdapter) categoryListAdapter);
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                StrictMode.class.getMethod("disableDeathOnFileUriExposure", new Class[0]).invoke(null, new Object[0]);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        SharedPreferences sharedPreferences = getSharedPreferences("FAVORITEMESSAGES", 0);
        this.localSharedPreferences = sharedPreferences;
        this.localEditor = sharedPreferences.edit();
        this.captionsAtrrays = strArr;
        this.listViewCategory.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                CaptionActivity.positionSelected = i;
                if (CaptionActivity.positionSelected < 0 || CaptionActivity.positionSelected > 5) {
                    CaptionActivity.selectedArray = CaptionActivity.this.captionsAtrrays[CaptionActivity.positionSelected - 5];
                    CaptionActivity.this.startActivity(new Intent(CaptionActivity.this.getApplicationContext(), CategoryCaptionsActivity.class));
                    return;
                }
                if (CaptionActivity.positionSelected == 0) {
                    CaptionActivity.fileToOpen = "girls.txt";
                } else if (CaptionActivity.positionSelected == 1) {
                    CaptionActivity.fileToOpen = "emotion.txt";
                } else if (CaptionActivity.positionSelected == 2) {
                    CaptionActivity.fileToOpen = "friends.txt";
                } else if (CaptionActivity.positionSelected == 3) {
                    CaptionActivity.fileToOpen = "hilarious.txt";
                } else if (CaptionActivity.positionSelected == 4) {
                    CaptionActivity.fileToOpen = "insta.txt";
                } else if (CaptionActivity.positionSelected == 5) {
                    CaptionActivity.fileToOpen = "motivational.txt";
                }
                CaptionActivity.this.startActivity(new Intent(CaptionActivity.this.getApplicationContext(), CaptionsByFilesActivity.class).putExtra("title", CaptionActivity.categoriesArray[CaptionActivity.positionSelected]));
            }
        });
    }

    @Override
    public void onPause() {
        this.state = this.listViewCategory.onSaveInstanceState();
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        Parcelable parcelable = this.state;
        if (parcelable != null) {
            this.listViewCategory.onRestoreInstanceState(parcelable);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        CaptionActivity.this.finish();

    }
}
