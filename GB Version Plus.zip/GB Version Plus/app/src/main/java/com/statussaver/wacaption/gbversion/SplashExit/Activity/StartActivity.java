package com.statussaver.wacaption.gbversion.SplashExit.Activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.statussaver.wacaption.gbversion.R;

/* loaded from: classes3.dex */
public class StartActivity extends AppCompatActivity {
    private Activity activity;
    public boolean dataAvailable = true;
    boolean doubleBackToExitPressedOnce = false;
    private GridView mGridMoreApps;
    private ImageView mImgSStart;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_start);
        this.activity = this;
        initView();
//        setAppInList();
    }

//    public void setAppInList() {
////        final AppList_Adapter appList_Adapter = new AppList_Adapter(this.activity, arrayList);
//        runOnUiThread(new Runnable() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.StartActivity.1
//            @Override // java.lang.Runnable
//            public void run() {
////                StartActivity.this.mGridMoreApps.setAdapter((ListAdapter) appList_Adapter);
//            }
//        });
//        this.mGridMoreApps.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.StartActivity.2
//            @Override // android.widget.AdapterView.OnItemClickListener
//            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
////                if (i / arrayList.size() >= 1) {
////                    i -= arrayList.size() * (i / arrayList.size());
////                }
////                Launches.openAppPlayStore(StartActivity.this.activity, ((MoreApp_Data) arrayList.get(i)).getAppPackageName());
//            }
//        });
//    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
//        if (AppManage.exitscreen == 1) {
//            startActivity(new Intent(this, BackActivity.class));
//            finish();
//        } else
            if (this.doubleBackToExitPressedOnce) {
            finishAffinity();
        } else {
            this.doubleBackToExitPressedOnce = true;
            Toast.makeText(this, "Please click BACK again to exit", 0).show();
            new Handler().postDelayed(new Runnable() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.StartActivity.3
                @Override // java.lang.Runnable
                public void run() {
                    StartActivity.this.doubleBackToExitPressedOnce = false;
                }
            }, 1000L);
        }
    }

    private void initView() {
        this.mGridMoreApps = (GridView) findViewById(R.id.grid_More_Apps);
        ImageView imageView = (ImageView) findViewById(R.id.ll_getstart);
        this.mImgSStart = imageView;
        imageView.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.StartActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                if (Glob.checkMultiplePermissions(StartActivity.this.activity)) {
//                    AppManage.getInstance(StartActivity.this.activity).showInterstitialAd(StartActivity.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.StartActivity.4.1
//                        @Override // com.pesonal.adsdk.MyCallback
//                        public void callbackCall() {
//                            if (AppManage.startScreen == 1) {
                                StartActivity.this.startActivity(new Intent(StartActivity.this.getApplicationContext(), EnterApp_Act.class));
                                StartActivity.this.finish();
//                            } else if (AppManage.extrascreen1 == 1) {
//                                StartActivity.this.startActivity(new Intent(StartActivity.this.getApplicationContext(), Activity_ExtraScrren1.class));
//                                StartActivity.this.finish();
//                            } else if (AppManage.extrascreen2 == 1) {
//                                StartActivity.this.startActivity(new Intent(StartActivity.this.getApplicationContext(), Activity_ExtraScrren2.class));
//                                StartActivity.this.finish();
//                            } else if (AppManage.extrascreen3 == 1) {
//                                StartActivity.this.startActivity(new Intent(StartActivity.this.getApplicationContext(), Activity_ExtraScrren3.class));
//                                StartActivity.this.finish();
//                            } else if (AppManage.extrascreen4 == 1) {
//                                StartActivity.this.startActivity(new Intent(StartActivity.this.getApplicationContext(), Activity_ExtraScrren4.class));
//                                StartActivity.this.finish();
//                            } else if (AppManage.extrascreen5 == 1) {
//                                StartActivity.this.startActivity(new Intent(StartActivity.this.getApplicationContext(), Activity_ExtraScrren5.class));
//                                StartActivity.this.finish();
//                            } else if (AppManage.extrascreen6 == 1) {
//                                StartActivity.this.startActivity(new Intent(StartActivity.this.getApplicationContext(), Activity_ExtraScrren6.class));
//                                StartActivity.this.finish();
//                            } else {
//                                StartActivity.this.startActivity(new Intent(StartActivity.this.getApplicationContext(), MainActivity.class));
//                                StartActivity.this.finish();
//                            }
//                        }
//                    }, AppManage.app_mainClickCntSwAd);
//                }
            }
        });
    }
}
