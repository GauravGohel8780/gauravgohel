package com.statussaver.wacaption.gbversion.magictext;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.statussaver.wacaption.gbversion.R;

import java.util.ArrayList;

public class Decoration_Activity extends AppCompatActivity {

    public ArrayList<DataStyle> decoratingStyles = new ArrayList<>();
    private EditText edtText;
    private RelativeLayout linerEdit;
    private RecyclerView recyclerView;
    public StyleAdapter styleAdapter;

    @SuppressLint("WrongConstant")
    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_decoration);
        findView();
        this.recyclerView.setHasFixedSize(true);
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this, 1, false));
        this.recyclerView.addItemDecoration(new EqualSpacingItemDecoration(15));
        initDataStyles();
        StyleAdapter styleAdapter = new StyleAdapter(this.decoratingStyles, this);
        this.styleAdapter = styleAdapter;
        this.recyclerView.setAdapter(styleAdapter);
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Decoration_Activity.super.onBackPressed();
            }
        });
    }

    private void findView() {
        this.linerEdit = (RelativeLayout) findViewById(R.id.linerEdit);
        EditText editText = (EditText) findViewById(R.id.edtText);
        this.edtText = editText;
        editText.addTextChangedListener(new TextDecoratorWatcher());
        this.recyclerView = (RecyclerView) findViewById(R.id.recycler_view_fancytextgenerator);
    }

    private void initDataStyles() {
        this.decoratingStyles.add(new DataStyle("Decorating Style 1", "\u2605\u00b7.\u00b7\u00b4\u00af`\u00b7.\u00b7\u2605 preview \u2605\u00b7.\u00b7\u00b4\u00af`\u00b7.\u00b7\u2605"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 2", "\u2581 \u2582 \u2584 \u2585 \u2586 \u2587 \u2588 preview \u2588 \u2587 \u2586 \u2585 \u2584 \u2582 \u2581"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 3", "\u00b0\u00b0\u00b0\u00b7.\u00b0\u00b7..\u00b7\u00b0\u00af\u00b0\u00b7._.\u00b7 preview \u00b7._.\u00b7\u00b0\u00af\u00b0\u00b7.\u00b7\u00b0 .\u00b7\u00b0\u00b0\u00b0"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 4", "\u00b8,\u00f8\u00a4\u00ba\u00b0`\u00b0\u00ba\u00a4\u00f8,\u00b8\u00b8,\u00f8\u00a4\u00ba\u00b0 preview \u00b0\u00ba\u00a4\u00f8,\u00b8\u00b8,\u00f8\u00a4\u00ba\u00b0`\u00b0\u00ba\u00a4\u00f8,\u00b8"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 5", "\u0131ll\u0131ll\u0131 preview \u0131ll\u0131ll\u0131"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 6", "\u2022?((\u00af\u00b0\u00b7._.\u2022 preview \u2022._.\u00b7\u00b0\u00af))\u061f\u2022"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 7", "\u258c\u2502\u2588\u2551\u258c\u2551\u258c\u2551 preview \u2551\u258c\u2551\u258c\u2551\u2588\u2502\u258c"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 8", "\u00d7\u00ba\u00b0\u201d\u02dc`\u201d\u00b0\u00ba\u00d7 preview \u00d7\u00ba\u00b0\u201d\u02dc`\u201d\u00b0\u00ba\u00d7"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 9", "\u2022]\u2022\u2022\u00b4\u00ba\u00b4\u2022\u00bb preview \u00ab\u2022\u00b4\u00ba\u00b4\u2022\u2022[\u2022"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 10", "*\u2022.\u00b8\u2661 preview \u2661\u00b8.\u2022*"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 11", "\u2570\u2606\u2606 preview \u2606\u2606\u256e"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 12", ".\u2022\u00b0\u00a4*(\u00af`\u2605\u00b4\u00af)*\u00a4\u00b0 preview \u00b0\u00a4*(\u00af\u00b4\u2605`\u00af)*\u00a4\u00b0\u2022."));
        this.decoratingStyles.add(new DataStyle("Decorating Style 13", "(\u00af\u00b4\u2022._.\u2022 preview \u2022._.\u2022\u00b4\u00af)"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 14", "\u00b8\u201e.-\u2022~\u00b9\u00b0\u201d\u02c6\u02dc\u00a8 preview \u00a8\u02dc\u02c6\u201d\u00b0\u00b9~\u2022-.\u201e\u00b8"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 15", "\u2591\u2592\u2593\u2588 preview \u2588\u2593\u2592\u2591"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 16", "\u2591\u2592\u2593\u2588\u25ba\u2500\u2550  preview \u2550\u2500\u25c4\u2588\u2593\u2592\u2591"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 17", "\u2605\u5f61 preview \u5f61\u2605"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 18", "\u2022\u00b4\u00af`\u2022. preview .\u2022\u00b4\u00af`\u2022"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 19", "\u00a7.\u2022\u00b4\u00a8'\u00b0\u00f7\u2022..\u00d7 preview \u00d7,.\u2022\u00b4\u00a8'\u00b0\u00f7\u2022..\u00a7"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 20", "\u2022\u00b0\u00af`\u2022\u2022 preview \u2022\u2022\u00b4\u00af\u00b0\u2022"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 21", "(\u00af`\u00b7.\u00b8\u00b8.\u00b7\u00b4\u00af`\u00b7.\u00b8\u00b8.-> preview <-.\u00b8\u00b8.\u00b7\u00b4\u00af`\u00b7.\u00b8\u00b8.\u00b7\u00b4\u00af)"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 22", "|!\u00a4*'~``~'*\u00a4!| preview |!\u00a4*'~``~'*\u00a4!|"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 23", "\u2022._.\u2022\u2022\u00b4\u00af``\u2022.\u00b8\u00b8.\u2022` preview `\u2022.\u00b8\u00b8.\u2022\u00b4\u00b4\u00af`\u2022\u2022._.\u2022"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 24", "\u00b8\u201e.-\u2022~\u00b9\u00b0\u201d\u02c6\u02dc\u00a8 preview \u00a8\u02dc\u02c6\u201d\u00b0\u00b9~\u2022-.\u201e\u00b8"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 25", "(\u00af\u00b4\u2022._.\u2022 preview \u2022._.\u2022\u00b4\u00af)"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 26", "\u2022\u2022\u00a4(`\u00d7[\u00a4 preview \u00a4]\u00d7\u00b4)\u00a4\u2022\u2022"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 27", "\u2022\u00b4\u00af`\u2022\u00bb preview \u00ab\u2022\u00b4\u00af`\u2022"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 28", " .o0\u00d7X\u00d70o. preview .o0\u00d7X\u00d70o."));
        this.decoratingStyles.add(new DataStyle("Decorating Style 29", "\u00a4\u00b8\u00b8.\u2022\u00b4\u00af`\u2022\u00b8\u00b8.\u2022..>> preview <<..\u2022.\u00b8\u00b8\u2022\u00b4\u00af`\u2022.\u00b8\u00b8\u00a4"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 30", "\u2014(\u2022\u2022\u00f7[ preview ]\u00f7\u2022\u2022)\u2014"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 31", "\u00b8,\u00f8\u00a4\u00ba\u00b0`\u00b0\u00ba\u00a4\u00f8,\u00b8 preview \u00b8,\u00f8\u00a4\u00ba\u00b0`\u00b0\u00ba\u00a4\u00f8,\u00b8"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 32", "`\u2022.\u00b8\u00b8.\u2022\u00b4\u00b4\u00af`\u2022\u2022._.\u2022 preview \u2022._.\u2022\u2022`\u00af\u00b4\u00b4\u2022.\u00b8\u00b8.\u2022`"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 33", ",-*' ^ '~*-.,_,.-*~ preview ~*-.,_,.-*~' ^ '*-,"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 34", "`\u2022.,\u00b8\u00b8,.\u2022\u00b4\u00af preview \u00af`\u2022.,\u00b8\u00b8,.\u2022\u00b4"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 35", "\u21a4\u21a4\u21a4\u21a4\u21a4 preview \u21a6\u21a6\u21a6\u21a6\u21a6"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 36", "\u27b6\u27b6\u27b6\u27b6\u27b6 preview \u27b7\u27b7\u27b7\u27b7\u27b7"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 37", "\u21ab\u21ab\u21ab\u21ab\u21ab preview \u21ac\u21ac\u21ac\u21ac\u21ac"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 38", "\u00b7.\u00b8\u00b8.\u00b7\u2669\u266a\u266b preview \u266b\u266a\u2669\u00b7.\u00b8\u00b8.\u00b7"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 39", "\u255a\u00bb\u2605\u00ab\u255d preview \u255a\u00bb\u2605\u00ab\u255d"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 40", "]|I{\u2022------\u00bb preview \u00ab------\u2022}I|["));
        this.decoratingStyles.add(new DataStyle("Decorating Style 41", "\u2580\u2584\u2580\u2584\u2580\u2584 preview \u2584\u2580\u2584\u2580\u2584\u2580"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 42", "(-_-) preview (-_-)"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 43", "\u2022\u00b4\u00af`\u2022. preview .\u2022\u00b4\u00af`\u2022"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 44", "-\u6f2b~*'\u00a8\u00af\u00a8'*\u00b7\u821e~ preview ~\u821e*'\u00a8\u00af\u00a8'*\u00b7~\u6f2b-"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 45", "\u0e51\u06de\u0e51,\u00b8\u00b8,\u00f8\u00a4\u00ba\u00b0`\u00b0\u0e51\u06e9 preview \u0e51\u06e9 ,\u00b8\u00b8,\u00f8\u00a4\u00ba\u00b0`\u00b0\u0e51\u06de\u0e51"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 46", ".\u2022\u00b0\u00a4*(\u00af`\u2605\u00b4\u00af)*\u00a4\u00b0 preview \u00b0\u00a4*(\u00af\u00b4\u2605`\u00af)*\u00a4\u00b0\u2022."));
        this.decoratingStyles.add(new DataStyle("Decorating Style 47", "\u2022\u2022.\u2022\u00b4\u00af`\u2022.\u2022\u2022 preview \u2022\u2022.\u2022\u00b4\u00af`\u2022.\u2022\u2022"));
        this.decoratingStyles.add(new DataStyle("Decorating Style 48", "\u00a4\u00b8\u00b8.\u2022\u00b4\u00af`\u2022\u00b8\u00b8.\u2022..>> preview <<..\u2022.\u00b8\u00b8\u2022\u00b4\u00af`\u2022.\u00b8\u00b8\u00a4"));
    }

    public class TextDecoratorWatcher implements TextWatcher {
        @Override
        public void afterTextChanged(Editable editable) {
        }

        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        private TextDecoratorWatcher() {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            String charSequence2 = charSequence.toString();
            if (charSequence2.trim().length() == 0) {
                charSequence2 = "preview";
            }
            Log.e("Original Text ", ":: " + charSequence2);
            Decoration_Activity.this.decoratingStyles.get(0).setStyleValue("\u2605\u00b7.\u00b7\u00b4\u00af`\u00b7.\u00b7\u2605 " + charSequence2 + " \u2605\u00b7.\u00b7\u00b4\u00af`\u00b7.\u00b7\u2605");
            Decoration_Activity.this.decoratingStyles.get(1).setStyleValue("\u2581 \u2582 \u2584 \u2585 \u2586 \u2587 \u2588 " + charSequence2 + " \u2588 \u2587 \u2586 \u2585 \u2584 \u2582 \u2581");
            Decoration_Activity.this.decoratingStyles.get(2).setStyleValue("\u00b0\u00b0\u00b0\u00b7.\u00b0\u00b7..\u00b7\u00b0\u00af\u00b0\u00b7._.\u00b7 " + charSequence2 + " \u00b7._.\u00b7\u00b0\u00af\u00b0\u00b7.\u00b7\u00b0 .\u00b7\u00b0\u00b0\u00b0");
            Decoration_Activity.this.decoratingStyles.get(3).setStyleValue("\u00b8,\u00f8\u00a4\u00ba\u00b0`\u00b0\u00ba\u00a4\u00f8,\u00b8\u00b8,\u00f8\u00a4\u00ba\u00b0 " + charSequence2 + " \u00b0\u00ba\u00a4\u00f8,\u00b8\u00b8,\u00f8\u00a4\u00ba\u00b0`\u00b0\u00ba\u00a4\u00f8,\u00b8");
            Decoration_Activity.this.decoratingStyles.get(4).setStyleValue("\u0131ll\u0131ll\u0131 " + charSequence2 + " \u0131ll\u0131ll\u0131");
            Decoration_Activity.this.decoratingStyles.get(5).setStyleValue("\u2022?((\u00af\u00b0\u00b7._.\u2022 " + charSequence2 + " \u2022._.\u00b7\u00b0\u00af))\u061f\u2022");
            Decoration_Activity.this.decoratingStyles.get(6).setStyleValue("\u258c\u2502\u2588\u2551\u258c\u2551\u258c\u2551 " + charSequence2 + " \u2551\u258c\u2551\u258c\u2551\u2588\u2502\u258c");
            Decoration_Activity.this.decoratingStyles.get(7).setStyleValue("\u00d7\u00ba\u00b0\u201d\u02dc`\u201d\u00b0\u00ba\u00d7 " + charSequence2 + " \u00d7\u00ba\u00b0\u201d\u02dc`\u201d\u00b0\u00ba\u00d7");
            Decoration_Activity.this.decoratingStyles.get(8).setStyleValue("\u2022]\u2022\u2022\u00b4\u00ba\u00b4\u2022\u00bb " + charSequence2 + " \u00ab\u2022\u00b4\u00ba\u00b4\u2022\u2022[\u2022");
            Decoration_Activity.this.decoratingStyles.get(9).setStyleValue("*\u2022.\u00b8\u2661 " + charSequence2 + " \u2661\u00b8.\u2022*");
            Decoration_Activity.this.decoratingStyles.get(10).setStyleValue("\u2570\u2606\u2606 " + charSequence2 + " \u2606\u2606\u256e");
            Decoration_Activity.this.decoratingStyles.get(11).setStyleValue(".\u2022\u00b0\u00a4*(\u00af`\u2605\u00b4\u00af)*\u00a4\u00b0 " + charSequence2 + " \u00b0\u00a4*(\u00af\u00b4\u2605`\u00af)*\u00a4\u00b0\u2022.");
            Decoration_Activity.this.decoratingStyles.get(12).setStyleValue("(\u00af\u00b4\u2022._.\u2022 " + charSequence2 + " \u2022._.\u2022\u00b4\u00af)");
            Decoration_Activity.this.decoratingStyles.get(13).setStyleValue("\u00b8\u201e.-\u2022~\u00b9\u00b0\u201d\u02c6\u02dc\u00a8 " + charSequence2 + " \u00a8\u02dc\u02c6\u201d\u00b0\u00b9~\u2022-.\u201e\u00b8");
            Decoration_Activity.this.decoratingStyles.get(14).setStyleValue("\u2591\u2592\u2593\u2588 " + charSequence2 + " \u2588\u2593\u2592\u2591");
            Decoration_Activity.this.decoratingStyles.get(15).setStyleValue("\u2591\u2592\u2593\u2588\u25ba\u2500\u2550  " + charSequence2 + " \u2550\u2500\u25c4\u2588\u2593\u2592\u2591");
            Decoration_Activity.this.decoratingStyles.get(16).setStyleValue("\u2605\u5f61 " + charSequence2 + " \u5f61\u2605");
            Decoration_Activity.this.decoratingStyles.get(17).setStyleValue("\u2022\u00b4\u00af`\u2022. " + charSequence2 + " .\u2022\u00b4\u00af`\u2022");
            Decoration_Activity.this.decoratingStyles.get(18).setStyleValue("\u00a7.\u2022\u00b4\u00a8'\u00b0\u00f7\u2022..\u00d7 " + charSequence2 + " \u00d7,.\u2022\u00b4\u00a8'\u00b0\u00f7\u2022..\u00a7");
            Decoration_Activity.this.decoratingStyles.get(19).setStyleValue("\u2022\u00b0\u00af`\u2022\u2022 " + charSequence2 + " \u2022\u2022\u00b4\u00af\u00b0\u2022");
            Decoration_Activity.this.decoratingStyles.get(20).setStyleValue("(\u00af`\u00b7.\u00b8\u00b8.\u00b7\u00b4\u00af`\u00b7.\u00b8\u00b8.-> " + charSequence2 + " <-.\u00b8\u00b8.\u00b7\u00b4\u00af`\u00b7.\u00b8\u00b8.\u00b7\u00b4\u00af)");
            Decoration_Activity.this.decoratingStyles.get(21).setStyleValue("|!\u00a4*'~``~'*\u00a4!| " + charSequence2 + " |!\u00a4*'~``~'*\u00a4!|");
            Decoration_Activity.this.decoratingStyles.get(22).setStyleValue("\u2022._.\u2022\u2022\u00b4\u00af``\u2022.\u00b8\u00b8.\u2022` " + charSequence2 + " `\u2022.\u00b8\u00b8.\u2022\u00b4\u00b4\u00af`\u2022\u2022._.\u2022");
            Decoration_Activity.this.decoratingStyles.get(23).setStyleValue("\u00b8\u201e.-\u2022~\u00b9\u00b0\u201d\u02c6\u02dc\u00a8 " + charSequence2 + " \u00a8\u02dc\u02c6\u201d\u00b0\u00b9~\u2022-.\u201e\u00b8");
            Decoration_Activity.this.decoratingStyles.get(24).setStyleValue("(\u00af\u00b4\u2022._.\u2022 " + charSequence2 + " \u2022._.\u2022\u00b4\u00af)");
            Decoration_Activity.this.decoratingStyles.get(25).setStyleValue("\u2022\u2022\u00a4(`\u00d7[\u00a4 " + charSequence2 + " \u00a4]\u00d7\u00b4)\u00a4\u2022\u2022");
            Decoration_Activity.this.decoratingStyles.get(26).setStyleValue("\u2022\u00b4\u00af`\u2022\u00bb " + charSequence2 + " \u00ab\u2022\u00b4\u00af`\u2022");
            Decoration_Activity.this.decoratingStyles.get(27).setStyleValue(" .o0\u00d7X\u00d70o. " + charSequence2 + " .o0\u00d7X\u00d70o.");
            Decoration_Activity.this.decoratingStyles.get(28).setStyleValue("\u00a4\u00b8\u00b8.\u2022\u00b4\u00af`\u2022\u00b8\u00b8.\u2022..>> " + charSequence2 + " <<..\u2022.\u00b8\u00b8\u2022\u00b4\u00af`\u2022.\u00b8\u00b8\u00a4");
            Decoration_Activity.this.decoratingStyles.get(29).setStyleValue("\u2014(\u2022\u2022\u00f7[ " + charSequence2 + " ]\u00f7\u2022\u2022)\u2014");
            Decoration_Activity.this.decoratingStyles.get(30).setStyleValue("\u00b8,\u00f8\u00a4\u00ba\u00b0`\u00b0\u00ba\u00a4\u00f8,\u00b8 " + charSequence2 + " \u00b8,\u00f8\u00a4\u00ba\u00b0`\u00b0\u00ba\u00a4\u00f8,\u00b8");
            Decoration_Activity.this.decoratingStyles.get(31).setStyleValue("`\u2022.\u00b8\u00b8.\u2022\u00b4\u00b4\u00af`\u2022\u2022._.\u2022 " + charSequence2 + " \u2022._.\u2022\u2022`\u00af\u00b4\u00b4\u2022.\u00b8\u00b8.\u2022`");
            Decoration_Activity.this.decoratingStyles.get(32).setStyleValue(",-*' ^ '~*-.,_,.-*~ " + charSequence2 + " ~*-.,_,.-*~' ^ '*-,");
            Decoration_Activity.this.decoratingStyles.get(33).setStyleValue("`\u2022.,\u00b8\u00b8,.\u2022\u00b4\u00af " + charSequence2 + " \u00af`\u2022.,\u00b8\u00b8,.\u2022\u00b4");
            Decoration_Activity.this.decoratingStyles.get(34).setStyleValue("\u21a4\u21a4\u21a4\u21a4\u21a4 " + charSequence2 + " \u21a6\u21a6\u21a6\u21a6\u21a6");
            Decoration_Activity.this.decoratingStyles.get(35).setStyleValue("\u27b6\u27b6\u27b6\u27b6\u27b6 " + charSequence2 + " \u27b7\u27b7\u27b7\u27b7\u27b7");
            Decoration_Activity.this.decoratingStyles.get(36).setStyleValue("\u21ab\u21ab\u21ab\u21ab\u21ab " + charSequence2 + " \u21ac\u21ac\u21ac\u21ac\u21ac");
            Decoration_Activity.this.decoratingStyles.get(37).setStyleValue("\u00b7.\u00b8\u00b8.\u00b7\u2669\u266a\u266b " + charSequence2 + " \u266b\u266a\u2669\u00b7.\u00b8\u00b8.\u00b7");
            Decoration_Activity.this.decoratingStyles.get(38).setStyleValue("\u255a\u00bb\u2605\u00ab\u255d " + charSequence2 + " \u255a\u00bb\u2605\u00ab\u255d");
            Decoration_Activity.this.decoratingStyles.get(39).setStyleValue("]|I{\u2022------\u00bb " + charSequence2 + " \u00ab------\u2022}I|[");
            Decoration_Activity.this.decoratingStyles.get(40).setStyleValue("\u2580\u2584\u2580\u2584\u2580\u2584 " + charSequence2 + " \u2584\u2580\u2584\u2580\u2584\u2580");
            Decoration_Activity.this.decoratingStyles.get(41).setStyleValue("(-_-) " + charSequence2 + " (-_-)");
            Decoration_Activity.this.decoratingStyles.get(42).setStyleValue("\u2022\u00b4\u00af`\u2022. " + charSequence2 + " .\u2022\u00b4\u00af`\u2022");
            Decoration_Activity.this.decoratingStyles.get(43).setStyleValue("-\u6f2b~*'\u00a8\u00af\u00a8'*\u00b7\u821e~ " + charSequence2 + " ~\u821e*'\u00a8\u00af\u00a8'*\u00b7~\u6f2b-");
            Decoration_Activity.this.decoratingStyles.get(44).setStyleValue("\u0e51\u06de\u0e51,\u00b8\u00b8,\u00f8\u00a4\u00ba\u00b0`\u00b0\u0e51\u06e9 " + charSequence2 + " \u0e51\u06e9 ,\u00b8\u00b8,\u00f8\u00a4\u00ba\u00b0`\u00b0\u0e51\u06de\u0e51");
            Decoration_Activity.this.decoratingStyles.get(45).setStyleValue(".\u2022\u00b0\u00a4*(\u00af`\u2605\u00b4\u00af)*\u00a4\u00b0 " + charSequence2 + " \u00b0\u00a4*(\u00af\u00b4\u2605`\u00af)*\u00a4\u00b0\u2022.");
            Decoration_Activity.this.decoratingStyles.get(46).setStyleValue("\u2022\u2022.\u2022\u00b4\u00af`\u2022.\u2022\u2022 " + charSequence2 + " \u2022\u2022.\u2022\u00b4\u00af`\u2022.\u2022\u2022");
            Decoration_Activity.this.decoratingStyles.get(47).setStyleValue("\u00a4\u00b8\u00b8.\u2022\u00b4\u00af`\u2022\u00b8\u00b8.\u2022..>> " + charSequence2 + " <<..\u2022.\u00b8\u00b8\u2022\u00b4\u00af`\u2022.\u00b8\u00b8\u00a4");
            Decoration_Activity.this.styleAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onBackPressed() {
        Decoration_Activity.this.finish();
    }
}
