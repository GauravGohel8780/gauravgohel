package com.statussaver.wacaption.gbversion.StatusSaver.util;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import java.io.File;

/* loaded from: classes3.dex */
public class iUtils {
    public static boolean isPackageInstalled(Context context, String str) {
        try {
            context.getPackageManager().getPackageInfo(str, 0);
            return true;
        } catch (PackageManager.NameNotFoundException unused) {
            return false;
        }
    }

    public static void scanFile(Activity activity, String str) {
        MediaScannerConnection.scanFile(activity, new String[]{Environment.getExternalStorageDirectory().getAbsolutePath() + Const.SAVE_FOLDER_NAME + str}, new String[]{"*/*"}, new MediaScannerConnection.MediaScannerConnectionClient() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.util.iUtils.1
            @Override // android.media.MediaScannerConnection.MediaScannerConnectionClient
            public void onMediaScannerConnected() {
            }

            @Override // android.media.MediaScannerConnection.OnScanCompletedListener
            public void onScanCompleted(String str2, Uri uri) {
                Log.d("path: ", str2);
            }
        });
    }

    public static void checkFolder() {
        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + Const.SAVE_FOLDER_NAME);
        boolean exists = file.exists();
        if (!exists) {
            exists = file.mkdir();
        }
        if (exists) {
            Log.d("Folder", "Already Created");
        }
    }
}
