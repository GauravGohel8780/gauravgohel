package com.statussaver.wacaption.gbversion.StatusSaver.activity;

import android.annotation.SuppressLint;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import com.bumptech.glide.Glide;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.newwautl.Utils;

/* loaded from: classes3.dex */
public class SavedViewer extends AppCompatActivity {
    SavedViewer activity;
    ImageView imageView;
    String pack;
    String path;
    String type;
    VideoView videoView;

    @SuppressLint("WrongConstant")
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_saved_viewer);
        this.activity = this;
//        AppManage.show_anim_header(this, (RelativeLayout) findViewById(R.id.rl_anim_header));
//        AppManage.getInstance(this).showNativeAds(this, (ViewGroup) findViewById(R.id.native_container), (ImageView) findViewById(R.id.native_space_img), 2);
//        AppManage.getInstance(this).showBannerAds(this, (ViewGroup) findViewById(R.id.native_container1));
        Bundle extras = getIntent().getExtras();
        this.path = extras.getString("path");
        this.type = extras.getString("type");
        this.pack = extras.getString("pack");
        findId();
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.SavedViewer.1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                SavedViewer.this.lambda$onCreate$0$SavedViewer(view);
            }
        });
        if (this.type.contains(Utils.IMAGE)) {
            this.videoView.setVisibility(8);
            Glide.with((FragmentActivity) this).load(this.path).into(this.imageView);
            return;
        }
        this.imageView.setVisibility(8);
        this.videoView.setVideoURI(Uri.parse(this.path));
        this.videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.SavedViewer.2
            @Override // android.media.MediaPlayer.OnPreparedListener
            public final void onPrepared(MediaPlayer mediaPlayer) {
                SavedViewer.this.lambda$onCreate$1$SavedViewer(mediaPlayer);
            }
        });
    }

    public void lambda$onCreate$0$SavedViewer(View view) {
        finish();
    }

    public void lambda$onCreate$1$SavedViewer(MediaPlayer mediaPlayer) {
        mediaPlayer.start();
        this.videoView.setMediaController(new MediaController(this));
    }

    private void findId() {
        this.imageView = (ImageView) findViewById(R.id.saved_image);
        this.videoView = (VideoView) findViewById(R.id.saved_video);
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
//        AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.SavedViewer.3
//            @Override // com.pesonal.adsdk.MyCallback
//            public void callbackCall() {
                SavedViewer.this.finish();
//            }
//        }, AppManage.app_mainClickCntSwAd);
    }
}
