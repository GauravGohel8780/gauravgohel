package com.statussaver.wacaption.gbversion.WhatsShake;

import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import com.statussaver.wacaption.gbversion.StatusSaver.util.WhitelistCheck;

/* loaded from: classes3.dex */
public class GBWhats_ShakeService extends Service implements SensorEventListener {
    private float mAccel;
    private float mAccelCurrent;
    private float mAccelLast;
    private SensorManager mSensorManager;

    @Override // android.hardware.SensorEventListener
    public void onAccuracyChanged(Sensor sensor, int i) {
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.hardware.SensorEventListener
    public void onSensorChanged(SensorEvent sensorEvent) {
        float[] fArr = sensorEvent.values;
        float f = fArr[0];
        float f2 = fArr[1];
        float f3 = fArr[2];
        this.mAccelLast = this.mAccelCurrent;
        float sqrt = (float) Math.sqrt((f3 * f3) + (f2 * f2) + (f * f));
        this.mAccelCurrent = sqrt;
        float f4 = (sqrt - this.mAccelLast) + (this.mAccel * 0.9f);
        this.mAccel = f4;
        if (f4 <= 11.0f || !GBWhats_WhatsShakeActivity.ShakeCheck) {
            return;
        }
        PackageManager packageManager = getPackageManager();
        boolean isPackageInstalled = GBWhats_Internetconnection.isPackageInstalled(WhitelistCheck.SMB_WHATSAPP_PACKAGE_NAME, packageManager);
        if (GBWhats_Internetconnection.isPackageInstalled(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME, packageManager)) {
            try {
                startActivity(getPackageManager().getLaunchIntentForPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME));
            } catch (Exception e) {
                Log.e("ERROR", e.toString());
            }
        } else if (!isPackageInstalled) {
        } else {
            try {
                startActivity(getPackageManager().getLaunchIntentForPackage(WhitelistCheck.SMB_WHATSAPP_PACKAGE_NAME));
            } catch (Exception e2) {
                Log.e("ERROR", e2.toString());
            }
        }
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        SensorManager sensorManager = (SensorManager) getSystemService("sensor");
        this.mSensorManager = sensorManager;
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(1), 2, new Handler());
        return 1;
    }
}
