package com.statussaver.wacaption.gbversion.newwautl;

import android.content.Context;
import android.content.pm.PackageManager;

/* loaded from: classes3.dex */
public class Utils {
    public static final String AUDIO = "audio";
    public static final String DOCUMENT = "document";
    public static final String GIF = "gif";
    public static final String IMAGE = "image";
    public static final String STICKER = "sticker";
    public static final String VIDEO = "video";
    public static final String VOICE = "status";
    public static final String WALLPAPER = "wallpaper";
    public static boolean iswApp = true;

    public static boolean appInstalledOrNot(Context context, String str) {
        try {
            context.getPackageManager().getPackageInfo(str, 1);
            return true;
        } catch (PackageManager.NameNotFoundException unused) {
            return false;
        }
    }
}
