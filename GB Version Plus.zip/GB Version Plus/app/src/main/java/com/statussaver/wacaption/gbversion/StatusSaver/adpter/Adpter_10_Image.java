package com.statussaver.wacaption.gbversion.StatusSaver.adpter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_DisplayNew_10_images;
import com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_StorieSaverBase;
import com.statussaver.wacaption.gbversion.StatusSaver.model.ImagesModel;
import com.statussaver.wacaption.gbversion.StatusSaver.util.Const;
import com.statussaver.wacaption.gbversion.StatusSaver.util.CustomToast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.ArrayList;

/* loaded from: classes3.dex */
public class Adpter_10_Image extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    public static ArrayList<ImagesModel> mImageResponsesList2;
    public Activity mContext;
    public ArrayList<ImagesModel> mImageResponsesList;
    private File mRoot;

    public Adpter_10_Image(Activity activity, ArrayList<ImagesModel> arrayList) {
        this.mContext = activity;
        this.mImageResponsesList = arrayList;
    }

    public static boolean isAppInstalled(Context context, String str) {
        try {
            context.getPackageManager().getApplicationInfo(str, 0);
            return true;
        } catch (PackageManager.NameNotFoundException unused) {
            return false;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(this.mContext).inflate(R.layout.item_10_status, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        viewHolder2.mIStatusIvPlay.setVisibility(8);
        viewHolder2.bindView(i);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.mImageResponsesList.size();
    }

    public void createNewFile(String str, String str2) {
        String str3 = str + str2.substring(45);
        File file = new File(str3);
        if (file.isFile() || file.exists()) {
            showToast("File Already Exists, Status Saved");
            Log.i("File Status", "File already exists");
        } else {
            Log.i("File Status", "Doesnt exist");
            try {
                if (file.createNewFile()) {
                    Log.i("File Status", "File Created");
                    copyStatusIntoFile(str3, str2);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        this.mRoot = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "/" + this.mContext.getResources().getString(R.string.app_name));
        if (Build.VERSION.SDK_INT >= 19) {
            new SingleMediaScanner(this.mContext.getApplicationContext(), new File(str, str2.substring(45)));
            this.mContext.sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.parse("file://" + str)));
            return;
        }
        this.mContext.sendBroadcast(new Intent("android.intent.action.MEDIA_MOUNTED", Uri.parse("file://" + str)));
    }

    private void copyStatusIntoFile(String str, String str2) {
        try {
            FileChannel channel = new FileInputStream(new File(str2)).getChannel();
            if (new FileOutputStream(new File(str)).getChannel().transferFrom(channel, 0L, channel.size()) > 0) {
                Log.i("Copy Status: ", "Copied");
                showToast("Status Saved");
                reScanSdCard();
                return;
            }
            Log.i("Copy Status: ", "Cant copy");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
    }

    private void reScanSdCard() {
        if (Build.VERSION.SDK_INT >= 19) {
            Activity activity = this.mContext;
            activity.sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.parse("file://" + Environment.getExternalStorageDirectory())));
            return;
        }
        Activity activity2 = this.mContext;
        activity2.sendBroadcast(new Intent("android.intent.action.MEDIA_MOUNTED", Uri.parse("file://" + Environment.getExternalStorageDirectory())));
    }

    public void showToast(String str) {
        CustomToast customToast = new CustomToast(this.mContext);
        customToast.setCustomView(str);
        customToast.setDuration(0);
        customToast.show();
    }

    /* loaded from: classes3.dex */
    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView mIStatusIvLogo;
        ImageView mIStatusIvPlay;
        ImageView mIStatusIvSave;
        ImageView mIStatusIvShare;
        ImageView mIStatusIvWhatsapp;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        ViewHolder(View view) {
            super(view);
            this.mIStatusIvLogo = (ImageView) view.findViewById(R.id.iStatus_ivLogo);
            this.mIStatusIvSave = (ImageView) view.findViewById(R.id.iStatus_ivSave);
            this.mIStatusIvPlay = (ImageView) view.findViewById(R.id.iStatus_ivPlay);
        }

        public void bindView(final int i) {
            Activity_StorieSaverBase.loadImage(Adpter_10_Image.this.mContext, this.mIStatusIvLogo, Adpter_10_Image.this.mImageResponsesList.get(i).getImagePath());
            this.mIStatusIvSave.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.adpter.Adpter_10_Image.ViewHolder.1
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    String imagePath = Adpter_10_Image.this.mImageResponsesList.get(i).getImagePath();
                    Environment.getExternalStorageDirectory();
                    File file = new File(Const.savedData);
                    if (file.isDirectory() || file.exists()) {
                        Adpter_10_Image.this.createNewFile(Const.savedData, imagePath);
                    } else if (!file.mkdirs()) {
                    } else {
                        Adpter_10_Image.this.createNewFile(Const.savedData, imagePath);
                    }
                }
            });
            this.mIStatusIvLogo.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.adpter.Adpter_10_Image.ViewHolder.2
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
//                    AppManage.getInstance(Adpter_10_Image.this.mContext).showInterstitialAd(Adpter_10_Image.this.mContext, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.adpter.Adpter_10_Image.ViewHolder.2.1
//                        @Override // com.pesonal.adsdk.MyCallback
//                        public void callbackCall() {
                            Adpter_10_Image.mImageResponsesList2 = Adpter_10_Image.this.mImageResponsesList;
                            Intent intent = new Intent(Adpter_10_Image.this.mContext, Activity_DisplayNew_10_images.class);
                            intent.putExtra("id", i);
                            intent.putExtra("flag", "Images");
                            Adpter_10_Image.this.mContext.startActivity(intent);
//                        }
//                    }, AppManage.app_mainClickCntSwAd);
                }
            });
        }
    }

    /* loaded from: classes3.dex */
    public class SingleMediaScanner implements MediaScannerConnection.MediaScannerConnectionClient {
        private File mFile;
        private MediaScannerConnection mMs;

        public SingleMediaScanner(Context context, File file) {
            this.mFile = file;
            MediaScannerConnection mediaScannerConnection = new MediaScannerConnection(context, this);
            this.mMs = mediaScannerConnection;
            mediaScannerConnection.connect();
        }

        @Override // android.media.MediaScannerConnection.MediaScannerConnectionClient
        public void onMediaScannerConnected() {
            this.mMs.scanFile(this.mFile.getAbsolutePath(), null);
        }

        @Override // android.media.MediaScannerConnection.OnScanCompletedListener
        public void onScanCompleted(String str, Uri uri) {
            this.mMs.disconnect();
        }
    }
}
