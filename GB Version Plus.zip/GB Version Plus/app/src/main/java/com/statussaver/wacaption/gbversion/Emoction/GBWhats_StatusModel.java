package com.statussaver.wacaption.gbversion.Emoction;

import android.os.Parcel;
import android.os.Parcelable;

public class GBWhats_StatusModel implements Parcelable {
    public static final Parcelable.Creator<GBWhats_StatusModel> CREATOR = new Parcelable.Creator<GBWhats_StatusModel>() { // from class: com.statussaver.wacaption.gbversion.Emoction.GBWhats_StatusModel.1
        @Override
        public GBWhats_StatusModel createFromParcel(Parcel parcel) {
            return new GBWhats_StatusModel(parcel);
        }

        @Override
        public GBWhats_StatusModel[] newArray(int i) {
            return new GBWhats_StatusModel[i];
        }
    };
    private String filepath;
    public boolean selected = false;

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.filepath);
    }

    public GBWhats_StatusModel(Parcel parcel) {
        this.filepath = parcel.readString();
    }

}
