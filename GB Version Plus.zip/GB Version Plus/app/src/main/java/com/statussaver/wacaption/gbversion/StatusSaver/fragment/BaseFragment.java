package com.statussaver.wacaption.gbversion.StatusSaver.fragment;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.storage.StorageManager;
import androidx.core.view.PointerIconCompat;
import androidx.fragment.app.Fragment;
import com.statussaver.wacaption.gbversion.StatusSaver.util.WhitelistCheck;
import com.statussaver.wacaption.gbversion.StatusSaver.util.iUtils;
import java.io.File;

/* loaded from: classes3.dex */
public class BaseFragment extends Fragment {
    public static final int MY_PERMISSIONS_REQUEST_WRITE_STORAGE = 123;
    final int REQUEST_ACTION_OPEN_DOCUMENT_TREE = PointerIconCompat.TYPE_COPY;

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    public void grantAnd11permission(Context context) {
        Intent intent;
        iUtils.isPackageInstalled(context, WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
        StorageManager storageManager = (StorageManager) context.getSystemService("storage");
        String whatsupFolder = getWhatsupFolder();
        if (Build.VERSION.SDK_INT >= 29) {
            intent = storageManager.getPrimaryStorageVolume().createOpenDocumentTreeIntent();
            String replace = intent.getParcelableExtra("android.provider.extra.INITIAL_URI").toString().replace("/root/", "/document/");
            intent.putExtra("android.provider.extra.INITIAL_URI", Uri.parse(replace + "%3A" + whatsupFolder));
        } else {
            intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
            intent.putExtra("android.provider.extra.INITIAL_URI", Uri.parse(whatsupFolder));
        }
        intent.addFlags(2);
        intent.addFlags(1);
        intent.addFlags(128);
        intent.addFlags(64);
        startActivityForResult(intent, PointerIconCompat.TYPE_COPY);
    }

    public String getWhatsupFolder() {
        StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStorageDirectory());
        sb.append(File.separator);
        sb.append("Android/media/com.whatsapp/WhatsApp");
        sb.append(File.separator);
        sb.append("Media");
        sb.append(File.separator);
        sb.append(".Statuses");
        return new File(sb.toString()).isDirectory() ? "Android%2Fmedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F.Statuses" : "WhatsApp%2FMedia%2F.Statuses";
    }

    public void CheckPermission(String str) {
        SharedPreferences.Editor edit = getActivity().getSharedPreferences("whatsapp_pref", 0).edit();
        edit.putString("Grant", str);
        edit.apply();
    }
}
