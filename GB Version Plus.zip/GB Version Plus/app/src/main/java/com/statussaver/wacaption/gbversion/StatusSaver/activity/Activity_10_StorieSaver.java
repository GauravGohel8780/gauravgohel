package com.statussaver.wacaption.gbversion.StatusSaver.activity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
import com.google.android.material.tabs.TabLayout;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.StatusSaver.pageer.StorieSaver_10_TabPager;

/* loaded from: classes3.dex */
public class Activity_10_StorieSaver extends AppCompatActivity {
    Activity_10_StorieSaver activity;
    ViewPager mPager;
    TabLayout mTabLayout;
    private int[] tabIconsselect = {R.drawable.photo_select, R.drawable.video_select};
    private int[] tabIconsunselect = {R.drawable.photo, R.drawable.video};

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_10_storiesaver);
        this.activity = this;
        ((TextView) findViewById(R.id.title)).setText("Recent Status");
        ((ImageView) findViewById(R.id.iv_back)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_10_StorieSaver.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Activity_10_StorieSaver.this.onBackPressed();
            }
        });
        this.mTabLayout = (TabLayout) findViewById(R.id.tab_layout);
        this.mPager = (ViewPager) findViewById(R.id.pager);
        final TabLayout tabLayout = (TabLayout) findViewById(R.id.tab_layout);
        this.mTabLayout = tabLayout;
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.photo_select));
        TabLayout tabLayout2 = this.mTabLayout;
        tabLayout2.addTab(tabLayout2.newTab().setIcon(R.drawable.video_select));
        this.mTabLayout.setTabGravity(0);
        setupTabIcons();
        for (int i = 0; i < this.mTabLayout.getTabCount(); i++) {
            this.mTabLayout.getTabAt(i).setCustomView((ImageView) LayoutInflater.from(getApplicationContext()).inflate(R.layout.custom_tab, (ViewGroup) null));
        }
        this.mPager.setAdapter(new StorieSaver_10_TabPager(getSupportFragmentManager(), this.mTabLayout.getTabCount()));
        this.mPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(this.mTabLayout));
        this.mTabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_10_StorieSaver.2
            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            public void onTabReselected(TabLayout.Tab tab) {
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            public void onTabUnselected(TabLayout.Tab tab) {
                tabLayout.getTabAt(0).setIcon(Activity_10_StorieSaver.this.tabIconsunselect[0]);
                tabLayout.getTabAt(1).setIcon(Activity_10_StorieSaver.this.tabIconsunselect[1]);
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            public void onTabSelected(TabLayout.Tab tab) {
                Activity_10_StorieSaver.this.mPager.setCurrentItem(tab.getPosition());
                if (tab.getPosition() == 0) {
                    tabLayout.getTabAt(0).setIcon(Activity_10_StorieSaver.this.tabIconsselect[0]);
                }
                if (tab.getPosition() == 1) {
                    tabLayout.getTabAt(1).setIcon(Activity_10_StorieSaver.this.tabIconsselect[1]);
                }
            }
        });
    }

    private void setupTabIcons() {
        this.mTabLayout.getTabAt(0).setIcon(this.tabIconsselect[0]);
        this.mTabLayout.getTabAt(1).setIcon(this.tabIconsunselect[1]);
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
//        AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_10_StorieSaver.3
//            @Override // com.pesonal.adsdk.MyCallback
//            public void callbackCall() {
                Activity_10_StorieSaver.this.finish();
//            }
//        }, AppManage.app_mainClickCntSwAd);
    }
}
