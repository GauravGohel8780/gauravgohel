package com.statussaver.wacaption.gbversion.StatusSaver.fragment;

import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.internal.view.SupportMenu;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.StatusSaver.adpter.Adpter_10_Image;
import com.statussaver.wacaption.gbversion.StatusSaver.model.ImagesModel;
import com.statussaver.wacaption.gbversion.StatusSaver.util.ItemOffsetDecoration;
import com.statussaver.wacaption.gbversion.StatusSaver.util.SdCardHelper;
import java.io.File;
import java.util.ArrayList;

/* loaded from: classes3.dex */
public class Fragment_10_Images extends Fragment {
    ImageView mErrorView;
    Adpter_10_Image mImageAdapter;
    public ArrayList<ImagesModel> mImageList;
    RecyclerView mTImageRvImagesList;
    SwipeRefreshLayout mTImageSrlImageView;

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_10_image, viewGroup, false);
        this.mTImageRvImagesList = (RecyclerView) inflate.findViewById(R.id.tImage_rvImagesList);
        this.mTImageSrlImageView = (SwipeRefreshLayout) inflate.findViewById(R.id.tImage_srlImageView);
        this.mErrorView = (ImageView) inflate.findViewById(R.id.error_view);
        check();
        this.mImageList = new ArrayList<>();
        copyAllStatusIntoFile();
        this.mImageAdapter = new Adpter_10_Image(getActivity(), this.mImageList);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 2);
        this.mTImageRvImagesList.addItemDecoration(new ItemOffsetDecoration(getActivity(), R.dimen.photos_list_spacing));
        this.mTImageRvImagesList.setLayoutManager(gridLayoutManager);
        this.mTImageRvImagesList.setNestedScrollingEnabled(true);
        ((SimpleItemAnimator) this.mTImageRvImagesList.getItemAnimator()).setSupportsChangeAnimations(false);
        this.mTImageRvImagesList.setAdapter(this.mImageAdapter);
        this.mImageAdapter.notifyDataSetChanged();
        doStatusCheck();
        this.mTImageSrlImageView.setColorSchemeColors(SupportMenu.CATEGORY_MASK, -16711936, -16776961, -16711681);
        this.mTImageSrlImageView.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.fragment.Fragment_10_Images.1
            @Override // androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
            public void onRefresh() {
                if (Fragment_10_Images.this.mTImageRvImagesList == null || Fragment_10_Images.this.mImageAdapter == null) {
                    return;
                }
                Fragment_10_Images.this.mTImageRvImagesList.getRecycledViewPool().clear();
                Fragment_10_Images.this.mImageList.clear();
                Fragment_10_Images.this.mImageAdapter.notifyDataSetChanged();
                Fragment_10_Images.this.copyAllStatusIntoFile();
                Fragment_10_Images.this.doStatusCheck();
            }
        });
        return inflate;
    }

    public void doStatusCheck() {
        if (this.mImageList.size() == 0) {
            doCheckFile();
        } else {
            this.mTImageSrlImageView.setRefreshing(false);
        }
        Adpter_10_Image adpter_10_Image = this.mImageAdapter;
        if (adpter_10_Image != null) {
            adpter_10_Image.notifyDataSetChanged();
        }
    }

    private void doCheckFile() {
        this.mTImageSrlImageView.setRefreshing(false);
        this.mErrorView.setVisibility(0);
    }

    public void copyAllStatusIntoFile() {
        this.mTImageSrlImageView.setRefreshing(false);
        if (SdCardHelper.isSdCardPresent()) {
            File externalStorageDirectory = Environment.getExternalStorageDirectory();
            File file = new File(externalStorageDirectory.getAbsolutePath() + "/WhatsApp/Media/.Statuses/");
            if (file.isDirectory()) {
                File[] listFiles = file.listFiles();
                if (listFiles == null || listFiles.length == 0) {
                    doCheckFile();
                    return;
                }
                for (int i = 0; i < listFiles.length; i++) {
                    if (listFiles[i].getName().contains(".jpg") || listFiles[i].getName().contains(".jpeg") || listFiles[i].getName().contains(".png")) {
                        ImagesModel imagesModel = new ImagesModel();
                        imagesModel.setImageName(listFiles[i].getName());
                        imagesModel.setImagePath(listFiles[i].getAbsolutePath());
                        this.mImageList.add(imagesModel);
                    }
                    if (this.mImageList.size() == 0) {
                        doCheckFile();
                    } else {
                        this.mErrorView.setVisibility(8);
                    }
                }
                return;
            }
            doCheckFile();
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
    }

    public void check() {
        if (ContextCompat.checkSelfPermission(getContext().getApplicationContext(), "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            requestStoragePermission();
        }
    }

    private void requestStoragePermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), "android.permission.WRITE_EXTERNAL_STORAGE")) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 0);
            Toast.makeText(getContext(), "Permission needed to save images and videos", 0).show();
            return;
        }
        ActivityCompat.requestPermissions(getActivity(), new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 0);
    }

    @Override // androidx.fragment.app.Fragment
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 0) {
            super.onRequestPermissionsResult(i, strArr, iArr);
        } else if (iArr.length == 1 && iArr[0] == 0) {
            Toast.makeText(getContext(), "Storage Permission Granted", 0).show();
        } else {
            Toast.makeText(getContext(), "Storage permission required\nto save images & videos", 0).show();
            requestStoragePermission();
        }
    }
}
