package com.statussaver.wacaption.gbversion.WAUtil.adpter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.WAUtil.WhatsSaveActivity;
import java.util.List;

/* loaded from: classes3.dex */
public class GbVersonAdpter extends RecyclerView.Adapter<GbVersonAdpter.MyView> {
    Context actContext;
    String checkId;
    List<String> listOfStatus;
    String txtTitle;

    public GbVersonAdpter(Context context, List<String> list, String str, String str2) {
        this.actContext = context;
        this.listOfStatus = list;
        this.checkId = str;
        this.txtTitle = str2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public MyView onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyView(LayoutInflater.from(this.actContext).inflate(R.layout.itm_rec_img, viewGroup, false));
    }

    public void onBindViewHolder(MyView myView, final int i) {
        Glide.with(this.actContext).load(this.listOfStatus.get(i)).centerCrop().into(myView.whats);
        myView.whats.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.adpter.GbVersonAdpter.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Intent intent = new Intent(GbVersonAdpter.this.actContext, WhatsSaveActivity.class);
                intent.putExtra("status", GbVersonAdpter.this.listOfStatus.get(i));
                intent.putExtra("checkId", GbVersonAdpter.this.checkId);
                intent.putExtra("txtTitle", GbVersonAdpter.this.txtTitle);
                GbVersonAdpter.this.actContext.startActivity(intent);
            }
        });
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.listOfStatus.size();
    }

    /* loaded from: classes3.dex */
    public class MyView extends RecyclerView.ViewHolder {
        ImageView whats;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public MyView(View view) {
            super(view);
            this.whats = (ImageView) view.findViewById(R.id.img_whatsapp);
        }
    }
}
