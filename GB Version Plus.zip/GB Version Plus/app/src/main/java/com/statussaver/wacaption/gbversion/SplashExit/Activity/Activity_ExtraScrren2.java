package com.statussaver.wacaption.gbversion.SplashExit.Activity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.statussaver.wacaption.gbversion.MainActivity;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.SplashExit.Splash_Utils.Glob;

/* loaded from: classes3.dex */
public class Activity_ExtraScrren2 extends AppCompatActivity {
    Activity_ExtraScrren2 activity;
    ImageView backImg;
    boolean doubleBackToExitPressedOnce = false;
    private ImageView text_gotoapp;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity__extra_scrren2);
        this.activity = this;
//        if (AppManage.playgamebutton == 1) {
//            findViewById(R.id.play_games).setVisibility(0);
//            findViewById(R.id.play_games).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren2.1
//                @Override // android.view.View.OnClickListener
//                public void onClick(View view) {
//                    AppManage.openChromeCustomTabUrl(Activity_ExtraScrren2.this.activity, AppManage.playgamelink);
//                }
//            });
//        } else {
//            findViewById(R.id.play_games).setVisibility(8);
//        }
        ImageView imageView = (ImageView) findViewById(R.id.text_gotoapp);
        this.text_gotoapp = imageView;
        imageView.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren2.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                if (Glob.checkMultiplePermissions(Activity_ExtraScrren2.this.activity)) {
//                    if (AppManage.extrascreen3 == 1) {
//                        AppManage.getInstance(Activity_ExtraScrren2.this.activity).showInterstitialAd(Activity_ExtraScrren2.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren2.2.1
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
                                Activity_ExtraScrren2.this.startActivity(new Intent(Activity_ExtraScrren2.this, Activity_ExtraScrren3.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    } else if (AppManage.extrascreen4 == 1) {
//                        AppManage.getInstance(Activity_ExtraScrren2.this.activity).showInterstitialAd(Activity_ExtraScrren2.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren2.2.2
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
//                                Activity_ExtraScrren2.this.startActivity(new Intent(Activity_ExtraScrren2.this, Activity_ExtraScrren4.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    } else if (AppManage.extrascreen5 == 1) {
//                        AppManage.getInstance(Activity_ExtraScrren2.this.activity).showInterstitialAd(Activity_ExtraScrren2.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren2.2.3
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
//                                Activity_ExtraScrren2.this.startActivity(new Intent(Activity_ExtraScrren2.this, Activity_ExtraScrren5.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    } else if (AppManage.extrascreen6 == 1) {
//                        AppManage.getInstance(Activity_ExtraScrren2.this.activity).showInterstitialAd(Activity_ExtraScrren2.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren2.2.4
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
//                                Activity_ExtraScrren2.this.startActivity(new Intent(Activity_ExtraScrren2.this, Activity_ExtraScrren6.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    } else {
//                        AppManage.getInstance(Activity_ExtraScrren2.this.activity).showInterstitialAd(Activity_ExtraScrren2.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren2.2.5
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
//                                Activity_ExtraScrren2.this.startActivity(new Intent(Activity_ExtraScrren2.this, MainActivity.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    }
//                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }


    //    @Override // androidx.activity.ComponentActivity, android.app.Activity
//    public void onBackPressed() {
//        if (AppManage.extrascreen1 == 1) {
//            AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren2.3
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
//                    Activity_ExtraScrren2.this.finish();
//                }
//            }, AppManage.app_mainClickCntSwAd);
//        } else if (AppManage.startScreen == 1) {
//            AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren2.4
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
//                    Activity_ExtraScrren2.this.finish();
//                }
//            }, AppManage.app_mainClickCntSwAd);
//        } else if (Glob.isOnline(this.activity)) {
//            if (AppManage.exitscreen == 1) {
//                startActivity(new Intent(this, BackActivity.class));
//            } else if (AppManage.exitscreendialog == 1) {
//                final Dialog dialog = new Dialog(this, R.style.MyDialog);
//                dialog.setCanceledOnTouchOutside(true);
//                dialog.setContentView(R.layout.backdlg);
//                dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
//                AppManage.show_anims_3btn(this, (RelativeLayout) dialog.findViewById(R.id.qureka), (RelativeLayout) dialog.findViewById(R.id.iv_predchamp), (RelativeLayout) dialog.findViewById(R.id.iv_mgl));
//                ((ImageView) dialog.findViewById(R.id.exit)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren2.5
//                    @Override // android.view.View.OnClickListener
//                    public void onClick(View view) {
//                        AppManage.getInstance(Activity_ExtraScrren2.this.activity).showInterstitialBackAd(Activity_ExtraScrren2.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren2.5.1
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
//                                Activity_ExtraScrren2.this.startActivity(new Intent(Activity_ExtraScrren2.this, Exit_Act.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    }
//                });
//                ((ImageView) dialog.findViewById(R.id.cancel)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren2.6
//                    @Override // android.view.View.OnClickListener
//                    public void onClick(View view) {
//                        dialog.dismiss();
//                    }
//                });
//                dialog.show();
//            } else if (this.doubleBackToExitPressedOnce) {
//                finishAffinity();
//            } else {
//                this.doubleBackToExitPressedOnce = true;
//                Toast.makeText(this, "Please click BACK again to exit", 0).show();
//                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren2.7
//                    @Override // java.lang.Runnable
//                    public void run() {
//                        Activity_ExtraScrren2.this.doubleBackToExitPressedOnce = false;
//                    }
//                }, 2000L);
//            }
//        } else if (this.doubleBackToExitPressedOnce) {
//            finishAffinity();
//        } else {
//            this.doubleBackToExitPressedOnce = true;
//            Toast.makeText(this, "Please click BACK again to exit", 0).show();
//            new Handler().postDelayed(new Runnable() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren2.8
//                @Override // java.lang.Runnable
//                public void run() {
//                    Activity_ExtraScrren2.this.doubleBackToExitPressedOnce = false;
//                }
//            }, 2000L);
//        }
//    }
}
