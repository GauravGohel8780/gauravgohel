package com.statussaver.wacaption.gbversion.WAUtil.adpter;

import android.content.Context;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import com.statussaver.wacaption.gbversion.WAUtil.frgmnt.S_ImgFragment;
import com.statussaver.wacaption.gbversion.WAUtil.frgmnt.S_VideoFragment;

/* loaded from: classes3.dex */
public class PagerStatusAdpter extends FragmentPagerAdapter {
    Context actContext;
    String checkId;
    int totCount;

    public PagerStatusAdpter(Context context, FragmentManager fragmentManager, int i, String str) {
        super(fragmentManager, i);
        this.actContext = context;
        this.totCount = i;
        this.checkId = str;
    }

    @Override // androidx.fragment.app.FragmentPagerAdapter
    public Fragment getItem(int i) {
        if (i == 0) {
            return new S_ImgFragment();
        }
        if (i == 1) {
            return new S_VideoFragment();
        }
        return null;
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public int getCount() {
        return this.totCount;
    }
}
