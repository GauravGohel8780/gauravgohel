package com.statussaver.wacaption.gbversion.SplashExit.Activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.statussaver.wacaption.gbversion.MainActivity;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.SplashExit.Splash_Utils.Glob;
import com.statussaver.wacaption.gbversion.SplashExit.Splash_Utils.Launches;

/* loaded from: classes3.dex */
public class EnterApp_Act extends AppCompatActivity {
    private static final int REQ_LAST = 3;
    Activity activity;
    boolean doubleBackToExitPressedOnce = false;
    private ImageView iv_enter;
    private ImageView predchamp;
    private ImageView qureka;
    private ImageView rate;
    private ImageView share;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.sp_activity_enterapp);
        this.activity = this;
//        AppManage.getInstance(this).showNativeAds(this, (ViewGroup) findViewById(R.id.native_container), (ImageView) findViewById(R.id.native_space_img), 1);
//        AppManage.show_anims_3btn(this, (RelativeLayout) findViewById(R.id.qureka), (RelativeLayout) findViewById(R.id.iv_predchamp), (RelativeLayout) findViewById(R.id.iv_mgl));
        ImageView imageView = (ImageView) findViewById(R.id.iv_share);
        this.share = imageView;
        imageView.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.EnterApp_Act.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Launches.shareApp(EnterApp_Act.this);
            }
        });
        ImageView imageView2 = (ImageView) findViewById(R.id.iv_rate);
        this.rate = imageView2;
        imageView2.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.EnterApp_Act.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                EnterApp_Act enterApp_Act = EnterApp_Act.this;
                Launches.openAppPlayStore(enterApp_Act, enterApp_Act.getPackageName());
            }
        });
        ImageView imageView3 = (ImageView) findViewById(R.id.iv_enter);
        this.iv_enter = imageView3;
        imageView3.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.EnterApp_Act.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
//                if (Glob.checkMultiplePermissions(EnterApp_Act.this.activity)) {
//                    if (AppManage.extrascreen1 == 1) {
//                        AppManage.getInstance(EnterApp_Act.this.activity).showInterstitialAd(EnterApp_Act.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.EnterApp_Act.3.1
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
                                EnterApp_Act.this.startActivity(new Intent(EnterApp_Act.this, Activity_ExtraScrren1.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    } else if (AppManage.extrascreen2 == 1) {
//                        AppManage.getInstance(EnterApp_Act.this.activity).showInterstitialAd(EnterApp_Act.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.EnterApp_Act.3.2
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
//                                EnterApp_Act.this.startActivity(new Intent(EnterApp_Act.this, Activity_ExtraScrren2.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    } else if (AppManage.extrascreen3 == 1) {
//                        AppManage.getInstance(EnterApp_Act.this.activity).showInterstitialAd(EnterApp_Act.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.EnterApp_Act.3.3
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
//                                EnterApp_Act.this.startActivity(new Intent(EnterApp_Act.this, Activity_ExtraScrren3.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    } else if (AppManage.extrascreen4 == 1) {
//                        AppManage.getInstance(EnterApp_Act.this.activity).showInterstitialAd(EnterApp_Act.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.EnterApp_Act.3.4
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
//                                EnterApp_Act.this.startActivity(new Intent(EnterApp_Act.this, Activity_ExtraScrren4.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    } else if (AppManage.extrascreen5 == 1) {
//                        AppManage.getInstance(EnterApp_Act.this.activity).showInterstitialAd(EnterApp_Act.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.EnterApp_Act.3.5
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
//                                EnterApp_Act.this.startActivity(new Intent(EnterApp_Act.this, Activity_ExtraScrren5.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    } else if (AppManage.extrascreen6 == 1) {
//                        AppManage.getInstance(EnterApp_Act.this.activity).showInterstitialAd(EnterApp_Act.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.EnterApp_Act.3.6
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
//                                EnterApp_Act.this.startActivity(new Intent(EnterApp_Act.this, Activity_ExtraScrren6.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    } else {
//                        AppManage.getInstance(EnterApp_Act.this.activity).showInterstitialAd(EnterApp_Act.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.EnterApp_Act.3.7
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
//                                EnterApp_Act.this.startActivity(new Intent(EnterApp_Act.this, MainActivity.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    }
//                }
            }
        });
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
//        if (Glob.isOnline(this.activity)) {
//            if (AppManage.exitscreen == 1) {
//                startActivity(new Intent(this, BackActivity.class));
//            } else if (AppManage.exitscreendialog == 1) {
//                final Dialog dialog = new Dialog(this, R.style.MyDialog);
//                dialog.setCanceledOnTouchOutside(true);
//                dialog.setContentView(R.layout.backdlg);
//                dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
//                AppManage.show_anims_3btn(this, (RelativeLayout) dialog.findViewById(R.id.qureka), (RelativeLayout) dialog.findViewById(R.id.iv_predchamp), (RelativeLayout) dialog.findViewById(R.id.iv_mgl));
//                ((ImageView) dialog.findViewById(R.id.exit)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.EnterApp_Act.4
//                    @Override // android.view.View.OnClickListener
//                    public void onClick(View view) {
//                        AppManage.getInstance(EnterApp_Act.this.activity).showInterstitialBackAd(EnterApp_Act.this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.EnterApp_Act.4.1
//                            @Override // com.pesonal.adsdk.MyCallback
//                            public void callbackCall() {
//                                EnterApp_Act.this.startActivity(new Intent(EnterApp_Act.this, Exit_Act.class));
//                            }
//                        }, AppManage.app_mainClickCntSwAd);
//                    }
//                });
//                ((ImageView) dialog.findViewById(R.id.cancel)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.EnterApp_Act.5
//                    @Override // android.view.View.OnClickListener
//                    public void onClick(View view) {
//                        dialog.dismiss();
//                    }
//                });
//                dialog.show();
//            } else if (this.doubleBackToExitPressedOnce) {
//                finishAffinity();
//            } else {
//                this.doubleBackToExitPressedOnce = true;
//                Toast.makeText(this, "Please click BACK again to exit", 0).show();
//                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.EnterApp_Act.6
//                    @Override // java.lang.Runnable
//                    public void run() {
//                        EnterApp_Act.this.doubleBackToExitPressedOnce = false;
//                    }
//                }, 2000L);
//            }
//        } else if (this.doubleBackToExitPressedOnce) {
            finish();
//        } else {
//            this.doubleBackToExitPressedOnce = true;
//            Toast.makeText(this, "Please click BACK again to exit", 0).show();
//            new Handler().postDelayed(new Runnable() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.EnterApp_Act.7
//                @Override // java.lang.Runnable
//                public void run() {
//                    EnterApp_Act.this.doubleBackToExitPressedOnce = false;
//                }
//            }, 2000L);
//        }
    }
}
