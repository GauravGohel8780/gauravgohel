package com.statussaver.wacaption.gbversion.WAUtil.frgmnt;

import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.exifinterface.media.ExifInterface;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.WAUtil.adpter.GbVersonAdpter;
import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;

/* loaded from: classes3.dex */
public class SentVideoFragment extends Fragment {
    GbVersonAdpter adapter;
    TextView filet;
    RecyclerView recyclerView_video;
    TextView size;
    long sizeVideo = 0;
    File videoSend;

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = LayoutInflater.from(getContext()).inflate(R.layout.fragment_sent_video, viewGroup, false);
        this.recyclerView_video = (RecyclerView) inflate.findViewById(R.id.recyclerView_Image);
        this.filet = (TextView) inflate.findViewById(R.id.file);
        this.size = (TextView) inflate.findViewById(R.id.size);
        this.recyclerView_video.setLayoutManager(new GridLayoutManager(getActivity(), 2));
        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "WhatsApp/Media/WhatsApp Video");
        if (Build.VERSION.SDK_INT >= 30) {
            this.videoSend = new File("Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Video/Sent");
        } else {
            this.videoSend = new File(file.getAbsolutePath(), "/Sent");
        }
        File[] listFiles = this.videoSend.listFiles();
        ArrayList arrayList = new ArrayList();
        if (listFiles != null) {
            for (int i = 0; i < listFiles.length; i++) {
                if (listFiles[i].getPath().endsWith(".mp4")) {
                    arrayList.add(listFiles[i].getPath());
                    this.sizeVideo += listFiles[i].length();
                }
            }
        }
        this.filet.setText(arrayList.size() + " Files");
        this.size.setText("Size: " + getReadableSize(this.sizeVideo));
        GbVersonAdpter gbVersonAdpter = new GbVersonAdpter(getActivity(), arrayList, ExifInterface.GPS_MEASUREMENT_2D, "Videos");
        this.adapter = gbVersonAdpter;
        this.recyclerView_video.setAdapter(gbVersonAdpter);
        this.adapter.notifyDataSetChanged();
        return inflate;
    }

    public static String getReadableSize(long j) {
        if (j <= 0) {
            return "0";
        }
        double d = j;
        int log10 = (int) (Math.log10(d) / Math.log10(1024.0d));
        StringBuilder sb = new StringBuilder();
        DecimalFormat decimalFormat = new DecimalFormat("#,##0.#");
        double pow = Math.pow(1024.0d, log10);
        Double.isNaN(d);
        Double.isNaN(d);
        Double.isNaN(d);
        sb.append(decimalFormat.format(d / pow));
        sb.append(" ");
        sb.append(new String[]{"B", "KB", "MB", "GB", "TB"}[log10]);
        return sb.toString();
    }
}
