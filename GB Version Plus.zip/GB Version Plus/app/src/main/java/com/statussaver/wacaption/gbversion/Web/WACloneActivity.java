package com.statussaver.wacaption.gbversion.Web;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.webkit.ConsoleMessage;
import android.webkit.DownloadListener;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.statussaver.wacaption.gbversion.R;
import java.util.Arrays;
import java.util.Locale;

/* loaded from: classes3.dex */
public class WACloneActivity extends AppCompatActivity {
    private static final String userAgent = "Mozilla/5.0 (Linux; Win64; x64; rv:46.0) Gecko/20100101 Firefox/60.0";
    public PermissionRequest permissionRequest;
    public ValueCallback<Uri[]> valueCallback;
    WebView whatsWebView;
    private static final String CAMERA_PERMISSION = "android.permission.CAMERA";
    private static final String SOUND_PERMISSION = "android.permission.RECORD_AUDIO";
    public static final String[] ALL_PERMISSION = {CAMERA_PERMISSION, SOUND_PERMISSION};
    static String WHATSZ_URL = null;

    @SuppressLint("WrongConstant")
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_waclone);
        WebView webView = (WebView) findViewById(R.id.whatsWebView);
        this.whatsWebView = webView;
        webView.getSettings().setJavaScriptEnabled(true);
        this.whatsWebView.setWebViewClient(new MyWebViewClient());
        WHATSZ_URL = "https://web.whatsapp.com/\u1f310/" + Locale.getDefault().getLanguage();
        this.whatsWebView.getSettings().setJavaScriptEnabled(true);
        this.whatsWebView.getSettings().setAllowContentAccess(true);
        this.whatsWebView.getSettings().setAllowFileAccess(true);
        this.whatsWebView.getSettings().setAllowFileAccessFromFileURLs(true);
        this.whatsWebView.getSettings().setAllowUniversalAccessFromFileURLs(true);
        this.whatsWebView.getSettings().setDomStorageEnabled(true);
        this.whatsWebView.getSettings().setAppCacheEnabled(true);
        this.whatsWebView.getSettings().setAppCachePath(getCacheDir().getAbsolutePath());
        this.whatsWebView.getSettings().setCacheMode(-1);
        this.whatsWebView.setScrollbarFadingEnabled(true);
        this.whatsWebView.setWebChromeClient(new WebChromeClient() { // from class: com.statussaver.wacaption.gbversion.Web.WACloneActivity.1
            @Override // android.webkit.WebChromeClient
            public void onPermissionRequest(PermissionRequest permissionRequest) {
                if (permissionRequest.getResources()[0].equals("android.webkit.resource.VIDEO_CAPTURE")) {
                    if (ContextCompat.checkSelfPermission(WACloneActivity.this, WACloneActivity.CAMERA_PERMISSION) == -1 && ContextCompat.checkSelfPermission(WACloneActivity.this, WACloneActivity.SOUND_PERMISSION) == -1) {
                        ActivityCompat.requestPermissions(WACloneActivity.this, WACloneActivity.ALL_PERMISSION, 203);
                    } else if (ContextCompat.checkSelfPermission(WACloneActivity.this, WACloneActivity.CAMERA_PERMISSION) == -1) {
                        ActivityCompat.requestPermissions(WACloneActivity.this, new String[]{WACloneActivity.CAMERA_PERMISSION}, 201);
                    } else if (ContextCompat.checkSelfPermission(WACloneActivity.this, WACloneActivity.SOUND_PERMISSION) == -1) {
                        ActivityCompat.requestPermissions(WACloneActivity.this, new String[]{WACloneActivity.SOUND_PERMISSION}, 202);
                    } else {
                        permissionRequest.grant(permissionRequest.getResources());
                    }
                } else if (!permissionRequest.getResources()[0].equals("android.webkit.resource.AUDIO_CAPTURE")) {
                    try {
                        permissionRequest.grant(permissionRequest.getResources());
                    } catch (RuntimeException e) {
                        Log.d("Whats Web", "Granting permissions failed", e);
                    }
                } else if (ContextCompat.checkSelfPermission(WACloneActivity.this, WACloneActivity.SOUND_PERMISSION) == 0) {
                    permissionRequest.grant(permissionRequest.getResources());
                } else {
                    ActivityCompat.requestPermissions(WACloneActivity.this, new String[]{WACloneActivity.SOUND_PERMISSION}, 202);
                }
            }

            @Override // android.webkit.WebChromeClient
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Log.d("Web whats", "WebView console message: " + consoleMessage.message());
                return super.onConsoleMessage(consoleMessage);
            }

            @Override // android.webkit.WebChromeClient
            public boolean onShowFileChooser(WebView webView2, ValueCallback<Uri[]> valueCallback, WebChromeClient.FileChooserParams fileChooserParams) {
                WACloneActivity.this.startActivityForResult(fileChooserParams.createIntent(), 200);
                Toast.makeText(WACloneActivity.this, "show", 1).show();
                return true;
            }
        });
        this.whatsWebView.setDownloadListener(new DownloadListener() { // from class: com.statussaver.wacaption.gbversion.Web.WACloneActivity.2
            @Override // android.webkit.DownloadListener
            public final void onDownloadStart(String str, String str2, String str3, String str4, long j) {
                Toast.makeText(WACloneActivity.this, "Downloading is not supported yet.", 0).show();
            }
        });
        this.whatsWebView.getSettings().setUserAgentString(userAgent);
        if (bundle == null) {
            loadWhatsz();
        } else {
            Log.d("Web whats", "savedInstanceState is present");
        }
    }

    private void loadWhatsz() {
        this.whatsWebView.loadUrl(WHATSZ_URL);
    }

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        this.whatsWebView.saveState(bundle);
    }

    @Override // android.app.Activity
    public void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        this.whatsWebView.restoreState(bundle);
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (this.valueCallback != null) {
            if (i != 200) {
                Log.d("DEBUG_TAG", "Got activity result with unknown request code " + i + " - " + intent.toString());
            } else if (i2 == 0 || intent.getData() == null) {
                this.valueCallback.onReceiveValue(null);
            } else {
                this.valueCallback.onReceiveValue(new Uri[]{intent.getData()});
            }
        }
    }

    @Override // androidx.appcompat.app.AppCompatActivity, android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4 || !this.whatsWebView.canGoBack()) {
            return super.onKeyDown(i, keyEvent);
        }
        this.whatsWebView.goBack();
        return true;
    }

    /* loaded from: classes3.dex */
    private class MyWebViewClient extends WebViewClient {
        private MyWebViewClient() {

        }

        @Override // android.webkit.WebViewClient
        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            webView.loadUrl(str);
            return true;
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        switch (i) {
            case 201:
            case 202:
                if (iArr.length > 0 && iArr[0] == 0) {
                    try {
                        PermissionRequest permissionRequest = this.permissionRequest;
                        permissionRequest.grant(permissionRequest.getResources());
                        break;
                    } catch (RuntimeException e) {
                        Log.e("DEBUG_TAG", "Granting permissions failed", e);
                        break;
                    }
                } else {
                    Toast.makeText(this, "sb.toString()", 0).show();
                    this.permissionRequest.deny();
                    break;
                }
            case 203:
                if (strArr.length != 2 || iArr[0] != 0 || iArr[1] != 0) {
                    Toast.makeText(this, "Permission not granted, can't use video.", 0).show();
                    this.permissionRequest.deny();
                    break;
                } else {
                    try {
                        PermissionRequest permissionRequest2 = this.permissionRequest;
                        permissionRequest2.grant(permissionRequest2.getResources());
                        break;
                    } catch (RuntimeException e2) {
                        Log.e("DEBUG_TAG", "Granting permissions failed", e2);
                        break;
                    }
                }
            case 204:
                if (iArr.length <= 0 || iArr[0] != 0) {
                    Toast.makeText(this, "Permission not granted, can't download to storage", 0).show();
                    break;
                }
                break;
            default:
                Log.d("DEBUG_TAG", "Got permission result with unknown request code " + i + " - " + Arrays.asList(strArr).toString());
                break;
        }
        this.permissionRequest = null;
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
//        AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.Web.WACloneActivity.3
//            @Override // com.pesonal.adsdk.MyCallback
//            public void callbackCall() {
                WACloneActivity.this.finish();
//            }
//        }, AppManage.app_mainClickCntSwAd);
    }
}
