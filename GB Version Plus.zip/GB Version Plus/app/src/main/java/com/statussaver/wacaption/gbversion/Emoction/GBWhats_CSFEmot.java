package com.statussaver.wacaption.gbversion.Emoction;

public class GBWhats_CSFEmot {

    private int f146id;
    private String name;

    public GBWhats_CSFEmot() {
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return obj != null && getClass() == obj.getClass() && this.f146id == ((GBWhats_CSFEmot) obj).f146id;
    }

    public int getId() {
        return this.f146id;
    }

    public String getName() {
        return this.name;
    }

    public int hashCode() {
        return this.f146id + 31;
    }

    public void setId(int i) {
        this.f146id = i;
    }

    public void setName(String str) {
        this.name = str;
    }

    public String toString() {
        return this.f146id + "Product [id=" + this.f146id + ", name=" + this.name + "]";
    }

    public GBWhats_CSFEmot(int i, String str) {
        this.f146id = i;
        this.name = str;
    }
}
