package com.statussaver.wacaption.gbversion.StatusSaver.activity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.google.android.material.tabs.TabLayout;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.StatusSaver.fragment.fragment_SavedImages;
import com.statussaver.wacaption.gbversion.StatusSaver.fragment.fragment_SavedVideo;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes3.dex */
public class activity_SavedStatus extends AppCompatActivity {
    activity_SavedStatus context;
    ImageView rel_back;
    private int[] tabIconsselect = {R.drawable.photo_select, R.drawable.video_select};
    private int[] tabIconsunselect = {R.drawable.photo, R.drawable.video};
    TabLayout tab_main;
    ViewPager viewPager;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_saved_status);
        this.context = this;
        this.viewPager = (ViewPager) findViewById(R.id.viewpager);
        this.tab_main = (TabLayout) findViewById(R.id.tab_main);
        ImageView imageView = (ImageView) findViewById(R.id.rel_back);
        this.rel_back = imageView;
        imageView.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.activity_SavedStatus.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                activity_SavedStatus.this.onBackPressed();
            }
        });
        setupViewPager(this.viewPager);
        this.tab_main.setupWithViewPager(this.viewPager);
        setupTabIcons();
        for (int i = 0; i < this.tab_main.getTabCount(); i++) {
            this.tab_main.getTabAt(i).setCustomView((ImageView) LayoutInflater.from(getApplicationContext()).inflate(R.layout.custom_tab, (ViewGroup) null));
        }
        this.tab_main.setOnTabSelectedListener((TabLayout.OnTabSelectedListener) new TabLayout.ViewPagerOnTabSelectedListener(this.viewPager) { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.activity_SavedStatus.2
            @Override // com.google.android.material.tabs.TabLayout.ViewPagerOnTabSelectedListener, com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            public void onTabSelected(TabLayout.Tab tab) {
                super.onTabSelected(tab);
                if (tab.getPosition() == 0) {
                    activity_SavedStatus.this.tab_main.getTabAt(0).setIcon(activity_SavedStatus.this.tabIconsselect[0]);
                }
                if (tab.getPosition() == 1) {
                    activity_SavedStatus.this.tab_main.getTabAt(1).setIcon(activity_SavedStatus.this.tabIconsselect[1]);
                }
            }

            @Override // com.google.android.material.tabs.TabLayout.ViewPagerOnTabSelectedListener, com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            public void onTabUnselected(TabLayout.Tab tab) {
                super.onTabUnselected(tab);
                activity_SavedStatus.this.tab_main.getTabAt(0).setIcon(activity_SavedStatus.this.tabIconsunselect[0]);
                activity_SavedStatus.this.tab_main.getTabAt(1).setIcon(activity_SavedStatus.this.tabIconsunselect[1]);
            }

            @Override // com.google.android.material.tabs.TabLayout.ViewPagerOnTabSelectedListener, com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            public void onTabReselected(TabLayout.Tab tab) {
                super.onTabReselected(tab);
            }
        });
    }

    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        viewPagerAdapter.addFragment(new fragment_SavedImages(this), "Images");
        viewPagerAdapter.addFragment(new fragment_SavedVideo(this), "Videos");
        viewPager.setAdapter(viewPagerAdapter);
    }

    private void setupTabIcons() {
        this.tab_main.getTabAt(0).setIcon(this.tabIconsselect[0]);
        this.tab_main.getTabAt(1).setIcon(this.tabIconsunselect[1]);
    }

    /* loaded from: classes3.dex */
    public class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList();
        private final List<String> mFragmentTitleList = new ArrayList();

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public ViewPagerAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        @Override // androidx.fragment.app.FragmentPagerAdapter
        public Fragment getItem(int i) {
            return this.mFragmentList.get(i);
        }

        @Override // androidx.viewpager.widget.PagerAdapter
        public int getCount() {
            return this.mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String str) {
            this.mFragmentList.add(fragment);
            this.mFragmentTitleList.add(str);
        }

        @Override // androidx.viewpager.widget.PagerAdapter
        public CharSequence getPageTitle(int i) {
            return this.mFragmentTitleList.get(i);
        }
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        finish();
        return true;
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
//        AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.activity_SavedStatus.3
//            @Override // com.pesonal.adsdk.MyCallback
//            public void callbackCall() {
                activity_SavedStatus.this.finish();
//            }
//        }, AppManage.app_mainClickCntSwAd);
    }
}
