package com.statussaver.wacaption.gbversion.StatusSaver.adpter;

import android.content.Context;
import android.graphics.Bitmap;
import android.hardware.SensorManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.viewpager.widget.PagerAdapter;
import cn.jzvd.JZVideoPlayer;
import cn.jzvd.JZVideoPlayerStandard;
import com.bumptech.glide.Glide;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.StatusSaver.model.VideosModel;
import java.io.ByteArrayOutputStream;
import java.util.List;

/* loaded from: classes3.dex */
public class CustomPager_10_VideoAdapter extends PagerAdapter {
    List<VideosModel> arrayList;
    JZVideoPlayerStandard jzVideoPlayerStandard;
    Context mContext;
    LayoutInflater mLayoutInflater;
    JZVideoPlayer.JZAutoFullscreenListener sensorEventListener;
    SensorManager sensorManager;
    String str;

    public CustomPager_10_VideoAdapter(Context context, List<VideosModel> list) {
        this.arrayList = list;
        this.mContext = context;
        this.mLayoutInflater = (LayoutInflater) context.getSystemService("layout_inflater");
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public int getCount() {
        return this.arrayList.size();
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public boolean isViewFromObject(View view, Object obj) {
        return view == ((LinearLayout) obj);
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public Object instantiateItem(ViewGroup viewGroup, int i) {
        View inflate = this.mLayoutInflater.inflate(R.layout.pager_video_item, viewGroup, false);
        this.jzVideoPlayerStandard = (JZVideoPlayerStandard) inflate.findViewById(R.id.videoplayer);
        this.sensorManager = (SensorManager) this.mContext.getSystemService("sensor");
        this.sensorEventListener = new JZVideoPlayer.JZAutoFullscreenListener();
        try {
            this.jzVideoPlayerStandard.setUp(this.arrayList.get(i).getVideoPath(), 0, "");
            Bitmap bitmap = this.arrayList.get(i).getBitmap();
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
            Glide.with(this.mContext).asBitmap().load(byteArrayOutputStream.toByteArray()).into(this.jzVideoPlayerStandard.thumbImageView);
        } catch (Exception e) {
            e.printStackTrace();
        }
        viewGroup.addView(inflate);
        return inflate;
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
        viewGroup.removeView((LinearLayout) obj);
    }
}
