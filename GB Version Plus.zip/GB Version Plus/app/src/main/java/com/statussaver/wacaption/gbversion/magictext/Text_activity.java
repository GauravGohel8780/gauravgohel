package com.statussaver.wacaption.gbversion.magictext;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.statussaver.wacaption.gbversion.R;

import java.util.ArrayList;

public class Text_activity extends AppCompatActivity {

    public ArrayList<DataStyle> NumberStyles = new ArrayList<>();
    ImageView back;
    Context context;
    EditText edtText;
    RelativeLayout linerEdit;
    public String numberOutput;
    RecyclerView recyclerView;
    public StyleAdapter styleAdapter;

    @SuppressLint("WrongConstant")
    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_text);
        findView();
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this.context, 1, false));
        initDataStyles();
        StyleAdapter styleAdapter = new StyleAdapter(this.NumberStyles, this);
        this.styleAdapter = styleAdapter;
        this.recyclerView.setAdapter(styleAdapter);
        this.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Text_activity.super.onBackPressed();
            }
        });
    }

    private void findView() {
        this.linerEdit = (RelativeLayout) findViewById(R.id.linerEdit);
        EditText editText = (EditText) findViewById(R.id.edtText);
        this.back = (ImageView) findViewById(R.id.back);
        this.edtText = editText;
        editText.addTextChangedListener(new TextDecoratorWatcher());
        this.recyclerView = (RecyclerView) findViewById(R.id.recycler_view_fancytextgenerator);
    }

    private void initDataStyles() {
        this.NumberStyles.add(new DataStyle("Bubble", "\u24c5\u24e1\u24d4\u24e5\u24d8\u24d4\u24e6 \u24c9\u24d4\u24e7\u24e3"));
        this.NumberStyles.add(new DataStyle("Small caps", "\u1d18\u0280\u1d07\u1d20\u026a\u1d07\u1d21 \u1d1b\u1d07x\u1d1b"));
        this.NumberStyles.add(new DataStyle("Antrophobia", "\u03c1\u044f\u0454\u03bd\u03b9\u0454\u03c9 \u0442\u0454\u03c7\u0442"));
        this.NumberStyles.add(new DataStyle("Currency", "\u20b1\u2c64\u0246V\u0142\u0246\u20a9 \u20ae\u0246\u04fe\u20ae"));
        this.NumberStyles.add(new DataStyle("Paranormal", "pr\u0454v\u00ed\u0454w t\u0454\u0445t"));
        this.NumberStyles.add(new DataStyle("Magic", "\u13e2\u13d2\u13ac\u13c9\u13a5\u13ac\u13b3 \u13c6\u13acx\u13c6"));
        this.NumberStyles.add(new DataStyle("Special", "\u146d\u1587E\u142fIE\u15ef TE\u166dT"));
        this.NumberStyles.add(new DataStyle("Sorcerer", "\u0584\u0280\u025b\u028b\u0268\u025b\u0561 \u0236\u025b\u04fc\u0236"));
        this.NumberStyles.add(new DataStyle("Knight", "\u1e56\u1e59\u1e15\u1e7c\u1e2d\u1e15\u1e87 \u1e6e\u1e15\u1e8c\u1e6e"));
        this.NumberStyles.add(new DataStyle("Thin", "\uff30\uff52\uff45\uff56\uff49\uff45\uff57 \uff34\uff45\uff58\uff54"));
        this.NumberStyles.add(new DataStyle("Tiny", "P\u0280\u1d07\u1d20\u026a\u1d07\u1d21 T\u1d07x\u1d1b"));
        this.NumberStyles.add(new DataStyle("Upside down", "d\u0279\u01dd\u028c\u0131\u01dd\u028d \u0287\u01ddx\u0287"));
        this.NumberStyles.add(new DataStyle("Dirty", "\u1e56\u0155\u1ec7\u1e7f\u00ef\u1ec7\u1e85 T\u1ec7\u1e8d\u1e97"));
        this.NumberStyles.add(new DataStyle("Strikethrough", "P\u0336r\u0336e\u0336v\u0336i\u0336e\u0336w\u0336 \u0336T\u0336e\u0336x\u0336t\u0336"));
        this.NumberStyles.add(new DataStyle("Tilde strikethrough", "P\u0334r\u0334e\u0334v\u0334i\u0334e\u0334w\u0334 \u0334T\u0334e\u0334x\u0334t\u0334"));
        this.NumberStyles.add(new DataStyle("Slash", "P\u0337r\u0337e\u0337v\u0337i\u0337e\u0337w\u0337 \u0337T\u0337e\u0337x\u0337t\u0337"));
        this.NumberStyles.add(new DataStyle("Underline", "P\u0332r\u0332e\u0332v\u0332i\u0332e\u0332w\u0332 \u0332T\u0332e\u0332x\u0332t\u0332"));
        this.NumberStyles.add(new DataStyle("Double underline", "P\u0333r\u0333e\u0333v\u0333i\u0333e\u0333w\u0333 \u0333T\u0333e\u0333x\u0333t\u0333"));
        this.NumberStyles.add(new DataStyle("Boxed", "[\u0332\u0305P\u0332\u0305][\u0332\u0305r\u0332\u0305][\u0332\u0305e\u0332\u0305][\u0332\u0305v\u0332\u0305][\u0332\u0305i\u0332\u0305][\u0332\u0305e\u0332\u0305][\u0332\u0305w\u0332\u0305] [\u0332\u0305T\u0332\u0305][\u0332\u0305e\u0332\u0305][\u0332\u0305x\u0332\u0305][\u0332\u0305t\u0332\u0305]"));
        this.NumberStyles.add(new DataStyle("Stinky", "P\u033er\u033ee\u033ev\u033ei\u033ee\u033ew\u033e T\u033ee\u033ex\u033et\u033e"));
        this.NumberStyles.add(new DataStyle("Bridge above", "P\u0346r\u0346e\u0346v\u0346i\u0346e\u0346w\u0346 T\u0346e\u0346x\u0346t\u0346"));
        this.NumberStyles.add(new DataStyle("Bridge bellow", "P\u033ar\u033ae\u033av\u033ai\u033ae\u033aw\u033a T\u033ae\u033ax\u033at\u033a"));
        this.NumberStyles.add(new DataStyle("Asterisk bellow", "P\u0359r\u0359e\u0359v\u0359i\u0359e\u0359w\u0359 T\u0359e\u0359x\u0359t\u0359"));
        this.NumberStyles.add(new DataStyle("Plus sign bellow", "P\u031fr\u031fe\u031fv\u031fi\u031fe\u031fw\u031f T\u031fe\u031fx\u031ft\u031f"));
        this.NumberStyles.add(new DataStyle("x above bellow", "P\u0353\u033dr\u0353\u033de\u0353\u033dv\u0353\u033di\u0353\u033de\u0353\u033dw\u0353\u033d T\u0353\u033de\u0353\u033dx\u0353\u033dt\u0353\u033d"));
        this.NumberStyles.add(new DataStyle("Arrow bellow", "P\u0353\u033dr\u0353\u033de\u0353\u033dv\u0353\u033di\u0353\u033de\u0353\u033dw\u0353\u033d T\u0353\u033de\u0353\u033dx\u0353\u033dt\u0353\u033d"));
        this.NumberStyles.add(new DataStyle("Love", "P\u2665r\u2665e\u2665v\u2665i\u2665e\u2665w\u2665 T\u2665e\u2665x\u2665t\u2665"));
        this.NumberStyles.add(new DataStyle("Black bracket", "\u3010P\u3011\u3010r\u3011\u3010e\u3011\u3010v\u3011\u3010i\u3011\u3010e\u3011\u3010w\u3011 \u3010T\u3011\u3010e\u3011\u3010x\u3011\u3010t\u3011"));
        this.NumberStyles.add(new DataStyle("White bracket", "\u300eP\u300f\u300er\u300f\u300ee\u300f\u300ev\u300f\u300ei\u300f\u300ee\u300f\u300ew\u300f \u300eT\u300f\u300ee\u300f\u300ex\u300f\u300et\u300f"));
        this.NumberStyles.add(new DataStyle("Fancy style 1", "\u03c1\u044f\u03b5v\u03b9\u03b5\u03c9 \u0442\u03b5x\u0442"));
        this.NumberStyles.add(new DataStyle("Fancy style 2", "\u5369\u5c3a\u4e47\u142f\u4e28\u4e47\u5c71 \u3112\u4e47\u4e42\u3112"));
        this.NumberStyles.add(new DataStyle("Fancy style 3", "\u0420\u0154\u0114V\u0128\u0114\u0174 \u0164\u0114\u0416\u0164"));
        this.NumberStyles.add(new DataStyle("Fancy style 4", "d\u0279\u01dd\u028c!\u01dd\u028d \u0287\u01ddx\u0287"));
        this.NumberStyles.add(new DataStyle("Fancy style 5", "\u01a4\u0158\u20acV\u0197\u20ac\u0174 \u0166\u20ac\u0416\u0166"));
        this.NumberStyles.add(new DataStyle("Fancy style 6", "\u03c1\u0ae8\u03b5\u0475\u0e40\u03b5\u03c9 \u01ad\u03b5\u05d0\u01ad"));
        this.NumberStyles.add(new DataStyle("Fancy style 7", "prev\u03b9ew \u0442e\u0445\u0442"));
        this.NumberStyles.add(new DataStyle("Fancy style 8", "\u24c5\u24c7\u24ba\u24cb\u24be\u24ba\u24cc \u24c9\u24ba\u24cd\u24c9"));
        this.NumberStyles.add(new DataStyle("Fancy style 9", "\u2118\u0f5e\u025b\u06f7\u0131\u025b\u1ff3 \u026c\u025b\u04b3\u026c"));
        this.NumberStyles.add(new DataStyle("Fancy style 10", "\u1598\ua2ea\ua35f\u142f\ua024\ua35f\ua14f \ua4c4\ua35f\ua2bc\ua4c4"));
        this.NumberStyles.add(new DataStyle("Fancy style 11", "pr\u0454v\u00ed\u0454w t\u0454\u0445t"));
        this.NumberStyles.add(new DataStyle("Fancy style 12", "\u03c1\u042f\u018e\u03d1\u00ee\u018e\u13d4 \u271e\u018e\u2718\u271e"));
        this.NumberStyles.add(new DataStyle("Fancy style 13", "P\u042f\u039eVI\u039e\u0429 \u0393\u039e\u0416\u0393"));
        this.NumberStyles.add(new DataStyle("Fancy style 14", "\u0584\u0280\u025b\u028b\u0268\u025b\u0561 \u13c6\u025bx\u13c6"));
        this.NumberStyles.add(new DataStyle("Fancy style 15", "\u0539\u027e\u04bd\u0475\u00ed\u04bd\u0561 \u0535\u04bd\u00d7\u0535"));
        this.NumberStyles.add(new DataStyle("Fancy style 16", "\u1d3e\u1d3f\u1d31\u1d5b\u1d35\u1d31\u1d42 \u1d40\u1d31\u02e3\u1d40"));
        this.NumberStyles.add(new DataStyle("Fancy style 17", "\u13b5\u13d2\ua085\u13c9\u13a5\ua085\u13b3 \u03ee\ua085\ua2bc\u03ee"));
        this.NumberStyles.add(new DataStyle("Fancy style 18", "\u157f\u1587\u164d\u143b\u14ff\u164d\u164e \u15b6\u164d\u166d\u15b6"));
        this.NumberStyles.add(new DataStyle("Fancy style 19", "\u00fe\u5c3a\u0190\u0194\u026a\u0190\u019c \u0164\u0190\u03c7\u0164"));
        this.NumberStyles.add(new DataStyle("Fancy style 20", "\u01a4\u01a6\u0404\u0194\u0196\u0404\u019c \u01ac\u0404\u04b2\u01ac"));
        this.NumberStyles.add(new DataStyle("Fancy style 21", "\u01bf\u0550\u0aef\u0c6e\u027f\u0aef\u03c9 \u0a6e\u0aef\u0aea\u0a6e"));
        this.NumberStyles.add(new DataStyle("Fancy style 22", "\u03c1\u0550\u021d\u05e2\u027f\u021d\u0561 \u0535\u021d\u0543\u0535"));
        this.NumberStyles.add(new DataStyle("Fancy style 23", "\uff71\u5c3a\u4e47\u221a\uff89\u4e47W \uff72\u4e47\uff92\uff72"));
        this.NumberStyles.add(new DataStyle("Fancy style 24", "pr\u03b5\u2200\u00ef\u03b5\u03c9 \u2020\u03b5x\u2020"));
        this.NumberStyles.add(new DataStyle("Fancy style 25", "\u13ae\u13d2\u13cb\u13c9\u13a5\u13cb\u13c7 \u13d6\u13cb\u1300\u13d6"));
        this.NumberStyles.add(new DataStyle("Fancy style 26", "\u05e7\u0211\u00a3\u221a\u020b\u00a3\u03a8 \u021b\u00a3\u00d7\u021b"));
        this.NumberStyles.add(new DataStyle("Fancy style 27", "\u03c1\u044f\u20ac\u02c5\u0268\u20ac\u03ce \u0163\u20ac\u0436\u0163"));
        this.NumberStyles.add(new DataStyle("Fancy style 28", "\u03c1\u0393\u10de\u1f57\u1f36\u10dew \u0f53\u10de\u10ef\u0f53"));
        this.NumberStyles.add(new DataStyle("Fancy style 29", "\u01a4\u0158\u1eb8\u03cb\u012e\u1eb8\u0174 \u0164\u1eb8\u0416\u0164"));
        this.NumberStyles.add(new DataStyle("Fancy style 30", "pr\u0113\u0e07i\u0113\u0e9f t\u0113xt"));
        this.NumberStyles.add(new DataStyle("Fancy style 31", "\u146d\u1587\u15f4\u142f\u13a5\u15f4\u15ef \u4e05\u15f4\u166d\u4e05"));
        this.NumberStyles.add(new DataStyle("Fancy style 32", "\u1575\u1587\u163f\u143a\u14f0\u163f\u163a \u15b6\u163f\u166d\u15b6"));
    }

    public class TextDecoratorWatcher implements TextWatcher {
        @Override
        public void afterTextChanged(Editable editable) {
        }

        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        private TextDecoratorWatcher() {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            String charSequence2 = charSequence.toString();
            if (charSequence2.trim().length() == 0) {
                charSequence2 = "Preview Text";
            }
            createFancyStyleText(charSequence2);
            Text_activity.this.styleAdapter.notifyDataSetChanged();
        }

        public void createFancyStyleText(String str) {
            String str2;
            String[] strArr = {"\u24d0\u24d1\u24d2\u24d3\u24d4\u24d5\u24d6\u24d7\u24d8\u24d9\u24da\u24db\u24dc\u24dd\u24de\u24df\u24e0\u24e1\u24e2\u24e3\u24e4\u24e5\u24e6\u24e7\u24e8\u24e9\u24b6\u24b7\u24b8\u24b9\u24ba\u24bb\u24bc\u24bd\u24be\u24bf\u24c0\u24c1\u24c2\u24c3\u24c4\u24c5\u24c6\u24c7\u24c8\u24c9\u24ca\u24cb\u24cc\u24cd\u24ce\u24cf\u24ea\u2460\u2461\u2462\u2463\u2464\u2465\u2466\u2467\u2468", "\u1d00\u0299\u1d04\u1d05\u1d07\u0493\u0262\u029c\u026a\u1d0a\u1d0b\u029f\u1d0d\u0274\u1d0f\u1d18\u01eb\u0280s\u1d1b\u1d1c\u1d20\u1d21x\u028f\u1d22\u1d00\u0299\u1d04\u1d05\u1d07\u0493\u0262\u029c\u026a\u1d0a\u1d0b\u029f\u1d0d\u0274\u1d0f\u1d18\u01eb\u0280s\u1d1b\u1d1c\u1d20\u1d21x\u028f\u1d220123456789", "\u03b1\u0432\u00a2\u2202\u0454fg\u043d\u03b9\u05e0\u043a\u2113\u043c\u0438\u03c3\u03c1q\u044f\u0455\u0442\u03c5\u03bd\u03c9\u03c7\u0443z\u03b1\u0432\u00a2\u2202\u0454fg\u043d\u03b9\u05e0\u043a\u2113\u043c\u0438\u03c3\u03c1q\u044f\u0455\u0442\u03c5\u03bd\u03c9\u03c7\u0443z0123456789", "\u20b3\u0e3f\u20b5\u0110\u0246\u20a3\u20b2\u2c67\u0142J\u20ad\u2c60\u20a5\u20a6\u00d8\u20b1Q\u2c64\u20b4\u20ae\u0244V\u20a9\u04fe\u024e\u2c6b\u20b3\u0e3f\u20b5\u0110\u0246\u20a3\u20b2\u2c67\u0142J\u20ad\u2c60\u20a5\u20a6\u00d8\u20b1Q\u2c64\u20b4\u20ae\u0244V\u20a9\u04fe\u024e\u2c6b0123456789", "\u03b1\u0432cd\u0454fgh\u00edjklmn\u03c3pqrstuvw\u0445\u0447z\u03b1\u0432cd\u0454fgh\u00edjklmn\u03c3pqrstuvw\u0445\u0447z0123456789", "\u13aab\u13df\u13a0\u13acf\u13b6h\u13a5j\u13e6\u13dem\u13c1\u13be\u13e2q\u13d2s\u13c6u\u13c9\u13b3x\u13bd\u13c3\u13aab\u13df\u13a0\u13acf\u13b6h\u13a5j\u13e6\u13dem\u13c1\u13be\u13e2q\u13d2s\u13c6u\u13c9\u13b3x\u13bd\u13c30123456789", "\u15e9\u15f7\u1455\u15eaE\u15b4G\u157cI\u148dK\u14aa\u15f0\u144eO\u146d\u146b\u1587\u1515T\u144c\u142f\u15ef\u166dY\u1614\u15e9\u15f7\u1455\u15eaE\u15b4G\u157cI\u148dK\u14aa\u15f0\u144eO\u146d\u146b\u1587\u1515T\u144c\u142f\u15ef\u166dY\u16140123456789", "\u01df\u026e\u0188\u0256\u025b\u0284\u0262\u0266\u0268\u029d\u04c4\u029f\u028d\u057c\u0585\u0584\u0566\u0280\u0586\u0236\u028a\u028b\u0561\u04fc\u028f\u0290\u01df\u026e\u0188\u0256\u025b\u0284\u0262\u0266\u0268\u029d\u04c4\u029f\u028d\u057c\u0585\u0584\u0566\u0280\u0586\u0236\u028a\u028b\u0561\u04fc\u028f\u02900123456789", "\u1e00\u1e03\u1e09\u1e0a\u1e15\u1e1f\u1e20\u1e27\u1e2dj\u1e32\u1e36\u1e41\u1e46\u1e4f\u1e56q\u1e59\u1e60\u1e6e\u1e73\u1e7c\u1e87\u1e8c\u1e8f\u1e92\u1e00\u1e02\u1e08\u1e0a\u1e14\u1e1e\u1e20\u1e26\u1e2cJ\u1e32\u1e36\u1e40\u1e46\u1e4e\u1e56Q\u1e58\u1e60\u1e6e\u1e72\u1e7c\u1e86\u1e8c\u1e8e\u1e920123456789", "\uff41\uff42\uff43\uff44\uff45\uff46\uff47\uff48\uff49\uff4a\uff4b\uff4c\uff4d\uff4e\uff4f\uff50\uff51\uff52\uff53\uff54\uff55\uff56\uff57\uff58\uff59\uff5a\uff21\uff22\uff23\uff24\uff25\uff26\uff27\uff28\uff29\uff2a\uff2b\uff2c\uff2d\uff2e\uff2f\uff30\uff31\uff32\uff33\uff34\uff35\uff36\uff37\uff38\uff39\uff3a\uff10\uff11\uff12\uff13\uff14\uff15\uff16\uff17\uff18\uff19", "\u1d00\u0299\u1d04\u1d05\u1d07\u0493\u0262\u029c\u026a\u1d0a\u1d0b\u029f\u1d0d\u0274\u1d0f\u1d18\u03d9\u0280\ua731\u1d1b\u1d1c\u1d20\u1d21x\u028f\u1d22ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", "\u0250q\u0254p\u01dd\u025f\u0183\u0265\u0131\u027e\u029el\u026fuodb\u0279s\u0287n\u028c\u028dx\u028ez\u0250q\u0254p\u01dd\u025f\u0183\u0265\u0131\u027e\u029el\u026fuodb\u0279s\u0287n\u028c\u028dx\u028ez0123456789", "\u00e4\u1e05\u010b\u010f\u1ec7\u1e1f\u0121\u1e27\u00efj\u1e33\u0140\u1e43\u0144\u00f6\u1e57q\u0155\u1e69\u1e97\u00fc\u1e7f\u1e85\u1e8d\u00ff\u1e93\u00c4\u1e04\u010a\u010e\u1ec6\u1e1e\u0120\u1e26\u00cfJ\u1e32\u013f\u1e42\u0143\u00d6\u1e56Q\u0154\u1e68\u1e6e\u00dc\u1e7e\u1e84\u1e8c\u0178\u1e920123456789"};
            for (int i = 0; i < 13; i++) {
                Text_activity.this.numberOutput = str;
                for (int i2 = 0; i2 < 62; i2++) {
                    Text_activity text_activity = Text_activity.this;
                    text_activity.numberOutput = text_activity.numberOutput.replaceAll(String.valueOf("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i2)), String.valueOf(strArr[i].charAt(i2)));
                }
                Text_activity.this.NumberStyles.get(i).setStyleValue(Text_activity.this.numberOutput);
            }
            for (int i3 = 13; i3 <= 28; i3++) {
                Text_activity.this.NumberStyles.get(i3).setStyleValue(str);
            }
            for (int i4 = 0; i4 < 62; i4++) {
                Text_activity.this.NumberStyles.get(13).setStyleValue(Text_activity.this.NumberStyles.get(13).getStyleValue().replaceAll(String.valueOf("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4)), "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4) + "\u0336"));
                Text_activity.this.NumberStyles.get(14).setStyleValue(Text_activity.this.NumberStyles.get(14).getStyleValue().replaceAll(String.valueOf("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4)), "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4) + "\u0334"));
                Text_activity.this.NumberStyles.get(15).setStyleValue(Text_activity.this.NumberStyles.get(15).getStyleValue().replaceAll(String.valueOf("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4)), "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4) + "\u0337"));
                Text_activity.this.NumberStyles.get(16).setStyleValue(Text_activity.this.NumberStyles.get(16).getStyleValue().replaceAll(String.valueOf("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4)), "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4) + "\u0332"));
                Text_activity.this.NumberStyles.get(17).setStyleValue(Text_activity.this.NumberStyles.get(17).getStyleValue().replaceAll(String.valueOf("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4)), "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4) + "\u0333"));
                Text_activity.this.NumberStyles.get(18).setStyleValue(Text_activity.this.NumberStyles.get(18).getStyleValue().replaceAll(String.valueOf("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4)), "[\u0332\u0305" + "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4) + "\u0332\u0305]"));
                Text_activity.this.NumberStyles.get(19).setStyleValue(Text_activity.this.NumberStyles.get(19).getStyleValue().replaceAll(String.valueOf("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4)), "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4) + "\u033e"));
                Text_activity.this.NumberStyles.get(20).setStyleValue(Text_activity.this.NumberStyles.get(20).getStyleValue().replaceAll(String.valueOf("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4)), "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4) + "\u0346"));
                Text_activity.this.NumberStyles.get(21).setStyleValue(Text_activity.this.NumberStyles.get(21).getStyleValue().replaceAll(String.valueOf("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4)), "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4) + "\u033a"));
                Text_activity.this.NumberStyles.get(22).setStyleValue(Text_activity.this.NumberStyles.get(22).getStyleValue().replaceAll(String.valueOf("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4)), "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4) + "\u0359"));
                Text_activity.this.NumberStyles.get(23).setStyleValue(Text_activity.this.NumberStyles.get(23).getStyleValue().replaceAll(String.valueOf("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4)), "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4) + "\u031f"));
                Text_activity.this.NumberStyles.get(24).setStyleValue(Text_activity.this.NumberStyles.get(24).getStyleValue().replaceAll(String.valueOf("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4)), "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4) + "\u033d\u0353"));
                Text_activity.this.NumberStyles.get(25).setStyleValue(Text_activity.this.NumberStyles.get(25).getStyleValue().replaceAll(String.valueOf("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4)), "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4) + "\u034e"));
                Text_activity.this.NumberStyles.get(26).setStyleValue(Text_activity.this.NumberStyles.get(26).getStyleValue().replaceAll(String.valueOf("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4)), "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4) + "\u2665"));
                Text_activity.this.NumberStyles.get(27).setStyleValue(Text_activity.this.NumberStyles.get(27).getStyleValue().replaceAll(String.valueOf("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4)), "\u3010" + "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4) + "\u3011"));
                Text_activity.this.NumberStyles.get(28).setStyleValue(Text_activity.this.NumberStyles.get(28).getStyleValue().replaceAll(String.valueOf("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4)), "\u300e" + "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(i4) + "\u300f"));
            }
            String[] strArr2 = {"\u03b1\u0432c\u2202\u03b5\u0493g\u043d\u03b9\u05e0\u043a\u2113\u043c\u03b7\u03c3\u03c1q\u044fs\u0442\u03c5v\u03c9x\u04afz", "\u5342\u4e43\u531a\u15ea\u4e47\u5343\u13b6\u5344\u4e28\uff8c\u049c\u3125\u722a\u51e0\u3116\u5369\u024a\u5c3a\u4e02\u3112\u3129\u142f\u5c71\u4e42\u311a\u4e59", "\u0102\u03b2\u010c\u010e\u0114\u0166\u011e\u0124\u0128\u0134\u0136\u0139\u041c\u0143\u0150\u0420Q\u0154\u015a\u0164\u00daV\u0174\u0416\u0176\u0179", "\u0250q\u0254p\u01dd\u025f\u0183\u0265!\u027e\u029e\u05df\u026fuodb\u0279s\u0287n\u028c\u028dx\u028ez", "\u0394\u03b2\u0106\u0110\u20ac\u20a3\u01e4\u0126\u0197\u0134\u049c\u0141\u039c\u0147\u00d8\u01a4\u03a9\u0158\u015e\u0166\u1eeeV\u0174\u0416\u00a5\u017d", "\u03b1\u0253\u0aee\u2202\u03b5\u0192\u0260\u0266\u0e40\u029d\u04a1\u2113\u0271\u0273\u03c3\u03c1\u03c6\u0ae8\u0e23\u01ad\u00b5\u0475\u03c9\u05d0\u10e7\u01b6", "a\u0432cde\u0493g\u043d\u03b9j\u0138l\u043cnopqr\u0455\u0442\u03c5vw\u0445yz", "\u24b6\u24b7\u24b8\u24b9\u24ba\u24bb\u24bc\u24bd\u24be\u24bf\u24c0\u24c1\u24c2\u24c3\u24c4\u24c5\u24c6\u24c7\u24c8\u24c9\u24ca\u24cb\u24cc\u24cd\u24ce\u24cf", "\u0105\u10ea\u0188\u0256\u025b\u0284\u0260\u0267\u0131\u029d\u0199\u0196\u0271\u014b\u01a1\u2118\u0566\u0f5e\u0282\u026c\u0173\u06f7\u1ff3\u04b3\u10e7\u0291", "\ua34f\ua303\ua253\ua038\ua35f\ua387\ua045\ua0c5\ua024\ua02d\ua018\ua492\ua3ad\ua224\ua0a6\u1598\ua1b0\ua2ea\ua317\ua4c4\ua00e\u142f\ua14f\ua2bc\ua329\ua074", "\u03b1\u0432cd\u0454fgh\u00edjklmn\u03c3pqr\u0455tuvw\u0445\u0447z", "\u0414\u13f0\u2102\u2202\u018e\u0192\u13b6\u210d\u00ee\u029d\u0198\u2113\u2133\u0418\u00f8\u03c1\u01ea\u042f\u01a7\u271e\u03c5\u03d1\u13d4\u2718\u0423\u0540", "\u0414\u0411CD\u039eFGHIJ\u049cLM\u0418\u0424P\u01ea\u042fS\u0393\u0426V\u0429\u0416\u0423Z", "\u01df\u026e\u0188\u0256\u025b\u0284\u0262\u0266\u0268\u029d\u13e6\u029f\u028d\u057c\u0585\u0584\u0566\u0280\u0586\u13c6\u028a\u028b\u0561x\u028f\u0290", "\u0251\u048d\u03f2\u056a\u04bd\u0192\u0581\u0570\u00ed\u0575\u0198\u04c0\u028d\u0572\u0585\u0539\u0566\u027e\u054f\u0535\u0574\u0475\u0561\u00d7\u057e\u0540", "\u1d2c\u1d2e\u1d9c\u1d30\u1d31\u1da0\u1d33\u1d34\u1d35\u1d36\u1d37\u1d38\u1d39\u1d3a\u1d3c\u1d3e\u1d5f\u1d3f\u02e2\u1d40\u1d41\u1d5b\u1d42\u02e3\u1d5e\u1dbb", "\u1571\u10ea\ua49d\u13a0\ua085\ua2b0g\u2645\u13a5\u03f3\u041a\u056c\u10dd\u0e20\u053e\u13b5\u0563\u13d2\u13d5\u03eeu\u13c9\u13b3\ua2bc\u13a9\u13c3", "\u15c5\u1658\u1464\u15eb\u164d\u15b4\u161c\u157c\u14ff\u1499\u15bd\u1438\u14aa\u1662\u1609\u14ce\u157f\u1574\u1587S\u15b6\u1457\u143b\u164e\u166d\u15bb\u1663", "\u039b\u03e6\u3108\u00d0\u0190F\u0193\u043d\u026a\uff8c\u049a\u0141\u0bf1\u041b\u00d8\u00fe\u04a8\u5c3a\u3089\u0164\u0426\u0194\u019c\u03c7\u03e4\u1e94", "\u019b\u0181\u0187\u018a\u0404\u0191\u0193\u04c7\u0196\u0286\u0198\u053cM\u019d\u01a0\u01a4\u01a2\u01a6\u01a7\u01ac\u01b2\u0194\u019c\u04b2\u01b3\u0224", "\u0e04\u10ea\u096e\u10eb\u0aef\u0532\u0aed\u04ba\u027f\u0286\u049b\u0546\u0271\u0548\u0ae6\u01bf\u04a9\u0550\u03c2\u0a6e\u03c5\u0c6e\u03c9\u0aea\u05e2\u0abd", "\u0539\u0545\u0547\u053a\u021d\u0532\u0533\u0267\u027f\u029d\u0199\u0285\u028d\u054c\u053e\u03c1\u03c6\u0550\u054f\u0535\u0544\u05e2\u0561\u0543\u054e\u0540", "\uff91\u4e43\u1103\u308a\u4e47\uff77\u30e0\u3093\uff89\uff8c\u30ba\uff9a\uffb6\u5200\u306e\uff71\u3090\u5c3a\u4e02\uff72\u3072\u221aW\uff92\uff98\u4e59", "\u03b1\u00df\u03c2d\u03b5\u0192gh\u00ef\u0575\u03ba\uff9am\u03b7\u2295p\u03a9r\u0161\u2020u\u2200\u03c9x\u03c8z", "\u13d7\u13f0\u1348\u13b4\u13cb\u13a6\u13b6\u13c2\u13a5\u13e0\u13e6\u13dd\u13b7\u13c1\u13a7\u13ae\u13a4\u13d2\u13d5\u13d6\u13ec\u13c9\u13c7\u1300\u13a9\u135a", "\u00e5\u03b2\u00e7\u010f\u00a3\u0192\u011f\u021f\u020bj\u0137\u023d\u0271\u00f1\u00a4\u05e7\u01ed\u0211\u00a7\u021b\u0265\u221a\u03a8\u00d7\u00ff\u017e", "\u0105\u03b2\u023c\u010f\u20ac\u0192\u01e5h\u0268j\u040c\u2113\u028d\u0272\u0e4f\u03c1\u01ed\u044f$\u0163\u00b5\u02c5\u03ce\u0436\u00a5\u01b6", "\u10db\u10e9\u10d4\u10eb\u10def\u10eah\u1f36\u10e5\u03bal\u10dd\u1fc6\u00f5\u03c1\u10d2\u0393\u10f0\u0f53\u03c5\u1f57w\u10ef\u10e7\u0240", "\u00c3\u03b2\u010c\u010e\u1eb8\u0191\u011e\u0124\u012e\u0134\u040c\u0139\u03fb\u0147\u1ed6\u01a4\u01ea\u0158\u015c\u0164\u01d7\u03cb\u0174\u0416\u040e\u017b", "\u0e04\u0e56\u00a2\u0ed3\u0113f\u0e87hi\u0e27kl\u0e53\u0e96\u0ed0p\u0e51r\u015et\u0e19\u0e07\u0e9fx\u0e2f\u0e8a", "\u15e9\u15f7\u1455\u15ea\u15f4\u15b4\u01e4\u157c\u13a5\u148e\u16d5\u14aa\u15f0\u144e\u15dd\u146d\u024a\u1587\u1515\u4e05\u144c\u142f\u15ef\u166d\u01b3\u4e59", "\u15e9\u15f7\u1462\u1572\u163f\u15b4\u161c\u157c\u14f0\u149a\u15bd\u1438\u14aa\u163b\u1609\u14cd\u1575\u1574\u1587S\u15b6\u1458\u143a\u163a\u166d\u15bb\u15f1"};
            for (int i5 = 0; i5 < 32; i5++) {
                Text_activity.this.numberOutput = str.toLowerCase();
                for (int i6 = 0; i6 < 26; i6++) {
                    if (i5 != 17 && i5 != 31) {
                        str2 = String.valueOf(strArr2[i5].charAt(i6));
                    } else if (i6 < 10) {
                        str2 = String.valueOf(strArr2[i5].charAt(i6));
                    } else if (i6 > 10) {
                        str2 = String.valueOf(strArr2[i5].charAt(i6 + 1));
                    } else {
                        str2 = String.valueOf(strArr2[i5].charAt(i6)) + String.valueOf(strArr2[i5].charAt(i6 + 1));
                    }
                    Text_activity text_activity2 = Text_activity.this;
                    text_activity2.numberOutput = text_activity2.numberOutput.replaceAll(String.valueOf("abcdefghijklmnopqrstuvwxyz".charAt(i6)), str2);
                }
                Text_activity.this.NumberStyles.get(i5 + 29).setStyleValue(Text_activity.this.numberOutput);
            }
        }
    }

    @Override
    public void onBackPressed() {
        Text_activity.this.finish();
    }
}
