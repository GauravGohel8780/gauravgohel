package com.statussaver.wacaption.gbversion.StatusSaver.activity;

import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.viewpager.widget.ViewPager;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.StatusSaver.adpter.Adpter_10_Image;
import com.statussaver.wacaption.gbversion.StatusSaver.adpter.CustomPager_10__ImageAdapter;
import com.statussaver.wacaption.gbversion.StatusSaver.model.ImagesModel;
import java.io.File;
import java.util.List;

/* loaded from: classes3.dex */
public class Activity_DisplayNew_10_images extends Activity_StorieSaverBase {
    List<ImagesModel> arrayList = Adpter_10_Image.mImageResponsesList2;
    ImageView copy;
    int currentPage;
    private String flag;
    int id;
    ImageView imgshare;
    private CustomPager_10__ImageAdapter mCustomPagerAdapter;
    public ViewPager mViewPager;
    ImageView whatsappshareiv;

    @Override // com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_StorieSaverBase, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_displaynew_10_image_video);
        this.imgshare = (ImageView) findViewById(R.id.shareimggggg);
        this.copy = (ImageView) findViewById(R.id.copyy);
        this.whatsappshareiv = (ImageView) findViewById(R.id.whatsappshareiv);
        this.id = getIntent().getExtras().getInt("id", 0);
        String stringExtra = getIntent().getStringExtra("flag");
        this.flag = stringExtra;
        setTitle(stringExtra);
        getWindowManager().getDefaultDisplay().getMetrics(new DisplayMetrics());
        this.currentPage = this.id;
        this.mCustomPagerAdapter = new CustomPager_10__ImageAdapter(this, this.arrayList);
        ViewPager viewPager = (ViewPager) findViewById(R.id.pager);
        this.mViewPager = viewPager;
        viewPager.setAdapter(this.mCustomPagerAdapter);
        this.mViewPager.setCurrentItem(this.id);
        this.mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_DisplayNew_10_images.1
            @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
            public void onPageScrollStateChanged(int i) {
            }

            @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
            public void onPageScrolled(int i, float f, int i2) {
            }

            @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
            public void onPageSelected(int i) {
            }
        });
        this.imgshare.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_DisplayNew_10_images.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Activity_DisplayNew_10_images.this.doShareVideo(new File(Activity_DisplayNew_10_images.this.arrayList.get(Activity_DisplayNew_10_images.this.mViewPager.getCurrentItem()).getImagePath()));
            }
        });
        this.whatsappshareiv.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_DisplayNew_10_images.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                int currentItem = Activity_DisplayNew_10_images.this.mViewPager.getCurrentItem();
                Activity_DisplayNew_10_images activity_DisplayNew_10_images = Activity_DisplayNew_10_images.this;
                activity_DisplayNew_10_images.doShareWhatsappVideo(activity_DisplayNew_10_images.arrayList.get(currentItem).getImagePath());
            }
        });
        this.copy.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_DisplayNew_10_images.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                int currentItem = Activity_DisplayNew_10_images.this.mViewPager.getCurrentItem();
                Activity_DisplayNew_10_images activity_DisplayNew_10_images = Activity_DisplayNew_10_images.this;
                activity_DisplayNew_10_images.saveImageStatus(activity_DisplayNew_10_images.arrayList.get(currentItem).getImagePath());
            }
        });
    }

    @Override // androidx.appcompat.app.AppCompatActivity
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
//        AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_DisplayNew_10_images.5
//            @Override // com.pesonal.adsdk.MyCallback
//            public void callbackCall() {
                Activity_DisplayNew_10_images.this.finish();
//            }
//        }, AppManage.app_mainClickCntSwAd);
    }
}
