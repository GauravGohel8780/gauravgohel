package com.statussaver.wacaption.gbversion.StatusSaver.fragment;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.documentfile.provider.DocumentFile;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_11_ImageViewer;
import com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_11_RecentStatus;
import com.statussaver.wacaption.gbversion.StatusSaver.model.StoryModel;
import com.statussaver.wacaption.gbversion.StatusSaver.util.Const;
import com.statussaver.wacaption.gbversion.StatusSaver.util.FilePathUtility;
import com.statussaver.wacaption.gbversion.StatusSaver.util.iUtils;
import com.statussaver.wacaption.gbversion.newwautl.Utils;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/* loaded from: classes3.dex */
public class Fragment_11_Image extends BaseFragment {
    public String SaveFilePath = Const.RootDirectoryWhatsappShow + "/";
    Activity_11_RecentStatus activity;
    ArrayList<Object> data;
    RecyclerView recycler_view;

    public Fragment_11_Image(Activity_11_RecentStatus activity_11_RecentStatus, ArrayList<Object> arrayList) {
        this.activity = activity_11_RecentStatus;
        this.data = arrayList;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.frgment_11_image_video, viewGroup, false);
        this.recycler_view = (RecyclerView) inflate.findViewById(R.id.recycler_view);
        ImageGet();
        return inflate;
    }

    private void ImageGet() {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < this.data.size(); i++) {
            StoryModel storyModel = (StoryModel) this.data.get(i);
            if (storyModel.getUri().toString().endsWith(".jpg")) {
                arrayList.add(storyModel);
            }
        }
        ImageAdapter imageAdapter = new ImageAdapter(this.activity, arrayList);
        this.recycler_view.setLayoutManager(new GridLayoutManager(this.activity, 2));
        this.recycler_view.setAdapter(imageAdapter);
    }

    /* loaded from: classes3.dex */
    public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.ViewHolder> {
        Activity activity;
        ArrayList<Object> data;

        public ImageAdapter(Activity activity, ArrayList<Object> arrayList) {
            this.activity = activity;
            this.data = arrayList;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            return new ViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.item_image_11, viewGroup, false));
        }

        public void onBindViewHolder(ViewHolder viewHolder, int i) {
            final StoryModel storyModel = (StoryModel) this.data.get(i);
            Glide.with(this.activity).load(storyModel.getUri()).centerCrop().into(viewHolder.img_image);
            viewHolder.downloadID.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.fragment.Fragment_11_Image.ImageAdapter.1
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    ImageAdapter.this.lambda$onBindViewHolder$0$ImageFragment$ImageAdapter(storyModel, view);
                }
            });
            viewHolder.itemView.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.fragment.Fragment_11_Image.ImageAdapter.2
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    Fragment_11_Image.this.next(storyModel, 1);
                }
            });
        }

        public void lambda$onBindViewHolder$0$ImageFragment$ImageAdapter(StoryModel storyModel, View view) {
            Fragment_11_Image.this.next(storyModel, 0);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public int getItemCount() {
            return this.data.size();
        }

        /* loaded from: classes3.dex */
        public class ViewHolder extends RecyclerView.ViewHolder {
            ImageView downloadID;
            ImageView img_image;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public ViewHolder(View view) {
                super(view);
                this.img_image = (ImageView) view.findViewById(R.id.img_image);
                this.downloadID = (ImageView) view.findViewById(R.id.downloadID);
            }
        }
    }

    public static void createFileFolder() {
        if (!Const.RootDirectoryWhatsappShow.exists()) {
            Const.RootDirectoryWhatsappShow.mkdirs();
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
    }

    @SuppressLint("WrongConstant")
    public void next(final StoryModel storyModel, int i) {
        if (i != 0) {
            if (i != 1) {
                return;
            }
//            AppManage.getInstance(this.activity).showInterstitialAd(this.activity, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.fragment.Fragment_11_Image.2
//                @Override // com.pesonal.adsdk.MyCallback
//                public void callbackCall() {
                    Intent intent = new Intent(Fragment_11_Image.this.activity, Activity_11_ImageViewer.class);
                    intent.putExtra(Utils.IMAGE, storyModel.getUri().toString());
                    intent.putExtra("type", Utils.IMAGE);
                    intent.putExtra("pack", storyModel.getPack());
                    Fragment_11_Image.this.activity.startActivity(intent);
//                }
//            }, AppManage.app_mainClickCntSwAd);
        } else if (Build.VERSION.SDK_INT >= 30) {
            iUtils.checkFolder();
            try {
                Activity_11_RecentStatus activity_11_RecentStatus = this.activity;
                FilePathUtility.moveFile(activity_11_RecentStatus, DocumentFile.fromSingleUri(activity_11_RecentStatus, Uri.parse(storyModel.getPath())).getUri().toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
            iUtils.scanFile(this.activity, storyModel.getFilename());
            Toast.makeText(this.activity, "Saved...", 0).show();
        } else {
            createFileFolder();
            String path = storyModel.getPath();
            String substring = path.substring(path.lastIndexOf("/") + 1);
            try {
                copyFileToDirectory(new File(path), new File(this.SaveFilePath));
            } catch (IOException e2) {
                e2.printStackTrace();
            }
            String substring2 = substring.substring(12);
            Activity_11_RecentStatus activity_11_RecentStatus2 = this.activity;
            String[] strArr = {new File(this.SaveFilePath + substring2).getAbsolutePath()};
            String[] strArr2 = new String[1];
            strArr2[0] = storyModel.getUri().toString().endsWith(".mp4") ? "video/*" : "image/*";
            MediaScannerConnection.scanFile(activity_11_RecentStatus2, strArr, strArr2, new MediaScannerConnection.MediaScannerConnectionClient() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.fragment.Fragment_11_Image.1
                @Override // android.media.MediaScannerConnection.MediaScannerConnectionClient
                public void onMediaScannerConnected() {
                }

                @Override // android.media.MediaScannerConnection.OnScanCompletedListener
                public void onScanCompleted(String str, Uri uri) {
                }
            });
            new File(this.SaveFilePath, substring).renameTo(new File(this.SaveFilePath, substring2));
            Activity_11_RecentStatus activity_11_RecentStatus3 = this.activity;
            Toast.makeText(activity_11_RecentStatus3, this.activity.getResources().getString(R.string.saved_to) + this.SaveFilePath + substring2, 1).show();
        }
    }

    public static void copyFileToDirectory(File file, File file2) throws IOException {
        copyFileToDirectory(file, file2);
    }

}
