package com.statussaver.wacaption.gbversion.StatusSaver.pageer;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import com.statussaver.wacaption.gbversion.StatusSaver.fragment.Fragment_10_Images;
import com.statussaver.wacaption.gbversion.StatusSaver.fragment.Fragment_10_Video;

/* loaded from: classes3.dex */
public class StorieSaver_10_TabPager extends FragmentStatePagerAdapter {
    int mNumOfTabs;

    public StorieSaver_10_TabPager(FragmentManager fragmentManager, int i) {
        super(fragmentManager);
        this.mNumOfTabs = i;
    }

    @Override // androidx.fragment.app.FragmentStatePagerAdapter
    public Fragment getItem(int i) {
        if (i == 0) {
            return new Fragment_10_Images();
        }
        if (i == 1) {
            return new Fragment_10_Video();
        }
        return null;
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public int getCount() {
        return this.mNumOfTabs;
    }
}
