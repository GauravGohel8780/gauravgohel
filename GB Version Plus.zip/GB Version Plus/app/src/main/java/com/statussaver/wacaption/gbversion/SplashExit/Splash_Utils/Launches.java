package com.statussaver.wacaption.gbversion.SplashExit.Splash_Utils;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import com.statussaver.wacaption.gbversion.R;
import java.io.File;
import java.io.FileOutputStream;

/* loaded from: classes3.dex */
public class Launches {
    public static void openAppPlayStore(Activity activity, String str) {
        if (!Glob.isOnline(activity)) {
            Toast.makeText(activity, "Check Your Internet Connection", 0).show();
            return;
        }
        try {
            activity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + str)));
        } catch (Exception unused) {
            Toast.makeText(activity, "You don't have Google Play installed", 1).show();
        }
    }

    public static void shareApp(Activity activity) {
        Uri uri;
        if (Glob.checkMultiplePermissions(activity)) {
            Bitmap decodeResource = BitmapFactory.decodeResource(activity.getResources(), R.drawable.banner);
            File file = new File(activity.getExternalCacheDir() + "/banner.jpg");
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(file);
                decodeResource.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                fileOutputStream.flush();
                fileOutputStream.close();
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("image/*");
                intent.putExtra("android.intent.extra.TEXT", Glob.app_link);
                if (Build.VERSION.SDK_INT >= 23) {
                    uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".provider", file);
                } else {
                    uri = Uri.fromFile(file);
                }
                intent.putExtra("android.intent.extra.STREAM", uri);
                activity.startActivity(Intent.createChooser(intent, "Share Image using"));
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }
}
