package com.statussaver.wacaption.gbversion.newwautl;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.storage.StorageManager;
import android.text.format.Formatter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.PointerIconCompat;
import androidx.documentfile.provider.DocumentFile;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.newwautl.WallCleanerAdapter;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes3.dex */
public class WallCleanerActivity extends AppCompatActivity implements WallCleanerAdapter.OnCheckboxListener {
    loadDataAsync async;
    ImageView backIV;
    String category;
    LinearLayout delete;
    RelativeLayout emptyLay;
    TextView emptyTxt;
    File file;
    String folderPath;
    RelativeLayout loaderLay;
    WallCleanerAdapter mAdapter;
    RecyclerView.LayoutManager mLayoutManager;
    RecyclerView recyclerView;
    LinearLayout sAccessBtn;
    CheckBox selectAll;
    TextView txt;
    int REQUEST_ACTION_OPEN_DOCUMENT_TREE = PointerIconCompat.TYPE_ALIAS;
    ArrayList<CleanerFileModel> filesToDelete = new ArrayList<>();
    ArrayList<CleanerFileModel> statusImageList = new ArrayList<>();

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_wall_cleaner);
        this.category = getIntent().getStringExtra("category");
        this.folderPath = getIntent().getStringExtra("folderPath");
        this.loaderLay = (RelativeLayout) findViewById(R.id.loaderLay);
        this.emptyLay = (RelativeLayout) findViewById(R.id.emptyLay);
        ImageView imageView = (ImageView) findViewById(R.id.backIV);
        this.backIV = imageView;
        imageView.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.newwautl.WallCleanerActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                WallCleanerActivity.this.onBackPressed();
            }
        });
        this.emptyTxt = (TextView) findViewById(R.id.emptyTxt);
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        this.recyclerView = recyclerView;
        recyclerView.setHasFixedSize(true);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 3);
        this.mLayoutManager = gridLayoutManager;
        this.recyclerView.setLayoutManager(gridLayoutManager);
        this.txt = (TextView) findViewById(R.id.txt);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.delete);
        this.delete = linearLayout;
        linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.newwautl.WallCleanerActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (!WallCleanerActivity.this.filesToDelete.isEmpty()) {
                    new AlertDialog.Builder(WallCleanerActivity.this).setMessage("Are you sure , You want to delete selected files?").setCancelable(true).setNegativeButton("Yes", new DialogInterface.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.newwautl.WallCleanerActivity.2.2
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialogInterface, int i) {
                            ArrayList arrayList = new ArrayList();
                            Iterator<CleanerFileModel> it = WallCleanerActivity.this.filesToDelete.iterator();
                            char c = '\uffff';
                            while (it.hasNext()) {
                                CleanerFileModel next = it.next();
                                DocumentFile fromSingleUri = DocumentFile.fromSingleUri(WallCleanerActivity.this, Uri.parse(next.getFilePath()));
                                if (!fromSingleUri.exists() || !fromSingleUri.delete()) {
                                    c = 0;
                                } else {
                                    arrayList.add(next);
                                    if (c == 0) {
                                        return;
                                    }
                                    c = 1;
                                }
                            }
                            WallCleanerActivity.this.filesToDelete.clear();
                            Iterator it2 = arrayList.iterator();
                            while (it2.hasNext()) {
                                WallCleanerActivity.this.statusImageList.remove((CleanerFileModel) it2.next());
                            }
                            WallCleanerActivity.this.mAdapter.notifyDataSetChanged();
                            if (c == 0) {
                                Toast.makeText(WallCleanerActivity.this, "Couldn't delete some files", 0).show();
                            } else if (c == 1) {
                                Toast.makeText(WallCleanerActivity.this, "Deleted successfully", 0).show();
                            }
                            WallCleanerActivity.this.txt.setText(R.string.delete_items_blank);
                            WallCleanerActivity.this.txt.setTextColor(WallCleanerActivity.this.getResources().getColor(R.color.black));
                            WallCleanerActivity.this.selectAll.setChecked(false);
                        }
                    }).setPositiveButton("No", new DialogInterface.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.newwautl.WallCleanerActivity.2.1
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    }).create().show();
                }
            }
        });
        CheckBox checkBox = (CheckBox) findViewById(R.id.selectAll);
        this.selectAll = checkBox;
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: com.statussaver.wacaption.gbversion.newwautl.WallCleanerActivity.3
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (compoundButton.isPressed()) {
                    WallCleanerActivity.this.filesToDelete.clear();
                    int i = 0;
                    while (true) {
                        if (i >= WallCleanerActivity.this.statusImageList.size()) {
                            break;
                        } else if (!WallCleanerActivity.this.statusImageList.get(i).selected) {
                            z = true;
                            break;
                        } else {
                            i++;
                        }
                    }
                    if (z) {
                        for (int i2 = 0; i2 < WallCleanerActivity.this.statusImageList.size(); i2++) {
                            WallCleanerActivity.this.statusImageList.get(i2).selected = true;
                            WallCleanerActivity.this.filesToDelete.add(WallCleanerActivity.this.statusImageList.get(i2));
                        }
                        WallCleanerActivity.this.selectAll.setChecked(true);
                    } else {
                        for (int i3 = 0; i3 < WallCleanerActivity.this.statusImageList.size(); i3++) {
                            WallCleanerActivity.this.statusImageList.get(i3).selected = false;
                        }
                    }
                    WallCleanerActivity.this.mAdapter.notifyDataSetChanged();
                }
            }
        });
        LinearLayout linearLayout2 = (LinearLayout) findViewById(R.id.sAccessBtn);
        this.sAccessBtn = linearLayout2;
        linearLayout2.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.newwautl.WallCleanerActivity.4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                WallCleanerActivity.this.lambda$onCreate$0$WallCleanerActivity(view);
            }
        });
        if (!Utils.iswApp || !this.category.equals(Utils.WALLPAPER)) {
            if (!Utils.iswApp || !this.category.equals(Utils.STICKER) || SharedPrefs.getWAStickerTree(this).equals("")) {
                return;
            }
            populateGrid();
        } else if (SharedPrefs.getWAWallTree(this).equals("")) {
        } else {
            populateGrid();
        }
    }

    public void lambda$onCreate$0$WallCleanerActivity(View view) {
        Intent intent;
        @SuppressLint("WrongConstant") StorageManager storageManager = (StorageManager) getSystemService("storage");
        String str = this.folderPath;
        if (Build.VERSION.SDK_INT >= 29) {
            intent = storageManager.getPrimaryStorageVolume().createOpenDocumentTreeIntent();
            String replace = ((Uri) intent.getParcelableExtra("android.provider.extra.INITIAL_URI")).toString().replace("/root/", "/document/");
            intent.putExtra("android.provider.extra.INITIAL_URI", Uri.parse(replace + "%3A" + str));
        } else {
            intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
            intent.putExtra("android.provider.extra.INITIAL_URI", Uri.parse("content://com.android.externalstorage.documents/document/primary%3A" + str));
        }
        intent.addFlags(2);
        intent.addFlags(1);
        intent.addFlags(128);
        intent.addFlags(64);
        startActivityForResult(intent, this.REQUEST_ACTION_OPEN_DOCUMENT_TREE);
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        loadDataAsync loaddataasync = this.async;
        if (loaddataasync != null) {
            loaddataasync.cancel(true);
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
//        AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.newwautl.WallCleanerActivity.5
//            @Override // com.pesonal.adsdk.MyCallback
//            public void callbackCall() {
                WallCleanerActivity.this.finish();
//            }
//        }, AppManage.app_mainClickCntSwAd);
    }

    public void populateGrid() {
        loadDataAsync loaddataasync = new loadDataAsync();
        this.async = loaddataasync;
        loaddataasync.execute(new Void[0]);
    }

    /* loaded from: classes3.dex */
    public class loadDataAsync extends AsyncTask<Void, Void, Void> {
        DocumentFile[] allFiles;

        loadDataAsync() {
        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            super.onPreExecute();
            WallCleanerActivity.this.loaderLay.setVisibility(0);
            WallCleanerActivity.this.recyclerView.setVisibility(8);
            WallCleanerActivity.this.sAccessBtn.setVisibility(8);
            WallCleanerActivity.this.emptyLay.setVisibility(8);
        }

        public Void doInBackground(Void... voidArr) {
            this.allFiles = null;
            WallCleanerActivity.this.statusImageList = new ArrayList<>();
            this.allFiles = WallCleanerActivity.this.getFromSdcard();
            int i = 0;
            while (true) {
                DocumentFile[] documentFileArr = this.allFiles;
                if (i >= documentFileArr.length) {
                    return null;
                }
                if (!documentFileArr[i].getUri().toString().contains(".nomedia") && !this.allFiles[i].isDirectory()) {
                    WallCleanerActivity.this.statusImageList.add(new CleanerFileModel(this.allFiles[i].getUri().toString(), this.allFiles[i].getName(), String.valueOf(this.allFiles[i].length())));
                }
                i++;
            }
        }

        public void onPostExecute(Void r4) {
            super.onPostExecute( r4);
            new Handler().postDelayed(new Runnable() { // from class: com.statussaver.wacaption.gbversion.newwautl.WallCleanerActivity.loadDataAsync.1
                @Override // java.lang.Runnable
                public final void run() {
                    loadDataAsync.this.lambda$onPostExecute$0$WallCleanerActivity$loadDataAsync();
                }
            }, 300L);
        }

        public void lambda$onPostExecute$0$WallCleanerActivity$loadDataAsync() {
            WallCleanerActivity wallCleanerActivity = WallCleanerActivity.this;
            wallCleanerActivity.mAdapter = new WallCleanerAdapter(wallCleanerActivity, wallCleanerActivity.statusImageList, Utils.WALLPAPER, WallCleanerActivity.this);
            WallCleanerActivity.this.recyclerView.setAdapter(WallCleanerActivity.this.mAdapter);
            WallCleanerActivity.this.loaderLay.setVisibility(8);
            WallCleanerActivity.this.recyclerView.setVisibility(0);
            if (WallCleanerActivity.this.statusImageList == null || WallCleanerActivity.this.statusImageList.size() == 0) {
                WallCleanerActivity.this.emptyLay.setVisibility(0);
            } else {
                WallCleanerActivity.this.emptyLay.setVisibility(8);
            }
        }
    }

    public DocumentFile[] getFromSdcard() {
        String str;
        if (Utils.iswApp && this.category.equals(Utils.WALLPAPER)) {
            str = SharedPrefs.getWAWallTree(this);
        } else if (!Utils.iswApp && this.category.equals(Utils.WALLPAPER)) {
            str = SharedPrefs.getWBWallTree(this);
        } else if (!Utils.iswApp || !this.category.equals(Utils.STICKER)) {
            str = (Utils.iswApp || !this.category.equals(Utils.STICKER)) ? "" : SharedPrefs.getWBStickerTree(this);
        } else {
            str = SharedPrefs.getWAStickerTree(this);
        }
        DocumentFile fromTreeUri = DocumentFile.fromTreeUri(getApplicationContext(), Uri.parse(str));
        if (fromTreeUri == null || !fromTreeUri.exists() || !fromTreeUri.isDirectory() || !fromTreeUri.canRead() || !fromTreeUri.canWrite()) {
            return null;
        }
        return fromTreeUri.listFiles();
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == this.REQUEST_ACTION_OPEN_DOCUMENT_TREE && i2 == -1) {
            Uri data = intent.getData();
            try {
                if (Build.VERSION.SDK_INT >= 19) {
                    getContentResolver().takePersistableUriPermission(data, 3);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (Utils.iswApp && this.category.equals(Utils.WALLPAPER)) {
                SharedPrefs.setWAWallTree(this, data.toString());
            } else if (!Utils.iswApp && this.category.equals(Utils.WALLPAPER)) {
                SharedPrefs.setWBWallTree(this, data.toString());
            } else if (Utils.iswApp && this.category.equals(Utils.STICKER)) {
                SharedPrefs.setWAStickerTree(this, data.toString());
            } else if (!Utils.iswApp && this.category.equals(Utils.STICKER)) {
                SharedPrefs.setWBStickerTree(this, data.toString());
            }
            populateGrid();
        }
    }

    @Override // com.statussaver.wacaption.gbversion.newwautl.WallCleanerAdapter.OnCheckboxListener
    public void onCheckboxListener(View view, List<CleanerFileModel> list) {
        this.filesToDelete.clear();
        for (CleanerFileModel cleanerFileModel : list) {
            if (cleanerFileModel.isSelected()) {
                this.filesToDelete.add(cleanerFileModel);
            }
        }
        if (this.filesToDelete.size() == this.statusImageList.size()) {
            this.selectAll.setChecked(true);
        }
        if (!this.filesToDelete.isEmpty()) {
            long j = 0;
            Iterator<CleanerFileModel> it = this.filesToDelete.iterator();
            while (it.hasNext()) {
                j += Integer.parseInt(it.next().getSize());
            }
            String formatShortFileSize = Formatter.formatShortFileSize(this, j);
            TextView textView = this.txt;
            textView.setText("Delete Selected Items (" + formatShortFileSize + ")");
            this.txt.setTextColor(Color.parseColor("#5AA061"));
            return;
        }
        this.txt.setText(R.string.delete_items_blank);
        this.txt.setTextColor(getResources().getColor(R.color.black));
        this.selectAll.setChecked(false);
    }
}
