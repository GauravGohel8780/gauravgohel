package com.statussaver.wacaption.gbversion.newwautl;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.statussaver.wacaption.gbversion.R;
import java.util.List;

/* loaded from: classes3.dex */
public class WallCleanerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    Activity activity;
    String category;
    List<CleanerFileModel> mData;
    public OnCheckboxListener onCheckboxListener;
    int voice = 1;
    int wallpaper = 2;

    /* loaded from: classes3.dex */
    public interface OnCheckboxListener {
        void onCheckboxListener(View view, List<CleanerFileModel> list);
    }

    public WallCleanerAdapter(Activity activity, List<CleanerFileModel> list, String str, OnCheckboxListener onCheckboxListener) {
        this.mData = list;
        this.activity = activity;
        this.category = str;
        this.onCheckboxListener = onCheckboxListener;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemViewType(int i) {
        String str = this.category;
        int hashCode = str.hashCode();
        if (hashCode != -892481550) {
            if (hashCode == 1474694658 && str.equals(Utils.WALLPAPER)) {
                return this.wallpaper;
            }
        } else {
            str.equals("status");
        }
        return hashCode;
    }

    /* loaded from: classes3.dex */
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        CheckBox checkBox;
        ImageView imagevi;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public ViewHolder(View view) {
            super(view);
            ImageView imageView = (ImageView) view.findViewById(R.id.imageView);
            this.imagevi = imageView;
            imageView.setOnClickListener(this);
            this.checkBox = (CheckBox) view.findViewById(R.id.checkbox);
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Intent intent = new Intent();
            intent.setAction("android.intent.action.VIEW");
            intent.setDataAndType(Uri.parse(WallCleanerAdapter.this.mData.get(getAdapterPosition()).getFilePath()), "image/*");
            intent.addFlags(1);
            try {
                WallCleanerAdapter.this.activity.startActivity(intent);
            } catch (ActivityNotFoundException unused) {
                Toast.makeText(WallCleanerAdapter.this.activity, "No Apps in your device for view this type of file.", 1).show();
            }
        }
    }

    /* loaded from: classes3.dex */
    public class ViewHolderAudios extends RecyclerView.ViewHolder implements View.OnClickListener {
        public CheckBox checkBox;
        public ImageView imageView;
        public TextView name;
        public TextView size;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public ViewHolderAudios(View view) {
            super(view);
            this.name = (TextView) view.findViewById(R.id.name);
            this.size = (TextView) view.findViewById(R.id.size);
            this.checkBox = (CheckBox) view.findViewById(R.id.checkbox);
            ImageView imageView = (ImageView) view.findViewById(R.id.imageView);
            this.imageView = imageView;
            imageView.setOnClickListener(this);
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Intent intent = new Intent();
            intent.setAction("android.intent.action.VIEW");
            intent.setDataAndType(Uri.parse(WallCleanerAdapter.this.mData.get(getAdapterPosition()).getFilePath()), "audio/*");
            try {
                WallCleanerAdapter.this.activity.startActivity(intent);
            } catch (ActivityNotFoundException unused) {
                Toast.makeText(WallCleanerAdapter.this.activity, "No Apps in your device for view this type of file.", 1).show();
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        if (i == this.wallpaper) {
            return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cleaner_item, viewGroup, false));
        }
        return new ViewHolderAudios(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cleaner_audio_item, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, final int i) {
        CleanerFileModel cleanerFileModel = this.mData.get(i);
        if (getItemViewType(i) == this.voice) {
            ViewHolderAudios viewHolderAudios = (ViewHolderAudios) viewHolder;
            viewHolderAudios.imageView.setImageResource(R.drawable.voice);
            viewHolderAudios.name.setText(cleanerFileModel.getFileName());
            viewHolderAudios.size.setText(cleanerFileModel.getSize());
            viewHolderAudios.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: com.statussaver.wacaption.gbversion.newwautl.WallCleanerAdapter.1
                @Override // android.widget.CompoundButton.OnCheckedChangeListener
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    WallCleanerAdapter.this.mData.get(i).setSelected(z);
                    if (WallCleanerAdapter.this.onCheckboxListener != null) {
                        WallCleanerAdapter.this.onCheckboxListener.onCheckboxListener(compoundButton, WallCleanerAdapter.this.mData);
                    }
                }
            });
            if (cleanerFileModel.isSelected()) {
                viewHolderAudios.checkBox.setChecked(true);
                return;
            } else {
                viewHolderAudios.checkBox.setChecked(false);
                return;
            }
        }
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        Glide.with(this.activity).load(cleanerFileModel.getFilePath()).into(viewHolder2.imagevi);
        viewHolder2.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: com.statussaver.wacaption.gbversion.newwautl.WallCleanerAdapter.2
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                WallCleanerAdapter.this.mData.get(i).setSelected(z);
                if (WallCleanerAdapter.this.onCheckboxListener != null) {
                    WallCleanerAdapter.this.onCheckboxListener.onCheckboxListener(compoundButton, WallCleanerAdapter.this.mData);
                }
            }
        });
        if (cleanerFileModel.isSelected()) {
            viewHolder2.checkBox.setChecked(true);
        } else {
            viewHolder2.checkBox.setChecked(false);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.mData.size();
    }
}
