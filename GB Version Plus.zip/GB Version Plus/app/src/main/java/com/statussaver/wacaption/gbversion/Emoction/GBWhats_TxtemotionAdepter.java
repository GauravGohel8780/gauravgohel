package com.statussaver.wacaption.gbversion.Emoction;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.recyclerview.widget.RecyclerView;
import com.statussaver.wacaption.gbversion.R;
import java.util.List;

public class GBWhats_TxtemotionAdepter extends RecyclerView.Adapter<GBWhats_TxtemotionAdepter.MyViewHolder> {

    public Activity context;
    public List<GBWhats_CSFEmot> f5743a;
    public GBWhats_SharedPreference f5744b = new GBWhats_SharedPreference();

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public AppCompatImageView f185p;
        public TextView f186q;
        public AppCompatImageView f187r;

        public MyViewHolder(View view) {
            super(view);
            this.f185p = (AppCompatImageView) view.findViewById(R.id.csf_cpy_btn);
            this.f187r = (AppCompatImageView) view.findViewById(R.id.csf_shr12);
            this.f186q = (TextView) view.findViewById(R.id.emoti);
        }
    }

    public GBWhats_TxtemotionAdepter(List<GBWhats_CSFEmot> list, Activity activity) {
        this.f5743a = list;
        this.context = activity;
    }

    public void add(GBWhats_CSFEmot gBWhats_CSFEmot) {
        this.f5743a.add(gBWhats_CSFEmot);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return this.f5743a.size();
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {
        myViewHolder.f186q.setText(this.f5743a.get(i).getName());
        myViewHolder.f186q.setSelected(true);
        final GBWhats_CopyHan gBWhats_CopyHan = new GBWhats_CopyHan(this.context);
        final String charSequence = myViewHolder.f186q.getText().toString();
        myViewHolder.f185p.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gBWhats_CopyHan.copy(charSequence);
            }
        });
        myViewHolder.f187r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gBWhats_CopyHan.Share(charSequence);
            }
        });
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(this.context).inflate(R.layout.gbwhats_emotion_itm, viewGroup, false));
    }
}
