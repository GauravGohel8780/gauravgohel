package com.statussaver.wacaption.gbversion.Fakeprofile;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.statussaver.wacaption.gbversion.R;

public class GBWhats_ProfileShowActivity extends AppCompatActivity {

    public String f204h;
    public String f205i;
    public String f206j;
    public String f207k;
    public String f208l;
    public ImageView f209m;
    public TextView f210n;
    public TextView f211o;
    public TextView f212p;
    public TextView f213q;
    public TextView f214r;
    ImageView idSwitchoff;
    ImageView idSwitchon;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.gbwhats_activity_profile_show);
        getWindow().setFlags(1024, 1024);
        this.f209m = (ImageView) findViewById(R.id.iv_image);
        this.f210n = (TextView) findViewById(R.id.name);
        this.f211o = (TextView) findViewById(R.id.status);
        this.f212p = (TextView) findViewById(R.id.statusdate);
        this.f213q = (TextView) findViewById(R.id.number);
        this.f214r = (TextView) findViewById(R.id.online);
        this.idSwitchoff = (ImageView) findViewById(R.id.idSwitchoff);
        this.idSwitchon = (ImageView) findViewById(R.id.idSwitchon);
        Intent intent = getIntent();
        this.f205i = intent.getStringExtra("lastseen");
        this.f206j = intent.getStringExtra("status");
        this.f207k = intent.getStringExtra("statusdate");
        this.f208l = intent.getStringExtra("number");
        Uri uri = GBWhats_FakeProfileActivity.selectedImageUri;
        if (uri == null) {
            this.f209m.setImageResource(R.drawable.profile);
        } else {
            this.f209m.setImageURI(uri);
        }
        this.f210n.setText(this.f204h);
        this.f214r.setText(this.f205i);
        this.f211o.setText(this.f206j);
        this.f212p.setText(this.f207k);
        TextView textView = this.f213q;
        textView.setText("+91 " + this.f208l);
        findViewById(R.id.more).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GBWhats_ProfileShowActivity.this.onBackPressed();
            }
        });
        this.idSwitchoff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GBWhats_ProfileShowActivity.this.idSwitchoff.setVisibility(8);
                GBWhats_ProfileShowActivity.this.idSwitchon.setVisibility(0);
            }
        });
        this.idSwitchon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GBWhats_ProfileShowActivity.this.idSwitchoff.setVisibility(0);
                GBWhats_ProfileShowActivity.this.idSwitchon.setVisibility(8);
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
