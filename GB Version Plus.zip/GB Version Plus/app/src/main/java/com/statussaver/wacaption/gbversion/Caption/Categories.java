package com.statussaver.wacaption.gbversion.Caption;

public class Categories {
    public static String[] categoriesArray = {"Girls", "Love & Emotion", "Friends", "Hillarious", "For Insta", "Motivational", "Birthday", "Cool", "Fitness", "Flirty", "Food", "Friendship", "Funny", "Inspiring", "Life", "Love", "Party", "Sarcastic", "Savage", "Selfie", "Selflove", "Smile", "Success", "Sweet", "Travel", "Happiness"};
}
