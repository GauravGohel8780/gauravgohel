package com.statussaver.wacaption.gbversion.Emoction;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.newwautl.Utils;

public class GBWhats_TxtemotincustAdepter extends BaseAdapter {

    public Activity csf_cnt;
    public int[] csf_icon;
    private LayoutInflater csf_inflater;
    private String[] csf_logo;

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0L;
    }

    public GBWhats_TxtemotincustAdepter(Activity activity, String[] strArr, int[] iArr) {
        this.csf_cnt = activity;
        this.csf_logo = strArr;
        this.csf_inflater = LayoutInflater.from(activity);
        this.csf_icon = iArr;
    }

    @Override
    public int getCount() {
        return this.csf_logo.length;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        View inflate = this.csf_inflater.inflate(R.layout.gbwhats_csf_gridview, (ViewGroup) null);
        ((ImageView) inflate.findViewById(R.id.textViewEachCategory)).setImageDrawable(this.csf_cnt.getDrawable(this.csf_icon[i]));
        ((ImageView) inflate.findViewById(R.id.textViewEachCategory)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view2) {
                final Intent intent = new Intent(GBWhats_TxtemotincustAdepter.this.csf_cnt, GBWhats_EmotionActivity.class);
                intent.putExtra(Utils.IMAGE, GBWhats_TxtemotincustAdepter.this.csf_icon[i]);
                intent.putExtra("P", i);
                GBWhats_TxtemotincustAdepter.this.csf_cnt.startActivity(intent);
            }
        });
        return inflate;
    }
}
