package com.statussaver.wacaption.gbversion.StatusSaver.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import com.bumptech.glide.Glide;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.StatusSaver.util.Const;
import com.statussaver.wacaption.gbversion.newwautl.Utils;

/* loaded from: classes3.dex */
public class Activity_11_ImageViewer extends AppCompatActivity {
    Activity_11_ImageViewer activity;
    ImageView imageView;
    public String SaveFilePath = Const.RootDirectoryWhatsappShow + "/";
    String image_path = "";
    String package_name = "";
    String path = "";
    String type = "";

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_11_image_viewer);
        this.activity = this;
        ((ImageView) findViewById(R.id.back)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_11_ImageViewer.1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                Activity_11_ImageViewer.this.onBackPressed();
            }
        });
        this.imageView = (ImageView) findViewById(R.id.imageView);
        Intent intent = getIntent();
        if (intent != null) {
            this.image_path = intent.getStringExtra(Utils.IMAGE);
            this.type = intent.getStringExtra("type");
            this.package_name = intent.getStringExtra("pack");
            if (this.image_path == null) {
                return;
            }
            Glide.with((FragmentActivity) this).load(this.image_path).into(this.imageView);
        }
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
//        AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_11_ImageViewer.2
//            @Override // com.pesonal.adsdk.MyCallback
//            public void callbackCall() {
                Activity_11_ImageViewer.this.finish();
//            }
//        }, AppManage.app_mainClickCntSwAd);
    }
}
