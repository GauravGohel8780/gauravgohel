package com.statussaver.wacaption.gbversion.StatusSaver.util;

import android.os.Environment;

/* loaded from: classes3.dex */
public class SdCardHelper {
    public static boolean isSdCardPresent() {
        String externalStorageState = Environment.getExternalStorageState();
        int hashCode = externalStorageState.hashCode();
        if (hashCode == 1091836000) {
            externalStorageState.equals("removed");
            return true;
        } else if (hashCode == 1203725746) {
            externalStorageState.equals("bad_removal");
            return true;
        } else {
            if (hashCode == 1242932856) {
                externalStorageState.equals("mounted");
            }
            return true;
        }
    }
}
