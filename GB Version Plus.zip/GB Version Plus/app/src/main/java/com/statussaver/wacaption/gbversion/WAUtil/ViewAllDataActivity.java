package com.statussaver.wacaption.gbversion.WAUtil;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.exifinterface.media.ExifInterface;
import androidx.viewpager.widget.ViewPager;
import com.google.android.material.tabs.TabLayout;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.WAUtil.adpter.PagerAdpter;
import com.statussaver.wacaption.gbversion.WAUtil.adpter.PagerAudioAdpter;
import com.statussaver.wacaption.gbversion.WAUtil.adpter.PagerStatusAdpter;
import com.statussaver.wacaption.gbversion.WAUtil.adpter.PagerVideoAdpter;

/* loaded from: classes3.dex */
public class ViewAllDataActivity extends AppCompatActivity {
    ImageView back;
    TabLayout tabLayout;
    TextView txtTitle;
    ViewPager viewPager;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_view_all_data);
        this.tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        this.viewPager = (ViewPager) findViewById(R.id.viewPager);
        this.txtTitle = (TextView) findViewById(R.id.tx_nm);
        this.back = (ImageView) findViewById(R.id.back);
        this.txtTitle.setText(getIntent().getStringExtra("active"));
        this.tabLayout.setTabGravity(0);
        this.back.setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.ViewAllDataActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ViewAllDataActivity.super.onBackPressed();
            }
        });
        if (getIntent().getStringExtra("id").equals("1")) {
            TabLayout tabLayout = this.tabLayout;
            tabLayout.addTab(tabLayout.newTab().setText("Received"));
            TabLayout tabLayout2 = this.tabLayout;
            tabLayout2.addTab(tabLayout2.newTab().setText("Sent"));
            this.viewPager.setAdapter(new PagerAdpter(this, getSupportFragmentManager(), this.tabLayout.getTabCount(), getIntent().getStringExtra("id")));
        } else if (getIntent().getStringExtra("id").equals(ExifInterface.GPS_MEASUREMENT_2D)) {
            TabLayout tabLayout3 = this.tabLayout;
            tabLayout3.addTab(tabLayout3.newTab().setText("Received"));
            TabLayout tabLayout4 = this.tabLayout;
            tabLayout4.addTab(tabLayout4.newTab().setText("Sent"));
            this.viewPager.setAdapter(new PagerVideoAdpter(this, getSupportFragmentManager(), this.tabLayout.getTabCount(), getIntent().getStringExtra("id")));
        } else if (getIntent().getStringExtra("id").equals(ExifInterface.GPS_MEASUREMENT_3D)) {
            TabLayout tabLayout5 = this.tabLayout;
            tabLayout5.addTab(tabLayout5.newTab().setText("Image"));
            TabLayout tabLayout6 = this.tabLayout;
            tabLayout6.addTab(tabLayout6.newTab().setText("Video"));
            this.viewPager.setAdapter(new PagerStatusAdpter(this, getSupportFragmentManager(), this.tabLayout.getTabCount(), getIntent().getStringExtra("id")));
        } else if (getIntent().getStringExtra("id").equals("5")) {
            TabLayout tabLayout7 = this.tabLayout;
            tabLayout7.addTab(tabLayout7.newTab().setText("Received"));
            TabLayout tabLayout8 = this.tabLayout;
            tabLayout8.addTab(tabLayout8.newTab().setText("Sent"));
            this.viewPager.setAdapter(new PagerAudioAdpter(this, getSupportFragmentManager(), this.tabLayout.getTabCount(), getIntent().getStringExtra("id")));
        }
        ViewPager viewPager = this.viewPager;
        viewPager.setCurrentItem(viewPager.getCurrentItem());
        this.viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(this.tabLayout));
        this.tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() { // from class: com.statussaver.wacaption.gbversion.WAUtil.ViewAllDataActivity.2
            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            public void onTabReselected(TabLayout.Tab tab) {
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            public void onTabSelected(TabLayout.Tab tab) {
                ViewAllDataActivity.this.viewPager.setCurrentItem(tab.getPosition());
            }
        });
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
//        AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.WAUtil.ViewAllDataActivity.3
//            @Override // com.pesonal.adsdk.MyCallback
//            public void callbackCall() {
                ViewAllDataActivity.this.finish();
//            }
//        }, AppManage.app_mainClickCntSwAd);
    }
}
