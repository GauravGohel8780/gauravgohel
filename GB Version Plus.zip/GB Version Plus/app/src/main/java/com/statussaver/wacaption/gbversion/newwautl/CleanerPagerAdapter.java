package com.statussaver.wacaption.gbversion.newwautl;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

/* loaded from: classes3.dex */
public class CleanerPagerAdapter extends FragmentPagerAdapter {
    String category;
    String receivedPath;
    String sentPath;

    @Override // androidx.viewpager.widget.PagerAdapter
    public int getCount() {
        return 2;
    }

    public CleanerPagerAdapter(FragmentManager fragmentManager, String str, String str2, String str3) {
        super(fragmentManager);
        this.category = str;
        this.receivedPath = str2;
        this.sentPath = str3;
    }

    @Override // androidx.fragment.app.FragmentPagerAdapter
    public Fragment getItem(int i) {
        if (i != 1) {
            return CleanListFragment.newInstance(this.category, this.receivedPath, "no");
        }
        return CleanListFragment.newInstance(this.category, this.sentPath, "yes");
    }
}
