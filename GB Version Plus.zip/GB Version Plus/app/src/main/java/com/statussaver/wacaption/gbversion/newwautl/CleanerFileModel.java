package com.statussaver.wacaption.gbversion.newwautl;

/* loaded from: classes3.dex */
public class CleanerFileModel {
    private String filename;
    private String filepath;
    public boolean selected = false;
    private String size;

    public boolean isSelected() {
        return this.selected;
    }

    public void setSelected(boolean z) {
        this.selected = z;
    }

    public CleanerFileModel(String str, String str2, String str3) {
        this.filepath = str;
        this.filename = str2;
        this.size = str3;
    }

    public String getFileName() {
        return this.filename;
    }

    public String getFilePath() {
        return this.filepath;
    }

    public String getSize() {
        return this.size;
    }

    public void setSize(String str) {
        this.size = str;
    }
}
