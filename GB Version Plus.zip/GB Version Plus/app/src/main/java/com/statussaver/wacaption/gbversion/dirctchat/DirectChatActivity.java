package com.statussaver.wacaption.gbversion.dirctchat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Contacts;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.content.CursorLoader;

import com.bumptech.glide.load.Key;
import com.hbb20.CountryCodePicker;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.StatusSaver.util.WhitelistCheck;

import java.io.PrintStream;
import java.net.URLEncoder;

public class DirectChatActivity extends AppCompatActivity {

    ImageView back;
    CountryCodePicker cc_code;
    EditText ed_Num;
    EditText ed_Text;
    ImageView i_Send;
    ImageView i_contct;
    String selectedCode;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_direct_chat);
        this.cc_code = (CountryCodePicker) findViewById(R.id.cc_code);
        this.ed_Num = (EditText) findViewById(R.id.ed_Num);
        this.ed_Text = (EditText) findViewById(R.id.ed_Text);
        this.i_contct = (ImageView) findViewById(R.id.i_contct);
        this.i_Send = (ImageView) findViewById(R.id.i_Send);
        this.back = (ImageView) findViewById(R.id.back);
        this.cc_code.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectChatActivity.this.cc_code.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener() {
                    @Override
                    public void onCountrySelected() {
                        DirectChatActivity.this.selectedCode = String.valueOf(DirectChatActivity.this.cc_code.getSelectedCountryCodeWithPlus());
                    }
                });
            }
        });
        this.i_contct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent("android.intent.action.PICK", Contacts.CONTENT_URI);
                intent.setType("vnd.android.cursor.dir/phone_v2");
                DirectChatActivity.this.startActivityForResult(intent, 101);
            }
        });
        this.i_Send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str = DirectChatActivity.this.cc_code.getSelectedCountryCodeWithPlus() + DirectChatActivity.this.ed_Num.getText().toString();
                String obj = DirectChatActivity.this.ed_Text.getText().toString();
                PackageManager packageManager = DirectChatActivity.this.getPackageManager();
                Intent intent = new Intent("android.intent.action.VIEW");
                int i = Build.VERSION.SDK_INT;
                try {
                    intent.setPackage(WhitelistCheck.CONSUMER_WHATSAPP_PACKAGE_NAME);
                    intent.setData(Uri.parse("https://api.whatsapp.com/send?phone=" + str + "&text=" + URLEncoder.encode(obj, Key.STRING_CHARSET_NAME)));
                    PrintStream printStream = System.out;
                    StringBuilder sb = new StringBuilder();
                    sb.append("VV1=");
                    sb.append(Build.VERSION.SDK_INT);
                    printStream.println(sb.toString());
                    if (intent.resolveActivity(packageManager) != null) {
                        DirectChatActivity.this.startActivity(intent);
                    } else if (i >= 30) {
                        try {
                            DirectChatActivity.this.startActivity(intent);
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(DirectChatActivity.this, " WhatsApp is not currently installed on your phone", 0).show();
                        }
                    } else {
                        Toast.makeText(DirectChatActivity.this, " WhatsApp is not currently installed on your phone", 0).show();
                    }
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        });
        this.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DirectChatActivity.this.onBackPressed();
            }
        });
    }

    @SuppressLint("Range")
    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 101 && i2 == -1) {
            Cursor loadInBackground = new CursorLoader(this, intent.getData(), null, null, null, null).loadInBackground();
            if (!loadInBackground.moveToFirst()) {
                return;
            }
            this.ed_Num.setText(loadInBackground.getString(loadInBackground.getColumnIndex("data1")));
        }
    }

    @Override
    public void onBackPressed() {
        DirectChatActivity.this.finish();
    }

}
