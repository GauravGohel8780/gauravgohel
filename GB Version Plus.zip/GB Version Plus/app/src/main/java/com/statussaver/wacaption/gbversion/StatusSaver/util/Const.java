package com.statussaver.wacaption.gbversion.StatusSaver.util;

import android.os.Environment;
import java.io.File;

/* loaded from: classes3.dex */
public class Const {
    public static final String FOLDER_NAME = "/WhatsApp/";
    public static final String FOLDER_NAME_Whatsapp_and11 = "/Android/media/com.whatsapp/WhatsApp/";
    public static final String FOLDER_NAME_Whatsapp_and11_B = "/Android/media/com.whatsapp.w4b/WhatsApp Business/";
    public static final String FOLDER_NAME_Whatsappbusiness = "/WhatsApp Business/";
    public static File RootDirectoryWhatsappShow = new File(Environment.getExternalStorageDirectory() + "/Download/WhatsSaver");
    public static final String SAVE_FOLDER_NAME = "/Download/WhatsSaver/";
    public static final String savedData = "/storage/emulated/0/Download/WhatsSaver/";
}
