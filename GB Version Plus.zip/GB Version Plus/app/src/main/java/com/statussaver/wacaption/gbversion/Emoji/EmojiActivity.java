package com.statussaver.wacaption.gbversion.Emoji;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.statussaver.wacaption.gbversion.Emoction.GBWhats_CopyHan;
import com.statussaver.wacaption.gbversion.R;

import java.io.IOException;
import java.io.InputStream;

public class EmojiActivity extends AppCompatActivity {

    ImageView clearTxtBtn;
    ImageView convertButton;
    EditText convertedText;
    ImageView copyButton;
    EditText emojeeText;
    EditText inputText;
    ImageView shareButton;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_emoji);
        this.inputText = (EditText) findViewById(R.id.inputText);
        this.emojeeText = (EditText) findViewById(R.id.emojeeTxt);
        this.convertedText = (EditText) findViewById(R.id.convertedEmojeeTxt);
        this.convertButton = (ImageView) findViewById(R.id.convertEmojeeBtn);
        this.copyButton = (ImageView) findViewById(R.id.copyTxtBtn);
        this.shareButton = (ImageView) findViewById(R.id.shareTxtBtn);
        this.clearTxtBtn = (ImageView) findViewById(R.id.clearTxtBtn);
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EmojiActivity.this.finish();
            }
        });
        this.convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (EmojiActivity.this.inputText.getText().toString().isEmpty()) {
                    Toast.makeText(EmojiActivity.this.getApplicationContext(), "Enter text", 0).show();
                    return;
                }
                char[] charArray = EmojiActivity.this.inputText.getText().toString().toCharArray();
                EmojiActivity.this.convertedText.setText("\n");
                for (char c : charArray) {
                    if (c == '?') {
                        try {
                            InputStream open = EmojiActivity.this.getBaseContext().getAssets().open("ques.txt");
                            byte[] bArr = new byte[open.available()];
                            open.read(bArr);
                            open.close();
                            String replaceAll = new String(bArr).replaceAll("[*]", EmojiActivity.this.emojeeText.getText().toString());
                            EmojiActivity.this.convertedText.append(replaceAll + "\n\n");
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else if (c == ((char) (c & '_')) || Character.isDigit(c)) {
                        try {
                            InputStream open2 = EmojiActivity.this.getBaseContext().getAssets().open(c + ".txt");
                            byte[] bArr2 = new byte[open2.available()];
                            open2.read(bArr2);
                            open2.close();
                            String replaceAll2 = new String(bArr2).replaceAll("[*]", EmojiActivity.this.emojeeText.getText().toString());
                            EmojiActivity.this.convertedText.append(replaceAll2 + "\n\n");
                        } catch (IOException e2) {
                            e2.printStackTrace();
                        }
                    } else {
                        try {
                            InputStream open3 = EmojiActivity.this.getBaseContext().getAssets().open("low" + c + ".txt");
                            byte[] bArr3 = new byte[open3.available()];
                            open3.read(bArr3);
                            open3.close();
                            String replaceAll3 = new String(bArr3).replaceAll("[*]", EmojiActivity.this.emojeeText.getText().toString());
                            EmojiActivity.this.convertedText.append(replaceAll3 + "\n\n");
                        } catch (IOException e3) {
                            e3.printStackTrace();
                        }
                    }
                }
            }
        });
        this.clearTxtBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EmojiActivity.this.convertedText.setText("");
            }
        });
        this.convertedText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!EmojiActivity.this.convertedText.getText().toString().isEmpty()) {
                    ((ClipboardManager) EmojiActivity.this.getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText(EmojiActivity.this.inputText.getText().toString(), EmojiActivity.this.convertedText.getText().toString()));
                }
            }
        });
        this.copyButton.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View view) {
                if (EmojiActivity.this.convertedText.getText().toString().isEmpty()) {
                    Toast.makeText(EmojiActivity.this.getApplicationContext(), "Convert text before copy", 0).show();
                    return;
                }
                ((ClipboardManager) EmojiActivity.this.getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText(EmojiActivity.this.inputText.getText().toString(), EmojiActivity.this.convertedText.getText().toString()));
                Toast.makeText(EmojiActivity.this.getApplicationContext(), "Copied to Clipboard", 0).show();
            }
        });
        this.shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (EmojiActivity.this.convertedText.getText().toString().isEmpty()) {
                    Toast.makeText(EmojiActivity.this.getApplicationContext(), "Convert text to share", 0).show();
                    return;
                }
                Intent intent = new Intent();
                intent.setAction("android.intent.action.SEND");
                intent.putExtra("android.intent.extra.TEXT", EmojiActivity.this.convertedText.getText().toString());
                intent.setType(GBWhats_CopyHan.MIME_PLAINTEXT);
                EmojiActivity.this.startActivity(Intent.createChooser(intent, "Select an app to share"));
            }
        });
    }

    @Override
    public void onBackPressed() {
        EmojiActivity.this.finish();
    }
}
