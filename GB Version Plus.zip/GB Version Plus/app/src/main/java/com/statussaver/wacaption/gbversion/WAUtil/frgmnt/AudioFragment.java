package com.statussaver.wacaption.gbversion.WAUtil.frgmnt;

import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.WAUtil.adpter.AudioAdpter;
import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;

/* loaded from: classes3.dex */
public class AudioFragment extends Fragment {
    AudioAdpter adapter;
    File audio;
    private File file1;
    TextView filet;
    RecyclerView recylerView;
    TextView size;
    long sizeAudio = 0;

    public static String getReadableSize(long j) {
        if (j <= 0) {
            return "0";
        }
        double d = j;
        int log10 = (int) (Math.log10(d) / Math.log10(1024.0d));
        StringBuilder sb = new StringBuilder();
        DecimalFormat decimalFormat = new DecimalFormat("#,##0.#");
        double pow = Math.pow(1024.0d, log10);
        Double.isNaN(d);
        Double.isNaN(d);
        Double.isNaN(d);
        sb.append(decimalFormat.format(d / pow));
        sb.append(" ");
        sb.append(new String[]{"B", "KB", "MB", "GB", "TB"}[log10]);
        return sb.toString();
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = LayoutInflater.from(getContext()).inflate(R.layout.fragment_rec_audio, viewGroup, false);
        this.recylerView = (RecyclerView) inflate.findViewById(R.id.recylerView);
        this.filet = (TextView) inflate.findViewById(R.id.file);
        this.size = (TextView) inflate.findViewById(R.id.size);
        this.recylerView.setLayoutManager(new GridLayoutManager(getActivity(), 1));
        File file = new File(new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "/WhatsApp").getAbsolutePath(), "/Media/WhatsApp Audio");
        if (Build.VERSION.SDK_INT >= 30) {
            this.file1 = new File("Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Audio");
        } else {
            this.file1 = new File(file.getAbsolutePath(), "/Media/.WhatsApp Audio");
        }
        File file2 = this.file1;
        this.audio = file2;
        File[] listFiles = file2.listFiles();
        ArrayList arrayList = new ArrayList();
        if (listFiles != null) {
            for (int i = 0; i < listFiles.length; i++) {
                if (listFiles[i].getPath().endsWith(".mp3") || listFiles[i].getPath().endsWith(".m4a")) {
                    arrayList.add(listFiles[i].getPath());
                    this.sizeAudio += listFiles[i].length();
                }
            }
        }
        this.filet.setText(arrayList.size() + " Files");
        this.size.setText("Size: " + getReadableSize(this.sizeAudio));
        AudioAdpter audioAdpter = new AudioAdpter(getActivity(), arrayList, "101");
        this.adapter = audioAdpter;
        this.recylerView.setAdapter(audioAdpter);
        this.adapter.notifyDataSetChanged();
        return inflate;
    }
}
