package com.statussaver.wacaption.gbversion.StatusSaver.model;

import java.io.Serializable;

/* loaded from: classes3.dex */
public class ImagesModel implements Serializable {
    String mImageName;
    String mImagePath;

    public String getImageName() {
        return this.mImageName;
    }

    public void setImageName(String str) {
        this.mImageName = str;
    }

    public String getImagePath() {
        return this.mImagePath;
    }

    public void setImagePath(String str) {
        this.mImagePath = str;
    }
}
