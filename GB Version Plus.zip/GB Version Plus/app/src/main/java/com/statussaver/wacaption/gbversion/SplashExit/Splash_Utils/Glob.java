package com.statussaver.wacaption.gbversion.SplashExit.Splash_Utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;

import androidx.annotation.RequiresApi;

import com.statussaver.wacaption.gbversion.MainActivity;
import com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren1;
import com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren2;
import com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren3;
import com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren4;
import com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren5;
import com.statussaver.wacaption.gbversion.SplashExit.Activity.Activity_ExtraScrren6;
import com.statussaver.wacaption.gbversion.SplashExit.Activity.EnterApp_Act;
import com.statussaver.wacaption.gbversion.SplashExit.Activity.StartActivity;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/* loaded from: classes3.dex */
public class Glob {
    public static String app_link = "https://play.google.com/store/apps/details?id=com.statussaver.wacaption.gbversion&hl=en";
    public static String privacy_link = "https://appsmanagerpolicy.blogspot.com/";

    public static boolean checkMultiplePermissions(Activity activity) {
        if (Build.VERSION.SDK_INT >= 23) {
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            if (!addPermission(activity, arrayList2, "android.permission.READ_EXTERNAL_STORAGE")) {
                arrayList.add("Read Storage");
            }
            if (!addPermission(activity, arrayList2, "android.permission.WRITE_EXTERNAL_STORAGE")) {
                arrayList.add("Write Storage");
            }
            if (arrayList2.size() <= 0) {
                return true;
            }
            activity.requestPermissions((String[]) arrayList2.toArray(new String[arrayList2.size()]), 124);
            return false;
        }
        return true;
    }

    @SuppressLint("WrongConstant")
    public static boolean addPermission(Activity activity, List<String> list, String str) {
        if (Build.VERSION.SDK_INT < 23 || activity.checkSelfPermission(str) == 0) {
            return true;
        }
        list.add(str);
        return activity.shouldShowRequestPermissionRationale(str);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static void checkTime(String str, String str2, String str3, final Activity activity) {
        DateTimeFormatter ofPattern = DateTimeFormatter.ofPattern("HH", Locale.US);
        LocalTime parse = LocalTime.parse(str, ofPattern);
        LocalTime parse2 = LocalTime.parse(str2, ofPattern);
        LocalTime parse3 = LocalTime.parse(str3, ofPattern);
        if (!parse2.isAfter(parse) ? parse3.isAfter(parse) || parse3.isBefore(parse2) || parse3.equals(parse) || parse3.equals(parse2) : (parse.isBefore(parse3) || parse.equals(parse3)) && (parse2.isAfter(parse3) || parse2.equals(parse3))) {
//            if (AppManage.vpnscreen == 1) {
//                UnifiedSDK.CC.getVpnState(new Callback<VPNState>() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Splash_Utils.Glob.1
//                    public void success(VPNState vPNState) {
//                        if (AnonymousClass2.$SwitchMap$com$anchorfree$vpnsdk$vpnservice$VPNState[vPNState.ordinal()] == 1) {
//                            Glob.callnext(activity);
//                        } else {
//                            activity.startActivity(new Intent(activity, VPN_MainActivity.class));
//                        }
//                    }
//
//                    @Override // com.anchorfree.vpnsdk.callbacks.Callback
//                    public void failure(VpnException vpnException) {
//                        activity.startActivity(new Intent(activity, VPN_MainActivity.class));
//                    }
//                });
//                return;
//            } else {
//                callnext(activity);
//                return;
//            }
        }
//        callnext(activity);
    }

//    /* renamed from: com.statussaver.wacaption.gbversion.SplashExit.Splash_Utils.Glob$2 */
//    /* loaded from: classes3.dex */
//    public static /* synthetic */ class AnonymousClass2 {
//        static final /* synthetic */ int[] $SwitchMap$com$anchorfree$vpnsdk$vpnservice$VPNState;
//
//        static {
//            int[] iArr = new int[VPNState.values().length];
//            $SwitchMap$com$anchorfree$vpnsdk$vpnservice$VPNState = iArr;
//            try {
//                iArr[VPNState.CONNECTED.ordinal()] = 1;
//            } catch (NoSuchFieldError unused) {
//            }
//        }
//    }

//    public static void callnext(Activity activity) {
//        if (AppManage.firstScreen == 1) {
//            activity.startActivity(new Intent(activity, StartActivity.class));
//            activity.finish();
//        } else if (AppManage.startScreen == 1) {
//            activity.startActivity(new Intent(activity, EnterApp_Act.class));
//            activity.finish();
//        } else if (AppManage.extrascreen1 == 1) {
//            activity.startActivity(new Intent(activity, Activity_ExtraScrren1.class));
//            activity.finish();
//        } else if (AppManage.extrascreen2 == 1) {
//            activity.startActivity(new Intent(activity, Activity_ExtraScrren2.class));
//            activity.finish();
//        } else if (AppManage.extrascreen3 == 1) {
//            activity.startActivity(new Intent(activity, Activity_ExtraScrren3.class));
//            activity.finish();
//        } else if (AppManage.extrascreen4 == 1) {
//            activity.startActivity(new Intent(activity, Activity_ExtraScrren4.class));
//            activity.finish();
//        } else if (AppManage.extrascreen5 == 1) {
//            activity.startActivity(new Intent(activity, Activity_ExtraScrren5.class));
//            activity.finish();
//        } else if (AppManage.extrascreen6 == 1) {
//            activity.startActivity(new Intent(activity, Activity_ExtraScrren6.class));
//            activity.finish();
//        } else {
//            activity.startActivity(new Intent(activity, MainActivity.class));
//            activity.finish();
//        }
//    }

    public static boolean isOnline(Activity activity) {
        @SuppressLint("WrongConstant") NetworkInfo activeNetworkInfo = ((ConnectivityManager) activity.getSystemService("connectivity")).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }
}
