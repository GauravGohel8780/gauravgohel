package com.statussaver.wacaption.gbversion.Emoction;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class GBWhats_CopyHan {

    public static final String MIME_PLAINTEXT = "text/plain";
    private Context context;

    public GBWhats_CopyHan(Context context) {
        this.context = context;
    }

    public void Share(String str) {
        if (str.isEmpty()) {
            Toast.makeText(this.context, "Enter Some Text", 0).show();
            return;
        }
        try {
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType(MIME_PLAINTEXT);
            intent.putExtra("android.intent.extra.TEXT", str);
            this.context.startActivity(Intent.createChooser(intent, "choose one"));
        } catch (Exception unused) {
        }
    }

    public void copy(String str) {
        if (str.isEmpty()) {
            Toast.makeText(this.context, "Enter Some Text", 0).show();
            return;
        }
        ClipboardManager clipboardManager = (ClipboardManager) this.context.getSystemService("clipboard");
        Context context = this.context;
        Toast.makeText(context, "Copied To Clipboard! Your Copied Text Ss " + str, 0).show();
        ClipData newPlainText = ClipData.newPlainText("simple text", str);
        if (clipboardManager == null) {
            return;
        }
        clipboardManager.setPrimaryClip(newPlainText);
    }
}
