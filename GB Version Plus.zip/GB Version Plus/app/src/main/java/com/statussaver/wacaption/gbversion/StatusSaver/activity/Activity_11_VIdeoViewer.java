package com.statussaver.wacaption.gbversion.StatusSaver.activity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;
import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.newwautl.Utils;

/* loaded from: classes3.dex */
public class Activity_11_VIdeoViewer extends AppCompatActivity {
    Activity_11_VIdeoViewer activity;
    String atype = "";
    String package_name = "";
    String path = "";
    private int position = 0;
    String type = "";
    String videoPath = "";
    VideoView video_view;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_11_video_viewer);
        this.activity = this;
        this.video_view = (VideoView) findViewById(R.id.video_view);
        ((ImageView) findViewById(R.id.back)).setOnClickListener(new View.OnClickListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_11_VIdeoViewer.1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                Activity_11_VIdeoViewer.this.onBackPressed();
            }
        });
        Intent intent = getIntent();
        if (intent != null) {
            this.videoPath = intent.getStringExtra(Utils.VIDEO);
            this.type = intent.getStringExtra("type");
            this.atype = intent.getStringExtra("type");
            this.package_name = intent.getStringExtra("pack");
            this.video_view.setVideoPath(this.videoPath);
            this.video_view.start();
        }
        this.video_view.setMediaController(new MediaController(this));
        try {
            this.video_view.setOnPreparedListener(new MediaPlayer.OnPreparedListener() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_11_VIdeoViewer.2
                @Override // android.media.MediaPlayer.OnPreparedListener
                public final void onPrepared(MediaPlayer mediaPlayer) {
                    Activity_11_VIdeoViewer.this.lambda$onCreate$1$VIdeoViewerActivity(mediaPlayer);
                }
            });
        } catch (Exception unused) {
        }
    }

    public void lambda$onCreate$1$VIdeoViewerActivity(MediaPlayer mediaPlayer) {
        this.video_view.seekTo(this.position);
        if (this.position == 0) {
            this.video_view.start();
        } else {
            this.video_view.resume();
        }
    }

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putInt("Position", this.video_view.getCurrentPosition());
        this.video_view.pause();
    }

    @Override // android.app.Activity
    public void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        int i = bundle.getInt("Position");
        this.position = i;
        this.video_view.seekTo(i);
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onResume() {
        this.video_view.start();
        super.onResume();
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
//        AppManage.getInstance(this).showInterstitialBackAd(this, new MyCallback() { // from class: com.statussaver.wacaption.gbversion.StatusSaver.activity.Activity_11_VIdeoViewer.3
//            @Override // com.pesonal.adsdk.MyCallback
//            public void callbackCall() {
                Activity_11_VIdeoViewer.this.finish();
//            }
//        }, AppManage.app_mainClickCntSwAd);
    }
}
