package com.statussaver.wacaption.gbversion.SplashExit.Activity;

import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.statussaver.wacaption.gbversion.R;
import com.statussaver.wacaption.gbversion.SplashExit.Splash_Utils.Glob;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;
import org.json.JSONObject;

public class Splash_Activity extends AppCompatActivity {

    public static Splash_Activity activity;
    private PreferenceManager prefManager;

    @Override
    public void onBackPressed() {
        finishAffinity();
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.sp_activity_splash);
        activity = this;
        printHashKey(this);
        this.prefManager = new PreferenceManager(this);
        Bundle bundle2 = new Bundle();
        bundle2.putString("Splash_Activity", "Splash_Activity");
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(getApplicationContext(),PermissionActivity.class));
            }
        },2000);
//        ADSinit(activity, getCurrentVersionCode(), new getDataListner() { // from class: com.statussaver.wacaption.gbversion.SplashExit.Activity.Splash_Activity.1
//            @Override // com.pesonal.adsdk.getDataListner
//            public void onReload() {
//            }
//
//            @Override // com.pesonal.adsdk.getDataListner
//            public void onSuccess() {
//                Splash_Activity.this.redirect3();
//            }
//
//            @Override // com.pesonal.adsdk.getDataListner
//            public void onVPNdataSuccess() {
//                if (AppManage.vpnscreen == 1) {
//                    Splash_Activity.this.initHydraSdk();
//                    Splash_Activity.this.prefManager.setStringpreference("MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAl5uXMT/9fIpE/SZvg2/5TeAgwtaCoUhyfZTff2UZqJaUN48fhr6Rev71Jyptw8ZswyOmR+E7y6JBxpxkOgw9BSUYaYmLwzJfcVaLBlU8dceFNGIEuToICMrJdRFCKjs2EfvFHjzg6uRFUUB4K+XikYlQE3plSAxxMpuuAwFaUYTqBB/ZOQVQDZF73kA7xaksePDex+yILc8+Sm5C/tfwVxx1aj1ISZmHj2S1ZYI4zHPMquO3hfxNxYMW+2VOzBrGu2ZbUnz8v1rPmHqMOQhV7mMLKTZRi53BsZ9OgfN+ObSnNw4rrGY3iOEUtaelHax0c1Dz2diyqO61luFKaoOcuwIDAQAB", "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAl5uXMT/9fIpE/SZvg2/5TeAgwtaCoUhyfZTff2UZqJaUN48fhr6Rev71Jyptw8ZswyOmR+E7y6JBxpxkOgw9BSUYaYmLwzJfcVaLBlU8dceFNGIEuToICMrJdRFCKjs2EfvFHjzg6uRFUUB4K+XikYlQE3plSAxxMpuuAwFaUYTqBB/ZOQVQDZF73kA7xaksePDex+yILc8+Sm5C/tfwVxx1aj1ISZmHj2S1ZYI4zHPMquO3hfxNxYMW+2VOzBrGu2ZbUnz8v1rPmHqMOQhV7mMLKTZRi53BsZ9OgfN+ObSnNw4rrGY3iOEUtaelHax0c1Dz2diyqO61luFKaoOcuwIDAQAB");
//                    Splash_Activity.this.prefManager.setStringpreference("oll_feature_for_onemonth", "oll_feature_for_onemonth");
//                    Splash_Activity.this.prefManager.setStringpreference("oll_feature_for_sixmonth", "oll_feature_for_sixmonth");
//                    Splash_Activity.this.prefManager.setStringpreference("oll_feature_for_year", "oll_feature_for_year");
//                }
//            }
//
//            @Override // com.pesonal.adsdk.getDataListner
//            public void onUpdate(String str) {
//                Log.e("my_log", "onUpdate: " + str);
//            }
//
//            @Override // com.pesonal.adsdk.getDataListner
//            public void onRedirect(String str) {
//                Log.e("my_log", "onRedirect: " + str);
//            }
//
//            @Override // com.pesonal.adsdk.getDataListner
//            public void onGetExtradata(JSONObject jSONObject) {
//                Log.e("my_log", "ongetExtradata: " + jSONObject.toString());
//            }
//        });
    }

    public void printHashKey(Activity activity2) {
        Signature[] signatureArr;
        try {
            for (Signature signature : getPackageManager().getPackageInfo(getPackageName(), 64).signatures) {
                MessageDigest messageDigest = MessageDigest.getInstance("SHA");
                messageDigest.update(signature.toByteArray());
                Log.e("abc", "printHashKey() Hash Key: " + new String(Base64.encode(messageDigest.digest(), 0)));
            }
        } catch (NoSuchAlgorithmException e) {
            Log.e("", "printHashKey()", e);
        } catch (Exception e2) {
            Log.e("", "printHashKey()", e2);
        }
    }

}
