package com.gbmashapp.statusdownloder.AdsDemo;

import android.app.Activity;
import android.app.Dialog;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.browser.customtabs.CustomTabsIntent;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.gbmashapp.statusdownloder.R;

import java.util.Random;

public class AppOpenAds {
    public void loadAd(Activity activity, OnAppOpenAdsListner onAppOpenAdsListner) {
        if (SharedPrefs.getADsShow(activity).equalsIgnoreCase("yes")) {
            if (SharedPrefs.getAppOpenShow(activity) == 1) {
                AdRequest request = new AdRequest.Builder().build();
                AppOpenAd.load(activity, SharedPrefs.getAMAppOpenId(activity), request, AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, new AppOpenAd.AppOpenAdLoadCallback() {
                    @Override
                    public void onAdLoaded(AppOpenAd ad) {
                        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override
                            public void onAdDismissedFullScreenContent() {
                                super.onAdDismissedFullScreenContent();
                                onAppOpenAdsListner.onAdsDismissed();
                            }

                            @Override
                            public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                                super.onAdFailedToShowFullScreenContent(adError);
                            }

                            @Override
                            public void onAdShowedFullScreenContent() {
                                super.onAdShowedFullScreenContent();
                            }
                        });
                        ad.show(activity);
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        onAppOpenAdsListner.onAdsDismissed();
                    }
                });
            }
            else if (SharedPrefs.getAppOpenShow(activity) == 2) {
                new InterstitialAds(activity).loadinterads(activity, new InterstitialAds.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        onAppOpenAdsListner.onAdsDismissed();
                    }
                });
            }
            else if (SharedPrefs.getAppOpenShow(activity) == 3) {
                Dialog dialog = new Dialog(activity);
                dialog = new Dialog(activity, android.R.style.Theme_DeviceDefault_Light_NoActionBar_Fullscreen);
                dialog.setContentView(R.layout.ads_qureka_layout);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                dialog.setCancelable(true);

                RelativeLayout qurekaappopen = dialog.findViewById(R.id.game_inter_ad_layout);
                ImageView cancelimage = dialog.findViewById(R.id.qureka_inter_close_btn);
                int[] qurekaBigBannerArray = {R.drawable.big_banner1, R.drawable.big_banner2, R.drawable.big_banner4, R.drawable.big_banner5, R.drawable.big_banner6, R.drawable.big_banner7, R.drawable.big_banner8, R.drawable.big_banner9, R.drawable.big_banner10, R.drawable.big_banner11, R.drawable.big_banner12};
                ImageView qurekaimg = dialog.findViewById(R.id.game_inter_mediaView);
                try {
                    qurekaimg.setImageResource(qurekaBigBannerArray[new Random().nextInt(qurekaBigBannerArray.length)]);
                } catch (Resources.NotFoundException e) {
                    e.printStackTrace();
                    qurekaimg.setImageDrawable(activity.getResources().getDrawable(R.drawable.big_banner1));
                }
                qurekaappopen.setOnClickListener(view1 -> {
                    onAppOpenAdsListner.onAdsDismissed();
                    CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                    CustomTabsIntent customTabsIntent = builder.build();
                    customTabsIntent.launchUrl(activity, Uri.parse(SharedPrefs.getqurekashowurl(activity)));
                });
                cancelimage.setOnClickListener(view1 -> {
                    onAppOpenAdsListner.onAdsDismissed();
                    CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                    CustomTabsIntent customTabsIntent = builder.build();
                    customTabsIntent.launchUrl(activity, Uri.parse(SharedPrefs.getqurekashowurl(activity)));
                });
                dialog.show();
            }
            else {
                onAppOpenAdsListner.onAdsDismissed();
            }
        } else {
            Toast.makeText(activity, " not load", Toast.LENGTH_SHORT).show();
            onAppOpenAdsListner.onAdsDismissed();
        }
    }

    public interface OnAppOpenAdsListner {
        void onAdsDismissed();
    }
}
