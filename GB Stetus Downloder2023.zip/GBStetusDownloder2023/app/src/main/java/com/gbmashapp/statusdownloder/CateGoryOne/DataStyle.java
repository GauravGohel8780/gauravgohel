package com.gbmashapp.statusdownloder.CateGoryOne;

public class DataStyle {

    String styleName;
    String styleValue;

    public DataStyle(String str, String str2) {
        this.styleName = str;
        this.styleValue = str2;
    }

    public String getStyleName() {
        return this.styleName;
    }

    public void setStyleName(String str) {
        this.styleName = str;
    }

    public String getStyleValue() {
        return this.styleValue;
    }

    public void setStyleValue(String str) {
        this.styleValue = str;
    }

}
