package com.gbmashapp.statusdownloder.ExtraScreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import com.gbmashapp.statusdownloder.AdsDemo.InterstitialAds;
import com.gbmashapp.statusdownloder.AdsDemo.NativeAds;
import com.gbmashapp.statusdownloder.AdsDemo.RateUsDialog;
import com.gbmashapp.statusdownloder.AdsDemo.SharedPrefs;
import com.gbmashapp.statusdownloder.MainActivity;
import com.gbmashapp.statusdownloder.R;

public class Music_M_M_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_mm);

        if (SharedPrefs.getAdsTextShow(this) == 1) {
            findViewById(R.id.nativead_text).setVisibility(View.VISIBLE);
        }
        if (SharedPrefs.getAdsShowleyer(this).contains("MAN")) {
            findViewById(R.id.viewlayout).setVisibility(View.VISIBLE);
        }
        new NativeAds(this).nativeads(this, findViewById(R.id.native_container));

        if (SharedPrefs.getScreen_chack(this).isEmpty()) {
            SharedPrefs.setScreen_chack(this, "1");
        }

        TextView textView = (TextView) findViewById(R.id.btnstart);
        textView.setAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.right));
        findViewById(R.id.btnstart).setOnClickListener(view -> {

            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {

                    if (SharedPrefs.getusersequence(Music_M_M_Activity.this).equals("1")) {
                        Intent intent = new Intent(Music_M_M_Activity.this, Locationn_New_Activity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    } else {
                        if (SharedPrefs.getextraPageShow(Music_M_M_Activity.this).contains("2")) {
                            Intent intent = new Intent(Music_M_M_Activity.this, Locationn_New_Activity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        } else if (SharedPrefs.getextraPageShow(Music_M_M_Activity.this).contains("3")) {
                            Intent intent = new Intent(Music_M_M_Activity.this, Location_Gt_Start_Activity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        } else if (SharedPrefs.getextraPageShow(Music_M_M_Activity.this).contains("4")) {
                            Intent intent = new Intent(Music_M_M_Activity.this, PageFourr_Activity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        } else if (SharedPrefs.getextraPageShow(Music_M_M_Activity.this).contains("5")) {
                            Intent intent = new Intent(Music_M_M_Activity.this, PageFive_Activity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        } else if (SharedPrefs.getextraPageShow(Music_M_M_Activity.this).contains("6")) {
                            Intent intent = new Intent(Music_M_M_Activity.this, MainActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        } else {
                            Intent intent = new Intent(Music_M_M_Activity.this, MainActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        }
                    }
                }
            });
        });
    }

    @Override
    public void onBackPressed() {
        if (SharedPrefs.getScreen_chack(this).equals("1")) {
            new RateUsDialog(this).ShowRateUsDialog();
        } else {
            super.onBackPressed();
        }
    }
}