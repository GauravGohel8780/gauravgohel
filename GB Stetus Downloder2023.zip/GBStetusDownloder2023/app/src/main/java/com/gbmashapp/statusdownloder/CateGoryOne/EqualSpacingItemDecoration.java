package com.gbmashapp.statusdownloder.CateGoryOne;

import android.graphics.Rect;
import android.view.View;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class EqualSpacingItemDecoration extends RecyclerView.ItemDecoration {

    private int displayMode;
    private final int spacing;

    public EqualSpacingItemDecoration(int i) {
        this(i, -1);
    }

    public EqualSpacingItemDecoration(int i, int i2) {
        this.spacing = i;
        this.displayMode = i2;
    }

    @Override
    public void getItemOffsets(Rect rect, View view, RecyclerView recyclerView, RecyclerView.State state) {
        setSpacingForDirection(rect, recyclerView.getLayoutManager(), recyclerView.getChildViewHolder(view).getAdapterPosition(), state.getItemCount());
    }

    private void setSpacingForDirection(Rect rect, RecyclerView.LayoutManager layoutManager, int i, int i2) {
        if (this.displayMode == -1) {
            this.displayMode = resolveDisplayMode(layoutManager);
        }
        int i3 = this.displayMode;
        int i4 = 0;
        if (i3 == 0) {
            int i5 = this.spacing;
            rect.left = i5;
            if (i == i2 - 1) {
                i4 = i5;
            }
            rect.right = i4;
            int i6 = this.spacing;
            rect.top = i6;
            rect.bottom = i6;
        } else if (i3 == 1) {
            int i7 = this.spacing;
            rect.left = i7;
            rect.right = i7;
            rect.top = i7;
            if (i == i2 - 1) {
                i4 = i7;
            }
            rect.bottom = i4;
        } else if (i3 != 2 || !(layoutManager instanceof GridLayoutManager)) {
        } else {
            int spanCount = ((GridLayoutManager) layoutManager).getSpanCount();
            int i8 = i2 / spanCount;
            int i9 = this.spacing;
            rect.left = i9;
            if (i % spanCount != spanCount - 1) {
                i9 = 0;
            }
            rect.right = i9;
            int i10 = this.spacing;
            rect.top = i10;
            if (i / spanCount == i8 - 1) {
                i4 = i10;
            }
            rect.bottom = i4;
        }
    }

    private int resolveDisplayMode(RecyclerView.LayoutManager layoutManager) {
        if (layoutManager instanceof GridLayoutManager) {
            return 2;
        }
//        return !layoutManager.canScrollHorizontally();
        return 0;
    }
}
