package com.gbmashapp.statusdownloder.AdsDemo;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.browser.customtabs.CustomTabsIntent;

import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.nativeAds.MaxNativeAdListener;
import com.applovin.mediation.nativeAds.MaxNativeAdLoader;
import com.applovin.mediation.nativeAds.MaxNativeAdView;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdListener;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.gbmashapp.statusdownloder.R;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.Random;

public class NativeAds {
    Activity activity;

    public NativeAds(Activity activity) {
        this.activity = activity;
    }

    public static BroadcastReceiver broadcastReceiver;
    String nativeid, fbnativeid;

    private MaxAd nativeAd;
    JSONArray amnativearry, fbnativearry;

    public void nativeads(Activity activity, ViewGroup viewGroup) {

        if (SharedPrefs.getInternetDilog(activity).equals("yes")) {
            broadcastReceiver = new NetworkChangeListener();
            activity.registerReceiver(broadcastReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        }
        if (SharedPrefs.getADsShow(activity).equals("yes")) {
            try {
                amnativearry = new JSONArray(SharedPrefs.getAMNativeId(activity));
                nativeid = amnativearry.getString(SharedPrefs.getAMNativeIdArry(activity));
            } catch (JSONException e) {
                e.printStackTrace();
            }

            try {
                fbnativearry = new JSONArray(SharedPrefs.getFBNativeId(activity));
                fbnativeid = fbnativearry.getString(SharedPrefs.getFBNativeIdArry(activity));
            } catch (JSONException e) {
                e.printStackTrace();
            }
            loadnativeads(activity, viewGroup);
        }
    }

    public void loadnativeads(Activity activity, ViewGroup viewGroup) {
        if (SharedPrefs.getNativeSpecific(activity) == 1) {
            if (SharedPrefs.getNativeSequns(activity) == 1) {
                AdLoader adLoader = new AdLoader.Builder(activity, nativeid).forNativeAd(nativeAd -> {
                    new InflatAds(activity).inflat_admobnative(nativeAd, viewGroup);
                    SharedPrefs.setAMNativeIdArry(activity, 0);
                }).withAdListener(new AdListener() {
                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        if (SharedPrefs.getAMNativeIdArry(activity) < amnativearry.length()) {
                            new NativeAds(activity).nativeads(activity, viewGroup);
                            SharedPrefs.setAMNativeIdArry(activity, SharedPrefs.getAMNativeIdArry(activity) + 1);
                        } else {
                            FBnativeads(activity, viewGroup);
                            SharedPrefs.setAMNativeIdArry(activity, 0);
                        }
                    }
                }).withNativeAdOptions(new NativeAdOptions.Builder().build()).build();
                adLoader.loadAd(new AdRequest.Builder().build());
            } else if (SharedPrefs.getNativeSequns(activity) == 2) {
                NativeAd nativeAd = new NativeAd(activity, fbnativeid);

                NativeAdListener nativeAdListener = new NativeAdListener() {
                    @Override
                    public void onMediaDownloaded(Ad ad) {
                    }

                    @Override
                    public void onError(Ad ad, AdError adError) {
                        if (SharedPrefs.getFBNativeIdArry(activity) < fbnativearry.length()) {
                            new NativeAds(activity).nativeads(activity, viewGroup);
                            SharedPrefs.setFBNativeIdArry(activity, SharedPrefs.getFBNativeIdArry(activity) + 1);
                        } else {
                            AMnativeads(activity, viewGroup);
                            SharedPrefs.setFBNativeIdArry(activity, 0);
                        }
                    }

                    @Override
                    public void onAdLoaded(Ad ad) {
                        SharedPrefs.setFBNativeIdArry(activity, 0);
                        new InflatAds(activity).inflat_fb_nativr(nativeAd, viewGroup);
                    }

                    @Override
                    public void onAdClicked(Ad ad) {
                    }

                    @Override
                    public void onLoggingImpression(Ad ad) {
                    }
                };
                nativeAd.loadAd(nativeAd.buildLoadAdConfig().withAdListener(nativeAdListener).build());
            } else if (SharedPrefs.getNativeSequns(activity) == 3) {
                if (SharedPrefs.getapplovinAMFB(activity) == 1) {
                    MaxNativeAdLoader nativeAdLoader = new MaxNativeAdLoader(SharedPrefs.getALNativeId(activity), activity);
                    nativeAdLoader.setNativeAdListener(new MaxNativeAdListener() {
                        @Override
                        public void onNativeAdLoaded(final MaxNativeAdView nativeAdView, final MaxAd ad) {
                            if (nativeAd != null) {
                                nativeAdLoader.destroy(nativeAd);
                            }

                            nativeAd = ad;
                            int width = ViewGroup.LayoutParams.MATCH_PARENT;
                            int height = activity.getResources().getDimensionPixelSize(R.dimen.Native);
                            nativeAdView.setLayoutParams(new FrameLayout.LayoutParams(width, height, Gravity.BOTTOM));
                            
                            viewGroup.removeAllViews();
                            viewGroup.addView(nativeAdView);
                        }

                        @Override
                        public void onNativeAdLoadFailed(final String adUnitId, final MaxError error) {
                            AdLoader adLoader = new AdLoader.Builder(activity, nativeid).forNativeAd(nativeAd -> {
                                new InflatAds(activity).inflat_admobnative(nativeAd, viewGroup);
                                SharedPrefs.setAMNativeIdArry(activity, 0);
                            }).withAdListener(new AdListener() {
                                @Override
                                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                    if (SharedPrefs.getAMNativeIdArry(activity) < amnativearry.length()) {
                                        new NativeAds(activity).nativeads(activity, viewGroup);
                                        SharedPrefs.setAMNativeIdArry(activity, SharedPrefs.getAMNativeIdArry(activity) + 1);
                                    } else {
                                        NativeAd nativeAd = new NativeAd(activity, fbnativeid);

                                        NativeAdListener nativeAdListener = new NativeAdListener() {
                                            @Override
                                            public void onMediaDownloaded(Ad ad) {
                                            }

                                            @Override
                                            public void onError(Ad ad, AdError adError) {
                                                if (SharedPrefs.getFBNativeIdArry(activity) < fbnativearry.length()) {
                                                    new NativeAds(activity).nativeads(activity, viewGroup);
                                                    SharedPrefs.setFBNativeIdArry(activity, SharedPrefs.getFBNativeIdArry(activity) + 1);
                                                } else {
                                                    if (SharedPrefs.getqurekashow(activity) == 1) {
                                                        loadQurekaNative(activity, viewGroup);
                                                    }
                                                    SharedPrefs.setFBNativeIdArry(activity, 0);
                                                }
                                            }

                                            @Override
                                            public void onAdLoaded(Ad ad) {
                                                SharedPrefs.setFBNativeIdArry(activity, 0);
                                                new InflatAds(activity).inflat_fb_nativr(nativeAd, viewGroup);
                                            }

                                            @Override
                                            public void onAdClicked(Ad ad) {
                                            }

                                            @Override
                                            public void onLoggingImpression(Ad ad) {
                                            }
                                        };
                                        nativeAd.loadAd(nativeAd.buildLoadAdConfig().withAdListener(nativeAdListener).build());
                                        SharedPrefs.setAMNativeIdArry(activity, 0);
                                    }
                                }
                            }).withNativeAdOptions(new NativeAdOptions.Builder().build()).build();
                            adLoader.loadAd(new AdRequest.Builder().build());
                        }

                        @Override
                        public void onNativeAdClicked(final MaxAd ad) {

                        }
                    });
                    nativeAdLoader.loadAd();
                } else if (SharedPrefs.getapplovinAMFB(activity) == 2) {
                    MaxNativeAdLoader nativeAdLoader = new MaxNativeAdLoader(SharedPrefs.getALNativeId(activity), activity);
                    nativeAdLoader.setNativeAdListener(new MaxNativeAdListener() {
                        @Override
                        public void onNativeAdLoaded(final MaxNativeAdView nativeAdView, final MaxAd ad) {
                            if (nativeAd != null) {
                                nativeAdLoader.destroy(nativeAd);
                            }

                            nativeAd = ad;
                            int width = ViewGroup.LayoutParams.MATCH_PARENT;
                            int height = activity.getResources().getDimensionPixelSize(R.dimen.Native);
                            nativeAdView.setLayoutParams(new FrameLayout.LayoutParams(width, height, Gravity.BOTTOM));
                            
                            viewGroup.removeAllViews();
                            viewGroup.addView(nativeAdView);
                        }

                        @Override
                        public void onNativeAdLoadFailed(final String adUnitId, final MaxError error) {
                            NativeAd nativeAd = new NativeAd(activity, fbnativeid);

                            NativeAdListener nativeAdListener = new NativeAdListener() {
                                @Override
                                public void onMediaDownloaded(Ad ad) {
                                }

                                @Override
                                public void onError(Ad ad, AdError adError) {
                                    if (SharedPrefs.getFBNativeIdArry(activity) < fbnativearry.length()) {
                                        new NativeAds(activity).nativeads(activity, viewGroup);
                                        SharedPrefs.setFBNativeIdArry(activity, SharedPrefs.getFBNativeIdArry(activity) + 1);
                                    } else {
                                        AdLoader adLoader = new AdLoader.Builder(activity, nativeid).forNativeAd(nativeAd -> {
                                            new InflatAds(activity).inflat_admobnative(nativeAd, viewGroup);
                                            SharedPrefs.setAMNativeIdArry(activity, 0);
                                        }).withAdListener(new AdListener() {
                                            @Override
                                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                                if (SharedPrefs.getAMNativeIdArry(activity) < amnativearry.length()) {
                                                    new NativeAds(activity).nativeads(activity, viewGroup);
                                                    SharedPrefs.setAMNativeIdArry(activity, SharedPrefs.getAMNativeIdArry(activity) + 1);
                                                } else {
                                                    if (SharedPrefs.getqurekashow(activity) == 1) {
                                                        loadQurekaNative(activity, viewGroup);
                                                    }
                                                    SharedPrefs.setAMNativeIdArry(activity, 0);
                                                }
                                            }
                                        }).withNativeAdOptions(new NativeAdOptions.Builder().build()).build();
                                        adLoader.loadAd(new AdRequest.Builder().build());
                                        SharedPrefs.setFBNativeIdArry(activity, 0);
                                    }
                                }

                                @Override
                                public void onAdLoaded(Ad ad) {
                                    new InflatAds(activity).inflat_fb_nativr(nativeAd, viewGroup);
                                    SharedPrefs.setFBNativeIdArry(activity, 0);
                                }

                                @Override
                                public void onAdClicked(Ad ad) {
                                }

                                @Override
                                public void onLoggingImpression(Ad ad) {
                                }
                            };
                            nativeAd.loadAd(nativeAd.buildLoadAdConfig().withAdListener(nativeAdListener).build());
                        }

                        @Override
                        public void onNativeAdClicked(final MaxAd ad) {

                        }
                    });
                    nativeAdLoader.loadAd();
                }
            }
        } else if (SharedPrefs.getNativeSpecific(activity) == 2) {
            AMnativeads(activity, viewGroup);
        } else if (SharedPrefs.getNativeSpecific(activity) == 3) {
            FBnativeads(activity, viewGroup);
        } else if (SharedPrefs.getNativeSpecific(activity) == 4) {
            loadQurekaNative(activity, viewGroup);
        } else if (SharedPrefs.getNativeSpecific(activity) == 5) {
            applovinnative(activity, viewGroup);
        }
    }

    public void AMnativeads(Activity activity, ViewGroup viewGroup) {
        Log.d("eeee", "loadnativeads: " + nativeid);
        AdLoader adLoader = new AdLoader.Builder(activity, nativeid).forNativeAd(nativeAd -> {
            new InflatAds(activity).inflat_admobnative(nativeAd, viewGroup);
            SharedPrefs.setAMNativeIdArry(activity, 0);
        }).withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                if (SharedPrefs.getAMNativeIdArry(activity) < amnativearry.length()) {
                    new NativeAds(activity).nativeads(activity, viewGroup);
                    SharedPrefs.setAMNativeIdArry(activity, SharedPrefs.getAMNativeIdArry(activity) + 1);
                } else {
                    if (SharedPrefs.getapplovinshow(activity) == 1) {
                        applovinnative(activity, viewGroup);
                    } else if (SharedPrefs.getapplovinshow(activity) == 0) {
                        if (SharedPrefs.getqurekashow(activity) == 1) {
                            loadQurekaNative(activity, viewGroup);
                        }
                    }
                    SharedPrefs.setAMNativeIdArry(activity, 0);
                }

            }
        }).withNativeAdOptions(new NativeAdOptions.Builder().build()).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void FBnativeads(Activity activity, ViewGroup viewGroup) {
        NativeAd nativeAd = new NativeAd(activity, fbnativeid);

        NativeAdListener nativeAdListener = new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                if (SharedPrefs.getFBNativeIdArry(activity) < fbnativearry.length()) {
                    new NativeAds(activity).nativeads(activity, viewGroup);
                    SharedPrefs.setFBNativeIdArry(activity, SharedPrefs.getFBNativeIdArry(activity) + 1);
                } else {
                    if (SharedPrefs.getapplovinshow(activity) == 1) {
                        applovinnative(activity, viewGroup);
                    } else if (SharedPrefs.getapplovinshow(activity) == 0) {
                        if (SharedPrefs.getqurekashow(activity) == 1) {
                            loadQurekaNative(activity, viewGroup);
                        }
                    }
                    SharedPrefs.setFBNativeIdArry(activity, 0);
                }
            }

            @Override
            public void onAdLoaded(Ad ad) {
                SharedPrefs.setFBNativeIdArry(activity, 0);
                new InflatAds(activity).inflat_fb_nativr(nativeAd, viewGroup);
            }

            @Override
            public void onAdClicked(Ad ad) {
            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        };
        nativeAd.loadAd(nativeAd.buildLoadAdConfig().withAdListener(nativeAdListener).build());
    }

    public void loadQurekaNative(Activity activity, ViewGroup viewGroup) {
        RelativeLayout adView = (RelativeLayout) (activity).getLayoutInflater().inflate(R.layout.ads_qureka_native_ad, null);
        int[] qurekaBigBannerArray = {R.drawable.big_banner1, R.drawable.big_banner2, R.drawable.big_banner4, R.drawable.big_banner5, R.drawable.big_banner6, R.drawable.big_banner7, R.drawable.big_banner8, R.drawable.big_banner9, R.drawable.big_banner10, R.drawable.big_banner11, R.drawable.big_banner12};
        ImageView qurekaimg = adView.findViewById(R.id.qureka_native_img);
        try {
            qurekaimg.setImageResource(qurekaBigBannerArray[new Random().nextInt(qurekaBigBannerArray.length)]);
        } catch (Resources.NotFoundException e) {
            e.printStackTrace();
            qurekaimg.setImageDrawable(activity.getResources().getDrawable(R.drawable.big_banner1));
        }

        ImageView qurekalogo = adView.findViewById(R.id.vp_qurekaBannerImg);
        int[] nativearray1 = new int[]{R.drawable.mgl_square1, R.drawable.mgl_square2, R.drawable.mgl_square3, R.drawable.mgl_square4, R.drawable.mgl_square5};
        try {
            qurekalogo.setImageResource(nativearray1[new Random().nextInt(nativearray1.length)]);
        } catch (Resources.NotFoundException e) {
            e.printStackTrace();
            qurekalogo.setImageDrawable(activity.getResources().getDrawable(R.drawable.mgl_square1));
        }

        adView.findViewById(R.id.qurekanetive).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                CustomTabsIntent customTabsIntent = builder.build();
                customTabsIntent.launchUrl(activity, Uri.parse(SharedPrefs.getqurekashowurl(activity)));
            }
        });

        viewGroup.removeAllViews();
        viewGroup.addView(adView);
    }

    public void applovinnative(Activity activity, ViewGroup viewGroup) {
        MaxNativeAdLoader nativeAdLoader = new MaxNativeAdLoader(SharedPrefs.getALNativeId(activity), activity);
        nativeAdLoader.setNativeAdListener(new MaxNativeAdListener() {
            @Override
            public void onNativeAdLoaded(final MaxNativeAdView nativeAdView, final MaxAd ad) {
                if (nativeAd != null) {
                    nativeAdLoader.destroy(nativeAd);
                }

                nativeAd = ad;
                int width = ViewGroup.LayoutParams.MATCH_PARENT;
                int height = activity.getResources().getDimensionPixelSize(R.dimen.Native);
                nativeAdView.setLayoutParams(new FrameLayout.LayoutParams(width, height, Gravity.BOTTOM));
                viewGroup.removeAllViews();
                viewGroup.addView(nativeAdView);
            }

            @Override
            public void onNativeAdLoadFailed(final String adUnitId, final MaxError error) {
                if (SharedPrefs.getqurekashow(activity) == 1) {
                    loadQurekaNative(activity, viewGroup);
                }
            }

            @Override
            public void onNativeAdClicked(final MaxAd ad) {

            }
        });
        nativeAdLoader.loadAd();
    }
}
