package com.gbmashapp.statusdownloder;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import com.gbmashapp.statusdownloder.AdsDemo.InterstitialAds;
import com.gbmashapp.statusdownloder.AdsDemo.NativeAds;
import com.gbmashapp.statusdownloder.AdsDemo.RateUsDialog;
import com.gbmashapp.statusdownloder.AdsDemo.SharedPrefs;
import com.gbmashapp.statusdownloder.CateGoryOne.CateGoryOneActivity;
import com.gbmashapp.statusdownloder.CateGoryThree.CateGory_Three;
import com.gbmashapp.statusdownloder.CateGoryTwo.CateGory_Two;
import com.gbmashapp.statusdownloder.ExtraScreen.PageFive_Activity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (SharedPrefs.getAdsTextShow(this) == 1) {
            findViewById(R.id.nativead_text).setVisibility(View.VISIBLE);
        }
        if (SharedPrefs.getAdsShowleyer(this).contains("MAN")) {
            findViewById(R.id.viewlayout).setVisibility(View.VISIBLE);
        }
        new NativeAds(this).nativeads(this, findViewById(R.id.native_container));
        if (SharedPrefs.getScreen_chack(this).isEmpty()) {
            SharedPrefs.setScreen_chack(this, "6");
        }

        findViewById(R.id.btn1).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    startActivity(new Intent(MainActivity.this, CateGoryOneActivity.class));
                }
            });
        });
        findViewById(R.id.btn2).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    startActivity(new Intent(MainActivity.this, CateGory_Two.class));
                }
            });
        });
        findViewById(R.id.btn3).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    startActivity(new Intent(MainActivity.this, CateGory_Three.class));
                }
            });
        });
    }

    @Override
    public void onBackPressed() {
        if (SharedPrefs.getScreen_chack(this).equals("6")) {
            new RateUsDialog(this).ShowRateUsDialog();
        } else {
            super.onBackPressed();
        }
    }
}