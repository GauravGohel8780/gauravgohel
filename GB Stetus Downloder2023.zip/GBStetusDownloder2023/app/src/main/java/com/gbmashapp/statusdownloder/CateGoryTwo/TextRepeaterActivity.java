package com.gbmashapp.statusdownloder.CateGoryTwo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.gbmashapp.statusdownloder.AdsDemo.BannerAds;
import com.gbmashapp.statusdownloder.AdsDemo.InterstitialAds;
import com.gbmashapp.statusdownloder.AdsDemo.SharedPrefs;
import com.gbmashapp.statusdownloder.R;

public class TextRepeaterActivity extends AppCompatActivity {

    ImageView btnback;
    EditText ettext, etrepettxt;
    TextView txtrepeat;
    SwitchCompat switchbtn;
    Button btncopy, btnclear, btnshare, btnrepeat;
    String emtytxt = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text_repeater);
        if (SharedPrefs.getAdsTextShow(this) == 1) {
            findViewById(R.id.bannerad_text).setVisibility(View.VISIBLE);
        }
        if (SharedPrefs.getAdsShowleyer(this).contains("TRAB")) {
            findViewById(R.id.viewlayout).setVisibility(View.VISIBLE);
        }
        new BannerAds(this).bannerads(this, findViewById(R.id.banner_container));
        btnback = findViewById(R.id.back);
        ettext = findViewById(R.id.inputText);
        etrepettxt = findViewById(R.id.emojeeTxt);
        btnrepeat = findViewById(R.id.convertEmojeeBtn);
        txtrepeat = findViewById(R.id.convertedEmojeeTxt);
        btncopy = findViewById(R.id.copyTxtBtn);
        btnclear = findViewById(R.id.clearTxtBtn);
        btnshare = findViewById(R.id.shareTxtBtn);
        switchbtn = findViewById(R.id.btnNewLine);

        btnrepeat.setOnClickListener(view -> {
            Repeat();
            txtrepeat.setText(emtytxt);
        });

        switchbtn.setOnClickListener(view -> {
            Repeat();
        });
        btnback.setOnClickListener(view -> {
            onBackPressed();
        });

        btncopy.setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    if (txtrepeat.getText().toString().isEmpty()) {
                        Toast.makeText(TextRepeaterActivity.this, "Enter some text", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    Toast.makeText(TextRepeaterActivity.this, "Copied to clipboard!", Toast.LENGTH_SHORT).show();
                    ClipData newPlainText = ClipData.newPlainText("simple text", txtrepeat.getText().toString());
                    if (clipboardManager != null) {
                        clipboardManager.setPrimaryClip(newPlainText);
                    }
                }
            });
        });
        btnclear.setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    txtrepeat.setText("");
                }
            });

        });
        btnshare.setOnClickListener(view -> {

            if (txtrepeat.getText().toString().isEmpty()) {
                Toast.makeText(this, "Enter some text", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.TEXT", txtrepeat.getText().toString());
                this.startActivity(Intent.createChooser(intent, "choose one"));
            } catch (Exception unused) {
            }
        });
    }

    private void Repeat() {
        if (ettext.getText().toString().trim().isEmpty() || ettext.getText().toString().isEmpty()) {
            Toast.makeText(this, "Please enter any value", Toast.LENGTH_LONG).show();
            return;
        }
        if (!etrepettxt.getText().toString().equals("")) {
            int parseInt = Integer.parseInt(etrepettxt.getText().toString());
            emtytxt = "";
            for (int i = 0; i < parseInt; i++) {
                if (switchbtn.isChecked()) {
                    emtytxt += ettext.getText().toString() + "\n";
                } else {
                    emtytxt += ettext.getText().toString() + " ";
                }
            }
        }
        txtrepeat.setText(emtytxt);
    }
}