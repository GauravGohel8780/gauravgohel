package com.gbmashapp.statusdownloder.ExtraScreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import com.gbmashapp.statusdownloder.AdsDemo.InterstitialAds;
import com.gbmashapp.statusdownloder.AdsDemo.NativeAds;
import com.gbmashapp.statusdownloder.AdsDemo.RateUsDialog;
import com.gbmashapp.statusdownloder.AdsDemo.SharedPrefs;
import com.gbmashapp.statusdownloder.MainActivity;
import com.gbmashapp.statusdownloder.R;

public class PageFive_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_five);
        if (SharedPrefs.getAdsTextShow(this) == 1) {
            findViewById(R.id.nativead_text).setVisibility(View.VISIBLE);
        }
        if (SharedPrefs.getAdsShowleyer(this).contains("PFAN")) {
            findViewById(R.id.viewlayout).setVisibility(View.VISIBLE);
        }
        new NativeAds(this).nativeads(this, findViewById(R.id.native_container));
        if (SharedPrefs.getScreen_chack(this).isEmpty()) {
            SharedPrefs.setScreen_chack(this, "5");
        }

        TextView textView = (TextView) findViewById(R.id.btnstart);
        textView.setAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.right));
        findViewById(R.id.btnstart).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    startActivity(new Intent(PageFive_Activity.this, MainActivity.class));
                }
            });
        });
    }

    @Override
    public void onBackPressed() {
        if (SharedPrefs.getScreen_chack(this).equals("5")) {
            new RateUsDialog(this).ShowRateUsDialog();
        } else {
            super.onBackPressed();
        }
    }
}