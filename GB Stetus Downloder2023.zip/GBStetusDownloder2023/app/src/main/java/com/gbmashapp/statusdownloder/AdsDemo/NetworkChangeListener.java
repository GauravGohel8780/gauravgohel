package com.gbmashapp.statusdownloder.AdsDemo;

import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.gbmashapp.statusdownloder.R;

public class NetworkChangeListener extends BroadcastReceiver {

    Dialog dialog;
    TextView tv;


    @Override
    public void onReceive(Context context, Intent intent) {

        try {
            if (!isNetworkConnected(context)) {
                dialog = new Dialog(context);
                dialog.setContentView(R.layout.chack_internet_layout);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.setCancelable(false);

                if(!((Activity) context).isFinishing())
                {
                    dialog.show();
                }

                Button retry = dialog.findViewById(R.id.btntry);

                retry.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        if (isNetworkConnected(context)) {
                            dialog.dismiss();
                        }
                    }
                });
            } else if (isNetworkConnected(context)) {
                tv=dialog.findViewById(R.id.tv);
                tv.setText("internet connected Successfully");
                tv.setBackgroundResource(R.color.green);
                int colorFrom = Color.RED;
                int colorTo = Color.GREEN;
                int duration = 1000;
                ObjectAnimator.ofObject(tv, "backgroundColor", new ArgbEvaluator(), colorFrom, colorTo)
                        .setDuration(duration)
                        .start();


                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        dialog.dismiss();
                    }
                },3000);

            }
        } catch (NullPointerException e) {
            Log.i("TAG", "CommingSoonDialog: " + e);
        }
    }
    private boolean isNetworkConnected(Context context) {
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            return networkInfo != null && networkInfo.isConnected();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
