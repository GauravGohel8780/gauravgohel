package com.gbmashapp.statusdownloder.AdsDemo;


import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.gbmashapp.statusdownloder.R;

public class RateUsDialog {

    Activity activity;

    public RateUsDialog(Activity activity) {
        this.activity = activity;
    }


    public void ShowRateUsDialog() {

        Dialog exitdialog = new Dialog(activity);
        exitdialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        exitdialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        exitdialog.setContentView(R.layout.ads_rate_us_dialog);
        exitdialog.setCancelable(true);
        Window window = exitdialog.getWindow();
        WindowManager.LayoutParams attributes = window.getAttributes();
        attributes.gravity = Gravity.CENTER;
        window.setAttributes(attributes);

        if (SharedPrefs.getAdsTextShow(activity) == 1){
            exitdialog.findViewById(R.id.nativead_text).setVisibility(View.VISIBLE);
        }

        new NativeAds(activity).nativeads(activity, exitdialog.findViewById(R.id.native_container));
        exitdialog.show();

        TextView rateUsBtn = exitdialog.findViewById(R.id.rateUsBtn);
        TextView notNowBtn = exitdialog.findViewById(R.id.notNowBtn);
        ImageView btncancel = exitdialog.findViewById(R.id.btncancel);


        rateUsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + activity.getPackageName())));
                } catch (ActivityNotFoundException anfe) {
                    activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + activity.getPackageName())));
                }
            }
        });

        notNowBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.finishAffinity();
                System.exit(0);
            }
        });
        btncancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exitdialog.dismiss();
            }
        });

    }

}
