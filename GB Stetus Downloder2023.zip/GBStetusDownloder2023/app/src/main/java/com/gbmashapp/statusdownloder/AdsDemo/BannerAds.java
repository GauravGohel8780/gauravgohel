package com.gbmashapp.statusdownloder.AdsDemo;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.browser.customtabs.CustomTabsIntent;

import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdViewAdListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.ads.MaxAdView;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.gbmashapp.statusdownloder.R;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.Random;

public class BannerAds {
    Activity activity;
    public static BroadcastReceiver broadcastReceiver;

    public BannerAds(Activity activity) {
        this.activity = activity;
    }

    String bannerid, fbbannerid;
    JSONArray ambannerarry, fbbannerarry;

    public void bannerads(Activity activity, ViewGroup viewGroup) {

        if (SharedPrefs.getInternetDilog(activity).equals("yes")) {
            broadcastReceiver = new NetworkChangeListener();
            activity.registerReceiver(broadcastReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        }
        if (SharedPrefs.getADsShow(activity).equals("yes")) {
            try {
                ambannerarry = new JSONArray(SharedPrefs.getAMBannerId(activity));
                bannerid = ambannerarry.getString(SharedPrefs.getAMBannerIdArry(activity));
            } catch (JSONException e) {
                e.printStackTrace();
            }

            try {
                fbbannerarry = new JSONArray(SharedPrefs.getFBBannerId(activity));
                fbbannerid = fbbannerarry.getString(SharedPrefs.getFBBannerIdArry(activity));
            } catch (JSONException e) {
                e.printStackTrace();
            }
            loadbannerads(activity, viewGroup);
        }
    }

    public void loadbannerads(Activity activity, ViewGroup viewGroup) {
        if (SharedPrefs.getBannerSpecific(activity) == 1) {
            if (SharedPrefs.getBannerSequns(activity) == 1) {
                AdView adView = new AdView(activity);
                adView.setAdSize(AdSize.BANNER);
                adView.setAdUnitId(bannerid);

                ViewGroup currentParent = (ViewGroup) adView.getParent();
                if (currentParent != null) {
                    currentParent.removeView(adView);
                }

                AdRequest adRequest = new AdRequest.Builder().build();
                adView.loadAd(adRequest);

                adView.setAdListener(new AdListener() {
                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        super.onAdFailedToLoad(loadAdError);
                        if (SharedPrefs.getAMBannerIdArry(activity) < ambannerarry.length()) {
                            new BannerAds(activity).bannerads(activity, viewGroup);
                            SharedPrefs.setAMBannerIdArry(activity, SharedPrefs.getAMBannerIdArry(activity) + 1);
                        } else {
                            FBbannerads(activity, viewGroup);
                            SharedPrefs.setAMBannerIdArry(activity, 0);
                        }
                    }

                    @Override
                    public void onAdLoaded() {
                        super.onAdLoaded();
                        SharedPrefs.setAMBannerIdArry(activity, 0);
                        if (adView.getParent() != null) {
                            ((ViewGroup) adView.getParent()).removeAllViews();
                        }
                        viewGroup.removeAllViews();
                        viewGroup.addView(adView);
                    }
                });
            }
            else if (SharedPrefs.getBannerSequns(activity) == 2) {
                com.facebook.ads.AdListener adListener = new com.facebook.ads.AdListener() {
                    @Override
                    public void onError(Ad ad, AdError adError) {
                        if (SharedPrefs.getFBBannerIdArry(activity) < fbbannerarry.length()) {
                            new BannerAds(activity).bannerads(activity, viewGroup);
                            SharedPrefs.setFBBannerIdArry(activity, SharedPrefs.getFBBannerIdArry(activity) + 1);
                        } else {
                            AMbannerads(activity, viewGroup);
                            SharedPrefs.setFBBannerIdArry(activity, 0);
                        }
                    }

                    @Override
                    public void onAdLoaded(Ad ad) {
                        SharedPrefs.setFBBannerIdArry(activity, 0);
                    }

                    @Override
                    public void onAdClicked(Ad ad) {

                    }

                    @Override
                    public void onLoggingImpression(Ad ad) {

                    }
                };
                com.facebook.ads.AdView adView = new com.facebook.ads.AdView(activity, fbbannerid, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
                viewGroup.removeAllViews();
                viewGroup.addView(adView);
                adView.loadAd(adView.buildLoadAdConfig().withAdListener(adListener).build());
            } else if (SharedPrefs.getBannerSequns(activity) == 3) {
                if (SharedPrefs.getapplovinAMFB(activity) == 1) {
                    MaxAdView adView = new MaxAdView(SharedPrefs.getALBannerId(activity), activity);
                    adView.setListener(new MaxAdViewAdListener() {
                        @Override
                        public void onAdExpanded(MaxAd ad) {

                        }

                        @Override
                        public void onAdCollapsed(MaxAd ad) {

                        }

                        @Override
                        public void onAdLoaded(MaxAd ad) {

                        }

                        @Override
                        public void onAdDisplayed(MaxAd ad) {

                        }

                        @Override
                        public void onAdHidden(MaxAd ad) {

                        }

                        @Override
                        public void onAdClicked(MaxAd ad) {

                        }

                        @Override
                        public void onAdLoadFailed(String adUnitId, MaxError error) {
                            AdView adView = new AdView(activity);
                            adView.setAdSize(AdSize.BANNER);
                            adView.setAdUnitId(bannerid);

                            ViewGroup currentParent = (ViewGroup) adView.getParent();
                            if (currentParent != null) {
                                currentParent.removeView(adView);
                            }

                            AdRequest adRequest = new AdRequest.Builder().build();
                            adView.loadAd(adRequest);

                            adView.setAdListener(new AdListener() {
                                @Override
                                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                    super.onAdFailedToLoad(loadAdError);
                                    if (SharedPrefs.getAMBannerIdArry(activity) < ambannerarry.length()) {
                                        new BannerAds(activity).bannerads(activity, viewGroup);
                                        SharedPrefs.setAMBannerIdArry(activity, SharedPrefs.getAMBannerIdArry(activity) + 1);
                                    } else {
                                        com.facebook.ads.AdListener adListener = new com.facebook.ads.AdListener() {
                                            @Override
                                            public void onError(Ad ad, AdError adError) {
                                                if (SharedPrefs.getFBBannerIdArry(activity) < fbbannerarry.length()) {
                                                    new BannerAds(activity).bannerads(activity, viewGroup);
                                                    SharedPrefs.setFBBannerIdArry(activity, SharedPrefs.getFBBannerIdArry(activity) + 1);
                                                } else {
                                                    if (SharedPrefs.getqurekashow(activity) == 1) {
                                                        loadQurekaBanner(activity, viewGroup);
                                                    }
                                                    SharedPrefs.setFBBannerIdArry(activity, 0);
                                                }
                                            }

                                            @Override
                                            public void onAdLoaded(Ad ad) {
                                                SharedPrefs.setFBBannerIdArry(activity, 0);
                                            }

                                            @Override
                                            public void onAdClicked(Ad ad) {

                                            }

                                            @Override
                                            public void onLoggingImpression(Ad ad) {

                                            }
                                        };
                                        com.facebook.ads.AdView adView = new com.facebook.ads.AdView(activity, fbbannerid, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
                                        viewGroup.removeAllViews();
                                        viewGroup.addView(adView);
                                        adView.loadAd(adView.buildLoadAdConfig().withAdListener(adListener).build());
                                        SharedPrefs.setAMBannerIdArry(activity, 0);
                                    }
                                }

                                @Override
                                public void onAdLoaded() {
                                    super.onAdLoaded();
                                    SharedPrefs.setAMBannerIdArry(activity, 0);
                                    if (adView.getParent() != null) {
                                        ((ViewGroup) adView.getParent()).removeAllViews();
                                    }
                                    viewGroup.removeAllViews();
                                    viewGroup.addView(adView);
                                }
                            });
                        }

                        @Override
                        public void onAdDisplayFailed(MaxAd ad, MaxError error) {

                        }
                    });

                    int width = ViewGroup.LayoutParams.MATCH_PARENT;
                    int height = activity.getResources().getDimensionPixelSize(R.dimen.banner_height);
                    adView.setLayoutParams(new FrameLayout.LayoutParams(width, height, Gravity.BOTTOM));
                    viewGroup.addView(adView);
                    adView.loadAd();
                } else if (SharedPrefs.getapplovinAMFB(activity) == 2) {
                    MaxAdView adView = new MaxAdView(SharedPrefs.getALBannerId(activity), activity);
                    adView.setListener(new MaxAdViewAdListener() {
                        @Override
                        public void onAdExpanded(MaxAd ad) {

                        }

                        @Override
                        public void onAdCollapsed(MaxAd ad) {

                        }

                        @Override
                        public void onAdLoaded(MaxAd ad) {

                        }

                        @Override
                        public void onAdDisplayed(MaxAd ad) {

                        }

                        @Override
                        public void onAdHidden(MaxAd ad) {

                        }

                        @Override
                        public void onAdClicked(MaxAd ad) {

                        }

                        @Override
                        public void onAdLoadFailed(String adUnitId, MaxError error) {
                            com.facebook.ads.AdListener adListener = new com.facebook.ads.AdListener() {
                                @Override
                                public void onError(Ad ad, AdError adError) {
                                    if (SharedPrefs.getFBBannerIdArry(activity) < fbbannerarry.length()) {
                                        new BannerAds(activity).bannerads(activity, viewGroup);
                                        SharedPrefs.setFBBannerIdArry(activity, SharedPrefs.getFBBannerIdArry(activity) + 1);
                                    } else {
                                        AdView adView = new AdView(activity);
                                        adView.setAdSize(AdSize.BANNER);
                                        adView.setAdUnitId(bannerid);

                                        ViewGroup currentParent = (ViewGroup) adView.getParent();
                                        if (currentParent != null) {
                                            currentParent.removeView(adView);
                                        }

                                        AdRequest adRequest = new AdRequest.Builder().build();
                                        adView.loadAd(adRequest);

                                        adView.setAdListener(new AdListener() {
                                            @Override
                                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                                super.onAdFailedToLoad(loadAdError);
                                                if (SharedPrefs.getAMBannerIdArry(activity) < ambannerarry.length()) {
                                                    new BannerAds(activity).bannerads(activity, viewGroup);
                                                    SharedPrefs.setAMBannerIdArry(activity, SharedPrefs.getAMBannerIdArry(activity) + 1);
                                                } else {
                                                    if (SharedPrefs.getqurekashow(activity) == 1) {
                                                        loadQurekaBanner(activity, viewGroup);
                                                    }
                                                    SharedPrefs.setAMBannerIdArry(activity, 0);
                                                }
                                            }

                                            @Override
                                            public void onAdLoaded() {
                                                super.onAdLoaded();
                                                SharedPrefs.setAMBannerIdArry(activity, 0);
                                                if (adView.getParent() != null) {
                                                    ((ViewGroup) adView.getParent()).removeAllViews();
                                                }
                                                viewGroup.removeAllViews();
                                                viewGroup.addView(adView);
                                            }
                                        });
                                        SharedPrefs.setFBBannerIdArry(activity, 0);
                                    }
                                }

                                @Override
                                public void onAdLoaded(Ad ad) {
                                    SharedPrefs.setFBBannerIdArry(activity, 0);
                                }

                                @Override
                                public void onAdClicked(Ad ad) {

                                }

                                @Override
                                public void onLoggingImpression(Ad ad) {

                                }
                            };
                            com.facebook.ads.AdView adView = new com.facebook.ads.AdView(activity, fbbannerid, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
                            viewGroup.removeAllViews();
                            viewGroup.addView(adView);
                            adView.loadAd(adView.buildLoadAdConfig().withAdListener(adListener).build());
                        }

                        @Override
                        public void onAdDisplayFailed(MaxAd ad, MaxError error) {

                        }
                    });

                    int width = ViewGroup.LayoutParams.MATCH_PARENT;
                    int height = activity.getResources().getDimensionPixelSize(R.dimen.banner_height);
                    adView.setLayoutParams(new FrameLayout.LayoutParams(width, height, Gravity.BOTTOM));
                    viewGroup.addView(adView);
                    adView.loadAd();
                }
            }
        } else if (SharedPrefs.getBannerSpecific(activity) == 2) {
            AMbannerads(activity, viewGroup);
        } else if (SharedPrefs.getBannerSpecific(activity) == 3) {
            FBbannerads(activity, viewGroup);
        } else if (SharedPrefs.getBannerSpecific(activity) == 4) {
            loadQurekaBanner(activity, viewGroup);
        } else if (SharedPrefs.getBannerSpecific(activity) == 5) {
            applovinbanner(activity, viewGroup);
        }
    }

    public void AMbannerads(Activity activity, ViewGroup viewGroup) {
        AdView adView = new AdView(activity);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId(bannerid);

        ViewGroup currentParent = (ViewGroup) adView.getParent();
        if (currentParent != null) {
            currentParent.removeView(adView);
        }

        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        adView.setAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                if (SharedPrefs.getAMBannerIdArry(activity) < ambannerarry.length()) {
                    new BannerAds(activity).bannerads(activity, viewGroup);
                    SharedPrefs.setAMBannerIdArry(activity, SharedPrefs.getAMBannerIdArry(activity) + 1);
                } else {
                    if (SharedPrefs.getapplovinshow(activity) == 1) {
                        applovinbanner(activity, viewGroup);
                    } else if (SharedPrefs.getapplovinshow(activity) == 0) {
                        if (SharedPrefs.getqurekashow(activity) == 1) {
                            loadQurekaBanner(activity, viewGroup);
                        }
                    }
                    SharedPrefs.setAMBannerIdArry(activity, 0);
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                SharedPrefs.setAMBannerIdArry(activity, 0);
                if (adView.getParent() != null) {
                    ((ViewGroup) adView.getParent()).removeAllViews();
                }
                viewGroup.removeAllViews();
                viewGroup.addView(adView);
            }
        });
    }

    public void FBbannerads(Activity activity, ViewGroup viewGroup) {
        com.facebook.ads.AdListener adListener = new com.facebook.ads.AdListener() {
            @Override
            public void onError(Ad ad, AdError adError) {
                if (SharedPrefs.getFBBannerIdArry(activity) < fbbannerarry.length()) {
                    new BannerAds(activity).bannerads(activity, viewGroup);
                    SharedPrefs.setFBBannerIdArry(activity, SharedPrefs.getFBBannerIdArry(activity) + 1);
                } else {
                    if (SharedPrefs.getapplovinshow(activity) == 1) {
                        applovinbanner(activity, viewGroup);
                    } else if (SharedPrefs.getapplovinshow(activity) == 0) {
                        if (SharedPrefs.getqurekashow(activity) == 1) {
                            loadQurekaBanner(activity, viewGroup);
                        }
                    }
                    SharedPrefs.setFBBannerIdArry(activity, 0);
                }
            }

            @Override
            public void onAdLoaded(Ad ad) {
                SharedPrefs.setFBBannerIdArry(activity, 0);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        };
        com.facebook.ads.AdView adView = new com.facebook.ads.AdView(activity, fbbannerid, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
        viewGroup.removeAllViews();
        viewGroup.addView(adView);
        adView.loadAd(adView.buildLoadAdConfig().withAdListener(adListener).build());
    }


    public void loadQurekaBanner(Activity activity, ViewGroup viewGroup) {
        RelativeLayout adView = (RelativeLayout) (activity).getLayoutInflater().inflate(R.layout.ads_qureka_banner_ad, null);
        ImageView qurekalogo = adView.findViewById(R.id.vp_qurekaBannerImg);
        int[] nativearray1 = new int[]{R.drawable.mgl_square1, R.drawable.mgl_square2, R.drawable.mgl_square3, R.drawable.mgl_square4, R.drawable.mgl_square5};
        try {
            qurekalogo.setImageResource(nativearray1[new Random().nextInt(nativearray1.length)]);
        } catch (Resources.NotFoundException e) {
            e.printStackTrace();
            qurekalogo.setImageDrawable(activity.getResources().getDrawable(R.drawable.mgl_square1));
        }
        adView.findViewById(R.id.qurekabanner).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                CustomTabsIntent customTabsIntent = builder.build();
                customTabsIntent.launchUrl(activity, Uri.parse(SharedPrefs.getqurekashowurl(activity)));
            }
        });

        viewGroup.removeAllViews();
        viewGroup.addView(adView);
    }

    public void applovinbanner(Activity activity, ViewGroup viewGroup) {
        MaxAdView adView = new MaxAdView(SharedPrefs.getALBannerId(activity), activity);
        adView.setListener(new MaxAdViewAdListener() {
            @Override
            public void onAdExpanded(MaxAd ad) {

            }

            @Override
            public void onAdCollapsed(MaxAd ad) {

            }

            @Override
            public void onAdLoaded(MaxAd ad) {

            }

            @Override
            public void onAdDisplayed(MaxAd ad) {

            }

            @Override
            public void onAdHidden(MaxAd ad) {

            }

            @Override
            public void onAdClicked(MaxAd ad) {

            }

            @Override
            public void onAdLoadFailed(String adUnitId, MaxError error) {
                if (SharedPrefs.getqurekashow(activity) == 1) {
                    loadQurekaBanner(activity, viewGroup);
                }
            }

            @Override
            public void onAdDisplayFailed(MaxAd ad, MaxError error) {

            }
        });

        int width = ViewGroup.LayoutParams.MATCH_PARENT;
        int height = activity.getResources().getDimensionPixelSize(R.dimen.banner_height);
        adView.setLayoutParams(new FrameLayout.LayoutParams(width, height, Gravity.BOTTOM));
        viewGroup.addView(adView);
        adView.loadAd();
    }
}
