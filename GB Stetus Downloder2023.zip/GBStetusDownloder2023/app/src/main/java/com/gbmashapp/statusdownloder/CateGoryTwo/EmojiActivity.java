package com.gbmashapp.statusdownloder.CateGoryTwo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.View;

import com.gbmashapp.statusdownloder.AdsDemo.BannerAds;
import com.gbmashapp.statusdownloder.AdsDemo.SharedPrefs;
import com.gbmashapp.statusdownloder.R;
import com.google.android.material.tabs.TabLayout;

public class EmojiActivity extends AppCompatActivity {

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private MyPagerAdapter pagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emoji);
        if (SharedPrefs.getAdsTextShow(this) == 1) {
            findViewById(R.id.bannerad_text).setVisibility(View.VISIBLE);
        }
        if (SharedPrefs.getAdsShowleyer(this).contains("EAB")) {
            findViewById(R.id.viewlayout).setVisibility(View.VISIBLE);
        }
        new BannerAds(this).bannerads(this, findViewById(R.id.banner_container));
        findViewById(R.id.back).setOnClickListener(view -> {
            onBackPressed();
        });
        tabLayout = findViewById(R.id.tabs);
        viewPager = findViewById(R.id.viewpager);
        pagerAdapter = new MyPagerAdapter(getSupportFragmentManager());

        viewPager.setAdapter(pagerAdapter);
        tabLayout.setupWithViewPager(viewPager);
    }
    private class MyPagerAdapter extends FragmentPagerAdapter {

        private String[] tabTitles = {"HAPPY", "ANGRY", "OTHER"};

        public MyPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case 0:
                    return new HappyFragment();
                case 1:
                    return new AngryFragment();
                case 2:
                    return new OtherFragment();
                default:
                    return null;
            }
        }

        @Override
        public int getCount() {
            return tabTitles.length;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return tabTitles[position];
        }
    }
}