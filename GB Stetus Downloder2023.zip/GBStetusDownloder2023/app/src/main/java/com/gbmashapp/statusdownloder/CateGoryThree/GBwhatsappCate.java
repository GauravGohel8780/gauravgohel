package com.gbmashapp.statusdownloder.CateGoryThree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.gbmashapp.statusdownloder.AdsDemo.InterstitialAds;
import com.gbmashapp.statusdownloder.AdsDemo.NativeAds;
import com.gbmashapp.statusdownloder.AdsDemo.SharedPrefs;
import com.gbmashapp.statusdownloder.R;

public class GBwhatsappCate extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gbwhatsapp_cate);
        if (SharedPrefs.getAdsTextShow(this) == 1) {
            findViewById(R.id.nativead_text).setVisibility(View.VISIBLE);
        }
        if (SharedPrefs.getAdsShowleyer(this).contains("GWACN")) {
            findViewById(R.id.viewlayout).setVisibility(View.VISIBLE);
        }
        new NativeAds(this).nativeads(this, findViewById(R.id.native_container));

        findViewById(R.id.back).setOnClickListener(view -> {
            onBackPressed();
        });

        findViewById(R.id.b1).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    Intent intent = new Intent(GBwhatsappCate.this, GB_DataActivity.class);
                    intent.putExtra("data", "b1");
                    startActivity(intent);
                }
            });

        });
        findViewById(R.id.b2).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    Intent intent = new Intent(GBwhatsappCate.this, GB_DataActivity.class);
                    intent.putExtra("data", "b2");
                    startActivity(intent);
                }
            });
        });
        findViewById(R.id.b3).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    Intent intent = new Intent(GBwhatsappCate.this, GB_DataActivity.class);
                    intent.putExtra("data", "b3");
                    startActivity(intent);
                }
            });
        });
        findViewById(R.id.b4).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    Intent intent = new Intent(GBwhatsappCate.this, GB_DataActivity.class);
                    intent.putExtra("data", "b4");
                    startActivity(intent);
                }
            });
        });
        findViewById(R.id.b5).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    Intent intent = new Intent(GBwhatsappCate.this, GB_DataActivity.class);
                    intent.putExtra("data", "b5");
                    startActivity(intent);
                }
            });
        });
        findViewById(R.id.b6).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    Intent intent = new Intent(GBwhatsappCate.this, GB_DataActivity.class);
                    intent.putExtra("data", "b6");
                    startActivity(intent);
                }
            });
        });
        findViewById(R.id.b7).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    Intent intent = new Intent(GBwhatsappCate.this, GB_DataActivity.class);
                    intent.putExtra("data", "b7");
                    startActivity(intent);
                }
            });
        });
        findViewById(R.id.b8).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    Intent intent = new Intent(GBwhatsappCate.this, GB_DataActivity.class);
                    intent.putExtra("data", "b8");
                    startActivity(intent);
                }
            });
        });
        findViewById(R.id.b9).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    Intent intent = new Intent(GBwhatsappCate.this, GB_DataActivity.class);
                    intent.putExtra("data", "b9");
                    startActivity(intent);
                }
            });
        });
    }
}