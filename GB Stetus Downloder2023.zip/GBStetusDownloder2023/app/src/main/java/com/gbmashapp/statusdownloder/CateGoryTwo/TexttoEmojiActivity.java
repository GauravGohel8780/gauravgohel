package com.gbmashapp.statusdownloder.CateGoryTwo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.gbmashapp.statusdownloder.AdsDemo.BannerAds;
import com.gbmashapp.statusdownloder.AdsDemo.InterstitialAds;
import com.gbmashapp.statusdownloder.AdsDemo.SharedPrefs;
import com.gbmashapp.statusdownloder.R;

import java.io.IOException;
import java.io.InputStream;

public class TexttoEmojiActivity extends AppCompatActivity {

    EditText ettextemoji, etemoji;
    TextView  txtemoji ;
    Button btncopy, btnclear,btnshare,transform;
    ImageView btnback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_textto_emoji);
        if (SharedPrefs.getAdsTextShow(this) == 1) {
            findViewById(R.id.bannerad_text).setVisibility(View.VISIBLE);
        }
        if (SharedPrefs.getAdsShowleyer(this).contains("TEAB")) {
            findViewById(R.id.viewlayout).setVisibility(View.VISIBLE);
        }
        new BannerAds(this).bannerads(this, findViewById(R.id.banner_container));
        ettextemoji = findViewById(R.id.inputText);
        etemoji = findViewById(R.id.emojeeTxt);
        transform = findViewById(R.id.convertEmojeeBtn);
        txtemoji = findViewById(R.id.convertedEmojeeTxt);
        btncopy = findViewById(R.id.copyTxtBtn);
        btnclear = findViewById(R.id.clearTxtBtn);
        btnshare = findViewById(R.id.shareTxtBtn);
        btnback = findViewById(R.id.back);

        transform.setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {

                    if (ettextemoji.getText().toString().isEmpty()) {
                        Toast.makeText(getApplicationContext(), "Enter text", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    char[] charArray = ettextemoji.getText().toString().toCharArray();
                    txtemoji.setText("\n");
                    for (char emoji : charArray) {
                        if (emoji == '?') {
                            try {
                                InputStream open = getBaseContext().getAssets().open("ques.txt");
                                byte[] bArr = new byte[open.available()];
                                open.read(bArr);
                                open.close();
                                String replaceAll = new String(bArr).replaceAll("[*]", etemoji.getText().toString());
                                txtemoji.append(replaceAll + "\n\n");
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        } else if (emoji == ((char) (emoji & '_')) || Character.isDigit(emoji)) {
                            try {
                                InputStream openimjo = getBaseContext().getAssets().open(emoji + ".txt");
                                byte[] bArr2 = new byte[openimjo.available()];
                                openimjo.read(bArr2);
                                openimjo.close();
                                String replaceAll2 = new String(bArr2).replaceAll("[*]", etemoji.getText().toString());
                                txtemoji.append(replaceAll2 + "\n\n");
                            } catch (IOException e2) {
                                e2.printStackTrace();
                            }
                        } else {
                            try {
                                InputStream open3 = getBaseContext().getAssets().open("low" + emoji + ".txt");
                                byte[] bArr3 = new byte[open3.available()];
                                open3.read(bArr3);
                                open3.close();
                                String replaceAll3 = new String(bArr3).replaceAll("[*]", etemoji.getText().toString());
                                txtemoji.append(replaceAll3 + "\n\n");
                            } catch (IOException e3) {
                                e3.printStackTrace();
                            }
                        }
                    }
                }
            });
        });

        btncopy.setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    if (txtemoji.getText().toString().isEmpty()) {
                        Toast.makeText(TexttoEmojiActivity.this, "Enter some text", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    Toast.makeText(TexttoEmojiActivity.this, "Copied to clipboard!", Toast.LENGTH_SHORT).show();
                    ClipData newPlainText = ClipData.newPlainText("simple text", txtemoji.getText().toString());
                    if (clipboardManager != null) {
                        clipboardManager.setPrimaryClip(newPlainText);
                    }
                }
            });
        });
        btnclear.setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    txtemoji.setText("");
                }
            });

        });
        btnback.setOnClickListener(view -> {
            onBackPressed();
        });
        btnshare.setOnClickListener(view -> {
            if (txtemoji.getText().toString().isEmpty()) {
                Toast.makeText(this, "Enter some text", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.TEXT", txtemoji.getText().toString());
                this.startActivity(Intent.createChooser(intent, "choose one"));
            } catch (Exception unused) {
            }
        });
    }
}