package com.gbmashapp.statusdownloder.CateGoryOne.stetussaver;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.UriPermission;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StrictMode;
import android.os.storage.StorageManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.gbmashapp.statusdownloder.R;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Executors;

public class WhatsappImageFragment extends Fragment {
    private RecyclerView recyclerView;
    private List<Status> imagesList = new ArrayList<>();

    private ImageAdapter imageAdapter;
    private RelativeLayout container;
    private TextView messageTextView;
    LinearLayout sAccessBtn;
    SwipeRefreshLayout swiperefresh;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup viewGroup,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_whatsapp_image, container, false);



        recyclerView = view.findViewById(R.id.recyclerViewImage);
        container = view.findViewById(R.id.image_container);
        messageTextView = view.findViewById(R.id.messageTextImage);
        swiperefresh = view.findViewById(R.id.swiperefresh);

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), Common.GRID_COUNT));

        sAccessBtn = view.findViewById(R.id.sAccessBtn);
        if (!SharedPrefs.getWATree(getActivity()).equals("")) {
            getStatus();
            sAccessBtn.setVisibility(View.GONE);
        }
        swiperefresh.setOnRefreshListener(() -> {
            if (!SharedPrefs.getWATree(getActivity()).equals("")) {
                getStatus();
                sAccessBtn.setVisibility(View.GONE);
            }
            swiperefresh.setRefreshing(false);
        });


        sAccessBtn.setOnClickListener(v -> {
            if (appInstalledOrNot(getActivity(), "com.whatsapp")) {

                StorageManager sm = (StorageManager) getActivity().getSystemService(Context.STORAGE_SERVICE);

                String statusDir = getWhatsupFolder();
                Intent intent = null;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    intent = sm.getPrimaryStorageVolume().createOpenDocumentTreeIntent();
                    Uri uri = intent.getParcelableExtra("android.provider.extra.INITIAL_URI");

                    String scheme = uri.toString();

                    scheme = scheme.replace("/root/", "/document/");

                    scheme += "%3A" + statusDir;

                    uri = Uri.parse(scheme);

                    intent.putExtra("android.provider.extra.INITIAL_URI", uri);
                } else {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    intent.putExtra("android.provider.extra.INITIAL_URI", Uri.parse("content://com.android.externalstorage.documents/document/primary%3A" + statusDir));
                }


                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intent.addFlags(Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);

                startActivityForResult(intent, 101);

            } else {
                Toast.makeText(getActivity(), "Please Install WhatsApp For Download Status!!!!!", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

    public String getWhatsupFolder() {
        if (new File(Environment.getExternalStorageDirectory() + File.separator + "Android/media/com.whatsapp/WhatsApp" + File.separator + "Media" + File.separator + ".Statuses").isDirectory()) {
            return "Android%2Fmedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F.Statuses";
        } else {
            return "WhatsApp%2FMedia%2F.Statuses";
        }
    }

    public void getStatus() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

            executeNew();

        } else if (Common.STATUS_DIRECTORY.exists()) {

            executeOld();

        } else {
            messageTextView.setVisibility(View.VISIBLE);
            messageTextView.setText("Cant find WhatsApp Dir");
            Toast.makeText(getActivity(), "Cant find WhatsApp Dir", Toast.LENGTH_SHORT).show();
        }

    }

    private void executeOld() {

        Executors.newSingleThreadExecutor().execute(() -> {

            Handler mainHandler = new Handler(Looper.getMainLooper());

            File[] statusFiles;
            statusFiles = Common.STATUS_DIRECTORY.listFiles();
            imagesList.clear();

            if (statusFiles != null && statusFiles.length > 0) {

                Arrays.sort(statusFiles);
                for (File file : statusFiles) {

                    if (file.getName().contains(".nomedia"))
                        continue;

                    Status status = new Status(file, file.getName(), file.getAbsolutePath());

                    if (!status.isVideo() && status.getTitle().endsWith(".jpg")) {
                        imagesList.add(status);
                    }

                }

                mainHandler.post(() -> {

                    if (imagesList.size() <= 0) {
                        messageTextView.setVisibility(View.VISIBLE);
                        messageTextView.setText("No Files Found");
                    } else {
                        messageTextView.setVisibility(View.GONE);
                        messageTextView.setText("");
                    }

                    imageAdapter = new ImageAdapter(imagesList, container);
                    recyclerView.setAdapter(imageAdapter);
                    imageAdapter.notifyItemRangeChanged(0, imagesList.size());
                });

            } else {

                mainHandler.post(() -> {
                    messageTextView.setVisibility(View.VISIBLE);
                    messageTextView.setText("No Files Found");
                    Toast.makeText(getActivity(), "No Files Found", Toast.LENGTH_SHORT).show();
                });

            }

        });
    }

    private void executeNew() {
        try {
            Executors.newSingleThreadExecutor().execute(() -> {
                Handler mainHandler = new Handler(Looper.getMainLooper());

                List<UriPermission> list = getActivity().getContentResolver().getPersistedUriPermissions();

                DocumentFile file = DocumentFile.fromTreeUri(getActivity(), list.get(0).getUri());


                imagesList.clear();

                if (file == null) {
                    mainHandler.post(() -> {
                        messageTextView.setVisibility(View.VISIBLE);
                        messageTextView.setText("No Files Found");
                        Toast.makeText(getActivity(), "No Files Found", Toast.LENGTH_SHORT).show();
                    });
                    return;
                }

                DocumentFile[] statusFiles = file.listFiles();

                if (statusFiles.length <= 0) {
                    mainHandler.post(() -> {
                        messageTextView.setVisibility(View.VISIBLE);
                        messageTextView.setText("No Files Found");
                        Toast.makeText(getActivity(), "No Files Found", Toast.LENGTH_SHORT).show();
                    });
                    return;
                }

                for (DocumentFile documentFile : statusFiles) {

                    if (Objects.requireNonNull(documentFile.getName()).contains(".nomedia"))
                        continue;

                    Status status = new Status(documentFile);

                    if (!status.isVideo()) {
                        imagesList.add(status);
                    }
                }

                mainHandler.post(() -> {
                    if (imagesList.size() <= 0) {
                        messageTextView.setVisibility(View.VISIBLE);
                        messageTextView.setText("No Files Found");
                    } else {
                        messageTextView.setVisibility(View.GONE);
                        messageTextView.setText("");
                    }

                    imageAdapter = new ImageAdapter(imagesList, container);
                    recyclerView.setAdapter(imageAdapter);
                    imageAdapter.notifyItemRangeChanged(0, imagesList.size());
                });

            });
        } catch (IndexOutOfBoundsException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 101 && resultCode == Activity.RESULT_OK) {
            Uri uri = data.getData();
            Log.e("onActivityResult: ", "" + data.getData());
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    getActivity().getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            SharedPrefs.setWATree(getActivity(), uri.toString());

            if (!SharedPrefs.getWATree(getActivity()).equals("")) {
                getStatus();
                sAccessBtn.setVisibility(View.GONE);
            }
        }
    }

    public static boolean appInstalledOrNot(Context context, String uri) {
        PackageManager pm = context.getPackageManager();
        try {
            pm.getPackageInfo(uri, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
}
