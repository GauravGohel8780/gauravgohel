package com.gbmashapp.statusdownloder.ExtraScreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import com.gbmashapp.statusdownloder.AdsDemo.InterstitialAds;
import com.gbmashapp.statusdownloder.AdsDemo.NativeAds;
import com.gbmashapp.statusdownloder.AdsDemo.RateUsDialog;
import com.gbmashapp.statusdownloder.AdsDemo.SharedPrefs;
import com.gbmashapp.statusdownloder.MainActivity;
import com.gbmashapp.statusdownloder.R;

public class PageFourr_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_fourr);
        if (SharedPrefs.getAdsTextShow(this) == 1) {
            findViewById(R.id.nativead_text).setVisibility(View.VISIBLE);
        }
        if (SharedPrefs.getAdsShowleyer(this).contains("PFAN")) {
            findViewById(R.id.viewlayout).setVisibility(View.VISIBLE);
        }
        new NativeAds(this).nativeads(this, findViewById(R.id.native_container));
        if (SharedPrefs.getScreen_chack(this).isEmpty()) {
            SharedPrefs.setScreen_chack(this, "4");
        }

        TextView textView = (TextView) findViewById(R.id.btnstart);
        textView.setAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.right));
        findViewById(R.id.btnstart).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    if (SharedPrefs.getusersequence(PageFourr_Activity.this).equals("1")) {
                        Intent intent = new Intent(PageFourr_Activity.this, PageFive_Activity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    } else {
                        if (SharedPrefs.getextraPageShow(PageFourr_Activity.this).contains("5")) {
                            Intent intent = new Intent(PageFourr_Activity.this, PageFive_Activity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        } else if (SharedPrefs.getextraPageShow(PageFourr_Activity.this).contains("6")) {
                            Intent intent = new Intent(PageFourr_Activity.this, MainActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        } else {
                            Intent intent = new Intent(PageFourr_Activity.this, MainActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        }
                    }
                }
            });
        });
    }

    @Override
    public void onBackPressed() {
        if (SharedPrefs.getScreen_chack(this).equals("4")) {
            new RateUsDialog(this).ShowRateUsDialog();
        } else {
            super.onBackPressed();
        }
    }
}