package com.gbmashapp.statusdownloder.CateGoryTwo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.gbmashapp.statusdownloder.AdsDemo.BannerAds;
import com.gbmashapp.statusdownloder.AdsDemo.InterstitialAds;
import com.gbmashapp.statusdownloder.AdsDemo.SharedPrefs;
import com.gbmashapp.statusdownloder.R;

public class CaptionitemActivity extends AppCompatActivity {
    RecyclerView recyclerView;

    public String[] f11217AUK ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_captionitem);
        if (SharedPrefs.getAdsTextShow(this) == 1) {
            findViewById(R.id.bannerad_text).setVisibility(View.VISIBLE);
        }
        if (SharedPrefs.getAdsShowleyer(this).contains("CIAB")) {
            findViewById(R.id.viewlayout).setVisibility(View.VISIBLE);
        }
        new BannerAds(this).bannerads(this, findViewById(R.id.banner_container));
        findViewById(R.id.back).setOnClickListener(view -> {
            onBackPressed();
        });
        recyclerView = findViewById(R.id.captionitemrecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        int intExtra = getIntent().getIntExtra("P", 0);
        if (intExtra == 0) {
            this.f11217AUK = getResources().getStringArray(R.array.s_best);
        } else if (intExtra == 1) {
            this.f11217AUK = getResources().getStringArray(R.array.s_clever);
        } else if (intExtra == 2) {
            this.f11217AUK = getResources().getStringArray(R.array.s_cool);
        } else if (intExtra == 3) {
            this.f11217AUK = getResources().getStringArray(R.array.s_cute);
        } else if (intExtra == 4) {
            this.f11217AUK = getResources().getStringArray(R.array.s_fitness);
        } else if (intExtra == 5) {
            this.f11217AUK = getResources().getStringArray(R.array.s_funny);
        } else if (intExtra == 6) {
            this.f11217AUK = getResources().getStringArray(R.array.s_life);
        } else if (intExtra == 7) {
            this.f11217AUK = getResources().getStringArray(R.array.s_love);
        } else if (intExtra == 8) {
            this.f11217AUK = getResources().getStringArray(R.array.s_motivation);
        } else if (intExtra == 9) {
            this.f11217AUK = getResources().getStringArray(R.array.s_sad);
        } else if (intExtra == 10) {
            this.f11217AUK = getResources().getStringArray(R.array.s_savage);
        } else if (intExtra == 11) {
            this.f11217AUK = getResources().getStringArray(R.array.s_selfie);
        } else if (intExtra == 12) {
            this.f11217AUK = getResources().getStringArray(R.array.s_song);
        }
        MyAdapter adapter = new MyAdapter(f11217AUK);
        recyclerView.setAdapter(adapter);
    }
    private static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        ImageView whats, copy_button;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            textView = itemView.findViewById(R.id.textView);
            whats = itemView.findViewById(R.id.whats);
            copy_button = itemView.findViewById(R.id.copy_button);
        }
    }

    // Create an Adapter for the RecyclerView
    private class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {
        private String[] data;

        MyAdapter(String[] data) {
            this.data = data;
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.cation_deteail_layout, parent, false);
            return new MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(MyViewHolder holder, int position) {
            holder.textView.setText(data[position]);
            holder.whats.setOnClickListener(view -> {
                shareToWhatsApp(data[position]);
            });
            holder.copy_button.setOnClickListener(view -> {
                new InterstitialAds(CaptionitemActivity.this).interads(CaptionitemActivity.this, new InterstitialAds.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        copyToClipboard(data[position]);
                    }
                });
            });

        }

        @Override
        public int getItemCount() {
            return data.length;
        }
    }
    private void shareToWhatsApp(String text) {
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, text);
        sendIntent.setType("text/plain");
        sendIntent.setPackage("com.whatsapp");

        if (isWhatsAppInstalled(sendIntent)) {
            startActivity(sendIntent);
        } else {
            Toast.makeText(CaptionitemActivity.this, "plz installe Whatsapp", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isWhatsAppInstalled(Intent intent) {
        PackageManager packageManager = getPackageManager();
        ResolveInfo resolveInfo = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY);
        return resolveInfo != null;
    }
    private void copyToClipboard(String textToCopy) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("Copied Text", textToCopy);
        clipboard.setPrimaryClip(clip);
        Toast.makeText(this, "Text copied to clipboard", Toast.LENGTH_SHORT).show();
    }
}