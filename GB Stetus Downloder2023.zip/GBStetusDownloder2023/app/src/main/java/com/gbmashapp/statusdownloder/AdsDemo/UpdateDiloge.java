package com.gbmashapp.statusdownloder.AdsDemo;


import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.gbmashapp.statusdownloder.R;

public class UpdateDiloge {

    Activity activity;

    public UpdateDiloge(Activity activity) {
        this.activity = activity;
    }

    public void ShowUpdateDialog() {
        Dialog exitdialog = new Dialog(activity);
        exitdialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        exitdialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        exitdialog.setContentView(R.layout.ads_appupdate_dilog);
        exitdialog.setCancelable(false);
        Window window = exitdialog.getWindow();
        WindowManager.LayoutParams attributes = window.getAttributes();
        attributes.gravity = Gravity.CENTER;
        window.setAttributes(attributes);
        exitdialog.show();

        TextView updatebtn = exitdialog.findViewById(R.id.updatebtn);
        String Updateurl = SharedPrefs.getUpdateurl(activity);

        updatebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(Updateurl));
                activity.startActivity(intent);
            }
        });
    }

    public void ShownotEnterDialog() {
        Dialog exitdialog = new Dialog(activity);
        exitdialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        exitdialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        exitdialog.setContentView(R.layout.ads_appupdate_dilog);
        exitdialog.setCancelable(false);
        Window window = exitdialog.getWindow();
        WindowManager.LayoutParams attributes = window.getAttributes();
        attributes.gravity = Gravity.CENTER;
        window.setAttributes(attributes);
        exitdialog.show();

        TextView updatebtn = exitdialog.findViewById(R.id.updatebtn);
        TextView title_update = exitdialog.findViewById(R.id.title_update);
        TextView ditail_update = exitdialog.findViewById(R.id.ditail_update);
        title_update.setText("App under maintenance");
        ditail_update.setText("please try after some houres.");
        updatebtn.setVisibility(View.GONE);
    }
}
