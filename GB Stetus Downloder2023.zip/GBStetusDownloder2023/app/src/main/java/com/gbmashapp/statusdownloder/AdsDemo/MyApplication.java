package com.gbmashapp.statusdownloder.AdsDemo;

import android.app.Application;

import com.onesignal.OneSignal;


public class MyApplication extends Application {
    private static final String ONESIGNAL_APP_ID = "c2c23f32-ceac-45e9-8d87-580d17db5f3a";

    @Override
    public void onCreate() {
        super.onCreate();
        new AppOpenManager(this);

        OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);
        OneSignal.initWithContext(this);
        OneSignal.setAppId(ONESIGNAL_APP_ID);
        OneSignal.promptForPushNotifications();
    }
}
