package com.gbmashapp.statusdownloder.CateGoryOne.stetussaver;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefs {

    private static SharedPreferences mPreferences;
    public static final String WA_TREE_URI = "wa_tree_uri";

    private static SharedPreferences getInstance(Context context) {
        if (mPreferences == null) {
            mPreferences = context.getApplicationContext()
                    .getSharedPreferences("all_saver_data", Context.MODE_PRIVATE);
        }
        return mPreferences;
    }
    public static void setWATree(Context context, String value) {
        getInstance(context).edit().putString(WA_TREE_URI, value).apply();
    }

    public static String getWATree(Context context) {
        return getInstance(context).getString(WA_TREE_URI, "");
    }
}
