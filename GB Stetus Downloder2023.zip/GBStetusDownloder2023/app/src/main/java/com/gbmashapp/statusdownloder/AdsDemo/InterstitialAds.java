package com.gbmashapp.statusdownloder.AdsDemo;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.CountDownTimer;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.browser.customtabs.CustomTabsIntent;

import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.ads.MaxInterstitialAd;
import com.facebook.ads.Ad;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.gbmashapp.statusdownloder.R;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.Random;

public class InterstitialAds {
    static ProgressDialog pd;

    Activity activity;
    public static BroadcastReceiver broadcastReceiver;

    public InterstitialAds(Activity activity) {
        this.activity = activity;
    }

    String interid, fbinterid;
    JSONArray aminterarry, fbinterarry;

    public void interads(Activity activity, OnIntertistialAdsListner onAdsListner) {
        if (SharedPrefs.getInternetDilog(activity).equals("yes")) {
            broadcastReceiver = new NetworkChangeListener();
            activity.registerReceiver(broadcastReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        }
        if (SharedPrefs.getcountOnOff(activity).equals("off")) {
            if (SharedPrefs.getADsShow(activity).equals("yes")) {
                if (!SharedPrefs.gettimer(activity)) {
                    loadinterads(activity, onAdsListner);
                    int second = SharedPrefs.getInterClickCount(activity) * 1000;
                    new CountDownTimer(second, 1000) {
                        public void onTick(long millisUntilFinished) {
                            SharedPrefs.settimer(activity, true);
                        }

                        public void onFinish() {
                            SharedPrefs.settimer(activity, false);
                        }
                    }.start();
                } else {
                    onAdsListner.onAdsDismissed();
                }
            } else {
                onAdsListner.onAdsDismissed();
            }
        } else {
            if (SharedPrefs.getADsShow(activity).equals("yes")) {
                int intertialseclick = SharedPrefs.getInterClickCount(activity);
                SharedPrefs.setinterclickcount(activity, SharedPrefs.getinterclickcount(activity) + 1);
                if (intertialseclick == SharedPrefs.getinterclickcount(activity)) {
                    SharedPrefs.setinterclickcount(activity, 0);
                    loadinterads(activity, onAdsListner);
                } else {
                    onAdsListner.onAdsDismissed();
                }
            } else {
                onAdsListner.onAdsDismissed();
            }
        }

    }

    public void loadinterads(Activity activity, OnIntertistialAdsListner onAdsListner) {
        try {
            aminterarry = new JSONArray(SharedPrefs.getAMInterId(activity));
            if (SharedPrefs.getAMInterIdArry(activity) < aminterarry.length()) {
                interid = aminterarry.getString(SharedPrefs.getAMInterIdArry(activity));
                SharedPrefs.setAMInterIdArry(activity, SharedPrefs.getAMInterIdArry(activity) + 1);
                if (!(SharedPrefs.getAMInterIdArry(activity) < aminterarry.length())) {
                    SharedPrefs.setAMInterIdArry(activity, 0);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            fbinterarry = new JSONArray(SharedPrefs.getFBInterId(activity));
            if (SharedPrefs.getFBInterIdArry(activity) < fbinterarry.length()) {
                fbinterid = fbinterarry.getString(SharedPrefs.getFBInterIdArry(activity));
                SharedPrefs.setFBInterIdArry(activity, SharedPrefs.getFBInterIdArry(activity) + 1);
                if (!(SharedPrefs.getFBInterIdArry(activity) < fbinterarry.length())) {
                    SharedPrefs.setFBInterIdArry(activity, 0);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        pd = new ProgressDialog(activity);
        pd.setMessage("Ads loading");
        pd.setCancelable(false);
        pd.show();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (SharedPrefs.getInterSpecific(activity) == 1) {
                    if (SharedPrefs.getInterSequns(activity) == 1) {
                        AdRequest adRequest = new AdRequest.Builder().build();
                        InterstitialAd.load(activity, interid, adRequest, new InterstitialAdLoadCallback() {
                            @Override
                            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {

                                interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                                    @Override
                                    public void onAdDismissedFullScreenContent() {
                                        onAdsListner.onAdsDismissed();
                                    }

                                    @Override
                                    public void onAdFailedToShowFullScreenContent(AdError adError) {

                                    }

                                    @Override
                                    public void onAdShowedFullScreenContent() {
                                        if (pd.isShowing()) {
                                            pd.dismiss();
                                        }
                                    }
                                });
                                interstitialAd.show(activity);
                            }

                            @Override
                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                FBinterads(activity, onAdsListner);
                            }
                        });
                    } else if (SharedPrefs.getInterSequns(activity) == 2) {
                        com.facebook.ads.InterstitialAd fbinterstitialAd = new com.facebook.ads.InterstitialAd(activity, fbinterid);
                        InterstitialAdListener interstitialAdListener = new InterstitialAdListener() {
                            @Override
                            public void onInterstitialDisplayed(Ad ad) {

                            }

                            @Override
                            public void onInterstitialDismissed(Ad ad) {
                                onAdsListner.onAdsDismissed();
                            }

                            @Override
                            public void onError(Ad ad, com.facebook.ads.AdError adError) {
                                AMinterads(activity, onAdsListner);
                            }

                            @Override
                            public void onAdLoaded(Ad ad) {
                                fbinterstitialAd.show();
                                if (pd.isShowing()) {
                                    pd.dismiss();
                                }
                            }

                            @Override
                            public void onAdClicked(Ad ad) {

                            }

                            @Override
                            public void onLoggingImpression(Ad ad) {

                            }
                        };
                        fbinterstitialAd.loadAd(fbinterstitialAd.buildLoadAdConfig().withAdListener(interstitialAdListener).build());
                    } else if (SharedPrefs.getInterSequns(activity) == 3) {
                        MaxInterstitialAd interstitialAd = new MaxInterstitialAd(SharedPrefs.getALInterId(activity), activity);
                        MaxAdListener adListener = new MaxAdListener() {
                            @Override
                            public void onAdLoaded(MaxAd ad) {
                                if (pd.isShowing()) {
                                    pd.dismiss();
                                }
                                if (interstitialAd.isReady()) {
                                    interstitialAd.showAd();
                                }
                            }

                            @Override
                            public void onAdDisplayed(MaxAd ad) {
                                if (pd.isShowing()) {
                                    pd.dismiss();
                                }
                            }

                            @Override
                            public void onAdHidden(MaxAd ad) {
                                onAdsListner.onAdsDismissed();
                            }

                            @Override
                            public void onAdClicked(MaxAd ad) {

                            }

                            @Override
                            public void onAdLoadFailed(String adUnitId, MaxError error) {
                                if (SharedPrefs.getapplovinAMFB(activity) == 1) {
                                    AdRequest adRequest = new AdRequest.Builder().build();
                                    InterstitialAd.load(activity, interid, adRequest, new InterstitialAdLoadCallback() {
                                        @Override
                                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                                            interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                                                @Override
                                                public void onAdDismissedFullScreenContent() {
                                                    onAdsListner.onAdsDismissed();
                                                }

                                                @Override
                                                public void onAdFailedToShowFullScreenContent(AdError adError) {

                                                }

                                                @Override
                                                public void onAdShowedFullScreenContent() {
                                                    if (pd.isShowing()) {
                                                        pd.dismiss();
                                                    }
                                                }
                                            });
                                            interstitialAd.show(activity);
                                        }

                                        @Override
                                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                            com.facebook.ads.InterstitialAd fbinterstitialAd = new com.facebook.ads.InterstitialAd(activity, fbinterid);
                                            InterstitialAdListener interstitialAdListener = new InterstitialAdListener() {
                                                @Override
                                                public void onInterstitialDisplayed(Ad ad) {

                                                }

                                                @Override
                                                public void onInterstitialDismissed(Ad ad) {
                                                    onAdsListner.onAdsDismissed();
                                                }

                                                @Override
                                                public void onError(Ad ad, com.facebook.ads.AdError adError) {
                                                    if (SharedPrefs.getqurekashow(activity) == 1) {
                                                        qurekaIntertistialAds(activity, onAdsListner);
                                                    } else {
                                                        onAdsListner.onAdsDismissed();
                                                        if (pd.isShowing()) {
                                                            pd.dismiss();
                                                        }
                                                    }
                                                }

                                                @Override
                                                public void onAdLoaded(Ad ad) {
                                                    fbinterstitialAd.show();
                                                    if (pd.isShowing()) {
                                                        pd.dismiss();
                                                    }
                                                }

                                                @Override
                                                public void onAdClicked(Ad ad) {

                                                }

                                                @Override
                                                public void onLoggingImpression(Ad ad) {

                                                }
                                            };
                                            fbinterstitialAd.loadAd(fbinterstitialAd.buildLoadAdConfig().withAdListener(interstitialAdListener).build());
                                        }
                                    });
                                } else if (SharedPrefs.getapplovinAMFB(activity) == 2) {
                                    com.facebook.ads.InterstitialAd fbinterstitialAd = new com.facebook.ads.InterstitialAd(activity, fbinterid);
                                    InterstitialAdListener interstitialAdListener = new InterstitialAdListener() {
                                        @Override
                                        public void onInterstitialDisplayed(Ad ad) {

                                        }

                                        @Override
                                        public void onInterstitialDismissed(Ad ad) {
                                            onAdsListner.onAdsDismissed();
                                        }

                                        @Override
                                        public void onError(Ad ad, com.facebook.ads.AdError adError) {
                                            AdRequest adRequest = new AdRequest.Builder().build();
                                            InterstitialAd.load(activity, interid, adRequest, new InterstitialAdLoadCallback() {
                                                @Override
                                                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                                                    interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                                                        @Override
                                                        public void onAdDismissedFullScreenContent() {
                                                            onAdsListner.onAdsDismissed();
                                                        }

                                                        @Override
                                                        public void onAdFailedToShowFullScreenContent(AdError adError) {

                                                        }

                                                        @Override
                                                        public void onAdShowedFullScreenContent() {
                                                            if (pd.isShowing()) {
                                                                pd.dismiss();
                                                            }
                                                        }
                                                    });
                                                    interstitialAd.show(activity);
                                                }

                                                @Override
                                                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                                    if (SharedPrefs.getqurekashow(activity) == 1) {
                                                        qurekaIntertistialAds(activity, onAdsListner);
                                                    } else {
                                                        onAdsListner.onAdsDismissed();
                                                        if (pd.isShowing()) {
                                                            pd.dismiss();
                                                        }
                                                    }
                                                }
                                            });
                                        }

                                        @Override
                                        public void onAdLoaded(Ad ad) {
                                            fbinterstitialAd.show();
                                            if (pd.isShowing()) {
                                                pd.dismiss();
                                            }
                                        }

                                        @Override
                                        public void onAdClicked(Ad ad) {

                                        }

                                        @Override
                                        public void onLoggingImpression(Ad ad) {

                                        }
                                    };
                                    fbinterstitialAd.loadAd(fbinterstitialAd.buildLoadAdConfig().withAdListener(interstitialAdListener).build());
                                }
                            }

                            @Override
                            public void onAdDisplayFailed(MaxAd ad, MaxError error) {

                            }
                        };
                        interstitialAd.setListener(adListener);
                        interstitialAd.loadAd();
                    }
                } else if (SharedPrefs.getInterSpecific(activity) == 2) {
                    AMinterads(activity, onAdsListner);
                } else if (SharedPrefs.getInterSpecific(activity) == 3) {
                    FBinterads(activity, onAdsListner);
                } else if (SharedPrefs.getInterSpecific(activity) == 4) {
                    qurekaIntertistialAds(activity, onAdsListner);
                } else if (SharedPrefs.getInterSpecific(activity) == 5) {
                    ApplovinIntertistialAds(activity, onAdsListner);
                }
            }
        }, 1000);
    }

    public void AMinterads(Activity activity, OnIntertistialAdsListner onAdsListner) {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(activity, interid, adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        onAdsListner.onAdsDismissed();
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError adError) {

                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        if (pd.isShowing()) {
                            pd.dismiss();
                        }
                    }
                });
                interstitialAd.show(activity);
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                if (SharedPrefs.getapplovinshow(activity) == 1) {
                    ApplovinIntertistialAds(activity, onAdsListner);
                } else if (SharedPrefs.getapplovinshow(activity) == 0) {
                    if (SharedPrefs.getqurekashow(activity) == 1) {
                        qurekaIntertistialAds(activity, onAdsListner);
                    } else {
                        onAdsListner.onAdsDismissed();
                        if (pd.isShowing()) {
                            pd.dismiss();
                        }
                    }
                }
            }
        });
    }

    public void FBinterads(Activity activity, OnIntertistialAdsListner onAdsListner) {
        com.facebook.ads.InterstitialAd fbinterstitialAd = new com.facebook.ads.InterstitialAd(activity, fbinterid);
        InterstitialAdListener interstitialAdListener = new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                onAdsListner.onAdsDismissed();
            }

            @Override
            public void onError(Ad ad, com.facebook.ads.AdError adError) {
                if (SharedPrefs.getapplovinshow(activity) == 1) {
                    ApplovinIntertistialAds(activity, onAdsListner);
                } else if (SharedPrefs.getapplovinshow(activity) == 0) {
                    if (SharedPrefs.getqurekashow(activity) == 1) {
                        qurekaIntertistialAds(activity, onAdsListner);
                    } else {
                        onAdsListner.onAdsDismissed();
                        if (pd.isShowing()) {
                            pd.dismiss();
                        }
                    }
                }
            }

            @Override
            public void onAdLoaded(Ad ad) {
                fbinterstitialAd.show();
                if (pd.isShowing()) {
                    pd.dismiss();
                }
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        };
        fbinterstitialAd.loadAd(fbinterstitialAd.buildLoadAdConfig().withAdListener(interstitialAdListener).build());
    }

    public static void ApplovinIntertistialAds(Activity activity, OnIntertistialAdsListner onAdsListner) {
        MaxInterstitialAd interstitialAd = new MaxInterstitialAd(SharedPrefs.getALInterId(activity), activity);
        MaxAdListener adListener = new MaxAdListener() {
            @Override
            public void onAdLoaded(MaxAd ad) {
                if (pd.isShowing()) {
                    pd.dismiss();
                }
                if (interstitialAd.isReady()) {
                    interstitialAd.showAd();
                }
            }

            @Override
            public void onAdDisplayed(MaxAd ad) {
                if (pd.isShowing()) {
                    pd.dismiss();
                }
            }

            @Override
            public void onAdHidden(MaxAd ad) {
                onAdsListner.onAdsDismissed();
            }

            @Override
            public void onAdClicked(MaxAd ad) {

            }

            @Override
            public void onAdLoadFailed(String adUnitId, MaxError error) {
                if (pd.isShowing()) {
                    pd.dismiss();
                }
                if (SharedPrefs.getqurekashow(activity) == 1) {
                    qurekaIntertistialAds(activity, onAdsListner);
                } else {
                    onAdsListner.onAdsDismissed();
                }
            }

            @Override
            public void onAdDisplayFailed(MaxAd ad, MaxError error) {
                if (SharedPrefs.getqurekashow(activity) == 1) {
                    qurekaIntertistialAds(activity, onAdsListner);
                } else {
                    onAdsListner.onAdsDismissed();
                }
            }
        };
        interstitialAd.setListener(adListener);
        interstitialAd.loadAd();
    }

    public static void qurekaIntertistialAds(Activity activity, OnIntertistialAdsListner onAdsListner) {
        if (SharedPrefs.getqurekainterdilogshow(activity).equals("yes")) {
            Dialog dialog = new Dialog(activity);
            dialog = new Dialog(activity, android.R.style.Theme_DeviceDefault_Light_NoActionBar_Fullscreen);
            dialog.setContentView(R.layout.ads_qureka_layout);
            dialog.setCancelable(false);
            dialog.show();
            if (pd.isShowing()) {
                pd.dismiss();
            }
            ImageView qureka_inter_close_btn = dialog.findViewById(R.id.qureka_inter_close_btn);
            RelativeLayout game_inter_ad_layout = dialog.findViewById(R.id.game_inter_ad_layout);
            Dialog finalDialog = dialog;
            qureka_inter_close_btn.setOnClickListener(view -> {
                finalDialog.dismiss();
                onAdsListner.onAdsDismissed();
            });
            int[] qurekaBigBannerArray = {R.drawable.big_banner1, R.drawable.big_banner2, R.drawable.big_banner4, R.drawable.big_banner5, R.drawable.big_banner6, R.drawable.big_banner7, R.drawable.big_banner8, R.drawable.big_banner9, R.drawable.big_banner10, R.drawable.big_banner11, R.drawable.big_banner12};
            ImageView qurekaimg = dialog.findViewById(R.id.game_inter_mediaView);
            try {
                qurekaimg.setImageResource(qurekaBigBannerArray[new Random().nextInt(qurekaBigBannerArray.length)]);
            } catch (Resources.NotFoundException e) {
                e.printStackTrace();
                qurekaimg.setImageDrawable(activity.getResources().getDrawable(R.drawable.big_banner1));
            }
            game_inter_ad_layout.setOnClickListener(view -> {
                finalDialog.dismiss();
                onAdsListner.onAdsDismissed();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                        CustomTabsIntent customTabsIntent = builder.build();
                        customTabsIntent.launchUrl(activity, Uri.parse(SharedPrefs.getqurekashowurl(activity)));
                    }
                }, 50);
            });
        } else if (SharedPrefs.getqurekainterdilogshow(activity).equals("no")) {
            if (pd.isShowing()) {
                pd.dismiss();
            }
            onAdsListner.onAdsDismissed();
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                    CustomTabsIntent customTabsIntent = builder.build();
                    customTabsIntent.launchUrl(activity, Uri.parse(SharedPrefs.getqurekashowurl(activity)));
                }
            }, 50);
        }
    }

    public interface OnIntertistialAdsListner {
        void onAdsDismissed();
    }
}
