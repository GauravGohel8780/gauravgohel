package com.gbmashapp.statusdownloder.CateGoryThree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.gbmashapp.statusdownloder.AdsDemo.InterstitialAds;
import com.gbmashapp.statusdownloder.AdsDemo.NativeAds;
import com.gbmashapp.statusdownloder.AdsDemo.SharedPrefs;
import com.gbmashapp.statusdownloder.R;

public class CateGory_Three extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cate_gory_three);
        if (SharedPrefs.getAdsTextShow(this) == 1){
            findViewById(R.id.nativead_text).setVisibility(View.VISIBLE);
        }
        if (SharedPrefs.getAdsShowleyer(this).contains("CGTN")) {
            findViewById(R.id.viewlayout).setVisibility(View.VISIBLE);
        }
        new NativeAds(this).nativeads(this, findViewById(R.id.native_container));

        findViewById(R.id.back).setOnClickListener(view -> {
            onBackPressed();
        });
        findViewById(R.id.Yowhasapp).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    startActivity(new Intent(CateGory_Three.this, GBwhatsappCate.class));
                }
            });
        });
    }
}