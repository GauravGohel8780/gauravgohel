package com.gbmashapp.statusdownloder.CateGoryOne;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.gbmashapp.statusdownloder.AdsDemo.BannerAds;
import com.gbmashapp.statusdownloder.AdsDemo.SharedPrefs;
import com.gbmashapp.statusdownloder.R;
import com.hbb20.CountryCodePicker;

import java.io.PrintStream;
import java.net.URLEncoder;
import java.security.Key;

public class DirectMsgActivity extends AppCompatActivity {

    ImageView btnback;
    CountryCodePicker countylist;
    EditText etnumber, etmassege;
    RelativeLayout btnsend;
    String selectedCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_direct_msg);
        if (SharedPrefs.getAdsTextShow(this) == 1) {
            findViewById(R.id.bannerad_text).setVisibility(View.VISIBLE);
        }
        if (SharedPrefs.getAdsShowleyer(this).contains("DMAB")) {
            findViewById(R.id.viewlayout).setVisibility(View.VISIBLE);
        }
        new BannerAds(this).bannerads(this, findViewById(R.id.banner_container));
        btnback = findViewById(R.id.back);
        countylist = findViewById(R.id.ccp);
        etnumber = findViewById(R.id.input_text);
        etmassege = findViewById(R.id.msg);
        btnsend = findViewById(R.id.go);

        btnback.setOnClickListener(view -> {
            onBackPressed();
        });

        countylist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                countylist.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener() {
                    @Override
                    public void onCountrySelected() {
                        selectedCode = String.valueOf(countylist.getSelectedCountryCodeWithPlus());
                    }
                });
            }
        });

        btnsend.setOnClickListener(view -> {
            if (etnumber.getText().toString().isEmpty()){
                Toast.makeText(this, "Please Enter a Number", Toast.LENGTH_SHORT).show();
            }else {
                PackageManager packageManager = getPackageManager();
                Intent intent = new Intent("android.intent.action.VIEW");
                int i = Build.VERSION.SDK_INT;
                try {
                    intent.setPackage("com.whatsapp");
                    intent.setData(Uri.parse("https://api.whatsapp.com/send?phone=" + countylist.getSelectedCountryCodeWithPlus() + etnumber.getText().toString() + "&text=" + URLEncoder.encode(etmassege.getText().toString(), "UTF-8")));
                    PrintStream printStream = System.out;
                    StringBuilder sb = new StringBuilder();
                    sb.append("VV1=");
                    sb.append(Build.VERSION.SDK_INT);
                    printStream.println(sb.toString());
                    if (intent.resolveActivity(packageManager) != null) {
                        startActivity(intent);
                    } else if (i >= 30) {
                        try {
                            startActivity(intent);
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(DirectMsgActivity.this, " WhatsApp is not currently installed on your phone", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else {
                        Toast.makeText(DirectMsgActivity.this, " WhatsApp is not currently installed on your phone", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        });
    }
}