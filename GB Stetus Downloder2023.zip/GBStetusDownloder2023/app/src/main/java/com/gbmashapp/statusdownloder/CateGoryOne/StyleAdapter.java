package com.gbmashapp.statusdownloder.CateGoryOne;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;


import com.gbmashapp.statusdownloder.AdsDemo.InterstitialAds;
import com.gbmashapp.statusdownloder.R;

import java.util.ArrayList;

public class StyleAdapter extends RecyclerView.Adapter<StyleAdapter.ViewHolder> {

    private static final String COPIED_NUMBER_KEY = "COPIED_NUMBER";
    private static final String PREFS_NAME = "MyPrefsFile";
    private static final String RATING_INVITED_KEY = "RATING_INVITED_VERSION_1.1";
    public Context context;
    public ArrayList<DataStyle> dataStyles;
    private int numberOfCopiedPressed;
    private boolean ratingInvited;

    public StyleAdapter(ArrayList<DataStyle> arrayList, Context context) {
        this.numberOfCopiedPressed = 0;
        this.ratingInvited = false;
        this.dataStyles = arrayList;
        this.context = context;
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_NAME, 0);
        this.numberOfCopiedPressed = sharedPreferences.getInt(COPIED_NUMBER_KEY, 0);
        this.ratingInvited = sharedPreferences.getBoolean(RATING_INVITED_KEY, false);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView cp_emoji_btn1;
        ImageView sh_emoji_btn1;
        TextView styleName;
        TextView styleValue;
        ImageView wp_emoji_btn1;

        public TextView getStyleValue() {
            return this.styleValue;
        }

        public ViewHolder(View view) {
            super(view);
            this.styleName = (TextView) view.findViewById(R.id.styleName);
            TextView textView = (TextView) view.findViewById(R.id.styleValue);
            this.styleValue = textView;
            textView.setSelected(true);
            this.cp_emoji_btn1 = (ImageView) view.findViewById(R.id.cp_emoji_btn1);
            this.sh_emoji_btn1 = (ImageView) view.findViewById(R.id.sh_emoji_btn1);
            this.wp_emoji_btn1 = (ImageView) view.findViewById(R.id.wp_emoji_btn1);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View inflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_row, viewGroup, false);
        new ViewHolder(inflate);
        return new ViewHolder(inflate);
    }

    public void onBindViewHolder(final ViewHolder viewHolder, final int i) {
        viewHolder.styleName.setText(this.dataStyles.get(i).getStyleName());
        viewHolder.styleValue.setText(this.dataStyles.get(i).getStyleValue());
        viewHolder.cp_emoji_btn1.setTag(R.id.cp_emoji_btn1, Integer.valueOf(i));
        viewHolder.cp_emoji_btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new InterstitialAds((Activity) context).interads((Activity) context, new InterstitialAds.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        ((ClipboardManager) StyleAdapter.this.context.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Emoji copy", StyleAdapter.this.dataStyles.get(i).getStyleValue()));
                        Toast.makeText(StyleAdapter.this.context, "Copy Clipboard Text", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
        viewHolder.sh_emoji_btn1.setTag(R.id.sh_emoji_btn1, Integer.valueOf(i));
        viewHolder.sh_emoji_btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String charSequence = viewHolder.styleValue.getText().toString();
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.TEXT", charSequence);
                StyleAdapter.this.context.startActivity(Intent.createChooser(intent, "Share via"));
            }
        });
        viewHolder.wp_emoji_btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String charSequence = viewHolder.styleValue.getText().toString();
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.setPackage("com.whatsapp");
                intent.putExtra("android.intent.extra.TEXT", charSequence);
                StyleAdapter.this.context.startActivity(Intent.createChooser(intent, "Share via"));
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.dataStyles.size();
    }

}
