package com.gbmashapp.statusdownloder.CateGoryOne.stetussaver;

import static androidx.fragment.app.FragmentStatePagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT;

import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.gbmashapp.statusdownloder.AdsDemo.BannerAds;
import com.gbmashapp.statusdownloder.CateGoryTwo.AngryFragment;
import com.gbmashapp.statusdownloder.CateGoryTwo.EmojiActivity;
import com.gbmashapp.statusdownloder.CateGoryTwo.HappyFragment;
import com.gbmashapp.statusdownloder.CateGoryTwo.OtherFragment;
import com.gbmashapp.statusdownloder.R;
import com.google.android.material.tabs.TabLayout;

import java.io.File;

public class StetasSvareActivity extends AppCompatActivity {
    public static File RootDirectoryWhatsappShow = new File(Environment.getExternalStorageDirectory() + "/status_saver");
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private MyPagerAdapter pagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stetas_svare);
        if (com.gbmashapp.statusdownloder.AdsDemo.SharedPrefs.getAdsTextShow(this) == 1) {
            findViewById(R.id.bannerad_text).setVisibility(View.VISIBLE);
        }
        if (com.gbmashapp.statusdownloder.AdsDemo.SharedPrefs.getAdsShowleyer(this).contains("SSAB")) {
            findViewById(R.id.viewlayout).setVisibility(View.VISIBLE);
        }
        new BannerAds(this).bannerads(this, findViewById(R.id.banner_container));
        findViewById(R.id.back).setOnClickListener(view -> {
            onBackPressed();
        });
        tabLayout = findViewById(R.id.tabs);
        viewPager = findViewById(R.id.viewpager);
        pagerAdapter = new MyPagerAdapter(getSupportFragmentManager());

        viewPager.setAdapter(pagerAdapter);
        tabLayout.setupWithViewPager(viewPager);
        createFileFolder();
    }

    public static void createFileFolder() {

        if (!RootDirectoryWhatsappShow.exists()) {
            RootDirectoryWhatsappShow.mkdirs();
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Common.APP_DIR == null || Common.APP_DIR.isEmpty()) {
            Common.APP_DIR = getExternalFilesDir("StatusDownloader").getPath();
            Log.d("App Path", Common.APP_DIR);
        }
    }

    private class MyPagerAdapter extends FragmentPagerAdapter {

        private String[] tabTitles = {"Images", "Videos", "Save Item"};

        public MyPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case 0:
                    return new WhatsappImageFragment();
                case 1:
                    return new WhatsappVideoFragment();
                case 2:
                    return new AllinOneGalleryFragment();
                default:
                    return null;
            }
        }

        @Override
        public int getCount() {
            return tabTitles.length;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return tabTitles[position];
        }
    }
}