package com.gbmashapp.statusdownloder.CateGoryOne;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.DownloadListener;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.gbmashapp.statusdownloder.AdsDemo.BannerAds;
import com.gbmashapp.statusdownloder.AdsDemo.SharedPrefs;
import com.gbmashapp.statusdownloder.R;

import java.util.Arrays;
import java.util.Locale;

public class WebActivity extends AppCompatActivity {

    public PermissionRequest permission;
    public ValueCallback<Uri[]> Callback;
    WebView whatsView;
    private static final String CAMERA_PERMISSION = "android.permission.CAMERA";
    private static final String SOUND_PERMISSION = "android.permission.RECORD_AUDIO";
    public static final String[] ALL_PERMISSION = {CAMERA_PERMISSION, SOUND_PERMISSION};
    static String WHATSZ_URL = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);
        if (SharedPrefs.getAdsTextShow(this) == 1) {
            findViewById(R.id.bannerad_text).setVisibility(View.VISIBLE);
        }
        if (SharedPrefs.getAdsShowleyer(this).contains("WAB")) {
            findViewById(R.id.viewlayout).setVisibility(View.VISIBLE);
        }
        new BannerAds(this).bannerads(this, findViewById(R.id.banner_container));
        WebView webView = (WebView) findViewById(R.id.webViewscan);
        this.whatsView = webView;
        webView.getSettings().setJavaScriptEnabled(true);
        this.whatsView.setWebViewClient(new MyWebViewClient());
        WHATSZ_URL = "https://web.whatsapp.com/\u1f310/" + Locale.getDefault().getLanguage();
        this.whatsView.getSettings().setJavaScriptEnabled(true);
        this.whatsView.getSettings().setAllowContentAccess(true);
        this.whatsView.getSettings().setAllowFileAccess(true);
        this.whatsView.getSettings().setAllowFileAccessFromFileURLs(true);
        this.whatsView.getSettings().setAllowUniversalAccessFromFileURLs(true);
        this.whatsView.getSettings().setDomStorageEnabled(true);
//        this.whatsView.getSettings().setAppCacheEnabled(true);
//        this.whatsView.getSettings().setAppCachePath(getCacheDir().getAbsolutePath());
        this.whatsView.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        this.whatsView.setScrollbarFadingEnabled(true);
        this.whatsView.setWebChromeClient(new WebChromeClient() { // from class: com.whats.statusapp.videoimagesaver.Web.WACloneActivity.1
            @Override // android.webkit.WebChromeClient
            public void onPermissionRequest(PermissionRequest permission) {
                if (permission.getResources()[0].equals("android.webkit.resource.VIDEO_CAPTURE")) {
                    if (ContextCompat.checkSelfPermission(WebActivity.this, CAMERA_PERMISSION) == -1 && ContextCompat.checkSelfPermission(WebActivity.this, WebActivity.SOUND_PERMISSION) == -1) {
                        ActivityCompat.requestPermissions(WebActivity.this, WebActivity.ALL_PERMISSION, 203);
                    } else if (ContextCompat.checkSelfPermission(WebActivity.this, WebActivity.CAMERA_PERMISSION) == -1) {
                        ActivityCompat.requestPermissions(WebActivity.this, new String[]{WebActivity.CAMERA_PERMISSION}, 201);
                    } else if (ContextCompat.checkSelfPermission(WebActivity.this, WebActivity.SOUND_PERMISSION) == -1) {
                        ActivityCompat.requestPermissions(WebActivity.this, new String[]{WebActivity.SOUND_PERMISSION}, 202);
                    } else {
                        permission.grant(permission.getResources());
                    }
                } else if (!permission.getResources()[0].equals("android.webkit.resource.AUDIO_CAPTURE")) {
                    try {
                        permission.grant(permission.getResources());
                    } catch (RuntimeException e) {
                        Log.d("Whats Web", "Granting permissions failed", e);
                    }
                } else if (ContextCompat.checkSelfPermission(WebActivity.this, WebActivity.SOUND_PERMISSION) == 0) {
                    permission.grant(permission.getResources());
                } else {
                    ActivityCompat.requestPermissions(WebActivity.this, new String[]{WebActivity.SOUND_PERMISSION}, 202);
                }
            }

            @Override // android.webkit.WebChromeClient
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Log.d("Web whats", "WebView console message: " + consoleMessage.message());
                return super.onConsoleMessage(consoleMessage);
            }

            @Override // android.webkit.WebChromeClient
            public boolean onShowFileChooser(WebView webView2, ValueCallback<Uri[]> Callback, FileChooserParams fileChooserParams) {
                WebActivity.this.startActivityForResult(fileChooserParams.createIntent(), 200);
                Toast.makeText(WebActivity.this, "show", Toast.LENGTH_LONG).show();
                return true;
            }
        });
        this.whatsView.setDownloadListener(new DownloadListener() { // from class: com.whats.statusapp.videoimagesaver.Web.WebActivity.2
            @Override // android.webkit.DownloadListener
            public final void onDownloadStart(String str, String str2, String str3, String str4, long j) {
                Toast.makeText(WebActivity.this, "Downloading is not supported yet.", Toast.LENGTH_SHORT).show();
            }
        });
        this.whatsView.getSettings().setUserAgentString("Mozilla/5.0 (Linux; Win64; x64; rv:46.0) Gecko/20100101 Firefox/60.0");
        if (savedInstanceState == null) {
            load();
        } else {
            Log.d("Web whats", "savedInstanceState is present");
        }
    }

    private void load() {
        this.whatsView.loadUrl(WHATSZ_URL);
    }

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        this.whatsView.saveState(bundle);
    }

    @Override // android.app.Activity
    public void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        this.whatsView.restoreState(bundle);
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (this.Callback != null) {
            if (i != 200) {
                Log.d("DEBUG_TAG", "Got activity result with unknown request code " + i + " - " + intent.toString());
            } else if (i2 == 0 || intent.getData() == null) {
                this.Callback.onReceiveValue(null);
            } else {
                this.Callback.onReceiveValue(new Uri[]{intent.getData()});
            }
        }
    }

    @Override // androidx.appcompat.app.AppCompatActivity, android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4 || !this.whatsView.canGoBack()) {
            return super.onKeyDown(i, keyEvent);
        }
        this.whatsView.goBack();
        return true;
    }


    private class MyWebViewClient extends WebViewClient {
        private MyWebViewClient() {

        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            webView.loadUrl(str);
            return true;
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        switch (i) {
            case 201:
            case 202:
                if (iArr.length > 0 && iArr[0] == 0) {
                    try {
                        PermissionRequest permission = this.permission;
                        permission.grant(permission.getResources());
                        break;
                    } catch (RuntimeException e) {
                        Log.e("DEBUG_TAG", "Granting permissions failed", e);
                        break;
                    }
                } else {
                    Toast.makeText(this, "sb.toString()", Toast.LENGTH_SHORT).show();
                    this.permission.deny();
                    break;
                }
            case 203:
                if (strArr.length != 2 || iArr[0] != 0 || iArr[1] != 0) {
                    Toast.makeText(this, "Permission not granted, can't use video.", Toast.LENGTH_SHORT).show();
                    this.permission.deny();
                    break;
                } else {
                    try {
                        PermissionRequest permissionRequest2 = this.permission;
                        permissionRequest2.grant(permissionRequest2.getResources());
                        break;
                    } catch (RuntimeException e2) {
                        Log.e("DEBUG_TAG", "Granting permissions failed", e2);
                        break;
                    }
                }
            case 204:
                if (iArr.length <= 0 || iArr[0] != 0) {
                    Toast.makeText(this, "Permission not granted, can't download to storage", Toast.LENGTH_SHORT).show();
                    break;
                }
                break;
            default:
                Log.d("DEBUG_TAG", "Got permission result with unknown request code " + i + " - " + Arrays.asList(strArr).toString());
                break;
        }
        this.permission = null;
    }

}