package com.gbmashapp.statusdownloder.AdsDemo;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefs {
    private static SharedPreferences mPreferences;
    public static final String ADsShow = "ADsShow";
    public static final String SpeshscrennIntent = "SpeshscrennIntent";
    public static final String AMAppOpenId = "AMAppOpenId";
    public static final String AMBannerId = "AMBannerId";
    public static final String AMBannerIdArry = "AMBannerIdArry";
    public static final String AMNativeId = "AMNativeId";
    public static final String AMNativeIdArry = "AMNativeIdArry";
    public static final String AMInterId = "AMInterId";
    public static final String AMInterIdArry = "AMInterIdArry";
    public static final String FBBannerId = "FBBannerId";
    public static final String FBBannerIdArry = "FBBannerIdArry";
    public static final String FBNativeId = "FBNativeId";
    public static final String FBNativeIdArry = "FBNativeIdArry";
    public static final String FBInterId = "FBInterId";
    public static final String FBInterIdArry = "FBInterIdArry";
    public static final String ALBannerId = "ALBannerId";
    public static final String ALNativeId = "ALNativeId";
    public static final String ALInterId = "ALInterId";
    public static final String InterClickCount = "InterClickCount";
    public static final String interclickcount = "interclickcount";
    public static final String BannerSpecific = "BannerSpecific";
    public static final String NativeSpecific = "NativeSpecific";
    public static final String InterSpecific = "InterSpecific";
    public static final String BannerSequns = "BannerSequns";
    public static final String NativeSequns = "NativeSequns";
    public static final String InterSequns = "InterSequns";
    public static final String AppOpenShow = "AppOpenShow";
    public static final String UpdateDilog = "UpdateDilog";
    public static final String UpdateCode = "UpdateCode";
    public static final String Updateurl = "Updateurl";
    public static final String applovinshow = "applovinshow";
    public static final String applovinAMFB = "applovinAMFB";
    public static final String qurekashow = "qurekashow";
    public static final String qurekainterdilogshow = "qurekainterdilogshow";
    public static final String qurekashowurl = "qurekashowurl";
    public static final String backgoundappopenshow = "backgoundappopenshow";
    public static final String timer = "timer";
    public static final String countOnOff = "countOnOff";
    public static final String ErrorDilogShow = "ErrorDilogShow";
    public static final String ErrorDilogCode = "ErrorDilogCode";
    public static final String AdsShowleyer = "AdsShowleyer";
    public static final String ChackUserinet = "ChackUserinet";
    public static final String chackReferrer = "chackReferrer";
    public static final String InternetDilog = "InternetDilog";
    public static final String AdsTextShow = "AdsTextShow";
    public static final String usersequence = "usersequence";
    public static final String extraPageShow = "extraPageShow";
    public static final String oddevan = "oddevan";
    public static final String Screen_chack = "Screen_chack";

    private static SharedPreferences getInstance(Context context) {
        if (mPreferences == null) {
            mPreferences = context.getApplicationContext().getSharedPreferences("data", 0);
        }
        return mPreferences;
    }

    public static void setADsShow(Context context, String b) {
        getInstance(context).edit().putString(ADsShow, b).apply();
    }

    public static String getADsShow(Context context) {
        return getInstance(context).getString(ADsShow, "");
    }

    public static void setSpeshscrennIntent(Context context, String b) {
        getInstance(context).edit().putString(SpeshscrennIntent, b).apply();
    }

    public static String getSpeshscrennIntent(Context context) {
        return getInstance(context).getString(SpeshscrennIntent, "");
    }

    public static void setAMAppOpenId(Context context, String b) {
        getInstance(context).edit().putString(AMAppOpenId, b).apply();
    }

    public static String getAMAppOpenId(Context context) {
        return getInstance(context).getString(AMAppOpenId, "");
    }

    public static void setAMBannerId(Context context, String b) {
        getInstance(context).edit().putString(AMBannerId, b).apply();
    }

    public static String getAMBannerId(Context context) {
        return getInstance(context).getString(AMBannerId, "");
    }

    public static void setAMBannerIdArry(Context context, int b) {
        getInstance(context).edit().putInt(AMBannerIdArry, b).apply();
    }

    public static int getAMBannerIdArry(Context context) {
        return getInstance(context).getInt(AMBannerIdArry, 0);
    }

    public static void setAMNativeIdArry(Context context, int b) {
        getInstance(context).edit().putInt(AMNativeIdArry, b).apply();
    }

    public static int getAMNativeIdArry(Context context) {
        return getInstance(context).getInt(AMNativeIdArry, 0);
    }

    public static void setAMNativeId(Context context, String b) {
        getInstance(context).edit().putString(AMNativeId, b).apply();
    }

    public static String getAMNativeId(Context context) {
        return getInstance(context).getString(AMNativeId, "");
    }

    public static void setAMInterId(Context context, String b) {
        getInstance(context).edit().putString(AMInterId, b).apply();
    }

    public static String getAMInterId(Context context) {
        return getInstance(context).getString(AMInterId, "");
    }

    public static void setAMInterIdArry(Context context, int b) {
        getInstance(context).edit().putInt(AMInterIdArry, b).apply();
    }

    public static int getAMInterIdArry(Context context) {
        return getInstance(context).getInt(AMInterIdArry, 0);
    }

    public static void setFBBannerId(Context context, String b) {
        getInstance(context).edit().putString(FBBannerId, b).apply();
    }

    public static String getFBBannerId(Context context) {
        return getInstance(context).getString(FBBannerId, "");
    }

    public static void setFBBannerIdArry(Context context, int b) {
        getInstance(context).edit().putInt(FBBannerIdArry, b).apply();
    }

    public static int getFBBannerIdArry(Context context) {
        return getInstance(context).getInt(FBBannerIdArry, 0);
    }

    public static void setFBNativeId(Context context, String b) {
        getInstance(context).edit().putString(FBNativeId, b).apply();
    }

    public static String getFBNativeId(Context context) {
        return getInstance(context).getString(FBNativeId, "");
    }

    public static void setFBNativeIdArry(Context context, int b) {
        getInstance(context).edit().putInt(FBNativeIdArry, b).apply();
    }

    public static int getFBNativeIdArry(Context context) {
        return getInstance(context).getInt(FBNativeIdArry, 0);
    }

    public static void setFBInterId(Context context, String b) {
        getInstance(context).edit().putString(FBInterId, b).apply();
    }

    public static String getFBInterId(Context context) {
        return getInstance(context).getString(FBInterId, "");
    }

    public static void setFBInterIdArry(Context context, int b) {
        getInstance(context).edit().putInt(FBInterIdArry, b).apply();
    }

    public static int getFBInterIdArry(Context context) {
        return getInstance(context).getInt(FBInterIdArry, 0);
    }

    public static void setALBannerId(Context context, String b) {
        getInstance(context).edit().putString(ALBannerId, b).apply();
    }

    public static String getALBannerId(Context context) {
        return getInstance(context).getString(ALBannerId, "");
    }

    public static void setALNativeId(Context context, String b) {
        getInstance(context).edit().putString(ALNativeId, b).apply();
    }

    public static String getALNativeId(Context context) {
        return getInstance(context).getString(ALNativeId, "");
    }

    public static void setALInterId(Context context, String b) {
        getInstance(context).edit().putString(ALInterId, b).apply();
    }

    public static String getALInterId(Context context) {
        return getInstance(context).getString(ALInterId, "");
    }

    public static void setInterClickCount(Context context, int b) {
        getInstance(context).edit().putInt(InterClickCount, b).apply();
    }

    public static int getInterClickCount(Context context) {
        return getInstance(context).getInt(InterClickCount, 0);
    }

    public static void setinterclickcount(Context context, int b) {
        getInstance(context).edit().putInt(interclickcount, b).apply();
    }

    public static int getinterclickcount(Context context) {
        return getInstance(context).getInt(interclickcount, 0);
    }

    public static void setBannerSpecific(Context context, int b) {
        getInstance(context).edit().putInt(BannerSpecific, b).apply();
    }

    public static int getBannerSpecific(Context context) {
        return getInstance(context).getInt(BannerSpecific, 0);
    }

    public static void setNativeSpecific(Context context, int b) {
        getInstance(context).edit().putInt(NativeSpecific, b).apply();
    }

    public static int getNativeSpecific(Context context) {
        return getInstance(context).getInt(NativeSpecific, 0);
    }

    public static void setInterSpecific(Context context, int b) {
        getInstance(context).edit().putInt(InterSpecific, b).apply();
    }

    public static int getInterSpecific(Context context) {
        return getInstance(context).getInt(InterSpecific, 0);
    }

    public static void setBannerSequns(Context context, int b) {
        getInstance(context).edit().putInt(BannerSequns, b).apply();
    }

    public static int getBannerSequns(Context context) {
        return getInstance(context).getInt(BannerSequns, 0);
    }

    public static void setNativeSequns(Context context, int b) {
        getInstance(context).edit().putInt(NativeSequns, b).apply();
    }

    public static int getNativeSequns(Context context) {
        return getInstance(context).getInt(NativeSequns, 0);
    }

    public static void setInterSequns(Context context, int b) {
        getInstance(context).edit().putInt(InterSequns, b).apply();
    }

    public static int getInterSequns(Context context) {
        return getInstance(context).getInt(InterSequns, 0);
    }

    public static void setAppOpenShow(Context context, int b) {
        getInstance(context).edit().putInt(AppOpenShow, b).apply();
    }

    public static int getAppOpenShow(Context context) {
        return getInstance(context).getInt(AppOpenShow, 0);
    }

    public static void setUpdateDilog(Context context, int b) {
        getInstance(context).edit().putInt(UpdateDilog, b).apply();
    }

    public static int getUpdateDilog(Context context) {
        return getInstance(context).getInt(UpdateDilog, 0);
    }

    public static void setUpdateCode(Context context, int b) {
        getInstance(context).edit().putInt(UpdateCode, b).apply();
    }

    public static int getUpdateCode(Context context) {
        return getInstance(context).getInt(UpdateCode, 0);
    }

    public static String getUpdateurl(Context context) {
        return getInstance(context).getString(Updateurl, "");
    }

    public static void setUpdateurl(Context context, String b) {
        getInstance(context).edit().putString(Updateurl, b).apply();
    }

    public static void setapplovinshow(Context context, int b) {
        getInstance(context).edit().putInt(applovinshow, b).apply();
    }

    public static int getapplovinshow(Context context) {
        return getInstance(context).getInt(applovinshow, 0);
    }

    public static void setapplovinAMFB(Context context, int b) {
        getInstance(context).edit().putInt(applovinAMFB, b).apply();
    }

    public static int getapplovinAMFB(Context context) {
        return getInstance(context).getInt(applovinAMFB, 0);
    }

    public static void setqurekashow(Context context, int b) {
        getInstance(context).edit().putInt(qurekashow, b).apply();
    }

    public static int getqurekashow(Context context) {
        return getInstance(context).getInt(qurekashow, 0);
    }

    public static String getqurekainterdilogshow(Context context) {
        return getInstance(context).getString(qurekainterdilogshow, "");
    }

    public static void setqurekainterdilogshow(Context context, String b) {
        getInstance(context).edit().putString(qurekainterdilogshow, b).apply();
    }

    public static void setqurekashowurl(Context context, String b) {
        getInstance(context).edit().putString(qurekashowurl, b).apply();
    }

    public static String getqurekashowurl(Context context) {
        return getInstance(context).getString(qurekashowurl, "");
    }

    public static String getbackgoundappopenshow(Context context) {
        return getInstance(context).getString(backgoundappopenshow, "");
    }

    public static void setbackgoundappopenshow(Context context, String b) {
        getInstance(context).edit().putString(backgoundappopenshow, b).apply();
    }

    public static void settimer(Context context, boolean value) {
        getInstance(context).edit().putBoolean(timer, value).apply();
    }

    public static boolean gettimer(Context context) {
        return getInstance(context).getBoolean(timer, false);
    }

    public static void setcountOnOff(Context context, String b) {
        getInstance(context).edit().putString(countOnOff, b).apply();
    }

    public static String getcountOnOff(Context context) {
        return getInstance(context).getString(countOnOff, "");
    }

    public static void setErrorDilogShow(Context context, String b) {
        getInstance(context).edit().putString(ErrorDilogShow, b).apply();
    }

    public static String getErrorDilogShow(Context context) {
        return getInstance(context).getString(ErrorDilogShow, "");
    }

    public static void setErrorDilogCode(Context context, String b) {
        getInstance(context).edit().putString(ErrorDilogCode, b).apply();
    }

    public static String getErrorDilogCode(Context context) {
        return getInstance(context).getString(ErrorDilogCode, "");
    }

    public static void setAdsShowleyer(Context context, String b) {
        getInstance(context).edit().putString(AdsShowleyer, b).apply();
    }

    public static String getAdsShowleyer(Context context) {
        return getInstance(context).getString(AdsShowleyer, "");
    }

    public static String getChackUserinet(Context context) {
        return getInstance(context).getString(ChackUserinet, "");
    }

    public static void setChackUserinet(Context context, String b) {
        getInstance(context).edit().putString(ChackUserinet, b).apply();
    }

    public static String getchackReferrer(Context context) {
        return getInstance(context).getString(chackReferrer, "");
    }

    public static void setchackReferrer(Context context, String b) {
        getInstance(context).edit().putString(chackReferrer, b).apply();
    }

    public static void setInternetDilog(Context context, String b) {
        getInstance(context).edit().putString(InternetDilog, b).apply();
    }

    public static String getInternetDilog(Context context) {
        return getInstance(context).getString(InternetDilog, "");
    }

    public static void setAdsTextShow(Context context, int b) {
        getInstance(context).edit().putInt(AdsTextShow, b).apply();
    }

    public static int getAdsTextShow(Context context) {
        return getInstance(context).getInt(AdsTextShow, 0);
    }

    public static String getusersequence(Context context) {
        return getInstance(context).getString(usersequence, "");
    }

    public static void setusersequence(Context context, String b) {
        getInstance(context).edit().putString(usersequence, b).apply();
    }
    public static String getextraPageShow(Context context) {
        return getInstance(context).getString(extraPageShow, "");
    }

    public static void setextraPageShow(Context context, String b) {
        getInstance(context).edit().putString(extraPageShow, b).apply();
    }
    public static boolean getoddevan(Context context) {
        return getInstance(context).getBoolean(oddevan, false);
    }

    public static void setoddevan(Context context, boolean value) {
        getInstance(context).edit().putBoolean(oddevan, value).apply();
    }

    public static void setScreen_chack(Context context, String value) {
        getInstance(context).edit().putString(Screen_chack, value).apply();
    }

    public static String getScreen_chack(Context context) {
        return getInstance(context).getString(Screen_chack, "");
    }
}
