package com.gbmashapp.statusdownloder.CateGoryTwo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.gbmashapp.statusdownloder.AdsDemo.InterstitialAds;
import com.gbmashapp.statusdownloder.AdsDemo.NativeAds;
import com.gbmashapp.statusdownloder.AdsDemo.SharedPrefs;
import com.gbmashapp.statusdownloder.CateGoryOne.CateGoryOneActivity;
import com.gbmashapp.statusdownloder.CateGoryOne.WebActivity;
import com.gbmashapp.statusdownloder.R;

public class CateGory_Two extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cate_gory_two);
        if (SharedPrefs.getAdsTextShow(this) == 1){
            findViewById(R.id.nativead_text).setVisibility(View.VISIBLE);
        }
        if (SharedPrefs.getAdsShowleyer(this).contains("CGTAN")) {
            findViewById(R.id.viewlayout).setVisibility(View.VISIBLE);
        }
        new NativeAds(this).nativeads(this, findViewById(R.id.native_container));

        findViewById(R.id.back).setOnClickListener(view -> {
            onBackPressed();
        });
        findViewById(R.id.cv_ascii_face).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    startActivity(new Intent(CateGory_Two.this, EmojiActivity.class));
                }
            });
        });
        findViewById(R.id.cv_text_repeater).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    startActivity(new Intent(CateGory_Two.this, TextRepeaterActivity.class));
                }
            });
        });
        findViewById(R.id.cv_caption_status).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    startActivity(new Intent(CateGory_Two.this, CaptionStatusActivity.class));
                }
            });
        });
        findViewById(R.id.cv_text_emoji).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    startActivity(new Intent(CateGory_Two.this, TexttoEmojiActivity.class));
                }
            });
        });
    }
}