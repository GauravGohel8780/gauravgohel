package com.gbmashapp.statusdownloder.CateGoryThree;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.gbmashapp.statusdownloder.AdsDemo.NativeAds;
import com.gbmashapp.statusdownloder.AdsDemo.SharedPrefs;
import com.gbmashapp.statusdownloder.R;

public class GB_DataActivity extends AppCompatActivity {
    TextView header_title, dital;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gb_data);
        if (SharedPrefs.getAdsTextShow(this) == 1){
            findViewById(R.id.nativead_text).setVisibility(View.VISIBLE);
        }
        if (SharedPrefs.getAdsShowleyer(this).contains("GDAN")) {
            findViewById(R.id.viewlayout).setVisibility(View.VISIBLE);
        }
        new NativeAds(this).nativeads(this, findViewById(R.id.native_container));


        findViewById(R.id.back).setOnClickListener(view -> {
            onBackPressed();
        });

        header_title = findViewById(R.id.header_title);
        dital = findViewById(R.id.dital);

        String data = getIntent().getStringExtra("data");

        if (data.equals("b1")) {
            header_title.setText("YOwhatsapp advice");
            dital.setText(R.string.dd1);
        } else if (data.equals("b2")) {
            header_title.setText("YOwhatsapp Characteristic");
            dital.setText(R.string.dd2);
        } else if (data.equals("b3")) {
            header_title.setText("Safe and Relaible");
            dital.setText(R.string.dd3);
        } else if (data.equals("b4")) {
            header_title.setText("Added feature");
            dital.setText(R.string.dd4);
        } else if (data.equals("b5")) {
            header_title.setText("Text System");
            dital.setText(R.string.dd5);
        } else if (data.equals("b6")) {
            header_title.setText("Transmit posts");
            dital.setText(R.string.dd6);
        } else if (data.equals("b7")) {
            header_title.setText("Modification");
            dital.setText(R.string.dd7);
        } else if (data.equals("b8")) {
            header_title.setText("Simple and Convenient");
            dital.setText(R.string.dd8);
        } else if (data.equals("b9")) {
            header_title.setText("Conclusion");
            dital.setText(R.string.dd9);
        }
    }
}