package com.gbmashapp.statusdownloder.CateGoryTwo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.gbmashapp.statusdownloder.AdsDemo.BannerAds;
import com.gbmashapp.statusdownloder.AdsDemo.InterstitialAds;
import com.gbmashapp.statusdownloder.AdsDemo.SharedPrefs;
import com.gbmashapp.statusdownloder.R;

public class CaptionStatusActivity extends AppCompatActivity {
    RecyclerView recyclerView;

    public String[] f11206AUK = {"Best", "Clever", "Cool", "Cute", "Fitness", "Funny", "Life", "Love", "Motivation", "Sad", "Savage", "Selfie", "Song"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caption_status);
        if (SharedPrefs.getAdsTextShow(this) == 1) {
            findViewById(R.id.bannerad_text).setVisibility(View.VISIBLE);
        }
        if (SharedPrefs.getAdsShowleyer(this).contains("CSAB")) {
            findViewById(R.id.viewlayout).setVisibility(View.VISIBLE);
        }
        new BannerAds(this).bannerads(this, findViewById(R.id.banner_container));
        findViewById(R.id.back).setOnClickListener(view -> {
            onBackPressed();
        });
        recyclerView = findViewById(R.id.captionrecyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        MyAdapter adapter = new MyAdapter(f11206AUK);
        recyclerView.setAdapter(adapter);
    }

    private static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView textView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            textView = itemView.findViewById(R.id.textView);
        }
    }

    // Create an Adapter for the RecyclerView
    private class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {
        private String[] data;

        MyAdapter(String[] data) {
            this.data = data;
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.caption_title_layout, parent, false);
            return new MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(MyViewHolder holder, int position) {
            holder.textView.setText(data[position]);
            holder.itemView.setOnClickListener(view -> {
                new InterstitialAds(CaptionStatusActivity.this).interads(CaptionStatusActivity.this, new InterstitialAds.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        Intent intent = new Intent(CaptionStatusActivity.this, CaptionitemActivity.class);
                        intent.putExtra("image", data[position]);
                        intent.putExtra("P", position);
                        startActivity(intent);
                    }
                });

            });

        }

        @Override
        public int getItemCount() {
            return data.length;
        }
    }

}