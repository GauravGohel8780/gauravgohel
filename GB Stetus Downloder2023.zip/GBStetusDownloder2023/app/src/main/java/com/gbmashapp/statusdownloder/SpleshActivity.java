package com.gbmashapp.statusdownloder;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.installreferrer.api.InstallReferrerClient;
import com.android.installreferrer.api.InstallReferrerStateListener;
import com.android.installreferrer.api.ReferrerDetails;
import com.gbmashapp.statusdownloder.AdsDemo.AppOpenAds;
import com.gbmashapp.statusdownloder.AdsDemo.SharedPrefs;
import com.gbmashapp.statusdownloder.AdsDemo.UpdateDiloge;
import com.gbmashapp.statusdownloder.ExtraScreen.Location_Gt_Start_Activity;
import com.gbmashapp.statusdownloder.ExtraScreen.Locationn_New_Activity;
import com.gbmashapp.statusdownloder.ExtraScreen.Music_M_M_Activity;
import com.gbmashapp.statusdownloder.ExtraScreen.PageFive_Activity;
import com.gbmashapp.statusdownloder.ExtraScreen.PageFourr_Activity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;

import org.json.JSONObject;

public class SpleshActivity extends AppCompatActivity {
    private FirebaseRemoteConfig mFirebaseRemoteConfig;
    String Ads, referrerUrl;
    Dialog dialog;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        FirebaseApp.initializeApp(this);
        setContentView(R.layout.activity_splesh);

        SharedPrefs.setinterclickcount(this, 0);
        SharedPrefs.setAMBannerIdArry(this, 0);
        SharedPrefs.setAMNativeIdArry(this, 0);
        SharedPrefs.setAMInterIdArry(this, 0);
        SharedPrefs.setFBBannerIdArry(this, 0);
        SharedPrefs.setFBNativeIdArry(this, 0);
        SharedPrefs.setFBInterIdArry(this, 0);
        SharedPrefs.settimer(this, false);
        SharedPrefs.setScreen_chack(this, "");

        if (isNetworkConnected(this)) {
            fachData();
        } else {
            try {
                if (!isNetworkConnected(this)) {
                    dialog = new Dialog(this);
                    dialog.setContentView(R.layout.chack_internet_layout);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    dialog.setCancelable(false);

                    if (!((Activity) this).isFinishing()) {
                        dialog.show();
                    }

                    Button retry = dialog.findViewById(R.id.btntry);

                    retry.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View view) {
                            if (isNetworkConnected(SpleshActivity.this)) {
                                fachData();
                                dialog.dismiss();
                            }
                        }
                    });
                } else if (isNetworkConnected(this)) {
                    tv = dialog.findViewById(R.id.tv);
                    tv.setText("internet connected Successfully");
                    tv.setBackgroundResource(R.color.green);
                    int colorFrom = Color.RED;
                    int colorTo = Color.GREEN;
                    int duration = 1000;
                    ObjectAnimator.ofObject(tv, "backgroundColor", new ArgbEvaluator(), colorFrom, colorTo).setDuration(duration).start();


                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            fachData();
                            dialog.dismiss();
                        }
                    }, 3000);

                }
            } catch (NullPointerException e) {
                Log.i("TAG", "CommingSoonDialog: " + e);
            }
        }

    }

    private void fachData() {
        InstallReferrerClient referrerClient;
        referrerClient = InstallReferrerClient.newBuilder(this).build();
        referrerClient.startConnection(new InstallReferrerStateListener() {
            @Override
            public void onInstallReferrerSetupFinished(int responseCode) {

                switch (responseCode) {
                    case InstallReferrerClient.InstallReferrerResponse.OK:
                        ReferrerDetails response = null;

                        try {
                            response = referrerClient.getInstallReferrer();
                        } catch (RemoteException e) {
                            throw new RuntimeException(e);
                        }

                        referrerUrl = response.getInstallReferrer();
                        long referrerClickTime = response.getReferrerClickTimestampSeconds();
                        long appInstallTime = response.getInstallBeginTimestampSeconds();
                        boolean instantExperienceLaunched = response.getGooglePlayInstantParam();

                        SharedPrefs.setChackUserinet(SpleshActivity.this, printSubsInDelimiters1(referrerUrl));

                        break;
                    case InstallReferrerClient.InstallReferrerResponse.FEATURE_NOT_SUPPORTED:

                        break;
                    case InstallReferrerClient.InstallReferrerResponse.SERVICE_UNAVAILABLE:

                        break;
                }
            }

            @Override
            public void onInstallReferrerServiceDisconnected() {

            }
        });

        mFirebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
        FirebaseRemoteConfigSettings configSettings = new FirebaseRemoteConfigSettings.Builder().setMinimumFetchIntervalInSeconds(3).build();
        mFirebaseRemoteConfig.setConfigSettingsAsync(configSettings);

        mFirebaseRemoteConfig.fetchAndActivate().addOnCompleteListener(this, new OnCompleteListener<Boolean>() {
            @Override
            public void onComplete(@NonNull Task<Boolean> task) {
                if (task.isSuccessful()) {

                    Ads = mFirebaseRemoteConfig.getString("Data");

                    try {
                        if (Ads != null) {
                            JSONObject jsonObject = new JSONObject(Ads);
                            SharedPrefs.setADsShow(SpleshActivity.this, jsonObject.getString("ADsShow"));
                            SharedPrefs.setSpeshscrennIntent(SpleshActivity.this, jsonObject.getString("SpeshscrennIntent"));
                            SharedPrefs.setAMAppOpenId(SpleshActivity.this, jsonObject.getString("AMAppOpenId"));
                            SharedPrefs.setAMBannerId(SpleshActivity.this, jsonObject.getString("AMBannerId"));
                            SharedPrefs.setAMNativeId(SpleshActivity.this, jsonObject.getString("AMNativeId"));
                            SharedPrefs.setAMInterId(SpleshActivity.this, jsonObject.getString("AMInterId"));
                            SharedPrefs.setFBBannerId(SpleshActivity.this, jsonObject.getString("FBBannerId"));
                            SharedPrefs.setFBNativeId(SpleshActivity.this, jsonObject.getString("FBNativeId"));
                            SharedPrefs.setFBInterId(SpleshActivity.this, jsonObject.getString("FBInterId"));
                            SharedPrefs.setALBannerId(SpleshActivity.this, jsonObject.getString("ALBannerId"));
                            SharedPrefs.setALNativeId(SpleshActivity.this, jsonObject.getString("ALNativeId"));
                            SharedPrefs.setALInterId(SpleshActivity.this, jsonObject.getString("ALInterId"));
                            SharedPrefs.setInterClickCount(SpleshActivity.this, jsonObject.getInt("InterClickCount"));
                            SharedPrefs.setBannerSpecific(SpleshActivity.this, jsonObject.getInt("BannerSpecific"));
                            SharedPrefs.setNativeSpecific(SpleshActivity.this, jsonObject.getInt("NativeSpecific"));
                            SharedPrefs.setInterSpecific(SpleshActivity.this, jsonObject.getInt("InterSpecific"));
                            SharedPrefs.setBannerSequns(SpleshActivity.this, jsonObject.getInt("BannerSequns"));
                            SharedPrefs.setNativeSequns(SpleshActivity.this, jsonObject.getInt("NativeSequns"));
                            SharedPrefs.setInterSequns(SpleshActivity.this, jsonObject.getInt("InterSequns"));
                            SharedPrefs.setAppOpenShow(SpleshActivity.this, jsonObject.getInt("AppOpenShow"));
                            SharedPrefs.setUpdateDilog(SpleshActivity.this, jsonObject.getInt("UpdateDilog"));
                            SharedPrefs.setUpdateCode(SpleshActivity.this, jsonObject.getInt("UpdateCode"));
                            SharedPrefs.setUpdateurl(SpleshActivity.this, jsonObject.getString("Updateurl"));
                            SharedPrefs.setapplovinshow(SpleshActivity.this, jsonObject.getInt("applovinshow"));
                            SharedPrefs.setapplovinAMFB(SpleshActivity.this, jsonObject.getInt("applovinAMFB"));
                            SharedPrefs.setqurekashow(SpleshActivity.this, jsonObject.getInt("qurekashow"));
                            SharedPrefs.setqurekainterdilogshow(SpleshActivity.this, jsonObject.getString("qurekainterdilogshow"));
                            SharedPrefs.setqurekashowurl(SpleshActivity.this, jsonObject.getString("qurekashowurl"));
                            SharedPrefs.setbackgoundappopenshow(SpleshActivity.this, jsonObject.getString("backgoundappopenshow"));
                            SharedPrefs.setcountOnOff(SpleshActivity.this, jsonObject.getString("countOnOff"));
                            SharedPrefs.setErrorDilogShow(SpleshActivity.this, jsonObject.getString("ErrorDilogShow"));
                            SharedPrefs.setErrorDilogCode(SpleshActivity.this, jsonObject.getString("ErrorDilogCode"));
                            SharedPrefs.setAdsShowleyer(SpleshActivity.this, jsonObject.getString("AdsShowleyer"));
                            SharedPrefs.setchackReferrer(SpleshActivity.this, jsonObject.getString("chackReferrer"));
                            SharedPrefs.setAdsTextShow(SpleshActivity.this, jsonObject.getInt("AdsTextShow"));
                            SharedPrefs.setInternetDilog(SpleshActivity.this, jsonObject.getString("InternetDilog"));
                            SharedPrefs.setusersequence(SpleshActivity.this, jsonObject.getString("usersequence"));
                            SharedPrefs.setextraPageShow(SpleshActivity.this, jsonObject.getString("extraPageShow"));

                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    if (SharedPrefs.getSpeshscrennIntent(SpleshActivity.this).equals("yes")) {
                                        StartApp();
                                    }
                                }
                            }, 1500);
                        }
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                } else {
                    Toast.makeText(SpleshActivity.this, "Please Check Your Internet Connection", Toast.LENGTH_SHORT).show();
                }
            }
        }).addOnFailureListener(this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(SpleshActivity.this, "Please Check Your Internet Connection....", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void StartApp() {
        if (SharedPrefs.getErrorDilogShow(SpleshActivity.this).equals("yes")) {
            if (SharedPrefs.getErrorDilogCode(SpleshActivity.this).contains("" + BuildConfig.VERSION_CODE)) {
                new UpdateDiloge(this).ShownotEnterDialog();
            } else {
                if (SharedPrefs.getUpdateDilog(SpleshActivity.this) == 1) {
                    if (SharedPrefs.getUpdateCode(this) != BuildConfig.VERSION_CODE) {
                        new UpdateDiloge(this).ShowUpdateDialog();
                    } else {
                        new AppOpenAds().loadAd(this, new AppOpenAds.OnAppOpenAdsListner() {
                            @Override
                            public void onAdsDismissed() {
                                splashintent();
                            }
                        });
                    }
                } else {
                    new AppOpenAds().loadAd(this, new AppOpenAds.OnAppOpenAdsListner() {
                        @Override
                        public void onAdsDismissed() {
                            splashintent();
                        }
                    });
                }
            }
        } else if (SharedPrefs.getErrorDilogShow(SpleshActivity.this).equals("no")) {
            if (SharedPrefs.getUpdateDilog(SpleshActivity.this) == 1) {
                if (SharedPrefs.getUpdateCode(this) != BuildConfig.VERSION_CODE) {
                    new UpdateDiloge(this).ShowUpdateDialog();
                } else {
                    new AppOpenAds().loadAd(this, new AppOpenAds.OnAppOpenAdsListner() {
                        @Override
                        public void onAdsDismissed() {
                            splashintent();
                        }
                    });
                }
            } else {
                new AppOpenAds().loadAd(this, new AppOpenAds.OnAppOpenAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        splashintent();
                    }
                });
            }
        }
    }

    public void splashintent() {
        if (SharedPrefs.getusersequence(SpleshActivity.this).equals("0")) {
            if (SharedPrefs.getextraPageShow(SpleshActivity.this).contains("1")) {
                Intent intent = new Intent(SpleshActivity.this, Music_M_M_Activity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            } else if (SharedPrefs.getextraPageShow(SpleshActivity.this).contains("2")) {
                Intent intent = new Intent(SpleshActivity.this, Locationn_New_Activity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            } else if (SharedPrefs.getextraPageShow(SpleshActivity.this).contains("3")) {
                Intent intent = new Intent(SpleshActivity.this, Location_Gt_Start_Activity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            } else if (SharedPrefs.getextraPageShow(SpleshActivity.this).contains("4")) {
                Intent intent = new Intent(SpleshActivity.this, PageFourr_Activity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            } else if (SharedPrefs.getextraPageShow(SpleshActivity.this).contains("5")) {
                Intent intent = new Intent(SpleshActivity.this, PageFive_Activity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            } else if (SharedPrefs.getextraPageShow(SpleshActivity.this).contains("6")) {
                Intent intent = new Intent(SpleshActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            } else {
                Intent intent = new Intent(SpleshActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        }
        else if (SharedPrefs.getusersequence(SpleshActivity.this).equals("1")) {
            Intent intent = new Intent(SpleshActivity.this, Music_M_M_Activity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        }
        else if (SharedPrefs.getusersequence(SpleshActivity.this).equals("2")) {
            if (!SharedPrefs.getoddevan(SpleshActivity.this)) {
                SharedPrefs.setoddevan(SpleshActivity.this, true);
                if (SharedPrefs.getextraPageShow(SpleshActivity.this).contains("1")) {
                    Intent intent = new Intent(SpleshActivity.this, Music_M_M_Activity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                } else if (SharedPrefs.getextraPageShow(SpleshActivity.this).contains("2")) {
                    Intent intent = new Intent(SpleshActivity.this, Locationn_New_Activity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                } else if (SharedPrefs.getextraPageShow(SpleshActivity.this).contains("3")) {
                    Intent intent = new Intent(SpleshActivity.this, Location_Gt_Start_Activity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                } else if (SharedPrefs.getextraPageShow(SpleshActivity.this).contains("4")) {
                    Intent intent = new Intent(SpleshActivity.this, PageFourr_Activity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                } else if (SharedPrefs.getextraPageShow(SpleshActivity.this).contains("5")) {
                    Intent intent = new Intent(SpleshActivity.this, PageFive_Activity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                } else if (SharedPrefs.getextraPageShow(SpleshActivity.this).contains("6")) {
                    Intent intent = new Intent(SpleshActivity.this, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                } else if (SharedPrefs.getextraPageShow(SpleshActivity.this).contains("7")) {
                    Intent intent = new Intent(SpleshActivity.this, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                } else {
                    Intent intent = new Intent(SpleshActivity.this, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }
            }
            else if (SharedPrefs.getoddevan(SpleshActivity.this)) {
                SharedPrefs.setoddevan(SpleshActivity.this, false);
                Intent intent = new Intent(SpleshActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        }
    }

    public String printSubsInDelimiters1(String str) {
        String ans = "";
        String[] arr = str.split("=", 2);
        ans = arr[0];
        return ans;
    }

    private boolean isNetworkConnected(Context context) {
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            return networkInfo != null && networkInfo.isConnected();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}