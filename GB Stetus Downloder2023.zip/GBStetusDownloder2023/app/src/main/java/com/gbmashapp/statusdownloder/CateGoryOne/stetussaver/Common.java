package com.gbmashapp.statusdownloder.CateGoryOne.stetussaver;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.RelativeLayout;

import com.google.android.material.snackbar.Snackbar;

import org.apache.commons.io.IOUtils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Common {
    public static final int GRID_COUNT = 2;

    public static final File STATUS_DIRECTORY = new File(Environment.getExternalStorageDirectory() +
            File.separator + "WhatsApp/Media/.Statuses");

    public static String APP_DIR;

    public static void copyFile(Status status, Context context, RelativeLayout container) {

        File file = new File(Common.APP_DIR);
        if (!file.exists()) {
            if (!file.mkdirs()) {
                Snackbar.make(container, "Something went wrong", Snackbar.LENGTH_SHORT).show();
            }
        }

        String fileName;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
        String currentDateTime = sdf.format(new Date());

        if (status.isVideo()) {
            fileName = "VID_" + currentDateTime + ".mp4";
        } else {
            fileName = "IMG_" + currentDateTime + ".jpg";
        }

        File destFile = new File(file + File.separator + fileName);

        try {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

                ContentValues values = new ContentValues();

                Uri destinationUri;

                values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH,
                        Environment.DIRECTORY_DCIM + "/status_saver");

                Uri collectionUri;
                if (status.isVideo()) {
                    values.put(MediaStore.MediaColumns.MIME_TYPE, "video/*");
                    collectionUri = MediaStore.Video.Media.getContentUri(
                            MediaStore.VOLUME_EXTERNAL_PRIMARY);
                } else {
                    values.put(MediaStore.MediaColumns.MIME_TYPE, "image/*");
                    collectionUri = MediaStore.Images.Media.getContentUri(
                            MediaStore.VOLUME_EXTERNAL_PRIMARY);
                }

                destinationUri = context.getContentResolver().insert(collectionUri, values);

                InputStream inputStream = context.getContentResolver().openInputStream(status.getDocumentFile().getUri());
                OutputStream outputStream = context.getContentResolver().openOutputStream(destinationUri);
                IOUtils.copy(inputStream, outputStream);

            } else {
                org.apache.commons.io.FileUtils.copyFile(status.getFile(), destFile);
                destFile.setLastModified(System.currentTimeMillis());
                new SingleMediaScanner(context, file);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
