package com.gbmashapp.statusdownloder.CateGoryOne;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Toast;

import com.gbmashapp.statusdownloder.AdsDemo.InterstitialAds;
import com.gbmashapp.statusdownloder.AdsDemo.NativeAds;
import com.gbmashapp.statusdownloder.AdsDemo.SharedPrefs;
import com.gbmashapp.statusdownloder.CateGoryOne.stetussaver.StetasSvareActivity;
import com.gbmashapp.statusdownloder.MainActivity;
import com.gbmashapp.statusdownloder.R;

public class CateGoryOneActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_RUNNER = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cate_gory_one);
        if (SharedPrefs.getAdsTextShow(this) == 1){
            findViewById(R.id.nativead_text).setVisibility(View.VISIBLE);
        }
        if (SharedPrefs.getAdsShowleyer(this).contains("CGOAN")) {
            findViewById(R.id.viewlayout).setVisibility(View.VISIBLE);
        }
        new NativeAds(this).nativeads(this, findViewById(R.id.native_container));
        findViewById(R.id.back).setOnClickListener(view -> {
            onBackPressed();
        });
        findViewById(R.id.cv_web).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    startActivity(new Intent(CateGoryOneActivity.this, WebActivity.class));
                }
            });
        });
        findViewById(R.id.cv_status_saver).setOnClickListener(view -> {
            if (checkWriteExternalPermission()) {
                new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        Intent intent = new Intent(CateGoryOneActivity.this, StetasSvareActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    }
                });
            }else {
                if (Build.VERSION.SDK_INT >= 33) {
                    if (!(ActivityCompat.checkSelfPermission(CateGoryOneActivity.this, "android.permission.READ_MEDIA_VIDEO") == 0 && ActivityCompat.checkSelfPermission(CateGoryOneActivity.this, "android.permission.READ_MEDIA_IMAGES") == 0 || ActivityCompat.checkSelfPermission(CateGoryOneActivity.this, "android.permission.READ_MEDIA_AUDIO") == 0) && !(ActivityCompat.checkSelfPermission(CateGoryOneActivity.this, "android.permission.READ_EXTERNAL_STORAGE") == 0)) {
                        ActivityCompat.requestPermissions(CateGoryOneActivity.this, new String[]{"android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_AUDIO"},
                                REQUEST_CODE_RUNNER);
                    }
                } else {
                    if (ContextCompat.checkSelfPermission(CateGoryOneActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(CateGoryOneActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                REQUEST_CODE_RUNNER);
                    }
                }
            }
        });
        findViewById(R.id.cv_direct_chat).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    startActivity(new Intent(CateGoryOneActivity.this, DirectMsgActivity.class));
                }
            });

        });
        findViewById(R.id.cv_cleaner).setOnClickListener(view -> {
            new InterstitialAds(this).interads(this, new InterstitialAds.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    Intent intent = new Intent(CateGoryOneActivity.this, MagicTextActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }
            });
        });
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_RUNNER) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
            }
        }
    }
    private boolean checkWriteExternalPermission() {
        int res;
        if (Build.VERSION.SDK_INT >= 33) {
            String permission = Manifest.permission.READ_MEDIA_AUDIO;
            res = checkCallingOrSelfPermission(permission);
        } else {
            String permission = Manifest.permission.WRITE_EXTERNAL_STORAGE;
            res = checkCallingOrSelfPermission(permission);
        }
        return (res == PackageManager.PERMISSION_GRANTED);
    }


}